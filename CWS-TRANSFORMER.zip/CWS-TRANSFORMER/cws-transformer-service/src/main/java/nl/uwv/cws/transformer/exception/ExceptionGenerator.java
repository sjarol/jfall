package nl.uwv.cws.transformer.exception;

/**
 * Generate Exception for different error situations. This utility class contains only static methods that make it easy
 * for developer to describe the error situation without having to choose which Exception to throw.
 */
public class ExceptionGenerator {

    private ExceptionGenerator() {}

    public static CwsInvalidInputException invalidInput(String message){
        return new CwsInvalidInputException(message);
    }

    public static CwsInvalidOutputException invalidOutput(String message) {
        return new CwsInvalidOutputException(message);
    }

    public static CwsException technicalException(String message){
        return new CwsException(message);
    }

    public static CwsException wrapException(String message, Throwable throwable){
        return new CwsException(message, throwable);
    }
}
