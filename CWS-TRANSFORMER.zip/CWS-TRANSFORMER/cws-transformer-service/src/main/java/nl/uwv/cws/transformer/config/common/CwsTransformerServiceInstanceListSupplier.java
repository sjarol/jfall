package nl.uwv.cws.transformer.config.common;

import nl.uwv.cws.transformer.exception.ExceptionGenerator;
import org.springframework.cloud.client.DefaultServiceInstance;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.loadbalancer.core.ServiceInstanceListSupplier;
import reactor.core.publisher.Flux;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class CwsTransformerServiceInstanceListSupplier implements ServiceInstanceListSupplier {

    private final String serviceId;
    private List<String> cwsLaHosts;

    public CwsTransformerServiceInstanceListSupplier(String serviceId, List<String> cwsLaHosts) {
        this.serviceId = serviceId;
        this.cwsLaHosts = Collections.unmodifiableList(cwsLaHosts);
    }

    @Override
    public String getServiceId() {
        return serviceId;
    }

    @Override
    public Flux<List<ServiceInstance>> get() {
        List<ServiceInstance> instance =
                cwsLaHosts.stream()
                        .map(hostAndPortPair -> {
                            String[] hostAndPort = hostAndPortPair.split(":");
                            if (hostAndPort.length < 2) {
                                throw ExceptionGenerator.technicalException(String.format("'%s' host and port is invalid.", hostAndPortPair));
                            }

                            final String host = hostAndPort[0];
                            final int port = Integer.parseInt(hostAndPort[1]);

                            return new DefaultServiceInstance(serviceId + "-" + host, null, host, port, false);
                        })
                        .collect(Collectors.toList());

        return Flux.just(instance);
    }
}
