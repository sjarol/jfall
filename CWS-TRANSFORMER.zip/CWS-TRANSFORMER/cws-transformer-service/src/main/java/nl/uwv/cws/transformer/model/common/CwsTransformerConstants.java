package nl.uwv.cws.transformer.model.common;

public final class CwsTransformerConstants {
    public static final String LEVER_CODE_CWS_LA = "CWS-LA";
    public static final String LEVER_CODE_CWS_NP = "CWS-NP";
    public static final String LEVER_CODE_CWS_HR = "CWS-HR";
    public static final String LEVER_CODE_CWS_IHP = "CWS-IHP";
    public static final String LEVER_CODE_CWS_WG = "CWS-WG";

    public static final String CWSLA_MAX_VERSION_DB_KEY = "transformer.berichtversie.max";
    public static final String CWSNP_MAX_VERSION_DB_KEY = "transformer.cwsnp.berichtversie.max";
    public static final String CWSHR_MAX_VERSION_DB_KEY = "transformer.cwshr.berichtversie.max";
    public static final String CWSIHP_MAX_VERSION_DB_KEY = "transformer.cwsihp.berichtversie.max";
    public static final String CWSWG_MAX_VERSION_DB_KEY = "transformer.cwswg.berichtversie.max";

    private CwsTransformerConstants() {}
}
