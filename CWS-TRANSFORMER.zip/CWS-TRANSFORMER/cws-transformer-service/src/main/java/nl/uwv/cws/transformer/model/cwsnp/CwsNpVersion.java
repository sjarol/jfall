package nl.uwv.cws.transformer.model.cwsnp;

import nl.uwv.cws.transformer.service.common.BaseCwsVersion;

public enum CwsNpVersion implements BaseCwsVersion {
    V0005("00", "05");

    private final String majorNpVersion;
    private final String minorNpVersion;

    CwsNpVersion(String majorVersion, String minorVersion) {
        this.majorNpVersion = majorVersion;
        this.minorNpVersion = minorVersion;
    }

    /**
     * @throws IllegalArgumentException if enum cannot be found with the requested major minor values
     */
    public static CwsNpVersion versionOf(String majorVersion, String minorVersion) {
        return valueOf("V" + majorVersion + minorVersion);
    }

    public static CwsNpVersion versionOf(String majorMinorVersion) {
        return valueOf("V" + majorMinorVersion);
    }

    @Override
    public String majorVersion() {
        return this.majorNpVersion;
    }

    @Override
    public String minorVersion() {
        return this.minorNpVersion;
    }

    @Override
    public String printVersion() {
        return this.majorNpVersion + this.minorNpVersion;
    }
}
