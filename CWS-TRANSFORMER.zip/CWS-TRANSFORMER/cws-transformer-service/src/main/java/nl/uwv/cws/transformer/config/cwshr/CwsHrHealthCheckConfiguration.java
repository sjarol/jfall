package nl.uwv.cws.transformer.config.cwshr;

import nl.uwv.cws.transformer.config.common.CwsHealthCheckServiceInstanceListSupplier;
import nl.uwv.cws.transformer.config.common.CwsTransformerServiceInstanceListSupplier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.client.loadbalancer.LoadBalancerProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.util.LinkedCaseInsensitiveMap;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.util.UriComponentsBuilder;

import java.time.Duration;
import java.util.List;
import java.util.Map;

@Configuration
public class CwsHrHealthCheckConfiguration {

    @Value("#{'${cws01.cwshr.hosts}'.split(',')}")
    private List<String> cwsHrHosts;

    @Value("${cws01.cwshr.healthcheck.interval}")
    private int healthCheckInterval;

    @Value("${cws01.cwshr.context.path}")
    private String cwsHrContextPath;

    @Bean
    CwsHealthCheckServiceInstanceListSupplier cwsHrHealthCheckServiceInstanceListSupplier() {
        LoadBalancerProperties.HealthCheck healthCheckProps = new LoadBalancerProperties.HealthCheck();
        healthCheckProps.setInterval(Duration.ofSeconds(healthCheckInterval));
        Map<String, String> path = new LinkedCaseInsensitiveMap<>();
        path.put("default", cwsHrContextPath + "/actuator/health");
        healthCheckProps.setPath(path);

        WebClient healthCheckWebClient = WebClient.builder().build();
        CwsTransformerServiceInstanceListSupplier cwsServiceInstanceListSupplier = new CwsTransformerServiceInstanceListSupplier("cws-hr-service", cwsHrHosts);

        return new CwsHealthCheckServiceInstanceListSupplier(cwsServiceInstanceListSupplier, healthCheckProps,
                (serviceInstance, healthCheckPath) -> healthCheckWebClient.get()
                        .uri(UriComponentsBuilder.fromUri(serviceInstance.getUri())
                        .path(healthCheckPath).build().toUri())
                        .exchangeToMono(clientResponse -> clientResponse.releaseBody()
                            .thenReturn(HttpStatus.OK.value() == clientResponse.rawStatusCode())));
    }
}