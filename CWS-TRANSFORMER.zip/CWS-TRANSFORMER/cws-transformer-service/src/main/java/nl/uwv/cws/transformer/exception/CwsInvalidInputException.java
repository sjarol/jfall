package nl.uwv.cws.transformer.exception;

public class CwsInvalidInputException extends CwsException {
    public CwsInvalidInputException(String message) {
        super(message);
    }
}
