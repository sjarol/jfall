package nl.uwv.cws.transformer.config.common;

import nl.uwv.cws.transformer.model.common.TransformerSettings;
import org.apache.hc.client5.http.config.RequestConfig;
import org.apache.hc.client5.http.cookie.StandardCookieSpec;
import org.apache.hc.client5.http.impl.async.CloseableHttpAsyncClient;
import org.apache.hc.client5.http.impl.async.HttpAsyncClients;
import org.apache.hc.core5.util.Timeout;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import javax.sql.DataSource;


@Configuration
public class CwsTransformerConfig {

    @Value("${apache.http.connection.timeout}")
    private int connectionTimeout;
    @Value("${apache.http.connection.request.timeout}")
    private int connectionRequestTimeout;
    @Value("${apache.http.socket.timeout}")
    private int socketTimeout;

    @Bean
    public CloseableHttpAsyncClient httpsAsyncClient5() {
        RequestConfig requestConfig = RequestConfig.custom()
                .setConnectTimeout(Timeout.ofSeconds(connectionTimeout))
                .setResponseTimeout(Timeout.ofSeconds(socketTimeout))
                .setConnectionRequestTimeout(Timeout.ofSeconds(connectionRequestTimeout))
                .setCookieSpec(StandardCookieSpec.IGNORE)
                .build();

        CloseableHttpAsyncClient httpAsyncClient = HttpAsyncClients.custom()
                .setDefaultRequestConfig(requestConfig)
                .build();
        httpAsyncClient.start();
        return httpAsyncClient;
    }

    @Bean
    public NamedParameterJdbcTemplate namedJdbcCws(DataSource dataSource) {
        return new NamedParameterJdbcTemplate(dataSource);
    }

    @Bean
    @ConfigurationProperties(prefix = "spring.datasource")
    public DataSource cwsTransformerDataSource() {
        return DataSourceBuilder.create().build();
    }

    @Bean
    public TransformerSettings cwsTransformerSettings() {
        return new TransformerSettings();
    }
}
