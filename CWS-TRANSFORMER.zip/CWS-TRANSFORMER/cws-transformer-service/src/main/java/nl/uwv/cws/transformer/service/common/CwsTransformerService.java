package nl.uwv.cws.transformer.service.common;

import nl.uwv.cws.transformer.model.common.TransformedCwsRequest;

public interface CwsTransformerService {

    TransformedCwsRequest transformRequest(String originalRequestXml);
    String transformResponse(final BaseCwsVersion originalCwsVersion, final String originalResponseXml);
}
