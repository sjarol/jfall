package nl.uwv.cws.transformer.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class PropertiesDao {

    @Autowired
    private NamedParameterJdbcTemplate jdbcTemplate;

    public String findPropertyByPropertyName(final String propertyName, final String leverCode) {
        SqlParameterSource namedParameters = new MapSqlParameterSource()
                .addValue("P_LEV_CODE", leverCode)
                .addValue("P_PROPERTY", propertyName);

        SimpleJdbcCall functionGetProperty = new SimpleJdbcCall(jdbcTemplate.getJdbcTemplate() )
                .withCatalogName("LEV_PROP")
                .withFunctionName("GET_PROPERTY")
                .withoutProcedureColumnMetaDataAccess()
                .declareParameters(
                        new SqlOutParameter("PROP_WAARDE",java.sql.Types.VARCHAR))
                .declareParameters(
                        new SqlParameter("P_LEV_CODE",java.sql.Types.VARCHAR))
                .declareParameters(
                        new SqlParameter("P_PROPERTY",java.sql.Types.VARCHAR))
                .declareParameters(
                        new SqlOutParameter("P_ERR_MSG",java.sql.Types.VARCHAR));

        Map<String,Object> resultMap = functionGetProperty.execute(namedParameters);
        String propWaarde = (String) resultMap.get("PROP_WAARDE");

        if (propWaarde==null) {
            String errMsg = (String) resultMap.get("P_ERR_MSG");
            throw new IllegalArgumentException("Could not retrieve property["+propertyName+"]. P_ERR_MSG=" + errMsg);
        }

        return propWaarde;
    }
}