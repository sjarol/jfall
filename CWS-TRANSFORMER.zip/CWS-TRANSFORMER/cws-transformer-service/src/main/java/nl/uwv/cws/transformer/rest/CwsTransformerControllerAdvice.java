package nl.uwv.cws.transformer.rest;

import nl.uwv.cws.transformer.exception.CwsException;
import nl.uwv.cws.transformer.exception.CwsInvalidInputException;
import nl.uwv.cws.transformer.exception.CwsInvalidOutputException;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

@RestControllerAdvice
public class CwsTransformerControllerAdvice {
    private static final Logger log = LoggerFactory.getLogger(CwsTransformerControllerAdvice.class);

    @Value("classpath:/soap/common-technical-error-message.xml")
    private Resource commonTechErrorResource;
    private ResponseEntity<String> commonTechErrorMessage;

    @Value("classpath:/soap/invalid-request-message.xml")
    private Resource invalidRequestErrorResource;
    private ResponseEntity<String> invalidRequestErrorMessage;

    @Value("classpath:/soap/invalid-response-message.xml")
    private Resource invalidResponseErrorResource;
    private ResponseEntity<String> invalidResponseErrorMessage;

    @Value("classpath:/soap/common-technical-error-message.xml")
    private Resource serviceUnavailableExceptionResponseErrorResource;
    private ResponseEntity<String> serviceUnavailableResponseErrorMessage;

    @Value("classpath:/soap/client-error-response-message.xml")
    private Resource clientErrorResponseResource;
    private ResponseEntity<String> clientErrorResponseMessage;

    @PostConstruct
    public void postConstruct() throws IOException {
        MultiValueMap<String, String> responseHeaders = new HttpHeaders();
        responseHeaders.add("Content-Type", "text/xml;charset=UTF-8");
        final String commonTechResponseBody = IOUtils.toString(commonTechErrorResource.getInputStream(), StandardCharsets.UTF_8);
        this.commonTechErrorMessage = new ResponseEntity<>(commonTechResponseBody, responseHeaders, HttpStatus.INTERNAL_SERVER_ERROR);

        final String invalidRequestResponseBody = IOUtils.toString(invalidRequestErrorResource.getInputStream(), StandardCharsets.UTF_8);
        this.invalidRequestErrorMessage = new ResponseEntity<>(invalidRequestResponseBody, responseHeaders, HttpStatus.INTERNAL_SERVER_ERROR);

        final String invalidResponseResponseBody = IOUtils.toString(invalidResponseErrorResource.getInputStream(), StandardCharsets.UTF_8);
        this.invalidResponseErrorMessage = new ResponseEntity<>(invalidResponseResponseBody, responseHeaders, HttpStatus.INTERNAL_SERVER_ERROR);

        final String serviceUnavailableResponseBody = IOUtils.toString(serviceUnavailableExceptionResponseErrorResource.getInputStream(), StandardCharsets.UTF_8);
        this.serviceUnavailableResponseErrorMessage = new ResponseEntity<>(serviceUnavailableResponseBody, responseHeaders, HttpStatus.UNAUTHORIZED);

        final String clientErrorResponseMessageBody = IOUtils.toString(clientErrorResponseResource.getInputStream(), StandardCharsets.UTF_8);
        this.clientErrorResponseMessage = new ResponseEntity<>(clientErrorResponseMessageBody, responseHeaders, HttpStatus.UNAUTHORIZED);
    }

    @ExceptionHandler(CwsInvalidInputException.class)
    public ResponseEntity<String> cwsInvalidInputException(CwsInvalidInputException exception) {
        log.error("Ongeldig invoer ontvangen met melding: {} ", exception.getMessage(), exception);
        return invalidRequestErrorMessage;
    }

    @ExceptionHandler(CwsInvalidOutputException.class)
    public ResponseEntity<String> cwsInvalidOutputException(CwsInvalidOutputException exception) {
        log.error("Ongeldig antwoordbericht ontvangen met melding: {} ", exception.getMessage(), exception);
        return invalidResponseErrorMessage;
    }

    @ExceptionHandler(CwsException.class)
    public ResponseEntity<String> cwsException(CwsException exception) {
        log.error("CWS fout ontvangen met melding: {} ", exception.getMessage(), exception);
        return commonTechErrorMessage;
    }

    @ExceptionHandler(value = WebClientResponseException.class)
    public ResponseEntity<String> handleWebClientResponseException(WebClientResponseException exception) {
        HttpStatus httpStatus = exception.getStatusCode();
        if (httpStatus.equals(HttpStatus.SERVICE_UNAVAILABLE)) {
            log.error("Backend problem: HTTP status code {} Load balancer is not able not connect to CWS, check CWS instance health", exception.getStatusCode());
            return serviceUnavailableResponseErrorMessage;
        } else if (httpStatus.is4xxClientError()) {
            log.warn("Client probleem: {} ", exception.getMessage());
            return clientErrorResponseMessage;
        }
        log.error("CWS fout ontvangen met melding: {} ", exception.getMessage(), exception);
        return commonTechErrorMessage;
    }

    @ExceptionHandler(value = Exception.class)
    public ResponseEntity<String> unknownException(Exception exception) {
        log.error("Onverwacht fout ontvangen met melding: {} ", exception.getMessage(), exception);
        return commonTechErrorMessage;
    }
}
