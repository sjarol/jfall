package nl.uwv.cws.transformer.model.common;

import nl.uwv.cws.transformer.service.common.BaseCwsVersion;

public class TransformedCwsRequest {
    private BaseCwsVersion originalCwsVersion;
    private String transformedRequestXml;

    public BaseCwsVersion getOriginalCwsVersion() {
        return originalCwsVersion;
    }

    public void setOriginalCwsVersion(BaseCwsVersion originalCwsVersion) {
        this.originalCwsVersion = originalCwsVersion;
    }

    public String getTransformedRequestXml() {
        return transformedRequestXml;
    }

    public void setTransformedRequestXml(String transformedRequestXml) {
        this.transformedRequestXml = transformedRequestXml;
    }
}
