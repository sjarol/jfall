package nl.uwv.cws.transformer.service.cwswg;

import lombok.extern.slf4j.Slf4j;
import nl.uwv.cws.transformer.exception.ExceptionGenerator;
import nl.uwv.cws.transformer.model.common.TransformedCwsRequest;
import nl.uwv.cws.transformer.model.common.TransformerSettings;
import nl.uwv.cws.transformer.model.cwswg.CwsWgVersion;
import nl.uwv.cws.transformer.service.common.BaseCwsVersion;
import nl.uwv.cws.transformer.service.common.BaseTransformerService;
import nl.uwv.cws.transformer.service.common.CwsTransformerService;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static org.apache.logging.log4j.util.Strings.isNotEmpty;

@Slf4j
@Component
public class CwsWgTransformerService extends BaseTransformerService implements CwsTransformerService {
    private static final Pattern CWSWG_REQUEST_NAMESPACE_PATTERN = Pattern.compile("(http://schemas.uwv.nl/UwvML/Berichten/CwsWerkgeverRequest-v)([0-9]{2})([0-9]{2})([0-9]*)");
    private static final Pattern CWSWG_RESPONSE_NAMESPACES_PATTERN = Pattern.compile("(http://schemas.uwv.nl/UwvML/Berichten/CwsWerkgever)(Request|Response)(-v)([0-9]{2})([0-9]{2})");

    @Resource
    private TransformerSettings cwsWgTransformerSettings;

    @Override
    public TransformedCwsRequest transformRequest(String originalRequestXml) {
        TransformedCwsRequest transformedCwsRequest = extractAndReplaceNamespaceVersion(originalRequestXml);
        final String requestId = extractRequestId(transformedCwsRequest.getTransformedRequestXml());
        final String originalVersion = transformedCwsRequest.getOriginalCwsVersion().printVersion();
        final String maxVersion = cwsWgTransformerSettings.getCwsWgMaxVersion().printVersion();

        log.info("Vraagbericht met id '{}' is van v{} naar v{} omgezet", requestId, originalVersion, maxVersion);
        findAndSetRequestMinorHeader(transformedCwsRequest);
        findAndSetRequestMajorHeader(transformedCwsRequest);
        return transformedCwsRequest;
    }

    private TransformedCwsRequest extractAndReplaceNamespaceVersion(String originalRequestXml) {
        TransformedCwsRequest transformedCwsRequest = new TransformedCwsRequest();
        Matcher namespaceMatcher = CWSWG_REQUEST_NAMESPACE_PATTERN.matcher(originalRequestXml);
        if (namespaceMatcher.find()) {
            String major = namespaceMatcher.group(2);
            String minor = namespaceMatcher.group(3);
            String extraNumber = namespaceMatcher.group(4);
            if (isNotEmpty(extraNumber)) {
                throw ExceptionGenerator.invalidInput("Request is invalid: incorrect CWS-WG namespace");
            }
            transformedCwsRequest.setOriginalCwsVersion(findCwsWgVersionWithMajorMinor(major, minor));

            if (!transformedCwsRequest.getOriginalCwsVersion().equals(cwsWgTransformerSettings.getCwsWgMaxVersion())) {
                String transformedXml = namespaceMatcher.replaceAll("$1" + cwsWgTransformerSettings.getCwsWgMaxVersion().printVersion());
                transformedCwsRequest.setTransformedRequestXml(transformedXml);
            } else {
                transformedCwsRequest.setTransformedRequestXml(originalRequestXml);
            }
        } else {
            throw ExceptionGenerator.invalidInput("Request is invalid: incorrect CWS-WG namespace");
        }
        return transformedCwsRequest;
    }

    private CwsWgVersion findCwsWgVersionWithMajorMinor(String major, String minor) {
        CwsWgVersion cwsWgVersion;
        try {
            cwsWgVersion = CwsWgVersion.versionOf(major, minor);
        } catch (IllegalArgumentException ex) {
            throw ExceptionGenerator.invalidInput("Ongeldige xml met major minor versie: " + major + minor);
        }
        return cwsWgVersion;
    }

    @Override
    public String transformResponse(BaseCwsVersion originalCwsVersion, String originalResponseXml) {
        Matcher namespaceMatcher = CWSWG_RESPONSE_NAMESPACES_PATTERN.matcher(originalResponseXml);
        if (namespaceMatcher.find()) {
            String transformedResponseXml = originalResponseXml;
            if (!originalCwsVersion.equals(cwsWgTransformerSettings.getCwsWgMaxVersion())) {
                transformedResponseXml = namespaceMatcher.replaceAll("$1$2$3" + originalCwsVersion.printVersion());
            }

            final String requestId = extractRequestId(transformedResponseXml);
            final String originalVersion = originalCwsVersion.printVersion();
            final String maxVersion = cwsWgTransformerSettings.getCwsWgMaxVersion().printVersion();
            log.info("Antwoordbericht met id '{}' is van v{} naar v{} omgezet", requestId, maxVersion, originalVersion);

            return transformedResponseXml;
        } else {
            throw ExceptionGenerator.invalidOutput("Response is invalid missing expected CWS-WG namespace");
        }
    }
}
