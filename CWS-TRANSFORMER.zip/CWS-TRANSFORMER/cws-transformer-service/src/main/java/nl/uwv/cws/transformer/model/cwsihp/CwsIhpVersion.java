package nl.uwv.cws.transformer.model.cwsihp;

import nl.uwv.cws.transformer.service.common.BaseCwsVersion;

public enum CwsIhpVersion implements BaseCwsVersion {
    V0007("00", "07");

    private final String majorIhpVersion;
    private final String minorIhpVersion;

    CwsIhpVersion(String majorVersion, String minorVersion) {
        this.majorIhpVersion = majorVersion;
        this.minorIhpVersion = minorVersion;
    }

    /**
     * @throws IllegalArgumentException if enum cannot be found with the requested major minor values
     */
    public static CwsIhpVersion versionOf(String majorVersion, String minorVersion) {
        return valueOf("V" + majorVersion + minorVersion);
    }

    public static CwsIhpVersion versionOf(String majorMinorVersion) {
        return valueOf("V" + majorMinorVersion);
    }

    @Override
    public String majorVersion() {
        return this.majorIhpVersion;
    }

    @Override
    public String minorVersion() {
        return this.minorIhpVersion;
    }

    @Override
    public String printVersion() {
        return this.majorIhpVersion + this.minorIhpVersion;
    }
}
