package nl.uwv.cws.transformer.service.cwshr;

import lombok.extern.slf4j.Slf4j;
import nl.uwv.cws.transformer.exception.ExceptionGenerator;
import nl.uwv.cws.transformer.model.common.TransformedCwsRequest;
import nl.uwv.cws.transformer.model.common.TransformerSettings;
import nl.uwv.cws.transformer.model.cwshr.CwsHrVersion;
import nl.uwv.cws.transformer.service.common.BaseCwsVersion;
import nl.uwv.cws.transformer.service.common.BaseTransformerService;
import nl.uwv.cws.transformer.service.common.CwsTransformerService;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static org.apache.logging.log4j.util.Strings.isNotEmpty;

@Slf4j
@Component
public class CwsHrTransformerService extends BaseTransformerService implements CwsTransformerService {
    private static final Pattern CWSHR_REQUEST_NAMESPACE_PATTERN = Pattern.compile("(http://schemas.uwv.nl/UwvML/Berichten/CwsHandelsregisterRequest-v)([0-9]{2})([0-9]{2})([0-9]*)");
    private static final Pattern CWSHR_RESPONSE_NAMESPACES_PATTERN = Pattern.compile("(http://schemas.uwv.nl/UwvML/Berichten/CwsHandelsregister)(Request|Response)(-v)([0-9]{2})([0-9]{2})");

    @Resource
    private TransformerSettings transformerSettings;

    @Override
    public TransformedCwsRequest transformRequest(String originalRequestXml) {
        TransformedCwsRequest transformedCwsRequest = extractAndReplaceNamespaceVersion(originalRequestXml);
        final String requestId = extractRequestId(transformedCwsRequest.getTransformedRequestXml());
        final String originalVersion = transformedCwsRequest.getOriginalCwsVersion().printVersion();
        final String maxVersion = transformerSettings.getCwsHrMaxVersion().printVersion();

        log.info("Vraagbericht met id '{}' is van v{} naar v{} omgezet", requestId, originalVersion, maxVersion);
        findAndSetRequestMinorHeader(transformedCwsRequest);
        findAndSetRequestMajorHeader(transformedCwsRequest);
        return transformedCwsRequest;
    }

    private TransformedCwsRequest extractAndReplaceNamespaceVersion(String originalRequestXml) {
        TransformedCwsRequest transformedCwsRequest = new TransformedCwsRequest();
        Matcher namespaceMatcher = CWSHR_REQUEST_NAMESPACE_PATTERN.matcher(originalRequestXml);
        if (namespaceMatcher.find()) {
            String major = namespaceMatcher.group(2);
            String minor = namespaceMatcher.group(3);
            String extraNumber = namespaceMatcher.group(4);
            if (isNotEmpty(extraNumber)) {
                throw ExceptionGenerator.invalidInput("Request is invalid: incorrect CWS-HR namespace");
            }
            transformedCwsRequest.setOriginalCwsVersion(findCwsHrVersionWithMajorMinor(major, minor));

            if (!transformedCwsRequest.getOriginalCwsVersion().equals(transformerSettings.getCwsHrMaxVersion())) {
                String transformedXml = namespaceMatcher.replaceAll("$1" + transformerSettings.getCwsHrMaxVersion().printVersion());
                transformedCwsRequest.setTransformedRequestXml(transformedXml);
            } else {
                transformedCwsRequest.setTransformedRequestXml(originalRequestXml);
            }
        } else {
            throw ExceptionGenerator.invalidInput("Request is invalid: incorrect CWS-HR namespace");
        }
        return transformedCwsRequest;
    }

    private CwsHrVersion findCwsHrVersionWithMajorMinor(String major, String minor) {
        CwsHrVersion cwsHrVersion;
        try {
            cwsHrVersion = CwsHrVersion.versionOf(major, minor);
        } catch (IllegalArgumentException ex) {
            throw ExceptionGenerator.invalidInput("Ongeldige xml met major minor versie: " + major + minor);
        }
        return cwsHrVersion;
    }

    @Override
    public String transformResponse(BaseCwsVersion originalCwsVersion, String originalResponseXml) {
        Matcher namespaceMatcher = CWSHR_RESPONSE_NAMESPACES_PATTERN.matcher(originalResponseXml);
        if (namespaceMatcher.find()) {
            String transformedResponseXml = originalResponseXml;
            if (!originalCwsVersion.equals(transformerSettings.getCwsHrMaxVersion())) {
                transformedResponseXml = namespaceMatcher.replaceAll("$1$2$3" + originalCwsVersion.printVersion());
            }

            final String requestId = extractRequestId(transformedResponseXml);
            final String originalVersion = originalCwsVersion.printVersion();
            final String maxVersion = transformerSettings.getCwsHrMaxVersion().printVersion();
            log.info("Antwoordbericht met id '{}' is van v{} naar v{} omgezet", requestId, maxVersion, originalVersion);

            return transformedResponseXml;
        } else {
            throw ExceptionGenerator.invalidOutput("Response is invalid missing expected CWS-HR namespace");
        }
    }
}
