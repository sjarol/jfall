package nl.uwv.cws.transformer.rest.cwsihp;

import lombok.extern.slf4j.Slf4j;
import nl.uwv.cws.transformer.model.common.TransformedCwsRequest;
import nl.uwv.cws.transformer.rest.common.BaseController;
import nl.uwv.cws.transformer.service.cwsihp.CwsIhpTransformerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StopWatch;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.List;

import static java.util.Arrays.asList;
import static org.springframework.http.MediaType.TEXT_XML_VALUE;

@Slf4j
@RestController
@RequestMapping("/cwsihp")
public class CwsIhpTransformerController extends BaseController {
    private static final List<String> HEADERS_TO_EXCLUDE = asList("content-length","host");

    @Value("${cws01.cwsihp.context.path}")
    private String cwsIhpContextPath;

    @Value("${cws01.cwsihp.soap.address}")
    private String cwsIhpSoapAddress;

    @Autowired
    @Qualifier("cws-ihp")
    private WebClient loadBalancedWebClient;

    @Autowired
    private CwsIhpTransformerService cwsIhpTransformerService;

    @GetMapping(produces = TEXT_XML_VALUE)
    public Mono<String> getWsdl(@RequestHeader HttpHeaders inboundHttpHeaders){
        final String endpoint = cwsIhpContextPath + cwsIhpSoapAddress + "?wsdl";
        HttpHeaders outboundHttpHeaders = filterHeaders(inboundHttpHeaders, HEADERS_TO_EXCLUDE);
        return doGetWsdl(loadBalancedWebClient, outboundHttpHeaders, endpoint);
    }

    @PostMapping(produces = TEXT_XML_VALUE)
    public Mono<ResponseEntity<String>> cwsIhpCall(@RequestHeader HttpHeaders headers, @RequestBody String request) {
        return sendAsync(headers, request);
    }

    private Mono<ResponseEntity<String>> sendAsync(HttpHeaders inboundHttpHeaders, String requestBody){
        final String endpoint = cwsIhpContextPath + cwsIhpSoapAddress;
        return doSendAsync(inboundHttpHeaders, requestBody, endpoint, cwsIhpTransformerService, loadBalancedWebClient);
    }
}
