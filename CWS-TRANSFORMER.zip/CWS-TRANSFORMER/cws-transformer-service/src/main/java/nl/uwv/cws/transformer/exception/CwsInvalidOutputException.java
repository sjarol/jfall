package nl.uwv.cws.transformer.exception;

public class CwsInvalidOutputException extends CwsException {
    public CwsInvalidOutputException(String message) {
        super(message);
    }
}
