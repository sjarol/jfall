package nl.uwv.cws.transformer.config.cwsnp;

import nl.uwv.cws.transformer.config.common.CwsHealthCheckServiceInstanceListSupplier;
import nl.uwv.cws.transformer.config.common.CwsTransformerServiceInstanceListSupplier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.client.loadbalancer.LoadBalancerProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.util.LinkedCaseInsensitiveMap;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.util.UriComponentsBuilder;

import java.time.Duration;
import java.util.List;
import java.util.Map;

@Configuration
public class CwsNpHealthCheckConfiguration {

    @Value("#{'${cws01.cwsnp.hosts}'.split(',')}")
    private List<String> cwsNpHosts;

    @Value("${cws01.cwsnp.healthcheck.interval}")
    private int healthCheckInterval;

    @Value("${cws01.cwsnp.context.path}")
    private String cwsNpContextPath;

    @Bean
    CwsHealthCheckServiceInstanceListSupplier cwsNpHealthCheckServiceInstanceListSupplier() {
        LoadBalancerProperties.HealthCheck healthCheckProps = new LoadBalancerProperties.HealthCheck();
        healthCheckProps.setInterval(Duration.ofSeconds(healthCheckInterval));
        Map<String, String> path = new LinkedCaseInsensitiveMap<>();
        path.put("default", cwsNpContextPath + "/actuator/health");
        healthCheckProps.setPath(path);

        WebClient healthCheckWebClient = WebClient.builder().build();
        CwsTransformerServiceInstanceListSupplier cwsServiceInstanceListSupplier = new CwsTransformerServiceInstanceListSupplier("cws-np-service", cwsNpHosts);

        return new CwsHealthCheckServiceInstanceListSupplier(cwsServiceInstanceListSupplier, healthCheckProps,
                (serviceInstance, healthCheckPath) -> healthCheckWebClient.get()
                        .uri(UriComponentsBuilder.fromUri(serviceInstance.getUri())
                        .path(healthCheckPath).build().toUri())
                        .exchangeToMono(
                            clientResponse -> clientResponse.releaseBody()
                            .thenReturn(HttpStatus.OK.value() == clientResponse.rawStatusCode())));

    }
}