package nl.uwv.cws.transformer.model.cwsla;

import nl.uwv.cws.transformer.service.common.BaseCwsVersion;

public enum CwsLaVersion implements BaseCwsVersion {
    V0008("00", "08"),
    V0009("00", "09"),
    V0102("01", "02"),
    V0104("01", "04"),
    V0107("01", "07");

    private final String majorLaVersion;
    private final String minorLaVersion;

    CwsLaVersion(String majorVersion, String minorVersion) {
        this.majorLaVersion = majorVersion;
        this.minorLaVersion = minorVersion;
    }

    /**
     * @throws IllegalArgumentException if enum cannot be found with the requested major minor values
     */
    public static CwsLaVersion versionOf(String majorVersion, String minorVersion) {
        return valueOf("V" + majorVersion + minorVersion);
    }

    public static CwsLaVersion versionOf(String majorMinorVersion) {
        return valueOf("V" + majorMinorVersion);
    }

    @Override
    public String majorVersion() {
        return this.majorLaVersion;
    }

    @Override
    public String minorVersion() {
        return this.minorLaVersion;
    }

    @Override
    public String printVersion() {
        return this.majorLaVersion + this.minorLaVersion;
    }
}
