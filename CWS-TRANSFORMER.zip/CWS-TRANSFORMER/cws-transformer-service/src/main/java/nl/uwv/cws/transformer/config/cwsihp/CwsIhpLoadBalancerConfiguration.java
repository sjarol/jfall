package nl.uwv.cws.transformer.config.cwsihp;

import org.apache.hc.client5.http.impl.async.CloseableHttpAsyncClient;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.client.loadbalancer.reactive.ReactorLoadBalancerExchangeFilterFunction;
import org.springframework.cloud.loadbalancer.annotation.LoadBalancerClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.reactive.ClientHttpConnector;
import org.springframework.http.client.reactive.HttpComponentsClientHttpConnector;
import org.springframework.web.reactive.function.client.WebClient;


@Configuration
@LoadBalancerClient(name = "cws-ihp-service", configuration = {CwsIhpHealthCheckConfiguration.class})
public class CwsIhpLoadBalancerConfiguration {

    @Value("${cws01.cwsihp.webclient.codecs.max.buffer.size}")
    private int maxBufferSize;

    @Bean
    @Qualifier("cws-ihp")
    public WebClient getCwsIhpLoadBalancedWebClient(ReactorLoadBalancerExchangeFilterFunction reactorLoadBalancerExchangeFilterFunction, CloseableHttpAsyncClient httpAsyncClient) {
        ClientHttpConnector connector = new HttpComponentsClientHttpConnector(httpAsyncClient);

        return WebClient.builder()
                .codecs(configurer -> configurer.defaultCodecs().maxInMemorySize(maxBufferSize))
                .filter(reactorLoadBalancerExchangeFilterFunction)
                .clientConnector(connector)
                .baseUrl("http://cws-ihp-service")
                .build();
    }
}
