package nl.uwv.cws.transformer.config.common;

import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.loadbalancer.LoadBalancerProperties;
import org.springframework.cloud.loadbalancer.core.HealthCheckServiceInstanceListSupplier;
import org.springframework.cloud.loadbalancer.core.ServiceInstanceListSupplier;
import reactor.core.publisher.Mono;

import java.util.function.BiFunction;

public class CwsHealthCheckServiceInstanceListSupplier extends HealthCheckServiceInstanceListSupplier {

    /**
     * @deprecated Healthcheck should be replaced by Factory<ServiceInstance>
     */
    @Deprecated
    public CwsHealthCheckServiceInstanceListSupplier(final ServiceInstanceListSupplier delegate, final LoadBalancerProperties.HealthCheck healthCheck, final BiFunction<ServiceInstance, String, Mono<Boolean>> aliveFunction) {
        super(delegate, healthCheck, aliveFunction);
    }
}
