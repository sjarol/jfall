package nl.uwv.cws.transformer.model.common;

import lombok.Getter;
import lombok.Setter;
import nl.uwv.cws.transformer.model.cwshr.CwsHrVersion;
import nl.uwv.cws.transformer.model.cwsihp.CwsIhpVersion;
import nl.uwv.cws.transformer.model.cwsla.CwsLaVersion;
import nl.uwv.cws.transformer.model.cwsnp.CwsNpVersion;
import nl.uwv.cws.transformer.model.cwswg.CwsWgVersion;

@Setter
@Getter
public class TransformerSettings {
    private CwsLaVersion cwsLaMaxVersion;
    private CwsNpVersion cwsNpMaxVersion;
    private CwsHrVersion cwsHrMaxVersion;
    private CwsIhpVersion cwsIhpMaxVersion;
    private CwsWgVersion cwsWgMaxVersion;
}
