package nl.uwv.cws.transformer.service.common;

public interface BaseCwsVersion {
    String majorVersion();
    String minorVersion();
    String printVersion();
}
