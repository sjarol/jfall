package nl.uwv.cws.transformer.model.cwshr;

import nl.uwv.cws.transformer.service.common.BaseCwsVersion;

public enum CwsHrVersion implements BaseCwsVersion {
    V0105("01", "05"),
    V0106("01", "06"),
    V0107("01", "07");

    private final String majorHrVersion;
    private final String minorHrVersion;

    CwsHrVersion(String majorVersion, String minorVersion) {
        this.majorHrVersion = majorVersion;
        this.minorHrVersion = minorVersion;
    }

    /**
     * @throws IllegalArgumentException if enum cannot be found with the requested major minor values
     */
    public static CwsHrVersion versionOf(String majorVersion, String minorVersion) {
        return valueOf("V" + majorVersion + minorVersion);
    }

    public static CwsHrVersion versionOf(String majorMinorVersion) {
        return valueOf("V" + majorMinorVersion);
    }

    @Override
    public String majorVersion() {
        return this.majorHrVersion;
    }

    @Override
    public String minorVersion() {
        return this.minorHrVersion;
    }

    @Override
    public String printVersion() {
        return this.majorHrVersion + this.minorHrVersion;
    }
}
