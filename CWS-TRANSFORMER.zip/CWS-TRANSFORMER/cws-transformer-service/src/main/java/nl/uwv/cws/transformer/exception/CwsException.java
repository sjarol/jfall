package nl.uwv.cws.transformer.exception;

public class CwsException extends RuntimeException {
    public CwsException(String message) {
        super(message);
    }

    public CwsException(String message, Throwable cause) {
        super(message, cause);
    }
}
