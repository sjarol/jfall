package nl.uwv.cws.transformer.model.cwswg;

import nl.uwv.cws.transformer.service.common.BaseCwsVersion;

public enum CwsWgVersion implements BaseCwsVersion {
    V0004("00", "04");

    private final String majorWgVersion;
    private final String minorWgVersion;

    CwsWgVersion(String majorVersion, String minorVersion) {
        this.majorWgVersion = majorVersion;
        this.minorWgVersion = minorVersion;
    }

    /**
     * @throws IllegalArgumentException if enum cannot be found with the requested major minor values
     */
    public static CwsWgVersion versionOf(String majorVersion, String minorVersion) {
        return valueOf("V" + majorVersion + minorVersion);
    }

    public static CwsWgVersion versionOf(String majorMinorVersion) {
        return valueOf("V" + majorMinorVersion);
    }

    @Override
    public String majorVersion() {
        return this.majorWgVersion;
    }

    @Override
    public String minorVersion() {
        return this.minorWgVersion;
    }

    @Override
    public String printVersion() {
        return this.majorWgVersion + this.minorWgVersion;
    }
}
