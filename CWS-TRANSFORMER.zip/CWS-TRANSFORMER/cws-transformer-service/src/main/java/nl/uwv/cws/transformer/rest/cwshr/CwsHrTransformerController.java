package nl.uwv.cws.transformer.rest.cwshr;

import lombok.extern.slf4j.Slf4j;
import nl.uwv.cws.transformer.model.common.TransformedCwsRequest;
import nl.uwv.cws.transformer.rest.common.BaseController;
import nl.uwv.cws.transformer.service.cwshr.CwsHrTransformerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StopWatch;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.List;

import static java.util.Arrays.asList;
import static org.springframework.http.MediaType.TEXT_XML_VALUE;

@Slf4j
@RestController
@RequestMapping("/cwshr")
public class CwsHrTransformerController extends BaseController {

    @Value("${cws01.cwshr.context.path}")
    private String cwsHrContextPath;

    @Value("${cws01.cwshr.soap.address}")
    private String cwsHrSoapAddress;

    @Autowired
    @Qualifier("cws-hr")
    private WebClient loadBalancedWebClient;

    @Autowired
    private CwsHrTransformerService cwsHrTransformerService;

    @PostMapping(produces = TEXT_XML_VALUE)
    public Mono<ResponseEntity<String>> cwsHrCall(@RequestHeader HttpHeaders headers, @RequestBody String request) {
        return sendAsync(headers, request);
    }

    @GetMapping(produces = TEXT_XML_VALUE)
    public Mono<String> getWsdl(@RequestHeader HttpHeaders inboundHttpHeaders){
        final String endpoint = cwsHrContextPath + cwsHrSoapAddress + "?wsdl";
        HttpHeaders outboundHttpHeaders = filterHeaders(inboundHttpHeaders, HEADERS_TO_EXCLUDE);
        return doGetWsdl(loadBalancedWebClient, outboundHttpHeaders, endpoint);
    }

    private Mono<ResponseEntity<String>> sendAsync(HttpHeaders inboundHttpHeaders, String requestBody) {
        final String endpoint = cwsHrContextPath + cwsHrSoapAddress;
        return doSendAsync(inboundHttpHeaders, requestBody, endpoint, cwsHrTransformerService, loadBalancedWebClient);
    }
}
