package nl.uwv.cws.transformer.service.common;

import nl.uwv.cws.transformer.exception.ExceptionGenerator;
import nl.uwv.cws.transformer.model.common.TransformedCwsRequest;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public abstract class BaseTransformerService {
    private static final String UNKNOWN_REQUEST_ID_REPLACEMENT = "Onbekend";
    private static final Pattern CWS_ID_HEADER_PATTERN = Pattern.compile("<GegevensUitwisselingsnr>(.+)</GegevensUitwisselingsnr>");
    private static final Pattern MAJOR_VERSION_HEADER_PATTERN = Pattern.compile("(<VersieMajor>)([0-9]{2})(</VersieMajor>)");
    private static final Pattern MINOR_VERSION_HEADER_PATTERN = Pattern.compile("(<VersieMinor>)([0-9]{2})(</VersieMinor>)");

    protected String extractRequestId(String requestXml) {
        String requestId = UNKNOWN_REQUEST_ID_REPLACEMENT;
        Matcher idMatcher = CWS_ID_HEADER_PATTERN.matcher(requestXml);
        if (idMatcher.find()) {
            requestId = idMatcher.group(1);
        }
        return requestId;
    }

    protected void findAndSetRequestMajorHeader(TransformedCwsRequest transformedCwsRequest) {
        Matcher majorMatcher = MAJOR_VERSION_HEADER_PATTERN.matcher(transformedCwsRequest.getTransformedRequestXml());
        if (majorMatcher.find()) {
            BaseCwsVersion originalCwsNpVersion = transformedCwsRequest.getOriginalCwsVersion();
            String transformedXml = majorMatcher.replaceFirst("$1" + originalCwsNpVersion.majorVersion() + "$3");
            transformedCwsRequest.setTransformedRequestXml(transformedXml);
        } else {
            throw ExceptionGenerator.invalidInput("Request is invalid missing expected MajorVersion");
        }
    }

    protected void findAndSetRequestMinorHeader(TransformedCwsRequest transformedCwsRequest) {
        Matcher minorMatcher = MINOR_VERSION_HEADER_PATTERN.matcher(transformedCwsRequest.getTransformedRequestXml());
        if (minorMatcher.find()) {
            BaseCwsVersion originalCwsNpVersion = transformedCwsRequest.getOriginalCwsVersion();
            String transformedXml = minorMatcher.replaceFirst("$1" + originalCwsNpVersion.minorVersion() + "$3");
            transformedCwsRequest.setTransformedRequestXml(transformedXml);
        } else {
            throw ExceptionGenerator.invalidInput("Request is invalid missing expected MinorVersion");
        }
    }
}
