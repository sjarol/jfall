package nl.uwv.cws.transformer;

import nl.uwv.cws.transformer.dao.PropertiesDao;
import nl.uwv.cws.transformer.model.common.TransformerSettings;
import nl.uwv.cws.transformer.model.cwshr.CwsHrVersion;
import nl.uwv.cws.transformer.model.cwsihp.CwsIhpVersion;
import nl.uwv.cws.transformer.model.cwsla.CwsLaVersion;
import nl.uwv.cws.transformer.model.cwsnp.CwsNpVersion;
import nl.uwv.cws.transformer.model.cwswg.CwsWgVersion;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

import static nl.uwv.cws.transformer.model.common.CwsTransformerConstants.*;

@Component
public class AfterStartApplication implements ApplicationListener<ApplicationReadyEvent> {

    @Autowired
    private PropertiesDao propertiesDao;
    @Resource
    private TransformerSettings transformerSettings;

    @Override
    public void onApplicationEvent(ApplicationReadyEvent event) {
        final String cwsLaMaxVersionString = getMaxVersion(CWSLA_MAX_VERSION_DB_KEY, LEVER_CODE_CWS_LA);
        final String cwsNpMaxVersionString = getMaxVersion(CWSNP_MAX_VERSION_DB_KEY, LEVER_CODE_CWS_NP);
        final String cwsHrMaxVersionString = getMaxVersion(CWSHR_MAX_VERSION_DB_KEY, LEVER_CODE_CWS_HR);
        final String cwsIhpMaxVersionString = getMaxVersion(CWSIHP_MAX_VERSION_DB_KEY, LEVER_CODE_CWS_IHP);
        final String cwsWgMaxVersionString = getMaxVersion(CWSWG_MAX_VERSION_DB_KEY, LEVER_CODE_CWS_WG);

        transformerSettings.setCwsLaMaxVersion(CwsLaVersion.versionOf(cwsLaMaxVersionString));
        transformerSettings.setCwsNpMaxVersion(CwsNpVersion.versionOf(cwsNpMaxVersionString));
        transformerSettings.setCwsHrMaxVersion(CwsHrVersion.versionOf(cwsHrMaxVersionString));
        transformerSettings.setCwsIhpMaxVersion(CwsIhpVersion.versionOf(cwsIhpMaxVersionString));
        transformerSettings.setCwsWgMaxVersion(CwsWgVersion.versionOf(cwsWgMaxVersionString));
    }

    private String getMaxVersion(final String key, final String leverCode){
        return propertiesDao.findPropertyByPropertyName(key, leverCode);
    }
}
