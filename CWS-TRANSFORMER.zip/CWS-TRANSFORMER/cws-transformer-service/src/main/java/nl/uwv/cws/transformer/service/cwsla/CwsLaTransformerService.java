package nl.uwv.cws.transformer.service.cwsla;

import lombok.extern.slf4j.Slf4j;
import nl.uwv.cws.transformer.exception.ExceptionGenerator;
import nl.uwv.cws.transformer.model.common.TransformedCwsRequest;
import nl.uwv.cws.transformer.model.common.TransformerSettings;
import nl.uwv.cws.transformer.model.cwsla.CwsLaVersion;
import nl.uwv.cws.transformer.service.common.BaseCwsVersion;
import nl.uwv.cws.transformer.service.common.BaseTransformerService;
import nl.uwv.cws.transformer.service.common.CwsTransformerService;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static org.apache.logging.log4j.util.Strings.isNotEmpty;

@Slf4j
@Component
public class CwsLaTransformerService extends BaseTransformerService implements CwsTransformerService {
    private static final Pattern CWSLA_REQUEST_NAMESPACE_PATTERN = Pattern.compile("(http://schemas.uwv.nl/UwvML/Berichten/CwsLoonaangifteRequest-v)([0-9]{2})([0-9]{2})([0-9]*)");
    private static final Pattern CWSLA_RESPONSE_NAMESPACES_PATTERN = Pattern.compile("(http://schemas.uwv.nl/UwvML/Berichten/CwsLoonaangifte)(Request|Response)(-v)([0-9]{2})([0-9]{2})");

    @Resource
    private TransformerSettings cwsLaTransformerSettings;

    @Override
    public TransformedCwsRequest transformRequest(String originalRequestXml) {
        TransformedCwsRequest transformedCwsRequest = extractAndReplaceNamespaceVersion(originalRequestXml);
        final String requestId = extractRequestId(transformedCwsRequest.getTransformedRequestXml());
        final String originalVersion = transformedCwsRequest.getOriginalCwsVersion().printVersion();
        final String maxVersion = cwsLaTransformerSettings.getCwsLaMaxVersion().printVersion();

        log.info("Vraagbericht met id '{}' is van v{} naar v{} omgezet", requestId, originalVersion, maxVersion);
        findAndSetRequestMinorHeader(transformedCwsRequest);
        findAndSetRequestMajorHeader(transformedCwsRequest);
        return transformedCwsRequest;
    }

    private TransformedCwsRequest extractAndReplaceNamespaceVersion(String originalRequestXml) {
        TransformedCwsRequest transformedCwsRequest = new TransformedCwsRequest();
        Matcher namespaceMatcher = CWSLA_REQUEST_NAMESPACE_PATTERN.matcher(originalRequestXml);
        if (namespaceMatcher.find()) {
            String major = namespaceMatcher.group(2);
            String minor = namespaceMatcher.group(3);
            String extraNumber = namespaceMatcher.group(4);
            if (isNotEmpty(extraNumber)) {
                throw ExceptionGenerator.invalidInput("Request is invalid: incorrect CWS-LA namespace");
            }
            transformedCwsRequest.setOriginalCwsVersion(findCwsLaVersionWithMajorMinor(major, minor));

            if (!transformedCwsRequest.getOriginalCwsVersion().equals(cwsLaTransformerSettings.getCwsLaMaxVersion())) {
                String transformedXml = namespaceMatcher.replaceAll("$1" + cwsLaTransformerSettings.getCwsLaMaxVersion().printVersion());
                transformedCwsRequest.setTransformedRequestXml(transformedXml);
            } else {
                transformedCwsRequest.setTransformedRequestXml(originalRequestXml);
            }
        } else {
            throw ExceptionGenerator.invalidInput("Request is invalid: incorrect CWS-LA namespace");
        }
        return transformedCwsRequest;
    }

    private CwsLaVersion findCwsLaVersionWithMajorMinor(String major, String minor) {
        CwsLaVersion cwsLaVersion;
        try {
            cwsLaVersion = CwsLaVersion.versionOf(major, minor);
        } catch (IllegalArgumentException ex) {
            throw ExceptionGenerator.invalidInput("Ongeldige xml met major minor versie: " + major + minor);
        }
        return cwsLaVersion;
    }

    @Override
    public String transformResponse(BaseCwsVersion originalCwsVersion, String originalResponseXml) {
        Matcher namespaceMatcher = CWSLA_RESPONSE_NAMESPACES_PATTERN.matcher(originalResponseXml);
        if (namespaceMatcher.find()) {
            String transformedResponseXml = originalResponseXml;
            if (!originalCwsVersion.equals(cwsLaTransformerSettings.getCwsLaMaxVersion())) {
                transformedResponseXml = namespaceMatcher.replaceAll("$1$2$3" + originalCwsVersion.printVersion());
            }

            final String requestId = extractRequestId(transformedResponseXml);
            final String originalVersion = originalCwsVersion.printVersion();
            final String maxVersion = cwsLaTransformerSettings.getCwsLaMaxVersion().printVersion();
            log.info("Antwoordbericht met id '{}' is van v{} naar v{} omgezet", requestId, maxVersion, originalVersion);

            return transformedResponseXml;
        } else {
            throw ExceptionGenerator.invalidOutput("Response is invalid missing expected CWS-LA namespace");
        }
    }
}
