package nl.uwv.cws.transformer.config.cwswg;

import org.apache.hc.client5.http.impl.async.CloseableHttpAsyncClient;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.client.loadbalancer.reactive.ReactorLoadBalancerExchangeFilterFunction;
import org.springframework.cloud.loadbalancer.annotation.LoadBalancerClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.reactive.ClientHttpConnector;
import org.springframework.http.client.reactive.HttpComponentsClientHttpConnector;
import org.springframework.web.reactive.function.client.WebClient;


@Configuration
@LoadBalancerClient(name = "cws-wg-service", configuration = {CwsWgHealthCheckConfiguration.class})
public class CwsWgLoadBalancerConfiguration {

    @Value("${cws01.cwswg.webclient.codecs.max.buffer.size}")
    private int maxBufferSize;

    @Bean
    @Qualifier("cws-wg")
    public WebClient getCwsWgLoadBalancedWebClient(ReactorLoadBalancerExchangeFilterFunction reactorLoadBalancerExchangeFilterFunction, CloseableHttpAsyncClient httpAsyncClient) {
        ClientHttpConnector connector = new HttpComponentsClientHttpConnector(httpAsyncClient);

        return WebClient.builder()
                .codecs(configurer -> configurer.defaultCodecs().maxInMemorySize(maxBufferSize)) //2MB
                .filter(reactorLoadBalancerExchangeFilterFunction)
                .clientConnector(connector)
                .baseUrl("http://cws-wg-service")
                .build();
    }
}
