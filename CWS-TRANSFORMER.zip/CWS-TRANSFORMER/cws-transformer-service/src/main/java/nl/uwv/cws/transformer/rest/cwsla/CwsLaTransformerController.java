package nl.uwv.cws.transformer.rest.cwsla;

import lombok.extern.slf4j.Slf4j;
import nl.uwv.cws.transformer.model.common.TransformedCwsRequest;
import nl.uwv.cws.transformer.rest.common.BaseController;
import nl.uwv.cws.transformer.service.cwsla.CwsLaTransformerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StopWatch;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.function.Function;

import static java.util.Arrays.asList;
import static org.springframework.http.MediaType.TEXT_XML_VALUE;

@Slf4j
@RestController
@RequestMapping("/cwsla")
public class CwsLaTransformerController extends BaseController {

    @Value("${cws01.cwsla.context.path}")
    private String cwsLaContextPath;

    @Value("${cws01.cwsla.soap.address}")
    private String cwsLaSoapAddress;

    @Autowired
    @Qualifier("cws-la")
    private WebClient loadBalancedWebClient;

    @Autowired
    private CwsLaTransformerService cwsLaTransformerService;

    @GetMapping(produces = TEXT_XML_VALUE)
    public Mono<String> getWsdl(@RequestHeader HttpHeaders inboundHttpHeaders){
        final String endpoint = cwsLaContextPath + cwsLaSoapAddress + "?wsdl";
        HttpHeaders outboundHttpHeaders = filterHeaders(inboundHttpHeaders, HEADERS_TO_EXCLUDE);
        return doGetWsdl(loadBalancedWebClient, outboundHttpHeaders, endpoint);
    }

    @PostMapping(produces = TEXT_XML_VALUE)
    public Mono<ResponseEntity<String>> cwsLaCall(@RequestHeader HttpHeaders headers, @RequestBody String request) {
        return sendAsync(headers, request);
    }

    private Mono<ResponseEntity<String>> sendAsync(HttpHeaders inboundHttpHeaders, String requestBody){
        final String endpoint = cwsLaContextPath + cwsLaSoapAddress;
        return doSendAsync(inboundHttpHeaders, requestBody, endpoint, cwsLaTransformerService, loadBalancedWebClient);
    }
}
