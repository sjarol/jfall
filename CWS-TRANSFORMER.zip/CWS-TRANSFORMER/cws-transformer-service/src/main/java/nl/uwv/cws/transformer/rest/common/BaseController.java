package nl.uwv.cws.transformer.rest.common;

import lombok.extern.slf4j.Slf4j;
import nl.uwv.cws.transformer.exception.CwsInvalidInputException;
import nl.uwv.cws.transformer.exception.CwsInvalidOutputException;
import nl.uwv.cws.transformer.model.common.TransformedCwsRequest;
import nl.uwv.cws.transformer.service.common.CwsTransformerService;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StopWatch;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.List;

import static java.util.Arrays.asList;

@Slf4j
public abstract class BaseController {
    private static final String TEXT_XML = "text/xml;charset=UTF-8";
    protected static final List<String> HEADERS_TO_EXCLUDE = asList("content-length","host");

    protected Mono<String> doGetWsdl(final WebClient webClient, final HttpHeaders headers, final String endpoint) {
        return webClient.get()
                .uri(endpoint)
                .headers(httpHeaders -> httpHeaders.addAll(headers))
                .exchangeToMono(clientResponse -> {
                    if (clientResponse.statusCode().equals(HttpStatus.UNAUTHORIZED)) {
                        return clientResponse.createException()
                                .flatMap(Mono::error);
                    }
                    return clientResponse.bodyToMono(String.class);
                });
    }

    protected Mono<ResponseEntity<String>> doSendAsync(final HttpHeaders inboundHttpHeaders,
                                                     final String requestBody,
                                                     final String endpoint,
                                                     final CwsTransformerService cwsTransformerService,
                                                     final WebClient loadBalancedWebClient) {
        StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        TransformedCwsRequest transformedCwsRequest = cwsTransformerService.transformRequest(requestBody);

        collectTimeInBetween(stopWatch, "Transformed request in {}ms");

        HttpHeaders outboundHttpHeaders = filterHeaders(inboundHttpHeaders, HEADERS_TO_EXCLUDE);

        return loadBalancedWebClient.post()
                .uri(endpoint)
                .headers(httpHeaders -> httpHeaders.addAll(outboundHttpHeaders))
                .body(BodyInserters.fromPublisher(
                        Mono.just(transformedCwsRequest.getTransformedRequestXml()), String.class))
                .exchangeToMono(clientResponse -> onCwsError(stopWatch, clientResponse))
                .map(responseEntity -> handleServerResponse(responseEntity, transformedCwsRequest, cwsTransformerService, stopWatch));
    }

    private ResponseEntity<String> handleServerResponse(final ResponseEntity<String> responseEntity,
                                                 final TransformedCwsRequest transformedCwsRequest,
                                                 final CwsTransformerService cwsTransformerService,
                                                 final StopWatch stopWatch) {
        log.debug("Response status: {}", responseEntity.getStatusCode());
        collectTimeInBetween(stopWatch, "Backend call completed in {}ms");

        final String responseBody = responseEntity.getBody();
        HttpStatus httpStatus = responseEntity.getStatusCode();
        if (httpStatus.isError()) {
            log.error("Backend problem: HTTP status code {}", httpStatus.value());
            stopWatch.stop();
            log.debug("Complete transformer call in {}ms with HTTP status code {}", stopWatch.getTotalTimeMillis(), httpStatus.value());

            log.error("Received response from CWS {}", responseBody);
            return new ResponseEntity<>(responseBody, httpStatus);
        }

        final String transformedResponse = cwsTransformerService.transformResponse(transformedCwsRequest.getOriginalCwsVersion(), responseBody);
        collectTimeInBetween(stopWatch, "Transformed response in {}ms");
        stopWatch.stop();
        log.debug("Complete transformer call in {}ms", stopWatch.getTotalTimeMillis());

        return ResponseEntity.ok(transformedResponse);
    }

    private Mono<ResponseEntity<String>> onCwsError(StopWatch stopWatch, ClientResponse clientResponse) {
        if (clientResponse.statusCode().isError()) {
            stopWatch.stop();

            return clientResponse.bodyToMono(String.class).flatMap(errorBody -> {
                if (errorBody.contains("Het vraagbericht voldoet niet aan het xsd")) {
                    return Mono.error(new CwsInvalidInputException(errorBody));
                } else if (errorBody.contains("Het antwoordbericht voldoet niet aan het xsd")) {
                    return Mono.error(new CwsInvalidOutputException(errorBody));
                }
                return clientResponse.createException()
                        .flatMap(Mono::error);
            });
        }
        return clientResponse.toEntity(String.class);
    }

    protected HttpHeaders filterHeaders(final HttpHeaders inboundHttpHeaders, final List<String> headersToExclude) {
        HttpHeaders outboundheaders = new HttpHeaders();
        outboundheaders.add(HttpHeaders.CONTENT_TYPE, TEXT_XML);
        inboundHttpHeaders.toSingleValueMap().entrySet().stream()
                .filter(entry -> !headersToExclude.contains(entry.getKey()))
                .forEach(entry -> outboundheaders.add(entry.getKey(), entry.getValue()));

        return outboundheaders;
    }

    private void collectTimeInBetween(StopWatch stopWatch, String messageFormat) {
        stopWatch.stop();
        log.debug(messageFormat, stopWatch.getLastTaskTimeMillis());
        stopWatch.start();
    }
}
