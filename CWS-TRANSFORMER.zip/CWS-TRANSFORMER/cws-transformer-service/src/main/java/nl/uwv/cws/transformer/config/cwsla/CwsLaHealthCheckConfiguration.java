package nl.uwv.cws.transformer.config.cwsla;

import nl.uwv.cws.transformer.config.common.CwsHealthCheckServiceInstanceListSupplier;
import nl.uwv.cws.transformer.config.common.CwsTransformerServiceInstanceListSupplier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.client.loadbalancer.LoadBalancerProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.util.LinkedCaseInsensitiveMap;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.util.UriComponentsBuilder;

import java.time.Duration;
import java.util.List;
import java.util.Map;

@Configuration
public class CwsLaHealthCheckConfiguration {

    @Value("#{'${cws01.cwsla.hosts}'.split(',')}")
    private List<String> cwsLaHosts;

    @Value("${cws01.cwsla.healthcheck.interval}")
    private int healthCheckInterval;

    @Value("${cws01.cwsla.context.path}")
    private String cwsLaContextPath;

    @Bean
    CwsHealthCheckServiceInstanceListSupplier cwsLaHealthCheckServiceInstanceListSupplier() {
        LoadBalancerProperties.HealthCheck healthCheckProps = new LoadBalancerProperties.HealthCheck();
        healthCheckProps.setInterval(Duration.ofSeconds(healthCheckInterval));
        Map<String, String> path = new LinkedCaseInsensitiveMap<>();
        path.put("default", cwsLaContextPath + "/actuator/health");
        healthCheckProps.setPath(path);

        WebClient healthCheckWebClient = WebClient.builder().build();
        CwsTransformerServiceInstanceListSupplier cwsServiceInstanceListSupplier = new CwsTransformerServiceInstanceListSupplier("cws-la-service", cwsLaHosts);

        return new CwsHealthCheckServiceInstanceListSupplier(cwsServiceInstanceListSupplier, healthCheckProps,
                (serviceInstance, healthCheckPath) -> healthCheckWebClient.get()
                        .uri(UriComponentsBuilder.fromUri(serviceInstance.getUri())
                        .path(healthCheckPath).build().toUri())
                        .exchangeToMono(clientResponse -> clientResponse.releaseBody()
                            .thenReturn(HttpStatus.OK.value() == clientResponse.rawStatusCode())));
    }
}