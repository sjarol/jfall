package nl.uwv.cws.transformer.rest.cwsnp;

import lombok.extern.slf4j.Slf4j;
import nl.uwv.cws.transformer.model.common.TransformedCwsRequest;
import nl.uwv.cws.transformer.rest.common.BaseController;
import nl.uwv.cws.transformer.service.cwsnp.CwsNpTransformerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StopWatch;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.List;

import static java.util.Arrays.asList;
import static org.springframework.http.MediaType.TEXT_XML_VALUE;

@Slf4j
@RestController
@RequestMapping("/cwsnp")
public class CwsNpTransformerController extends BaseController {
    private static final List<String> HEADERS_TO_EXCLUDE = asList("content-length","host");

    @Value("${cws01.cwsnp.context.path}")
    private String cwsNpContextPath;

    @Value("${cws01.cwsnp.soap.address}")
    private String cwsNpSoapAddress;

    @Autowired
    @Qualifier("cws-np")
    private WebClient loadBalancedWebClient;

    @Autowired
    private CwsNpTransformerService cwsNpTransformerService;

    @GetMapping(produces = TEXT_XML_VALUE)
    public Mono<String> getWsdl(@RequestHeader HttpHeaders inboundHttpHeaders){
        final String endpoint = cwsNpContextPath + cwsNpSoapAddress + "?wsdl";
        HttpHeaders outboundHttpHeaders = filterHeaders(inboundHttpHeaders, HEADERS_TO_EXCLUDE);
        return doGetWsdl(loadBalancedWebClient, outboundHttpHeaders, endpoint);
    }

    @PostMapping(produces = TEXT_XML_VALUE)
    public Mono<ResponseEntity<String>> cwsNpCall(@RequestHeader HttpHeaders headers, @RequestBody String request) {
        return sendAsync(headers, request);
    }

    private Mono<ResponseEntity<String>> sendAsync(HttpHeaders inboundHttpHeaders, String requestBody){
        final String endpoint = cwsNpContextPath + cwsNpSoapAddress;
        return doSendAsync(inboundHttpHeaders, requestBody, endpoint, cwsNpTransformerService, loadBalancedWebClient);
    }
}
