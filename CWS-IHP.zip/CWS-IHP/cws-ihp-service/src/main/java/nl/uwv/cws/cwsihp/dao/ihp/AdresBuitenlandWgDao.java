package nl.uwv.cws.cwsihp.dao.ihp;

import nl.uwv.cws.cwsihp.dao.mapper.AdresBuitenlandWgRowMapper;
import nl.uwv.cws.cwsihp.model.configuratie.CwsIhpConfiguratie;
import nl.uwv.cws.cwsihp.model.wg.AdresBuitenlandWg;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public class AdresBuitenlandWgDao extends BaseDao {
	
	@Autowired
	private AdresBuitenlandWgRowMapper rowMapper;

    public List<AdresBuitenlandWg> findAdresBuitenland(final Long administratieveEenheidId, final LocalDateTime beschouwingsmoment, final CwsIhpConfiguratie cwsIhpConfiguratie) {
        Timestamp beschouwingsmomentTimestamp = Timestamp.valueOf(beschouwingsmoment);

        String sql = 	" SELECT adr.adresrol " +
						"      , adr.dataanv " +
						"      , adr.dateind " +
						"      , adrstruct.straatnaam " +
						"      , adrstruct.postcode " +
						"      , adrstruct.huisnr " +
						"      , adrstruct.woonplaats " +
						"      , adrstruct.regionaam " +
						"      , adrstruct.locatie_omsch " +
						"      , adrstruct.landcode_iso " +
						"      , adrstruct.postbusnr " +
						"      , adrstruct.adrestypestruct " +
						" FROM wga_adres adr " +
						" INNER JOIN WGA_ADRES_STRUCT adrstruct " +
						" ON adrstruct.adr_id = adr.adr_id " +
						" AND adrstruct.adrestypestruct = adr.adrestypek33 " +
						" AND adrstruct.his_ts_in  <  :beschouwingsmoment " +
						" AND adrstruct.his_ts_end >= :beschouwingsmoment " +
						" WHERE adr.aeh_id = :administratieveEenheidId " +
						" AND adr.adrestypek33 IN ('SAB', 'PAB') " +
						" AND adr.his_ts_in  <  :beschouwingsmoment " +
						" AND adr.his_ts_end >= :beschouwingsmoment " +
						(cwsIhpConfiguratie.excludeBeeindigdAdres() ? AdreshoudingWgQueries.CONDITION_EXCLUDE_BEEINDIGD_ADRES : "");

        SqlParameterSource namedParameters = new MapSqlParameterSource()
        		.addValue("administratieveEenheidId", administratieveEenheidId)
				.addValue("beschouwingsmoment", beschouwingsmomentTimestamp);

		List<String> attributen = cwsIhpConfiguratie.getGroepenGegevens().getRequiredColumnsAdresBuitenlandWg();
		attributen.addAll(cwsIhpConfiguratie.getGroepenGegevens().getRequiredColumnsStraatadresBuitenlandWg());
		attributen.addAll(cwsIhpConfiguratie.getGroepenGegevens().getRequiredColumnsPostbusadresBuitenlandWg());
		return jdbcTemplate.query(sql, namedParameters, (resultSet, i) -> rowMapper.mapRow(resultSet, attributen));
	}	
}
