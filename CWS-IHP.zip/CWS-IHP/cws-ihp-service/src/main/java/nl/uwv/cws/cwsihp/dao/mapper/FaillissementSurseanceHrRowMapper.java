package nl.uwv.cws.cwsihp.dao.mapper;

import nl.uwv.cws.common.dao.mapper.CwsRowMapper;
import nl.uwv.cws.cwsihp.model.hr.FaillissementSurseanceHr;
import org.springframework.stereotype.Component;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import static nl.uwv.cws.cwsihp.util.DateUtil.setDatumEinde;

@Component
public class FaillissementSurseanceHrRowMapper extends CwsRowMapper<FaillissementSurseanceHr> {

    @Override
    public FaillissementSurseanceHr mapRow(final ResultSet resultSet, final List<String> attributen) throws SQLException {

        final String codeFaillissementSurseance = readApplicableString(attributen, "FAIL_SURS_IND", resultSet);
        final Date datumAanvangFaillissementSurseance = readApplicableDate(attributen, "DATAANV", resultSet);
        final Integer codeFictieveDatumAanvang = readApplicableNullableInteger(attributen, "CD_DATUM_AANVANG_CGM", resultSet);
        final Date datumEindeFaillissementSurseance = setDatumEinde(readApplicableDate(attributen, "DATEIND", resultSet), resultSet.getInt("CD_DATUM_EINDE_CGM"));
        final Integer codeFictieveDatumEinde = readApplicableNullableInteger(attributen, "CD_DATUM_EINDE_CGM", resultSet);

        return FaillissementSurseanceHr.builder()
                .codeFaillissementSurseance(codeFaillissementSurseance)
                .datumAanvangFaillissementSurseance(datumAanvangFaillissementSurseance)
                .codeFictieveDatumAanvang(codeFictieveDatumAanvang)
                .datumEindeFaillissementSurseance(datumEindeFaillissementSurseance)
                .codeFictieveDatumEinde(codeFictieveDatumEinde)
                .build();
    }
}
