package nl.uwv.cws.cwsihp.webservice.rule.transformer;

import nl.uwv.cws.common.model.rule.AttributeRuleProperties;
import nl.uwv.cws.common.webservice.rule.transformer.RuleValueTransformer;
import nl.uwv.cws.cwsihp.model.rule.CwsIhpAttributeRule;
import org.springframework.stereotype.Component;

import static nl.uwv.cws.cwsihp.model.rule.CwsIhpAttributeRule.GEEN;

@Component
public class GeenTransformer implements RuleValueTransformer<Object, Object> {
    @Override
    public CwsIhpAttributeRule getTransformRule() {
        return GEEN;
    }

    @Override
    public Object transform(Object originalValue, AttributeRuleProperties attributeRuleProperties) {
        return originalValue;
    }
}
