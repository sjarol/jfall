package nl.uwv.cws.cwsihp.webservice.mapper;

import nl.uwv.cws.common.webservice.rule.CwsRuleExecutor;
import nl.uwv.cws.cwsihp.model.rule.CwsIhpAttributeRule;
import org.springframework.beans.factory.annotation.Autowired;

public abstract class BaseMapper {

    @Autowired
    protected CwsRuleExecutor<CwsIhpAttributeRule> ruleExecutor;
}
