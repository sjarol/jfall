package nl.uwv.cws.cwsihp.webservice.mapper;

import nl.uwv.cws.common.model.Foutmelding;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0007.CwsInhoudingsplichtigeResponse.Applicatiemelding;
import org.springframework.stereotype.Component;

import static nl.uwv.cws.cwsihp.model.CwsIhpConstants.*;

@Component
public class ApplicatiemeldingMapper extends BaseMapper {

    public Applicatiemelding mapToJaxbApplicatieMelding(Foutmelding foutmelding) {
        Applicatiemelding applicatiemelding = new Applicatiemelding();
        ruleExecutor.setTransformedValue(applicatiemelding, XSD_CDSRTAPPLICATIEMELDING, foutmelding.getSoort());
        ruleExecutor.setTransformedValue(applicatiemelding, XSD_CDAPPLICATIEMELDING, foutmelding.getCode());
        ruleExecutor.setTransformedValue(applicatiemelding, XSD_TOELAPPLICATIEMELDING, foutmelding.getMessage());

        return applicatiemelding;
    }
}
