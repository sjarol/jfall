package nl.uwv.cws.cwsihp.webservice.mapper;

import nl.uwv.cws.common.VisibleForTesting;
import nl.uwv.cws.cwsihp.model.wg.SectorRisicogroepWg;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0007.CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.SectorRisicogroep;
import org.springframework.stereotype.Component;

import static nl.uwv.cws.common.util.MapperUtil.collectNonEmptyObject;
import static nl.uwv.cws.common.util.NullValueUtil.extractStringValueOrNull;
import static nl.uwv.cws.cwsihp.model.CwsIhpConstants.*;

@Component
public class SectorRisicogroepMapper extends BaseMapper {

    @VisibleForTesting
    protected SectorRisicogroep mapToJaxbSectorRisicogroep(SectorRisicogroepWg sectorRisicogroepWg) {
        SectorRisicogroep sectorRisicogroep = new SectorRisicogroep();

        final String codeRisicopremiegroep = sectorRisicogroepWg.getCodeRisicopremiegroep();
        final String codeSectorOsv = sectorRisicogroepWg.getCodeSectorOsv();
        final Long datumAanvangSectorRisicogroep = sectorRisicogroepWg.getDatumAanvangSectorRisicogroep();
        final Long datumEindeSectorRisicogroep = sectorRisicogroepWg.getDatumEindeSectorRisicogroep();

        ruleExecutor.setTransformedValue(sectorRisicogroep, XSD_CDRISICOPREMIEGROEP, codeRisicopremiegroep);
        ruleExecutor.setTransformedValue(sectorRisicogroep, XSD_CDSECTOROSV, codeSectorOsv);
        ruleExecutor.setTransformedValue(sectorRisicogroep, XSD_DATB, extractStringValueOrNull(datumAanvangSectorRisicogroep));
        ruleExecutor.setTransformedValue(sectorRisicogroep, XSD_DATE, extractStringValueOrNull(datumEindeSectorRisicogroep));

        return collectNonEmptyObject(sectorRisicogroep);
    }
}
