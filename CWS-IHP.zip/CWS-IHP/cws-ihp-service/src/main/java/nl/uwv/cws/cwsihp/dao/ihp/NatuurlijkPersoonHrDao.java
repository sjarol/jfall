package nl.uwv.cws.cwsihp.dao.ihp;

import nl.uwv.cws.cwsihp.dao.mapper.NatuurlijkPersoonHrRowMapper;
import nl.uwv.cws.cwsihp.model.configuratie.CwsIhpConfiguratie;
import nl.uwv.cws.cwsihp.model.hr.NatuurlijkPersoonHr;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

import static nl.uwv.cws.common.util.DaoUtil.findOneOrNone;

@Repository
public class NatuurlijkPersoonHrDao extends BaseDao {

    @Autowired
    private NatuurlijkPersoonHrRowMapper natuurlijkPersoonHrRowMapper;

    public NatuurlijkPersoonHr findNatuurlijkPersoonHr (final Long natuurlijkpersoonId, final LocalDateTime beschouwingsmoment, final CwsIhpConfiguratie cwsIhpConfiguratie) {
        final String sql =
                "SELECT bsn, voorletters, voornamen, voorvoegsel, achternaam, cd_aanduiding_naamgebruik_cgm, geboortedatum_cgm, cd_geboortedatum_cgm, geslacht, " +
                        "voorv_geslachtsnm_partner, geslachtsnaampartner " +
                        "FROM ( SELECT uh_pers.bsn " +
                        "            , NVL2(upa_prs.bsn, upa_prs.voorletters, null) AS voorletters " +
                        "            , NVL2(upa_prs.bsn, upa_prs.voornamen, uh_pers.voornamen) AS voornamen " +
                        "            , NVL2(upa_prs.bsn, upa_prs.voorvoegsel, uh_pers.voorvoegsel) AS voorvoegsel " +
                        "            , NVL2(upa_prs.bsn, upa_prs.significant_deel_achternaam, uh_pers.achternaam) AS achternaam " +
                        "            , NVL2(upa_prs.bsn, upa_prs.ang_code, uh_pers.cd_aanduiding_naamgebruik_cgm) AS cd_aanduiding_naamgebruik_cgm " +
                        "            , uh_pers.geboortedatum_cgm " +
                        "            , uh_pers.cd_geboortedatum_cgm " +
                        "            , NVL2(upa_prs.bsn, upa_prs.geslacht, null) AS geslacht " +
                        "            , NVL2(upa_prs.bsn, upa_prs.voorvoegsel_partnr, uh_pers.voorv_geslachtsnm_partner) AS voorv_geslachtsnm_partner " +
                        "            , NVL2(upa_prs.bsn, upa_prs.sign_deel_achternaam_partnr, uh_pers.geslachtsnaampartner) AS geslachtsnaampartner " +
                        "            , ROW_NUMBER() OVER (PARTITION BY uh_pers.natuurlijkepersoon_id ORDER BY datum_aanvang_cgm DESC, his_ts_in DESC) AS rn " +
                        "		FROM uh_natuurlijkpersoon uh_pers " +
                        "       LEFT OUTER JOIN TABLE (upa_lev_get_upanaam( uh_pers.bsn )) upa_prs " +
                        "       ON upa_prs.bsn = uh_pers.bsn " +
                        "       AND his_ts_in  <= :beschouwingsmoment " +
                        "       AND his_ts_end > :beschouwingsmoment " +
                        "       WHERE uh_pers.natuurlijkepersoon_id = :natuurlijkpersoonId) " +
                        "WHERE rn = 1";

        Timestamp beschouwingsmomentTimestamp = Timestamp.valueOf(beschouwingsmoment);
        SqlParameterSource namedParameters = new MapSqlParameterSource()
                .addValue("natuurlijkpersoonId", natuurlijkpersoonId)
                .addValue("beschouwingsmoment", beschouwingsmomentTimestamp);

        List<String> attributen = cwsIhpConfiguratie.getGroepenGegevens().getRequiredColumnsNatuurlijkPersoon();
        attributen.addAll(cwsIhpConfiguratie.getGroepenGegevens().getRequiredColumnsHuwelijkGeregistreerdPartnerschap());
        List<NatuurlijkPersoonHr> results = jdbcTemplate.query(sql, namedParameters, (resultSet, i) -> natuurlijkPersoonHrRowMapper.mapRow(resultSet, attributen));
        String errorMessage = "Meerdere rijen gevonden";
        return findOneOrNone(errorMessage, results);
    }
}
