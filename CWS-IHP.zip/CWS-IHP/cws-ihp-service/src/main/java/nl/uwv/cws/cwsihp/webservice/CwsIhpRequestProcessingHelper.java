package nl.uwv.cws.cwsihp.webservice;

import lombok.extern.slf4j.Slf4j;
import nl.uwv.cws.common.model.CwsAuditInformation;
import nl.uwv.cws.common.model.configuratie.ConfiguratieKey;
import nl.uwv.cws.common.service.CwsAuditLoggerService;
import nl.uwv.cws.common.webservice.CwsRequestProcessingHelper;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigerequest_v0007.CwsInhoudingsplichtigeRequest;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigerequest_v0007.CwsInhoudingsplichtigeRequest.Gegevensvraag.ContractGegevenslevering;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import javax.xml.ws.WebServiceContext;
import java.time.LocalDateTime;

@Component
@Slf4j
public class CwsIhpRequestProcessingHelper implements CwsRequestProcessingHelper<CwsInhoudingsplichtigeRequest> {

    @Qualifier("requestScopedBean")
    @Autowired
    private CwsAuditInformation cwsAuditInformation;

    @Autowired
    private CwsAuditLoggerService cwsAuditLoggerService;

    @Override
    public void logRequestPart(CwsInhoudingsplichtigeRequest cwsInhoudingsplichtigeRequest) {
        ContractGegevenslevering contractGegevenslevering = cwsInhoudingsplichtigeRequest.getGegevensvraag().getContractGegevenslevering();

        String requestPartString = "Contractnummer: " + contractGegevenslevering.getContractnrGegevenslevering() +
                                   "; Datum aanvang contract: " + contractGegevenslevering.getDatBContractGegevenslevering() +
                                   "; Versienummer gegevensafnemer configuratie: " + contractGegevenslevering.getGegevensafnemerConfiguratie().getVersienrGegevensafnemerConf();

        if (isLeveringRequestedForPersoon(cwsInhoudingsplichtigeRequest)) {
            String nummerInhoudingsplichtige = cwsInhoudingsplichtigeRequest.getGegevensvraag().getPersoonInhoudingsplichtige().getNrInhoudingsplichtige() ;
            log.info(requestPartString + "; Nummer Inhoudingsplichtige: ******" + nummerInhoudingsplichtige.substring(6));

        } else if (isLeveringRequestedForAdministratieveEenheid(cwsInhoudingsplichtigeRequest)) {
            final String loonheffingennr = cwsInhoudingsplichtigeRequest.getGegevensvraag().getAdministratieveEenheid().getLoonheffingennr();
            log.info(requestPartString + "; Loonheffingennummer: {}" , StringUtils.hasText(loonheffingennr) ? loonheffingennr : "onbekend");

        } else {
            String kvkNummer = cwsInhoudingsplichtigeRequest.getGegevensvraag().getWerkgeverKvk().getKvkNr();
            log.info(requestPartString + "; Kvk Nummer: {}", kvkNummer);
        }
    }

    protected boolean isLeveringRequestedForPersoon(CwsInhoudingsplichtigeRequest request) {
        return request.getGegevensvraag().getPersoonInhoudingsplichtige() != null;
    }

    protected boolean isLeveringRequestedForAdministratieveEenheid(CwsInhoudingsplichtigeRequest request) {
        return request.getGegevensvraag().getAdministratieveEenheid() != null;
    }

    protected boolean isLeveringRequestedForWerkgeverKvk(CwsInhoudingsplichtigeRequest request) {
        return request.getGegevensvraag().getWerkgeverKvk() != null;
    }

    @Override
    public void logAudit(WebServiceContext context, CwsInhoudingsplichtigeRequest request, boolean gegevensGeleverd) {
        if (isLeveringRequestedForPersoon(request)) {
            cwsAuditInformation.setNrInhoudingsplichtige(request.getGegevensvraag().getPersoonInhoudingsplichtige().getNrInhoudingsplichtige());
        } else if (isLeveringRequestedForWerkgeverKvk(request)) {
            cwsAuditInformation.setKvkNummer(request.getGegevensvraag().getWerkgeverKvk().getKvkNr());
        } else if (isLeveringRequestedForAdministratieveEenheid(request)) {
            cwsAuditInformation.setLoonheffingennr(request.getGegevensvraag().getAdministratieveEenheid().getLoonheffingennr());
        }
        cwsAuditInformation.setContractId(request.getGegevensvraag().getContractGegevenslevering().getContractnrGegevenslevering());
        cwsAuditInformation.addDeterminedBeschouwingsmoment(LocalDateTime.now());
        cwsAuditLoggerService.log(cwsAuditInformation, context, gegevensGeleverd);
    }

    @Override
    public ConfiguratieKey extractConfiguratieKey(CwsInhoudingsplichtigeRequest request) {
        return ConfiguratieKey.builder()
                .contractNummer(request.getGegevensvraag().getContractGegevenslevering().getContractnrGegevenslevering())
                .contractStartDate(request.getGegevensvraag().getContractGegevenslevering().getDatBContractGegevenslevering())
                .versie(request.getGegevensvraag().getContractGegevenslevering().getGegevensafnemerConfiguratie().getVersienrGegevensafnemerConf())
                .build();
    }
}
