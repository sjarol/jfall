package nl.uwv.cws.cwsihp.webservice.rule.transformer;

import nl.uwv.cws.common.model.FictieveDatum;
import nl.uwv.cws.common.util.FictieveDatumUtil;
import nl.uwv.cws.common.model.rule.AttributeRuleProperties;
import nl.uwv.cws.common.webservice.rule.transformer.RuleValueTransformer;
import nl.uwv.cws.cwsihp.model.rule.CwsIhpAttributeRule;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import static nl.uwv.cws.cwsihp.model.rule.CwsIhpAttributeRule.FICTIEVE_GEBOORTEDATUM;

@Component
public class FictieveGeboorteDatumTransformer implements RuleValueTransformer<String, String> {

    @Override
    public CwsIhpAttributeRule getTransformRule() {
        return FICTIEVE_GEBOORTEDATUM;
    }

    @Override
    public String transform(final String originalValue, final AttributeRuleProperties attributeRuleProperties) {
        if (!StringUtils.hasLength(originalValue)) {
            return null;
        }

        return determineFictieveGeboortedatum(originalValue);
    }

    /**
     * Geboortedatum in UPA Code Fict Geb.datum Aanpassing nodig voor Geboortedatum
     * Geen enkel datumdeel is fictief.......................................................... <geen>
     * Dagdeel is fictief.............................................. ................vul dag met 16
     * Maanddeel is fictief ............................................................vul maand met 07
     * Dagdeel en maanddeel zijn fictief................................................vul dag met 01; vul maand met 07
     * Jaardeel is fictief............................................................. vul jaar met 1850
     * Dagdeel en jaardeel zijn fictief.................................................vul datum met 18500101
     * Maanddeel en jaardeel zijn fictief...............................................vul datum met 18500101
     * Dag-, maand- en jaardeel zijn fictief............................................vul datum met 18500101
     *
     * @param geboortedatum
     * @return String
     */
    private String determineFictieveGeboortedatum(String geboortedatum) {
        if (FictieveDatumUtil.isDatumFicitief(geboortedatum)) {
            FictieveDatum fictieveDatum = FictieveDatumUtil.buildFictieveDatum(geboortedatum);
            return FictieveDatumUtil.getDateAsFictieveDatumIncludeJaar(fictieveDatum);
        }

        return geboortedatum;
    }
}
