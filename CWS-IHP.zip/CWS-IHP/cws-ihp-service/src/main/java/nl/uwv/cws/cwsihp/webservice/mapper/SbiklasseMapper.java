package nl.uwv.cws.cwsihp.webservice.mapper;

import nl.uwv.cws.common.VisibleForTesting;
import nl.uwv.cws.cwsihp.model.hr.SbiklasseHr;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0007.CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0007.CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.ActiviteitHandelsregister;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0007.CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Onderneming;
import org.springframework.stereotype.Component;

import java.sql.Date;

import static nl.uwv.cws.common.util.MapperUtil.collectNonEmptyObject;
import static nl.uwv.cws.common.util.NullValueUtil.extractStringFromDateValueOrNull;
import static nl.uwv.cws.common.util.NullValueUtil.extractStringValueOrNull;
import static nl.uwv.cws.cwsihp.model.CwsIhpConstants.*;

@Component
public class SbiklasseMapper extends BaseMapper {

    public MaatschappelijkeActiviteit.Sbiklasse mapToJaxbSbiklasseMaatschappelijkeActiviteit(final SbiklasseHr sbiklasseHr) {
        MaatschappelijkeActiviteit.Sbiklasse sbiklasse = new MaatschappelijkeActiviteit.Sbiklasse();
        mapToJaxbSbiklasse(sbiklasseHr, sbiklasse);

        return collectNonEmptyObject(sbiklasse);
    }

    public ActiviteitHandelsregister.Sbiklasse mapToJaxbSbiklasseActiviteitHandelsregister(final SbiklasseHr sbiklasseHr) {
        ActiviteitHandelsregister.Sbiklasse sbiklasse = new ActiviteitHandelsregister.Sbiklasse();
        mapToJaxbSbiklasse(sbiklasseHr, sbiklasse);

        return collectNonEmptyObject(sbiklasse);
    }

    public Onderneming.Sbiklasse mapToJaxbSbiklasseOnderneming(final SbiklasseHr sbiklasseHr) {
        Onderneming.Sbiklasse sbiklasse = new Onderneming.Sbiklasse();
        mapToJaxbSbiklasse(sbiklasseHr, sbiklasse);

        return collectNonEmptyObject(sbiklasse);
    }

    @VisibleForTesting
    protected void mapToJaxbSbiklasse(final SbiklasseHr sbiklasseHr, final Object sbiklasse) {
        final String codeSbi = sbiklasseHr.getCodeSbi();
        final String omschrijvingSbi = sbiklasseHr.getOmschrijvingSbi();
        final String indicatieSbiHoofdactiviteit = sbiklasseHr.getIndicatieSbiHoofdactiviteit();
        final Date datumAanvangSbiKlasse = sbiklasseHr.getDatumAanvangSbiActiviteit();
        Integer codeFictieveDatumAanvang = null;
        if (datumAanvangSbiKlasse != null) {
            codeFictieveDatumAanvang = sbiklasseHr.getCodeFictieveDatumAanvang();
        }
        final Date datumEindeSbiKlasse = sbiklasseHr.getDatumEindeSbiActiviteit();
        Integer codeFictieveDatumEinde = null;
        if (datumEindeSbiKlasse != null) {
            codeFictieveDatumEinde = sbiklasseHr.getCodeFictieveDatumEinde();
        }

        ruleExecutor.setTransformedValue(sbiklasse, XSD_CDSBI, codeSbi);
        ruleExecutor.setTransformedValue(sbiklasse, XSD_OMSSBI, omschrijvingSbi);
        ruleExecutor.setTransformedValue(sbiklasse, XSD_INDSBIHOOFDACTIVITEIT, indicatieSbiHoofdactiviteit);
        ruleExecutor.setTransformedValue(sbiklasse, XSD_DATBSBIACTIVITEIT, extractStringFromDateValueOrNull(datumAanvangSbiKlasse));
        ruleExecutor.setTransformedValue(sbiklasse, XSD_CDFICTIEVEDATB, extractStringValueOrNull(codeFictieveDatumAanvang));
        ruleExecutor.setTransformedValue(sbiklasse, XSD_DATESBIACTIVITEIT, extractStringFromDateValueOrNull(datumEindeSbiKlasse));
        ruleExecutor.setTransformedValue(sbiklasse, XSD_CDFICTIEVEDATE, extractStringValueOrNull(codeFictieveDatumEinde));
    }
}
