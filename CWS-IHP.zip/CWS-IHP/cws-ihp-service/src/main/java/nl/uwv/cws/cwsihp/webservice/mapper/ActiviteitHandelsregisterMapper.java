package nl.uwv.cws.cwsihp.webservice.mapper;

import nl.uwv.cws.cwsihp.model.hr.ActiviteitHandelsregisterHr;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0007.CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0007.CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NietNatuurlijkPersoon.Rechtspersoon;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Optional;

import static nl.uwv.cws.common.util.MapperUtil.collectNonEmptyObject;
import static nl.uwv.cws.common.util.MapperUtil.mapToJaxbListIfNotEmpty;
import static nl.uwv.cws.cwsihp.model.CwsIhpConstants.XSD_OMSACTIVITEITHANDELSREGISTER;

@Component
public class ActiviteitHandelsregisterMapper extends BaseMapper {

    @Autowired
    private SbiklasseMapper sbiklasseMapper;

    public Optional<VestigingHandelsregister.ActiviteitHandelsregister> mapToJaxbActiviteitHandelsregisterVestigingHandelsregister(ActiviteitHandelsregisterHr activiteitHandelsregisterHr) {
        return Optional.ofNullable(activiteitHandelsregisterHr).map(notNullableActiviteitHandelsregister -> {
            VestigingHandelsregister.ActiviteitHandelsregister activiteitHandelsregister = new VestigingHandelsregister.ActiviteitHandelsregister();
            mapToJaxbActiviteitHandelsregister(notNullableActiviteitHandelsregister, activiteitHandelsregister);

            mapToJaxbListIfNotEmpty(notNullableActiviteitHandelsregister.getSbiklasseHrList(),
                    activiteitHandelsregister.getSbiklasse(),
                    sbiklasseMapper::mapToJaxbSbiklasseActiviteitHandelsregister);

            return collectNonEmptyObject(activiteitHandelsregister);
        });
    }

    public Optional<Rechtspersoon.ActiviteitHandelsregister> mapToJaxbActiviteitHandelsregisterRechtspersoon(ActiviteitHandelsregisterHr activiteitHandelsregisterHr) {
        return Optional.ofNullable(activiteitHandelsregisterHr).map(notNullableActiviteitHandelsregister -> {
            Rechtspersoon.ActiviteitHandelsregister activiteitHandelsregister = new Rechtspersoon.ActiviteitHandelsregister();
            mapToJaxbActiviteitHandelsregister(notNullableActiviteitHandelsregister, activiteitHandelsregister);

            return collectNonEmptyObject(activiteitHandelsregister);
        });
    }

    protected void mapToJaxbActiviteitHandelsregister(final ActiviteitHandelsregisterHr activiteitHandelsregisterHr, final Object activiteitHandelsregister) {

        final String omschrijving = activiteitHandelsregisterHr.getOmschrijving();

        ruleExecutor.setTransformedValue(activiteitHandelsregister, XSD_OMSACTIVITEITHANDELSREGISTER, omschrijving);
    }
}