package nl.uwv.cws.cwsihp.dao.ihp;

import nl.uwv.cws.cwsihp.model.configuratie.CwsIhpConfiguratie;
import nl.uwv.cws.cwsihp.model.hr.AdresBuitenlandHr;
import nl.uwv.cws.cwsihp.model.hr.AdresBuitenlandOngestructureerdHr;
import nl.uwv.cws.cwsihp.model.hr.AdresNederlandHr;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Component;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

import static nl.uwv.cws.common.model.CwsCommonConstants.BESCHOUWINGSMOMENT;
import static nl.uwv.cws.common.model.CwsCommonConstants.SQL_UNION;
import static nl.uwv.cws.common.util.DaoUtil.setOptionalParameter;

@Component
public class AdreshoudingPersoonHrDao extends BaseAdreshoudingHrDao {

    private static final String WITH_CLAUSE = "   (SELECT locatie_id, code_adresrol_cgm " +
            "    FROM uh_naampersoon " +
            "    WHERE naam_persoon_id = :naamPersoonId " +
            "    AND his_ts_in  <= :beschouwingsmoment " +
            "    AND his_ts_end > :beschouwingsmoment " +
            SQL_UNION +
            "    SELECT woon_locatie_id AS locatie_id, code_adresrol_cgm " +
            "    FROM uh_natuurlijkpersoon " +
            "    WHERE natuurlijkepersoon_id = :natuurlijkpersoonId " +
            "    AND his_ts_in  <= :beschouwingsmoment " +
            "    AND his_ts_end > :beschouwingsmoment " +
            SQL_UNION +
            "    SELECT loc.locatie_id, code_adresrol_cgm " +
            "    FROM uh_locatie_buitenl_vennootsch loc " +
            "    JOIN uh_persoon per " +
            "    ON per.buitenlandsevennootschap_id = loc.buitenlandsevennootschap_id " +
            "    AND per.persoon_id = :persoonId " +
            "    WHERE loc.his_ts_in  <= :beschouwingsmoment " +
            "    AND loc.his_ts_end > :beschouwingsmoment " +
            SQL_UNION +
            "    SELECT loc.locatie_id, code_adresrol_cgm " +
            "    FROM uh_locatie_rechtspersoon loc " +
            "    JOIN uh_persoon per " +
            "    ON per.rechtspersoon_id = loc.rechtspersoon_id " +
            "    AND per.persoon_id = :persoonId " +
            "    WHERE loc.his_ts_in  <= :beschouwingsmoment " +
            "    AND loc.his_ts_end > :beschouwingsmoment " +
            "    ) ";

    public List<AdresNederlandHr> findAdresNederlandPersoon(final Long persoonId, final Long naamPersoonId, final Long natuurlijkpersoonId, final LocalDateTime beschouwingsmoment, final CwsIhpConfiguratie cwsIhpConfiguratie) {

        Timestamp beschouwingsmomentTimestamp = Timestamp.valueOf(beschouwingsmoment);

        MapSqlParameterSource namedParameters = getMapSqlParameterSource(persoonId, naamPersoonId, natuurlijkpersoonId);
        namedParameters.addValue(BESCHOUWINGSMOMENT, beschouwingsmomentTimestamp);
        List<String> attributen = cwsIhpConfiguratie.getGroepenGegevens().getRequiredColumnsAdresNederlandPersoon();
        attributen.addAll(cwsIhpConfiguratie.getGroepenGegevens().getRequiredColumnsStraatadresNederlandPersoon());
        attributen.addAll(cwsIhpConfiguratie.getGroepenGegevens().getRequiredColumnsPostbusadresNederlandPersoon());
        return findAdresNederland(WITH_CLAUSE, namedParameters, cwsIhpConfiguratie, attributen);
    }

    public List<AdresBuitenlandHr> findAdresBuitenlandPersoon(final Long persoonId, final Long naamPersoonId, final Long natuurlijkpersoonId, final LocalDateTime beschouwingsmoment, final CwsIhpConfiguratie cwsIhpConfiguratie) {

        Timestamp beschouwingsmomentTimestamp = Timestamp.valueOf(beschouwingsmoment);

        MapSqlParameterSource namedParameters = getMapSqlParameterSource(persoonId, naamPersoonId, natuurlijkpersoonId);
        namedParameters.addValue(BESCHOUWINGSMOMENT, beschouwingsmomentTimestamp);
        List<String> attributen = cwsIhpConfiguratie.getGroepenGegevens().getRequiredColumnsAdresBuitenlandPersoon();
        attributen.addAll(cwsIhpConfiguratie.getGroepenGegevens().getRequiredColumnsStraatadresBuitenlandPersoon());
        attributen.addAll(cwsIhpConfiguratie.getGroepenGegevens().getRequiredColumnsPostbusadresBuitenlandPersoon());
        return findAdresBuitenland(WITH_CLAUSE, namedParameters, cwsIhpConfiguratie, attributen);
    }

    public List<AdresBuitenlandOngestructureerdHr> findAdresBuitenlandOngestructureerdPersoon(final Long persoonId, final Long naamPersoonId, final Long natuurlijkpersoonId, final LocalDateTime beschouwingsmoment, final CwsIhpConfiguratie cwsIhpConfiguratie) {

        Timestamp beschouwingsmomentTimestamp = Timestamp.valueOf(beschouwingsmoment);

        MapSqlParameterSource namedParameters = getMapSqlParameterSource(persoonId, naamPersoonId, natuurlijkpersoonId);
        namedParameters.addValue(BESCHOUWINGSMOMENT, beschouwingsmomentTimestamp);
        List<String> attributen = cwsIhpConfiguratie.getGroepenGegevens().getRequiredColumnsAdresBuitenlandOngestructureerdPersoon();
        return findAdresBuitenlandOngestructureerd(WITH_CLAUSE, namedParameters, cwsIhpConfiguratie, attributen);
    }

    private MapSqlParameterSource getMapSqlParameterSource(final Long persoonId, final Long naamPersoonId, final Long natuurlijkpersoonId) {
        MapSqlParameterSource namedParameters = new MapSqlParameterSource()
                .addValue("persoonId", persoonId);
        setOptionalParameter(namedParameters, "naamPersoonId", naamPersoonId);
        setOptionalParameter(namedParameters, "natuurlijkpersoonId", natuurlijkpersoonId);
        return namedParameters;
    }

}
