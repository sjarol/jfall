package nl.uwv.cws.cwsihp.service.wg;

import nl.uwv.cws.cwsihp.dao.ihp.*;
import nl.uwv.cws.cwsihp.model.configuratie.CwsIhpConfiguratie;
import nl.uwv.cws.cwsihp.model.wg.*;
import nl.uwv.cws.cwsihp.service.BaseService;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDateTime;
import java.util.List;

public class BaseWgService extends BaseService {

    @Autowired
    protected PersoonWgDao persoonWgDao;

    @Autowired
    protected NietNatuurlijkPersoonWgDao nietNatuurlijkPersoonWgDao;

    @Autowired
    protected NatuurlijkPersoonWgDao natuurlijkPersoonWgDao;

    @Autowired
    protected FaillissementSurseanceWgDao faillissementSurseanceWgDao;

    @Autowired
    protected RechtsvormWgService rechtsvormWgService;

    @Autowired
    protected GemoedsbezwaardheidWgDao gemoedsbezwaardheidWgDao;

    public List<AdministratieveEenheidWg> getAdministratieveEenheidWgIfRequired(final Long persoonId,
                                                                                 final String lhnr,
                                                                                 final LocalDateTime beschouwingsmoment,
                                                                                 CwsIhpConfiguratie cwsIhpConfiguratie){
        List<AdministratieveEenheidWg> administratieveEenheidWgList = null;
        if (cwsIhpConfiguratie.requiresAdministratieveEenheid()) {
            administratieveEenheidWgList = findAdministratieveEenheidByPersoonId(persoonId, lhnr, beschouwingsmoment, cwsIhpConfiguratie);
        }

        return administratieveEenheidWgList;
    }

    protected List<GemoedsbezwaardheidWg> getGemoedsbezwaardheidWgIfRequired(final Long persoonId,
                                                                           final LocalDateTime beschouwingsmoment,
                                                                           CwsIhpConfiguratie cwsIhpConfiguratie){
        List<GemoedsbezwaardheidWg> gemoedsbezwaardheidWgList = null;
        if (cwsIhpConfiguratie.requiresGemoedsbezwaardheid()) {
            gemoedsbezwaardheidWgList = gemoedsbezwaardheidWgDao.findGemoedsbezwaardheidByPersoonId(persoonId, beschouwingsmoment, cwsIhpConfiguratie);
        }

        return gemoedsbezwaardheidWgList;
    }

    protected List<FaillissementSurseanceWg> getFaillissementSurseanceWgIfRequired(final Long persoonId,
                                                                                 final LocalDateTime beschouwingsmoment,
                                                                                 CwsIhpConfiguratie cwsIhpConfiguratie){
        List<FaillissementSurseanceWg> faillissementSurseanceWgList = null;
        if (cwsIhpConfiguratie.requiresGemoedsbezwaardheid()) {
            faillissementSurseanceWgList = faillissementSurseanceWgDao.findFaillissementSurseanceByPersoonId(persoonId, beschouwingsmoment, cwsIhpConfiguratie);
        }

        return faillissementSurseanceWgList;
    }

    protected List<AdministratieveEenheidWg> findAdministratieveEenheidByPersoonId(final Long persoonId, final String lhnr, final LocalDateTime beschouwingsmoment, CwsIhpConfiguratie cwsIhpConfiguratie) {
        List<AdministratieveEenheidWg> administratieveEenheidWgList = administratieveEenheidWgDao.findAdministratieveEenheidByPersoonId(persoonId, lhnr, beschouwingsmoment, cwsIhpConfiguratie);
        administratieveEenheidWgList.forEach(administratieveEenheidWg -> {

            AdreshoudingWg adreshoudingWg = findAdres(administratieveEenheidWg.getAehId(), beschouwingsmoment, cwsIhpConfiguratie);
            administratieveEenheidWg.setAdreshouding(adreshoudingWg);

            findAndAttachAdministratieveEenheidMembers(administratieveEenheidWg, beschouwingsmoment, cwsIhpConfiguratie);
        });

        return administratieveEenheidWgList;
    }
}
