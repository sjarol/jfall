package nl.uwv.cws.cwsihp.model.hr;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Builder
@Getter
@Setter
public class ActiviteitHandelsregisterHr {

    private Long activiteitId;
    private String omschrijving;
    private List<SbiklasseHr> sbiklasseHrList;
}
