package nl.uwv.cws.cwsihp.model.ihp;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter
public class HuwelijkGeregistreerdPartnerIhp {

    private String voorvoegselGeslachtsnaamPartner;
    private String geslachtsnaamPartner;
}
