package nl.uwv.cws.cwsihp.model.configuratie;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import nl.uwv.cws.common.model.configuratie.Configuratie;

@Setter
@Getter
@ToString
public class CwsIhpConfiguratie extends Configuratie<ConfiguratieSoortSelectie, ConfiguratieGroepenGegevens> {

    public static CwsIhpConfiguratie deepCopy(Configuratie<ConfiguratieSoortSelectie, ConfiguratieGroepenGegevens> configuratie) {
        CwsIhpConfiguratie cwsIhpConfiguratie = null;
        if (configuratie != null) {
            cwsIhpConfiguratie = new CwsIhpConfiguratie();
            cwsIhpConfiguratie.setCconId(configuratie.getCconId());
            cwsIhpConfiguratie.setContractId(configuratie.getContractId());
            cwsIhpConfiguratie.setContractStartDate(configuratie.getContractStartDate());
            cwsIhpConfiguratie.setNaam(configuratie.getNaam());
            cwsIhpConfiguratie.setVersion(configuratie.getVersion());
            cwsIhpConfiguratie.setStatus(configuratie.getStatus());
            cwsIhpConfiguratie.setStartDate(configuratie.getStartDate());
            cwsIhpConfiguratie.setStartTransactionTimestamp(configuratie.getStartTransactionTimestamp());
            cwsIhpConfiguratie.setEndDate(configuratie.getEndDate());
            cwsIhpConfiguratie.setEndTransactionTimestamp(configuratie.getEndTransactionTimestamp());
        }
        return cwsIhpConfiguratie;
    }

    public boolean excludeBeeindigdAdres() {
        return soortSelectie.isBeeindigdAdresUitsluiten();
    }

    public boolean requiresNietNatuurlijkPersoon() {
        return this.groepenGegevens.requiresNietNatuurlijkPersoon();
    }

    public boolean requiresRechtspersoon() {
        return this.groepenGegevens.requiresRechtspersoon();
    }

    public boolean requiresActiviteitHandelsregisterRechtspersoon() {
        return this.groepenGegevens.requiresActiviteitHandelsregisterRechtspersoon();
    }

    public boolean requiresVennootschapBuitenland() {
        return this.groepenGegevens.requiresVennootschapBuitenland();
    }

    public boolean requiresAnyNatuurlijkPersoon() {
        return this.requiresNatuurlijkPersoon() ||
                this.requiresHuwelijkGeregistreerdPartnerschap();
    }

    public boolean requiresNatuurlijkPersoon() {
        return this.groepenGegevens.requiresNatuurlijkPersoon();
    }

    public boolean requiresHuwelijkGeregistreerdPartnerschap() {
        return this.groepenGegevens.requiresHuwelijkGeregistreerdPartnerschap();
    }

    public boolean requiresPersoonHandelsregister() {
        return this.groepenGegevens.requiresPersoonHandelsregister();
    }

    public boolean requiresRechtsvorm() {
        return this.groepenGegevens.requiresRechtsvorm();
    }

    public boolean requiresFaillissementSurseance() {
        return this.groepenGegevens.requiresFaillissementSurseance();
    }

    public boolean requiresGemoedsbezwaardheid() {
        return this.groepenGegevens.requiresGemoedsbezwaardheid();
    }

    public boolean requiresAnyAdresNederlandPersoon() {
        return this.requiresAdresNederlandPersoon() ||
                this.requiresStraatadresNederlandPersoon() ||
                this.requiresPostbusadresNederlandPersoon();
    }

    public boolean requiresAdresNederlandPersoon() {
        return this.groepenGegevens.requiresAdresNederlandPersoon();
    }

    public boolean requiresStraatadresNederlandPersoon() {
        return this.groepenGegevens.requiresStraatadresNederlandPersoon();
    }

    public boolean requiresPostbusadresNederlandPersoon() {
        return this.groepenGegevens.requiresPostbusadresNederlandPersoon();
    }

    public boolean requiresAnyAdresBuitenlandPersoon() {
        return this.requiresAdresBuitenlandPersoon() ||
                this.requiresStraatadresBuitenlandPersoon() ||
                this.requiresPostbusadresBuitenlandPersoon();
    }

    public boolean requiresAdresBuitenlandPersoon() {
        return this.groepenGegevens.requiresAdresBuitenlandPersoon();
    }

    public boolean requiresStraatadresBuitenlandPersoon() {
        return this.groepenGegevens.requiresStraatadresBuitenlandPersoon();
    }

    public boolean requiresPostbusadresBuitenlandPersoon() {
        return this.groepenGegevens.requiresPostbusadresBuitenlandPersoon();
    }

    public boolean requiresAdresBuitenlandOngestructureerdPersoon() {
        return this.groepenGegevens.requiresAdresBuitenlandOngestructureerdPersoon();
    }

    public boolean requiresMaatschappelijkeActiviteit() {
        return this.groepenGegevens.requiresMaatschappelijkeActiviteit();
    }

    public boolean requiresSbiklasseMaatschappelijkeActiviteit() {
        return this.groepenGegevens.requiresSbiklasseMaatschappelijkeActiviteit();
    }

    public boolean requiresVestigingHandelsregister() {
        return this.groepenGegevens.requiresVestigingHandelsregister();
    }

    public boolean requiresAnyAdresNederlandVestigingHandelsregister() {
        return this.requiresAdresNederlandVestigingHandelsregister() ||
                this.requiresStraatadresNederlandVestigingHandelsregister() ||
                this.requiresPostbusadresNederlandVestigingHandelsregister();
    }

    public boolean requiresAdresNederlandVestigingHandelsregister() {
        return this.groepenGegevens.requiresAdresNederlandVestigingHandelsregister();
    }

    public boolean requiresStraatadresNederlandVestigingHandelsregister() {
        return this.groepenGegevens.requiresStraatadresNederlandVestigingHandelsregister();
    }

    public boolean requiresPostbusadresNederlandVestigingHandelsregister() {
        return this.groepenGegevens.requiresPostbusadresNederlandVestigingHandelsregister();
    }

    public boolean requiresAnyAdresBuitenlandVestigingHandelsregister() {
        return this.requiresAdresBuitenlandVestigingHandelsregister() ||
                this.requiresStraatadresBuitenlandVestigingHandelsregister() ||
                this.requiresPostbusadresBuitenlandVestigingHandelsregister();
    }

    public boolean requiresAdresBuitenlandVestigingHandelsregister() {
        return this.groepenGegevens.requiresAdresBuitenlandVestigingHandelsregister();
    }

    public boolean requiresStraatadresBuitenlandVestigingHandelsregister() {
        return this.groepenGegevens.requiresStraatadresBuitenlandVestigingHandelsregister();
    }

    public boolean requiresPostbusadresBuitenlandVestigingHandelsregister() {
        return this.groepenGegevens.requiresPostbusadresBuitenlandVestigingHandelsregister();
    }

    public boolean requiresAdresBuitenlandOngestructureerdVestigingHandelsregister() {
        return this.groepenGegevens.requiresAdresBuitenlandOngestructureerdVestigingHandelsregister();
    }

    public boolean requiresActiviteitHandelsregisterVestigingHandelsregister() {
        return this.groepenGegevens.requiresActiviteitHandelsregisterVestigingHandelsregister();
    }

    public boolean requiresSbiklasseActiviteitHandelsregister() {
        return this.groepenGegevens.requiresSbiklasseActiviteitHandelsregister();
    }

    public boolean requiresOnderneming() {
        return this.groepenGegevens.requiresOnderneming();
    }

    public boolean requiresSbiklasseOnderneming() {
        return this.groepenGegevens.requiresSbiklasseOnderneming();
    }

    public boolean requiresHandelsnaamOnderneming() {
        return this.groepenGegevens.requiresHandelsnaamOnderneming();
    }

    public boolean requiresHandelsnaamVestigingHandelsregister() {
        return this.groepenGegevens.requiresHandelsnaamVestigingHandelsregister();
    }

    public boolean requiresAdministratieveEenheid() {
        return this.groepenGegevens.requiresAdministratieveEenheid();
    }

    public boolean requiresSectorRisicogroep() {
        return this.groepenGegevens.requiresSectorRisicogroep();
    }

    public boolean requiresPremiepercentageIndividueel() {
        return this.groepenGegevens.requiresPremiepercentageIndividueel();
    }

    public boolean requiresEigenRisicoDrager() {
        return this.groepenGegevens.requiresEigenRisicoDrager();
    }

    public boolean requiresAnyAdresNederlandWg() {
        return this.requiresAdresNederlandWg() ||
                this.requiresStraatadresNederlandWg() ||
                this.requiresPostbusadresNederlandWg();
    }

    public boolean requiresAdresNederlandWg() {
        return this.groepenGegevens.requiresAdresNederlandWg();
    }

    public boolean requiresStraatadresNederlandWg() {
        return this.groepenGegevens.requiresStraatadresNederlandWg();
    }

    public boolean requiresPostbusadresNederlandWg() {
        return this.groepenGegevens.requiresPostbusadresNederlandWg();
    }

    public boolean requiresAnyAdresBuitenlandWg() {
        return this.requiresAdresBuitenlandWg() ||
                this.requiresStraatadresBuitenlandWg() ||
                this.requiresPostbusadresBuitenlandWg();
    }

    public boolean requiresAdresBuitenlandWg() {
        return this.groepenGegevens.requiresAdresBuitenlandWg();
    }

    public boolean requiresStraatadresBuitenlandWg() {
        return this.groepenGegevens.requiresStraatadresBuitenlandWg();
    }

    public boolean requiresPostbusadresBuitenlandWg() {
        return this.groepenGegevens.requiresPostbusadresBuitenlandWg();
    }

    public boolean requiresAdresBuitenlandOngestructureerdWg() {
        return this.groepenGegevens.requiresAdresBuitenlandOngestructureerdWg();
    }

    public boolean requiresVoortzettingsrelatieOpvolger() {
        return this.groepenGegevens.requiresVoortzettingsrelatieOpvolger();
    }

    public boolean requiresVoortzettingsrelatieVoorganger() {
        return this.groepenGegevens.requiresVoortzettingsrelatieVoorganger();
    }

    public boolean requiresAangifteFrequentieAdministratieveEenheid() {
        return this.groepenGegevens.requiresAangifteFrequentieAdministratieveEenheid();
    }

    public boolean requiresAansluitingsnummerBv() {
        return this.groepenGegevens.requiresAansluitingsnummerBv();
    }
}
