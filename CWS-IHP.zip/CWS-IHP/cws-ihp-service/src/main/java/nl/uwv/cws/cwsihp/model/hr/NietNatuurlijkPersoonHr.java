package nl.uwv.cws.cwsihp.model.hr;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.sql.Date;

@Builder
@Getter
@Setter
public class NietNatuurlijkPersoonHr {

    private Long rechtspersoonId;
    private Long buitenlandseVennootschapId;

    private Integer rsin;
    private Date datumAanvangNietNatuurlijkPersoon;
    private Integer codeFictieveDatumAanvang;
    private Date datumEindeNietNatuurlijkPersoon;
    private Integer codeFictieveDatumEinde;
    private String volledigeNaamNietNatuurlijkPersoon;

    private RechtspersoonHr rechtspersoonHr;
    private VennootschapBuitenlandHr vennootschapBuitenlandHr;

    public boolean isRechtspersoon() {
        return (this.rechtspersoonId != null);
    }
    public boolean isVennootschapBuitenland() {
        return (this.buitenlandseVennootschapId != null);
    }
}
