package nl.uwv.cws.cwsihp.webservice.mapper;

import nl.uwv.cws.common.VisibleForTesting;
import nl.uwv.cws.cwsihp.model.hr.PersoonHandelsregisterHr;
import nl.uwv.cws.cwsihp.model.ihp.NatuurlijkPersoonIhp;
import nl.uwv.cws.cwsihp.model.ihp.NietNatuurlijkPersoonIhp;
import nl.uwv.cws.cwsihp.model.ihp.PersoonIhp;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0007.CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0007.CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NatuurlijkPersoon;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0007.CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NietNatuurlijkPersoon;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0007.CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.PersoonHandelsregister;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Optional;

import static nl.uwv.cws.common.util.MapperUtil.collectNonEmptyObject;
import static nl.uwv.cws.common.util.MapperUtil.mapToJaxbListIfNotEmpty;

@Component
public class PersoonInhoudingsplichtigeMapper extends BaseMapper {

    @Autowired
    private NatuurlijkPersoonMapper natuurlijkPersoonMapper;

    @Autowired
    private NietNatuurlijkPersoonMapper nietNatuurlijkPersoonMapper;

    @Autowired
    private PersoonHandelsregisterMapper persoonHandelsregisterMapper;

    @Autowired
    private FaillissementSurseanceMapper faillissementSurseanceMapper;

    @Autowired
    private RechtsvormMapper rechtsvormMapper;

    @Autowired
    private GemoedsbezwaardheidMapper gemoedsbezwaardheidMapper;

    @Autowired
    private AdreshoudingMapper adreshoudingMapper;

    @Autowired
    private MaatschappelijkeActiviteitMapper maatschappelijkeActiviteitMapper;

    @Autowired
    private AdministratieveEenheidMapper administratieveEenheidMapper;

    @VisibleForTesting
    protected PersoonInhoudingsplichtige mapToJaxbPersoonIhp(PersoonIhp persoonIhp) {
        NietNatuurlijkPersoonIhp nietNatuurlijkPersoonIhp = persoonIhp.getNietNatuurlijkPersoonIhp();
        NatuurlijkPersoonIhp natuurlijkPersoonIhp = persoonIhp.getNatuurlijkPersoonIhp();
        PersoonHandelsregisterHr persoonHandelsregisterHr = persoonIhp.getPersoonHandelsregisterHr();

        PersoonInhoudingsplichtige persoonInhoudingsplichtige = new PersoonInhoudingsplichtige();

        if (persoonIhp.getFaillissementSurseanceWgList() != null) {
            mapToJaxbListIfNotEmpty(persoonIhp.getFaillissementSurseanceWgList(),
                    persoonInhoudingsplichtige.getFaillSurs(),
                    faillissementSurseanceMapper::mapToJaxbFaillissementSurseanceWg);
        } else {
            mapToJaxbListIfNotEmpty(persoonIhp.getFaillissementSurseanceHrList(),
                    persoonInhoudingsplichtige.getFaillSurs(),
                    faillissementSurseanceMapper::mapToJaxbFaillissementSurseanceHr);
        }

        if (persoonIhp.getRechtsvormHrList() != null) {
            mapToJaxbListIfNotEmpty(persoonIhp.getRechtsvormHrList(),
                    persoonInhoudingsplichtige.getRechtsvorm(),
                    rechtsvormMapper::mapToJaxbRechtsvormHr);
        } else {
            mapToJaxbListIfNotEmpty(persoonIhp.getRechtsvormWgList(),
                    persoonInhoudingsplichtige.getRechtsvorm(),
                    rechtsvormMapper::mapToJaxbRechtsvormWg);
        }

        mapToJaxbListIfNotEmpty(persoonIhp.getGemoedsbezwaardheidWgList(),
                persoonInhoudingsplichtige.getGemoedsbezwaardheid(),
                gemoedsbezwaardheidMapper::mapToJaxbGemoedsbezwaardheid);

        mapToJaxbListIfNotEmpty(persoonIhp.getAdreshoudingHr().getAdresNederlandHrList(),
                persoonInhoudingsplichtige.getAdreshouding(),
                adreshoudingMapper::mapToJaxbAdresNederlandUhrPersoon);

        mapToJaxbListIfNotEmpty(persoonIhp.getAdreshoudingHr().getAdresBuitenlandHrList(),
                persoonInhoudingsplichtige.getAdreshouding(),
                adreshoudingMapper::mapToJaxbAdresBuitenlandPersoon);

        mapToJaxbListIfNotEmpty(persoonIhp.getAdreshoudingHr().getAdresBuitenlandOngestructureerdHrList(),
                persoonInhoudingsplichtige.getAdreshouding(),
                adreshoudingMapper::mapToJaxbAdresBuitenlandOngestructureerdPersoon);

        mapToJaxbListIfNotEmpty(persoonIhp.getMaatschappelijkeActiviteitHrList(),
                persoonInhoudingsplichtige.getMaatschappelijkeActiviteit(),
                maatschappelijkeActiviteitMapper::mapToJaxbMaatschappelijkeActiviteit);

        mapToJaxbListIfNotEmpty(persoonIhp.getAdministratieveEenheidWgList(),
                persoonInhoudingsplichtige.getAdministratieveEenheid(),
                administratieveEenheidMapper::mapToJaxbAdministratieveEenheid);

        Optional<NietNatuurlijkPersoon> nietNatuurlijkPersoon = nietNatuurlijkPersoonMapper.mapToJaxbNietNatuurlijkPersoon(nietNatuurlijkPersoonIhp);
        nietNatuurlijkPersoon.ifPresent(persoonInhoudingsplichtige::setNietNatuurlijkPersoon);

        Optional<NatuurlijkPersoon> natuurlijkPersoon = natuurlijkPersoonMapper.mapToJaxbNatuurlijkPersoon(natuurlijkPersoonIhp);
        natuurlijkPersoon.ifPresent(persoonInhoudingsplichtige::setNatuurlijkPersoon);

        Optional<PersoonHandelsregister> persoonHandelsregister = persoonHandelsregisterMapper.mapToJaxbPersoonHandelsregister(persoonHandelsregisterHr);
        persoonHandelsregister.ifPresent(persoonInhoudingsplichtige::setPersoonHandelsregister);

        return collectNonEmptyObject(persoonInhoudingsplichtige);
    }
}
