package nl.uwv.cws.cwsihp.dao.ihp;

import nl.uwv.cws.cwsihp.dao.mapper.VoortzettingsrelatieOpvolgerWgRowMapper;
import nl.uwv.cws.cwsihp.model.configuratie.CwsIhpConfiguratie;
import nl.uwv.cws.cwsihp.model.wg.VoortzettingsrelatieOpvolgerWg;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public class VoortzettingsrelatieOpvolgerWgDao extends BaseDao {

    @Autowired
    private VoortzettingsrelatieOpvolgerWgRowMapper voortzettingsrelatieOpvolgerWgRowMapper;

    public List<VoortzettingsrelatieOpvolgerWg> findVoortzettingsrelatieOpvolger(final Long administratieveEenheidId, final LocalDateTime beschouwingsmoment, final CwsIhpConfiguratie cwsIhpConfiguratie) {
        Timestamp beschouwingsmomentTimestamp = Timestamp.valueOf(beschouwingsmoment);
        final String sql =
                " SELECT dat_voortzet " +
                "      , perc_voortzet " +
                "      , lhnr_opv " +
                " FROM WGA_VOORTZETTINGSRELATIE " +
                " WHERE aeh_id = :administratieveEenheidId " +
                " AND aeh_id_opv is not null " +
                " AND his_ts_in <= :beschouwingsmoment " +
                " AND his_ts_end > :beschouwingsmoment";

        SqlParameterSource namedParameters = new MapSqlParameterSource()
                .addValue("administratieveEenheidId", administratieveEenheidId.toString())
                .addValue("beschouwingsmoment", beschouwingsmomentTimestamp);
        List<String> attributen = cwsIhpConfiguratie.getGroepenGegevens().getRequiredColumnsVoortzettingsrelatieOpvolger();

        return jdbcTemplate.query(sql, namedParameters, (resultSet, i) -> voortzettingsrelatieOpvolgerWgRowMapper.mapRow(resultSet, attributen));
    }
}
