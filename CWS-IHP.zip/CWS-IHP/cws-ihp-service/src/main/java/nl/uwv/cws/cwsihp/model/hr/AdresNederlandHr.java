package nl.uwv.cws.cwsihp.model.hr;

import lombok.Getter;
import lombok.experimental.SuperBuilder;

import java.sql.Date;

@SuperBuilder
@Getter
public class AdresNederlandHr extends AdresHr {
    private String codeAdresrol;
    private Date datumAanvangAdreshouding;
    private Integer codeFictieveDatumAanvang;
    private Integer codeFictieveDatumEinde;
    private Integer codeAfgeschermdAdres;

    private AdresNederlandStraatadresHr straatadresHr;
    private AdresNederlandPostbusadresHr postbusadresHr;
}
