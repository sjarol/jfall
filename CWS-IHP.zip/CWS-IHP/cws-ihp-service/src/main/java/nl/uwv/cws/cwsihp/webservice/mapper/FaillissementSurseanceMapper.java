package nl.uwv.cws.cwsihp.webservice.mapper;

import nl.uwv.cws.common.VisibleForTesting;
import nl.uwv.cws.cwsihp.model.hr.FaillissementSurseanceHr;
import nl.uwv.cws.cwsihp.model.wg.FaillissementSurseanceWg;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0007.CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.FaillSurs;
import org.springframework.stereotype.Component;

import java.sql.Date;

import static nl.uwv.cws.common.util.MapperUtil.collectNonEmptyObject;
import static nl.uwv.cws.common.util.NullValueUtil.extractStringFromDateValueOrNull;
import static nl.uwv.cws.common.util.NullValueUtil.extractStringValueOrNull;
import static nl.uwv.cws.cwsihp.model.CwsIhpConstants.*;

@Component
public class FaillissementSurseanceMapper extends BaseMapper {

    @VisibleForTesting
    protected FaillSurs mapToJaxbFaillissementSurseanceHr(FaillissementSurseanceHr faillissementSurseanceHr) {
        FaillSurs faillSurs = new FaillSurs();

        final String codeFaillissementSurseance = faillissementSurseanceHr.getCodeFaillissementSurseance();
        final Date datumAanvangFaillissementSurseance = faillissementSurseanceHr.getDatumAanvangFaillissementSurseance();
        Integer codeFictieveDatumAanvang = null;
        if (datumAanvangFaillissementSurseance != null) {
            codeFictieveDatumAanvang = faillissementSurseanceHr.getCodeFictieveDatumAanvang();
        }
        final Date datumEindeFaillissementSurseance = faillissementSurseanceHr.getDatumEindeFaillissementSurseance();
        Integer codeFictieveDatumEinde = null;
        if (datumEindeFaillissementSurseance != null) {
            codeFictieveDatumEinde = faillissementSurseanceHr.getCodeFictieveDatumEinde();
        }

        ruleExecutor.setTransformedValue(faillSurs, XSD_CDFAILLSURS, codeFaillissementSurseance);
        ruleExecutor.setTransformedValue(faillSurs, XSD_DATBFAILLISSEMENTSURSEANCE, extractStringFromDateValueOrNull(datumAanvangFaillissementSurseance));
        ruleExecutor.setTransformedValue(faillSurs, XSD_CDFICTIEVEDATB, extractStringValueOrNull(codeFictieveDatumAanvang));
        ruleExecutor.setTransformedValue(faillSurs, XSD_DATEFAILLISSEMENTSURSEANCE, extractStringFromDateValueOrNull(datumEindeFaillissementSurseance));
        ruleExecutor.setTransformedValue(faillSurs, XSD_CDFICTIEVEDATE, extractStringValueOrNull(codeFictieveDatumEinde));

        return collectNonEmptyObject(faillSurs);
    }

    @VisibleForTesting
    protected FaillSurs mapToJaxbFaillissementSurseanceWg(FaillissementSurseanceWg faillissementSurseanceWg) {
        FaillSurs faillSurs = new FaillSurs();

        final String codeFaillissementSurseance = faillissementSurseanceWg.getCodeFaillissementSurseance();
        final String codeRedenEindeFaillissementSurseance = faillissementSurseanceWg.getCodeRedenEindeFaillissementSurseance();
        final Long datumAanvangFaillissementSurseance = faillissementSurseanceWg.getDatumAanvangFaillissementSurseance();
        Integer codeFictieveDatumAanvang = null;
        if (datumAanvangFaillissementSurseance != null) {
            codeFictieveDatumAanvang = 0;
        }
        final Long datumEindeFaillissementSurseance = faillissementSurseanceWg.getDatumEindeFaillissementSurseance();
        Integer codeFictieveDatumEinde = null;
        if (datumEindeFaillissementSurseance != null) {
            codeFictieveDatumEinde = 0;
        }

        ruleExecutor.setTransformedValue(faillSurs, XSD_CDFAILLSURS, codeFaillissementSurseance);
        ruleExecutor.setTransformedValue(faillSurs, XSD_CDREDENEINDEFAILLSURS, codeRedenEindeFaillissementSurseance);
        ruleExecutor.setTransformedValue(faillSurs, XSD_DATBFAILLISSEMENTSURSEANCE, extractStringValueOrNull(datumAanvangFaillissementSurseance));
        ruleExecutor.setTransformedValue(faillSurs, XSD_CDFICTIEVEDATB, extractStringValueOrNull(codeFictieveDatumAanvang));
        ruleExecutor.setTransformedValue(faillSurs, XSD_DATEFAILLISSEMENTSURSEANCE, extractStringValueOrNull(datumEindeFaillissementSurseance));
        ruleExecutor.setTransformedValue(faillSurs, XSD_CDFICTIEVEDATE, extractStringValueOrNull(codeFictieveDatumEinde));

        return collectNonEmptyObject(faillSurs);
    }
}
