package nl.uwv.cws.cwsihp.dao.mapper;

import nl.uwv.cws.common.dao.mapper.CwsRowMapper;
import nl.uwv.cws.cwsihp.model.wg.AdministratieveEenheidWg;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import static nl.uwv.cws.common.util.ConverterUtil.totDatumToTotEnMetDatum;

@Component
public class AdministratieveEenheidWgRowMapper extends CwsRowMapper<AdministratieveEenheidWg> {

    @Override
    public AdministratieveEenheidWg mapRow(ResultSet resultSet, List<String> attributen) throws SQLException {

        final Long aehId = resultSet.getLong("AEH_ID");
        final String loonheffingennummer = readApplicableString(attributen, "LHNR", resultSet);
        final String naamAdministratieveEenheid = readApplicableString(attributen, "AEH_NAAM", resultSet);
        final Long datumAanvangAdministratieveEenheid = readApplicableNullableLong(attributen, "DATAANV", resultSet);
        final Long datumEindeAdministratieveEenheid = totDatumToTotEnMetDatum(readApplicableNullableLong(attributen, "DATEIND", resultSet));

        return AdministratieveEenheidWg.builder()
                .aehId(aehId)
                .loonheffingennummer(loonheffingennummer)
                .naamAdministratieveEenheid(naamAdministratieveEenheid)
                .datumAanvangAdministratieveEenheid(datumAanvangAdministratieveEenheid)
                .datumEindeAdministratieveEenheid(datumEindeAdministratieveEenheid)
                .build();
    }
}
