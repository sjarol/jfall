package nl.uwv.cws.cwsihp.webservice;

import nl.uwv.cws.common.aspect.LogPerformance;
import nl.uwv.cws.common.model.CwsAuthorization;
import nl.uwv.cws.common.model.configuratie.ConfiguratieKey;
import nl.uwv.cws.common.service.AuthorizationService;
import nl.uwv.cws.common.service.RequestValidationService;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigerequest_v0007.CwsInhoudingsplichtigeRequest;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigerequest_v0007.CwsInhoudingsplichtigeRequest.Gegevensvraag.ContractGegevenslevering;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import static nl.uwv.cws.cwsihp.model.CwsIhpConstants.LEV_CD;

@Component
public class RequestValidator {
    @Autowired
    private RequestValidationService requestValidationService;

    @Autowired
    private AuthorizationService authorizationService;

    @LogPerformance
    public void validateGegevensvraag(CwsInhoudingsplichtigeRequest request) {
        ContractGegevenslevering contractGegevenslevering = request.getGegevensvraag().getContractGegevenslevering();
        String contractNr = contractGegevenslevering.getContractnrGegevenslevering();
        String contractStart = contractGegevenslevering.getDatBContractGegevenslevering();

        ContractGegevenslevering.GegevensafnemerConfiguratie configContainer = contractGegevenslevering.getGegevensafnemerConfiguratie();
        String versieNrGegevensafnemerConf = configContainer==null ? null : configContainer.getVersienrGegevensafnemerConf();
        requestValidationService.validateConfiguratieKey(contractNr, contractStart, versieNrGegevensafnemerConf);

        if (request.getGegevensvraag().getAdministratieveEenheid() != null && StringUtils.hasText(request.getGegevensvraag().getAdministratieveEenheid().getLoonheffingennr())) {
            final String loonhefffingennummer = request.getGegevensvraag().getAdministratieveEenheid().getLoonheffingennr();
            requestValidationService.validateLoonheffingennummer(loonhefffingennummer);
        }
    }

    public void validateAuthorisation(CwsAuthorization cwsAuthorization, ConfiguratieKey configuratieKey) {
        authorizationService.isAfnemerAuthorised(cwsAuthorization, configuratieKey, LEV_CD);
    }
}
