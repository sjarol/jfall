package nl.uwv.cws.cwsihp.dao.ihp;

import nl.uwv.cws.cwsihp.dao.mapper.AdresBuitenlandOngestructureerdWgRowMapper;
import nl.uwv.cws.cwsihp.model.configuratie.CwsIhpConfiguratie;
import nl.uwv.cws.cwsihp.model.wg.AdresBuitenlandOngestructureerdWg;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public class AdresBuitenlandOngestructureerdWgDao extends BaseDao {
	
	@Autowired
	private AdresBuitenlandOngestructureerdWgRowMapper rowMapper;

    public List<AdresBuitenlandOngestructureerdWg> findAdresBuitenlandOngestructureerd(final Long administratieveEenheidId, final LocalDateTime beschouwingsmoment, final CwsIhpConfiguratie cwsIhpConfiguratie) {
        Timestamp beschouwingsmomentTimestamp = Timestamp.valueOf(beschouwingsmoment);

        String sql = 	" SELECT adr.adresrol " +
						"      , adr.dataanv " +
						"      , adr.dateind " +
						"      , adr.b_adresregel " +
						"      , adr.b_woonpl_landregel " +
						"      , adr.regionaam " +
						"      , adr.landcode " +
						" FROM wga_adres adr " +
						" WHERE adr.aeh_id = :administratieveEenheidId " +
						" AND adr.adrestypek33 IN ('SAB', 'PAB') " +
						" AND adr.his_ts_in  <  :beschouwingsmoment " +
						" AND adr.his_ts_end >= :beschouwingsmoment" +
						" AND NOT EXISTS (SELECT 1 " +
		                "                 FROM wga_adres_struct adrstruct " +
				        "                 WHERE adrstruct.adr_id = adr.adr_id " +
				        "                 AND adrstruct.his_ts_in  <  :beschouwingsmoment " +
				        "                 AND adrstruct.his_ts_end >= :beschouwingsmoment) " +
						(cwsIhpConfiguratie.excludeBeeindigdAdres() ? AdreshoudingWgQueries.CONDITION_EXCLUDE_BEEINDIGD_ADRES : "");

        SqlParameterSource namedParameters = new MapSqlParameterSource()
        		.addValue("administratieveEenheidId", administratieveEenheidId)
				.addValue("beschouwingsmoment", beschouwingsmomentTimestamp);

		return jdbcTemplate.query(sql, namedParameters, (resultSet, i) -> rowMapper.mapRow(resultSet, cwsIhpConfiguratie.getGroepenGegevens().getRequiredColumnsAdresBuitenlandOngestructureerdWg()));
	}	
}
