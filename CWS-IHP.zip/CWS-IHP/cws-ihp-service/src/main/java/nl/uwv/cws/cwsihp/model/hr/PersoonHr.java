package nl.uwv.cws.cwsihp.model.hr;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Builder
@Setter
@Getter
public class PersoonHr {

    private Long persoonId;
    private String kvkNummer;
    private Long naamPersoonId;
    private Long natuurlijkePersoonId;

    public boolean isPersoonHandelsregister() {
            return (this.naamPersoonId != null);
    }

    public boolean isNatuurlijkPersoon() {
        return (this.natuurlijkePersoonId != null);
    }

    public boolean isNietNatuurlijkPersoon() {
        // Een Persoon is een Niet Natuurlijk Persoon als het geen PersoonHandelsregister en
        // geen NatuurlijkePersoon is.
        return !(this.isPersoonHandelsregister() || this.isNatuurlijkPersoon());
    }

}
