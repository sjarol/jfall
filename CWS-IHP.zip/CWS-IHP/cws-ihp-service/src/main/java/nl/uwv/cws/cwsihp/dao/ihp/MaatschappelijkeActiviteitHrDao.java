package nl.uwv.cws.cwsihp.dao.ihp;

import nl.uwv.cws.cwsihp.dao.mapper.MaatschappelijkeActiviteitHrRowMapper;
import nl.uwv.cws.cwsihp.model.configuratie.CwsIhpConfiguratie;
import nl.uwv.cws.cwsihp.model.hr.MaatschappelijkeActiviteitHr;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public class MaatschappelijkeActiviteitHrDao extends BaseDao {

    @Autowired
    private MaatschappelijkeActiviteitHrRowMapper maatschappelijkeActiviteitRowMapper;

    public List<MaatschappelijkeActiviteitHr> findMaatschappelijkeActiviteitByKvkNummer(final String kvkNummer, final LocalDateTime beschouwingsmoment, final CwsIhpConfiguratie cwsIhpConfiguratie) {
        final String whereClause = "WHERE maa.kvk_nummer = :kvkNummer ";
        final boolean joinPersoon = false;
        return findMaatschappelijkeActiviteit(kvkNummer, whereClause, joinPersoon, beschouwingsmoment, cwsIhpConfiguratie);
    }

    public List<MaatschappelijkeActiviteitHr> findMaatschappelijkeActiviteitByNummerIhp(final String bsnOrRsin, final LocalDateTime beschouwingsmoment, final CwsIhpConfiguratie cwsIhpConfiguratie) {
        final String whereClause = "WHERE (pers.bsn = :nrIhp OR pers.rsin = :nrIhp) ";
        final boolean joinPersoon = true;
        return findMaatschappelijkeActiviteit(bsnOrRsin, whereClause, joinPersoon, beschouwingsmoment, cwsIhpConfiguratie);
    }

    public List<MaatschappelijkeActiviteitHr> findMaatschappelijkeActiviteit(final String identifier, final String whereClause, boolean joinPersoon, final LocalDateTime beschouwingsmoment, final CwsIhpConfiguratie cwsIhpConfiguratie) {

        String sql = "WITH laatste_beeld AS " +
                     "        (SELECT kvk_nummer, datum_einde_cgm, cd_datum_einde_cgm " +
                     "         FROM (SELECT maa.kvk_nummer " +
                     "                    , maa.datum_einde_cgm  " +
                     "                    , maa.cd_datum_einde_cgm  " +
                     "                    , ROW_NUMBER() OVER (PARTITION BY maa.kvk_nummer ORDER BY maa.datum_aanvang_cgm DESC, maa.his_ts_in DESC) AS rn  " +
                     "               FROM uh_maatschappelijke_activiteit maa " +
                     (joinPersoon ? "INNER JOIN uh_persoon pers ON (maa.kvk_nummer = pers.kvk_nummer) AND pers.his_ts_in  <= :beschouwingsmoment AND pers.his_ts_end > :beschouwingsmoment " : "") +
                     whereClause +
                     "               AND maa.his_ts_in  <= :beschouwingsmoment " +
                     "               AND maa.his_ts_end > :beschouwingsmoment " +
                     "              ) " +
                     "         WHERE rn = 1) " +
                     ", oudste_beeld AS " +
                     "        (SELECT kvk_nummer, datum_aanvang_cgm , cd_datum_aanvang_cgm" +
                     "         FROM (SELECT maa.kvk_nummer " +
                     "                    , maa.datum_aanvang_cgm  " +
                     "                    , maa.cd_datum_aanvang_cgm  " +
                     "                    , ROW_NUMBER() OVER (PARTITION BY maa.kvk_nummer ORDER BY maa.datum_aanvang_cgm ASC, maa.his_ts_in ASC) AS rn  " +
                     "               FROM uh_maatschappelijke_activiteit maa " +
                     (joinPersoon ? "INNER JOIN uh_persoon pers ON (maa.kvk_nummer = pers.kvk_nummer) AND pers.his_ts_in  <= :beschouwingsmoment AND pers.his_ts_end > :beschouwingsmoment " : "") +
                     whereClause +
                     "               AND maa.his_ts_in  <= :beschouwingsmoment " +
                     "               AND maa.his_ts_end > :beschouwingsmoment " +
                     "              ) " +
                     "         WHERE rn = 1) " +
                     "SELECT laatste_beeld.kvk_nummer " +
                     "     , oudste_beeld.datum_aanvang_cgm " +
                     "     , oudste_beeld.cd_datum_aanvang_cgm " +
                     "     , laatste_beeld.datum_einde_cgm " +
                     "     , laatste_beeld.cd_datum_einde_cgm " +
                     "FROM laatste_beeld " +
                     "JOIN oudste_beeld " +
                     "ON laatste_beeld.kvk_nummer = oudste_beeld.kvk_nummer";

        Timestamp beschouwingsmomentTimestamp = Timestamp.valueOf(beschouwingsmoment);
        MapSqlParameterSource namedParameters = getNamedParameters(whereClause, identifier)
                .addValue("beschouwingsmoment", beschouwingsmomentTimestamp);
        List<String> attributen = cwsIhpConfiguratie.getGroepenGegevens().getRequiredColumnsMaatschappelijkeActiviteit();
        return jdbcTemplate.query(sql, namedParameters, (resultSet, i) -> maatschappelijkeActiviteitRowMapper.mapRow(resultSet, attributen));
    }
}
