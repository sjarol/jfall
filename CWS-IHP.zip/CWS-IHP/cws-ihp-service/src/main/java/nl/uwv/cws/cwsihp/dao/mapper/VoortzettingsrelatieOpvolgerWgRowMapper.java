package nl.uwv.cws.cwsihp.dao.mapper;

import nl.uwv.cws.common.dao.mapper.CwsRowMapper;
import nl.uwv.cws.cwsihp.model.wg.VoortzettingsrelatieOpvolgerWg;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Component
public class VoortzettingsrelatieOpvolgerWgRowMapper extends CwsRowMapper<VoortzettingsrelatieOpvolgerWg> {

    @Override
    public VoortzettingsrelatieOpvolgerWg mapRow(final ResultSet resultSet, final List<String> attributen) throws SQLException {
        final Long datumAanvangVoortzettingsrelatieOpvolger = readApplicableNullableLong(attributen, "DAT_VOORTZET", resultSet);
        final Double percentageLoonsomOvergegaan = readApplicableNullableDouble(attributen, "PERC_VOORTZET", resultSet);
        final String lhnrOpvolger = readApplicableString(attributen, "LHNR_OPV", resultSet);

        return VoortzettingsrelatieOpvolgerWg.builder()
                .datumAanvangVoortzettingsrelatieOpvolger(datumAanvangVoortzettingsrelatieOpvolger)
                .percentageLoonsomOvergegaan(percentageLoonsomOvergegaan)
                .lhnrOpvolger(lhnrOpvolger)
                .build();
    }
}
