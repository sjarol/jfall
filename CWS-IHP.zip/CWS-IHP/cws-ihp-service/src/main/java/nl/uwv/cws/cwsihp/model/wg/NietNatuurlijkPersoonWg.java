package nl.uwv.cws.cwsihp.model.wg;

import lombok.Builder;
import lombok.Getter;

@Builder
@Getter
public class NietNatuurlijkPersoonWg {

    private Integer rsin;
    private String naamNietNatuurlijkPersoon;
    private Long datumOntbindingNietNatuurlijkPersoon;
    private Long datumOprichtingNietNatuurlijkPersoon;
}
