package nl.uwv.cws.cwsihp.dao.ihp;

import nl.uwv.cws.cwsihp.dao.mapper.HandelsnaamHrRowMapper;
import nl.uwv.cws.cwsihp.model.configuratie.CwsIhpConfiguratie;
import nl.uwv.cws.cwsihp.model.hr.HandelsnaamHr;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public class HandelsnaamHrDao extends BaseDao {

    @Autowired
    private HandelsnaamHrRowMapper handelsnaamHrRowMapper;

    public List<HandelsnaamHr> findHandelsnaamVestigingHandelsregister(final String kvkNummer, final Long vestigingsNummer, final LocalDateTime beschouwingsmoment, final CwsIhpConfiguratie cwsIhpConfiguratie) {

        final String sql = "SELECT hand.handelsnaam, " +
                "    hand.volgorde, " +
                "    hand.datum_aanvang_cgm, " +
                "    hand.cd_datum_aanvang_cgm, " +
                "    hand.datum_einde_cgm, " +
                "    hand.cd_datum_einde_cgm " +
                "FROM uh_vest_handelsnaam_relatie vest_hr " +
                "JOIN uh_handelsnaam hand " +
                "ON (vest_hr.handelsnaam_id = hand.handelsnaam_id) " +
                "AND hand.his_ts_in  <= :beschouwingsmoment " +
                "AND hand.his_ts_end > :beschouwingsmoment " +
                "WHERE vest_hr.kvk_nummer = :kvkNummer " +
                "AND vest_hr.vestigings_nummer = :vestigingsNummer " +
                "AND vest_hr.his_ts_in  <= :beschouwingsmoment " +
                "AND vest_hr.his_ts_end > :beschouwingsmoment";

        Timestamp beschouwingsmomentTimestamp = Timestamp.valueOf(beschouwingsmoment);
        MapSqlParameterSource namedParameters = new MapSqlParameterSource()
                .addValue("kvkNummer", kvkNummer)
                .addValue("vestigingsNummer", vestigingsNummer)
                .addValue("beschouwingsmoment", beschouwingsmomentTimestamp);

        List<String> attributen = cwsIhpConfiguratie.getGroepenGegevens().getRequiredColumnsHandelsnaamVestigingHandelsregister();
        return jdbcTemplate.query(sql, namedParameters, (resultSet, i) -> handelsnaamHrRowMapper.mapRow(resultSet, attributen));
    }

    public List<HandelsnaamHr> findHandelsnaamOnderneming(final String kvkNummer, final LocalDateTime beschouwingsmoment, final CwsIhpConfiguratie cwsIhpConfiguratie) {

        final String sql = "SELECT hand.handelsnaam, " +
                "    hand.volgorde, " +
                "    hand.datum_aanvang_cgm, " +
                "    hand.cd_datum_aanvang_cgm, " +
                "    hand.datum_einde_cgm, " +
                "    hand.cd_datum_einde_cgm " +
                "FROM uh_ondern_handelsnaam_relatie ond_hr " +
                "JOIN uh_handelsnaam hand " +
                "ON (ond_hr.handelsnaam_id = hand.handelsnaam_id) " +
                "AND hand.his_ts_in  <= :beschouwingsmoment " +
                "AND hand.his_ts_end > :beschouwingsmoment " +
                "WHERE ond_hr.kvk_nummer = :kvkNummer " +
                "AND ond_hr.his_ts_in  <= :beschouwingsmoment " +
                "AND ond_hr.his_ts_end > :beschouwingsmoment";

        Timestamp beschouwingsmomentTimestamp = Timestamp.valueOf(beschouwingsmoment);
        MapSqlParameterSource namedParameters = new MapSqlParameterSource()
                .addValue("kvkNummer", kvkNummer)
                .addValue("beschouwingsmoment", beschouwingsmomentTimestamp);

        List<String> attributen = cwsIhpConfiguratie.getGroepenGegevens().getRequiredColumnsHandelsnaamOnderneming();
        return jdbcTemplate.query(sql, namedParameters, (resultSet, i) -> handelsnaamHrRowMapper.mapRow(resultSet, attributen));
    }
}
