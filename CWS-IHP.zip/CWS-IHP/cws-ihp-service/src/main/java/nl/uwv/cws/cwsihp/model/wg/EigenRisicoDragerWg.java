package nl.uwv.cws.cwsihp.model.wg;

import lombok.Builder;
import lombok.Getter;

@Builder
@Getter
public class EigenRisicoDragerWg {
    private String codeSzProduct;
    private Long datumAanvangEigenRisicoDrager;
    private Long datumEindeEigenRisicoDrager;
}
