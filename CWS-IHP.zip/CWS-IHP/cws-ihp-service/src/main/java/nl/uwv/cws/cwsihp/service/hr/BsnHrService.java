package nl.uwv.cws.cwsihp.service.hr;

import nl.uwv.cws.cwsihp.model.configuratie.CwsIhpConfiguratie;
import nl.uwv.cws.cwsihp.model.hr.*;
import nl.uwv.cws.cwsihp.model.ihp.NatuurlijkPersoonIhp;
import nl.uwv.cws.cwsihp.model.ihp.PersoonIhp;
import nl.uwv.cws.cwsihp.model.selection.SelectionParameters;
import nl.uwv.cws.cwsihp.model.wg.AdministratieveEenheidWg;
import nl.uwv.cws.cwsihp.model.wg.FaillissementSurseanceWg;
import nl.uwv.cws.cwsihp.model.wg.GemoedsbezwaardheidWg;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class BsnHrService extends BaseHrService {

    public List<PersoonIhp> findPersoonIhp(final SelectionParameters selectionParameters, final boolean includeAeh) {
        final String bsn = selectionParameters.getBsn();
        final String kvkNummer = selectionParameters.getKvknummer();
        final String lhnr = selectionParameters.getLoonheffingennummer();
        final LocalDateTime beschouwingsmoment = selectionParameters.getBeschouwingsmoment();
        final CwsIhpConfiguratie cwsIhpConfiguratie = selectionParameters.getCwsIhpConfiguratie();
        final List<PersoonHr> persoonHrList = persoonHrDao.findPersoonHrByBsn(bsn, beschouwingsmoment);

        List<PersoonIhp> persoonIhpList = new ArrayList<>();
        persoonHrList.forEach(persoonHr -> {
            final Long persoonId = persoonHr.getPersoonId();
            final Long natuurlijkePersoonId = persoonHr.getNatuurlijkePersoonId();

            NatuurlijkPersoonIhp natuurlijkPersoonIhp = getNatuurlijkPersoonIhpIfRequired(natuurlijkePersoonId, beschouwingsmoment, persoonHr, cwsIhpConfiguratie);
            PersoonHandelsregisterHr persoonHandelsregisterHr = getPersoonHandelsregisterHrIfRequired(persoonId, beschouwingsmoment, persoonHr, cwsIhpConfiguratie);
            List<RechtsvormHr> rechtsvormHrList = getRechtsvormHrIfRequired(persoonId, beschouwingsmoment, cwsIhpConfiguratie);
            List<FaillissementSurseanceWg> faillissementSurseanceWgList = getFaillissementSurseanceWgIfRequired(bsn, includeAeh, beschouwingsmoment, cwsIhpConfiguratie);
            List<FaillissementSurseanceHr> faillissementSurseanceHrList = getFaillissementSurseanceHrIfRequired(includeAeh, beschouwingsmoment, persoonId, cwsIhpConfiguratie);
            List<GemoedsbezwaardheidWg> gemoedsbezwaardheidWgList = getGemoedsbezwaardheidWgIfRequired(bsn, includeAeh, beschouwingsmoment, cwsIhpConfiguratie);

            AdreshoudingHr adreshoudingHr = findAdresPersoon(persoonId, persoonHr.getNaamPersoonId(), natuurlijkePersoonId, beschouwingsmoment, cwsIhpConfiguratie);

            List<MaatschappelijkeActiviteitHr> maatschappelijkeActiviteitHrList = getMaatschappelijkeActiviteitHrIfRequired(bsn, kvkNummer, beschouwingsmoment, cwsIhpConfiguratie);
            List<AdministratieveEenheidWg> administratieveEenheidWgList = getAdministratieveEenheidWgIfRequired(bsn, lhnr, includeAeh, beschouwingsmoment, cwsIhpConfiguratie);

            PersoonIhp persoonIhp = PersoonIhp.builder()
                    .natuurlijkPersoonIhp(natuurlijkPersoonIhp)
                    .persoonHandelsregisterHr(persoonHandelsregisterHr)
                    .faillissementSurseanceWgList(faillissementSurseanceWgList)
                    .faillissementSurseanceHrList(faillissementSurseanceHrList)
                    .rechtsvormHrList(rechtsvormHrList)
                    .gemoedsbezwaardheidWgList(gemoedsbezwaardheidWgList)
                    .adreshoudingHr(adreshoudingHr)
                    .maatschappelijkeActiviteitHrList(maatschappelijkeActiviteitHrList)
                    .administratieveEenheidWgList(administratieveEenheidWgList)
                    .build();

            filterAdresWg(persoonIhp);
            persoonIhpList.add(persoonIhp);
        });
        return persoonIhpList;
    }

    private NatuurlijkPersoonIhp getNatuurlijkPersoonIhpIfRequired(final Long natuurlijkePersoonId,
                                                                   final LocalDateTime beschouwingsmoment,
                                                                   PersoonHr persoonHr,
                                                                   CwsIhpConfiguratie cwsIhpConfiguratie){
        NatuurlijkPersoonIhp natuurlijkPersoonIhp = null;
        if (cwsIhpConfiguratie.requiresAnyNatuurlijkPersoon() && persoonHr.isNatuurlijkPersoon()) {
            final NatuurlijkPersoonHr natuurlijkPersoonHr = natuurlijkPersoonHrDao.findNatuurlijkPersoonHr(natuurlijkePersoonId, beschouwingsmoment, cwsIhpConfiguratie);
            natuurlijkPersoonIhp = NatuurlijkPersoonIhp.builder()
                    .natuurlijkPersoonHr(natuurlijkPersoonHr)
                    .build();
        }

        return natuurlijkPersoonIhp;
    }
}
