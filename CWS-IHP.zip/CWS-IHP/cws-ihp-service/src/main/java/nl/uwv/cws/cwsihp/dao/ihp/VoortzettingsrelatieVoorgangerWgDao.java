package nl.uwv.cws.cwsihp.dao.ihp;

import nl.uwv.cws.cwsihp.dao.mapper.VoortzettingsrelatieVoorgangerWgRowMapper;
import nl.uwv.cws.cwsihp.model.configuratie.CwsIhpConfiguratie;
import nl.uwv.cws.cwsihp.model.wg.VoortzettingsrelatieVoorgangerWg;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public class VoortzettingsrelatieVoorgangerWgDao extends BaseDao {

    @Autowired
    private VoortzettingsrelatieVoorgangerWgRowMapper voortzettingsrelatieVoorgangerWgRowMapper;

    public List<VoortzettingsrelatieVoorgangerWg> findVoortzettingsrelatieVoorganger(final Long administratieveEenheidId, final LocalDateTime beschouwingsmoment, final CwsIhpConfiguratie cwsIhpConfiguratie) {
        Timestamp beschouwingsmomentTimestamp = Timestamp.valueOf(beschouwingsmoment);
        final String sql =
                " SELECT voor.dat_voortzet " +
                "      , voor.perc_voortzet " +
                "      , aeh.lhnr as lhnr_voor " +
                " FROM WGA_VOORTZETTINGSRELATIE voor " +
                " JOIN WGA_AEH aeh " +
                " ON aeh.aeh_id = voor.aeh_id " +
                " WHERE voor.aeh_id_opv = :administratieveEenheidId " +
                " AND voor.his_ts_in <= :beschouwingsmoment " +
                " AND voor.his_ts_end > :beschouwingsmoment";

        SqlParameterSource namedParameters = new MapSqlParameterSource()
                .addValue("administratieveEenheidId", administratieveEenheidId.toString())
                .addValue("beschouwingsmoment", beschouwingsmomentTimestamp);
        List<String> attributen = cwsIhpConfiguratie.getGroepenGegevens().getRequiredColumnsVoortzettingsrelatieVoorganger();

        return jdbcTemplate.query(sql, namedParameters, (resultSet, i) -> voortzettingsrelatieVoorgangerWgRowMapper.mapRow(resultSet, attributen));
    }
}
