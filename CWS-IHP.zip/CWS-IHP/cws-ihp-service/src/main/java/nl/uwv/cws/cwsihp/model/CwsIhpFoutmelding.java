package nl.uwv.cws.cwsihp.model;

import nl.uwv.cws.common.model.Foutmelding;

/**
 * CwsIhpFoutmelding range F071 - F0799
 * voor CwsIhp specifieke code
 */
public enum CwsIhpFoutmelding implements Foutmelding {

    F071("F", "071", "Inhoudingsplichtige niet gevonden in het handelsregister of de werkgeversadministratie"),
    F072("F", "072", "Geen gegevens gevonden");


    private final String soort;
    private final String code;
    private final String message;

    CwsIhpFoutmelding(String soort, String code, String message) {
        this.soort = soort;
        this.code = code;
        this.message = message;
    }

    @Override
    public String getSoort() {
        return soort;
    }

    @Override
    public String getCode() {
        return code;
    }

    @Override
    public String getMessage() {
        return message;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(this.soort)
            .append(this.code)
            .append(": ")
            .append(this.message);
        return sb.toString();
    }
}
