package nl.uwv.cws.cwsihp.dao.ihp;

import nl.uwv.cws.cwsihp.dao.mapper.PersoonHandelsregisterHrRowMapper;
import nl.uwv.cws.cwsihp.model.configuratie.CwsIhpConfiguratie;
import nl.uwv.cws.cwsihp.model.hr.PersoonHandelsregisterHr;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

import static nl.uwv.cws.common.util.DaoUtil.findOneOrNone;

@Repository
public class PersoonHandelsregisterHrDao extends BaseDao {

    @Autowired
    private PersoonHandelsregisterHrRowMapper persoonHandelsregisterHrRowMapper;

    public PersoonHandelsregisterHr findPersoonHandelsregisterHr (final Long persoonId, final Long naamPersoonId, final LocalDateTime beschouwingsmoment, final CwsIhpConfiguratie cwsIhpConfiguratie) {
        // Voor PersoonHandelsregister kunnen meerdere actuele records gevonden worden.
        // Het uiteindelijke resultaat is een combinatie van het oudste beeld en het laatste beeld.
        // Er kan en mag dan altijd maar 1 record teruggegeven worden.
        final String sql = "WITH laatste_beeld_ph AS " +
                           "   (SELECT datum_einde_cgm, " +
                           "           cd_datum_einde_cgm, " +
                           "           naam " +
                           "    FROM uh_naampersoon " +
                           "    WHERE naam_persoon_id = :naamPersoonId " +
                           "    AND his_ts_in  <= :beschouwingsmoment " +
                           "    AND his_ts_end > :beschouwingsmoment " +
                           "    ORDER BY datum_aanvang_cgm DESC, his_ts_in DESC " +
                           "    FETCH FIRST 1 ROWS ONLY), " +
                           "oudste_beeld_ph AS " +
                           "   (SELECT datum_aanvang_cgm, " +
                           "           cd_datum_aanvang_cgm " +
                           "    FROM uh_naampersoon " +
                           "    WHERE naam_persoon_id = :naamPersoonId " +
                           "    AND his_ts_in  <= :beschouwingsmoment " +
                           "    AND his_ts_end > :beschouwingsmoment " +
                           "    ORDER BY datum_aanvang_cgm ASC, his_ts_in ASC " +
                           "    FETCH FIRST 1 ROWS ONLY), " +
                           "laatste_beeld_pers AS " +
                           "   (SELECT volledigenaam " +
                           "    FROM uh_persoon " +
                           "    WHERE persoon_id = :persoonId " +
                           "    AND his_ts_in  <= :beschouwingsmoment " +
                           "    AND his_ts_end > :beschouwingsmoment " +
                           "    ORDER BY datum_aanvang_cgm DESC, his_ts_in DESC " +
                           "    FETCH FIRST 1 ROWS ONLY) " +
                           "SELECT oudste_beeld_ph.datum_aanvang_cgm, " +
                           "       oudste_beeld_ph.cd_datum_aanvang_cgm, " +
                           "       laatste_beeld_ph.datum_einde_cgm, " +
                           "       laatste_beeld_ph.cd_datum_einde_cgm, " +
                           "       laatste_beeld_ph.naam, " +
                           "       laatste_beeld_pers.volledigenaam  " +
                           "FROM oudste_beeld_ph, laatste_beeld_ph, laatste_beeld_pers" ;

        Timestamp beschouwingsmomentTimestamp = Timestamp.valueOf(beschouwingsmoment);
        SqlParameterSource namedParameters = new MapSqlParameterSource()
                .addValue("persoonId", persoonId)
                .addValue("naamPersoonId", naamPersoonId)
                .addValue("beschouwingsmoment", beschouwingsmomentTimestamp);

        List<String> attributen = cwsIhpConfiguratie.getGroepenGegevens().getRequiredColumnsPersoonHandelsregister();
        List<PersoonHandelsregisterHr> results = jdbcTemplate.query(sql, namedParameters, (resultSet, i) -> persoonHandelsregisterHrRowMapper.mapRow(resultSet, attributen));
        String errorMessage = "Meerdere rijen gevonden";
        return findOneOrNone(errorMessage, results);
    }
}

