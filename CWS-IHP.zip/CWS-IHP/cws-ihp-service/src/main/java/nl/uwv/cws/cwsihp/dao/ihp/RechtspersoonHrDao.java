package nl.uwv.cws.cwsihp.dao.ihp;

import nl.uwv.cws.cwsihp.dao.mapper.RechtspersoonHrRowMapper;
import nl.uwv.cws.cwsihp.model.configuratie.CwsIhpConfiguratie;
import nl.uwv.cws.cwsihp.model.hr.RechtspersoonHr;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

import static nl.uwv.cws.common.util.DaoUtil.findOneOrNone;

@Repository
public class RechtspersoonHrDao extends BaseDao {

    @Autowired
    private RechtspersoonHrRowMapper rechtspersoonRowMapper;

    public RechtspersoonHr findRechtspersoon (final Long rechtspersoonId, final LocalDateTime beschouwingsmoment, CwsIhpConfiguratie cwsIhpConfiguratie) {
        String sql = "SELECT activiteit_id, " +
                "statutairezetel, " +
                "aanvang_statutairezetel_cgm, " +
                "cd_aanvang_statutairezetel_cgm " +
                "FROM uh_rechtspersoon " +
                "WHERE rechtspersoon_id = :rechtspersoonId " +
                "AND his_ts_in  <= :beschouwingsmoment " +
                "AND his_ts_end > :beschouwingsmoment " +
                "ORDER BY aanvang_statutairezetel_cgm DESC, his_ts_in DESC " +
                "FETCH FIRST 1 ROWS ONLY";

        Timestamp beschouwingsmomentTimestamp = Timestamp.valueOf(beschouwingsmoment);
        SqlParameterSource namedParameters = new MapSqlParameterSource()
                .addValue("rechtspersoonId", rechtspersoonId)
                .addValue("beschouwingsmoment", beschouwingsmomentTimestamp);

        List<String> attributen = cwsIhpConfiguratie.getGroepenGegevens().getRequiredColumnsRechtspersoon();
        List<RechtspersoonHr> results = jdbcTemplate.query(sql, namedParameters, (resultSet, i) -> rechtspersoonRowMapper.mapRow(resultSet, attributen));
        String errorMessage = "Meerdere rijen gevonden";
        return findOneOrNone(errorMessage, results);
    }
}
