package nl.uwv.cws.cwsihp.service;

import nl.uwv.cws.common.dao.SupportingDataDao;
import nl.uwv.cws.cwsihp.model.CwsIhpConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

@Component
@CacheConfig(cacheNames = {"beschouwingsplafond"})
public class BeschouwingsmomentService {

    @Autowired
    private SupportingDataDao supportingDataDao;

    @Cacheable
    public LocalDateTime getBeschouwingsmoment() {
        return supportingDataDao.getBeschouwingsPlafond(CwsIhpConstants.CWS06_TRANSACTION_TYPE);
    }
}
