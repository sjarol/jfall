package nl.uwv.cws.cwsihp.dao.mapper;

import nl.uwv.cws.common.dao.mapper.CwsRowMapper;
import nl.uwv.cws.cwsihp.model.hr.RechtsvormHr;
import org.springframework.stereotype.Component;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import static nl.uwv.cws.cwsihp.util.DateUtil.setDatumEinde;

@Component
public class RechtsvormHrRowMapper extends CwsRowMapper<RechtsvormHr> {

    @Override
    public RechtsvormHr mapRow(final ResultSet resultSet, final List<String> attributen) throws SQLException {
        final String code = readApplicableString(attributen, "CODE_RECHTSVORM_CGM", resultSet);
        final Date datumAanvang = readApplicableDate(attributen, "DATUM_AANVANG_CGM", resultSet);
        final Integer codeFictieveDatumAanvang = readApplicableNullableInteger(attributen, "CD_DATUM_AANVANG_CGM", resultSet);
        final Date datumEinde = setDatumEinde(readApplicableDate(attributen, "DATUM_EINDE_CGM", resultSet), resultSet.getInt("CD_DATUM_EINDE_CGM"));
        final Integer codeFictieveDatumEinde = readApplicableNullableInteger(attributen, "CD_DATUM_EINDE_CGM", resultSet);

        return RechtsvormHr.builder()
                .codeRechtsvorm(code)
                .datumAanvangRechtsvorm(datumAanvang)
                .codeFictieveDatumAanvang(codeFictieveDatumAanvang)
                .datumEindeRechtsvorm(datumEinde)
                .codeFictieveDatumEinde(codeFictieveDatumEinde)
                .build();
    }
}
