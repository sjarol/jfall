package nl.uwv.cws.cwsihp.dao.mapper;

import nl.uwv.cws.common.dao.mapper.CwsRowMapper;
import nl.uwv.cws.cwsihp.model.wg.GemoedsbezwaardheidWg;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import static nl.uwv.cws.common.util.ConverterUtil.totDatumToTotEnMetDatum;

@Component
public class GemoedsbezwaardheidWgRowMapper extends CwsRowMapper<GemoedsbezwaardheidWg> {

    @Override
    public GemoedsbezwaardheidWg mapRow(final ResultSet resultSet, final List<String> attributen) throws SQLException {
        final String codeSzProduct = readApplicableString(attributen, "SZ_PRODUCT_CODE", resultSet);
        final Long datumAanvangGemoedsbezwaardheid = readApplicableNullableLong(attributen, "DATAANV", resultSet);
        final Long datumEindeGemoedsbezwaardheid = totDatumToTotEnMetDatum(readApplicableNullableLong(attributen, "DATEIND", resultSet));

        return GemoedsbezwaardheidWg.builder()
                .codeSzProduct(codeSzProduct)
                .datumAanvangGemoedsbezwaardheid(datumAanvangGemoedsbezwaardheid)
                .datumEindeGemoedsbezwaardheid(datumEindeGemoedsbezwaardheid)
                .build();
    }
}
