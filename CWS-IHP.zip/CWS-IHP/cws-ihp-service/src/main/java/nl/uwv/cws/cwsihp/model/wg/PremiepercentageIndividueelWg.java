package nl.uwv.cws.cwsihp.model.wg;

import lombok.Builder;
import lombok.Getter;

@Builder
@Getter
public class PremiepercentageIndividueelWg {
    private String codeSzProduct;
    private Double percentage;
    private Long datumAanvangPremiepercentageIndividueel;
    private Long datumEindePremiepercentageIndividueel;
}
