package nl.uwv.cws.cwsihp.dao.mapper;

import nl.uwv.cws.cwsihp.model.wg.PersoonWg;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

@Component
public class PersoonWgRowMapper implements RowMapper<PersoonWg> {

    @Override
    public PersoonWg mapRow(final ResultSet resultSet, final int rownum) throws SQLException {
        final Long persoonId = resultSet.getLong("PER_ID");

        return PersoonWg.builder()
                .persoonId(persoonId)
                .build();
    }
}
