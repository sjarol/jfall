package nl.uwv.cws.cwsihp.model.ihp;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import nl.uwv.cws.cwsihp.model.hr.NatuurlijkPersoonHr;
import nl.uwv.cws.cwsihp.model.wg.NatuurlijkPersoonWg;

@Builder
@Getter
@Setter
public class NatuurlijkPersoonIhp {

    private NatuurlijkPersoonHr natuurlijkPersoonHr;
    private NatuurlijkPersoonWg natuurlijkPersoonWg;
}
