package nl.uwv.cws.cwsihp.model.wg;

import lombok.Getter;
import lombok.experimental.SuperBuilder;

@SuperBuilder
@Getter
public class AdresBuitenlandOngestructureerdWg extends AdresWg {
    private Long datumAanvangAdreshouding;
    private Long datumEindeAdreshouding;
    private String adresregel1Buitenland;
    private String adresregel2Buitenland;
    private String adresregel3Buitenland;
    private String landcodeIso;
}
