package nl.uwv.cws.cwsihp.webservice.mapper;

import nl.uwv.cws.cwsihp.model.hr.VennootschapBuitenlandHr;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0007.CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NietNatuurlijkPersoon.VennootschapBuitenland;
import org.springframework.stereotype.Component;

import java.sql.Date;
import java.util.Optional;

import static nl.uwv.cws.common.util.MapperUtil.collectNonEmptyObject;
import static nl.uwv.cws.common.util.NullValueUtil.extractStringFromDateValueOrNull;
import static nl.uwv.cws.common.util.NullValueUtil.extractStringValueOrNull;
import static nl.uwv.cws.cwsihp.model.CwsIhpConstants.*;

@Component
public class VennootschapBuitenlandMapper extends BaseMapper {

    public Optional<VennootschapBuitenland> mapToJaxbVennootschapBuitenland(VennootschapBuitenlandHr vennootschapBuitenlandHr) {
        return Optional.ofNullable(vennootschapBuitenlandHr).map(notNullableVennootschapBuitenland -> {

            VennootschapBuitenland vennootschapBuitenland = new VennootschapBuitenland();

            final Date datumAanvangVennootschapBuitenland = notNullableVennootschapBuitenland.getDatumAanvangVennootschapBuitenland();
            // Als een datum leeg is, dan code fictieve datum ook niet leveren.
            Integer codeFictieveDatumAanvang = null;
            if (datumAanvangVennootschapBuitenland != null) {
                codeFictieveDatumAanvang = notNullableVennootschapBuitenland.getCodeFictieveDatumAanvang();
            }
            final Date datumEindeVennootschapBuitenland = notNullableVennootschapBuitenland.getDatumEindeVennootschapBuitenland();
            Integer codeFictieveDatumEinde = null;
            if (datumEindeVennootschapBuitenland != null) {
                codeFictieveDatumEinde = notNullableVennootschapBuitenland.getCodeFictieveDatumEinde();
            }

            ruleExecutor.setTransformedValue(vennootschapBuitenland, XSD_DATBVENNOOTSCHAPBUITENLAND, extractStringFromDateValueOrNull(datumAanvangVennootschapBuitenland));
            ruleExecutor.setTransformedValue(vennootschapBuitenland, XSD_CDFICTIEVEDATB, extractStringValueOrNull(codeFictieveDatumAanvang));
            ruleExecutor.setTransformedValue(vennootschapBuitenland, XSD_DATEVENNOOTSCHAPBUITENLAND, extractStringFromDateValueOrNull(datumEindeVennootschapBuitenland));
            ruleExecutor.setTransformedValue(vennootschapBuitenland, XSD_CDFICTIEVEDATE, extractStringValueOrNull(codeFictieveDatumEinde));

            return collectNonEmptyObject(vennootschapBuitenland);
        });
    }
}
