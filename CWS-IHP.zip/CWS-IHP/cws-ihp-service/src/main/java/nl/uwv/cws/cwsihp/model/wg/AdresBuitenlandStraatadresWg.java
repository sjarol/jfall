package nl.uwv.cws.cwsihp.model.wg;

import lombok.Builder;
import lombok.Getter;

@Builder
@Getter
public class AdresBuitenlandStraatadresWg {
    private String postcodeBuitenland;
    private String woonplaatsnaamBuitenland;
    private String regionaamBuitenland;
    private String landcodeIso;
    private String straatnaamBuitenland;
    private String huisnummerBuitenland;
    private String locatieomschrijvingBuitenland;
}
