package nl.uwv.cws.cwsihp.model.hr;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.sql.Date;
import java.util.List;

@Builder
@Getter
@Setter
public class MaatschappelijkeActiviteitHr {

    private String kvkNummer;
    private boolean configurationIncludesKvkNummer;

    private Date datumAanvangMaatschappelijkeActiviteit;
    private Integer codeFictieveDatumAanvang;
    private Date datumEindeMaatschappelijkeActiviteit;
    private Integer codeFictieveDatumEinde;

    private List<SbiklasseHr> sbiklasseHrList;
    private List<VestigingHandelsregisterHr> vestigingHandelsregisterHrList;

}
