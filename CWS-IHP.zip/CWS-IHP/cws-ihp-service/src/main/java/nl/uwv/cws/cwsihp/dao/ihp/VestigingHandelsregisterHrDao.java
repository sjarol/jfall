package nl.uwv.cws.cwsihp.dao.ihp;

import nl.uwv.cws.cwsihp.dao.mapper.VestigingHandelsregisterHrRowMapper;
import nl.uwv.cws.cwsihp.model.configuratie.CwsIhpConfiguratie;
import nl.uwv.cws.cwsihp.model.hr.VestigingHandelsregisterHr;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public class VestigingHandelsregisterHrDao extends BaseDao {

    @Autowired
    private VestigingHandelsregisterHrRowMapper vestigingHandelsregisterHrRowMapper;

    public List<VestigingHandelsregisterHr> findVestigingHandelsregister(final String kvkNummer, final LocalDateTime beschouwingsmoment, final CwsIhpConfiguratie cwsIhpConfiguratie) {
        final String sql = "SELECT kvk_nummer " +
                ", vestigings_nummer " +
                ", activiteit_id " +
                ", eerste_handelsnaam " +
                ", datum_aanvang_cgm " +
                ", cd_datum_aanvang_cgm " +
                ", datum_einde_cgm " +
                ", cd_datum_einde_cgm " +
                "FROM uh_vestiging " +
                "WHERE kvk_nummer = :kvkNummer " +
                "AND his_ts_in  <= :beschouwingsmoment " +
                "AND his_ts_end > :beschouwingsmoment";

        Timestamp beschouwingsmomentTimestamp = Timestamp.valueOf(beschouwingsmoment);
        SqlParameterSource namedParameters = new MapSqlParameterSource()
                .addValue("kvkNummer", kvkNummer)
                .addValue("beschouwingsmoment", beschouwingsmomentTimestamp);

        List<String> attributen = cwsIhpConfiguratie.getGroepenGegevens().getRequiredColumnsVestigingHandelsregister();
        return jdbcTemplate.query(sql, namedParameters, (resultSet, i) -> vestigingHandelsregisterHrRowMapper.mapRow(resultSet, attributen));
    }
}
