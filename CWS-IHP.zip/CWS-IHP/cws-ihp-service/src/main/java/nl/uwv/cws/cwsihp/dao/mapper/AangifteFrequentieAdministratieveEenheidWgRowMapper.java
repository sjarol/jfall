package nl.uwv.cws.cwsihp.dao.mapper;

import nl.uwv.cws.common.dao.mapper.CwsRowMapper;
import nl.uwv.cws.cwsihp.model.wg.AangifteFrequentieAdministratieveEenheidWg;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import static nl.uwv.cws.common.util.ConverterUtil.totDatumToTotEnMetDatum;

@Component
public class AangifteFrequentieAdministratieveEenheidWgRowMapper extends CwsRowMapper<AangifteFrequentieAdministratieveEenheidWg> {

    @Override
    public AangifteFrequentieAdministratieveEenheidWg mapRow(final ResultSet resultSet, final List<String> attributen) throws SQLException {
        final String codeAangifteFrequentieAdministratieveEenheid = readApplicableString(attributen, "CODE_AANGIFTEFREQUENTIE", resultSet);
        final Long datumAanvangAangifteFrequentieAdministratieveEenheid = readApplicableNullableLong(attributen, "DATAANV", resultSet);
        final Long datumEindeAangifteFrequentieAdministratieveEenheid = totDatumToTotEnMetDatum(readApplicableNullableLong(attributen, "DATEIND", resultSet));

        return AangifteFrequentieAdministratieveEenheidWg.builder()
                .codeAangifteFrequentieAdministratieveEenheid(codeAangifteFrequentieAdministratieveEenheid)
                .datumAanvangAangifteFrequentieAdministratieveEenheid(datumAanvangAangifteFrequentieAdministratieveEenheid)
                .datumEindeAangifteFrequentieAdministratieveEenheid(datumEindeAangifteFrequentieAdministratieveEenheid)
                .build();
    }
}
