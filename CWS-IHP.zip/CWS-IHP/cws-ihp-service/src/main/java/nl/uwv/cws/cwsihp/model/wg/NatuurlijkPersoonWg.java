package nl.uwv.cws.cwsihp.model.wg;

import lombok.Builder;
import lombok.Getter;
import nl.uwv.cws.cwsihp.model.ihp.HuwelijkGeregistreerdPartnerIhp;

@Builder
@Getter
public class NatuurlijkPersoonWg {

    private Integer burgerservicenummer;
    private String voorletters;
    private String voornamen;
    private String voorvoegsel;
    private String achternaam;
    private Integer codeAanduidingNaamgebruik;
    private Integer geboorteDatum;
    private Integer codeFictieveGeboortedatum;
    private String geslacht;

    private HuwelijkGeregistreerdPartnerIhp huwelijkGeregistreerdPartnerIhp;
}
