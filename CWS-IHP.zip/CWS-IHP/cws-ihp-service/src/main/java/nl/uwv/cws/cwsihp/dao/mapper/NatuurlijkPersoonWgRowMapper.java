package nl.uwv.cws.cwsihp.dao.mapper;

import nl.uwv.cws.common.dao.mapper.CwsRowMapper;
import nl.uwv.cws.common.util.CodeFictieveDatumUtil;
import nl.uwv.cws.cwsihp.model.ihp.HuwelijkGeregistreerdPartnerIhp;
import nl.uwv.cws.cwsihp.model.wg.NatuurlijkPersoonWg;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import static nl.uwv.cws.common.util.NullValueUtil.getIntegerOrNull;

@Component
public class NatuurlijkPersoonWgRowMapper extends CwsRowMapper<NatuurlijkPersoonWg> {

    @Override
    public NatuurlijkPersoonWg mapRow(final ResultSet resultSet, final List<String> attributen) throws SQLException {

        // NATUURLIJKPERSOON
        final Integer burgerservicenummer = readApplicableNullableInteger(attributen, "BSN", resultSet);
        final String voorletters = readApplicableString(attributen, "VOORLETTERS", resultSet);
        final String voornamen = readApplicableString(attributen, "VOORNAMEN", resultSet);
        final String voorvoegsel = readApplicableString(attributen, "VOORVOEGSEL", resultSet);
        final String achternaam = readApplicableString(attributen, "ACHTERNAAM", resultSet);
        final Integer codeAanduidingNaamgebruik = readApplicableNullableInteger(attributen, "CD_AANDUIDING_NAAMGEBRUIK_CGM", resultSet);
        final Integer geboorteDatum = readApplicableNullableInteger(attributen, "GEBOORTEDATUM_CGM", resultSet);
        final Integer codeFictieveGeboortedatum = getCodeFictieveGeboortedatum(resultSet, attributen);
        final String geslacht = readApplicableString(attributen, "GESLACHT", resultSet);

        // HUWELIJK/GEREGISTREERD PARTNERSCHAP
        final String voorvoegselGeslachtsnaamPartner = readApplicableString(attributen, "VOORV_GESLACHTSNM_PARTNER", resultSet);
        final String geslachtsnaamPartner = readApplicableString(attributen, "GESLACHTSNAAMPARTNER", resultSet);

        NatuurlijkPersoonWg.NatuurlijkPersoonWgBuilder natuurlijkPersoonWgBuilder = NatuurlijkPersoonWg.builder();
        natuurlijkPersoonWgBuilder.burgerservicenummer(burgerservicenummer)
                .voorletters(voorletters)
                .voornamen(voornamen)
                .voorvoegsel(voorvoegsel)
                .achternaam(achternaam)
                .codeAanduidingNaamgebruik(codeAanduidingNaamgebruik)
                .geboorteDatum(geboorteDatum)
                .codeFictieveGeboortedatum(codeFictieveGeboortedatum)
                .geslacht(geslacht);

        HuwelijkGeregistreerdPartnerIhp huwelijkGeregistreerdPartnerIhp = HuwelijkGeregistreerdPartnerIhp.builder()
                .voorvoegselGeslachtsnaamPartner(voorvoegselGeslachtsnaamPartner)
                .geslachtsnaamPartner(geslachtsnaamPartner)
                .build();

        return natuurlijkPersoonWgBuilder
                .huwelijkGeregistreerdPartnerIhp(huwelijkGeregistreerdPartnerIhp)
                .build();
    }

    private boolean requiresCodeFictieveGeboortedatum(List<String> attributen) {
        return attributen.contains("CD_GEBOORTEDATUM_CGM");
    }

    private Integer getCodeFictieveGeboortedatum(ResultSet resultSet, List<String> attributen) throws SQLException {
        Integer codeFictieveGeboortedatum = null;
        if (requiresCodeFictieveGeboortedatum(attributen)) {
            final Integer geboortedatum = getIntegerOrNull(resultSet, "GEBOORTEDATUM_CGM");
            if (geboortedatum != null) {
                codeFictieveGeboortedatum = CodeFictieveDatumUtil.determineCodeFictieveGeboortedatum(geboortedatum);
            }
        }

        return codeFictieveGeboortedatum;
    }
}
