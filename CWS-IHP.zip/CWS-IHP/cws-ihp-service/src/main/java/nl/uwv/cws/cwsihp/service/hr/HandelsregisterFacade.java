package nl.uwv.cws.cwsihp.service.hr;

import nl.uwv.cws.cwsihp.model.ihp.PersoonIhp;
import nl.uwv.cws.cwsihp.model.selection.SelectionParameters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.List;

@Component
public class HandelsregisterFacade {

    @Autowired
    private BsnHrService bsnHrService;

    @Autowired
    private RsinHrService rsinHrService;

    public List<PersoonIhp> findPersoonIhpMetAeh(SelectionParameters selectionParameters) {
        return findPersoonIhp(selectionParameters, true);
    }

    public List<PersoonIhp> findPersoonIhpZonderAeh(SelectionParameters selectionParameters) {
        return findPersoonIhp(selectionParameters, false);
    }

    private List<PersoonIhp> findPersoonIhp(final SelectionParameters selectionParameters, final boolean includeAeh) {
        final String bsn = selectionParameters.getBsn();

        List<PersoonIhp> persoonIhp;
        if (StringUtils.hasText(bsn)) {
            persoonIhp = bsnHrService.findPersoonIhp(selectionParameters, includeAeh);
        } else {
            persoonIhp = rsinHrService.findPersoonIhp(selectionParameters, includeAeh);
        }
        return persoonIhp;
    }
}
