package nl.uwv.cws.cwsihp.service.hr;

import nl.uwv.cws.cwsihp.model.configuratie.CwsIhpConfiguratie;
import nl.uwv.cws.cwsihp.model.hr.*;
import nl.uwv.cws.cwsihp.model.ihp.NietNatuurlijkPersoonIhp;
import nl.uwv.cws.cwsihp.model.ihp.PersoonIhp;
import nl.uwv.cws.cwsihp.model.selection.SelectionParameters;
import nl.uwv.cws.cwsihp.model.wg.AdministratieveEenheidWg;
import nl.uwv.cws.cwsihp.model.wg.FaillissementSurseanceWg;
import nl.uwv.cws.cwsihp.model.wg.GemoedsbezwaardheidWg;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class RsinHrService extends BaseHrService {

    public List<PersoonIhp> findPersoonIhp(final SelectionParameters selectionParameters, final boolean includeAeh) {
        final String rsin = selectionParameters.getRsin();
        final String kvkNummer = selectionParameters.getKvknummer();
        final String lhnr = selectionParameters.getLoonheffingennummer();
        final LocalDateTime beschouwingsmoment = selectionParameters.getBeschouwingsmoment();
        final CwsIhpConfiguratie cwsIhpConfiguratie = selectionParameters.getCwsIhpConfiguratie();
        final List<PersoonHr> persoonHrList = persoonHrDao.findPersoonHrByRsin(rsin, beschouwingsmoment);

        List<PersoonIhp> persoonIhpList = new ArrayList<>();
        persoonHrList.forEach(persoonHr -> {
            final Long persoonId = persoonHr.getPersoonId();

            NietNatuurlijkPersoonIhp nietNatuurlijkPersoonIhp = getNietNatuurlijkPersoonIhpIfRequired(persoonId, beschouwingsmoment, persoonHr.isNietNatuurlijkPersoon(), cwsIhpConfiguratie);
            PersoonHandelsregisterHr persoonHandelsregisterHr = getPersoonHandelsregisterHrIfRequired(persoonId, beschouwingsmoment, persoonHr, cwsIhpConfiguratie);

            List<FaillissementSurseanceWg> faillissementSurseanceWgList = getFaillissementSurseanceWgIfRequired(rsin, includeAeh, beschouwingsmoment, cwsIhpConfiguratie);
            List<FaillissementSurseanceHr> faillissementSurseanceHrList = getFaillissementSurseanceHrIfRequired(includeAeh, beschouwingsmoment, persoonId, cwsIhpConfiguratie);
            List<RechtsvormHr> rechtsvormHrList = getRechtsvormHrIfRequired(persoonId, beschouwingsmoment, cwsIhpConfiguratie);

            List<GemoedsbezwaardheidWg> gemoedsbezwaardheidWgList = getGemoedsbezwaardheidWgIfRequired(rsin, includeAeh, beschouwingsmoment, cwsIhpConfiguratie);
            AdreshoudingHr adreshoudingHr = findAdresPersoon(persoonId, persoonHr.getNaamPersoonId(), persoonHr.getNatuurlijkePersoonId(), beschouwingsmoment, cwsIhpConfiguratie);
            List<MaatschappelijkeActiviteitHr> maatschappelijkeActiviteitHrList = getMaatschappelijkeActiviteitHrIfRequired(rsin, kvkNummer, beschouwingsmoment, cwsIhpConfiguratie);
            List<AdministratieveEenheidWg> administratieveEenheidWgList = getAdministratieveEenheidWgIfRequired(rsin, lhnr, includeAeh, beschouwingsmoment, cwsIhpConfiguratie);

            PersoonIhp persoonIhp = PersoonIhp.builder()
                    .nietNatuurlijkPersoonIhp(nietNatuurlijkPersoonIhp)
                    .persoonHandelsregisterHr(persoonHandelsregisterHr)
                    .faillissementSurseanceWgList(faillissementSurseanceWgList)
                    .faillissementSurseanceHrList(faillissementSurseanceHrList)
                    .rechtsvormHrList(rechtsvormHrList)
                    .gemoedsbezwaardheidWgList(gemoedsbezwaardheidWgList)
                    .adreshoudingHr(adreshoudingHr)
                    .maatschappelijkeActiviteitHrList(maatschappelijkeActiviteitHrList)
                    .administratieveEenheidWgList(administratieveEenheidWgList)
                    .build();

            filterAdresWg(persoonIhp);
            persoonIhpList.add(persoonIhp);
        });
        return persoonIhpList;
    }

    private NietNatuurlijkPersoonIhp getNietNatuurlijkPersoonIhpIfRequired(final Long persoonId,
                                                                   final LocalDateTime beschouwingsmoment,
                                                                   boolean isNietNatuurlijkPersoon,
                                                                   CwsIhpConfiguratie cwsIhpConfiguratie){
        NietNatuurlijkPersoonIhp nietNatuurlijkPersoonIhp = null;
        if (cwsIhpConfiguratie.requiresNietNatuurlijkPersoon() && isNietNatuurlijkPersoon) {
            final NietNatuurlijkPersoonHr nietNatuurlijkPersoonHr = findNietNatuurlijkPersoonHr(persoonId, beschouwingsmoment, cwsIhpConfiguratie);
            nietNatuurlijkPersoonIhp = NietNatuurlijkPersoonIhp.builder()
                    .nietNatuurlijkPersoonHr(nietNatuurlijkPersoonHr)
                    .build();
        }

        return nietNatuurlijkPersoonIhp;
    }

    protected NietNatuurlijkPersoonHr findNietNatuurlijkPersoonHr(final Long persoonId, final LocalDateTime beschouwingsmoment, final CwsIhpConfiguratie cwsIhpConfiguratie) {
        NietNatuurlijkPersoonHr nietNatuurlijkPersoonHr = nietNatuurlijkPersoonHrDao.findNietNatuurlijkPersoonHr(persoonId, beschouwingsmoment, cwsIhpConfiguratie);

        if (cwsIhpConfiguratie.requiresRechtspersoon() && nietNatuurlijkPersoonHr.isRechtspersoon()) {
            RechtspersoonHr rechtspersoonHr = rechtspersoonHrDao.findRechtspersoon(nietNatuurlijkPersoonHr.getRechtspersoonId(), beschouwingsmoment, cwsIhpConfiguratie);
            nietNatuurlijkPersoonHr.setRechtspersoonHr(rechtspersoonHr);

            if (cwsIhpConfiguratie.requiresActiviteitHandelsregisterRechtspersoon() && rechtspersoonHr.getActiviteitId() != null) {
                final Long activiteitId = rechtspersoonHr.getActiviteitId();
                ActiviteitHandelsregisterHr activiteitHandelsregisterHr = activiteitHandelsregisterHrDao.findActiviteitHandelsregisterRechtspersoon(activiteitId, beschouwingsmoment, cwsIhpConfiguratie);
                rechtspersoonHr.setActiviteitHandelsregisterHr(activiteitHandelsregisterHr);
            }
        }

        if (cwsIhpConfiguratie.requiresVennootschapBuitenland() && nietNatuurlijkPersoonHr.isVennootschapBuitenland()) {
            VennootschapBuitenlandHr vennootschapBuitenlandHr = vennootschapBuitenlandHrDao.findVennootschapBuitenland(nietNatuurlijkPersoonHr.getBuitenlandseVennootschapId(), beschouwingsmoment, cwsIhpConfiguratie);
            nietNatuurlijkPersoonHr.setVennootschapBuitenlandHr(vennootschapBuitenlandHr);
        }

        return nietNatuurlijkPersoonHr;
    }
}
