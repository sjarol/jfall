package nl.uwv.cws.cwsihp.model.hr;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.sql.Date;
import java.util.List;

@Setter
@Getter
@Builder
public class OndernemingHr {
    private String kvkNummer;
    private boolean configurationIncludesKvkNummer;
    private Date datumAanvangOnderneming;
    private Integer codeFictieveDatumAanvang;
    private Date datumEindeOnderneming;
    private Integer codeFictieveDatumEinde;

    private List<SbiklasseHr> sbiklasseHrList;
    private List<HandelsnaamHr> handelsnaamHrList;
}
