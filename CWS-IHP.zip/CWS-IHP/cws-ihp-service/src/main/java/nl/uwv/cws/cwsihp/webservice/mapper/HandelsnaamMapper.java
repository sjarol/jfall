package nl.uwv.cws.cwsihp.webservice.mapper;

import nl.uwv.cws.cwsihp.model.hr.HandelsnaamHr;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0007.CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0007.CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Onderneming;
import org.springframework.stereotype.Component;

import java.sql.Date;

import static nl.uwv.cws.common.util.MapperUtil.collectNonEmptyObject;
import static nl.uwv.cws.common.util.NullValueUtil.*;
import static nl.uwv.cws.cwsihp.model.CwsIhpConstants.*;

@Component
public class HandelsnaamMapper extends BaseMapper {

    public VestigingHandelsregister.Handelsnaam mapToJaxbHandelsnaamVestigingHandelsregister(HandelsnaamHr handelsnaamHr) {
        VestigingHandelsregister.Handelsnaam handelsnaam = new VestigingHandelsregister.Handelsnaam();
        mapToJaxbHandelsnaam(handelsnaamHr, handelsnaam);

        return collectNonEmptyObject(handelsnaam);
    }

    public Onderneming.Handelsnaam mapToJaxbHandelsnaamOnderneming(HandelsnaamHr handelsnaamHr) {
        Onderneming.Handelsnaam handelsnaam = new Onderneming.Handelsnaam();
        mapToJaxbHandelsnaam(handelsnaamHr, handelsnaam);

        return collectNonEmptyObject(handelsnaam);
    }

    protected void mapToJaxbHandelsnaam(final HandelsnaamHr handelsnaamHr, final Object handelsnaam) {

        final String naam = handelsnaamHr.getNaam();
        final Integer volgorde = handelsnaamHr.getVolgorde();
        final Date datumAanvangHandelsnaam = handelsnaamHr.getDatumAanvangHandelsnaam();
        Integer codeFictieveDatumAanvang = null;
        if (datumAanvangHandelsnaam != null) {
            codeFictieveDatumAanvang = handelsnaamHr.getCodeFictieveDatumAanvang();
        }
        final Date datumEindeHandelsnaam = handelsnaamHr.getDatumEindeHandelsnaam();
        Integer codeFictieveDatumEinde = null;
        if (datumEindeHandelsnaam != null) {
            codeFictieveDatumEinde = handelsnaamHr.getCodeFictieveDatumEinde();
        }

        ruleExecutor.setTransformedValue(handelsnaam, XSD_HANDELSNAAM, naam);
        ruleExecutor.setTransformedValue(handelsnaam, XSD_VOLGORDEHANDELSNAAM, extractBigIntegerValueOrNull(volgorde));
        ruleExecutor.setTransformedValue(handelsnaam, XSD_DATBHANDELSNAAM, extractStringFromDateValueOrNull(datumAanvangHandelsnaam));
        ruleExecutor.setTransformedValue(handelsnaam, XSD_CDFICTIEVEDATB, extractStringValueOrNull(codeFictieveDatumAanvang));
        ruleExecutor.setTransformedValue(handelsnaam, XSD_DATEHANDELSNAAM, extractStringFromDateValueOrNull(datumEindeHandelsnaam));
        ruleExecutor.setTransformedValue(handelsnaam, XSD_CDFICTIEVEDATE, extractStringValueOrNull(codeFictieveDatumEinde));
    }
}
