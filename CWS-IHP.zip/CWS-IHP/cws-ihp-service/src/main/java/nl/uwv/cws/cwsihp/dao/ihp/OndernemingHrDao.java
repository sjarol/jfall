package nl.uwv.cws.cwsihp.dao.ihp;

import nl.uwv.cws.cwsihp.dao.mapper.OndernemingHrRowMapper;
import nl.uwv.cws.cwsihp.model.configuratie.CwsIhpConfiguratie;
import nl.uwv.cws.cwsihp.model.hr.OndernemingHr;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public class OndernemingHrDao extends BaseDao {

    @Autowired
    private OndernemingHrRowMapper ondernemingHrRowMapper;

    public List<OndernemingHr> findOnderneming(final String kvkNummer, final Long vestigingsNummer, final LocalDateTime beschouwingsmoment, final CwsIhpConfiguratie cwsIhpConfiguratie) {
        final String sql = "SELECT ond.kvk_nummer " +
                ", ond.datum_aanvang_cgm " +
                ", ond.cd_datum_aanvang_cgm " +
                ", ond.datum_einde_cgm " +
                ", ond.cd_datum_einde_cgm " +
                "FROM uh_comm_vestigingrelatie com_vest " +
                "JOIN uh_onderneming ond " +
                "ON (ond.kvk_nummer = com_vest.kvk_nummer) " +
                "AND ond.his_ts_in  <= :beschouwingsmoment " +
                "AND ond.his_ts_end > :beschouwingsmoment " +
                "WHERE com_vest.kvk_nummer = :kvkNummer " +
                "AND com_vest.vestigings_nummer = :vestigingsNummer " +
                "AND com_vest.his_ts_in  <= :beschouwingsmoment " +
                "AND com_vest.his_ts_end > :beschouwingsmoment";

        Timestamp beschouwingsmomentTimestamp = Timestamp.valueOf(beschouwingsmoment);
        SqlParameterSource namedParameters = new MapSqlParameterSource()
                .addValue("kvkNummer", kvkNummer)
                .addValue("vestigingsNummer", vestigingsNummer)
                .addValue("beschouwingsmoment", beschouwingsmomentTimestamp);
        List<String> attributen = cwsIhpConfiguratie.getGroepenGegevens().getRequiredColumnsOnderneming();
        return jdbcTemplate.query(sql, namedParameters, (resultSet, i) -> ondernemingHrRowMapper.mapRow(resultSet, attributen));
    }
}

