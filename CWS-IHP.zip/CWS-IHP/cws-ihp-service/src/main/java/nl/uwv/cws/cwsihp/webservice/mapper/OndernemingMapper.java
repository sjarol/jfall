package nl.uwv.cws.cwsihp.webservice.mapper;

import nl.uwv.cws.common.VisibleForTesting;
import nl.uwv.cws.cwsihp.model.hr.OndernemingHr;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0007.CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Onderneming;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.sql.Date;

import static nl.uwv.cws.common.util.MapperUtil.collectNonEmptyObject;
import static nl.uwv.cws.common.util.MapperUtil.mapToJaxbListIfNotEmpty;
import static nl.uwv.cws.common.util.NullValueUtil.extractStringFromDateValueOrNull;
import static nl.uwv.cws.common.util.NullValueUtil.extractStringValueOrNull;
import static nl.uwv.cws.cwsihp.model.CwsIhpConstants.*;

@Component
public class OndernemingMapper extends BaseMapper {

    @Autowired
    private SbiklasseMapper sbiklasseMapper;

    @Autowired
    private HandelsnaamMapper handelsnaamMapper;

    public Onderneming mapToJaxbOnderneming(OndernemingHr ondernemingHr) {
        Onderneming onderneming = new Onderneming();
        mapToJaxbOnderneming(ondernemingHr, onderneming);

       mapToJaxbListIfNotEmpty(ondernemingHr.getSbiklasseHrList(),
                onderneming.getSbiklasse(),
                sbiklasseMapper::mapToJaxbSbiklasseOnderneming);

        mapToJaxbListIfNotEmpty(ondernemingHr.getHandelsnaamHrList(),
                onderneming.getHandelsnaam(),
                handelsnaamMapper::mapToJaxbHandelsnaamOnderneming);

        return collectNonEmptyObject(onderneming);
    }

    @VisibleForTesting
    protected void mapToJaxbOnderneming(OndernemingHr ondernemingHr, Object onderneming) {
        String kvkNummer = null;
        if (ondernemingHr.isConfigurationIncludesKvkNummer()) {
            kvkNummer = ondernemingHr.getKvkNummer();
        }
        final Date datumAanvangOnderneming = ondernemingHr.getDatumAanvangOnderneming();
        Integer codeFictieveDatumBegin = null;
        if (datumAanvangOnderneming != null) {
            codeFictieveDatumBegin = ondernemingHr.getCodeFictieveDatumAanvang();
        }
        final Date datumEindeOnderneming = ondernemingHr.getDatumEindeOnderneming();
        Integer codeFictieveDatumEinde = null;
        if (datumEindeOnderneming != null) {
            codeFictieveDatumEinde = ondernemingHr.getCodeFictieveDatumEinde();
        }

        ruleExecutor.setTransformedValue(onderneming, XSD_KVKNR, kvkNummer);
        ruleExecutor.setTransformedValue(onderneming, XSD_DATBONDERNEMING, extractStringFromDateValueOrNull(datumAanvangOnderneming));
        ruleExecutor.setTransformedValue(onderneming, XSD_CDFICTIEVEDATB, extractStringValueOrNull(codeFictieveDatumBegin));
        ruleExecutor.setTransformedValue(onderneming, XSD_DATEONDERNEMING, extractStringFromDateValueOrNull(datumEindeOnderneming));
        ruleExecutor.setTransformedValue(onderneming, XSD_CDFICTIEVEDATE, extractStringValueOrNull(codeFictieveDatumEinde));
    }
}
