package nl.uwv.cws.cwsihp.webservice.mapper;

import nl.uwv.cws.common.VisibleForTesting;
import nl.uwv.cws.cwsihp.model.wg.GemoedsbezwaardheidWg;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0007.CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Gemoedsbezwaardheid;
import org.springframework.stereotype.Component;

import static nl.uwv.cws.common.util.MapperUtil.collectNonEmptyObject;
import static nl.uwv.cws.common.util.NullValueUtil.extractStringValueOrNull;
import static nl.uwv.cws.cwsihp.model.CwsIhpConstants.*;

@Component
public class GemoedsbezwaardheidMapper extends BaseMapper {

    @VisibleForTesting
    protected Gemoedsbezwaardheid mapToJaxbGemoedsbezwaardheid(GemoedsbezwaardheidWg gemoedsbezwaardheidWg) {
        Gemoedsbezwaardheid gemoedsbezwaardheid = new Gemoedsbezwaardheid();

        final String codeSzProduct = gemoedsbezwaardheidWg.getCodeSzProduct();
        final Long datumAanvangGemoedsbezwaardheid = gemoedsbezwaardheidWg.getDatumAanvangGemoedsbezwaardheid();
        final Long datumEindeGemoedsbezwaardheid = gemoedsbezwaardheidWg.getDatumEindeGemoedsbezwaardheid();

        ruleExecutor.setTransformedValue(gemoedsbezwaardheid, XSD_CDSZPRODUCT, codeSzProduct);
        ruleExecutor.setTransformedValue(gemoedsbezwaardheid, XSD_DATBGEMOEDSBEZWAARDHEID, extractStringValueOrNull(datumAanvangGemoedsbezwaardheid));
        ruleExecutor.setTransformedValue(gemoedsbezwaardheid, XSD_DATEGEMOEDSBEZWAARDHEID, extractStringValueOrNull(datumEindeGemoedsbezwaardheid));

        return collectNonEmptyObject(gemoedsbezwaardheid);
    }
}
