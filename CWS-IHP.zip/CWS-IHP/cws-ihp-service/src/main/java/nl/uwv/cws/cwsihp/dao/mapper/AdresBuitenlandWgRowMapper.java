package nl.uwv.cws.cwsihp.dao.mapper;

import nl.uwv.cws.common.dao.mapper.CwsRowMapper;
import nl.uwv.cws.cwsihp.model.wg.AdresBuitenlandPostbusadresWg;
import nl.uwv.cws.cwsihp.model.wg.AdresBuitenlandStraatadresWg;
import nl.uwv.cws.cwsihp.model.wg.AdresBuitenlandWg;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import static nl.uwv.cws.common.util.ConverterUtil.totDatumToTotEnMetDatum;

@Component
public class AdresBuitenlandWgRowMapper extends CwsRowMapper<AdresBuitenlandWg> {

    @Override
    public AdresBuitenlandWg mapRow(final ResultSet resultSet, final List<String> attributen) throws SQLException {

        // ADRES BUITENLAND
        final String codeAdresrol = readApplicableString(attributen, "ADRESROL", resultSet);
        final Long datumAanvangAdreshouding = readApplicableNullableLong(attributen, "DATAANV", resultSet);
        final Long datumEindeAdreshouding = totDatumToTotEnMetDatum(readApplicableNullableLong(attributen, "DATEIND", resultSet));

        final String adrestype = resultSet.getString("ADRESTYPESTRUCT");
        AdresBuitenlandStraatadresWg straatadresWg = null;
        AdresBuitenlandPostbusadresWg postbusadresWg= null;

        // STRAATADRES
        String postcodeBuitenland = null;
        String woonplaatsnaamBuitenland = null;
        String regionaamBuitenland = null;
        String landcodeIso = null;
        String straatnaamBuitenland = null;
        String huisnummerBuitenland = null;
        String locatieomschrijvingBuitenland = null;

        // POSTBUSADRES
        String postbusPostcodeBuitenland = null;
        String postbusWoonplaatsnaamBuitenland = null;
        String postbusRegionaamBuitenland = null;
        String postbusLandcodeIso = null;
        String postbusnummerBuitenland = null;


        // STRAATADRES
        if (adrestype.equals("SAB")) {
            postcodeBuitenland = readApplicableString(attributen, "POSTCODE", resultSet);
            woonplaatsnaamBuitenland = readApplicableString(attributen, "WOONPLAATS", resultSet);
            regionaamBuitenland = readApplicableString(attributen, "REGIONAAM", resultSet);
            landcodeIso = readApplicableString(attributen, "LANDCODE_ISO", resultSet);
            straatnaamBuitenland = readApplicableString(attributen, "STRAATNAAM", resultSet);
            huisnummerBuitenland = readApplicableString(attributen, "HUISNR", resultSet);
            locatieomschrijvingBuitenland = readApplicableString(attributen, "LOCATIE_OMSCH", resultSet);
        // POSTBUSADRES
        } else {
            postbusPostcodeBuitenland = readApplicablePostbusString(attributen, "POSTBUS_POSTCODE", "POSTCODE", resultSet);
            postbusWoonplaatsnaamBuitenland = readApplicablePostbusString(attributen, "POSTBUS_WOONPLAATS", "WOONPLAATS", resultSet);
            postbusRegionaamBuitenland = readApplicablePostbusString(attributen, "POSTBUS_REGIONAAM", "REGIONAAM", resultSet);
            postbusLandcodeIso = readApplicablePostbusString(attributen, "POSTBUS_LANDCODE_ISO", "LANDCODE_ISO", resultSet);
            postbusnummerBuitenland = readApplicableString(attributen, "POSTBUSNR", resultSet);
        }

        straatadresWg = AdresBuitenlandStraatadresWg.builder()
                .postcodeBuitenland(postcodeBuitenland)
                .woonplaatsnaamBuitenland(woonplaatsnaamBuitenland)
                .regionaamBuitenland(regionaamBuitenland)
                .landcodeIso(landcodeIso)
                .straatnaamBuitenland(straatnaamBuitenland)
                .huisnummerBuitenland(huisnummerBuitenland)
                .locatieomschrijvingBuitenland(locatieomschrijvingBuitenland)
                .build();

        postbusadresWg = AdresBuitenlandPostbusadresWg.builder()
                .postcodeBuitenland(postbusPostcodeBuitenland)
                .woonplaatsnaamBuitenland(postbusWoonplaatsnaamBuitenland)
                .regionaamBuitenland(postbusRegionaamBuitenland)
                .landcodeIso(postbusLandcodeIso)
                .postbusnummerBuitenland(postbusnummerBuitenland)
                .build();

        return AdresBuitenlandWg.builder()
                .codeAdresrol(codeAdresrol)
                .datumAanvangAdreshouding(datumAanvangAdreshouding)
                .datumEindeAdreshouding(datumEindeAdreshouding)
                .straatadresWg(straatadresWg)
                .postbusadresWg(postbusadresWg)
                .build();

    }

    private String readApplicablePostbusString(List<String> attributen, String attributeLabel, String columnLabel, ResultSet resultSet) throws SQLException {
        return attributen.contains(attributeLabel) ? resultSet.getString(columnLabel) : null;
    }
}
