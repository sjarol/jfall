package nl.uwv.cws.cwsihp.webservice.mapper;

import nl.uwv.cws.common.VisibleForTesting;
import nl.uwv.cws.cwsihp.model.hr.PersoonHandelsregisterHr;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0007.CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.PersoonHandelsregister;
import org.springframework.stereotype.Component;

import java.sql.Date;
import java.util.Optional;

import static nl.uwv.cws.common.util.MapperUtil.collectNonEmptyObject;
import static nl.uwv.cws.common.util.NullValueUtil.extractStringFromDateValueOrNull;
import static nl.uwv.cws.common.util.NullValueUtil.extractStringValueOrNull;
import static nl.uwv.cws.cwsihp.model.CwsIhpConstants.*;

@Component
public class PersoonHandelsregisterMapper extends BaseMapper {

    @VisibleForTesting
    protected Optional<PersoonHandelsregister> mapToJaxbPersoonHandelsregister(PersoonHandelsregisterHr persoonHandelsregisterHr) {
        return Optional.ofNullable(persoonHandelsregisterHr).map(notNullablePersoonHandelsregister -> {
                PersoonHandelsregister persoonHandelsregister = new PersoonHandelsregister();

                final Date datumAanvangPersoonHandelsregister = notNullablePersoonHandelsregister.getDatumAanvangPersoonHandelsregister();
                Integer codeFictieveDatumAanvang = null;
                if (datumAanvangPersoonHandelsregister != null) {
                    codeFictieveDatumAanvang = notNullablePersoonHandelsregister.getCodeFictieveDatumAanvang();
                }
                final Date datumEindePersoonHandelsregister = notNullablePersoonHandelsregister.getDatumEindePersoonHandelsregister();
                Integer codeFictieveDatumEinde = null;
                if (datumEindePersoonHandelsregister != null) {
                    codeFictieveDatumEinde = notNullablePersoonHandelsregister.getCodeFictieveDatumEinde();
                }
                final String naamPersoonHandelsregister = notNullablePersoonHandelsregister.getNaamPersoonHandelsregister();
                final String volledigeNaamPersoonHandelsregister = notNullablePersoonHandelsregister.getVolledigeNaamPersoonHandelsregister();

                ruleExecutor.setTransformedValue(persoonHandelsregister, XSD_DATBPERSOONHANDELSREGISTER, extractStringFromDateValueOrNull(datumAanvangPersoonHandelsregister));
                ruleExecutor.setTransformedValue(persoonHandelsregister, XSD_CDFICTIEVEDATB, extractStringValueOrNull(codeFictieveDatumAanvang));
                ruleExecutor.setTransformedValue(persoonHandelsregister, XSD_DATEPERSOONHANDELSREGISTER, extractStringFromDateValueOrNull(datumEindePersoonHandelsregister));
                ruleExecutor.setTransformedValue(persoonHandelsregister, XSD_CDFICTIEVEDATE, extractStringValueOrNull(codeFictieveDatumEinde));
                ruleExecutor.setTransformedValue(persoonHandelsregister, XSD_NAAMPERSOONHANDELSREGISTER, naamPersoonHandelsregister);
                ruleExecutor.setTransformedValue(persoonHandelsregister, XSD_VOLLEDIGENMPERSHANDELSREGISTER, volledigeNaamPersoonHandelsregister);

                return collectNonEmptyObject(persoonHandelsregister);
        });
    }
}
