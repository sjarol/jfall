package nl.uwv.cws.cwsihp.model.ihp;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import nl.uwv.cws.cwsihp.model.hr.AdreshoudingHr;
import nl.uwv.cws.cwsihp.model.hr.FaillissementSurseanceHr;
import nl.uwv.cws.cwsihp.model.hr.MaatschappelijkeActiviteitHr;
import nl.uwv.cws.cwsihp.model.hr.PersoonHandelsregisterHr;
import nl.uwv.cws.cwsihp.model.hr.RechtsvormHr;
import nl.uwv.cws.cwsihp.model.wg.AdministratieveEenheidWg;
import nl.uwv.cws.cwsihp.model.wg.FaillissementSurseanceWg;
import nl.uwv.cws.cwsihp.model.wg.GemoedsbezwaardheidWg;
import nl.uwv.cws.cwsihp.model.wg.RechtsvormWg;

import java.util.List;


@Builder
@Setter
@Getter
public class PersoonIhp {

    private NietNatuurlijkPersoonIhp nietNatuurlijkPersoonIhp;
    private NatuurlijkPersoonIhp natuurlijkPersoonIhp;
    private PersoonHandelsregisterHr persoonHandelsregisterHr;
    private List<FaillissementSurseanceWg> faillissementSurseanceWgList;
    private List<FaillissementSurseanceHr> faillissementSurseanceHrList;
    private List<RechtsvormHr> rechtsvormHrList;
    private List<RechtsvormWg> rechtsvormWgList;
    private List<GemoedsbezwaardheidWg> gemoedsbezwaardheidWgList;
    private AdreshoudingHr adreshoudingHr;
    private List<MaatschappelijkeActiviteitHr> maatschappelijkeActiviteitHrList;
    private List<AdministratieveEenheidWg> administratieveEenheidWgList;


}
