package nl.uwv.cws.cwsihp.dao.mapper;


import nl.uwv.cws.cwsihp.model.ihp.Inhoudingsplichtige;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

@Component
public class InhoudingsplichtigeRowMapper implements RowMapper<Inhoudingsplichtige> {
    private static final String TYPE_NIET_NATUURLIJKPERSOON = "niet_natuurlijkpersoon";

    @Override
    public Inhoudingsplichtige mapRow(final ResultSet resultSet, final int rownum) throws SQLException {
        final String id = resultSet.getString("ID");
        final String type = resultSet.getString("TYPE");

        if (type != null && type.equalsIgnoreCase(TYPE_NIET_NATUURLIJKPERSOON)) {
            return Inhoudingsplichtige.builder()
                    .rsin(id)
                    .build();
        }

        return Inhoudingsplichtige.builder()
                .bsn(id)
                .build();
    }
}
