package nl.uwv.cws.cwsihp.dao.mapper;

import nl.uwv.cws.common.util.NullValueUtil;
import nl.uwv.cws.cwsihp.model.hr.PersoonHr;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

@Component
public class PersoonHrRowMapper implements RowMapper<PersoonHr> {

    @Override
    public PersoonHr mapRow(final ResultSet resultSet, final int rownum) throws SQLException {
        final Long persoonId = resultSet.getLong("PERSOON_ID");
        final Long kvkNummer = resultSet.getLong("KVK_NUMMER");
        final Long naamPersoonId = NullValueUtil.getLongOrNull(resultSet, "NAAM_PERSOON_ID");
        final Long natuurlijkePersoonId = NullValueUtil.getLongOrNull(resultSet, "NATUURLIJKEPERSOON_ID");

        return PersoonHr.builder()
                .persoonId(persoonId)
                .kvkNummer(String.valueOf(kvkNummer))
                .naamPersoonId(naamPersoonId)
                .natuurlijkePersoonId(natuurlijkePersoonId)
                .build();
    }
}
