package nl.uwv.cws.cwsihp.model.configuratie;

import nl.uwv.cws.common.model.configuratie.BaseConfiguratieGroepenGegevens;

import java.util.List;

public class ConfiguratieGroepenGegevens extends BaseConfiguratieGroepenGegevens {

    public boolean requiresNietNatuurlijkPersoon() {
        return this.containsRequiredTable("UH_NIETNATUURLIJKPERSOON");
    }

    public boolean requiresRechtspersoon() {
        return this.containsRequiredTable("UH_RECHTSPERSOON");
    }

    public boolean requiresActiviteitHandelsregisterRechtspersoon() {
        return this.containsRequiredTable("UH_ACTIVITEITEN_RECHTSPRS_NNP");
    }

    public boolean requiresVennootschapBuitenland() {
        return this.containsRequiredTable("UH_BUITENLANDSE_VENNOOTSCHAP");
    }

    public boolean requiresNatuurlijkPersoon() {
        return this.containsRequiredTable("UH_NATUURLIJKPERSOON");
    }

    public boolean requiresHuwelijkGeregistreerdPartnerschap() {
        return this.containsRequiredTable("UH_NATUURLIJKPERSOON_HGP");
    }

    public boolean requiresPersoonHandelsregister() {
        return this.containsRequiredTable("UH_PERSOON_HR");
    }

    public boolean requiresRechtsvorm() {
        return this.containsRequiredTable("UH_RECHTSVORM");
    }

    public boolean requiresFaillissementSurseance() {
        return this.containsRequiredTable("WGA_FAIL_SURS");
    }

    public boolean requiresGemoedsbezwaardheid() {
        return this.containsRequiredTable("WGA_GEMOEDSBEZWAARDHEID");
    }

    public boolean requiresAdresNederlandPersoon() {
        return this.containsRequiredTable("UH_LOCATIE_PERSOON_NL");
    }

    public boolean requiresStraatadresNederlandPersoon() {
        return this.containsRequiredTable("UH_STRAATADRES_PERSOON_NL");
    }

    public boolean requiresPostbusadresNederlandPersoon() {
        return this.containsRequiredTable("UH_POSTBUSADRES_PERSOON_NL");
    }

    public boolean requiresAdresBuitenlandPersoon() {
        return this.containsRequiredTable("UH_LOCATIE_PERSOON_BL");
    }

    public boolean requiresStraatadresBuitenlandPersoon() {
        return this.containsRequiredTable("UH_STRAATADRES_PERSOON_BL");
    }

    public boolean requiresPostbusadresBuitenlandPersoon() {
        return this.containsRequiredTable("UH_POSTBUSADRES_PERSOON_BL");
    }

    public boolean requiresAdresBuitenlandOngestructureerdPersoon() {
        return this.containsRequiredTable("UH_LOCATIE_PERSOON_ONG_BL");
    }

    public boolean requiresMaatschappelijkeActiviteit() {
        return this.containsRequiredTable("UH_MAATSCHAPPELIJKE_ACTIVITEIT");
    }

    public boolean requiresSbiklasseMaatschappelijkeActiviteit() {
        return this.containsRequiredTable("UH_SBI_ACTIVITEIT_MAATSCH_ACT");
    }

    public boolean requiresVestigingHandelsregister() {
        return this.containsRequiredTable("UH_VESTIGING");
    }

    public boolean requiresAdresNederlandVestigingHandelsregister() {
        return this.containsRequiredTable("UH_LOCATIE_VESTIGING_NL");
    }

    public boolean requiresStraatadresNederlandVestigingHandelsregister() {
        return this.containsRequiredTable("UH_STRAATADRES_VESTIGING_NL");
    }

    public boolean requiresPostbusadresNederlandVestigingHandelsregister() {
        return this.containsRequiredTable("UH_POSTBUSADRES_VESTIGING_NL");
    }

    public boolean requiresAdresBuitenlandVestigingHandelsregister() {
        return this.containsRequiredTable("UH_LOCATIE_VESTIGING_BL");
    }

    public boolean requiresStraatadresBuitenlandVestigingHandelsregister() {
        return this.containsRequiredTable("UH_STRAATADRES_VESTIGING_BL");
    }

    public boolean requiresPostbusadresBuitenlandVestigingHandelsregister() {
        return this.containsRequiredTable("UH_POSTBUSADRES_VESTIGING_BL");
    }

    public boolean requiresAdresBuitenlandOngestructureerdVestigingHandelsregister() {
        return this.containsRequiredTable("UH_LOCATIE_VESTIGING_ONG_BL");
    }

    public boolean requiresActiviteitHandelsregisterVestigingHandelsregister() {
        return this.containsRequiredTable("UH_ACTIVITEITEN_VTG");
    }

    public boolean requiresSbiklasseActiviteitHandelsregister() {
        return this.containsRequiredTable("UH_SBI_ACTIVITEIT_VTG_ACT_HAND");
    }

    public boolean requiresOnderneming() {
        return this.containsRequiredTable("UH_ONDERNEMING_VTG");
    }
    
    public boolean requiresSbiklasseOnderneming() {
        return this.containsRequiredTable("UH_SBI_ACTIVITEIT_VTG_OND");
    }

    public boolean requiresHandelsnaamOnderneming() {
        return this.containsRequiredTable("UH_HANDELSNAAM_OND_VTG");
    }

    public boolean requiresHandelsnaamVestigingHandelsregister() {
        return this.containsRequiredTable("UH_HANDELSNAAM_VTG");
    }

    public boolean requiresAdministratieveEenheid() {
        return this.containsRequiredTable("WGA_AEH_HIS");
    }

    public boolean requiresSectorRisicogroep() {
        return this.containsRequiredTable("WGA_SECTOR_RISICOGRP_AEH");
    }

    public boolean requiresPremiepercentageIndividueel() {
        return this.containsRequiredTable("WGA_PREMIEPERC_INDIV");
    }

    public boolean requiresEigenRisicoDrager() {
        return this.containsRequiredTable("WGA_EIGEN_RISICO_DRAGER");
    }

    public boolean requiresAdresNederlandWg() {
        return this.containsRequiredTable("WGA_ADRES_NL");
    }

    public boolean requiresStraatadresNederlandWg() {
        return this.containsRequiredTable("WGA_STRAATADRES_NL");
    }

    public boolean requiresPostbusadresNederlandWg() {
        return this.containsRequiredTable("WGA_POSTBUSADRES_NL");
    }

    public boolean requiresAdresBuitenlandWg() {
        return this.containsRequiredTable("WGA_ADRES_BTL");
    }

    public boolean requiresStraatadresBuitenlandWg() {
        return this.containsRequiredTable("WGA_STRAATADRES_BTL");
    }

    public boolean requiresPostbusadresBuitenlandWg() {
        return this.containsRequiredTable("WGA_POSTBUSADRES_BTL");
    }

    public boolean requiresAdresBuitenlandOngestructureerdWg() {
        return this.containsRequiredTable("WGA_ADRES_ONG");
    }

    public boolean requiresVoortzettingsrelatieOpvolger() {
        return this.containsRequiredTable("WGA_VOORTZETTINGSRELATIE_OPV");
    }

    public boolean requiresVoortzettingsrelatieVoorganger() {
        return this.containsRequiredTable("WGA_VOORTZETTINGSRELATIE_VOOR");
    }

    public boolean requiresAangifteFrequentieAdministratieveEenheid() {
        return this.containsRequiredTable("WGA_AANGIFTEFREQUENTIE");
    }

    public boolean requiresAansluitingsnummerBv() {
        return this.containsRequiredTable("WGA_ASU");
    }

    public List<String> getRequiredColumnsNietNatuurlijkPersoon() {
        return getRequiredColumnsOfTable("UH_NIETNATUURLIJKPERSOON");
    }

    public List<String> getRequiredColumnsRechtspersoon() {
        return getRequiredColumnsOfTable("UH_RECHTSPERSOON");
    }

    public List<String> getRequiredColumnsActiviteitHandelsregisterRechtspersoon() {
        return getRequiredColumnsOfTable("UH_ACTIVITEITEN_RECHTSPRS_NNP");
    }

    public List<String> getRequiredColumnsVennootschapBuitenland() {
        return getRequiredColumnsOfTable("UH_BUITENLANDSE_VENNOOTSCHAP");
    }

    public List<String> getRequiredColumnsNatuurlijkPersoon() {
        return getRequiredColumnsOfTable("UH_NATUURLIJKPERSOON");
    }

    public List<String> getRequiredColumnsHuwelijkGeregistreerdPartnerschap() {
        return getRequiredColumnsOfTable("UH_NATUURLIJKPERSOON_HGP");
    }

    public List<String> getRequiredColumnsPersoonHandelsregister() {
        return getRequiredColumnsOfTable("UH_PERSOON_HR");
    }

    public List<String> getRequiredColumnsRechtsvorm() {
        return getRequiredColumnsOfTable("UH_RECHTSVORM");
    }

    public List<String> getRequiredColumnsFaillissementSurseance() {
        return getRequiredColumnsOfTable("WGA_FAIL_SURS");
    }

    public List<String> getRequiredColumnsGemoedsbezwaardheid() {
        return getRequiredColumnsOfTable("WGA_GEMOEDSBEZWAARDHEID");
    }

    public List<String> getRequiredColumnsAdresNederlandPersoon() {
        return getRequiredColumnsOfTable("UH_LOCATIE_PERSOON_NL");
    }

    public List<String> getRequiredColumnsStraatadresNederlandPersoon() {
        return getRequiredColumnsOfTable("UH_STRAATADRES_PERSOON_NL");
    }

    public List<String> getRequiredColumnsPostbusadresNederlandPersoon() {
        return getRequiredColumnsOfTable("UH_POSTBUSADRES_PERSOON_NL");
    }

    public List<String> getRequiredColumnsAdresBuitenlandPersoon() {
        return getRequiredColumnsOfTable("UH_LOCATIE_PERSOON_BL");
    }

    public List<String> getRequiredColumnsStraatadresBuitenlandPersoon() {
        return getRequiredColumnsOfTable("UH_STRAATADRES_PERSOON_BL");
    }

    public List<String> getRequiredColumnsPostbusadresBuitenlandPersoon() {
        return getRequiredColumnsOfTable("UH_POSTBUSADRES_PERSOON_BL");
    }

    public List<String> getRequiredColumnsAdresBuitenlandOngestructureerdPersoon() {
        return getRequiredColumnsOfTable("UH_LOCATIE_PERSOON_ONG_BL");
    }

    public List<String> getRequiredColumnsMaatschappelijkeActiviteit() {
        return getRequiredColumnsOfTable("UH_MAATSCHAPPELIJKE_ACTIVITEIT");
    }

    public List<String> getRequiredColumnsSbiklasseMaatschappelijkeActiviteit() {
        return getRequiredColumnsOfTable("UH_SBI_ACTIVITEIT_MAATSCH_ACT");
    }

    public List<String> getRequiredColumnsVestigingHandelsregister() {
        return getRequiredColumnsOfTable("UH_VESTIGING");
    }

    public List<String> getRequiredColumnsAdresNederlandVestigingHandelsregister() {
        return getRequiredColumnsOfTable("UH_LOCATIE_VESTIGING_NL");
    }

    public List<String> getRequiredColumnsStraatadresNederlandVestigingHandelsregister() {
        return getRequiredColumnsOfTable("UH_STRAATADRES_VESTIGING_NL");
    }

    public List<String> getRequiredColumnsPostbusadresNederlandVestigingHandelsregister() {
        return getRequiredColumnsOfTable("UH_POSTBUSADRES_VESTIGING_NL");
    }

    public List<String> getRequiredColumnsAdresBuitenlandVestigingHandelsregister() {
        return getRequiredColumnsOfTable("UH_LOCATIE_VESTIGING_BL");
    }

    public List<String> getRequiredColumnsStraatadresBuitenlandVestigingHandelsregister() {
        return getRequiredColumnsOfTable("UH_STRAATADRES_VESTIGING_BL");
    }

    public List<String> getRequiredColumnsPostbusadresBuitenlandVestigingHandelsregister() {
        return getRequiredColumnsOfTable("UH_POSTBUSADRES_VESTIGING_BL");
    }

    public List<String> getRequiredColumnsAdresBuitenlandOngestructureerdVestigingHandelsregister() {
        return getRequiredColumnsOfTable("UH_LOCATIE_VESTIGING_ONG_BL");
    }

    public List<String> getRequiredColumnsActiviteitHandelsregisterVestigingHandelsregister() {
        return getRequiredColumnsOfTable("UH_ACTIVITEITEN_VTG");
    }

    public List<String> getRequiredColumnsSbiklasseActiviteitHandelsregister() {
        return getRequiredColumnsOfTable("UH_SBI_ACTIVITEIT_VTG_ACT_HAND");
    }

    public List<String> getRequiredColumnsOnderneming() {
        return getRequiredColumnsOfTable("UH_ONDERNEMING_VTG");
    }

    public List<String> getRequiredColumnsSbiklasseOnderneming() {
        return getRequiredColumnsOfTable("UH_SBI_ACTIVITEIT_VTG_OND");
    }

    public List<String> getRequiredColumnsHandelsnaamOnderneming() {
        return getRequiredColumnsOfTable("UH_HANDELSNAAM_OND_VTG");
    }

    public List<String> getRequiredColumnsHandelsnaamVestigingHandelsregister() {
        return getRequiredColumnsOfTable("UH_HANDELSNAAM_VTG");
    }

    public List<String> getRequiredColumnsAdministratieveEenheid() {
        return getRequiredColumnsOfTable("WGA_AEH_HIS");
    }

    public List<String> getRequiredColumnsSectorRisicogroep() {
        return getRequiredColumnsOfTable("WGA_SECTOR_RISICOGRP_AEH");
    }

    public List<String> getRequiredColumnsPremiepercentageIndividueel() {
        return getRequiredColumnsOfTable("WGA_PREMIEPERC_INDIV");
    }

    public List<String> getRequiredColumnsEigenRisicoDrager() {
        return getRequiredColumnsOfTable("WGA_EIGEN_RISICO_DRAGER");
    }

    public List<String> getRequiredColumnsAdresNederlandWg() {
        return getRequiredColumnsOfTable("WGA_ADRES_NL");
    }

    public List<String> getRequiredColumnsStraatadresNederlandWg() {
        return getRequiredColumnsOfTable("WGA_STRAATADRES_NL");
    }

    public List<String> getRequiredColumnsPostbusadresNederlandWg() {
        return getRequiredColumnsOfTable("WGA_POSTBUSADRES_NL");
    }

    public List<String> getRequiredColumnsAdresBuitenlandWg() {
        return getRequiredColumnsOfTable("WGA_ADRES_BTL");
    }

    public List<String> getRequiredColumnsStraatadresBuitenlandWg() {
        return getRequiredColumnsOfTable("WGA_STRAATADRES_BTL");
    }

    public List<String> getRequiredColumnsPostbusadresBuitenlandWg() {
        return getRequiredColumnsOfTable("WGA_POSTBUSADRES_BTL");
    }

    public List<String> getRequiredColumnsAdresBuitenlandOngestructureerdWg() {
        return getRequiredColumnsOfTable("WGA_ADRES_ONG");
    }

    public List<String> getRequiredColumnsVoortzettingsrelatieOpvolger() {
        return getRequiredColumnsOfTable("WGA_VOORTZETTINGSRELATIE_OPV");
    }

    public List<String> getRequiredColumnsVoortzettingsrelatieVoorganger() {
        return getRequiredColumnsOfTable("WGA_VOORTZETTINGSRELATIE_VOOR");
    }

    public List<String> getRequiredColumnsAangifteFrequentieAdministratieveEenheid() {
        return getRequiredColumnsOfTable("WGA_AANGIFTEFREQUENTIE");
    }

    public List<String> getRequiredColumnsAansluitingsnummerBv() {
        return getRequiredColumnsOfTable("WGA_ASU");
    }
}
