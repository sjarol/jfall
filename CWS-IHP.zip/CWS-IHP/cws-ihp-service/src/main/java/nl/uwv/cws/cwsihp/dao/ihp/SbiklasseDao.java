package nl.uwv.cws.cwsihp.dao.ihp;

import nl.uwv.cws.cwsihp.dao.mapper.SbiklasseHrRowMapper;
import nl.uwv.cws.cwsihp.model.configuratie.CwsIhpConfiguratie;
import nl.uwv.cws.cwsihp.model.hr.SbiklasseHr;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

import static nl.uwv.cws.common.model.CwsCommonConstants.BESCHOUWINGSMOMENT;
import static nl.uwv.cws.common.model.CwsCommonConstants.KVK_NUMMER;

@Repository
public class SbiklasseDao extends BaseDao {

    @Autowired
    private SbiklasseHrRowMapper sbiklasseHrRowMapper;

    private static final String SBI_EXCLUSION = "sbi.code_sbi_cgm >= 0 ";

    private static final String SBI_COLUMNS = "sbi.code_sbi_cgm, " +
            "sbi.omschrijving_sbicode, " +
            "sbi.ishoofdactiviteit, " +
            "sbi.datum_aanvang_cgm, " +
            "sbi.cd_datum_aanvang_cgm, " +
            "sbi.datum_einde_cgm,  " +
            "sbi.cd_datum_einde_cgm ";

    public List<SbiklasseHr> findSbiklasseMaatschappelijkeActiviteit(final String kvkNummer, final LocalDateTime beschouwingsmoment, final CwsIhpConfiguratie cwsIhpConfiguratie) {
        final String sql = "SELECT " +
                SBI_COLUMNS +
                "FROM uh_sbi_activiteit_maatsch_act sbi_maa INNER JOIN uh_sbi_activiteit sbi ON (sbi_maa.sbi_act_id = sbi.sbi_act_id) " +
                "WHERE sbi_maa.kvk_nummer = :kvkNummer " +
                "AND " + SBI_EXCLUSION +
                "AND sbi_maa.his_ts_in <= :beschouwingsmoment " +
                "AND sbi_maa.his_ts_end > :beschouwingsmoment " +
                "AND sbi.his_ts_in <= :beschouwingsmoment " +
                "AND sbi.his_ts_end > :beschouwingsmoment";

        Timestamp beschouwingsmomentTimestamp = Timestamp.valueOf(beschouwingsmoment);
        SqlParameterSource namedParameters = new MapSqlParameterSource()
                .addValue(KVK_NUMMER, kvkNummer)
                .addValue(BESCHOUWINGSMOMENT, beschouwingsmomentTimestamp);

        List<String> attributen = cwsIhpConfiguratie.getGroepenGegevens().getRequiredColumnsSbiklasseMaatschappelijkeActiviteit();
        return jdbcTemplate.query(sql, namedParameters, (resultSet, i) -> sbiklasseHrRowMapper.mapRow(resultSet, attributen));
    }

    public List<SbiklasseHr> findSbiklasseActiviteitHandelsregister(final Long activiteitHandelsregisterId, final LocalDateTime beschouwingsmoment, final CwsIhpConfiguratie cwsIhpConfiguratie) {
        final String sql = "SELECT " +
                SBI_COLUMNS +
                "FROM uh_kopp_activiteit_sbi_act kop_act INNER JOIN uh_sbi_activiteit sbi ON (kop_act.sbi_act_id = sbi.sbi_act_id) " +
                "WHERE kop_act.activiteit_id = :activiteitHandelsregisterId " +
                "AND " + SBI_EXCLUSION +
                "AND kop_act.his_ts_in <= :beschouwingsmoment " +
                "AND kop_act.his_ts_end > :beschouwingsmoment " +
                "AND sbi.his_ts_in <= :beschouwingsmoment " +
                "AND sbi.his_ts_end > :beschouwingsmoment";

        Timestamp beschouwingsmomentTimestamp = Timestamp.valueOf(beschouwingsmoment);
        SqlParameterSource namedParameters = new MapSqlParameterSource()
                .addValue("activiteitHandelsregisterId", activiteitHandelsregisterId)
                .addValue(BESCHOUWINGSMOMENT, beschouwingsmomentTimestamp);

        List<String> attributen = cwsIhpConfiguratie.getGroepenGegevens().getRequiredColumnsSbiklasseActiviteitHandelsregister();
        return jdbcTemplate.query(sql, namedParameters, (resultSet, i) -> sbiklasseHrRowMapper.mapRow(resultSet, attributen));
    }

    public List<SbiklasseHr> findSbiklasseOnderneming(final String kvkNummer, final LocalDateTime beschouwingsmoment, final CwsIhpConfiguratie cwsIhpConfiguratie) {
        final String sql = "SELECT " +
                SBI_COLUMNS +
                "FROM uh_sbi_activiteit_onderneming act_ond LEFT JOIN uh_sbi_activiteit sbi ON (act_ond.sbi_act_id = sbi.sbi_act_id) " +
                "WHERE act_ond.kvk_nummer = :kvkNummer " +
                "AND " + SBI_EXCLUSION +
                "AND act_ond.his_ts_in <= :beschouwingsmoment " +
                "AND act_ond.his_ts_end > :beschouwingsmoment " +
                "AND sbi.his_ts_in <= :beschouwingsmoment " +
                "AND sbi.his_ts_end > :beschouwingsmoment";

        Timestamp beschouwingsmomentTimestamp = Timestamp.valueOf(beschouwingsmoment);
        SqlParameterSource namedParameters = new MapSqlParameterSource()
                .addValue(KVK_NUMMER, kvkNummer)
                .addValue(BESCHOUWINGSMOMENT, beschouwingsmomentTimestamp);

        List<String> attributen = cwsIhpConfiguratie.getGroepenGegevens().getRequiredColumnsSbiklasseOnderneming();
        return jdbcTemplate.query(sql, namedParameters, (resultSet, i) -> sbiklasseHrRowMapper.mapRow(resultSet, attributen));
    }
}
