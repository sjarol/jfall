package nl.uwv.cws.cwsihp.model.wg;

import lombok.Builder;
import lombok.Getter;

@Builder
@Getter
public class AangifteFrequentieAdministratieveEenheidWg {
    private String codeAangifteFrequentieAdministratieveEenheid;
    private Long datumAanvangAangifteFrequentieAdministratieveEenheid;
    private Long datumEindeAangifteFrequentieAdministratieveEenheid;
}
