package nl.uwv.cws.cwsihp.webservice.mapper;

import nl.uwv.cws.common.VisibleForTesting;
import nl.uwv.cws.cwsihp.model.hr.RechtsvormHr;
import nl.uwv.cws.cwsihp.model.wg.RechtsvormWg;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0007.CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Rechtsvorm;
import org.springframework.stereotype.Component;

import java.sql.Date;

import static nl.uwv.cws.common.util.MapperUtil.collectNonEmptyObject;
import static nl.uwv.cws.common.util.NullValueUtil.extractStringFromDateValueOrNull;
import static nl.uwv.cws.common.util.NullValueUtil.extractStringValueOrNull;
import static nl.uwv.cws.cwsihp.model.CwsIhpConstants.*;

@Component
public class RechtsvormMapper extends BaseMapper {

    @VisibleForTesting
    protected Rechtsvorm mapToJaxbRechtsvormHr(RechtsvormHr rechtsvormHr) {
        Rechtsvorm rechtsvorm = new Rechtsvorm();

        final String codeRechtsvorm = rechtsvormHr.getCodeRechtsvorm();
        final Date datumAanvangRechtsvorm = rechtsvormHr.getDatumAanvangRechtsvorm();
        Integer codeFictieveDatumAanvang = null;
        if (datumAanvangRechtsvorm != null) {
            codeFictieveDatumAanvang = rechtsvormHr.getCodeFictieveDatumAanvang();
        }
        final Date datumEindeRechtsvorm = rechtsvormHr.getDatumEindeRechtsvorm();
        Integer codeFictieveDatumEinde = null;
        if (datumEindeRechtsvorm != null) {
            codeFictieveDatumEinde = rechtsvormHr.getCodeFictieveDatumEinde();
        }

        ruleExecutor.setTransformedValue(rechtsvorm, XSD_CDRECHTSVORM, codeRechtsvorm);
        ruleExecutor.setTransformedValue(rechtsvorm, XSD_DATBRECHTSVORM, extractStringFromDateValueOrNull(datumAanvangRechtsvorm));
        ruleExecutor.setTransformedValue(rechtsvorm, XSD_CDFICTIEVEDATB, extractStringValueOrNull(codeFictieveDatumAanvang));
        ruleExecutor.setTransformedValue(rechtsvorm, XSD_DATERECHTSVORM, extractStringFromDateValueOrNull(datumEindeRechtsvorm));
        ruleExecutor.setTransformedValue(rechtsvorm, XSD_CDFICTIEVEDATE, extractStringValueOrNull(codeFictieveDatumEinde));

        return collectNonEmptyObject(rechtsvorm);
    }

    @VisibleForTesting
    protected Rechtsvorm mapToJaxbRechtsvormWg(RechtsvormWg rechtsvormWg) {
        Rechtsvorm rechtsvorm = new Rechtsvorm();

        final String codeRechtsvorm = rechtsvormWg.getCodeRechtsvorm();
        final Long datumAanvangRechtsvorm = rechtsvormWg.getDatumAanvangRechtsvorm();
        Integer codeFictieveDatumAanvang = null;
        if (datumAanvangRechtsvorm != null) {
            codeFictieveDatumAanvang = 0;
        }
        final Long datumEindeRechtsvorm = rechtsvormWg.getDatumEindeRechtsvorm();
        Integer codeFictieveDatumEinde = null;
        if (datumEindeRechtsvorm != null) {
            codeFictieveDatumEinde = 0;
        }

        ruleExecutor.setTransformedValue(rechtsvorm, XSD_CDRECHTSVORM, codeRechtsvorm);
        ruleExecutor.setTransformedValue(rechtsvorm, XSD_DATBRECHTSVORM, extractStringValueOrNull(datumAanvangRechtsvorm));
        ruleExecutor.setTransformedValue(rechtsvorm, XSD_CDFICTIEVEDATB, extractStringValueOrNull(codeFictieveDatumAanvang));
        ruleExecutor.setTransformedValue(rechtsvorm, XSD_DATERECHTSVORM, extractStringValueOrNull(datumEindeRechtsvorm));
        ruleExecutor.setTransformedValue(rechtsvorm, XSD_CDFICTIEVEDATE, extractStringValueOrNull(codeFictieveDatumEinde));

        return collectNonEmptyObject(rechtsvorm);
    }
}
