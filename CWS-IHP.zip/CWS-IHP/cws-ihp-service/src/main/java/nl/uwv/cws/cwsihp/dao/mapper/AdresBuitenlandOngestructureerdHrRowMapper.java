package nl.uwv.cws.cwsihp.dao.mapper;

import nl.uwv.cws.common.dao.mapper.CwsRowMapper;
import nl.uwv.cws.cwsihp.model.hr.AdresBuitenlandOngestructureerdHr;
import org.springframework.stereotype.Component;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

import static nl.uwv.cws.cwsihp.util.DateUtil.setDatumEinde;

@Component
public class AdresBuitenlandOngestructureerdHrRowMapper extends CwsRowMapper<AdresBuitenlandOngestructureerdHr> {

    @Override
    public AdresBuitenlandOngestructureerdHr mapRow(final ResultSet resultSet, final List<String> attributen) throws SQLException {

       // ADRES BUITENLAND ONGESTRUCTUREERD
        final String codeAdresrolCgm = readApplicableString(attributen, "CODE_ADRESROL_CGM", resultSet);
        final Date datumAanvangAdreshouding = readApplicableDate(attributen, "DATUM_AANVANG_CGM", resultSet);
        final Integer codeFictieveDatumAanvang = readApplicableNullableInteger(attributen, "CD_DATUM_AANVANG_CGM", resultSet);
        final Date datumEindeAdreshouding = setDatumEinde(readApplicableDate(attributen, "DATUM_EINDE_CGM", resultSet), resultSet.getInt("CD_DATUM_EINDE_CGM"));
        final Integer codeFictieveDatumEinde = readApplicableNullableInteger(attributen, "CD_DATUM_EINDE_CGM", resultSet);
        final Integer codeAfgeschermdAdres = readApplicableNullableInteger(attributen, "IND_AFGESCHERMD_ADRES_CGM", resultSet);

        final boolean isAdresActief = resultSet.getDate("DATUM_EINDE_CGM").after(Timestamp.valueOf(LocalDateTime.now()));

        String adresregel1Buitenland = readApplicableString(attributen, "ADRESREGEL_1_BUITENLAND_CGM", resultSet);
        String adresregel2Buitenland = readApplicableString(attributen, "ADRESREGEL_2_BUITENLAND_CGM", resultSet);
        String adresregel3Buitenland = readApplicableString(attributen, "ADRESREGEL_3_BUITENLAND_CGM", resultSet);
        Integer landcodeGba = readApplicableNullableInteger(attributen, "LANDCODE_GBA_CGM", resultSet);
        String landsnaamGba = readApplicableString(attributen, "LANDSNAAM_GBA_CGM", resultSet);
        String landcodeIso = readApplicableString(attributen, "LANDCODE_ISO_CGM", resultSet);
        String landsnaam = readApplicableString(attributen, "LANDSNAAM_CGM", resultSet);

        return AdresBuitenlandOngestructureerdHr.builder().codeAdresrol(codeAdresrolCgm)
                .datumAanvangAdreshouding(datumAanvangAdreshouding)
                .codeFictieveDatumAanvang(codeFictieveDatumAanvang)
                .datumEindeAdreshouding(datumEindeAdreshouding)
                .codeFictieveDatumEinde(codeFictieveDatumEinde)
                .codeAfgeschermdAdres(codeAfgeschermdAdres)
                .adresregel1Buitenland(adresregel1Buitenland)
                .adresregel2Buitenland(adresregel2Buitenland)
                .adresregel3Buitenland(adresregel3Buitenland)
                .landcodeGba(landcodeGba)
                .landsnaamGba(landsnaamGba)
                .landcodeIso(landcodeIso)
                .isAdresActief(isAdresActief)
                .landsnaam(landsnaam).build();
    }
}
