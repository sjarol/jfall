package nl.uwv.cws.cwsihp.model.wg;

import lombok.Builder;
import lombok.Getter;

@Builder
@Getter
public class GemoedsbezwaardheidWg {
    private String codeSzProduct;
    private Long datumAanvangGemoedsbezwaardheid;
    private Long datumEindeGemoedsbezwaardheid;
}
