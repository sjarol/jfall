package nl.uwv.cws.cwsihp.webservice.rule.transformer;

import nl.uwv.cws.common.model.rule.AttributeRuleProperties;
import nl.uwv.cws.common.webservice.rule.transformer.RuleValueTransformer;
import nl.uwv.cws.cwsihp.model.rule.CwsIhpAttributeRule;
import org.springframework.stereotype.Component;

import java.math.BigInteger;

import static nl.uwv.cws.cwsihp.model.rule.CwsIhpAttributeRule.NUMMER_TUSSEN_1_EN_99999_OF_NULL;

@Component
public class NummerTussen1En99999OfNullTransformer implements RuleValueTransformer<String, BigInteger> {
    private static final int MINIMUM = 1;
    private static final int MAXIMUM = 99999;

    @Override
    public CwsIhpAttributeRule getTransformRule() {
        return NUMMER_TUSSEN_1_EN_99999_OF_NULL;
    }

    @Override
    public BigInteger transform(String originalValue, AttributeRuleProperties attributeRuleProperties) {
        try {
            if (originalValue != null) {
                BigInteger huisnummer = new BigInteger(originalValue);
                if (huisnummer.intValue() >= MINIMUM && huisnummer.intValue() <= MAXIMUM) {
                    return huisnummer;
                } else {
                    return null;
                }
            } else {
                return null;
            }
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
