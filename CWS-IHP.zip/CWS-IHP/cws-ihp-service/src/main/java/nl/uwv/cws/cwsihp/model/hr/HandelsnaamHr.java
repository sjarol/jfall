package nl.uwv.cws.cwsihp.model.hr;

import lombok.Builder;
import lombok.Getter;

import java.sql.Date;

@Getter
@Builder
public class HandelsnaamHr {
    private String naam;
    private Integer volgorde;
    private Date datumAanvangHandelsnaam;
    private Integer codeFictieveDatumAanvang;
    private Date datumEindeHandelsnaam;
    private Integer codeFictieveDatumEinde;
}
