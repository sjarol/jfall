package nl.uwv.cws.cwsihp.webservice.mapper;

import nl.uwv.cws.cwsihp.model.hr.*;
import nl.uwv.cws.cwsihp.model.wg.*;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0007.CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0007.CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0007.CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister;
import org.springframework.stereotype.Component;

import java.sql.Date;

import static nl.uwv.cws.common.util.MapperUtil.collectNonEmptyObject;
import static nl.uwv.cws.common.util.NullValueUtil.*;
import static nl.uwv.cws.cwsihp.model.CwsIhpConstants.*;

@Component
public class AdreshoudingMapper extends BaseMapper {

    public PersoonInhoudingsplichtige.Adreshouding mapToJaxbAdresNederlandUhrPersoon(AdresNederlandHr adresNederlandHr) {
        PersoonInhoudingsplichtige.Adreshouding adres = new PersoonInhoudingsplichtige.Adreshouding();
        PersoonInhoudingsplichtige.Adreshouding.AdresNederlandUhr adresNederland = new PersoonInhoudingsplichtige.Adreshouding.AdresNederlandUhr();
        mapToJaxbAdresNederlandUhr(adresNederlandHr, adresNederland);

        PersoonInhoudingsplichtige.Adreshouding.AdresNederlandUhr.StraatadresUhr straatadres = mapToJaxbStraatadresUhrAdresNederlandUhrPersoon(adresNederlandHr.getStraatadresHr());
        PersoonInhoudingsplichtige.Adreshouding.AdresNederlandUhr.PostbusadresUhr postbusadres = mapToJaxbPostbusadresAdresNederlandUhrPersoon(adresNederlandHr.getPostbusadresHr());

        if (straatadres != null || postbusadres != null) {
            adresNederland.setStraatadresUhr(straatadres);
            adresNederland.setPostbusadresUhr(postbusadres);
            adres.setAdresNederlandUhr(adresNederland);
        }

        return collectNonEmptyObject(adres);
    }

    private PersoonInhoudingsplichtige.Adreshouding.AdresNederlandUhr.StraatadresUhr mapToJaxbStraatadresUhrAdresNederlandUhrPersoon(AdresNederlandStraatadresHr straatadresHr) {
        PersoonInhoudingsplichtige.Adreshouding.AdresNederlandUhr.StraatadresUhr straatadres = new PersoonInhoudingsplichtige.Adreshouding.AdresNederlandUhr.StraatadresUhr();
        mapToJaxbStraatadresUhrAdresNederlandUhr(straatadresHr, straatadres);
        return collectNonEmptyObject(straatadres);
    }

    private PersoonInhoudingsplichtige.Adreshouding.AdresNederlandUhr.PostbusadresUhr mapToJaxbPostbusadresAdresNederlandUhrPersoon(AdresNederlandPostbusadresHr postbusadresHr) {
        PersoonInhoudingsplichtige.Adreshouding.AdresNederlandUhr.PostbusadresUhr postbusadres = new PersoonInhoudingsplichtige.Adreshouding.AdresNederlandUhr.PostbusadresUhr();
        mapToJaxbPostbusadresAdresNederlandUhr(postbusadresHr, postbusadres);
        return collectNonEmptyObject(postbusadres);
    }

    public VestigingHandelsregister.Adreshouding mapToJaxbAdresNederlandUhrVestigingHandelsregister(AdresNederlandHr adresNederlandHr) {
        VestigingHandelsregister.Adreshouding adres = new VestigingHandelsregister.Adreshouding();
        VestigingHandelsregister.Adreshouding.AdresNederlandUhr adresNederland = new VestigingHandelsregister.Adreshouding.AdresNederlandUhr();
        mapToJaxbAdresNederlandUhr(adresNederlandHr, adresNederland);

        VestigingHandelsregister.Adreshouding.AdresNederlandUhr.StraatadresUhr straatadres = mapToJaxbStraatadresUhrAdresNederlandUhrVestigingHandelsregister(adresNederlandHr.getStraatadresHr());
        VestigingHandelsregister.Adreshouding.AdresNederlandUhr.PostbusadresUhr postbusadres = mapToJaxbPostbusadresAdresNederlandUhrVestigingHandelsregister(adresNederlandHr.getPostbusadresHr());

        if (straatadres != null || postbusadres != null) {
            adresNederland.setStraatadresUhr(straatadres);
            adresNederland.setPostbusadresUhr(postbusadres);
            adres.setAdresNederlandUhr(adresNederland);
        }

        return collectNonEmptyObject(adres);
    }

    private VestigingHandelsregister.Adreshouding.AdresNederlandUhr.StraatadresUhr mapToJaxbStraatadresUhrAdresNederlandUhrVestigingHandelsregister(AdresNederlandStraatadresHr straatadresHr) {
        VestigingHandelsregister.Adreshouding.AdresNederlandUhr.StraatadresUhr straatadres = new VestigingHandelsregister.Adreshouding.AdresNederlandUhr.StraatadresUhr();
        mapToJaxbStraatadresUhrAdresNederlandUhr(straatadresHr, straatadres);
        return collectNonEmptyObject(straatadres);
    }

    private VestigingHandelsregister.Adreshouding.AdresNederlandUhr.PostbusadresUhr mapToJaxbPostbusadresAdresNederlandUhrVestigingHandelsregister(AdresNederlandPostbusadresHr postbusadresHr) {
        VestigingHandelsregister.Adreshouding.AdresNederlandUhr.PostbusadresUhr postbusadres = new VestigingHandelsregister.Adreshouding.AdresNederlandUhr.PostbusadresUhr();
        mapToJaxbPostbusadresAdresNederlandUhr(postbusadresHr, postbusadres);
        return collectNonEmptyObject(postbusadres);
    }

    private void mapToJaxbAdresNederlandUhr(AdresNederlandHr adresNederlandHr, Object adresNederland) {
        final String codeAdresrol = adresNederlandHr.getCodeAdresrol();
        final Date datumAanvangAdreshouding = adresNederlandHr.getDatumAanvangAdreshouding();
        Integer codeFictieveDatumAanvang = null;
        if (datumAanvangAdreshouding != null) {
            codeFictieveDatumAanvang = adresNederlandHr.getCodeFictieveDatumAanvang();
        }

        Date datumEindeAdreshouding = adresNederlandHr.getDatumEindeAdreshouding();
        Integer codeFictieveDatumEinde = null;
        if (datumEindeAdreshouding != null) {
            codeFictieveDatumEinde = adresNederlandHr.getCodeFictieveDatumEinde();
        }
        final Integer codeAfgeschermdAdres = adresNederlandHr.getCodeAfgeschermdAdres();

        ruleExecutor.setTransformedValue(adresNederland, XSD_CDADRESROL, codeAdresrol);
        ruleExecutor.setTransformedValue(adresNederland, XSD_DATBADRESHOUDING, extractStringFromDateValueOrNull(datumAanvangAdreshouding));
        ruleExecutor.setTransformedValue(adresNederland, XSD_CDFICTIEVEDATB, extractStringValueOrNull(codeFictieveDatumAanvang));
        ruleExecutor.setTransformedValue(adresNederland, XSD_DATEADRESHOUDING, extractStringFromDateValueOrNull(datumEindeAdreshouding));
        ruleExecutor.setTransformedValue(adresNederland, XSD_CDFICTIEVEDATE, extractStringValueOrNull(codeFictieveDatumEinde));
        ruleExecutor.setTransformedValue(adresNederland, XSD_CDAFGESCHERMDADRES, extractStringValueOrNull(codeAfgeschermdAdres));
    }

    private void mapToJaxbStraatadresUhrAdresNederlandUhr(AdresNederlandStraatadresHr straatadresHr, Object straatadres) {
        final String postcode = straatadresHr.getPostcode();
        final String woonplaatsnaam = straatadresHr.getWoonplaatsnaam();
        final String straatnaam = straatadresHr.getStraatnaam();
        final Integer huisnummer = straatadresHr.getHuisnummer();
        final String huisletter = straatadresHr.getHuisletter();
        final String huisnummertoevoeging = straatadresHr.getHuisnummertoevoeging();
        final String codeAanduidingBijHuisnummer = straatadresHr.getCodeAanduidingBijHuisnummer();
        final String naamOpenbareRuimte = straatadresHr.getNaamOpenbareRuimte();

        ruleExecutor.setTransformedValue(straatadres, XSD_POSTCD, postcode);
        ruleExecutor.setTransformedValue(straatadres, XSD_WOONPLAATSNAAM, woonplaatsnaam);
        ruleExecutor.setTransformedValue(straatadres, XSD_STRAATNAAM, straatnaam);
        ruleExecutor.setTransformedValue(straatadres, XSD_HUISNR, extractBigIntegerValueOrNull(huisnummer));
        ruleExecutor.setTransformedValue(straatadres, XSD_HUISLETTER, huisletter);
        ruleExecutor.setTransformedValue(straatadres, XSD_HUISNRTOEVOEGING, huisnummertoevoeging);
        ruleExecutor.setTransformedValue(straatadres, XSD_CDAANDUIDINGBIJHUISNR, codeAanduidingBijHuisnummer);
        ruleExecutor.setTransformedValue(straatadres, XSD_NAAMOPENBARERUIMTE, naamOpenbareRuimte);
    }

    private void mapToJaxbPostbusadresAdresNederlandUhr(AdresNederlandPostbusadresHr postbusadresHr, Object postbusadres) {
        final String postcode = postbusadresHr.getPostcode();
        final String woonplaatsnaam = postbusadresHr.getWoonplaatsnaam();
        final Integer postbusnummer = postbusadresHr.getPostbusnummer();

        ruleExecutor.setTransformedValue(postbusadres, XSD_POSTCD, postcode);
        ruleExecutor.setTransformedValue(postbusadres, XSD_WOONPLAATSNAAM, woonplaatsnaam);
        ruleExecutor.setTransformedValue(postbusadres, XSD_POSTBUSNR, extractBigIntegerValueOrNull(postbusnummer));
    }

    public PersoonInhoudingsplichtige.Adreshouding mapToJaxbAdresBuitenlandPersoon(AdresBuitenlandHr adresBuitenlandHr) {
        PersoonInhoudingsplichtige.Adreshouding adres = new PersoonInhoudingsplichtige.Adreshouding();
        PersoonInhoudingsplichtige.Adreshouding.AdresBuitenlandUhr adresBuitenland = new PersoonInhoudingsplichtige.Adreshouding.AdresBuitenlandUhr();
        mapToJaxbAdresBuitenland(adresBuitenlandHr, adresBuitenland);

        PersoonInhoudingsplichtige.Adreshouding.AdresBuitenlandUhr.StraatadresBuitenlandUhr straatadres = mapToJaxbStraatadresUhrAdresBuitenlandPersoon(adresBuitenlandHr.getStraatadresHr());
        PersoonInhoudingsplichtige.Adreshouding.AdresBuitenlandUhr.PostbusadresBuitenlandUhr postbusadres = mapToJaxbPostbusadresAdresBuitenlandPersoon(adresBuitenlandHr.getPostbusadresHr());

        if (straatadres != null || postbusadres != null) {
            adresBuitenland.setStraatadresBuitenlandUhr(straatadres);
            adresBuitenland.setPostbusadresBuitenlandUhr(postbusadres);
            adres.setAdresBuitenlandUhr(adresBuitenland);
        }

        return collectNonEmptyObject(adres);
    }

    private PersoonInhoudingsplichtige.Adreshouding.AdresBuitenlandUhr.StraatadresBuitenlandUhr mapToJaxbStraatadresUhrAdresBuitenlandPersoon(AdresBuitenlandStraatadresHr straatadresHr) {
        PersoonInhoudingsplichtige.Adreshouding.AdresBuitenlandUhr.StraatadresBuitenlandUhr straatadres = new PersoonInhoudingsplichtige.Adreshouding.AdresBuitenlandUhr.StraatadresBuitenlandUhr();
        mapToJaxbStraatadresUhrAdresBuitenland(straatadresHr, straatadres);
        return collectNonEmptyObject(straatadres);
    }

    private PersoonInhoudingsplichtige.Adreshouding.AdresBuitenlandUhr.PostbusadresBuitenlandUhr mapToJaxbPostbusadresAdresBuitenlandPersoon(AdresBuitenlandPostbusadresHr postbusadresHr) {
        PersoonInhoudingsplichtige.Adreshouding.AdresBuitenlandUhr.PostbusadresBuitenlandUhr postbusadres = new PersoonInhoudingsplichtige.Adreshouding.AdresBuitenlandUhr.PostbusadresBuitenlandUhr();
        mapToJaxbPostbusadresAdresBuitenland(postbusadresHr, postbusadres);
        return collectNonEmptyObject(postbusadres);
    }

    public VestigingHandelsregister.Adreshouding mapToJaxbAdresBuitenlandVestigingHandelsregister(AdresBuitenlandHr adresBuitenlandHr) {
        VestigingHandelsregister.Adreshouding adres = new VestigingHandelsregister.Adreshouding();
        VestigingHandelsregister.Adreshouding.AdresBuitenlandUhr adresBuitenland = new VestigingHandelsregister.Adreshouding.AdresBuitenlandUhr();
        mapToJaxbAdresBuitenland(adresBuitenlandHr, adresBuitenland);

        VestigingHandelsregister.Adreshouding.AdresBuitenlandUhr.StraatadresBuitenlandUhr straatadres = mapToJaxbStraatadresUhrAdresBuitenlandVestigingHandelsregister(adresBuitenlandHr.getStraatadresHr());
        VestigingHandelsregister.Adreshouding.AdresBuitenlandUhr.PostbusadresBuitenlandUhr postbusadres = mapToJaxbPostbusadresAdresBuitenlandVestigingHandelsregister(adresBuitenlandHr.getPostbusadresHr());

        if (straatadres != null || postbusadres != null) {
            adresBuitenland.setStraatadresBuitenlandUhr(straatadres);
            adresBuitenland.setPostbusadresBuitenlandUhr(postbusadres);
            adres.setAdresBuitenlandUhr(adresBuitenland);
        }

        return collectNonEmptyObject(adres);
    }

    private VestigingHandelsregister.Adreshouding.AdresBuitenlandUhr.StraatadresBuitenlandUhr mapToJaxbStraatadresUhrAdresBuitenlandVestigingHandelsregister(AdresBuitenlandStraatadresHr straatadresHr) {
        VestigingHandelsregister.Adreshouding.AdresBuitenlandUhr.StraatadresBuitenlandUhr straatadres = new VestigingHandelsregister.Adreshouding.AdresBuitenlandUhr.StraatadresBuitenlandUhr();
        mapToJaxbStraatadresUhrAdresBuitenland(straatadresHr, straatadres);
        return collectNonEmptyObject(straatadres);
    }

    private VestigingHandelsregister.Adreshouding.AdresBuitenlandUhr.PostbusadresBuitenlandUhr mapToJaxbPostbusadresAdresBuitenlandVestigingHandelsregister(AdresBuitenlandPostbusadresHr postbusadresHr) {
        VestigingHandelsregister.Adreshouding.AdresBuitenlandUhr.PostbusadresBuitenlandUhr postbusadres = new VestigingHandelsregister.Adreshouding.AdresBuitenlandUhr.PostbusadresBuitenlandUhr();
        mapToJaxbPostbusadresAdresBuitenland(postbusadresHr, postbusadres);
        return collectNonEmptyObject(postbusadres);
    }

    private void mapToJaxbAdresBuitenland(AdresBuitenlandHr adresBuitenlandHr, Object adresBuitenland) {
        final String codeAdresrol = adresBuitenlandHr.getCodeAdresrol();
        final Date datumAanvangAdreshouding = adresBuitenlandHr.getDatumAanvangAdreshouding();
        Integer codeFictieveDatumAanvang = null;
        if (datumAanvangAdreshouding != null) {
            codeFictieveDatumAanvang = adresBuitenlandHr.getCodeFictieveDatumAanvang();
        }

        Date datumEindeAdreshouding = adresBuitenlandHr.getDatumEindeAdreshouding();
        Integer codeFictieveDatumEinde = null;
        if (datumEindeAdreshouding != null) {
            codeFictieveDatumEinde = adresBuitenlandHr.getCodeFictieveDatumEinde();
        }
        final Integer codeAfgeschermdAdres = adresBuitenlandHr.getCodeAfgeschermdAdres();

        ruleExecutor.setTransformedValue(adresBuitenland, XSD_CDADRESROL, codeAdresrol);
        ruleExecutor.setTransformedValue(adresBuitenland, XSD_DATBADRESHOUDING, extractStringFromDateValueOrNull(datumAanvangAdreshouding));
        ruleExecutor.setTransformedValue(adresBuitenland, XSD_CDFICTIEVEDATB, extractStringValueOrNull(codeFictieveDatumAanvang));
        ruleExecutor.setTransformedValue(adresBuitenland, XSD_DATEADRESHOUDING, extractStringFromDateValueOrNull(datumEindeAdreshouding));
        ruleExecutor.setTransformedValue(adresBuitenland, XSD_CDFICTIEVEDATE, extractStringValueOrNull(codeFictieveDatumEinde));
        ruleExecutor.setTransformedValue(adresBuitenland, XSD_CDAFGESCHERMDADRES, extractStringValueOrNull(codeAfgeschermdAdres));
    }

    private void mapToJaxbStraatadresUhrAdresBuitenland(AdresBuitenlandStraatadresHr straatadresHr, Object straatadres) {
        final String postcode = straatadresHr.getPostcodeBuitenland();
        final String woonplaatsnaam = straatadresHr.getWoonplaatsnaamBuitenland();
        final String straatnaam = straatadresHr.getStraatnaamBuitenland();
        final String huisnummer = straatadresHr.getHuisnummerBuitenland();
        final String locatieomschrijving = straatadresHr.getLocatieomschrijvingBuitenland();
        final String regionaam = straatadresHr.getRegionaamBuitenland();
        final Integer landcodeGba = straatadresHr.getLandcodeGba();
        final String landcodeIso = straatadresHr.getLandcodeIso();
        final String landsnaam = straatadresHr.getLandsnaam();

        ruleExecutor.setTransformedValue(straatadres, XSD_POSTCDBUITENLAND, postcode);
        ruleExecutor.setTransformedValue(straatadres, XSD_WOONPLAATSNAAMBUITENLAND, woonplaatsnaam);
        ruleExecutor.setTransformedValue(straatadres, XSD_STRAATNAAMBUITENLAND, straatnaam);
        ruleExecutor.setTransformedValue(straatadres, XSD_HUISNRBUITENLAND, huisnummer);
        ruleExecutor.setTransformedValue(straatadres, XSD_LOCATIEOMSBUITENLAND, locatieomschrijving);
        ruleExecutor.setTransformedValue(straatadres, XSD_REGIONAAMBUITENLAND, regionaam);
        ruleExecutor.setTransformedValue(straatadres, XSD_LANDCODEGBA, extractStringValueOrNull(landcodeGba));
        ruleExecutor.setTransformedValue(straatadres, XSD_LANDCODEISO, landcodeIso);
        ruleExecutor.setTransformedValue(straatadres, XSD_LANDSNAAM, landsnaam);
    }

    private void mapToJaxbPostbusadresAdresBuitenland(AdresBuitenlandPostbusadresHr postbusadresHr, Object postbusadres) {
        final String postcode = postbusadresHr.getPostcodeBuitenland();
        final String woonplaatsnaam = postbusadresHr.getWoonplaatsnaamBuitenland();
        final String postbusnummer = postbusadresHr.getPostbusnummerBuitenland();
        final String regionaam = postbusadresHr.getRegionaamBuitenland();
        final Integer landcodeGba = postbusadresHr.getLandcodeGba();
        final String landcodeIso = postbusadresHr.getLandcodeIso();
        final String landsnaam = postbusadresHr.getLandsnaam();

        ruleExecutor.setTransformedValue(postbusadres, XSD_POSTCDBUITENLAND, postcode);
        ruleExecutor.setTransformedValue(postbusadres, XSD_WOONPLAATSNAAMBUITENLAND, woonplaatsnaam);
        ruleExecutor.setTransformedValue(postbusadres, XSD_POSTBUSNRBUITENLAND, postbusnummer);
        ruleExecutor.setTransformedValue(postbusadres, XSD_REGIONAAMBUITENLAND, regionaam);
        ruleExecutor.setTransformedValue(postbusadres, XSD_LANDCODEGBA, extractStringValueOrNull(landcodeGba));
        ruleExecutor.setTransformedValue(postbusadres, XSD_LANDCODEISO, landcodeIso);
        ruleExecutor.setTransformedValue(postbusadres, XSD_LANDSNAAM, landsnaam);
    }

    public PersoonInhoudingsplichtige.Adreshouding mapToJaxbAdresBuitenlandOngestructureerdPersoon(AdresBuitenlandOngestructureerdHr adresBuitenlandOngestructureerdHr) {
        PersoonInhoudingsplichtige.Adreshouding adres = new PersoonInhoudingsplichtige.Adreshouding();
        PersoonInhoudingsplichtige.Adreshouding.AdresBuitenlandOngestructureerdUhr adresBuitenlandOngestructureerd = new PersoonInhoudingsplichtige.Adreshouding.AdresBuitenlandOngestructureerdUhr();
        mapToJaxbAdresBuitenlandOngestructureerd(adresBuitenlandOngestructureerdHr, adresBuitenlandOngestructureerd);

        adres.setAdresBuitenlandOngestructureerdUhr(adresBuitenlandOngestructureerd);

        return collectNonEmptyObject(adres);
    }

    public VestigingHandelsregister.Adreshouding mapToJaxbAdresBuitenlandOngestructureerdVestigingHandelsregister(AdresBuitenlandOngestructureerdHr adresBuitenlandOngestructureerdHr) {
        VestigingHandelsregister.Adreshouding adres = new VestigingHandelsregister.Adreshouding();
        VestigingHandelsregister.Adreshouding.AdresBuitenlandOngestructureerdUhr adresBuitenlandOngestructureerd = new VestigingHandelsregister.Adreshouding.AdresBuitenlandOngestructureerdUhr();
        mapToJaxbAdresBuitenlandOngestructureerd(adresBuitenlandOngestructureerdHr, adresBuitenlandOngestructureerd);

        adres.setAdresBuitenlandOngestructureerdUhr(adresBuitenlandOngestructureerd);

        return collectNonEmptyObject(adres);
    }

    private void mapToJaxbAdresBuitenlandOngestructureerd(AdresBuitenlandOngestructureerdHr adresBuitenlandOngestructureerdHr, Object adresBuitenlandOngestructureerd) {
        final String codeAdresrol = adresBuitenlandOngestructureerdHr.getCodeAdresrol();
        final Date datumAanvangAdreshouding = adresBuitenlandOngestructureerdHr.getDatumAanvangAdreshouding();
        Integer codeFictieveDatumAanvang = null;
        if (datumAanvangAdreshouding != null) {
            codeFictieveDatumAanvang = adresBuitenlandOngestructureerdHr.getCodeFictieveDatumAanvang();
        }

        Date datumEindeAdreshouding = adresBuitenlandOngestructureerdHr.getDatumEindeAdreshouding();
        Integer codeFictieveDatumEinde = null;
        if (datumEindeAdreshouding != null) {
            codeFictieveDatumEinde = adresBuitenlandOngestructureerdHr.getCodeFictieveDatumEinde();
        }
        final Integer codeAfgeschermdAdres = adresBuitenlandOngestructureerdHr.getCodeAfgeschermdAdres();

        final String adresregel1 = adresBuitenlandOngestructureerdHr.getAdresregel1Buitenland();
        final String adresregel2 = adresBuitenlandOngestructureerdHr.getAdresregel2Buitenland();
        final String adresregel3 = adresBuitenlandOngestructureerdHr.getAdresregel3Buitenland();
        final Integer landcodeGba = adresBuitenlandOngestructureerdHr.getLandcodeGba();
        final String landsnaamGba = adresBuitenlandOngestructureerdHr.getLandsnaamGba();
        final String landcodeIso = adresBuitenlandOngestructureerdHr.getLandcodeIso();
        final String landsnaam = adresBuitenlandOngestructureerdHr.getLandsnaam();

        ruleExecutor.setTransformedValue(adresBuitenlandOngestructureerd, XSD_CDADRESROL, codeAdresrol);
        ruleExecutor.setTransformedValue(adresBuitenlandOngestructureerd, XSD_DATBADRESHOUDING, extractStringFromDateValueOrNull(datumAanvangAdreshouding));
        ruleExecutor.setTransformedValue(adresBuitenlandOngestructureerd, XSD_CDFICTIEVEDATB, extractStringValueOrNull(codeFictieveDatumAanvang));
        ruleExecutor.setTransformedValue(adresBuitenlandOngestructureerd, XSD_DATEADRESHOUDING, extractStringFromDateValueOrNull(datumEindeAdreshouding));
        ruleExecutor.setTransformedValue(adresBuitenlandOngestructureerd, XSD_CDFICTIEVEDATE, extractStringValueOrNull(codeFictieveDatumEinde));
        ruleExecutor.setTransformedValue(adresBuitenlandOngestructureerd, XSD_CDAFGESCHERMDADRES, extractStringValueOrNull(codeAfgeschermdAdres));
        ruleExecutor.setTransformedValue(adresBuitenlandOngestructureerd, XSD_ADRESREGEL1BUITENLAND, adresregel1);
        ruleExecutor.setTransformedValue(adresBuitenlandOngestructureerd, XSD_ADRESREGEL2BUITENLAND, adresregel2);
        ruleExecutor.setTransformedValue(adresBuitenlandOngestructureerd, XSD_ADRESREGEL3BUITENLAND, adresregel3);
        ruleExecutor.setTransformedValue(adresBuitenlandOngestructureerd, XSD_LANDCODEGBA, extractStringValueOrNull(landcodeGba));
        ruleExecutor.setTransformedValue(adresBuitenlandOngestructureerd, XSD_LANDSNAAMGBA, landsnaamGba);
        ruleExecutor.setTransformedValue(adresBuitenlandOngestructureerd, XSD_LANDCODEISO, landcodeIso);
        ruleExecutor.setTransformedValue(adresBuitenlandOngestructureerd, XSD_LANDSNAAM, landsnaam);
    }

    public AdministratieveEenheid.Adreshouding mapToJaxbAdresNederlandWg(AdresNederlandWg adresNederlandWg) {
        AdministratieveEenheid.Adreshouding adreshouding = new AdministratieveEenheid.Adreshouding();
        AdministratieveEenheid.Adreshouding.AdresNederlandWga adresNederland = new AdministratieveEenheid.Adreshouding.AdresNederlandWga();
        mapToJaxbAdresNederland(adresNederlandWg, adresNederland);

        AdministratieveEenheid.Adreshouding.AdresNederlandWga.StraatadresWga straatadres = mapToJaxbStraatadresAdresNederland(adresNederlandWg.getStraatadresWg());
        AdministratieveEenheid.Adreshouding.AdresNederlandWga.PostbusadresWga postbusadres = mapToJaxbPostbusadresAdresNederland(adresNederlandWg.getPostbusadresWg());

        if (straatadres != null || postbusadres != null) {
            adresNederland.setStraatadresWga(straatadres);
            adresNederland.setPostbusadresWga(postbusadres);
            adreshouding.setAdresNederlandWga(adresNederland);
        }

        return collectNonEmptyObject(adreshouding);
    }

    private AdministratieveEenheid.Adreshouding.AdresNederlandWga.StraatadresWga mapToJaxbStraatadresAdresNederland(AdresNederlandStraatadresWg straatadresWg) {
        AdministratieveEenheid.Adreshouding.AdresNederlandWga.StraatadresWga straatadres = new AdministratieveEenheid.Adreshouding.AdresNederlandWga.StraatadresWga();
        mapToJaxbStraatadresAdresNederland(straatadresWg, straatadres);
        return collectNonEmptyObject(straatadres);
    }

    private AdministratieveEenheid.Adreshouding.AdresNederlandWga.PostbusadresWga mapToJaxbPostbusadresAdresNederland(AdresNederlandPostbusadresWg postbusadresWg) {
        AdministratieveEenheid.Adreshouding.AdresNederlandWga.PostbusadresWga postbusadres = new AdministratieveEenheid.Adreshouding.AdresNederlandWga.PostbusadresWga();
        mapToJaxbPostbusadresAdresNederland(postbusadresWg, postbusadres);
        return collectNonEmptyObject(postbusadres);
    }

    private void mapToJaxbAdresNederland(AdresNederlandWg adresNederlandWg, Object adresNederland) {
        final String codeAdresrol = adresNederlandWg.getCodeAdresrol();
        final Long datumAanvangAdreshouding = adresNederlandWg.getDatumAanvangAdreshouding();
        final Long datumEindeAdreshouding = adresNederlandWg.getDatumEindeAdreshouding();

        ruleExecutor.setTransformedValue(adresNederland, XSD_CDADRESROL, codeAdresrol);
        ruleExecutor.setTransformedValue(adresNederland, XSD_DATBADRESHOUDING, extractStringValueOrNull(datumAanvangAdreshouding));
        ruleExecutor.setTransformedValue(adresNederland, XSD_DATEADRESHOUDING, extractStringValueOrNull(datumEindeAdreshouding));
    }

    private void mapToJaxbStraatadresAdresNederland(AdresNederlandStraatadresWg straatadresWg, Object straatadres) {
        final String postcode = straatadresWg.getPostcode();
        final String woonplaatsnaam = straatadresWg.getWoonplaatsnaam();
        final String gemeentenaam = straatadresWg.getGemeentenaam();
        final String straatnaam = straatadresWg.getStraatnaam();
        final Integer huisnummer = straatadresWg.getHuisnummer();
        final String huisnummertoevoeging = straatadresWg.getHuisnummerToevoeging();
        final String locatieomschrijving = straatadresWg.getLocatieomschrijving();

        ruleExecutor.setTransformedValue(straatadres, XSD_POSTCD, postcode);
        ruleExecutor.setTransformedValue(straatadres, XSD_WOONPLAATSNAAM, woonplaatsnaam);
        ruleExecutor.setTransformedValue(straatadres, XSD_GEMEENTENAAM, gemeentenaam);
        ruleExecutor.setTransformedValue(straatadres, XSD_STRAATNAAM, straatnaam);
        ruleExecutor.setTransformedValue(straatadres, XSD_HUISNR, extractStringValueOrNull(huisnummer));
        ruleExecutor.setTransformedValue(straatadres, XSD_HUISNRTOEVOEGING, huisnummertoevoeging);
        ruleExecutor.setTransformedValue(straatadres, XSD_LOCATIEOMS, locatieomschrijving);
    }

    private void mapToJaxbPostbusadresAdresNederland(AdresNederlandPostbusadresWg postbusadresWg, Object postbusadres) {
        final String postcode = postbusadresWg.getPostcode();
        final String woonplaatsnaam = postbusadresWg.getWoonplaatsnaam();
        final Integer postbusnummer = postbusadresWg.getPostbusnummer();

        ruleExecutor.setTransformedValue(postbusadres, XSD_POSTCD, postcode);
        ruleExecutor.setTransformedValue(postbusadres, XSD_WOONPLAATSNAAM, woonplaatsnaam);
        ruleExecutor.setTransformedValue(postbusadres, XSD_POSTBUSNR, extractBigIntegerValueOrNull(postbusnummer));
    }

    public AdministratieveEenheid.Adreshouding mapToJaxbAdresBuitenlandWg(AdresBuitenlandWg adresBuitenlandWg) {
        AdministratieveEenheid.Adreshouding adreshouding = new AdministratieveEenheid.Adreshouding();
        AdministratieveEenheid.Adreshouding.AdresBuitenlandWga adresBuitenland = new AdministratieveEenheid.Adreshouding.AdresBuitenlandWga();
        mapToJaxbAdresBuitenland(adresBuitenlandWg, adresBuitenland);

        AdministratieveEenheid.Adreshouding.AdresBuitenlandWga.StraatadresBuitenlandWga straatadres = mapToJaxbStraatadresAdresBuitenland(adresBuitenlandWg.getStraatadresWg());
        AdministratieveEenheid.Adreshouding.AdresBuitenlandWga.PostbusadresBuitenlandWga postbusadres = mapToJaxbPostbusadresAdresBuitenland(adresBuitenlandWg.getPostbusadresWg());

        if (straatadres != null || postbusadres != null) {
            adresBuitenland.setStraatadresBuitenlandWga(straatadres);
            adresBuitenland.setPostbusadresBuitenlandWga(postbusadres);
            adreshouding.setAdresBuitenlandWga(adresBuitenland);
        }

        return collectNonEmptyObject(adreshouding);
    }

    private AdministratieveEenheid.Adreshouding.AdresBuitenlandWga.StraatadresBuitenlandWga mapToJaxbStraatadresAdresBuitenland(AdresBuitenlandStraatadresWg straatadresWg) {
        AdministratieveEenheid.Adreshouding.AdresBuitenlandWga.StraatadresBuitenlandWga straatadres = new AdministratieveEenheid.Adreshouding.AdresBuitenlandWga.StraatadresBuitenlandWga();
        mapToJaxbStraatadresAdresBuitenland(straatadresWg, straatadres);
        return collectNonEmptyObject(straatadres);
    }

    private AdministratieveEenheid.Adreshouding.AdresBuitenlandWga.PostbusadresBuitenlandWga mapToJaxbPostbusadresAdresBuitenland(AdresBuitenlandPostbusadresWg postbusadresWg) {
        AdministratieveEenheid.Adreshouding.AdresBuitenlandWga.PostbusadresBuitenlandWga postbusadres = new AdministratieveEenheid.Adreshouding.AdresBuitenlandWga.PostbusadresBuitenlandWga();
        mapToJaxbPostbusadresAdresBuitenland(postbusadresWg, postbusadres);
        return collectNonEmptyObject(postbusadres);
    }

    private void mapToJaxbAdresBuitenland(AdresBuitenlandWg adresBuitenlandWg, Object adresBuitenland) {
        final String codeAdresrol = adresBuitenlandWg.getCodeAdresrol();
        final Long datumAanvangAdreshouding = adresBuitenlandWg.getDatumAanvangAdreshouding();
        final Long datumEindeAdreshouding = adresBuitenlandWg.getDatumEindeAdreshouding();

        ruleExecutor.setTransformedValue(adresBuitenland, XSD_CDADRESROL, codeAdresrol );
        ruleExecutor.setTransformedValue(adresBuitenland, XSD_DATBADRESHOUDING, extractStringValueOrNull(datumAanvangAdreshouding));
        ruleExecutor.setTransformedValue(adresBuitenland, XSD_DATEADRESHOUDING, extractStringValueOrNull(datumEindeAdreshouding));
    }

    private void mapToJaxbStraatadresAdresBuitenland(AdresBuitenlandStraatadresWg straatadresWg, Object straatadres) {
        final String postcode = straatadresWg.getPostcodeBuitenland();
        final String woonplaatsnaam = straatadresWg.getWoonplaatsnaamBuitenland();
        final String straatnaam = straatadresWg.getStraatnaamBuitenland();
        final String huisnummer = straatadresWg.getHuisnummerBuitenland();
        final String regionaam = straatadresWg.getRegionaamBuitenland();
        final String landcodeIso = straatadresWg.getLandcodeIso();
        final String locatieomschrijving = straatadresWg.getLocatieomschrijvingBuitenland();

        ruleExecutor.setTransformedValue(straatadres, XSD_POSTCDBUITENLAND, postcode);
        ruleExecutor.setTransformedValue(straatadres, XSD_WOONPLAATSNAAMBUITENLAND, woonplaatsnaam);
        ruleExecutor.setTransformedValue(straatadres, XSD_REGIONAAMBUITENLAND, regionaam);
        ruleExecutor.setTransformedValue(straatadres, XSD_LANDCODEISO, landcodeIso);
        ruleExecutor.setTransformedValue(straatadres, XSD_STRAATNAAMBUITENLAND, straatnaam);
        ruleExecutor.setTransformedValue(straatadres, XSD_HUISNRBUITENLAND, huisnummer);
        ruleExecutor.setTransformedValue(straatadres, XSD_LOCATIEOMSBUITENLAND, locatieomschrijving);
    }

    private void mapToJaxbPostbusadresAdresBuitenland(AdresBuitenlandPostbusadresWg postbusadresWg, Object postbusadres) {
        final String postcode = postbusadresWg.getPostcodeBuitenland();
        final String woonplaatsnaam = postbusadresWg.getWoonplaatsnaamBuitenland();
        final String postbusnummer = postbusadresWg.getPostbusnummerBuitenland();
        final String regionaam = postbusadresWg.getRegionaamBuitenland();
        final String landcodeIso = postbusadresWg.getLandcodeIso();

        ruleExecutor.setTransformedValue(postbusadres, XSD_POSTCDBUITENLAND, postcode);
        ruleExecutor.setTransformedValue(postbusadres, XSD_WOONPLAATSNAAMBUITENLAND, woonplaatsnaam);
        ruleExecutor.setTransformedValue(postbusadres, XSD_REGIONAAMBUITENLAND, regionaam);
        ruleExecutor.setTransformedValue(postbusadres, XSD_LANDCODEISO, landcodeIso);
        ruleExecutor.setTransformedValue(postbusadres, XSD_POSTBUSNRBUITENLAND, postbusnummer);
    }

    public AdministratieveEenheid.Adreshouding mapToJaxbAdresBuitenlandOngestructureerdWg(AdresBuitenlandOngestructureerdWg adresBuitenlandOngestructureerdWg) {
        AdministratieveEenheid.Adreshouding adreshouding = new AdministratieveEenheid.Adreshouding();
        AdministratieveEenheid.Adreshouding.AdresBuitenlandOngestructureerdWga adresBuitenlandOngestructureerd = new AdministratieveEenheid.Adreshouding.AdresBuitenlandOngestructureerdWga();
        mapToJaxbAdresBuitenlandOngestructureerd(adresBuitenlandOngestructureerdWg, adresBuitenlandOngestructureerd);

        adreshouding.setAdresBuitenlandOngestructureerdWga(adresBuitenlandOngestructureerd);

        return collectNonEmptyObject(adreshouding);
    }

    private void mapToJaxbAdresBuitenlandOngestructureerd(AdresBuitenlandOngestructureerdWg adresBuitenlandOngestructureerdWg, Object adresBuitenlandOngestructureerd) {
        final String codeAdresrol = adresBuitenlandOngestructureerdWg.getCodeAdresrol();
        final Long datumAanvangAdreshouding = adresBuitenlandOngestructureerdWg.getDatumAanvangAdreshouding();
        final Long datumEindeAdreshouding = adresBuitenlandOngestructureerdWg.getDatumEindeAdreshouding();

        final String adresregel1 = adresBuitenlandOngestructureerdWg.getAdresregel1Buitenland();
        final String adresregel2 = adresBuitenlandOngestructureerdWg.getAdresregel2Buitenland();
        final String adresregel3 = adresBuitenlandOngestructureerdWg.getAdresregel3Buitenland();
        final String landcodeIso = adresBuitenlandOngestructureerdWg.getLandcodeIso();

        ruleExecutor.setTransformedValue(adresBuitenlandOngestructureerd, XSD_CDADRESROL, codeAdresrol);
        ruleExecutor.setTransformedValue(adresBuitenlandOngestructureerd, XSD_DATBADRESHOUDING, extractStringValueOrNull(datumAanvangAdreshouding));
        ruleExecutor.setTransformedValue(adresBuitenlandOngestructureerd, XSD_DATEADRESHOUDING, extractStringValueOrNull(datumEindeAdreshouding));
        ruleExecutor.setTransformedValue(adresBuitenlandOngestructureerd, XSD_ADRESREGEL1BUITENLAND, adresregel1);
        ruleExecutor.setTransformedValue(adresBuitenlandOngestructureerd, XSD_ADRESREGEL2BUITENLAND, adresregel2);
        ruleExecutor.setTransformedValue(adresBuitenlandOngestructureerd, XSD_ADRESREGEL3BUITENLAND, adresregel3);
        ruleExecutor.setTransformedValue(adresBuitenlandOngestructureerd, XSD_LANDCODEISO, landcodeIso);
    }


}