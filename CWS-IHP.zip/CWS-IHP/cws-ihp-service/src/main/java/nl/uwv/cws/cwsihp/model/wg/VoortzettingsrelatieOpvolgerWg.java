package nl.uwv.cws.cwsihp.model.wg;

import lombok.Builder;
import lombok.Getter;

@Builder
@Getter
public class VoortzettingsrelatieOpvolgerWg {
    private Long datumAanvangVoortzettingsrelatieOpvolger;
    private Double percentageLoonsomOvergegaan;
    private String lhnrOpvolger;
}
