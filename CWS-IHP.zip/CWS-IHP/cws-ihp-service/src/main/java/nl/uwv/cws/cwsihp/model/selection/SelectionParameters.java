package nl.uwv.cws.cwsihp.model.selection;

import lombok.Builder;
import lombok.Getter;
import nl.uwv.cws.cwsihp.model.configuratie.CwsIhpConfiguratie;

import java.time.LocalDateTime;

@Builder
@Getter
public class SelectionParameters {
    private String bsn;
    private String rsin;
    private String kvknummer;
    private String loonheffingennummer;
    private LocalDateTime beschouwingsmoment;
    private CwsIhpConfiguratie cwsIhpConfiguratie;
    private boolean inhoudingsplichtigeIsPresentInHr;
    private boolean inhoudingsplichtigeIsPresentInWg;

    public boolean isPersoonInhoudingsplichtigeHr() {
        return (this.inhoudingsplichtigeIsPresentInHr && !this.inhoudingsplichtigeIsPresentInWg);
    }

    public boolean isPersoonInhoudingsplichtigeHrWg() {
        return (this.inhoudingsplichtigeIsPresentInHr && this.inhoudingsplichtigeIsPresentInWg);
    }
}
