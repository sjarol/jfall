package nl.uwv.cws.cwsihp.service;

import lombok.extern.slf4j.Slf4j;
import nl.uwv.cws.cwsihp.dao.ihp.*;
import nl.uwv.cws.cwsihp.model.configuratie.CwsIhpConfiguratie;
import nl.uwv.cws.cwsihp.model.hr.*;
import nl.uwv.cws.cwsihp.model.ihp.PersoonIhp;
import nl.uwv.cws.cwsihp.model.wg.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Slf4j
public abstract class BaseService{

    @Autowired
    protected AdministratieveEenheidWgDao administratieveEenheidWgDao;

    @Autowired
    protected SectorRisicogroepWgDao sectorRisicogroepWgDao;

    @Autowired
    protected PremiepercentageIndividueelWgDao premiepercentageIndividueelWgDao;

    @Autowired
    protected EigenRisicoDragerWgDao eigenRisicoDragerWgDao;

    @Autowired
    protected AdresNederlandWgDao adresNederlandWgDao;

    @Autowired
    protected AdresBuitenlandWgDao adresBuitenlandWgDao;

    @Autowired
    protected AdresBuitenlandOngestructureerdWgDao adresBuitenlandOngestructureerdWgDao;

    @Autowired
    protected VoortzettingsrelatieOpvolgerWgDao voortzettingsrelatieOpvolgerWgDao;

    @Autowired
    protected VoortzettingsrelatieVoorgangerWgDao voortzettingsrelatieVoorgangerWgDao;

    @Autowired
    protected AangifteFrequentieAdministratieveEenheidWgDao aangifteFrequentieAdministratieveEenheidWgDao;

    @Autowired
    protected AansluitingsnummerBvWgDao aansluitingsnummerBvWgDao;

    protected List<AdministratieveEenheidWg> findAdministratieveEenheidByNrihp(final String nrihp, final String lhnr, final LocalDateTime beschouwingsmoment, final CwsIhpConfiguratie cwsIhpConfiguratie) {
        List<AdministratieveEenheidWg> administratieveEenheidWgList = administratieveEenheidWgDao.findAdministratieveEenheidByNrihp(nrihp, lhnr, beschouwingsmoment, cwsIhpConfiguratie);
        administratieveEenheidWgList.forEach(administratieveEenheidWg -> {

            AdreshoudingWg adreshoudingWg = findAdres(administratieveEenheidWg.getAehId(), beschouwingsmoment, cwsIhpConfiguratie);
            administratieveEenheidWg.setAdreshouding(adreshoudingWg);

            findAndAttachAdministratieveEenheidMembers(administratieveEenheidWg, beschouwingsmoment, cwsIhpConfiguratie);
        });

        return administratieveEenheidWgList;
    }

    protected AdreshoudingWg findAdres(final Long aehId, final LocalDateTime beschouwingsmoment, final CwsIhpConfiguratie cwsIhpConfiguratie) {
        List<AdresNederlandWg> adresNederlandWgList = null;
        List<AdresBuitenlandWg> adresBuitenlandWgList = null;
        List<AdresBuitenlandOngestructureerdWg> adresBuitenlandOngestructureerdWgList = null;

        if (cwsIhpConfiguratie.requiresAnyAdresNederlandWg()) {
            adresNederlandWgList = adresNederlandWgDao.findAdresNederland(aehId, beschouwingsmoment, cwsIhpConfiguratie);
        }

        if (cwsIhpConfiguratie.requiresAnyAdresBuitenlandWg()) {
            adresBuitenlandWgList = adresBuitenlandWgDao.findAdresBuitenland(aehId, beschouwingsmoment, cwsIhpConfiguratie);
        }

        if (cwsIhpConfiguratie.requiresAdresBuitenlandOngestructureerdWg()) {
            adresBuitenlandOngestructureerdWgList = adresBuitenlandOngestructureerdWgDao.findAdresBuitenlandOngestructureerd(aehId, beschouwingsmoment, cwsIhpConfiguratie);
        }

        return AdreshoudingWg.builder()
                .adresNederlandWgList(adresNederlandWgList)
                .adresBuitenlandWgList(adresBuitenlandWgList)
                .adresBuitenlandOngestructureerdWgList(adresBuitenlandOngestructureerdWgList)
                .build();
    }

    protected void findAndAttachAdministratieveEenheidMembers(AdministratieveEenheidWg administratieveEenheidWg, final LocalDateTime beschouwingsmoment, final CwsIhpConfiguratie cwsIhpConfiguratie) {

        if (cwsIhpConfiguratie.requiresSectorRisicogroep()) {
            List<SectorRisicogroepWg> sectorRisicogroepWgList = sectorRisicogroepWgDao.findSectorRisicogroep(administratieveEenheidWg.getAehId(), beschouwingsmoment, cwsIhpConfiguratie);
            administratieveEenheidWg.setSectorRisicogroepList(sectorRisicogroepWgList);
        }

        if (cwsIhpConfiguratie.requiresPremiepercentageIndividueel()) {
            List<PremiepercentageIndividueelWg> premiepercentageIndividueelWgList = premiepercentageIndividueelWgDao.findPremiepercentageIndividueel(administratieveEenheidWg.getAehId(), beschouwingsmoment, cwsIhpConfiguratie);
            administratieveEenheidWg.setPremiepercentageIndividueelList(premiepercentageIndividueelWgList);
        }

        if (cwsIhpConfiguratie.requiresEigenRisicoDrager()) {
            List<EigenRisicoDragerWg> eigenRisicoDragerWgList = eigenRisicoDragerWgDao.findEigenRisicoDrager(administratieveEenheidWg.getAehId(), beschouwingsmoment, cwsIhpConfiguratie);
            administratieveEenheidWg.setEigenRisicoDragerList(eigenRisicoDragerWgList);
        }

        if (cwsIhpConfiguratie.requiresVoortzettingsrelatieOpvolger()) {
            List<VoortzettingsrelatieOpvolgerWg> voortzettingsrelatieOpvolgerWgList = voortzettingsrelatieOpvolgerWgDao.findVoortzettingsrelatieOpvolger(administratieveEenheidWg.getAehId(), beschouwingsmoment, cwsIhpConfiguratie);
            administratieveEenheidWg.setVoortzettingsrelatieOpvolgerList(voortzettingsrelatieOpvolgerWgList);
        }

        if (cwsIhpConfiguratie.requiresVoortzettingsrelatieVoorganger()) {
            List<VoortzettingsrelatieVoorgangerWg> voortzettingsrelatieVoorgangerWgList = voortzettingsrelatieVoorgangerWgDao.findVoortzettingsrelatieVoorganger(administratieveEenheidWg.getAehId(), beschouwingsmoment, cwsIhpConfiguratie);
            administratieveEenheidWg.setVoortzettingsrelatieVoorgangerList(voortzettingsrelatieVoorgangerWgList);
        }

        if (cwsIhpConfiguratie.requiresAangifteFrequentieAdministratieveEenheid()) {
            List<AangifteFrequentieAdministratieveEenheidWg> aangifteFrequentieAdministratieveEenheidWgList = aangifteFrequentieAdministratieveEenheidWgDao.findAangifteFrequentieAdministratieveEenheid(administratieveEenheidWg.getAehId(), beschouwingsmoment, cwsIhpConfiguratie);
            administratieveEenheidWg.setAangiftefrequentieAdministratieveEenheidList(aangifteFrequentieAdministratieveEenheidWgList);
        }

        if (cwsIhpConfiguratie.requiresAansluitingsnummerBv()) {
            List<AansluitingsnummerBvWg> aansluitingsnummerBvWgList = aansluitingsnummerBvWgDao.findAansluitingsnummerBv(administratieveEenheidWg.getAehId(), beschouwingsmoment, cwsIhpConfiguratie);
            administratieveEenheidWg.setAansluitingsnummerBvList(aansluitingsnummerBvWgList);
        }
    }

    protected void filterAdresWg(final PersoonIhp persoonIhp) {
        AdreshoudingHr adreshoudingHr = persoonIhp.getAdreshoudingHr();
        if (adreshoudingHr != null) {
            List<MaatschappelijkeActiviteitHr> maatschappelijkeActiviteitHrList = persoonIhp.getMaatschappelijkeActiviteitHrList();
            List<VestigingHandelsregisterHr> vestigingHandelsregisterHrList = getVestigingHandelsregisterHr(maatschappelijkeActiviteitHrList);
            List<AdministratieveEenheidWg> administratieveEenheidWgList = persoonIhp.getAdministratieveEenheidWgList();

            final boolean actiefAdresNederlandPersoonHrPresent = isActiefAdresPersoonPresent(adreshoudingHr);
            final boolean actiefAdresVestigingHandelsRegisterHrPresent = isActiefAdresVestigingHandelsregisterHrPresent(vestigingHandelsregisterHrList);

            if (actiefAdresNederlandPersoonHrPresent || actiefAdresVestigingHandelsRegisterHrPresent) {
                filterAdresAdministratieveEenheid(administratieveEenheidWgList);
            }
        }
    }

    private boolean isActiefAdresPersoonPresent(final AdreshoudingHr adreshoudingHr) {
        List<AdresNederlandHr> adresNederlandPersoonHrList = adreshoudingHr.getAdresNederlandHrList();
        List<AdresBuitenlandHr> adresBuitenlandHrList = adreshoudingHr.getAdresBuitenlandHrList();
        List<AdresBuitenlandOngestructureerdHr> adresBuitenlandOngestructureerdHrList = adreshoudingHr.getAdresBuitenlandOngestructureerdHrList();

        return isActiefAdresHrPresent(adresNederlandPersoonHrList) ||
                isActiefAdresHrPresent(adresBuitenlandHrList) ||
                isActiefAdresHrPresent(adresBuitenlandOngestructureerdHrList);
    }

    private List<VestigingHandelsregisterHr> getVestigingHandelsregisterHr(final List<MaatschappelijkeActiviteitHr> maatschappelijkeActiviteitHrList) {
        List<VestigingHandelsregisterHr> vestigingHandelsregisterHrList = new ArrayList<>();
        if (!CollectionUtils.isEmpty(maatschappelijkeActiviteitHrList)) {
            maatschappelijkeActiviteitHrList.forEach(maatschappelijkeActiviteitHr -> {
                if (!CollectionUtils.isEmpty(maatschappelijkeActiviteitHr.getVestigingHandelsregisterHrList())) {
                    vestigingHandelsregisterHrList.addAll(maatschappelijkeActiviteitHr.getVestigingHandelsregisterHrList());
                }
            });
        }
        return vestigingHandelsregisterHrList;
    }

    private boolean isActiefAdresVestigingHandelsregisterHrPresent(final List<VestigingHandelsregisterHr> vestigingHandelsregisterHrList) {
        if (!CollectionUtils.isEmpty(vestigingHandelsregisterHrList)) {
            return vestigingHandelsregisterHrList.stream()
                    .filter(vestigingHandelsregisterHr -> vestigingHandelsregisterHr.getAdreshoudingHr() != null)
                    .anyMatch(vestigingHandelsregisterHr ->
                            isActiefAdresHrPresent(vestigingHandelsregisterHr.getAdreshoudingHr().getAdresNederlandHrList()) ||
                            isActiefAdresHrPresent(vestigingHandelsregisterHr.getAdreshoudingHr().getAdresBuitenlandHrList()) ||
                            isActiefAdresHrPresent(vestigingHandelsregisterHr.getAdreshoudingHr().getAdresBuitenlandOngestructureerdHrList()));
        }
        return false;
    }

    private void filterAdresAdministratieveEenheid(List<AdministratieveEenheidWg> administratieveEenheidWgList) {
        if (!CollectionUtils.isEmpty(administratieveEenheidWgList)) {
            administratieveEenheidWgList.stream()
                    .filter(administratieveEenheidWg -> administratieveEenheidWg.getAdreshouding() != null)
                    .forEach(administratieveEenheidWg -> {
                AdreshoudingWg adreshoudingWg = administratieveEenheidWg.getAdreshouding();
                if (!CollectionUtils.isEmpty(adreshoudingWg.getAdresNederlandWgList())) {
                    List<AdresNederlandWg> adresNederlandWgList = adreshoudingWg.getAdresNederlandWgList();
                    List<AdresNederlandWg> feitelijkAdresNederlandWgList = collectFeitelijkAdresWg(adresNederlandWgList);

                    log.debug("Volgende feitelijkadressen Nederland van AdministratieveEenheid worden verwijderd uit AEH omdat ze ook in UHR bestaan {}", Arrays.toString(feitelijkAdresNederlandWgList.toArray()));
                    adresNederlandWgList.removeAll(feitelijkAdresNederlandWgList);
                }

                if (!CollectionUtils.isEmpty(adreshoudingWg.getAdresBuitenlandWgList())) {
                    List<AdresBuitenlandWg> adresBuitenlandWgList = adreshoudingWg.getAdresBuitenlandWgList();
                    List<AdresBuitenlandWg> feitelijkAdresBuitenlandWgList = collectFeitelijkAdresWg(adresBuitenlandWgList);

                    log.debug("Volgende feitelijkadressen Buitenland van AdministratieveEenheid worden verwijderd uit AEH omdat ze ook in UHR bestaan {}", Arrays.toString(feitelijkAdresBuitenlandWgList.toArray()));
                    adresBuitenlandWgList.removeAll(feitelijkAdresBuitenlandWgList);
                }

                if (!CollectionUtils.isEmpty(adreshoudingWg.getAdresBuitenlandOngestructureerdWgList())) {
                    List<AdresBuitenlandOngestructureerdWg> adresBuitenlandOngestructureerdWgList = adreshoudingWg.getAdresBuitenlandOngestructureerdWgList();
                    List<AdresBuitenlandOngestructureerdWg> feitelijkAdresBuitenlandOngestructureerdWgList = collectFeitelijkAdresWg(adresBuitenlandOngestructureerdWgList);

                    log.debug("Volgende feitelijkadressen BuitenlandOngestructureerd van AdministratieveEenheid worden verwijderd uit AEH omdat ze ook in UHR bestaan {}", Arrays.toString(feitelijkAdresBuitenlandOngestructureerdWgList.toArray()));
                    adresBuitenlandOngestructureerdWgList.removeAll(feitelijkAdresBuitenlandOngestructureerdWgList);
                }
            });
        }
    }

    private <A extends AdresWg> List<A> collectFeitelijkAdresWg(final List<A> adresWgList) {
        return adresWgList.stream()
                .filter(adres -> adres.getCodeAdresrol().equalsIgnoreCase("F"))
                .collect(Collectors.toList());
    }

    private <A extends AdresHr> boolean isActiefAdresHrPresent(final List<A> adresHrList) {
        if (CollectionUtils.isEmpty(adresHrList)) {
            return false;
        }

        Optional<A> adresHr = adresHrList.stream()
                .filter(AdresHr::isAdresActief)
                .findFirst();
        return adresHr.isPresent();
    }
}
