package nl.uwv.cws.cwsihp.model.hr;

import lombok.Builder;
import lombok.Getter;

import java.util.List;


@Getter
@Builder
public class AdreshoudingHr {
    private List<AdresNederlandHr> adresNederlandHrList;
    private List<AdresBuitenlandHr> adresBuitenlandHrList;
    private List<AdresBuitenlandOngestructureerdHr> adresBuitenlandOngestructureerdHrList;
}
