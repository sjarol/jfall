package nl.uwv.cws.cwsihp.model.hr;

import lombok.Builder;
import lombok.Getter;

import java.sql.Date;

@Builder
@Getter
public class RechtsvormHr {
    private String codeRechtsvorm;
    private Date datumAanvangRechtsvorm;
    private Integer codeFictieveDatumAanvang;
    private Date datumEindeRechtsvorm;
    private Integer codeFictieveDatumEinde;
}
