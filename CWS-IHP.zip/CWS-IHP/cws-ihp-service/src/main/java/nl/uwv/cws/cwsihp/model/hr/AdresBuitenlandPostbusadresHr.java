package nl.uwv.cws.cwsihp.model.hr;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter
public class AdresBuitenlandPostbusadresHr {
    private String postcodeBuitenland;
    private String woonplaatsnaamBuitenland;
    private String regionaamBuitenland;
    private Integer landcodeGba;
    private String landcodeIso;
    private String landsnaam;
    private String postbusnummerBuitenland;
}
