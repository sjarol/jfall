package nl.uwv.cws.cwsihp.service;

import nl.uwv.cws.cwsihp.dao.ihp.IdentifierStatusDao;
import nl.uwv.cws.cwsihp.model.ihp.Inhoudingsplichtige;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class IdentifierStatusService {

    @Autowired
    private IdentifierStatusDao identifierStatusDao;

    public Inhoudingsplichtige getInhoudingsplichtigeWga(final String nummerInhoudingsplichtige, final LocalDateTime beschouwingsmoment) {
        return identifierStatusDao.getInhoudingsplichtigeWga(nummerInhoudingsplichtige, beschouwingsmoment);
    }

    public Inhoudingsplichtige getInhoudingsplichtigeHr(final String kvkNummer, final LocalDateTime beschouwingsmoment) {
        return identifierStatusDao.getInhoudingsplichtigeHr(kvkNummer, beschouwingsmoment);
    }

    public Inhoudingsplichtige getInhoudingsplichtigeHrByNrIhp(final String loonheffingennummer, final LocalDateTime beschouwingsmoment) {
        return identifierStatusDao.getInhoudingsplichtigeHrByNrIhp(loonheffingennummer, beschouwingsmoment);
    }

    public boolean isWerkgeverPresent(final String kvkNummer, final LocalDateTime beschouwingsmoment) {
        return identifierStatusDao.isWerkgeverPresent(kvkNummer, beschouwingsmoment);
    }

    public boolean isAdministratieveEenheidPresent(final String loonheffingennummer, final LocalDateTime beschouwingsmoment) {
        return identifierStatusDao.isAdministratieveEenheidPresent(loonheffingennummer, beschouwingsmoment);
    }

    public boolean isInhoudingsplichtigePresentInWga(final String nummerInhoudingsplichtige, final LocalDateTime beschouwingsmoment) {
        return identifierStatusDao.isInhoudingsplichtigePresentInWga(nummerInhoudingsplichtige, beschouwingsmoment);
    }

    public boolean isInhoudingsplichtigePresentInHr(final String nummerInhoudingsplichtige, final LocalDateTime beschouwingsmoment) {
        return identifierStatusDao.isInhoudingsplichtigePresentInHr(nummerInhoudingsplichtige, beschouwingsmoment);
    }
}
