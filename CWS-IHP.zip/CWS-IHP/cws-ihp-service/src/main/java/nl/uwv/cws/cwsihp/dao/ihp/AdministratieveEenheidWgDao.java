package nl.uwv.cws.cwsihp.dao.ihp;

import nl.uwv.cws.cwsihp.dao.mapper.AdministratieveEenheidWgRowMapper;
import nl.uwv.cws.cwsihp.model.configuratie.CwsIhpConfiguratie;
import nl.uwv.cws.cwsihp.model.wg.AdministratieveEenheidWg;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public class AdministratieveEenheidWgDao extends BaseDao {

    @Autowired
    private AdministratieveEenheidWgRowMapper administratieveEenheidWgRowMapper;

    public List<AdministratieveEenheidWg> findAdministratieveEenheidByNrihp(final String nrihp, final String lhnr, final LocalDateTime beschouwingsmoment, final CwsIhpConfiguratie cwsIhpConfiguratie) {
        final String whereClause = "INNER JOIN wga_persoon per " +
                                   "ON (per.per_id = aeh.per_id) " +
                                   "AND (per.sofinr = :nrihp OR per.finr = :nrihp) ";

        return findAdministratieveEenheid(nrihp, whereClause, lhnr, beschouwingsmoment, cwsIhpConfiguratie);
    }

    public List<AdministratieveEenheidWg> findAdministratieveEenheidByPersoonId(final Long persoonId, final String lhnr, final LocalDateTime beschouwingsmoment, final CwsIhpConfiguratie cwsIhpConfiguratie) {
        final String whereClause = "AND aeh.per_id = :persoonId ";

        return findAdministratieveEenheid(persoonId.toString(), whereClause, lhnr, beschouwingsmoment, cwsIhpConfiguratie);
    }

    private List<AdministratieveEenheidWg> findAdministratieveEenheid(final String identifier,final String whereClause, final String lhnr, final LocalDateTime beschouwingsmoment, final CwsIhpConfiguratie cwsIhpConfiguratie) {
        Timestamp beschouwingsmomentTimestamp = Timestamp.valueOf(beschouwingsmoment);
        boolean lhnrPresent = (lhnr != null);
        final String sql =
                "WITH laatste_beeld AS " +
                "        (SELECT aeh_id, lhnr, aeh_naam, dateind " +
                "         FROM (SELECT aeh.aeh_id " +
                "                    , aeh.lhnr  " +
                "                    , his.aeh_naam  " +
                "                    , his.dateind  " +
                "                    , ROW_NUMBER() OVER (PARTITION BY his.aeh_id ORDER BY his.dataanv DESC, his.his_ts_in DESC) AS rn  " +
                "               FROM wga_aeh_his his " +
                "               INNER JOIN wga_aeh aeh " +
                "               ON (aeh.aeh_id = his.aeh_id) " +
                whereClause +
                (lhnrPresent ? "AND aeh.lhnr = :lhnr " : "") +
                "               WHERE his.his_ts_in <= :beschouwingsmoment " +
                "               AND his.his_ts_end > :beschouwingsmoment " +
                "              ) " +
                "         WHERE rn = 1) " +
                ", oudste_beeld AS " +
                "        (SELECT aeh_id, dataanv " +
                "         FROM (SELECT aeh.aeh_id " +
                "                    , his.dataanv  " +
                "                    , ROW_NUMBER() OVER (PARTITION BY his.aeh_id ORDER BY his.dataanv ASC, his.his_ts_in ASC) AS rn  " +
                "               FROM wga_aeh_his his " +
                "               INNER JOIN wga_aeh aeh " +
                "               ON (aeh.aeh_id = his.aeh_id) " +
                whereClause +
                (lhnrPresent ? "AND aeh.lhnr = :lhnr " : "") +
                "               WHERE his.his_ts_in <= :beschouwingsmoment " +
                "               AND his.his_ts_end > :beschouwingsmoment " +
                "              ) " +
                "         WHERE rn = 1) " +
                "SELECT laatste_beeld.aeh_id " +
                "     , laatste_beeld.lhnr " +
                "     , laatste_beeld.aeh_naam " +
                "     , oudste_beeld.dataanv " +
                "     , laatste_beeld.dateind " +
                "FROM laatste_beeld " +
                "JOIN oudste_beeld " +
                "ON laatste_beeld.aeh_id = oudste_beeld.aeh_id";

        MapSqlParameterSource namedParameters = getNamedParameters(whereClause, identifier);
        namedParameters.addValue("beschouwingsmoment", beschouwingsmomentTimestamp);
        if (lhnrPresent) {
            namedParameters.addValue("lhnr", lhnr);
        }

        List<String> attributen = cwsIhpConfiguratie.getGroepenGegevens().getRequiredColumnsAdministratieveEenheid();
        return jdbcTemplate.query(sql, namedParameters, (resultSet, i) -> administratieveEenheidWgRowMapper.mapRow(resultSet, attributen));
    }
}
