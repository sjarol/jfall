package nl.uwv.cws.cwsihp.model.hr;

import lombok.Builder;
import lombok.Getter;

import java.sql.Date;

@Getter
@Builder
public class SbiklasseHr {
    private String codeSbi;
    private String omschrijvingSbi;
    private String indicatieSbiHoofdactiviteit;
    private Date datumAanvangSbiActiviteit;
    private Integer codeFictieveDatumAanvang;
    private Date datumEindeSbiActiviteit;
    private Integer codeFictieveDatumEinde;
}
