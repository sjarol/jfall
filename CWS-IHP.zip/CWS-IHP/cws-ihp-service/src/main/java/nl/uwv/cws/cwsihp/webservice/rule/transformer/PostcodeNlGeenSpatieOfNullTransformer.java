package nl.uwv.cws.cwsihp.webservice.rule.transformer;

import nl.uwv.cws.common.model.rule.AttributeRuleProperties;
import nl.uwv.cws.common.webservice.rule.transformer.RuleValueTransformer;
import nl.uwv.cws.cwsihp.model.rule.CwsIhpAttributeRule;
import org.springframework.stereotype.Component;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static nl.uwv.cws.cwsihp.model.rule.CwsIhpAttributeRule.POSTCODE_NL_GEEN_SPATIE_OF_NULL;

@Component
public class PostcodeNlGeenSpatieOfNullTransformer implements RuleValueTransformer<String, String> {
    private static final Pattern POSTCODE_NL_PATTERN = Pattern.compile("[1-9][0-9]{3}[A-Z]{2}");
    private static final Pattern POSTCODE_NL_WITH_SPACE_PATTERN = Pattern.compile("[1-9][0-9]{3}(\\s+)[A-Z]{2}");
    @Override
    public CwsIhpAttributeRule getTransformRule() {
        return POSTCODE_NL_GEEN_SPATIE_OF_NULL;
    }

    @Override
    public String transform(String originalValue, AttributeRuleProperties attributeRuleProperties) {
        if (originalValue == null || POSTCODE_NL_PATTERN.matcher(originalValue).matches()) {
            return originalValue;
        }
        Matcher postcodeNlWithSpaceMatcher = POSTCODE_NL_WITH_SPACE_PATTERN.matcher(originalValue);
        if (postcodeNlWithSpaceMatcher.matches()) {
            int spaceStartIndex = postcodeNlWithSpaceMatcher.start(1);
            int spaceEndIndex = postcodeNlWithSpaceMatcher.end(1);
            return originalValue.substring(0, spaceStartIndex) + originalValue.substring(spaceEndIndex);
        } else {
            return null;
        }
    }
}
