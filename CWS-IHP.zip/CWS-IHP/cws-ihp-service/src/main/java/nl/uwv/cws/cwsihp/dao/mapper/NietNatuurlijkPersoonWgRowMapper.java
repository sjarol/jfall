package nl.uwv.cws.cwsihp.dao.mapper;

import nl.uwv.cws.common.dao.mapper.CwsRowMapper;
import nl.uwv.cws.cwsihp.model.wg.NietNatuurlijkPersoonWg;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Component
public class NietNatuurlijkPersoonWgRowMapper extends CwsRowMapper<NietNatuurlijkPersoonWg> {

    @Override
    public NietNatuurlijkPersoonWg mapRow(final ResultSet resultSet, final List<String> attributen) throws SQLException {
        final Integer rsin = readApplicableNullableInteger(attributen, "RSIN", resultSet);
        final String naam = readApplicableString(attributen, "VOLLEDIGENAAM", resultSet);
        final Long datumOprichting = readApplicableNullableLong(attributen, "DAT_OPR", resultSet);
        final Long datumOntbinding = readApplicableNullableLong(attributen, "DAT_ONTB", resultSet);

        return NietNatuurlijkPersoonWg.builder()
                .rsin(rsin)
                .naamNietNatuurlijkPersoon(naam)
                .datumOprichtingNietNatuurlijkPersoon(datumOprichting)
                .datumOntbindingNietNatuurlijkPersoon(datumOntbinding)
                .build();

    }
}