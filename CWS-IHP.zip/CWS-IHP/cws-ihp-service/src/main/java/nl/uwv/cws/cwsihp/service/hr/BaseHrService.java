package nl.uwv.cws.cwsihp.service.hr;

import lombok.extern.slf4j.Slf4j;
import nl.uwv.cws.cwsihp.dao.ihp.*;
import nl.uwv.cws.cwsihp.model.configuratie.CwsIhpConfiguratie;
import nl.uwv.cws.cwsihp.model.hr.*;
import nl.uwv.cws.cwsihp.model.wg.*;
import nl.uwv.cws.cwsihp.service.BaseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;
import java.util.List;

@Slf4j
public abstract class BaseHrService extends BaseService {

    @Autowired
    protected PersoonHrDao persoonHrDao;

    @Autowired
    protected NietNatuurlijkPersoonHrDao nietNatuurlijkPersoonHrDao;

    @Autowired
    protected RechtspersoonHrDao rechtspersoonHrDao;

    @Autowired
    protected VennootschapBuitenlandHrDao vennootschapBuitenlandHrDao;

    @Autowired
    protected NatuurlijkPersoonHrDao natuurlijkPersoonHrDao;

    @Autowired
    protected PersoonHandelsregisterHrDao persoonHandelsregisterHrDao;

    @Autowired
    protected FaillissementSurseanceWgDao faillissementSurseanceWgDao;

    @Autowired
    protected FaillissementSurseanceHrDao faillissementSurseanceHrDao;

    @Autowired
    protected RechtsvormHrDao rechtsvormHrDao;

    @Autowired
    protected GemoedsbezwaardheidWgDao gemoedsbezwaardheidWgDao;

    @Autowired
    protected AdreshoudingHrDao adreshoudingHrDao;

    @Autowired
    protected MaatschappelijkeActiviteitHrDao maatschappelijkeActiviteitHrDao;

    @Autowired
    protected VestigingHandelsregisterHrDao vestigingHandelsregisterHrDao;

    @Autowired
    protected OndernemingHrDao ondernemingHrDao;

    @Autowired
    protected HandelsnaamHrDao handelsnaamHrDao;

    @Autowired
    protected ActiviteitHandelsregisterHrDao activiteitHandelsregisterHrDao;

    @Autowired
    protected SbiklasseDao sbiklasseDao;

    protected AdreshoudingHr findAdresPersoon(final Long persoonId, final Long naamPersoonId, final Long natuurlijkpersoonId, final LocalDateTime beschouwingsmoment, final CwsIhpConfiguratie cwsIhpConfiguratie) {
        List<AdresNederlandHr> adresNederlandHrList = null;
        List<AdresBuitenlandHr> adresBuitenlandHrList = null;
        List<AdresBuitenlandOngestructureerdHr> adresBuitenlandOngestructureerdHrList = null;

        if (cwsIhpConfiguratie.requiresAnyAdresNederlandPersoon()) {
            adresNederlandHrList = adreshoudingHrDao.findAdresNederlandPersoon(persoonId, naamPersoonId, natuurlijkpersoonId, beschouwingsmoment, cwsIhpConfiguratie);
        }

        if (cwsIhpConfiguratie.requiresAnyAdresBuitenlandPersoon()) {
            adresBuitenlandHrList = adreshoudingHrDao.findAdresBuitenlandPersoon(persoonId, naamPersoonId, natuurlijkpersoonId, beschouwingsmoment, cwsIhpConfiguratie);
        }

        if (cwsIhpConfiguratie.requiresAdresBuitenlandOngestructureerdPersoon()) {
            adresBuitenlandOngestructureerdHrList = adreshoudingHrDao.findAdresBuitenlandOngestructureerdPersoon(persoonId, naamPersoonId, natuurlijkpersoonId, beschouwingsmoment, cwsIhpConfiguratie);
        }

        return AdreshoudingHr.builder()
                .adresNederlandHrList(adresNederlandHrList)
                .adresBuitenlandHrList(adresBuitenlandHrList)
                .adresBuitenlandOngestructureerdHrList(adresBuitenlandOngestructureerdHrList)
                .build();
    }

    protected List<AdministratieveEenheidWg> getAdministratieveEenheidWgIfRequired(final String nrIhp,
                                                                                 final String lhnr,
                                                                                 final boolean includeAeh,
                                                                                 final LocalDateTime beschouwingsmoment,
                                                                                 CwsIhpConfiguratie cwsIhpConfiguratie){
        List<AdministratieveEenheidWg> administratieveEenheidWgList = null;
        if (cwsIhpConfiguratie.requiresAdministratieveEenheid() && includeAeh) {
            administratieveEenheidWgList = findAdministratieveEenheidByNrihp(nrIhp, lhnr, beschouwingsmoment, cwsIhpConfiguratie);
        }

        return administratieveEenheidWgList;
    }

    protected List<FaillissementSurseanceWg> getFaillissementSurseanceWgIfRequired(final String nrIhp,
                                                                                 final boolean includeAeh,
                                                                                 final LocalDateTime beschouwingsmoment,
                                                                                 CwsIhpConfiguratie cwsIhpConfiguratie){
        List<FaillissementSurseanceWg> faillissementSurseanceWgList = null;
        if (cwsIhpConfiguratie.requiresFaillissementSurseance() && includeAeh) {
            faillissementSurseanceWgList = faillissementSurseanceWgDao.findFaillissementSurseanceByNrihp(nrIhp, beschouwingsmoment, cwsIhpConfiguratie);
        }

        return faillissementSurseanceWgList;
    }

    protected List<FaillissementSurseanceHr> getFaillissementSurseanceHrIfRequired(final boolean includeAeh,
                                                                                 final LocalDateTime beschouwingsmoment,
                                                                                 final Long persoonId,
                                                                                 CwsIhpConfiguratie cwsIhpConfiguratie){
        List<FaillissementSurseanceHr> faillissementSurseanceHrList = null;
        if (cwsIhpConfiguratie.requiresFaillissementSurseance() && !includeAeh) {
            faillissementSurseanceHrList = faillissementSurseanceHrDao.findFaillissementSurseance(persoonId, beschouwingsmoment, cwsIhpConfiguratie);
        }

        return faillissementSurseanceHrList;
    }

    protected List<GemoedsbezwaardheidWg> getGemoedsbezwaardheidWgIfRequired(final String nrIhp,
                                                                           final boolean includeAeh,
                                                                           final LocalDateTime beschouwingsmoment,
                                                                           CwsIhpConfiguratie cwsIhpConfiguratie){
        List<GemoedsbezwaardheidWg> gemoedsbezwaardheidWgList = null;
        if (cwsIhpConfiguratie.requiresGemoedsbezwaardheid() && includeAeh) {
            gemoedsbezwaardheidWgList = gemoedsbezwaardheidWgDao.findGemoedsbezwaardheidByNrihp(nrIhp, beschouwingsmoment, cwsIhpConfiguratie);
        }

        return gemoedsbezwaardheidWgList;
    }

    protected List<MaatschappelijkeActiviteitHr> getMaatschappelijkeActiviteitHrIfRequired(final String nrIhp,
                                                                                         final String kvkNummer,
                                                                                         final LocalDateTime beschouwingsmoment,
                                                                                         CwsIhpConfiguratie cwsIhpConfiguratie){
        List<MaatschappelijkeActiviteitHr> maatschappelijkeActiviteitHrList = null;
        if (cwsIhpConfiguratie.requiresMaatschappelijkeActiviteit()) {
            if (StringUtils.hasText(kvkNummer)) {
                maatschappelijkeActiviteitHrList = findMaatschappelijkeActiviteitByKvkNummer(kvkNummer, beschouwingsmoment, cwsIhpConfiguratie);
            } else {
                maatschappelijkeActiviteitHrList = findMaatschappelijkeActiviteitByNrIhp(nrIhp, beschouwingsmoment, cwsIhpConfiguratie);
            }
        }

        return maatschappelijkeActiviteitHrList;
    }

    protected List<MaatschappelijkeActiviteitHr> findMaatschappelijkeActiviteitByKvkNummer(final String kvkNummer, final LocalDateTime beschouwingsmoment, CwsIhpConfiguratie cwsIhpConfiguratie) {
        List<MaatschappelijkeActiviteitHr> maatschappelijkeActiviteitHrList;

        maatschappelijkeActiviteitHrList = maatschappelijkeActiviteitHrDao.findMaatschappelijkeActiviteitByKvkNummer(kvkNummer, beschouwingsmoment, cwsIhpConfiguratie);
        maatschappelijkeActiviteitHrList.forEach(maatschappelijkeActiviteitHr -> findAndAttachMaatschappelijkeActiviteitMembers(maatschappelijkeActiviteitHr, beschouwingsmoment, cwsIhpConfiguratie));
        return maatschappelijkeActiviteitHrList;
    }

    protected List<MaatschappelijkeActiviteitHr> findMaatschappelijkeActiviteitByNrIhp(final String bsnOrRsin, final LocalDateTime beschouwingsmoment, CwsIhpConfiguratie cwsIhpConfiguratie) {
        List<MaatschappelijkeActiviteitHr> maatschappelijkeActiviteitHrList;

        maatschappelijkeActiviteitHrList = maatschappelijkeActiviteitHrDao.findMaatschappelijkeActiviteitByNummerIhp(bsnOrRsin, beschouwingsmoment, cwsIhpConfiguratie);
        maatschappelijkeActiviteitHrList.forEach(maatschappelijkeActiviteitHr -> findAndAttachMaatschappelijkeActiviteitMembers(maatschappelijkeActiviteitHr, beschouwingsmoment, cwsIhpConfiguratie));
        return maatschappelijkeActiviteitHrList;
    }

    private void findAndAttachMaatschappelijkeActiviteitMembers(final MaatschappelijkeActiviteitHr maatschappelijkeActiviteitHr, final LocalDateTime beschouwingsmoment, CwsIhpConfiguratie cwsIhpConfiguratie) {
        final String kvkNummer = maatschappelijkeActiviteitHr.getKvkNummer();
        if (cwsIhpConfiguratie.requiresSbiklasseMaatschappelijkeActiviteit()) {
            List<SbiklasseHr> sbiklasseHrList = sbiklasseDao.findSbiklasseMaatschappelijkeActiviteit(kvkNummer, beschouwingsmoment, cwsIhpConfiguratie);
            maatschappelijkeActiviteitHr.setSbiklasseHrList(sbiklasseHrList);
        }

        List<VestigingHandelsregisterHr> vestigingHandelsregisterHrList = findVestigingHandelsregister(kvkNummer, beschouwingsmoment, cwsIhpConfiguratie);
        maatschappelijkeActiviteitHr.setVestigingHandelsregisterHrList(vestigingHandelsregisterHrList);
    }

    protected List<VestigingHandelsregisterHr> findVestigingHandelsregister(final String kvkNummer, final LocalDateTime beschouwingsmoment, CwsIhpConfiguratie cwsIhpConfiguratie) {
        List<VestigingHandelsregisterHr> vestigingHandelsregisterHrList = null;

        if (cwsIhpConfiguratie.requiresVestigingHandelsregister()) {
            vestigingHandelsregisterHrList = vestigingHandelsregisterHrDao.findVestigingHandelsregister(kvkNummer, beschouwingsmoment, cwsIhpConfiguratie);
            vestigingHandelsregisterHrList.forEach(vestigingHandelsregisterHr -> {
                AdreshoudingHr adreshoudingHr = findAdresVestigingHandelsregister(kvkNummer, vestigingHandelsregisterHr.getVestigingsNummer(), beschouwingsmoment, cwsIhpConfiguratie);
                vestigingHandelsregisterHr.setAdreshoudingHr(adreshoudingHr);

                findAndAttachVestigingHandelsregisterMembers(vestigingHandelsregisterHr, beschouwingsmoment, cwsIhpConfiguratie);
            });
        }

        return vestigingHandelsregisterHrList;
    }


    protected AdreshoudingHr findAdresVestigingHandelsregister(final String kvkNummer, final Long vestigingsNummerId, final LocalDateTime beschouwingsmoment, final CwsIhpConfiguratie cwsIhpConfiguratie) {
        List<AdresNederlandHr> adresNederlandHrList = null;
        List<AdresBuitenlandHr> adresBuitenlandHrList = null;
        List<AdresBuitenlandOngestructureerdHr> adresBuitenlandOngestructureerdHrList = null;

        if (cwsIhpConfiguratie.requiresAnyAdresNederlandVestigingHandelsregister()) {
            adresNederlandHrList = adreshoudingHrDao.findAdresNederlandVestigingHandelsregister(kvkNummer, vestigingsNummerId, beschouwingsmoment, cwsIhpConfiguratie);
        }

        if (cwsIhpConfiguratie.requiresAnyAdresBuitenlandVestigingHandelsregister()) {
            adresBuitenlandHrList = adreshoudingHrDao.findAdresBuitenlandVestigingHandelsregister(kvkNummer, vestigingsNummerId, beschouwingsmoment, cwsIhpConfiguratie);
        }

        if (cwsIhpConfiguratie.requiresAdresBuitenlandOngestructureerdVestigingHandelsregister()) {
            adresBuitenlandOngestructureerdHrList = adreshoudingHrDao.findAdresBuitenlandOngestructureerdVestigingHandelsregister(kvkNummer, vestigingsNummerId, beschouwingsmoment, cwsIhpConfiguratie);
        }

        return AdreshoudingHr.builder()
                .adresNederlandHrList(adresNederlandHrList)
                .adresBuitenlandHrList(adresBuitenlandHrList)
                .adresBuitenlandOngestructureerdHrList(adresBuitenlandOngestructureerdHrList)
                .build();
    }

    protected void findAndAttachVestigingHandelsregisterMembers(final VestigingHandelsregisterHr vestigingHandelsregisterHr, final LocalDateTime beschouwingsmoment, final CwsIhpConfiguratie cwsIhpConfiguratie) {

        if (cwsIhpConfiguratie.requiresActiviteitHandelsregisterVestigingHandelsregister()) {
            final Long activiteitId = vestigingHandelsregisterHr.getActiviteitId();
            ActiviteitHandelsregisterHr activiteitHandelsregisterHr = activiteitHandelsregisterHrDao.findActiviteitHandelsregisterVestigingHandelsregister(activiteitId, beschouwingsmoment, cwsIhpConfiguratie);
            vestigingHandelsregisterHr.setActiviteitHandelsregisterHr(activiteitHandelsregisterHr);

            if (activiteitHandelsregisterHr != null && cwsIhpConfiguratie.requiresSbiklasseActiviteitHandelsregister()) {
                List<SbiklasseHr> sbiklasseHrList = sbiklasseDao.findSbiklasseActiviteitHandelsregister(activiteitId, beschouwingsmoment, cwsIhpConfiguratie);
                activiteitHandelsregisterHr.setSbiklasseHrList(sbiklasseHrList);
            }
        }

        if (cwsIhpConfiguratie.requiresOnderneming()) {
            List<OndernemingHr> ondernemingList = ondernemingHrDao.findOnderneming(vestigingHandelsregisterHr.getKvkNummer(), vestigingHandelsregisterHr.getVestigingsNummer(), beschouwingsmoment, cwsIhpConfiguratie);
            vestigingHandelsregisterHr.setOndernemingHrList(ondernemingList);

            if (cwsIhpConfiguratie.requiresSbiklasseOnderneming()) {
                ondernemingList.forEach(ondernemingHr -> {
                    List<SbiklasseHr> sbiklasseHrList = sbiklasseDao.findSbiklasseOnderneming(ondernemingHr.getKvkNummer(), beschouwingsmoment, cwsIhpConfiguratie);
                    ondernemingHr.setSbiklasseHrList(sbiklasseHrList);
                });
            }

            if (cwsIhpConfiguratie.requiresHandelsnaamOnderneming()) {
                ondernemingList.forEach(ondernemingHr -> {
                    List<HandelsnaamHr> handelsnaamHrList = handelsnaamHrDao.findHandelsnaamOnderneming(ondernemingHr.getKvkNummer(), beschouwingsmoment, cwsIhpConfiguratie);
                    ondernemingHr.setHandelsnaamHrList(handelsnaamHrList);
                });
            }
        }

        if (cwsIhpConfiguratie.requiresHandelsnaamVestigingHandelsregister()) {
            List<HandelsnaamHr> handelsnaamHrList = handelsnaamHrDao.findHandelsnaamVestigingHandelsregister(vestigingHandelsregisterHr.getKvkNummer(), vestigingHandelsregisterHr.getVestigingsNummer(), beschouwingsmoment, cwsIhpConfiguratie);
            vestigingHandelsregisterHr.setHandelsnaamHrList(handelsnaamHrList);
        }
    }



    protected PersoonHandelsregisterHr getPersoonHandelsregisterHrIfRequired(final Long persoonId,
                                                                           final LocalDateTime beschouwingsmoment,
                                                                           PersoonHr persoonHr,
                                                                           CwsIhpConfiguratie cwsIhpConfiguratie){
        PersoonHandelsregisterHr persoonHandelsregisterHr = null;
        if (cwsIhpConfiguratie.requiresPersoonHandelsregister() && persoonHr.isPersoonHandelsregister()) {
            persoonHandelsregisterHr = persoonHandelsregisterHrDao.findPersoonHandelsregisterHr(persoonId, persoonHr.getNaamPersoonId(), beschouwingsmoment, cwsIhpConfiguratie);
        }

        return persoonHandelsregisterHr;
    }

    protected List<RechtsvormHr> getRechtsvormHrIfRequired(final Long persoonId,
                                                         final LocalDateTime beschouwingsmoment,
                                                         CwsIhpConfiguratie cwsIhpConfiguratie){
        List<RechtsvormHr> rechtsvormHrList = null;
        if (cwsIhpConfiguratie.requiresRechtsvorm()) {
            rechtsvormHrList = rechtsvormHrDao.findRechtsvorm(persoonId, beschouwingsmoment, cwsIhpConfiguratie);
        }

        return rechtsvormHrList;
    }
}
