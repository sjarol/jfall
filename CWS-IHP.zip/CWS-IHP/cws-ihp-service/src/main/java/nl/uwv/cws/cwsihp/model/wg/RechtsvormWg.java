package nl.uwv.cws.cwsihp.model.wg;

import lombok.Builder;
import lombok.Getter;

@Builder
@Getter
public class RechtsvormWg {
    private String codeRechtsvorm;
    private Long datumAanvangRechtsvorm;
    private Long datumEindeRechtsvorm;
}
