package nl.uwv.cws.cwsihp.dao.mapper;

import nl.uwv.cws.common.dao.mapper.CwsRowMapper;
import nl.uwv.cws.cwsihp.model.hr.NatuurlijkPersoonHr;
import nl.uwv.cws.cwsihp.model.ihp.HuwelijkGeregistreerdPartnerIhp;
import org.springframework.stereotype.Component;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Component
public class NatuurlijkPersoonHrRowMapper extends CwsRowMapper<NatuurlijkPersoonHr> {

    @Override
    public NatuurlijkPersoonHr mapRow(final ResultSet resultSet, final List<String> attributen) throws SQLException {

        // NATUURLIJKPERSOON
        final Integer burgerservicenummer = readApplicableNullableInteger(attributen, "BSN", resultSet);
        final String voorletters = readApplicableString(attributen, "VOORLETTERS", resultSet);
        final String voornamen = readApplicableString(attributen, "VOORNAMEN", resultSet);
        final String voorvoegsel = readApplicableString(attributen, "VOORVOEGSEL", resultSet);
        final String achternaam = readApplicableString(attributen, "ACHTERNAAM", resultSet);
        final Integer codeAanduidingNaamgebruik = readApplicableNullableInteger(attributen, "CD_AANDUIDING_NAAMGEBRUIK_CGM", resultSet);
        final Date geboorteDatum = readApplicableDate(attributen, "GEBOORTEDATUM_CGM", resultSet);
        final Integer codeFictieveGeboortedatum = readApplicableNullableInteger(attributen, "CD_GEBOORTEDATUM_CGM", resultSet);
        final String geslacht = readApplicableString(attributen, "GESLACHT", resultSet);

        // HUWELIJK/GEREGISTREERD PARTNERSCHAP
        final String voorvoegselGeslachtsnaamPartner = readApplicableString(attributen, "VOORV_GESLACHTSNM_PARTNER", resultSet);
        final String geslachtsnaamPartner = readApplicableString(attributen, "GESLACHTSNAAMPARTNER", resultSet);

        NatuurlijkPersoonHr.NatuurlijkPersoonHrBuilder natuurlijkPersoonHrBuilder = NatuurlijkPersoonHr.builder();
        natuurlijkPersoonHrBuilder.burgerservicenummer(burgerservicenummer)
                .voorletters(voorletters)
                .voornamen(voornamen)
                .voorvoegsel(voorvoegsel)
                .achternaam(achternaam)
                .codeAanduidingNaamgebruik(codeAanduidingNaamgebruik)
                .geboorteDatum(geboorteDatum)
                .codeFictieveGeboortedatum(codeFictieveGeboortedatum)
                .geslacht(geslacht);

        HuwelijkGeregistreerdPartnerIhp huwelijkGeregistreerdPartnerIhp = HuwelijkGeregistreerdPartnerIhp.builder()
                .voorvoegselGeslachtsnaamPartner(voorvoegselGeslachtsnaamPartner)
                .geslachtsnaamPartner(geslachtsnaamPartner)
                .build();

        return natuurlijkPersoonHrBuilder
                .huwelijkGeregistreerdPartnerIhp(huwelijkGeregistreerdPartnerIhp)
                .build();
    }
}
