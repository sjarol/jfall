package nl.uwv.cws.cwsihp.model.configuratie;

import nl.uwv.cws.common.model.configuratie.BaseCwsFilterType;

public enum CwsIhpFilterType implements BaseCwsFilterType {
    BEEINDIGD_ADRES_UITSLUITEN_IHP;

    @Override
    public String filterName() {
        return name();
    }

    @Override
    public String levCode() {
        return "CWS-IHP";
    }
}
