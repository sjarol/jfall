package nl.uwv.cws.cwsihp.webservice.mapper;

import nl.uwv.cws.common.VisibleForTesting;
import nl.uwv.cws.cwsihp.model.wg.VoortzettingsrelatieOpvolgerWg;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0007.CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.VoortzettingsrelatieOpvolger;
import org.springframework.stereotype.Component;

import static nl.uwv.cws.common.util.MapperUtil.collectNonEmptyObject;
import static nl.uwv.cws.common.util.NullValueUtil.extractBigDecimalValueOrNull;
import static nl.uwv.cws.common.util.NullValueUtil.extractStringValueOrNull;
import static nl.uwv.cws.cwsihp.model.CwsIhpConstants.*;

@Component
public class VoortzettingsrelatieOpvolgerMapper extends BaseMapper {

    @VisibleForTesting
    protected VoortzettingsrelatieOpvolger mapToJaxbVoortzettingsrelatieOpvolger(VoortzettingsrelatieOpvolgerWg voortzettingsrelatieOpvolgerWg) {
        VoortzettingsrelatieOpvolger voortzettingsrelatieOpvolger = new VoortzettingsrelatieOpvolger();

        final Long datumAanvangVoortzettingsrelatieOpvolger = voortzettingsrelatieOpvolgerWg.getDatumAanvangVoortzettingsrelatieOpvolger();
        final Double percentageLoonsomOvergegaan = voortzettingsrelatieOpvolgerWg.getPercentageLoonsomOvergegaan();
        final String lhnrOpvolger = voortzettingsrelatieOpvolgerWg.getLhnrOpvolger();

        ruleExecutor.setTransformedValue(voortzettingsrelatieOpvolger, XSD_DATBVOORTZETTINGSRELATIE, extractStringValueOrNull(datumAanvangVoortzettingsrelatieOpvolger));
        ruleExecutor.setTransformedValue(voortzettingsrelatieOpvolger, XSD_PERCLOONSOMOVERGEGAANINOPVOLGER, extractBigDecimalValueOrNull(percentageLoonsomOvergegaan));
        ruleExecutor.setTransformedValue(voortzettingsrelatieOpvolger, XSD_LOONHEFFINGENNROPVOLGER, lhnrOpvolger);

        return collectNonEmptyObject(voortzettingsrelatieOpvolger);
    }
}
