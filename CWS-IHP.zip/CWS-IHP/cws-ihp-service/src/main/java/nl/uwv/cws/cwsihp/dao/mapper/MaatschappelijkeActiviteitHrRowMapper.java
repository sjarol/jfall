package nl.uwv.cws.cwsihp.dao.mapper;

import nl.uwv.cws.common.dao.mapper.CwsRowMapper;
import nl.uwv.cws.cwsihp.model.hr.MaatschappelijkeActiviteitHr;
import org.springframework.stereotype.Component;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import static nl.uwv.cws.cwsihp.util.DateUtil.setDatumEinde;

@Component
public class MaatschappelijkeActiviteitHrRowMapper extends CwsRowMapper<MaatschappelijkeActiviteitHr> {

    @Override
    public MaatschappelijkeActiviteitHr mapRow(ResultSet resultSet, List<String> attributen) throws SQLException {

        final String kvkNummer = resultSet.getString("KVK_NUMMER");
        final boolean configurationIncludesKvkNummer = isAttributeApplicable(attributen,"KVK_NUMMER");

        final Date datumAanvang = readApplicableDate(attributen, "DATUM_AANVANG_CGM", resultSet);
        final Integer codeFictieveDatumAanvang = readApplicableNullableInteger(attributen, "CD_DATUM_AANVANG_CGM", resultSet);
        final Date datumEinde = setDatumEinde(readApplicableDate(attributen, "DATUM_EINDE_CGM", resultSet), resultSet.getInt("CD_DATUM_EINDE_CGM"));
        final Integer codeFictieveDatumEinde = readApplicableNullableInteger(attributen, "CD_DATUM_EINDE_CGM", resultSet);

        return MaatschappelijkeActiviteitHr.builder()
                .kvkNummer(String.valueOf(kvkNummer))
                .configurationIncludesKvkNummer(configurationIncludesKvkNummer)
                .datumAanvangMaatschappelijkeActiviteit(datumAanvang)
                .codeFictieveDatumAanvang(codeFictieveDatumAanvang)
                .datumEindeMaatschappelijkeActiviteit(datumEinde)
                .codeFictieveDatumEinde(codeFictieveDatumEinde)
                .build();
    }
}
