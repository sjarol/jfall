package nl.uwv.cws.cwsihp.model.hr;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.sql.Date;

@Builder
@Getter
@Setter
public class RechtspersoonHr {

    private Long activiteitId;

    private String statutaireZetel;
    private Date datumAanvangStatutaireZetel;
    private Integer codeFictieveDatumAanvang;

    private ActiviteitHandelsregisterHr activiteitHandelsregisterHr;
}
