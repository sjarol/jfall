package nl.uwv.cws.cwsihp.util;

import java.sql.Date;

import static nl.uwv.cws.common.util.ConverterUtil.totDatumToTotEnMetDatum;
import static nl.uwv.cws.common.util.ConverterUtil.totEnMetDatumOneindigToNull;

public final class DateUtil {

    private DateUtil() {}

    public static Date setDatumEinde(Date input, Integer codeFictief) {
        Date datumEinde;
        if (codeFictief.equals(0)) {
            datumEinde = totDatumToTotEnMetDatum(input);
        } else {
            datumEinde = totEnMetDatumOneindigToNull(input);
        }
        return datumEinde;
    }
}
