package nl.uwv.cws.cwsihp.dao.ihp;

public final class AdreshoudingWgQueries {

    private AdreshoudingWgQueries() { }

    static final String CONDITION_EXCLUDE_BEEINDIGD_ADRES =
            "AND (adr.dateind IS NULL " +
                    "OR TO_DATE(adr.dateind, 'YYYYMMDD') >= TRUNC(SYSDATE)) ";
}
