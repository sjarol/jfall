package nl.uwv.cws.cwsihp.dao.mapper;

import nl.uwv.cws.common.dao.mapper.CwsRowMapper;
import nl.uwv.cws.common.util.NullValueUtil;
import nl.uwv.cws.cwsihp.model.hr.NietNatuurlijkPersoonHr;
import org.springframework.stereotype.Component;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import static nl.uwv.cws.cwsihp.util.DateUtil.setDatumEinde;

@Component
public class NietNatuurlijkPersoonHrRowMapper extends CwsRowMapper<NietNatuurlijkPersoonHr> {

    @Override
    public NietNatuurlijkPersoonHr mapRow(final ResultSet resultSet, final List<String> attributen) throws SQLException {
        final Long rechtspersoonId = NullValueUtil.getLongOrNull(resultSet, "RECHTSPERSOON_ID");
        final Long buitenlandseVennootschapId = NullValueUtil.getLongOrNull(resultSet, "BUITENLANDSEVENNOOTSCHAP_ID");

        final Integer rsin = readApplicableNullableInteger(attributen, "RSIN", resultSet);
        final Date datumAanvang = readApplicableDate(attributen, "DATUM_AANVANG_CGM", resultSet);
        final Integer codeFictieveDatumAanvang = readApplicableNullableInteger(attributen, "CD_DATUM_AANVANG_CGM", resultSet);
        final Date datumEinde = setDatumEinde(readApplicableDate(attributen, "DATUM_EINDE_CGM", resultSet), resultSet.getInt("CD_DATUM_EINDE_CGM"));
        final Integer codeFictieveDatumEinde = readApplicableNullableInteger(attributen, "CD_DATUM_EINDE_CGM", resultSet);
        final String volledigeNaam = readApplicableString(attributen, "VOLLEDIGENAAM", resultSet);

        return NietNatuurlijkPersoonHr.builder()
                .rsin(rsin)
                .datumAanvangNietNatuurlijkPersoon(datumAanvang)
                .codeFictieveDatumAanvang(codeFictieveDatumAanvang)
                .datumEindeNietNatuurlijkPersoon(datumEinde)
                .codeFictieveDatumEinde(codeFictieveDatumEinde)
                .volledigeNaamNietNatuurlijkPersoon(volledigeNaam)
                .rechtspersoonId(rechtspersoonId)
                .buitenlandseVennootschapId(buitenlandseVennootschapId)
                .build();
    }
}
