package nl.uwv.cws.cwsihp.webservice.rule.transformer;

import nl.uwv.cws.common.model.rule.AttributeRuleProperties;
import nl.uwv.cws.common.webservice.rule.transformer.RuleValueTransformer;
import nl.uwv.cws.cwsihp.model.rule.CwsIhpAttributeRule;
import org.springframework.stereotype.Component;

import static nl.uwv.cws.cwsihp.model.rule.CwsIhpAttributeRule.AFKAPPEN_OBV_SIZE_MAX;
import static org.apache.commons.lang3.StringUtils.truncate;

@Component
public class AfkappenObvSizeMaxTransformer implements RuleValueTransformer<String, String> {

    @Override
    public CwsIhpAttributeRule getTransformRule() {
        return AFKAPPEN_OBV_SIZE_MAX;
    }

    @Override
    public String transform(String originalValue, AttributeRuleProperties attributeRuleProperties) {
        return truncate(originalValue, attributeRuleProperties.getSizeMax());
    }
}
