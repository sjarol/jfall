package nl.uwv.cws.cwsihp.model.wg;

import lombok.Builder;
import lombok.Getter;

@Builder
@Getter
public class FaillissementSurseanceWg {
    private String codeFaillissementSurseance;
    private String codeRedenEindeFaillissementSurseance;
    private Long datumAanvangFaillissementSurseance;
    private Long datumEindeFaillissementSurseance;
}
