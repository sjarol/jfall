package nl.uwv.cws.cwsihp.model.hr;

import lombok.Builder;
import lombok.Getter;

import java.sql.Date;

@Builder
@Getter
public class FaillissementSurseanceHr {
    private String codeFaillissementSurseance;
    private Date datumAanvangFaillissementSurseance;
    private Integer codeFictieveDatumAanvang;
    private Date datumEindeFaillissementSurseance;
    private Integer codeFictieveDatumEinde;
}
