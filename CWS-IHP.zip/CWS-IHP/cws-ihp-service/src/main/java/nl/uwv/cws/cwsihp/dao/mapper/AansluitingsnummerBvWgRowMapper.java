package nl.uwv.cws.cwsihp.dao.mapper;

import nl.uwv.cws.common.dao.mapper.CwsRowMapper;
import nl.uwv.cws.cwsihp.model.wg.AansluitingsnummerBvWg;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Component
public class AansluitingsnummerBvWgRowMapper extends CwsRowMapper<AansluitingsnummerBvWg> {

    @Override
    public AansluitingsnummerBvWg mapRow(final ResultSet resultSet, final List<String> attributen) throws SQLException {
        final Long codeSectorOsv = readApplicableNullableLong(attributen, "CODESECTOROSV", resultSet);
        final Long risicoPremiegroep = readApplicableNullableLong(attributen, "RISICOPREMIEGROEP", resultSet);
        final Long aansluitingsnummerBv = readApplicableNullableLong(attributen, "AANSLUITINGSNRBV", resultSet);
        final Long datumAanvangAansluitingsnummerBv = readApplicableNullableLong(attributen, "DATAANV", resultSet);

        return AansluitingsnummerBvWg.builder()
                .codeSectorOsv(codeSectorOsv)
                .risicoPremiegroep(risicoPremiegroep)
                .aansluitingsnummerBv(aansluitingsnummerBv)
                .datumAanvangAansluitingsnummerBv(datumAanvangAansluitingsnummerBv)
                .build();
    }
}
