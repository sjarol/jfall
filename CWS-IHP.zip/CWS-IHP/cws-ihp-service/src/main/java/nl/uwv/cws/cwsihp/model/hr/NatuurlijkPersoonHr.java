package nl.uwv.cws.cwsihp.model.hr;

import lombok.Builder;
import lombok.Getter;
import nl.uwv.cws.cwsihp.model.ihp.HuwelijkGeregistreerdPartnerIhp;

import java.sql.Date;

@Builder
@Getter
public class NatuurlijkPersoonHr {

    private Integer burgerservicenummer;
    private String voorletters;
    private String voornamen;
    private String voorvoegsel;
    private String achternaam;
    private Integer codeAanduidingNaamgebruik;
    private Date geboorteDatum;
    private Integer codeFictieveGeboortedatum;
    private String geslacht;

    private HuwelijkGeregistreerdPartnerIhp huwelijkGeregistreerdPartnerIhp;
}
