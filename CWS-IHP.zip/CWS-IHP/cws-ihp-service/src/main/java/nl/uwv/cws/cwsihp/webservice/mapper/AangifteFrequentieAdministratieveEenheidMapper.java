package nl.uwv.cws.cwsihp.webservice.mapper;

import nl.uwv.cws.common.VisibleForTesting;
import nl.uwv.cws.cwsihp.model.wg.AangifteFrequentieAdministratieveEenheidWg;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0007.CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.AangifteFrequentieAdminEenheid;
import org.springframework.stereotype.Component;

import static nl.uwv.cws.common.util.MapperUtil.collectNonEmptyObject;
import static nl.uwv.cws.common.util.NullValueUtil.extractStringValueOrNull;
import static nl.uwv.cws.cwsihp.model.CwsIhpConstants.*;

@Component
public class AangifteFrequentieAdministratieveEenheidMapper extends BaseMapper {

    @VisibleForTesting
    protected AangifteFrequentieAdminEenheid mapToJaxbAangifteFrequentieAdministratieveEenheid(AangifteFrequentieAdministratieveEenheidWg aangifteFrequentieAdministratieveEenheidWg) {
        AangifteFrequentieAdminEenheid aangifteFrequentieAdminEenheid = new AangifteFrequentieAdminEenheid();

        final String codeAangifteFrequentieAdministratieveEenheid = aangifteFrequentieAdministratieveEenheidWg.getCodeAangifteFrequentieAdministratieveEenheid();
        final Long datumAanvangAangifteFrequentieAdministratieveEenheid = aangifteFrequentieAdministratieveEenheidWg.getDatumAanvangAangifteFrequentieAdministratieveEenheid();
        final Long datumEindeAangifteFrequentieAdministratieveEenheid = aangifteFrequentieAdministratieveEenheidWg.getDatumEindeAangifteFrequentieAdministratieveEenheid();

        ruleExecutor.setTransformedValue(aangifteFrequentieAdminEenheid, XSD_CDAANGIFTEFREQUENTIEADMINEENHEID, codeAangifteFrequentieAdministratieveEenheid);
        ruleExecutor.setTransformedValue(aangifteFrequentieAdminEenheid, XSD_DATBAANGIFTEFREQADMINEENHEID, extractStringValueOrNull(datumAanvangAangifteFrequentieAdministratieveEenheid));
        ruleExecutor.setTransformedValue(aangifteFrequentieAdminEenheid, XSD_DATEAANGIFTEFREQADMINEENHEID, extractStringValueOrNull(datumEindeAangifteFrequentieAdministratieveEenheid));

        return collectNonEmptyObject(aangifteFrequentieAdminEenheid);
    }
}
