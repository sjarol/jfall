package nl.uwv.cws.cwsihp.dao.ihp;

import nl.uwv.cws.cwsihp.dao.mapper.PersoonWgRowMapper;
import nl.uwv.cws.cwsihp.model.wg.PersoonWg;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public class PersoonWgDao extends BaseDao {
	
	@Autowired
	private PersoonWgRowMapper rowMapper;

	public List<PersoonWg> findPersoonWgByFinr(String finr, LocalDateTime beschouwingsmoment) {
		final Timestamp beschouwingsmomentTimestamp = Timestamp.valueOf(beschouwingsmoment);
		String sql =
				"  SELECT per.per_id AS per_id " +
				"  FROM wga_persoon per " +
				"  LEFT OUTER JOIN wga_nnp_persoon_his nnp " +
				"  ON nnp.per_id = per.per_id " +
				"  AND nnp.his_ts_in  <= :beschouwingsmoment " +
				"  AND nnp.his_ts_end > :beschouwingsmoment " +
				"  WHERE per.finr = :finr";

		SqlParameterSource namedParameters = new MapSqlParameterSource()
				.addValue("finr", finr)
				.addValue("beschouwingsmoment", beschouwingsmomentTimestamp);

		return jdbcTemplate.query(sql, namedParameters, rowMapper);
	}

	public List<PersoonWg> findPersoonWgBySofinr(String sofinr, LocalDateTime beschouwingsmoment) {
		final Timestamp beschouwingsmomentTimestamp = Timestamp.valueOf(beschouwingsmoment);
		String sql =
				"  SELECT per.per_id AS per_id " +
				"  FROM wga_persoon per " +
				"  LEFT OUTER JOIN wga_npn_persoon_his npn " +
				"  ON npn.per_id = per.per_id " +
				"  AND npn.his_ts_in  <= :beschouwingsmoment " +
				"  AND npn.his_ts_end > :beschouwingsmoment " +
				"  WHERE per.sofinr = :sofinr";

		SqlParameterSource namedParameters = new MapSqlParameterSource()
				.addValue("sofinr", sofinr)
				.addValue("beschouwingsmoment", beschouwingsmomentTimestamp);

		return jdbcTemplate.query(sql, namedParameters, rowMapper);
	}
}
