package nl.uwv.cws.cwsihp.webservice.mapper;

import nl.uwv.cws.cwsihp.model.hr.MaatschappelijkeActiviteitHr;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0007.CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.sql.Date;

import static nl.uwv.cws.common.util.MapperUtil.collectNonEmptyObject;
import static nl.uwv.cws.common.util.MapperUtil.mapToJaxbListIfNotEmpty;
import static nl.uwv.cws.common.util.NullValueUtil.extractStringFromDateValueOrNull;
import static nl.uwv.cws.common.util.NullValueUtil.extractStringValueOrNull;
import static nl.uwv.cws.cwsihp.model.CwsIhpConstants.*;

@Component
public class MaatschappelijkeActiviteitMapper extends BaseMapper {

    @Autowired
    private VestigingHandelsregisterMapper vestigingHandelsregisterMapper;

    @Autowired
    private SbiklasseMapper sbiklasseMapper;


    public MaatschappelijkeActiviteit mapToJaxbMaatschappelijkeActiviteit(MaatschappelijkeActiviteitHr maatschappelijkeActiviteitHr) {
        MaatschappelijkeActiviteit maatschappelijkeActiviteit = new MaatschappelijkeActiviteit();
        mapToJaxbMaatschappelijkeActiviteit(maatschappelijkeActiviteitHr, maatschappelijkeActiviteit);

        mapToJaxbListIfNotEmpty(maatschappelijkeActiviteitHr.getSbiklasseHrList(),
                maatschappelijkeActiviteit.getSbiklasse(),
                sbiklasseMapper::mapToJaxbSbiklasseMaatschappelijkeActiviteit);

        mapToJaxbListIfNotEmpty(maatschappelijkeActiviteitHr.getVestigingHandelsregisterHrList(),
                maatschappelijkeActiviteit.getVestigingHandelsregister(),
                vestigingHandelsregisterMapper::mapToJaxbVestigingHandelsregister);

        return collectNonEmptyObject(maatschappelijkeActiviteit);
    }

    private void mapToJaxbMaatschappelijkeActiviteit(MaatschappelijkeActiviteitHr maatschappelijkeActiviteitHr, MaatschappelijkeActiviteit maatschappelijkeActiviteit) {
        String kvkNummer = null;
        if (maatschappelijkeActiviteitHr.isConfigurationIncludesKvkNummer()) {
            kvkNummer = maatschappelijkeActiviteitHr.getKvkNummer();
        }
        final Date datumAanvangMaatschappelijkeActiviteit = maatschappelijkeActiviteitHr.getDatumAanvangMaatschappelijkeActiviteit();
        Integer codeFictieveDatumAanvang = null;
        if (datumAanvangMaatschappelijkeActiviteit != null) {
            codeFictieveDatumAanvang = maatschappelijkeActiviteitHr.getCodeFictieveDatumAanvang();
        }

        final Date datumEindeMaatschappelijkeActiviteit = maatschappelijkeActiviteitHr.getDatumEindeMaatschappelijkeActiviteit();
        Integer codeFictieveDatumEinde = null;
        if (datumEindeMaatschappelijkeActiviteit != null) {
            codeFictieveDatumEinde = maatschappelijkeActiviteitHr.getCodeFictieveDatumEinde();
        }

        ruleExecutor.setTransformedValue(maatschappelijkeActiviteit, XSD_KVKNR, kvkNummer);
        ruleExecutor.setTransformedValue(maatschappelijkeActiviteit, XSD_DATBMAATSCHAPPELIJKEACTIVITEIT, extractStringFromDateValueOrNull(datumAanvangMaatschappelijkeActiviteit));
        ruleExecutor.setTransformedValue(maatschappelijkeActiviteit, XSD_CDFICTIEVEDATB, extractStringValueOrNull(codeFictieveDatumAanvang));
        ruleExecutor.setTransformedValue(maatschappelijkeActiviteit, XSD_DATEMAATSCHAPPELIJKEACTIVITEIT, extractStringFromDateValueOrNull(datumEindeMaatschappelijkeActiviteit));
        ruleExecutor.setTransformedValue(maatschappelijkeActiviteit, XSD_CDFICTIEVEDATE, extractStringValueOrNull(codeFictieveDatumEinde));
    }
}
