package nl.uwv.cws.cwsihp.webservice.mapper;

import nl.uwv.cws.cwsihp.model.hr.VestigingHandelsregisterHr;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0007.CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.sql.Date;
import java.util.Optional;

import static nl.uwv.cws.common.util.MapperUtil.collectNonEmptyObject;
import static nl.uwv.cws.common.util.MapperUtil.mapToJaxbListIfNotEmpty;
import static nl.uwv.cws.common.util.NullValueUtil.extractStringFromDateValueOrNull;
import static nl.uwv.cws.common.util.NullValueUtil.extractStringValueOrNull;
import static nl.uwv.cws.cwsihp.model.CwsIhpConstants.*;

@Component
public class VestigingHandelsregisterMapper extends BaseMapper {

    @Autowired
    private AdreshoudingMapper adreshoudingMapper;

    @Autowired
    private ActiviteitHandelsregisterMapper activiteitHandelsregisterMapper;

    @Autowired
    private OndernemingMapper ondernemingMapper;

    @Autowired
    private HandelsnaamMapper handelsnaamMapper;

    public VestigingHandelsregister mapToJaxbVestigingHandelsregister(final VestigingHandelsregisterHr vestigingHandelsregisterHr) {
        VestigingHandelsregister vestigingHandelsregister = new VestigingHandelsregister();
        mapToJaxbVestigingHandelsregister(vestigingHandelsregisterHr, vestigingHandelsregister);

        mapToJaxbListIfNotEmpty(vestigingHandelsregisterHr.getAdreshoudingHr().getAdresNederlandHrList(),
                vestigingHandelsregister.getAdreshouding(),
                adreshoudingMapper::mapToJaxbAdresNederlandUhrVestigingHandelsregister);

        mapToJaxbListIfNotEmpty(vestigingHandelsregisterHr.getAdreshoudingHr().getAdresBuitenlandHrList(),
                vestigingHandelsregister.getAdreshouding(),
                adreshoudingMapper::mapToJaxbAdresBuitenlandVestigingHandelsregister);

        mapToJaxbListIfNotEmpty(vestigingHandelsregisterHr.getAdreshoudingHr().getAdresBuitenlandOngestructureerdHrList(),
                vestigingHandelsregister.getAdreshouding(),
                adreshoudingMapper::mapToJaxbAdresBuitenlandOngestructureerdVestigingHandelsregister);

        mapToJaxbListIfNotEmpty(vestigingHandelsregisterHr.getOndernemingHrList(),
                vestigingHandelsregister.getOnderneming(),
                ondernemingMapper::mapToJaxbOnderneming);

        mapToJaxbListIfNotEmpty(vestigingHandelsregisterHr.getHandelsnaamHrList(),
                vestigingHandelsregister.getHandelsnaam(),
                handelsnaamMapper::mapToJaxbHandelsnaamVestigingHandelsregister);

        Optional<VestigingHandelsregister.ActiviteitHandelsregister> activiteitHandelsregister = activiteitHandelsregisterMapper.mapToJaxbActiviteitHandelsregisterVestigingHandelsregister(vestigingHandelsregisterHr.getActiviteitHandelsregisterHr());
        activiteitHandelsregister.ifPresent(vestigingHandelsregister::setActiviteitHandelsregister);

        return collectNonEmptyObject(vestigingHandelsregister);
    }

    private void mapToJaxbVestigingHandelsregister(VestigingHandelsregisterHr vestigingHandelsregisterHr, VestigingHandelsregister vestigingHandelsregister) {
        Long vestigingsNummer = null;
        if (vestigingHandelsregisterHr.isConfigurationIncludesVestigingsNummer()) {
            vestigingsNummer = vestigingHandelsregisterHr.getVestigingsNummer();
        }

        final String eersteHandelsnaam = vestigingHandelsregisterHr.getEersteHandelsnaam();
        final Date datumAanvangVestigingHandelsregister = vestigingHandelsregisterHr.getDatumAanvangVestigingHandelsregister();
        Integer codeFictieveDatumAanvang = null;
        if (datumAanvangVestigingHandelsregister != null) {
            codeFictieveDatumAanvang = vestigingHandelsregisterHr.getCodeFictieveDatumAanvang();
        }
        final Date datumEindeVestigingHandelsregister = vestigingHandelsregisterHr.getDatumEindeVestigingHandelsregister();
        Integer codeFictieveDatumEinde = null;
        if (datumEindeVestigingHandelsregister != null) {
            codeFictieveDatumEinde = vestigingHandelsregisterHr.getCodeFictieveDatumEinde();
        }

        ruleExecutor.setTransformedValue(vestigingHandelsregister, XSD_VESTIGINGSNRHANDELSREGISTER, extractStringValueOrNull(vestigingsNummer));
        ruleExecutor.setTransformedValue(vestigingHandelsregister, XSD_EERSTEHANDELSNAAM, eersteHandelsnaam);
        ruleExecutor.setTransformedValue(vestigingHandelsregister, XSD_DATBVESTIGINGHANDELSREGISTER, extractStringFromDateValueOrNull(datumAanvangVestigingHandelsregister));
        ruleExecutor.setTransformedValue(vestigingHandelsregister, XSD_CDFICTIEVEDATB, extractStringValueOrNull(codeFictieveDatumAanvang));
        ruleExecutor.setTransformedValue(vestigingHandelsregister, XSD_DATEVESTIGINGHANDELSREGISTER, extractStringFromDateValueOrNull(datumEindeVestigingHandelsregister));
        ruleExecutor.setTransformedValue(vestigingHandelsregister, XSD_CDFICTIEVEDATE, extractStringValueOrNull(codeFictieveDatumEinde));
    }
}
