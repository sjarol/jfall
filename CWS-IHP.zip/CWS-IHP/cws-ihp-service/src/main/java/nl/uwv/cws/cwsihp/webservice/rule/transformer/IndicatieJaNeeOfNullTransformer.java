package nl.uwv.cws.cwsihp.webservice.rule.transformer;

import nl.uwv.cws.common.model.rule.AttributeRuleProperties;
import nl.uwv.cws.common.webservice.rule.transformer.RuleValueTransformer;
import nl.uwv.cws.cwsihp.model.rule.CwsIhpAttributeRule;
import org.springframework.stereotype.Component;

import static nl.uwv.cws.cwsihp.model.rule.CwsIhpAttributeRule.INDICATIE_JA_NEE_OF_NULL;

@Component
public class IndicatieJaNeeOfNullTransformer implements RuleValueTransformer<String, String> {
    @Override
    public CwsIhpAttributeRule getTransformRule() {
        return INDICATIE_JA_NEE_OF_NULL;
    }

    @Override
    public String transform(String originalValue, AttributeRuleProperties attributeRuleProperties) {
        String result = null;
        if (originalValue != null) {
            if (originalValue.equalsIgnoreCase("J")) {
                result = "1";
            } else if (originalValue.equalsIgnoreCase("N")) {
                result = "2";
            }
        }
        return result;
    }
}
