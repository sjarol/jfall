package nl.uwv.cws.cwsihp.model.hr;

import lombok.Builder;
import lombok.Getter;

import java.sql.Date;

@Builder
@Getter
public class PersoonHandelsregisterHr {
    private Date datumAanvangPersoonHandelsregister;
    private Integer codeFictieveDatumAanvang;
    private Date datumEindePersoonHandelsregister;
    private Integer codeFictieveDatumEinde;
    private String naamPersoonHandelsregister;
    private String volledigeNaamPersoonHandelsregister;
}
