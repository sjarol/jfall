package nl.uwv.cws.cwsihp.model.wg;

import lombok.Builder;
import lombok.Getter;

@Builder
@Getter
public class SectorRisicogroepWg {
    private String codeRisicopremiegroep;
    private String codeSectorOsv;
    private Long datumAanvangSectorRisicogroep;
    private Long datumEindeSectorRisicogroep;
}
