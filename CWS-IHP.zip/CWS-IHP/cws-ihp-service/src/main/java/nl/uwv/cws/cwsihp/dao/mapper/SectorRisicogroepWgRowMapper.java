package nl.uwv.cws.cwsihp.dao.mapper;

import nl.uwv.cws.common.dao.mapper.CwsRowMapper;
import nl.uwv.cws.cwsihp.model.wg.SectorRisicogroepWg;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import static nl.uwv.cws.common.util.ConverterUtil.totDatumToTotEnMetDatum;

@Component
public class SectorRisicogroepWgRowMapper extends CwsRowMapper<SectorRisicogroepWg> {

    @Override
    public SectorRisicogroepWg mapRow(final ResultSet resultSet, final List<String> attributen) throws SQLException {
        final String codeRisicopremiegroep = readApplicableString(attributen, "SECT_RISICOGRP_CODE", resultSet);
        final String codeSectorOsv = readApplicableString(attributen, "SECT_CODE", resultSet);
        final Long datumAanvangSectorRisicogroep = readApplicableNullableLong(attributen, "DATAANV", resultSet);
        final Long datumEindeSectorRisicogroep = totDatumToTotEnMetDatum(readApplicableNullableLong(attributen, "DATEIND", resultSet));

        return SectorRisicogroepWg.builder()
                .codeRisicopremiegroep(codeRisicopremiegroep)
                .codeSectorOsv(codeSectorOsv)
                .datumAanvangSectorRisicogroep(datumAanvangSectorRisicogroep)
                .datumEindeSectorRisicogroep(datumEindeSectorRisicogroep)
                .build();
    }
}
