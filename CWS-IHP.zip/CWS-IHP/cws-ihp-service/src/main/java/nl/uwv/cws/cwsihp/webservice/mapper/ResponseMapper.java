package nl.uwv.cws.cwsihp.webservice.mapper;

import nl.uwv.cws.common.aspect.LogPerformance;
import nl.uwv.cws.common.exception.CwsCommonExceptionGenerator;
import nl.uwv.cws.common.exception.CwsResponseXsdInvalidException;
import nl.uwv.cws.common.model.Foutmelding;
import nl.uwv.cws.cwsihp.exception.CwsIhpResponseXsdInvalidException;
import nl.uwv.cws.cwsihp.model.CwsIhpCollectResult;
import nl.uwv.cws.cwsihp.model.CwsIhpFoutmelding;
import nl.uwv.cws.cwsihp.model.selection.SelectionParameters;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0007.CwsInhoudingsplichtigeResponse.Applicatiemelding;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0007.CwsInhoudingsplichtigeResponse.Gegevenslevering;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import static nl.uwv.cws.common.util.MapperUtil.mapToJaxbListIfNotEmpty;
import static nl.uwv.cws.cwsihp.model.CwsIhpConstants.BESCHOUWING_TIMESTAMP_FORMATTER;

@Component
public class ResponseMapper extends BaseMapper {

    @Autowired
    private ApplicatiemeldingMapper applicatiemeldingMapper;

    @Autowired
    private GegevensleveringMapper gegevensleveringMapper;

    @Autowired
    private PersoonInhoudingsplichtigeMapper persoonInhoudingsplichtigeMapper;

    public Applicatiemelding mapToJaxbApplicatieMelding(Foutmelding foutmelding) {
        return applicatiemeldingMapper.mapToJaxbApplicatieMelding(foutmelding);
    }

    @LogPerformance
    public Gegevenslevering mapToJaxb(CwsIhpCollectResult collectedInhoudingsplichtige) throws CwsIhpResponseXsdInvalidException {
        final SelectionParameters selectionParameters = collectedInhoudingsplichtige.getSelectionParameters();
        final String bsn = selectionParameters.getBsn();
        final String rsin = selectionParameters.getRsin();
        final String beschouwingsmoment = selectionParameters.getBeschouwingsmoment().format(BESCHOUWING_TIMESTAMP_FORMATTER);

        Gegevenslevering gegevenslevering = gegevensleveringMapper.mapToJaxbGegevenslevering(selectionParameters);

        mapToJaxbListIfNotEmpty(collectedInhoudingsplichtige.getPersoonIhpList(),
                gegevenslevering.getPersoonInhoudingsplichtige(),
                persoonInhoudingsplichtigeMapper::mapToJaxbPersoonIhp);

        if (gegevenslevering.getPersoonInhoudingsplichtige().isEmpty()) {
            throw CwsCommonExceptionGenerator.functionalError(CwsIhpFoutmelding.F072);
        }
        try {
            ruleExecutor.processXsdValidationResult(bsn + rsin, beschouwingsmoment);
        } catch (CwsResponseXsdInvalidException e) {
            throw new CwsIhpResponseXsdInvalidException(e.getMessage());
        }

        return gegevenslevering;
    }
}