package nl.uwv.cws.cwsihp.dao.ihp;

import nl.uwv.cws.cwsihp.dao.mapper.FaillissementSurseanceHrRowMapper;
import nl.uwv.cws.cwsihp.model.configuratie.CwsIhpConfiguratie;
import nl.uwv.cws.cwsihp.model.hr.FaillissementSurseanceHr;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public class FaillissementSurseanceHrDao extends BaseDao {

    @Autowired
    private FaillissementSurseanceHrRowMapper faillissementSurseanceHrRowMapper;

    public List<FaillissementSurseanceHr> findFaillissementSurseance(final Long persoonId, final LocalDateTime beschouwingsmoment, final CwsIhpConfiguratie cwsIhpConfiguratie) {
        final String sql = "SELECT code_bijz_rechtstoestand_cgm AS fail_surs_ind " +
                ", datum_aanvang_cgm AS dataanv" +
                ", cd_datum_aanvang_cgm " +
                ", datum_einde_cgm AS dateind " +
                ", cd_datum_einde_cgm " +
                "FROM uh_bijzondere_rechtstoestand " +
                "WHERE persoon_id = :persoonId " +
                "AND his_ts_in <= :beschouwingsmoment " +
                "AND his_ts_end > :beschouwingsmoment";

        Timestamp beschouwingsmomentTimestamp = Timestamp.valueOf(beschouwingsmoment);
        SqlParameterSource namedParameters = new MapSqlParameterSource()
                .addValue("persoonId", persoonId.toString())
                .addValue("beschouwingsmoment", beschouwingsmomentTimestamp);
        List<String> attributen = cwsIhpConfiguratie.getGroepenGegevens().getRequiredColumnsFaillissementSurseance();
        return jdbcTemplate.query(sql, namedParameters, (resultSet, i) -> faillissementSurseanceHrRowMapper.mapRow(resultSet, attributen));
    }

}
