package nl.uwv.cws.cwsihp.webservice.rule.transformer;

import nl.uwv.cws.common.model.CwsCommonConstants;
import nl.uwv.cws.common.model.rule.AttributeRuleProperties;
import nl.uwv.cws.common.webservice.rule.transformer.RuleValueTransformer;
import nl.uwv.cws.cwsihp.model.rule.CwsIhpAttributeRule;
import org.springframework.stereotype.Component;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static nl.uwv.cws.cwsihp.model.rule.CwsIhpAttributeRule.AFKAPPEN_OBV_SIZE_MAX_EN_MES1_OF_NULL;
import static org.apache.commons.lang3.StringUtils.truncate;
import static org.springframework.util.StringUtils.hasText;

@Component
public class AfkappenObvSizeMaxEnMes1OfNullTransformer implements RuleValueTransformer<String, String> {
    private static final Pattern DIGIT_PATTERN = Pattern.compile("\\d");
    @Override
    public CwsIhpAttributeRule getTransformRule() {
        return AFKAPPEN_OBV_SIZE_MAX_EN_MES1_OF_NULL;
    }

    @Override
    public String transform(String originalValue, AttributeRuleProperties attributeRuleProperties) {
        String transformedValue = truncate(originalValue, attributeRuleProperties.getSizeMax());
        if (hasText(transformedValue)) {
            transformedValue = replaceNonMes1WithQuestionMark(transformedValue);
            if (containsInvalidPattern(transformedValue)) {
                transformedValue = null;
            }
        }
        return transformedValue;
    }

    private String replaceNonMes1WithQuestionMark(String truncatedValue) {
        return CwsCommonConstants.ANY_NON_MES1_PATTERN.matcher(truncatedValue).replaceAll("?");
    }

    private boolean containsInvalidPattern(String truncatedValue) {
        Matcher matcher = DIGIT_PATTERN.matcher(truncatedValue);
        return matcher.find();
    }
}
