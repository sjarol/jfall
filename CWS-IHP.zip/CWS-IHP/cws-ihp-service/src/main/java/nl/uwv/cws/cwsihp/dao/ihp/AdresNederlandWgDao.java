package nl.uwv.cws.cwsihp.dao.ihp;

import nl.uwv.cws.cwsihp.dao.mapper.AdresNederlandWgRowMapper;
import nl.uwv.cws.cwsihp.model.configuratie.CwsIhpConfiguratie;
import nl.uwv.cws.cwsihp.model.wg.AdresNederlandWg;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public class AdresNederlandWgDao extends BaseDao {
	
	@Autowired
	private AdresNederlandWgRowMapper rowMapper;

    public List<AdresNederlandWg> findAdresNederland(final Long administratieveEenheidId, final LocalDateTime beschouwingsmoment, final CwsIhpConfiguratie cwsIhpConfiguratie) {
        Timestamp beschouwingsmomentTimestamp = Timestamp.valueOf(beschouwingsmoment);

        String sql = 	" SELECT adresrol " +
						"      , dataanv " +
						"      , dateind " +
						"      , straatnaam " +
						"      , postcode " +
						"      , huisnr " +
						"      , huisnr_toev " +
						"      , woonplaats " +
						"      , gemeentenaam " +
						"      , locatie_omsch " +
						"      , postbusnr " +
						"      , adrestypek33 " +
						" FROM wga_adres adr" +
						" WHERE aeh_id = :administratieveEenheidId " +
						" AND adrestypek33 IN ('SAN', 'PAN') " +
						" AND his_ts_in  <  :beschouwingsmoment " +
						" AND his_ts_end >= :beschouwingsmoment " +
						(cwsIhpConfiguratie.excludeBeeindigdAdres() ? AdreshoudingWgQueries.CONDITION_EXCLUDE_BEEINDIGD_ADRES : "");

        SqlParameterSource namedParameters = new MapSqlParameterSource()
        		.addValue("administratieveEenheidId", administratieveEenheidId)
				.addValue("beschouwingsmoment", beschouwingsmomentTimestamp);

		List<String> attributen = cwsIhpConfiguratie.getGroepenGegevens().getRequiredColumnsAdresNederlandWg();
		attributen.addAll(cwsIhpConfiguratie.getGroepenGegevens().getRequiredColumnsStraatadresNederlandWg());
		attributen.addAll(cwsIhpConfiguratie.getGroepenGegevens().getRequiredColumnsPostbusadresNederlandWg());
		return jdbcTemplate.query(sql, namedParameters, (resultSet, i) -> rowMapper.mapRow(resultSet, attributen));
	}	
}
