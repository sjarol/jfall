package nl.uwv.cws.cwsihp.dao.mapper;

import nl.uwv.cws.common.dao.mapper.CwsRowMapper;
import nl.uwv.cws.cwsihp.model.wg.FaillissementSurseanceWg;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import static nl.uwv.cws.common.util.ConverterUtil.totDatumToTotEnMetDatum;

@Component
public class FaillissementSurseanceWgRowMapper extends CwsRowMapper<FaillissementSurseanceWg> {

    @Override
    public FaillissementSurseanceWg mapRow(final ResultSet resultSet, final List<String> attributen) throws SQLException {
        final String codeFaillissementSurseance = readApplicableString(attributen, "FAIL_SURS_IND", resultSet);
        final String codeRedenEindeFaillissementSurseance = readApplicableString(attributen, "FAIL_SURS_CODE", resultSet);
        final Long datumAanvangFaillissementSurseance = readApplicableNullableLong(attributen, "DATAANV", resultSet);
        final Long datumEindeFaillissementSurseance = totDatumToTotEnMetDatum(readApplicableNullableLong(attributen, "DATEIND", resultSet));

        return FaillissementSurseanceWg.builder()
                .codeFaillissementSurseance(codeFaillissementSurseance)
                .codeRedenEindeFaillissementSurseance(codeRedenEindeFaillissementSurseance)
                .datumAanvangFaillissementSurseance(datumAanvangFaillissementSurseance)
                .datumEindeFaillissementSurseance(datumEindeFaillissementSurseance)
                .build();
    }
}
