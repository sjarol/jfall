package nl.uwv.cws.cwsihp.dao.mapper;

import nl.uwv.cws.common.dao.mapper.CwsRowMapper;
import nl.uwv.cws.cwsihp.model.wg.PremiepercentageIndividueelWg;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import static nl.uwv.cws.common.util.ConverterUtil.totDatumToTotEnMetDatum;

@Component
public class PremiepercentageIndividueelWgRowMapper extends CwsRowMapper<PremiepercentageIndividueelWg> {

    @Override
    public PremiepercentageIndividueelWg mapRow(final ResultSet resultSet, final List<String> attributen) throws SQLException {
        final String codeSzProduct = readApplicableString(attributen, "SZ_PRODUCT_CODE", resultSet);
        final Double percentage = readApplicableNullableDouble(attributen, "PERCENTAGE", resultSet);
        final Long datumAanvangPremiepercentageIndividueel = readApplicableNullableLong(attributen, "DATAANV", resultSet);
        final Long datumEindePremiepercentageIndividueel = totDatumToTotEnMetDatum(readApplicableNullableLong(attributen, "DATEIND", resultSet));

        return PremiepercentageIndividueelWg.builder()
                .codeSzProduct(codeSzProduct)
                .percentage(percentage)
                .datumAanvangPremiepercentageIndividueel(datumAanvangPremiepercentageIndividueel)
                .datumEindePremiepercentageIndividueel(datumEindePremiepercentageIndividueel)
                .build();
    }
}
