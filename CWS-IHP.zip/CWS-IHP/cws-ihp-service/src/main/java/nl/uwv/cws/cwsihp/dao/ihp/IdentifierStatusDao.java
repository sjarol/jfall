package nl.uwv.cws.cwsihp.dao.ihp;

import nl.uwv.cws.cwsihp.dao.mapper.InhoudingsplichtigeRowMapper;
import nl.uwv.cws.cwsihp.model.ihp.Inhoudingsplichtige;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Component;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

import static nl.uwv.cws.common.model.CwsCommonConstants.BESCHOUWINGSMOMENT;
import static nl.uwv.cws.common.model.CwsCommonConstants.KVK_NUMMER;
import static nl.uwv.cws.common.util.DaoUtil.findOneOrNone;

@Component
public class IdentifierStatusDao extends BaseDao {

    @Autowired
    private InhoudingsplichtigeRowMapper inhoudingsplichtigeRowMapper;

    public boolean isWerkgeverPresent(final String kvkNummer, final LocalDateTime beschouwingsmoment) {
        Timestamp beschouwingsmomentTimestamp = Timestamp.valueOf(beschouwingsmoment);
        String sql ="SELECT CASE " +
                    "WHEN EXISTS " +
                    "   (SELECT DISTINCT 1 " +
                    "    FROM uh_maatschappelijke_activiteit " +
                    "    WHERE kvk_nummer = :kvkNummer " +
                    "    AND his_ts_in <= :beschouwingsmoment " +
                    "    AND his_ts_end > :beschouwingsmoment) " +
                    "THEN 1 " +
                    "ELSE 0 " +
                    "END " +
                    "FROM dual";
        SqlParameterSource namedParameters = new MapSqlParameterSource()
                .addValue(KVK_NUMMER, kvkNummer)
                .addValue(BESCHOUWINGSMOMENT, beschouwingsmomentTimestamp);
        Integer count = jdbcTemplate.queryForObject(sql, namedParameters, Integer.class);
        return count != null && count == 1;
    }

    public boolean isInhoudingsplichtigePresentInHr(final String nummerInhoudingsplichtige, final LocalDateTime beschouwingsmoment) {
        Timestamp beschouwingsmomentTimestamp = Timestamp.valueOf(beschouwingsmoment);
        String sql ="SELECT CASE " +
                    "WHEN EXISTS " +
                    "   (SELECT DISTINCT 1 " +
                    "    FROM uh_persoon " +
                    "    WHERE (bsn = :nummerInhoudingsplichtige " +
                    "    OR rsin = :nummerInhoudingsplichtige) " +
                    "    AND his_ts_in <= :beschouwingsmoment " +
                    "    AND his_ts_end > :beschouwingsmoment) " +
                    "THEN 1 " +
                    "ELSE 0 " +
                    "END " +
                    "FROM dual";
        SqlParameterSource namedParameters = new MapSqlParameterSource()
                .addValue("nummerInhoudingsplichtige", nummerInhoudingsplichtige)
                .addValue(BESCHOUWINGSMOMENT, beschouwingsmomentTimestamp);
        Integer count = jdbcTemplate.queryForObject(sql, namedParameters, Integer.class);
        return count != null && count == 1;
    }

    public boolean isInhoudingsplichtigePresentInWga(final String nummerInhoudingsplichtige, final LocalDateTime beschouwingsmoment) {
        Timestamp beschouwingsmomentTimestamp = Timestamp.valueOf(beschouwingsmoment);
        String sql ="SELECT CASE " +
                "WHEN EXISTS " +
                "   (SELECT DISTINCT 1 " +
                "    FROM wga_npn_persoon_his per_his " +
                "    INNER JOIN wga_persoon per " +
                "    ON per_his.per_id = per.per_id " +
                "    WHERE per.sofinr = :nummerInhoudingsplichtige " +
                "    AND per_his.his_ts_in <= :beschouwingsmoment " +
                "    AND per_his.his_ts_end > :beschouwingsmoment " +
                "    UNION " +
                "    SELECT DISTINCT 1 " +
                "    FROM wga_nnp_persoon_his per_his " +
                "    INNER JOIN wga_persoon per " +
                "    ON per_his.per_id = per.per_id " +
                "    WHERE per.finr = :nummerInhoudingsplichtige " +
                "    AND per_his.his_ts_in <= :beschouwingsmoment " +
                "    AND per_his.his_ts_end > :beschouwingsmoment) " +
                "THEN 1 " +
                "ELSE 0 " +
                "END " +
                "FROM dual";
        SqlParameterSource namedParameters = new MapSqlParameterSource()
                .addValue("nummerInhoudingsplichtige", nummerInhoudingsplichtige)
                .addValue(BESCHOUWINGSMOMENT, beschouwingsmomentTimestamp);
        Integer count = jdbcTemplate.queryForObject(sql, namedParameters, Integer.class);
        return count != null && count == 1;
    }

    public boolean isAdministratieveEenheidPresent(final String loonheffingennummer, final LocalDateTime beschouwingsmoment) {
        Timestamp beschouwingsmomentTimestamp = Timestamp.valueOf(beschouwingsmoment);
        String sql ="SELECT CASE " +
                "WHEN EXISTS " +
                "   (SELECT DISTINCT 1 " +
                "    FROM wga_aeh_his aeh_his " +
                "    INNER JOIN wga_aeh aeh " +
                "    ON aeh_his.aeh_id = aeh.aeh_id " +
                "    WHERE aeh.lhnr = :loonheffingennummer " +
                "    AND aeh_his.his_ts_in <= :beschouwingsmoment " +
                "    AND aeh_his.his_ts_end > :beschouwingsmoment) " +
                "THEN 1 " +
                "ELSE 0 " +
                "END " +
                "FROM dual";
        SqlParameterSource namedParameters = new MapSqlParameterSource()
                .addValue("loonheffingennummer", loonheffingennummer)
                .addValue(BESCHOUWINGSMOMENT, beschouwingsmomentTimestamp);
        Integer count = jdbcTemplate.queryForObject(sql, namedParameters, Integer.class);
        return count != null && count == 1;
    }

    public Inhoudingsplichtige getInhoudingsplichtigeHr(final String kvknummer, final LocalDateTime beschouwingsmoment) {
        final Timestamp beschouwingsmomentTimestamp = Timestamp.valueOf(beschouwingsmoment);

        String sql = "SELECT id, type " +
                    "FROM (SELECT kvk_nummer " +
                    "           , bsn AS id " +
                    "           , 'natuurlijkpersoon' AS type " +
                    "      FROM uh_persoon " +
                    "      WHERE bsn IS NOT NULL " +
                    "      AND his_ts_in <= :beschouwingsmoment " +
                    "      AND his_ts_end > :beschouwingsmoment " +
                    "      UNION " +
                    "      SELECT kvk_nummer " +
                    "          , rsin AS id " +
                    "          , 'niet_natuurlijkpersoon' AS type " +
                    "      FROM uh_persoon " +
                    "      WHERE rsin IS NOT NULL " +
                    "      AND his_ts_in <= :beschouwingsmoment " +
                    "      AND his_ts_end > :beschouwingsmoment) " +
                    " WHERE kvk_nummer = :kvkNummer";

        SqlParameterSource namedParameters = new MapSqlParameterSource()
                .addValue("kvkNummer", kvknummer)
                .addValue("beschouwingsmoment", beschouwingsmomentTimestamp);
        List<Inhoudingsplichtige> results = jdbcTemplate.query(sql, namedParameters, inhoudingsplichtigeRowMapper);
        String errorMessage = "Meerdere rijen gevonden voor kvk nummer: ******" + kvknummer.substring(6);
        return findOneOrNone(errorMessage, results);
    }

    public Inhoudingsplichtige getInhoudingsplichtigeHrByNrIhp(final String nummerInhoudingsplichtige, final LocalDateTime beschouwingsmoment) {
        final Timestamp beschouwingsmomentTimestamp = Timestamp.valueOf(beschouwingsmoment);

        String sql = "SELECT DISTINCT * " +
                "FROM (SELECT bsn AS id " +
                "           , 'natuurlijkpersoon' AS type " +
                "      FROM uh_persoon " +
                "      WHERE bsn IS NOT NULL " +
                "      AND his_ts_in <= :beschouwingsmoment " +
                "      AND his_ts_end > :beschouwingsmoment " +
                "      UNION " +
                "      SELECT rsin AS id " +
                "           , 'niet_natuurlijkpersoon' AS type " +
                "      FROM uh_persoon " +
                "      WHERE rsin IS NOT NULL " +
                "      AND his_ts_in <= :beschouwingsmoment " +
                "      AND his_ts_end > :beschouwingsmoment) " +
                " WHERE ID = :bsnOrRsin";

        SqlParameterSource namedParameters = new MapSqlParameterSource()
                .addValue("bsnOrRsin", nummerInhoudingsplichtige)
                .addValue(BESCHOUWINGSMOMENT, beschouwingsmomentTimestamp);
        List<Inhoudingsplichtige> results = jdbcTemplate.query(sql, namedParameters, inhoudingsplichtigeRowMapper);
        String errorMessage = "Meerdere rijen gevonden voor nummer inhoudingsplichtige: ******" + nummerInhoudingsplichtige.substring(6);
        return findOneOrNone(errorMessage, results);
    }

    public Inhoudingsplichtige getInhoudingsplichtigeWga(final String nummerInhoudingsplichtige, final LocalDateTime beschouwingsmoment) {
        final Timestamp beschouwingsmomentTimestamp = Timestamp.valueOf(beschouwingsmoment);

        String sql = "SELECT DISTINCT * " +
                     "FROM (SELECT per.sofinr AS id " +
                     "           , 'natuurlijkpersoon' AS type " +
                     "      FROM wga_npn_persoon_his npn " +
                     "      INNER JOIN wga_persoon per " +
                     "      ON npn.per_id  = per.per_id " +
                     "      WHERE per.sofinr IS NOT NULL " +
                     "      AND npn.his_ts_in <= :beschouwingsmoment " +
                     "      AND npn.his_ts_end > :beschouwingsmoment " +
                     "      UNION " +
                     "      SELECT per.finr AS id " +
                     "           , 'niet_natuurlijkpersoon' AS type " +
                     "      FROM wga_nnp_persoon_his nnp " +
                     "      INNER JOIN wga_persoon per " +
                     "      ON nnp.per_id  = per.per_id " +
                     "      WHERE per.finr IS NOT NULL " +
                     "      AND nnp.his_ts_in <= :beschouwingsmoment " +
                     "      AND nnp.his_ts_end > :beschouwingsmoment) " +
                     "WHERE ID = :bsnOrRsin";

        SqlParameterSource namedParameters = new MapSqlParameterSource()
                .addValue("bsnOrRsin", nummerInhoudingsplichtige)
                .addValue(BESCHOUWINGSMOMENT, beschouwingsmomentTimestamp);

        List<Inhoudingsplichtige> results = jdbcTemplate.query(sql, namedParameters, inhoudingsplichtigeRowMapper);
        String errorMessage = "Meerdere rijen gevonden voor nummer inhoudingsplichtige: ******" + nummerInhoudingsplichtige.substring(6);
        return findOneOrNone(errorMessage, results);
    }
}
