package nl.uwv.cws.cwsihp.webservice.mapper;

import nl.uwv.cws.cwsihp.model.hr.RechtspersoonHr;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0007.CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NietNatuurlijkPersoon.Rechtspersoon;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.sql.Date;
import java.util.Optional;

import static nl.uwv.cws.common.util.MapperUtil.collectNonEmptyObject;
import static nl.uwv.cws.common.util.NullValueUtil.extractStringFromDateValueOrNull;
import static nl.uwv.cws.common.util.NullValueUtil.extractStringValueOrNull;
import static nl.uwv.cws.cwsihp.model.CwsIhpConstants.*;

@Component
public class RechtspersoonMapper extends BaseMapper {

    @Autowired
    private ActiviteitHandelsregisterMapper activiteitHandelsregisterMapper;

    public Optional<Rechtspersoon> mapToJaxbRechtspersoon(RechtspersoonHr rechtspersoonHr) {
        return Optional.ofNullable(rechtspersoonHr).map(notNullableRechtspersoon -> {

            Rechtspersoon rechtspersoon = new Rechtspersoon();
            mapToJaxbRechtspersoon(notNullableRechtspersoon, rechtspersoon);

            Optional<Rechtspersoon.ActiviteitHandelsregister> activiteitHandelsregister = activiteitHandelsregisterMapper.mapToJaxbActiviteitHandelsregisterRechtspersoon(notNullableRechtspersoon.getActiviteitHandelsregisterHr());
            activiteitHandelsregister.ifPresent(rechtspersoon::setActiviteitHandelsregister);

            return collectNonEmptyObject(rechtspersoon);
        });
    }

    private void mapToJaxbRechtspersoon(RechtspersoonHr rechtspersoonHr, Object rechtspersoon) {
        final String statutaireZetel = rechtspersoonHr.getStatutaireZetel();
        final Date datumAanvangStatutaireZetel = rechtspersoonHr.getDatumAanvangStatutaireZetel();
        Integer codeFictieveDatumAanvang = null;
        if (datumAanvangStatutaireZetel != null) {
            codeFictieveDatumAanvang = rechtspersoonHr.getCodeFictieveDatumAanvang();
        }

        ruleExecutor.setTransformedValue(rechtspersoon, XSD_STATUTAIREZETEL, statutaireZetel);
        ruleExecutor.setTransformedValue(rechtspersoon, XSD_DATBSTATUTAIREZETEL, extractStringFromDateValueOrNull(datumAanvangStatutaireZetel));
        ruleExecutor.setTransformedValue(rechtspersoon, XSD_CDFICTIEVEDATB, extractStringValueOrNull(codeFictieveDatumAanvang));
    }
}
