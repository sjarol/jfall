package nl.uwv.cws.cwsihp.model.rule;

import nl.uwv.cws.common.model.rule.CwsAttributeRule;

public enum CwsIhpAttributeRule implements CwsAttributeRule {
    GEEN,
    NUMMER_MET_VOORLOOPNULLEN_OBV_SIZE_MAX_OF_NULL,
    VOORLOOPNULLEN_OBV_SIZE_MAX,
    INDICATIE_JA_NEE_OF_NULL,
    POSTCODE_NL_GEEN_SPATIE_OF_NULL,
    NUMMER_TUSSEN_1_EN_99999_OF_NULL,
    AFKAPPEN_OBV_SIZE_MAX,
    AFKAPPEN_OBV_SIZE_MAX_EN_MES1_OF_NULL,
    AFKAPPEN_OBV_SIZE_MAX_EN_MES1_EN_GEEN_GETALLEN,
    FICTIEVE_GEBOORTEDATUM
}
