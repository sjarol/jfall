package nl.uwv.cws.cwsihp.webservice;

import lombok.extern.slf4j.Slf4j;
import nl.uwv.cws.common.aspect.LogPerformance;
import nl.uwv.cws.common.exception.ApplicatieMeldingException;
import nl.uwv.cws.common.exception.CwsCommonExceptionGenerator;
import nl.uwv.cws.common.model.CwsAuthorization;
import nl.uwv.cws.common.model.CwsCommonFoutmelding;
import nl.uwv.cws.common.model.Foutmelding;
import nl.uwv.cws.common.model.configuratie.ConfiguratieKey;
import nl.uwv.cws.common.webservice.WebserviceHeaderProcessingHelper;
import nl.uwv.cws.cwsihp.model.CwsIhpCollectResult;
import nl.uwv.cws.cwsihp.orchestration.InhoudingsplichtigeOrchestration;
import nl.uwv.cws.cwsihp.webservice.mapper.ResponseMapper;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigerequest_v0007.CwsInhoudingsplichtigeRequest;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0007.CwsInhoudingsplichtigeResponse;
import nl.uwv.schemas.uwvml.header_v0202.UwvMLHeader;
import nl.uwv.schemas.uwvml.services.cwsinhoudingsplichtige_v0007.Fault;
import nl.uwv.schemas.uwvml.services.cwsinhoudingsplichtige_v0007.WsPortType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.xml.ws.Holder;
import javax.xml.ws.WebServiceContext;

import static nl.uwv.cws.cwsihp.model.CwsIhpConstants.BERICHTNAAM;
import static nl.uwv.cws.cwsihp.model.CwsIhpConstants.CWSIHP_RAADPLEGEN_BEHEER_ROLE;

@Component
@Slf4j
public class CwsInhoudingsplichtigeWebService implements WsPortType {

    @Resource
    private WebServiceContext context;

    @Autowired
    private InhoudingsplichtigeOrchestration inhoudingsplichtigeOrchestration;
    @Autowired
    private RequestValidator requestValidator;
    @Autowired
    private ResponseMapper responseMapper;
    @Autowired
    private CwsIhpRequestProcessingHelper cwsIhpRequestProcessingHelper;
    @Autowired
    private WebserviceHeaderProcessingHelper webserviceHeaderProcessingHelper;

    @LogPerformance("03-JavaCode")
    @Override
    public CwsInhoudingsplichtigeResponse uwvMLCwsInhoudingsplichtige(final CwsInhoudingsplichtigeRequest cwsInhoudingsplichtigeRequest, final Holder<UwvMLHeader> uwvMLHeader) throws Fault {
        log.debug("Vraagbericht komt binnen als een geldige XML voor UwvML_CwsWerkgever");
        CwsInhoudingsplichtigeResponse cwsInhoudingsplichtigeResponse = new CwsInhoudingsplichtigeResponse();
        boolean gegevensGeleverd = false;

        try {
            webserviceHeaderProcessingHelper.logHeader(uwvMLHeader);
            cwsIhpRequestProcessingHelper.logRequestPart(cwsInhoudingsplichtigeRequest);
            requestValidator.validateGegevensvraag(cwsInhoudingsplichtigeRequest);

            CwsAuthorization cwsAuthorization = webserviceHeaderProcessingHelper.createCwsAuthorization(context, uwvMLHeader, CWSIHP_RAADPLEGEN_BEHEER_ROLE);
            ConfiguratieKey configuratieKey = cwsIhpRequestProcessingHelper.extractConfiguratieKey(cwsInhoudingsplichtigeRequest);
            requestValidator.validateAuthorisation(cwsAuthorization, configuratieKey);
            log.debug("Waarden van vraagbericht zijn gevalideerd");

            CwsIhpCollectResult collectedInhoudingsplichtige = processCollectionResult(cwsInhoudingsplichtigeRequest, configuratieKey);
            log.debug("Resultaten zijn verzameld");

            CwsInhoudingsplichtigeResponse.Gegevenslevering gegevenslevering = responseMapper.mapToJaxb(collectedInhoudingsplichtige);
            cwsInhoudingsplichtigeResponse.setGegevenslevering(gegevenslevering);

            webserviceHeaderProcessingHelper.updateHeaderToSuccessResponse(uwvMLHeader, BERICHTNAAM);
            gegevensGeleverd = true;
        } catch (ApplicatieMeldingException e) {
            log.info("Functionele fout is opgetreden. Error message: {}", e.getFoutmelding());

            addApplicatiemeldingToResponse(cwsInhoudingsplichtigeResponse, e.getFoutmelding());
            webserviceHeaderProcessingHelper.updateHeaderToSuccessResponse(uwvMLHeader, BERICHTNAAM);
        } catch (Exception e) {
            log.error("Onverwachte fout is opgetreden. Error message: {}", e.getMessage(), e);

            addApplicatiemeldingToResponse(cwsInhoudingsplichtigeResponse, CwsCommonFoutmelding.F999);
            webserviceHeaderProcessingHelper.updateHeaderToFailureResponse(uwvMLHeader, BERICHTNAAM);

        } finally {
            cwsIhpRequestProcessingHelper.logAudit(context, cwsInhoudingsplichtigeRequest, gegevensGeleverd);
        }

        log.debug("Antwoordbericht is samengesteld");
        return cwsInhoudingsplichtigeResponse;
    }

    private CwsIhpCollectResult processCollectionResult(CwsInhoudingsplichtigeRequest cwsInhoudingsplichtigeRequest, ConfiguratieKey configuratieKey) {
        if (cwsIhpRequestProcessingHelper.isLeveringRequestedForPersoon(cwsInhoudingsplichtigeRequest)) {
            String nummerInhoudingsplichtige = cwsInhoudingsplichtigeRequest.getGegevensvraag().getPersoonInhoudingsplichtige().getNrInhoudingsplichtige();
            return inhoudingsplichtigeOrchestration.collectInhoudingsplichtigeUsingNummerInhoudingsplichtige(configuratieKey, nummerInhoudingsplichtige);
        } else if (cwsIhpRequestProcessingHelper.isLeveringRequestedForAdministratieveEenheid(cwsInhoudingsplichtigeRequest)) {
            final String loonheffingennr = cwsInhoudingsplichtigeRequest.getGegevensvraag().getAdministratieveEenheid().getLoonheffingennr();
            if (loonheffingennr == null) {
                throw CwsCommonExceptionGenerator.functionalError(CwsCommonFoutmelding.F062);
            }
            return inhoudingsplichtigeOrchestration.collectInhoudingsplichtigeUsingLoonheffingNummer(configuratieKey, loonheffingennr);
        }

        String kvkNummer = cwsInhoudingsplichtigeRequest.getGegevensvraag().getWerkgeverKvk().getKvkNr();
        return inhoudingsplichtigeOrchestration.collectInhoudingsplichtigeUsingKvkNummer(configuratieKey, kvkNummer);
    }

    private void addApplicatiemeldingToResponse(CwsInhoudingsplichtigeResponse cwsInhoudingsplichtigeResponse, Foutmelding foutmelding) {
        CwsInhoudingsplichtigeResponse.Applicatiemelding applicatiemelding  = responseMapper.mapToJaxbApplicatieMelding(foutmelding);
        cwsInhoudingsplichtigeResponse.setApplicatiemelding(applicatiemelding);
    }
}
