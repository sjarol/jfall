package nl.uwv.cws.cwsihp.dao.ihp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

public abstract class BaseDao {

    @Autowired
    protected NamedParameterJdbcTemplate jdbcTemplate;

    protected MapSqlParameterSource getNamedParameters(String whereClause, String identifier) {
        MapSqlParameterSource namedParameters = new MapSqlParameterSource();

        if (whereClause.contains(":bsn")) {
            namedParameters.addValue("bsn", identifier);
        } else if (whereClause.contains(":rsin")) {
            namedParameters.addValue("rsin", identifier);
        } else if (whereClause.contains(":nrIhp")) {
            namedParameters.addValue("nrIhp", identifier);
        } else if (whereClause.contains(":kvkNummer")) {
            namedParameters.addValue("kvkNummer", identifier);
        } else if (whereClause.contains(":persoonId")) {
            namedParameters.addValue("persoonId", identifier);
        } else {
            namedParameters.addValue("nrihp", identifier);
        }
        return namedParameters;
    }
}
