package nl.uwv.cws.cwsihp.dao.mapper;

import nl.uwv.cws.common.dao.mapper.CwsRowMapper;
import nl.uwv.cws.cwsihp.model.wg.AdresBuitenlandOngestructureerdWg;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import static nl.uwv.cws.common.util.ConverterUtil.totDatumToTotEnMetDatum;

@Component
public class AdresBuitenlandOngestructureerdWgRowMapper extends CwsRowMapper<AdresBuitenlandOngestructureerdWg> {

    @Override
    public AdresBuitenlandOngestructureerdWg mapRow(final ResultSet resultSet, final List<String> attributen) throws SQLException {

       // ADRES BUITENLAND ONGESTRUCTUREERD
        final String codeAdresrol = readApplicableString(attributen, "ADRESROL", resultSet);
        final Long datumAanvangAdreshouding = readApplicableNullableLong(attributen, "DATAANV", resultSet);
        final Long datumEindeAdreshouding = totDatumToTotEnMetDatum(readApplicableNullableLong(attributen, "DATEIND", resultSet));

        String adresregel1Buitenland = readApplicableString(attributen, "B_ADRESREGEL", resultSet);
        String adresregel2Buitenland = readApplicableString(attributen, "B_WOONPL_LANDREGEL", resultSet);
        String adresregel3Buitenland = readApplicableString(attributen, "REGIONAAM", resultSet);
        String landcodeIso = readApplicableString(attributen, "LANDCODE", resultSet);

        return AdresBuitenlandOngestructureerdWg.builder().codeAdresrol(codeAdresrol)
                .datumAanvangAdreshouding(datumAanvangAdreshouding)
                .datumEindeAdreshouding(datumEindeAdreshouding)
                .adresregel1Buitenland(adresregel1Buitenland)
                .adresregel2Buitenland(adresregel2Buitenland)
                .adresregel3Buitenland(adresregel3Buitenland)
                .landcodeIso(landcodeIso)
                .build();
    }
}
