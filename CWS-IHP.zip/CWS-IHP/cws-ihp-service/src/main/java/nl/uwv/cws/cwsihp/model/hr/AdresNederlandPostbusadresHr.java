package nl.uwv.cws.cwsihp.model.hr;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter
public class AdresNederlandPostbusadresHr {
    private String postcode;
    private String woonplaatsnaam;
    private Integer postbusnummer;
}
