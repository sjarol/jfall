package nl.uwv.cws.cwsihp.webservice.mapper;

import nl.uwv.cws.common.VisibleForTesting;
import nl.uwv.cws.cwsihp.model.wg.VoortzettingsrelatieVoorgangerWg;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0007.CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.VoortzettingsrelatieVoorganger;
import org.springframework.stereotype.Component;

import static nl.uwv.cws.common.util.MapperUtil.collectNonEmptyObject;
import static nl.uwv.cws.common.util.NullValueUtil.extractBigDecimalValueOrNull;
import static nl.uwv.cws.common.util.NullValueUtil.extractStringValueOrNull;
import static nl.uwv.cws.cwsihp.model.CwsIhpConstants.*;

@Component
public class VoortzettingsrelatieVoorgangerMapper extends BaseMapper {

    @VisibleForTesting
    protected VoortzettingsrelatieVoorganger mapToJaxbVoortzettingsrelatieVoorganger(VoortzettingsrelatieVoorgangerWg voortzettingsrelatieVoorgangerWg) {
        VoortzettingsrelatieVoorganger voortzettingsrelatieVoorganger = new VoortzettingsrelatieVoorganger();

        final Long datumAanvangVoortzettingsrelatieVoorganger = voortzettingsrelatieVoorgangerWg.getDatumAanvangVoortzettingsrelatieVoorganger();
        final Double percentageLoonsomOvergegaan = voortzettingsrelatieVoorgangerWg.getPercentageLoonsomOvergegaan();
        final String lhnrVoorganger = voortzettingsrelatieVoorgangerWg.getLhnrVoorganger();

        ruleExecutor.setTransformedValue(voortzettingsrelatieVoorganger, XSD_DATBVOORTZETTINGSRELATIE, extractStringValueOrNull(datumAanvangVoortzettingsrelatieVoorganger));
        ruleExecutor.setTransformedValue(voortzettingsrelatieVoorganger, XSD_PERCLOONSOMOVERGEGAANINOPVOLGER, extractBigDecimalValueOrNull(percentageLoonsomOvergegaan));
        ruleExecutor.setTransformedValue(voortzettingsrelatieVoorganger, XSD_LOONHEFFINGENNR, lhnrVoorganger);

        return collectNonEmptyObject(voortzettingsrelatieVoorganger);
    }
}
