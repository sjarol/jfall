package nl.uwv.cws.cwsihp.dao.ihp;

public final class AdreshoudingHrQueries {

    private AdreshoudingHrQueries() { }

    static final String WITH_LOCATIE_ID_AS = "WITH locatie_id AS ";

    static final String COMMON_COLUMNS = "status_adres " +
            ", id.code_adresrol_cgm " +
            ", loc.datum_aanvang_cgm " +
            ", loc.cd_datum_aanvang_cgm " +
            ", loc.datum_einde_cgm " +
            ", loc.cd_datum_einde_cgm " +
            ", loc.ind_afgeschermd_adres_cgm ";

    static final String FROM_LOCATIE = "FROM uh_locatie loc " +
            "JOIN locatie_id id " +
            "ON id.locatie_id = loc.locatie_id ";

    static final String JOIN_BINNENLANDS = "JOIN uh_binnenlands_adres bin ON bin.adres_bin_id = loc.adres_bin_id ";

    static final String JOIN_BUITENLANDS = "JOIN uh_buitenlands_adres bin ON bin.adres_buit_id = loc.adres_buit_id ";

    static final String WHERE_GELDIGE_ADRESROL = "WHERE id.code_adresrol_cgm <> '?' ";

    static final String CONDITION_EXCLUDE_BEEINDIGD_ADRES =
            "AND (loc.datum_einde_cgm IS NULL " +
                    "OR TRUNC(loc.datum_einde_cgm) >= TRUNC(SYSDATE)) ";

    static final String IS_ADRES_BUITENLAND = "AND status_adres = 'H' ";
    static final String IS_ADRES_BUITENLAND_ONGESTRUCTUREERD = "AND status_adres = 'A' ";
}
