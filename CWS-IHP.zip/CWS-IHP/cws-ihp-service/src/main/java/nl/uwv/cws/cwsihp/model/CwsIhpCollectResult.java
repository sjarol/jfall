package nl.uwv.cws.cwsihp.model;

import lombok.Builder;
import lombok.Getter;
import nl.uwv.cws.cwsihp.model.ihp.PersoonIhp;
import nl.uwv.cws.cwsihp.model.selection.SelectionParameters;

import java.util.List;

@Builder
@Getter
public class CwsIhpCollectResult {
    private SelectionParameters selectionParameters;
    private List<PersoonIhp> persoonIhpList;
}