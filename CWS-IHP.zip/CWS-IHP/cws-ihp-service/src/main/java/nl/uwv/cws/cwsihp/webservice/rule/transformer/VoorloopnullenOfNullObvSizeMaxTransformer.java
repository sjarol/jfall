package nl.uwv.cws.cwsihp.webservice.rule.transformer;

import nl.uwv.cws.common.util.ConverterUtil;
import nl.uwv.cws.common.model.rule.AttributeRuleProperties;
import nl.uwv.cws.common.webservice.rule.transformer.RuleValueTransformer;
import nl.uwv.cws.cwsihp.model.rule.CwsIhpAttributeRule;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import static nl.uwv.cws.cwsihp.model.rule.CwsIhpAttributeRule.NUMMER_MET_VOORLOOPNULLEN_OBV_SIZE_MAX_OF_NULL;

@Component
public class VoorloopnullenOfNullObvSizeMaxTransformer implements RuleValueTransformer<String, String> {

    @Override
    public CwsIhpAttributeRule getTransformRule() {
        return NUMMER_MET_VOORLOOPNULLEN_OBV_SIZE_MAX_OF_NULL;
    }

    @Override
    public String transform(String originalValue, AttributeRuleProperties attributeRuleProperties) {
        if (!StringUtils.hasText(originalValue) || originalValue.length() > attributeRuleProperties.getSizeMax()) {
            return null;
        } else {
            return ConverterUtil.codeToCodeMetVoorloopnul(originalValue, attributeRuleProperties.getSizeMax());
        }
    }
}
