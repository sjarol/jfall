package nl.uwv.cws.cwsihp.model.hr;

import lombok.Getter;
import lombok.experimental.SuperBuilder;

import java.sql.Date;

@SuperBuilder
@Getter
public class AdresBuitenlandHr extends AdresHr {
    private String codeAdresrol;
    private Date datumAanvangAdreshouding;
    private Integer codeFictieveDatumAanvang;
    private Integer codeFictieveDatumEinde;
    private Integer codeAfgeschermdAdres;

    private AdresBuitenlandStraatadresHr straatadresHr;
    private AdresBuitenlandPostbusadresHr postbusadresHr;
}
