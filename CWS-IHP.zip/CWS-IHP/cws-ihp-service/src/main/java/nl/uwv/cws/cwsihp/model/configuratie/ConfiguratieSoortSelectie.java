package nl.uwv.cws.cwsihp.model.configuratie;

import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.Map;

import static nl.uwv.cws.cwsihp.model.configuratie.CwsIhpFilterType.BEEINDIGD_ADRES_UITSLUITEN_IHP;

public class ConfiguratieSoortSelectie {

    private boolean beeindigdAdresUitsluiten;

    private ConfiguratieSoortSelectie() {
    }

    public boolean isBeeindigdAdresUitsluiten() {
        return beeindigdAdresUitsluiten;
    }

    public void setBeeindigdAdresUitsluiten(boolean beeindigdAdresUitsluiten) {
        this.beeindigdAdresUitsluiten = beeindigdAdresUitsluiten;
    }

    public static ConfiguratieSoortSelectie build(Map<String, String> filterKeyValues) {
        ConfiguratieSoortSelectie configuratieSoortSelectie = new ConfiguratieSoortSelectie();

        for (Map.Entry<String, String> keyValue : filterKeyValues.entrySet()) {
            String techNaam = keyValue.getKey();
            String value = keyValue.getValue();

            CwsIhpFilterType filterType = CwsIhpFilterType.valueOf(techNaam);
            if (filterType == BEEINDIGD_ADRES_UITSLUITEN_IHP) {
                switch (value) {
                    case "J":
                    case "N":
                        configuratieSoortSelectie.setBeeindigdAdresUitsluiten("J".equals(value));
                        break;
                    default:
                        throw new IllegalArgumentException("Configuration has an illegal value ["+value+"] for filter " + BEEINDIGD_ADRES_UITSLUITEN_IHP);
                }
            }
        }
        return configuratieSoortSelectie;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }
}
