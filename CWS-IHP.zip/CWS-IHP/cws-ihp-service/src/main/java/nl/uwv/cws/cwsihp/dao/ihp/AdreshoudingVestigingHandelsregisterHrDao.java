package nl.uwv.cws.cwsihp.dao.ihp;

import nl.uwv.cws.cwsihp.model.configuratie.CwsIhpConfiguratie;
import nl.uwv.cws.cwsihp.model.hr.AdresBuitenlandHr;
import nl.uwv.cws.cwsihp.model.hr.AdresBuitenlandOngestructureerdHr;
import nl.uwv.cws.cwsihp.model.hr.AdresNederlandHr;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Component;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

import static nl.uwv.cws.common.model.CwsCommonConstants.*;

@Component
public class AdreshoudingVestigingHandelsregisterHrDao extends BaseAdreshoudingHrDao {

    private static final String WITH_CLAUSE = "   (SELECT locatie_id, code_adresrol_cgm " +
            "    FROM uh_locatie_vestiging " +
            "    WHERE kvk_nummer = :kvkNummer " +
            "    AND vestigings_nummer = :vestigingsNummer " +
            "    AND his_ts_in  <= :beschouwingsmoment " +
            "    AND his_ts_end > :beschouwingsmoment " +
            "    ) ";

    public List<AdresNederlandHr> findAdresNederlandVestigingHandelsregister(final String kvkNummer, final Long vestigingsNummer, final LocalDateTime beschouwingsmoment, final CwsIhpConfiguratie cwsIhpConfiguratie) {
        MapSqlParameterSource namedParameters = getMappedSqlParameterSource(kvkNummer, vestigingsNummer, beschouwingsmoment);
        List<String> attributen = cwsIhpConfiguratie.getGroepenGegevens().getRequiredColumnsAdresNederlandVestigingHandelsregister();
        attributen.addAll(cwsIhpConfiguratie.getGroepenGegevens().getRequiredColumnsStraatadresNederlandVestigingHandelsregister());
        attributen.addAll(cwsIhpConfiguratie.getGroepenGegevens().getRequiredColumnsPostbusadresNederlandVestigingHandelsregister());
        return findAdresNederland(WITH_CLAUSE, namedParameters, cwsIhpConfiguratie, attributen);
    }

    public List<AdresBuitenlandHr> findAdresBuitenlandVestigingHandelsregister(final String kvkNummer, final Long vestigingsNummer, final LocalDateTime beschouwingsmoment, final CwsIhpConfiguratie cwsIhpConfiguratie) {
        MapSqlParameterSource namedParameters = getMappedSqlParameterSource(kvkNummer, vestigingsNummer, beschouwingsmoment);
        List<String> attributen = cwsIhpConfiguratie.getGroepenGegevens().getRequiredColumnsAdresBuitenlandVestigingHandelsregister();
        attributen.addAll(cwsIhpConfiguratie.getGroepenGegevens().getRequiredColumnsStraatadresBuitenlandVestigingHandelsregister());
        attributen.addAll(cwsIhpConfiguratie.getGroepenGegevens().getRequiredColumnsPostbusadresBuitenlandVestigingHandelsregister());
        return findAdresBuitenland(WITH_CLAUSE, namedParameters, cwsIhpConfiguratie, attributen);
    }

    public List<AdresBuitenlandOngestructureerdHr> findAdresBuitenlandOngestructureerdVestigingHandelsregister(final String kvkNummer, final Long vestigingsNummer, final LocalDateTime beschouwingsmoment, final CwsIhpConfiguratie cwsIhpConfiguratie) {
        MapSqlParameterSource namedParameters = getMappedSqlParameterSource(kvkNummer, vestigingsNummer, beschouwingsmoment);
        List<String> attributen = cwsIhpConfiguratie.getGroepenGegevens().getRequiredColumnsAdresBuitenlandOngestructureerdVestigingHandelsregister();
        return findAdresBuitenlandOngestructureerd(WITH_CLAUSE, namedParameters, cwsIhpConfiguratie, attributen);
    }

    private MapSqlParameterSource getMappedSqlParameterSource(final String kvkNummer, final Long vestigingsNummer, final LocalDateTime beschouwingsmoment){
        Timestamp beschouwingsmomentTimestamp = Timestamp.valueOf(beschouwingsmoment);
        return new MapSqlParameterSource()
                .addValue(KVK_NUMMER, kvkNummer)
                .addValue(VESTIGINGS_NUMMER, vestigingsNummer)
                .addValue(BESCHOUWINGSMOMENT, beschouwingsmomentTimestamp);
    }
}
