package nl.uwv.cws.cwsihp.dao.ihp;


import nl.uwv.cws.cwsihp.model.configuratie.CwsIhpConfiguratie;
import nl.uwv.cws.cwsihp.model.hr.AdresBuitenlandHr;
import nl.uwv.cws.cwsihp.model.hr.AdresBuitenlandOngestructureerdHr;
import nl.uwv.cws.cwsihp.model.hr.AdresNederlandHr;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;


@Repository
public class AdreshoudingHrDao extends BaseDao {

    @Autowired
    private AdreshoudingVestigingHandelsregisterHrDao adreshoudingVestigingHandelsregisterDao;

    @Autowired
    private AdreshoudingPersoonHrDao adreshoudingPersoonDao;

    public List<AdresNederlandHr> findAdresNederlandPersoon(final Long persoonId, final Long naamPersoonId, final Long natuurlijkpersoonId, final LocalDateTime beschouwingsmoment, final CwsIhpConfiguratie cwsIhpConfiguratie) {
        return adreshoudingPersoonDao.findAdresNederlandPersoon(persoonId, naamPersoonId, natuurlijkpersoonId, beschouwingsmoment, cwsIhpConfiguratie);
    }

    public List<AdresBuitenlandHr> findAdresBuitenlandPersoon(final Long persoonId, final Long naamPersoonId, final Long natuurlijkpersoonId, final LocalDateTime beschouwingsmoment, final CwsIhpConfiguratie cwsIhpConfiguratie) {
        return adreshoudingPersoonDao.findAdresBuitenlandPersoon(persoonId, naamPersoonId, natuurlijkpersoonId, beschouwingsmoment, cwsIhpConfiguratie);
    }

    public List<AdresBuitenlandOngestructureerdHr> findAdresBuitenlandOngestructureerdPersoon(final Long persoonId, final Long naamPersoonId, final Long natuurlijkpersoonId, final LocalDateTime beschouwingsmoment, final CwsIhpConfiguratie cwsIhpConfiguratie) {
        return adreshoudingPersoonDao.findAdresBuitenlandOngestructureerdPersoon(persoonId, naamPersoonId, natuurlijkpersoonId, beschouwingsmoment, cwsIhpConfiguratie);
    }

    public List<AdresNederlandHr> findAdresNederlandVestigingHandelsregister(final String kvkNummer, final Long vestigingsNummer, final LocalDateTime beschouwingsmoment, final CwsIhpConfiguratie cwsIhpConfiguratie) {
        return adreshoudingVestigingHandelsregisterDao.findAdresNederlandVestigingHandelsregister(kvkNummer, vestigingsNummer, beschouwingsmoment, cwsIhpConfiguratie);
    }

    public List<AdresBuitenlandHr> findAdresBuitenlandVestigingHandelsregister(final String kvkNummer, final Long vestigingsNummer, final LocalDateTime beschouwingsmoment, final CwsIhpConfiguratie cwsIhpConfiguratie) {
        return adreshoudingVestigingHandelsregisterDao.findAdresBuitenlandVestigingHandelsregister(kvkNummer, vestigingsNummer, beschouwingsmoment, cwsIhpConfiguratie);
    }

    public List<AdresBuitenlandOngestructureerdHr> findAdresBuitenlandOngestructureerdVestigingHandelsregister(final String kvkNummer, final Long vestigingsNummer, final LocalDateTime beschouwingsmoment, final CwsIhpConfiguratie cwsIhpConfiguratie) {
        return adreshoudingVestigingHandelsregisterDao.findAdresBuitenlandOngestructureerdVestigingHandelsregister(kvkNummer, vestigingsNummer, beschouwingsmoment, cwsIhpConfiguratie);
    }
}
