package nl.uwv.cws.cwsihp.model.hr;

import lombok.Builder;
import lombok.Getter;

@Builder
@Getter
public class AdresBuitenlandStraatadresHr {
    private String postcodeBuitenland;
    private String woonplaatsnaamBuitenland;
    private String regionaamBuitenland;
    private Integer landcodeGba;
    private String landcodeIso;
    private String landsnaam;
    private String straatnaamBuitenland;
    private String huisnummerBuitenland;
    private String locatieomschrijvingBuitenland;
}
