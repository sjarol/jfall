package nl.uwv.cws.cwsihp.dao.ihp;

import nl.uwv.cws.cwsihp.dao.mapper.AansluitingsnummerBvWgRowMapper;
import nl.uwv.cws.cwsihp.model.configuratie.CwsIhpConfiguratie;
import nl.uwv.cws.cwsihp.model.wg.AansluitingsnummerBvWg;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public class AansluitingsnummerBvWgDao extends BaseDao {

    @Autowired
    private AansluitingsnummerBvWgRowMapper aansluitingsnummerBvWgRowMapper;

    public List<AansluitingsnummerBvWg> findAansluitingsnummerBv(final Long administratieveEenheidId, final LocalDateTime beschouwingsmoment, final CwsIhpConfiguratie cwsIhpConfiguratie) {
        Timestamp beschouwingsmomentTimestamp = Timestamp.valueOf(beschouwingsmoment);
        final String sql =
                " SELECT codesectorosv " +
                "      , risicopremiegroep " +
                "      , aansluitingsnrbv " +
                "      , dataanv " +
                " FROM wga_asu " +
                " WHERE aeh_id = :administratieveEenheidId " +
                " AND his_ts_in <= :beschouwingsmoment " +
                " AND his_ts_end > :beschouwingsmoment";

        SqlParameterSource namedParameters = new MapSqlParameterSource()
                .addValue("administratieveEenheidId", administratieveEenheidId.toString())
                .addValue("beschouwingsmoment", beschouwingsmomentTimestamp);
        List<String> attributen = cwsIhpConfiguratie.getGroepenGegevens().getRequiredColumnsAansluitingsnummerBv();

        return jdbcTemplate.query(sql, namedParameters, (resultSet, i) -> aansluitingsnummerBvWgRowMapper.mapRow(resultSet, attributen));
    }
}
