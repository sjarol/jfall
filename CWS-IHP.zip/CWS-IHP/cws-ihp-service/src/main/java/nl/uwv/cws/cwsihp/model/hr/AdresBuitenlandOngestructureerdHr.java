package nl.uwv.cws.cwsihp.model.hr;

import lombok.Getter;
import lombok.experimental.SuperBuilder;

import java.sql.Date;

@SuperBuilder
@Getter
public class AdresBuitenlandOngestructureerdHr extends AdresHr {
    private String codeAdresrol;
    private Date datumAanvangAdreshouding;
    private Integer codeFictieveDatumAanvang;
    private Integer codeFictieveDatumEinde;
    private Integer codeAfgeschermdAdres;
    private String adresregel1Buitenland;
    private String adresregel2Buitenland;
    private String adresregel3Buitenland;
    private Integer landcodeGba;
    private String landsnaamGba;
    private String landcodeIso;
    private String landsnaam;
}
