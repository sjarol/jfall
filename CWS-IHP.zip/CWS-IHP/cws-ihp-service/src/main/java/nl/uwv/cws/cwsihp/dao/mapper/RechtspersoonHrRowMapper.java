package nl.uwv.cws.cwsihp.dao.mapper;

import nl.uwv.cws.common.dao.mapper.CwsRowMapper;
import nl.uwv.cws.cwsihp.model.hr.RechtspersoonHr;
import org.springframework.stereotype.Component;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Component
public class RechtspersoonHrRowMapper extends CwsRowMapper<RechtspersoonHr> {
    @Override
    public RechtspersoonHr mapRow(final ResultSet resultSet, final List<String> attributen) throws SQLException {
        final Long activiteitId = resultSet.getLong("ACTIVITEIT_ID");

        final String statutaireZetel = readApplicableString(attributen, "STATUTAIREZETEL", resultSet);
        final Date datumAanvang = readApplicableDate(attributen, "AANVANG_STATUTAIREZETEL_CGM", resultSet);
        final Integer codeFictieveDatumAanvang = readApplicableNullableInteger(attributen, "CD_AANVANG_STATUTAIREZETEL_CGM", resultSet);

        return RechtspersoonHr.builder()
                .activiteitId(activiteitId)
                .statutaireZetel(statutaireZetel)
                .datumAanvangStatutaireZetel(datumAanvang)
                .codeFictieveDatumAanvang(codeFictieveDatumAanvang).build();
    }
}
