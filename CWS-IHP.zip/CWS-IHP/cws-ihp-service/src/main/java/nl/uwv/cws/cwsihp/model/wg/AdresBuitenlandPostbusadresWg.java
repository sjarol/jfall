package nl.uwv.cws.cwsihp.model.wg;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter
public class AdresBuitenlandPostbusadresWg {
    private String postcodeBuitenland;
    private String woonplaatsnaamBuitenland;
    private String regionaamBuitenland;
    private String landcodeIso;
    private String postbusnummerBuitenland;
}
