package nl.uwv.cws.cwsihp.service.wg;

import nl.uwv.cws.cwsihp.model.configuratie.CwsIhpConfiguratie;
import nl.uwv.cws.cwsihp.model.hr.AdreshoudingHr;
import nl.uwv.cws.cwsihp.model.ihp.NatuurlijkPersoonIhp;
import nl.uwv.cws.cwsihp.model.ihp.PersoonIhp;
import nl.uwv.cws.cwsihp.model.selection.SelectionParameters;
import nl.uwv.cws.cwsihp.model.wg.*;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class SofinrWgService extends BaseWgService {

    public List<PersoonIhp> findPersoonIhp(final SelectionParameters selectionParameters) {
        final String sofinr = selectionParameters.getBsn();
        final String lhnr = selectionParameters.getLoonheffingennummer();
        final LocalDateTime beschouwingsmoment = selectionParameters.getBeschouwingsmoment();
        final CwsIhpConfiguratie cwsIhpConfiguratie = selectionParameters.getCwsIhpConfiguratie();
        final List<PersoonWg> persoonWgList = persoonWgDao.findPersoonWgBySofinr(sofinr, beschouwingsmoment);

        List<PersoonIhp> persoonIhpList = new ArrayList<>();
        persoonWgList.forEach(persoonWg -> {
            final Long persoonId = persoonWg.getPersoonId();

            NatuurlijkPersoonIhp natuurlijkPersoonIhp = getNatuurlijkPersoonIhpIfRequired(persoonId, beschouwingsmoment, cwsIhpConfiguratie);

            List<FaillissementSurseanceWg> faillissementSurseanceWgList = getFaillissementSurseanceWgIfRequired(persoonId, beschouwingsmoment, cwsIhpConfiguratie);
            List<RechtsvormWg> rechtsvormWgList = getRechtsvormWgIfRequired(cwsIhpConfiguratie);
            List<GemoedsbezwaardheidWg> gemoedsbezwaardheidWgList = getGemoedsbezwaardheidWgIfRequired(persoonId, beschouwingsmoment, cwsIhpConfiguratie);

            // IHP komt alleen in WGA voor dus geen adressen uit UHR.
            AdreshoudingHr adreshoudingHr = AdreshoudingHr.builder().build();
            List<AdministratieveEenheidWg> administratieveEenheidWgList = getAdministratieveEenheidWgIfRequired(persoonId, lhnr, beschouwingsmoment, cwsIhpConfiguratie);

            PersoonIhp persoonIhp = PersoonIhp.builder()
                    .natuurlijkPersoonIhp(natuurlijkPersoonIhp)
                    .faillissementSurseanceWgList(faillissementSurseanceWgList)
                    .rechtsvormWgList(rechtsvormWgList)
                    .gemoedsbezwaardheidWgList(gemoedsbezwaardheidWgList)
                    .adreshoudingHr(adreshoudingHr)
                    .administratieveEenheidWgList(administratieveEenheidWgList)
                    .build();

            persoonIhpList.add(persoonIhp);
        });
        return persoonIhpList;
    }

    private NatuurlijkPersoonIhp getNatuurlijkPersoonIhpIfRequired(final Long persoonId,
                                                                   final LocalDateTime beschouwingsmoment,
                                                                   CwsIhpConfiguratie cwsIhpConfiguratie){
        NatuurlijkPersoonIhp natuurlijkPersoonIhp = null;
        if (cwsIhpConfiguratie.requiresAnyNatuurlijkPersoon()) {
            final NatuurlijkPersoonWg natuurlijkPersoonWg = natuurlijkPersoonWgDao.findNatuurlijkPersoonWg(persoonId, beschouwingsmoment, cwsIhpConfiguratie);
            natuurlijkPersoonIhp = NatuurlijkPersoonIhp.builder()
                    .natuurlijkPersoonWg(natuurlijkPersoonWg)
                    .build();
        }

        return natuurlijkPersoonIhp;
    }

    private List<RechtsvormWg> getRechtsvormWgIfRequired(CwsIhpConfiguratie cwsIhpConfiguratie){
        List<RechtsvormWg> rechtsvormWgList = null;
        if (cwsIhpConfiguratie.requiresRechtsvorm()) {
            rechtsvormWgList = rechtsvormWgService.getRechtsvormWgEenmanszaak(cwsIhpConfiguratie);
        }

        return rechtsvormWgList;
    }
}
