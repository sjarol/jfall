package nl.uwv.cws.cwsihp.webservice.mapper;

import nl.uwv.cws.cwsihp.model.hr.NatuurlijkPersoonHr;
import nl.uwv.cws.cwsihp.model.ihp.NatuurlijkPersoonIhp;
import nl.uwv.cws.cwsihp.model.wg.NatuurlijkPersoonWg;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0007.CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NatuurlijkPersoon;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.sql.Date;
import java.util.Optional;

import static nl.uwv.cws.common.util.MapperUtil.collectNonEmptyObject;
import static nl.uwv.cws.common.util.NullValueUtil.extractStringFromDateValueOrNull;
import static nl.uwv.cws.common.util.NullValueUtil.extractStringValueOrNull;
import static nl.uwv.cws.cwsihp.model.CwsIhpConstants.*;

@Component
public class NatuurlijkPersoonMapper extends BaseMapper {

    @Autowired
    private HuwelijkGeregistreerdPartnerMapper huwelijkGeregistreerdPartnerMapper;

    public Optional<NatuurlijkPersoon> mapToJaxbNatuurlijkPersoon(NatuurlijkPersoonIhp natuurlijkPersoonIhp) {
        return Optional.ofNullable(natuurlijkPersoonIhp).map(notNullableNatuurlijkPersoon -> {

            NatuurlijkPersoonHr natuurlijkPersoonHr = natuurlijkPersoonIhp.getNatuurlijkPersoonHr();
            NatuurlijkPersoonWg natuurlijkPersoonWg = natuurlijkPersoonIhp.getNatuurlijkPersoonWg();
            NatuurlijkPersoon natuurlijkPersoon = new NatuurlijkPersoon();
            if (natuurlijkPersoonHr != null) {
                mapToJaxbNatuurlijkPersoonHr(natuurlijkPersoonHr, natuurlijkPersoon);

                Optional<NatuurlijkPersoon.HuwelijkGeregistreerdPartner> huwelijkGeregistreerdPartner = huwelijkGeregistreerdPartnerMapper.mapToJaxbHuwelijkGeregistreerdPartner(natuurlijkPersoonHr.getHuwelijkGeregistreerdPartnerIhp());
                huwelijkGeregistreerdPartner.ifPresent(natuurlijkPersoon::setHuwelijkGeregistreerdPartner);
            } else {
                mapToJaxbNatuurlijkPersoonWg(natuurlijkPersoonWg, natuurlijkPersoon);

                Optional<NatuurlijkPersoon.HuwelijkGeregistreerdPartner> huwelijkGeregistreerdPartner = huwelijkGeregistreerdPartnerMapper.mapToJaxbHuwelijkGeregistreerdPartner(natuurlijkPersoonWg.getHuwelijkGeregistreerdPartnerIhp());
                huwelijkGeregistreerdPartner.ifPresent(natuurlijkPersoon::setHuwelijkGeregistreerdPartner);
            }

            return collectNonEmptyObject(natuurlijkPersoon);
        });
    }

    private void mapToJaxbNatuurlijkPersoonHr(NatuurlijkPersoonHr natuurlijkPersoonHr, NatuurlijkPersoon natuurlijkPersoon) {
        final Integer burgerservicenummer = natuurlijkPersoonHr.getBurgerservicenummer();
        final String voorletters = natuurlijkPersoonHr.getVoorletters();
        final String voornamen = natuurlijkPersoonHr.getVoornamen();
        final String voorvoegsel = natuurlijkPersoonHr.getVoorvoegsel();
        final String achternaam = natuurlijkPersoonHr.getAchternaam();
        final Integer codeAanduidingNaamgebruik = natuurlijkPersoonHr.getCodeAanduidingNaamgebruik();
        final Date geboortedatum = natuurlijkPersoonHr.getGeboorteDatum();
        // Als een datum leeg is, dan code fictieve datum ook niet leveren.
        Integer codeFictieveGeboortedatum = null;
        if (geboortedatum != null) {
            codeFictieveGeboortedatum = natuurlijkPersoonHr.getCodeFictieveGeboortedatum();
        }
        final String geslacht = natuurlijkPersoonHr.getGeslacht();

        ruleExecutor.setTransformedValue(natuurlijkPersoon, XSD_BURGERSERVICENR, extractStringValueOrNull(burgerservicenummer));
        ruleExecutor.setTransformedValue(natuurlijkPersoon, XSD_VOORLETTERS, voorletters);
        ruleExecutor.setTransformedValue(natuurlijkPersoon, XSD_VOORNAMEN, extractStringValueOrNull(voornamen));
        ruleExecutor.setTransformedValue(natuurlijkPersoon, XSD_VOORVOEGSEL, extractStringValueOrNull(voorvoegsel));
        ruleExecutor.setTransformedValue(natuurlijkPersoon, XSD_SIGNIFICANTDEELVANDEACHTERNAAM, extractStringValueOrNull(achternaam));
        ruleExecutor.setTransformedValue(natuurlijkPersoon, XSD_CDAANDUIDINGNAAMGEBRUIK, extractStringValueOrNull(codeAanduidingNaamgebruik));
        ruleExecutor.setTransformedValue(natuurlijkPersoon, XSD_GEBOORTEDAT, extractStringFromDateValueOrNull(geboortedatum));
        ruleExecutor.setTransformedValue(natuurlijkPersoon, XSD_CDFICTIEVEGEBOORTEDAT, extractStringValueOrNull(codeFictieveGeboortedatum));
        ruleExecutor.setTransformedValue(natuurlijkPersoon, XSD_GESLACHT, geslacht);
    }

    private void mapToJaxbNatuurlijkPersoonWg(NatuurlijkPersoonWg natuurlijkPersoonWg, NatuurlijkPersoon natuurlijkPersoon) {
        final Integer burgerservicenummer = natuurlijkPersoonWg.getBurgerservicenummer();
        final String voorletters = natuurlijkPersoonWg.getVoorletters();
        final String voornamen = natuurlijkPersoonWg.getVoornamen();
        final String voorvoegsel = natuurlijkPersoonWg.getVoorvoegsel();
        final String achternaam = natuurlijkPersoonWg.getAchternaam();
        final Integer codeAanduidingNaamgebruik = natuurlijkPersoonWg.getCodeAanduidingNaamgebruik();
        final Integer geboortedatum = natuurlijkPersoonWg.getGeboorteDatum();
        // Als een datum leeg is, dan code fictieve datum ook niet leveren.
        Integer codeFictieveGeboortedatum = null;
        if (geboortedatum != null) {
            codeFictieveGeboortedatum = natuurlijkPersoonWg.getCodeFictieveGeboortedatum();
        }
        final String geslacht = natuurlijkPersoonWg.getGeslacht();

        ruleExecutor.setTransformedValue(natuurlijkPersoon, XSD_BURGERSERVICENR, extractStringValueOrNull(burgerservicenummer));
        ruleExecutor.setTransformedValue(natuurlijkPersoon, XSD_VOORLETTERS, voorletters);
        ruleExecutor.setTransformedValue(natuurlijkPersoon, XSD_VOORNAMEN, extractStringValueOrNull(voornamen));
        ruleExecutor.setTransformedValue(natuurlijkPersoon, XSD_VOORVOEGSEL, extractStringValueOrNull(voorvoegsel));
        ruleExecutor.setTransformedValue(natuurlijkPersoon, XSD_SIGNIFICANTDEELVANDEACHTERNAAM, extractStringValueOrNull(achternaam));
        ruleExecutor.setTransformedValue(natuurlijkPersoon, XSD_CDAANDUIDINGNAAMGEBRUIK, extractStringValueOrNull(codeAanduidingNaamgebruik));
        ruleExecutor.setTransformedValue(natuurlijkPersoon, XSD_GEBOORTEDAT, extractStringValueOrNull(geboortedatum));
        ruleExecutor.setTransformedValue(natuurlijkPersoon, XSD_CDFICTIEVEGEBOORTEDAT, extractStringValueOrNull(codeFictieveGeboortedatum));
        ruleExecutor.setTransformedValue(natuurlijkPersoon, XSD_GESLACHT, geslacht);
    }
}
