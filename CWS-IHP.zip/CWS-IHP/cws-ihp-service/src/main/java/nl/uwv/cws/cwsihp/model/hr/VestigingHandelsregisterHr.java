package nl.uwv.cws.cwsihp.model.hr;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.sql.Date;
import java.util.List;

@Setter
@Getter
@Builder
public class VestigingHandelsregisterHr {

    private String kvkNummer;
    private Long vestigingsNummer;
    private boolean configurationIncludesVestigingsNummer;
    private Long activiteitId;

    private String eersteHandelsnaam;
    private Date datumAanvangVestigingHandelsregister;
    private Integer codeFictieveDatumAanvang;
    private Date datumEindeVestigingHandelsregister;
    private Integer codeFictieveDatumEinde;

    private AdreshoudingHr adreshoudingHr;
    private ActiviteitHandelsregisterHr activiteitHandelsregisterHr;
    private List<OndernemingHr> ondernemingHrList;
    private List<HandelsnaamHr> handelsnaamHrList;
}
