package nl.uwv.cws.cwsihp.service.wg;

import nl.uwv.cws.cwsihp.dao.ihp.RechtsvormWgDao;
import nl.uwv.cws.cwsihp.model.configuratie.CwsIhpConfiguratie;
import nl.uwv.cws.cwsihp.model.wg.RechtsvormWg;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

@Component
public class RechtsvormWgService {

    @Autowired
    private RechtsvormWgDao rechtsvormWgDao;

    public List<RechtsvormWg> findRechtsvormWg(final Long persoonId, final LocalDateTime beschouwingsmoment, final CwsIhpConfiguratie cwsIhpConfiguratie) {
        return rechtsvormWgDao.findRechtsvormWg(persoonId, beschouwingsmoment, cwsIhpConfiguratie);
    }

    public List<RechtsvormWg> getRechtsvormWgEenmanszaak(final CwsIhpConfiguratie cwsIhpConfiguratie) {
        List<String> attributen = cwsIhpConfiguratie.getGroepenGegevens().getRequiredColumnsRechtsvorm();

        final String codeRechtsvorm = attributen.contains("CODE_RECHTSVORM_CGM") ? "001" : null;

        RechtsvormWg rechtsvormWg =  RechtsvormWg.builder()
                .codeRechtsvorm(codeRechtsvorm)
                .build();

        return Arrays.asList(rechtsvormWg);
    }
}
