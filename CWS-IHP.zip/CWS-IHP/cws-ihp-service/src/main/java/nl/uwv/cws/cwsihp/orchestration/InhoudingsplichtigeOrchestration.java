package nl.uwv.cws.cwsihp.orchestration;

import lombok.extern.slf4j.Slf4j;
import nl.uwv.cws.common.aspect.LogPerformance;
import nl.uwv.cws.common.exception.CwsCommonExceptionGenerator;
import nl.uwv.cws.common.model.CwsAuditInformation;
import nl.uwv.cws.common.model.CwsCommonFoutmelding;
import nl.uwv.cws.common.model.configuratie.ConfiguratieKey;
import nl.uwv.cws.common.service.AfnemerService;
import nl.uwv.cws.cwsihp.model.CwsIhpCollectResult;
import nl.uwv.cws.cwsihp.model.CwsIhpFoutmelding;
import nl.uwv.cws.cwsihp.model.configuratie.CwsIhpConfiguratie;
import nl.uwv.cws.cwsihp.model.ihp.Inhoudingsplichtige;
import nl.uwv.cws.cwsihp.model.ihp.PersoonIhp;
import nl.uwv.cws.cwsihp.model.selection.SelectionParameters;
import nl.uwv.cws.cwsihp.service.BeschouwingsmomentService;
import nl.uwv.cws.cwsihp.service.CwsIhpConfiguratieService;
import nl.uwv.cws.cwsihp.service.IdentifierStatusService;
import nl.uwv.cws.cwsihp.service.hr.HandelsregisterFacade;
import nl.uwv.cws.cwsihp.service.wg.WerkgeverFacade;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;

@Component
@Slf4j
public class InhoudingsplichtigeOrchestration {

    @Autowired
    @Qualifier("requestScopedBean")
    private CwsAuditInformation cwsIhpAuditInformation;

    @Autowired
    private IdentifierStatusService identifierStatusService;

    @Autowired
    private AfnemerService afnemerService;

    @Autowired
    private CwsIhpConfiguratieService cwsConfigurationService;

    @Autowired
    private HandelsregisterFacade handelsregisterFacade;

    @Autowired
    private WerkgeverFacade werkgeverFacade;

    @Autowired
    private BeschouwingsmomentService beschouwingsmomentService;

    @LogPerformance
    public CwsIhpCollectResult collectInhoudingsplichtigeUsingKvkNummer(final ConfiguratieKey configuratieKey, final String kvkNummer) {
        log.debug("Zoeken naar inhoudingsplichtige met KVKnummer");
        CwsIhpConfiguratie cwsIhpConfiguratie = getConfiguratie(configuratieKey);
        final LocalDateTime beschouwingsmoment = getBeschouwingsmoment();

        if (!identifierStatusService.isWerkgeverPresent(kvkNummer, beschouwingsmoment)) {
            throw CwsCommonExceptionGenerator.functionalError(CwsCommonFoutmelding.F042);
        }
        final Inhoudingsplichtige inhoudingsplichtigeUhr = identifierStatusService.getInhoudingsplichtigeHr(kvkNummer, beschouwingsmoment);
        final String nummerInhoudingsplichtige = inhoudingsplichtigeUhr.getBsn() != null ? inhoudingsplichtigeUhr.getBsn() : inhoudingsplichtigeUhr.getRsin();

        boolean isPresentInHr = true;
        boolean isPresentInWg = identifierStatusService.isInhoudingsplichtigePresentInWga(nummerInhoudingsplichtige, beschouwingsmoment);

        SelectionParameters selectionParameters = SelectionParameters.builder()
                .kvknummer(kvkNummer)
                .bsn(inhoudingsplichtigeUhr.getBsn())
                .rsin(inhoudingsplichtigeUhr.getRsin())
                .beschouwingsmoment(beschouwingsmoment)
                .cwsIhpConfiguratie(cwsIhpConfiguratie)
                .inhoudingsplichtigeIsPresentInHr(isPresentInHr)
                .inhoudingsplichtigeIsPresentInWg(isPresentInWg)
                .build();

        return getCwsIhpCollectResult(selectionParameters);
    }

    @LogPerformance
    public CwsIhpCollectResult collectInhoudingsplichtigeUsingNummerInhoudingsplichtige(final ConfiguratieKey configuratieKey, final String nummerInhoudingsplichtige) {
        log.debug("Zoeken naar inhoudingsplichtigegegevens met nummer inhoudingsplichtige");
        CwsIhpConfiguratie cwsIhpConfiguratie = getConfiguratie(configuratieKey);
        final LocalDateTime beschouwingsmoment = getBeschouwingsmoment();
        final Inhoudingsplichtige inhoudingsplichtige;

        boolean isPresentInHr = identifierStatusService.isInhoudingsplichtigePresentInHr(nummerInhoudingsplichtige, beschouwingsmoment);
        boolean isPresentInWg = identifierStatusService.isInhoudingsplichtigePresentInWga(nummerInhoudingsplichtige, beschouwingsmoment);
        if (isPresentInHr) {
            inhoudingsplichtige = identifierStatusService.getInhoudingsplichtigeHrByNrIhp(nummerInhoudingsplichtige, beschouwingsmoment);
        } else if (isPresentInWg) {
            inhoudingsplichtige = identifierStatusService.getInhoudingsplichtigeWga(nummerInhoudingsplichtige, beschouwingsmoment);
        } else {
            throw CwsCommonExceptionGenerator.functionalError(CwsIhpFoutmelding.F071);
        }

        SelectionParameters selectionParameters = SelectionParameters.builder()
                .bsn(inhoudingsplichtige.getBsn())
                .rsin(inhoudingsplichtige.getRsin())
                .beschouwingsmoment(beschouwingsmoment)
                .cwsIhpConfiguratie(cwsIhpConfiguratie)
                .inhoudingsplichtigeIsPresentInHr(isPresentInHr)
                .inhoudingsplichtigeIsPresentInWg(isPresentInWg)
                .build();

        return getCwsIhpCollectResult(selectionParameters);
    }

    public CwsIhpCollectResult collectInhoudingsplichtigeUsingLoonheffingNummer(final ConfiguratieKey configuratieKey, final String loonheffingennummer) {
        log.debug("Zoeken naar Inhoudingsplichtigegegevens met Loonheffingennummer");
        CwsIhpConfiguratie cwsIhpConfiguratie = getConfiguratie(configuratieKey);
        final LocalDateTime beschouwingsmoment = getBeschouwingsmoment();

        if (!identifierStatusService.isAdministratieveEenheidPresent(loonheffingennummer, beschouwingsmoment)) {
            throw CwsCommonExceptionGenerator.functionalError(CwsCommonFoutmelding.F065);
        }
        final Inhoudingsplichtige inhoudingsplichtigeWga = identifierStatusService.getInhoudingsplichtigeWga(loonheffingennummer.substring(0, 9), beschouwingsmoment);
        final String nummerInhoudingsplichtige = inhoudingsplichtigeWga.getBsn() != null ? inhoudingsplichtigeWga.getBsn() : inhoudingsplichtigeWga.getRsin();

        boolean isPresentInHr = identifierStatusService.isInhoudingsplichtigePresentInHr(nummerInhoudingsplichtige, beschouwingsmoment);
        boolean isPresentInWg = true;

        SelectionParameters selectionParameters = SelectionParameters.builder()
                .loonheffingennummer(loonheffingennummer)
                .bsn(inhoudingsplichtigeWga.getBsn())
                .rsin(inhoudingsplichtigeWga.getRsin())
                .beschouwingsmoment(beschouwingsmoment)
                .cwsIhpConfiguratie(cwsIhpConfiguratie)
                .inhoudingsplichtigeIsPresentInHr(isPresentInHr)
                .inhoudingsplichtigeIsPresentInWg(isPresentInWg)
                .build();

        return getCwsIhpCollectResult(selectionParameters);
    }

    private CwsIhpConfiguratie getConfiguratie(final ConfiguratieKey configuratieKey) {
        log.debug("Configuratie ophalen");
        CwsIhpConfiguratie cwsIhpConfiguratie = cwsConfigurationService.getConfiguratie(configuratieKey);
        cwsIhpAuditInformation.addDeterminedConfiguratie(cwsIhpConfiguratie);
        log.debug("Gevonden configuratie " + cwsIhpConfiguratie.toString());

        return cwsIhpConfiguratie;
    }

    private LocalDateTime getBeschouwingsmoment() {
        return beschouwingsmomentService.getBeschouwingsmoment();
    }

    private CwsIhpCollectResult getCwsIhpCollectResult(SelectionParameters selectionParameters) {
        if (selectionParameters.isPersoonInhoudingsplichtigeHrWg()) {
            log.debug("Gegevens ophalen uit UHR en WGA");
            List<PersoonIhp> persoonIhpList = handelsregisterFacade.findPersoonIhpMetAeh(selectionParameters);
            return CwsIhpCollectResult.builder()
                    .selectionParameters(selectionParameters)
                    .persoonIhpList(persoonIhpList)
                    .build();

        } else if (selectionParameters.isPersoonInhoudingsplichtigeHr()) {
            log.debug("Gegevens ophalen uit UHR");
            List<PersoonIhp> persoonIhpList = handelsregisterFacade.findPersoonIhpZonderAeh(selectionParameters);
            return CwsIhpCollectResult.builder()
                    .selectionParameters(selectionParameters)
                    .persoonIhpList(persoonIhpList)
                    .build();

        } else {
            log.debug("Gegevens ophalen uit WGA");
            List<PersoonIhp> persoonIhpList = werkgeverFacade.findPersoonIhp(selectionParameters);
            return CwsIhpCollectResult.builder()
                    .selectionParameters(selectionParameters)
                    .persoonIhpList(persoonIhpList)
                    .build();
        }
    }
}
