package nl.uwv.cws.cwsihp.dao.ihp;

import nl.uwv.cws.cwsihp.dao.mapper.FaillissementSurseanceWgRowMapper;
import nl.uwv.cws.cwsihp.model.configuratie.CwsIhpConfiguratie;
import nl.uwv.cws.cwsihp.model.wg.FaillissementSurseanceWg;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public class FaillissementSurseanceWgDao extends BaseDao {

    @Autowired
    private FaillissementSurseanceWgRowMapper faillissementSurseanceWgRowMapper;

    public List<FaillissementSurseanceWg> findFaillissementSurseanceByPersoonId(final Long persoonId, final LocalDateTime beschouwingsmoment, final CwsIhpConfiguratie cwsIhpConfiguratie) {
        Timestamp beschouwingsmomentTimestamp = Timestamp.valueOf(beschouwingsmoment);
        final String sql =
                " SELECT fail_surs_ind " +
                "      , fail_surs_code " +
                "      , dataanv " +
                "      , dateind " +
                " FROM wga_fail_surs " +
                " WHERE per_id = :persoonId " +
                " AND his_ts_in <= :beschouwingsmoment " +
                " AND his_ts_end > :beschouwingsmoment";

        SqlParameterSource namedParameters = new MapSqlParameterSource()
                .addValue("persoonId", persoonId.toString())
                .addValue("beschouwingsmoment", beschouwingsmomentTimestamp);
        List<String> attributen = cwsIhpConfiguratie.getGroepenGegevens().getRequiredColumnsFaillissementSurseance();

        return jdbcTemplate.query(sql, namedParameters, (resultSet, i) -> faillissementSurseanceWgRowMapper.mapRow(resultSet, attributen));
    }

    public List<FaillissementSurseanceWg> findFaillissementSurseanceByNrihp(final String nrihp, final LocalDateTime beschouwingsmoment, final CwsIhpConfiguratie cwsIhpConfiguratie) {
        Timestamp beschouwingsmomentTimestamp = Timestamp.valueOf(beschouwingsmoment);
        final String sql =
                " SELECT fail_surs_ind " +
                "      , fail_surs_code " +
                "      , dataanv " +
                "      , dateind " +
                " FROM wga_fail_surs fai" +
                " INNER JOIN wga_persoon per " +
                " ON fai.per_id = per.per_id " +
                " WHERE (per.finr = :nrihp OR per.sofinr = :nrihp)" +
                " AND his_ts_in <= :beschouwingsmoment " +
                " AND his_ts_end > :beschouwingsmoment";

        SqlParameterSource namedParameters = new MapSqlParameterSource()
                .addValue("nrihp", nrihp)
                .addValue("beschouwingsmoment", beschouwingsmomentTimestamp);
        List<String> attributen = cwsIhpConfiguratie.getGroepenGegevens().getRequiredColumnsFaillissementSurseance();

        return jdbcTemplate.query(sql, namedParameters, (resultSet, i) -> faillissementSurseanceWgRowMapper.mapRow(resultSet, attributen));
    }
}
