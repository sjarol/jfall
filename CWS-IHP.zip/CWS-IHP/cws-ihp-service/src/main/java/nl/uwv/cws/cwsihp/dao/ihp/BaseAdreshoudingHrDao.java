package nl.uwv.cws.cwsihp.dao.ihp;

import nl.uwv.cws.cwsihp.dao.mapper.AdresBuitenlandHrRowMapper;
import nl.uwv.cws.cwsihp.dao.mapper.AdresBuitenlandOngestructureerdHrRowMapper;
import nl.uwv.cws.cwsihp.dao.mapper.AdresNederlandHrRowMapper;
import nl.uwv.cws.cwsihp.model.configuratie.CwsIhpConfiguratie;
import nl.uwv.cws.cwsihp.model.hr.AdresBuitenlandHr;
import nl.uwv.cws.cwsihp.model.hr.AdresBuitenlandOngestructureerdHr;
import nl.uwv.cws.cwsihp.model.hr.AdresNederlandHr;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

import java.util.List;

import static nl.uwv.cws.common.model.CwsCommonConstants.SQL_SELECT;
import static nl.uwv.cws.common.util.DaoUtil.removeNullsFromList;
import static nl.uwv.cws.cwsihp.dao.ihp.AdreshoudingHrQueries.*;

public abstract class BaseAdreshoudingHrDao extends BaseDao {

    @Autowired
    private AdresNederlandHrRowMapper adresNederlandHrRowMapper;

    @Autowired
    private AdresBuitenlandHrRowMapper adresBuitenlandHrRowMapper;

    @Autowired
    private AdresBuitenlandOngestructureerdHrRowMapper adresBuitenlandOngestructureerdHrRowMapper;

    protected List<AdresNederlandHr> findAdresNederland(final String withClause, final SqlParameterSource namedParameters
            , final CwsIhpConfiguratie cwsIhpConfiguratie, final List<String> attributen) {

        String sql = WITH_LOCATIE_ID_AS +
                withClause +
                SQL_SELECT + COMMON_COLUMNS +
                "     , postcode " +
                "     , plaats " +
                "     , woonplaatsnaam_cgm " +
                "     , straatnaam " +
                "     , straatnaam_cgm " +
                "     , huisnummer " +
                "     , huisletter " +
                "     , huisnummer_toevoeging " +
                "     , huisnummer_toevoeging_cgm " +
                "     , code_aand_bij_huisnummer_cgm " +
                "     , postbusnummer " +
                FROM_LOCATIE +
                JOIN_BINNENLANDS +
                WHERE_GELDIGE_ADRESROL +
                (cwsIhpConfiguratie.excludeBeeindigdAdres() ? CONDITION_EXCLUDE_BEEINDIGD_ADRES : "");

        List<AdresNederlandHr> results = jdbcTemplate.query(sql, namedParameters, (resultSet, i) -> adresNederlandHrRowMapper.mapRow(resultSet, attributen));
        removeNullsFromList(results);
        return results;
    }

    protected List<AdresBuitenlandHr> findAdresBuitenland(final String withClause, final SqlParameterSource namedParameters
            , final CwsIhpConfiguratie cwsIhpConfiguratie, final List<String> attributen) {

        String sql = WITH_LOCATIE_ID_AS +
                withClause +
                SQL_SELECT + COMMON_COLUMNS +
                ", postcodebuitenland_cgm " +
                ", woonplaatsnaambuitenland_cgm " +
                ", straatnaambuitenland_cgm " +
                ", huisnummerbuitenland_cgm " +
                ", locatieomschrijving_cgm " +
                ", regionaambuitenland_cgm " +
                ", landcode_gba_cgm " +
                ", landcode_iso_cgm " +
                ", landsnaam_cgm " +
                ", postbusnummer_buitenland_cgm " +
                FROM_LOCATIE +
                JOIN_BUITENLANDS +
                WHERE_GELDIGE_ADRESROL +
                IS_ADRES_BUITENLAND +
                (cwsIhpConfiguratie.excludeBeeindigdAdres() ? CONDITION_EXCLUDE_BEEINDIGD_ADRES : "");

        List<AdresBuitenlandHr> results = jdbcTemplate.query(sql, namedParameters, (resultSet, i) -> adresBuitenlandHrRowMapper.mapRow(resultSet, attributen));
        removeNullsFromList(results);
        return results;
    }

    protected List<AdresBuitenlandOngestructureerdHr> findAdresBuitenlandOngestructureerd(String withClause, SqlParameterSource namedParameters
            , CwsIhpConfiguratie cwsIhpConfiguratie, List<String> attributen) {

        String sql = WITH_LOCATIE_ID_AS +
                withClause +
                SQL_SELECT + COMMON_COLUMNS +
                ", adresregel_1_buitenland_cgm " +
                ", adresregel_2_buitenland_cgm " +
                ", adresregel_3_buitenland_cgm " +
                ", landcode_gba_cgm " +
                ", landsnaam_gba_cgm " +
                ", landcode_iso_cgm " +
                ", landsnaam_cgm " +
                FROM_LOCATIE +
                JOIN_BUITENLANDS +
                WHERE_GELDIGE_ADRESROL +
                IS_ADRES_BUITENLAND_ONGESTRUCTUREERD +
                (cwsIhpConfiguratie.excludeBeeindigdAdres() ? CONDITION_EXCLUDE_BEEINDIGD_ADRES : "");

        return jdbcTemplate.query(sql, namedParameters, (resultSet, i) -> adresBuitenlandOngestructureerdHrRowMapper.mapRow(resultSet, attributen));
    }

}
