package nl.uwv.cws.cwsihp.dao.ihp;

import nl.uwv.cws.cwsihp.dao.mapper.PersoonHrRowMapper;
import nl.uwv.cws.cwsihp.model.hr.PersoonHr;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public class PersoonHrDao extends BaseDao {

    @Autowired
    private PersoonHrRowMapper persoonHrRowMapper;

    public List<PersoonHr> findPersoonHrByBsn(String bsn, final LocalDateTime beschouwingsmoment) {
        final String whereClause = "WHERE bsn = :bsn ";
        return findPersoonByNrIhp(bsn, whereClause, beschouwingsmoment);
    }

    public List<PersoonHr> findPersoonHrByRsin(String rsin, final LocalDateTime beschouwingsmoment) {
        final String whereClause = "WHERE rsin = :rsin ";
        return findPersoonByNrIhp(rsin, whereClause, beschouwingsmoment);
    }

    public List<PersoonHr> findPersoonByNrIhp(String nrIhp, String whereClause, final LocalDateTime beschouwingsmoment) {
        final Timestamp beschouwingsmomentTimestamp = Timestamp.valueOf(beschouwingsmoment);
        final String sql =
                "SELECT per.kvk_nummer, per.persoon_id, per.naam_persoon_id , per.natuurlijkepersoon_id " +
                "FROM uh_persoon per " +
                "JOIN uh_maatschappelijke_activiteit maa " +
                "ON maa.kvk_nummer = per.kvk_nummer " +
                whereClause +
                "AND per.his_ts_in  <= :beschouwingsmoment " +
                "AND per.his_ts_end > :beschouwingsmoment " +
                "ORDER BY maa.datum_einde_cgm DESC, maa.datum_aanvang_cgm DESC, maa.his_ts_in DESC, per.datum_aanvang_cgm DESC " +
                "FETCH FIRST 1 ROWS ONLY";

        MapSqlParameterSource namedParameters = getNamedParameters(whereClause, nrIhp);
        namedParameters.addValue("beschouwingsmoment", beschouwingsmomentTimestamp);

        return jdbcTemplate.query(sql, namedParameters, persoonHrRowMapper);
    }
}
