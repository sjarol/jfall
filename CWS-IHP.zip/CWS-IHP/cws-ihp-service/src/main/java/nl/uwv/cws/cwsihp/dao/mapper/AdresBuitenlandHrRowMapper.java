package nl.uwv.cws.cwsihp.dao.mapper;

import nl.uwv.cws.common.dao.mapper.CwsRowMapper;
import nl.uwv.cws.common.util.NullValueUtil;
import nl.uwv.cws.cwsihp.model.hr.AdresBuitenlandHr;
import nl.uwv.cws.cwsihp.model.hr.AdresBuitenlandPostbusadresHr;
import nl.uwv.cws.cwsihp.model.hr.AdresBuitenlandStraatadresHr;
import org.springframework.stereotype.Component;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

import static nl.uwv.cws.cwsihp.util.DateUtil.setDatumEinde;

@Component
public class AdresBuitenlandHrRowMapper extends CwsRowMapper<AdresBuitenlandHr> {

    @Override
    public AdresBuitenlandHr mapRow(final ResultSet resultSet, final List<String> attributen) throws SQLException {

        // ADRES BUITENLAND
        final String codeAdresrolCgm = readApplicableString(attributen, "CODE_ADRESROL_CGM", resultSet);
        final Date datumAanvangAdreshouding = readApplicableDate(attributen, "DATUM_AANVANG_CGM", resultSet);
        final Integer codeFictieveDatumAanvang = readApplicableNullableInteger(attributen, "CD_DATUM_AANVANG_CGM", resultSet);
        final Date datumEindeAdreshouding = setDatumEinde(readApplicableDate(attributen, "DATUM_EINDE_CGM", resultSet), resultSet.getInt("CD_DATUM_EINDE_CGM"));
        final Integer codeFictieveDatumEinde = readApplicableNullableInteger(attributen, "CD_DATUM_EINDE_CGM", resultSet);
        final Integer codeAfgeschermdAdres = readApplicableNullableInteger(attributen, "IND_AFGESCHERMD_ADRES_CGM", resultSet);

        final boolean isAdresActief = resultSet.getDate("DATUM_EINDE_CGM").after(Timestamp.valueOf(LocalDateTime.now()));

        // STRAATADRES
        String postcodeBuitenland = null;
        String woonplaatsnaamBuitenland = null;
        String regionaamBuitenland = null;
        Integer landcodeGba = null;
        String landcodeIso = null;
        String landsnaam = null;
        String straatnaamBuitenland = null;
        String huisnummerBuitenland = null;
        String locatieomschrijvingBuitenland = null;

        // POSTBUSADRES
        String postcodePostbusadresBuitenland = null;
        String woonplaatsnaamPostbusadresBuitenland = null;
        String regionaamPostbusadresBuitenland = null;
        Integer landcodeGbaPostbusadres = null;
        String landcodeIsoPostbusadres = null;
        String landsnaamPostbusadres = null;
        final String postbusnummerBuitenland = resultSet.getString("POSTBUSNUMMER_BUITENLAND_CGM");

        if (postbusnummerBuitenland == null) {
            postcodeBuitenland = readApplicableString(attributen, "POSTCODEBUITENLAND_CGM", resultSet);
            woonplaatsnaamBuitenland = readApplicableString(attributen, "WOONPLAATSNAAMBUITENLAND_CGM", resultSet);
            regionaamBuitenland = readApplicableString(attributen, "REGIONAAMBUITENLAND_CGM", resultSet);
            landcodeGba = readApplicableNullableInteger(attributen, "LANDCODE_GBA_CGM", resultSet);
            landcodeIso = readApplicableString(attributen, "LANDCODE_ISO_CGM", resultSet);
            landsnaam = readApplicableString(attributen, "LANDSNAAM_CGM", resultSet);
            straatnaamBuitenland = readApplicableString(attributen, "STRAATNAAMBUITENLAND_CGM", resultSet);
            huisnummerBuitenland = readApplicableString(attributen, "HUISNUMMERBUITENLAND_CGM", resultSet);
            locatieomschrijvingBuitenland = readApplicableString(attributen, "LOCATIEOMSCHRIJVING_CGM", resultSet);
        } else {
            postcodePostbusadresBuitenland = readApplicablePostbusString(attributen, "POSTBUS_POSTCODEBL_CGM", "POSTCODEBUITENLAND_CGM", resultSet);
            woonplaatsnaamPostbusadresBuitenland = readApplicablePostbusString(attributen, "POSTBUS_WOONPLAATSNAAMBL_CGM", "WOONPLAATSNAAMBUITENLAND_CGM", resultSet);
            regionaamPostbusadresBuitenland = readApplicablePostbusString(attributen, "POSTBUS_REGIONAAMBL_CGM", "REGIONAAMBUITENLAND_CGM", resultSet);
            landcodeGbaPostbusadres = readApplicableNullablePostbusInteger(attributen, "POSTBUS_LANDCODE_GBA_CGM", "LANDCODE_GBA_CGM", resultSet);
            landcodeIsoPostbusadres = readApplicablePostbusString(attributen, "POSTBUS_LANDCODE_ISO_CGM", "LANDCODE_ISO_CGM", resultSet);
            landsnaamPostbusadres = readApplicablePostbusString(attributen, "POSTBUS_LANDSNAAM_CGM", "LANDSNAAM_CGM", resultSet);
        }

        AdresBuitenlandStraatadresHr straatadresHr = AdresBuitenlandStraatadresHr.builder()
                .postcodeBuitenland(postcodeBuitenland)
                .woonplaatsnaamBuitenland(woonplaatsnaamBuitenland)
                .regionaamBuitenland(regionaamBuitenland)
                .landcodeGba(landcodeGba)
                .landcodeIso(landcodeIso)
                .landsnaam(landsnaam)
                .straatnaamBuitenland(straatnaamBuitenland)
                .huisnummerBuitenland(huisnummerBuitenland)
                .locatieomschrijvingBuitenland(locatieomschrijvingBuitenland)
                .build();

        AdresBuitenlandPostbusadresHr postbusadresHr = AdresBuitenlandPostbusadresHr.builder()
                .postcodeBuitenland(postcodePostbusadresBuitenland)
                .woonplaatsnaamBuitenland(woonplaatsnaamPostbusadresBuitenland)
                .regionaamBuitenland(regionaamPostbusadresBuitenland)
                .landcodeGba(landcodeGbaPostbusadres)
                .landcodeIso(landcodeIsoPostbusadres)
                .landsnaam(landsnaamPostbusadres)
                .postbusnummerBuitenland((attributen.contains("POSTBUSNUMMER_BUITENLAND_CGM") ? postbusnummerBuitenland : null))
                .build();

        return AdresBuitenlandHr.builder()
                    .codeAdresrol(codeAdresrolCgm)
                    .datumAanvangAdreshouding(datumAanvangAdreshouding)
                    .codeFictieveDatumAanvang(codeFictieveDatumAanvang)
                    .datumEindeAdreshouding(datumEindeAdreshouding)
                    .codeFictieveDatumEinde(codeFictieveDatumEinde)
                    .codeAfgeschermdAdres(codeAfgeschermdAdres)
                    .straatadresHr(straatadresHr)
                    .postbusadresHr(postbusadresHr)
                    .isAdresActief(isAdresActief)
                    .build();
    }

    private String readApplicablePostbusString(List<String> attributen, String attributeLabel, String columnLabel, ResultSet resultSet) throws SQLException {
        return attributen.contains(attributeLabel) ? resultSet.getString(columnLabel) : null;
    }

    private Integer readApplicableNullablePostbusInteger(List<String> attributen, String attributeLabel, String columnLabel, ResultSet resultSet) throws SQLException {
        return attributen.contains(attributeLabel) ? NullValueUtil.getIntegerOrNull(resultSet, columnLabel) : null;
    }
}
