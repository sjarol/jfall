package nl.uwv.cws.cwsihp.model.wg;

import lombok.Getter;
import lombok.experimental.SuperBuilder;

@SuperBuilder
@Getter
public class AdresNederlandWg extends AdresWg {
    private Long datumAanvangAdreshouding;
    private Long datumEindeAdreshouding;

    private AdresNederlandStraatadresWg straatadresWg;
    private AdresNederlandPostbusadresWg postbusadresWg;
}
