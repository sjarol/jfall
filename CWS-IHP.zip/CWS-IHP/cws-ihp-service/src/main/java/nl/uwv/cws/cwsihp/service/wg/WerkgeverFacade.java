package nl.uwv.cws.cwsihp.service.wg;

import nl.uwv.cws.cwsihp.model.ihp.PersoonIhp;
import nl.uwv.cws.cwsihp.model.selection.SelectionParameters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.List;

@Component
public class WerkgeverFacade {

    @Autowired
    private SofinrWgService sofinrWgService;

    @Autowired
    private FinrWgService finrWgService;

    public List<PersoonIhp> findPersoonIhp(SelectionParameters selectionParameters) {
        final String sofinr = selectionParameters.getBsn();

        List<PersoonIhp> persoonIhp;
        if (StringUtils.hasText(sofinr)) {
            persoonIhp = sofinrWgService.findPersoonIhp(selectionParameters);
        } else {
            persoonIhp = finrWgService.findPersoonIhp(selectionParameters);
        }

        return persoonIhp;
    }
}
