package nl.uwv.cws.cwsihp.model.wg;

import lombok.Getter;
import lombok.experimental.SuperBuilder;

@SuperBuilder
@Getter
public class AdresBuitenlandWg extends AdresWg {
    private Long datumAanvangAdreshouding;
    private Long datumEindeAdreshouding;

    private AdresBuitenlandStraatadresWg straatadresWg;
    private AdresBuitenlandPostbusadresWg postbusadresWg;
}
