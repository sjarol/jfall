package nl.uwv.cws.cwsihp.dao.mapper;

import nl.uwv.cws.common.dao.mapper.CwsRowMapper;
import nl.uwv.cws.common.util.NullValueUtil;
import nl.uwv.cws.cwsihp.model.hr.AdresNederlandHr;
import nl.uwv.cws.cwsihp.model.hr.AdresNederlandPostbusadresHr;
import nl.uwv.cws.cwsihp.model.hr.AdresNederlandStraatadresHr;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

import static nl.uwv.cws.cwsihp.util.DateUtil.setDatumEinde;

@Component
public class AdresNederlandHrRowMapper extends CwsRowMapper<AdresNederlandHr> {

    static final String CD_DATUM_EINDE_CGM = "CD_DATUM_EINDE_CGM";
    static final String WOONPLAATSNAAM_CGM = "WOONPLAATSNAAM_CGM";

    @Override
    public AdresNederlandHr mapRow(final ResultSet resultSet, final List<String> attributen) throws SQLException {

        final String statusAdres = resultSet.getString("STATUS_ADRES");

        // ADRESNEDERLAND
        final String codeAdresrolCgm = readApplicableString(attributen, "CODE_ADRESROL_CGM", resultSet);
        final Date datumAanvangAdreshouding = readApplicableDate(attributen, "DATUM_AANVANG_CGM", resultSet);
        final Integer codeFictieveDatumAanvang = readApplicableNullableInteger(attributen, "CD_DATUM_AANVANG_CGM", resultSet);
        final Date datumEindeAdreshouding = setDatumEinde(readApplicableDate(attributen, "DATUM_EINDE_CGM", resultSet), resultSet.getInt(CD_DATUM_EINDE_CGM));
        final Integer codeFictieveDatumEinde = readApplicableNullableInteger(attributen, CD_DATUM_EINDE_CGM, resultSet);
        final Integer codeAfgeschermdAdres = readApplicableNullableInteger(attributen, "IND_AFGESCHERMD_ADRES_CGM", resultSet);

        final boolean isAdresActief = resultSet.getDate("DATUM_EINDE_CGM").after(Timestamp.valueOf(LocalDateTime.now()));

        // STRAATADRES
        String postcodeStraatadres = null;
        String woonplaatsnaamStraatadres = null;
        String straatnaam = null;
        Integer huisnummer = null;
        String huisletter = null;
        String huisnummertoevoeging = null;
        String codeAanduidingBijHuisnummer = null;
        String naamOpenbareRuimte = null;

        // POSTBUSADRES
        String postcodePostbusadres = null;
        String woonplaatsnaamPostbusadres = null;
        final Integer postbusnummer = NullValueUtil.getIntegerOrNull(resultSet, "POSTBUSNUMMER");

        if (postbusnummer == null) {
            postcodeStraatadres = readApplicableString(attributen, "POSTCODE", resultSet);
            woonplaatsnaamStraatadres = readApplicableString(attributen, WOONPLAATSNAAM_CGM, resultSet);
            straatnaam = readApplicableString(attributen, "STRAATNAAM_CGM", resultSet);
            huisnummer = readApplicableNullableInteger(attributen, "HUISNUMMER", resultSet);
            huisletter = readApplicableString(attributen, "HUISLETTER", resultSet);
            huisnummertoevoeging = readApplicableString(attributen, "HUISNUMMER_TOEVOEGING_CGM", resultSet);
            if (StringUtils.hasText(statusAdres) && statusAdres.equalsIgnoreCase("n")) {
                woonplaatsnaamStraatadres = readApplicableStringWhenNoCgmValue(attributen, WOONPLAATSNAAM_CGM, "PLAATS", resultSet);
                straatnaam = readApplicableStringWhenNoCgmValue(attributen, "STRAATNAAM_CGM", "STRAATNAAM", resultSet);
                huisnummertoevoeging = readApplicableStringWhenNoCgmValue(attributen, "HUISNUMMER_TOEVOEGING_CGM", "HUISNUMMER_TOEVOEGING", resultSet);
            }
            codeAanduidingBijHuisnummer = readApplicableString(attributen, "CODE_AAND_BIJ_HUISNUMMER_CGM", resultSet);
            naamOpenbareRuimte = readApplicableString(attributen, "STRAATNAAM", resultSet);
        } else  {
            postcodePostbusadres = readApplicablePostbusString(attributen, "POSTBUS_POSTCODE", "POSTCODE", resultSet);
            woonplaatsnaamPostbusadres = readApplicablePostbusString(attributen, "POSTBUS_WOONPLAATSNAAM_CGM", WOONPLAATSNAAM_CGM, resultSet);
            if (StringUtils.hasText(statusAdres) && statusAdres.equalsIgnoreCase("n")) {
                woonplaatsnaamPostbusadres = readApplicableStringWhenNoCgmValue(attributen, WOONPLAATSNAAM_CGM, "PLAATS", resultSet);
            }
        }

        AdresNederlandStraatadresHr straatadresHr = AdresNederlandStraatadresHr.builder()
                .postcode(postcodeStraatadres)
                .woonplaatsnaam(woonplaatsnaamStraatadres)
                .straatnaam(straatnaam)
                .huisnummer(huisnummer)
                .huisletter(huisletter)
                .huisnummertoevoeging(huisnummertoevoeging)
                .codeAanduidingBijHuisnummer(codeAanduidingBijHuisnummer)
                .naamOpenbareRuimte(naamOpenbareRuimte)
                .build();

        AdresNederlandPostbusadresHr postbusadresHr = AdresNederlandPostbusadresHr.builder()
                .postcode(postcodePostbusadres)
                .woonplaatsnaam(woonplaatsnaamPostbusadres)
                .postbusnummer((attributen.contains("POSTBUSNUMMER") ? postbusnummer : null))
                .build();

        return AdresNederlandHr.builder()
                    .codeAdresrol(codeAdresrolCgm)
                    .datumAanvangAdreshouding(datumAanvangAdreshouding)
                    .codeFictieveDatumAanvang(codeFictieveDatumAanvang)
                    .datumEindeAdreshouding(datumEindeAdreshouding)
                    .codeFictieveDatumEinde(codeFictieveDatumEinde)
                    .codeAfgeschermdAdres(codeAfgeschermdAdres)
                    .straatadresHr(straatadresHr)
                    .postbusadresHr(postbusadresHr)
                    .isAdresActief(isAdresActief)
                    .build();
    }

    private String readApplicablePostbusString(List<String> attributen, String attributeLabel, String columnLabel, ResultSet resultSet) throws SQLException {
        return readApplicableStringWhenNoCgmValue(attributen, attributeLabel, columnLabel, resultSet);
    }

    private String readApplicableStringWhenNoCgmValue(List<String> attributen, String attributeLabel, String columnLabel, ResultSet resultSet) throws SQLException {
        return attributen.contains(attributeLabel) ? resultSet.getString(columnLabel) : null;
    }
}
