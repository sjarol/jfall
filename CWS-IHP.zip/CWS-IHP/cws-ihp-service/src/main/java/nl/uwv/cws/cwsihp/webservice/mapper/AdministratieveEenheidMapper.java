package nl.uwv.cws.cwsihp.webservice.mapper;

import nl.uwv.cws.cwsihp.model.wg.AdministratieveEenheidWg;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0007.CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import static nl.uwv.cws.common.util.MapperUtil.collectNonEmptyObject;
import static nl.uwv.cws.common.util.MapperUtil.mapToJaxbListIfNotEmpty;
import static nl.uwv.cws.common.util.NullValueUtil.extractStringValueOrNull;
import static nl.uwv.cws.cwsihp.model.CwsIhpConstants.*;

@Component
public class AdministratieveEenheidMapper extends BaseMapper {

    @Autowired
    private SectorRisicogroepMapper sectorRisicogroepMapper;

    @Autowired
    private PremiepercentageIndividueelMapper premiepercentageIndividueelMapper;

    @Autowired
    private EigenRisicoDragerMapper eigenRisicoDragerMapper;

    @Autowired
    private AdreshoudingMapper adreshoudingMapper;

    @Autowired
    private VoortzettingsrelatieOpvolgerMapper voortzettingsrelatieOpvolgerMapper;

    @Autowired
    private VoortzettingsrelatieVoorgangerMapper voortzettingsrelatieVoorgangerMapper;

    @Autowired
    private AangifteFrequentieAdministratieveEenheidMapper aangifteFrequentieAdministratieveEenheidMapper;

    @Autowired
    private AansluitingsnummerBvMapper aansluitingsnummerBvMapper;

    public AdministratieveEenheid mapToJaxbAdministratieveEenheid(AdministratieveEenheidWg administratieveEenheidWg) {
        AdministratieveEenheid administratieveEenheid = new AdministratieveEenheid();
        mapToJaxbAdministratieveEenheid(administratieveEenheidWg, administratieveEenheid);

        mapToJaxbListIfNotEmpty(administratieveEenheidWg.getSectorRisicogroepList(),
                administratieveEenheid.getSectorRisicogroep(),
                sectorRisicogroepMapper::mapToJaxbSectorRisicogroep);

        mapToJaxbListIfNotEmpty(administratieveEenheidWg.getPremiepercentageIndividueelList(),
                administratieveEenheid.getPremiepercIndividueel(),
                premiepercentageIndividueelMapper::mapToJaxbPremiepercentageIndividueel);

        mapToJaxbListIfNotEmpty(administratieveEenheidWg.getEigenRisicoDragerList(),
                administratieveEenheid.getEigenRisicoDrager(),
                eigenRisicoDragerMapper::mapToJaxbEigenRisicoDrager);

        mapToJaxbListIfNotEmpty(administratieveEenheidWg.getAdreshouding().getAdresNederlandWgList(),
                administratieveEenheid.getAdreshouding(),
                adreshoudingMapper::mapToJaxbAdresNederlandWg);

        mapToJaxbListIfNotEmpty(administratieveEenheidWg.getAdreshouding().getAdresBuitenlandWgList(),
                administratieveEenheid.getAdreshouding(),
                adreshoudingMapper::mapToJaxbAdresBuitenlandWg);

        mapToJaxbListIfNotEmpty(administratieveEenheidWg.getAdreshouding().getAdresBuitenlandOngestructureerdWgList(),
                administratieveEenheid.getAdreshouding(),
                adreshoudingMapper::mapToJaxbAdresBuitenlandOngestructureerdWg);

        mapToJaxbListIfNotEmpty(administratieveEenheidWg.getVoortzettingsrelatieOpvolgerList(),
                administratieveEenheid.getVoortzettingsrelatieOpvolger(),
                voortzettingsrelatieOpvolgerMapper::mapToJaxbVoortzettingsrelatieOpvolger);

        mapToJaxbListIfNotEmpty(administratieveEenheidWg.getVoortzettingsrelatieVoorgangerList(),
                administratieveEenheid.getVoortzettingsrelatieVoorganger(),
                voortzettingsrelatieVoorgangerMapper::mapToJaxbVoortzettingsrelatieVoorganger);

        mapToJaxbListIfNotEmpty(administratieveEenheidWg.getAangiftefrequentieAdministratieveEenheidList(),
                administratieveEenheid.getAangifteFrequentieAdminEenheid(),
                aangifteFrequentieAdministratieveEenheidMapper::mapToJaxbAangifteFrequentieAdministratieveEenheid);

        mapToJaxbListIfNotEmpty(administratieveEenheidWg.getAansluitingsnummerBvList(),
                administratieveEenheid.getAansluitingsnrBv(),
                aansluitingsnummerBvMapper::mapToJaxbAansluitingsnummerBv);

        return collectNonEmptyObject(administratieveEenheid);
    }

    private void mapToJaxbAdministratieveEenheid(AdministratieveEenheidWg administratieveEenheidWg, AdministratieveEenheid administratieveEenheid) {

        final String loonheffingennummer = administratieveEenheidWg.getLoonheffingennummer();
        final String naamAdministratieveEenheid = administratieveEenheidWg.getNaamAdministratieveEenheid();
        final Long datumAanvangAdministratieveEenheid = administratieveEenheidWg.getDatumAanvangAdministratieveEenheid();
        final Long datumEindeAdministratieveEenheid = administratieveEenheidWg.getDatumEindeAdministratieveEenheid();

        ruleExecutor.setTransformedValue(administratieveEenheid, XSD_LOONHEFFINGENNR, loonheffingennummer);
        ruleExecutor.setTransformedValue(administratieveEenheid, XSD_NAAMADMINEENHEID, naamAdministratieveEenheid);
        ruleExecutor.setTransformedValue(administratieveEenheid, XSD_DATBADMINEENHEID, extractStringValueOrNull(datumAanvangAdministratieveEenheid));
        ruleExecutor.setTransformedValue(administratieveEenheid, XSD_DATEADMINEENHEID, extractStringValueOrNull(datumEindeAdministratieveEenheid));
    }
}
