package nl.uwv.cws.cwsihp.webservice.rule.transformer;

import nl.uwv.cws.common.model.CwsCommonConstants;
import nl.uwv.cws.common.model.rule.AttributeRuleProperties;
import nl.uwv.cws.common.webservice.rule.transformer.RuleValueTransformer;
import nl.uwv.cws.cwsihp.model.rule.CwsIhpAttributeRule;
import org.springframework.stereotype.Component;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static nl.uwv.cws.cwsihp.model.rule.CwsIhpAttributeRule.AFKAPPEN_OBV_SIZE_MAX_EN_MES1_EN_GEEN_GETALLEN;
import static org.apache.commons.lang3.StringUtils.truncate;
import static org.springframework.util.StringUtils.hasText;

@Component
public class AfkappenObvSizeMaxEnMes1EnGeenGetallenTransformer implements RuleValueTransformer<String, String> {
    private static final Pattern DIGIT_PATTERN = Pattern.compile("\\d");
    @Override
    public CwsIhpAttributeRule getTransformRule() {
        return AFKAPPEN_OBV_SIZE_MAX_EN_MES1_EN_GEEN_GETALLEN;
    }

    @Override
    public String transform(String originalValue, AttributeRuleProperties attributeRuleProperties) {
        String truncatedValue = truncate(originalValue, attributeRuleProperties.getSizeMax());
        if (hasText(truncatedValue)) {
            truncatedValue = replaceNonMes1WithQuestionMark(truncatedValue);
            truncatedValue = replaceDigitWithQuestionMark(truncatedValue);
        }
        return truncatedValue;
    }

    private String replaceNonMes1WithQuestionMark(String truncatedValue) {
        return CwsCommonConstants.ANY_NON_MES1_PATTERN.matcher(truncatedValue).replaceAll("?");
    }

    private String replaceDigitWithQuestionMark(String truncatedValue) {
        Matcher matcher = DIGIT_PATTERN.matcher(truncatedValue);
        if (matcher.find()) {
            truncatedValue = matcher.replaceAll("?");
        }
        return truncatedValue;
    }
}
