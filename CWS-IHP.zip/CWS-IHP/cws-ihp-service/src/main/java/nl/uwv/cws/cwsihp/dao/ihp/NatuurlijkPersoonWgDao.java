package nl.uwv.cws.cwsihp.dao.ihp;

import nl.uwv.cws.cwsihp.dao.mapper.NatuurlijkPersoonWgRowMapper;
import nl.uwv.cws.cwsihp.model.configuratie.CwsIhpConfiguratie;
import nl.uwv.cws.cwsihp.model.wg.NatuurlijkPersoonWg;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

import static nl.uwv.cws.common.util.DaoUtil.findOneOrNone;

@Repository
public class NatuurlijkPersoonWgDao extends BaseDao {
	
	@Autowired
	private NatuurlijkPersoonWgRowMapper rowMapper;

	public NatuurlijkPersoonWg findNatuurlijkPersoonWg(final Long persoonId, LocalDateTime beschouwingsmoment, CwsIhpConfiguratie cwsIhpConfiguratie) {
		Timestamp beschouwingsmomentTimestamp = Timestamp.valueOf(beschouwingsmoment);
		String sql =
				"SELECT bsn, voorletters, voornamen, voorvoegsel, achternaam, cd_aanduiding_naamgebruik_cgm, geboortedatum_cgm, geslacht, " +
				"       voorv_geslachtsnm_partner, geslachtsnaampartner " +
				"FROM ( SELECT per.sofinr AS bsn " +
				"            , NVL2(upa_prs.bsn, upa_prs.voorletters, npn.voorletters) AS voorletters " +
				"            , NVL2(upa_prs.bsn, upa_prs.voornamen, npn.voornamen) AS voornamen " +
				"            , NVL2(upa_prs.bsn, upa_prs.voorvoegsel, npn.voorvoegsel) AS voorvoegsel " +
				"            , NVL2(upa_prs.bsn, upa_prs.significant_deel_achternaam, npn.sig_achternaam) AS achternaam " +
				"            , NVL2(upa_prs.bsn, upa_prs.ang_code, npn.ang_code) AS cd_aanduiding_naamgebruik_cgm " +
				"            , npn.dat_geboren AS geboortedatum_cgm " +
				"            , NVL2(upa_prs.bsn, upa_prs.geslacht, npn.geslacht) AS geslacht " +
				"            , NVL2(upa_prs.bsn, upa_prs.voorvoegsel_partnr, npn.voorvoegsel_partner) AS voorv_geslachtsnm_partner " +
				"            , NVL2(upa_prs.bsn, upa_prs.sign_deel_achternaam_partnr, npn.sig_achternaam_partner) AS geslachtsnaampartner " +
				"            , ROW_NUMBER() OVER (PARTITION BY npn.per_id ORDER BY npn.his_ts_in DESC) AS rn " +
				"		FROM wga_persoon per " +
				"       LEFT OUTER JOIN wga_npn_persoon_his npn " +
				"       ON per.per_id = npn.per_id " +
				"       AND npn.his_ts_in  <= :beschouwingsmoment " +
				"       AND npn.his_ts_end > :beschouwingsmoment " +
				"       LEFT OUTER JOIN TABLE (upa_lev_get_upanaam( per.sofinr )) upa_prs " +
				"       ON upa_prs.bsn = per.sofinr " +
				"       WHERE per.per_id = :persoonId)" +
				"WHERE rn = 1";

		MapSqlParameterSource namedParameters = new MapSqlParameterSource()
				.addValue("persoonId", persoonId)
				.addValue("beschouwingsmoment", beschouwingsmomentTimestamp);

		List<String> attributen = cwsIhpConfiguratie.getGroepenGegevens().getRequiredColumnsNatuurlijkPersoon();
		attributen.addAll(cwsIhpConfiguratie.getGroepenGegevens().getRequiredColumnsHuwelijkGeregistreerdPartnerschap());
		List<NatuurlijkPersoonWg> results = jdbcTemplate.query(sql, namedParameters, (resultSet, i) -> rowMapper.mapRow(resultSet, attributen));
		String errorMessage = "Meerdere rijen gevonden";
		return findOneOrNone(errorMessage, results);
	}
}
