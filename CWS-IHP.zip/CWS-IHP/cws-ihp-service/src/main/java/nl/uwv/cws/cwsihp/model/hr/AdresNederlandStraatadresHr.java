package nl.uwv.cws.cwsihp.model.hr;

import lombok.Builder;
import lombok.Getter;

@Builder
@Getter
public class AdresNederlandStraatadresHr {
    private String postcode;
    private String woonplaatsnaam;
    private String straatnaam;
    private Integer huisnummer;
    private String huisletter;
    private String huisnummertoevoeging;
    private String codeAanduidingBijHuisnummer;
    private String naamOpenbareRuimte;
}
