package nl.uwv.cws.cwsihp.model.ihp;

import lombok.Builder;
import lombok.Getter;

@Builder
@Getter
public class Inhoudingsplichtige {
    private String bsn;
    private String rsin;
}
