package nl.uwv.cws.cwsihp.dao.mapper;

import nl.uwv.cws.common.dao.mapper.CwsRowMapper;
import nl.uwv.cws.cwsihp.model.wg.AdresNederlandPostbusadresWg;
import nl.uwv.cws.cwsihp.model.wg.AdresNederlandStraatadresWg;
import nl.uwv.cws.cwsihp.model.wg.AdresNederlandWg;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import static nl.uwv.cws.common.util.ConverterUtil.totDatumToTotEnMetDatum;

@Component
public class AdresNederlandWgRowMapper extends CwsRowMapper<AdresNederlandWg> {

    @Override
    public AdresNederlandWg mapRow(final ResultSet resultSet, final List<String> attributen) throws SQLException {

        // ADRES NEDERLAND
        final String codeAdresrol = readApplicableString(attributen, "ADRESROL", resultSet);
        final Long datumAanvangAdreshouding = readApplicableNullableLong(attributen, "DATAANV", resultSet);
        final Long datumEindeAdreshouding = totDatumToTotEnMetDatum(readApplicableNullableLong(attributen, "DATEIND", resultSet));

        final String adrestype = resultSet.getString("ADRESTYPEK33");
        AdresNederlandStraatadresWg straatadresWg = null;
        AdresNederlandPostbusadresWg postbusadresWg= null;

        // STRAATADRES
        String postcode = null;
        String woonplaatsnaam = null;
        String gemeentenaam = null;
        String straatnaam = null;
        Integer huisnummer = null;
        String huisnummerToevoeging = null;
        String locatieomschrijving = null;

        // POSTBUSADRES
        String postbusPostcode = null;
        String postbusWoonplaatsnaam = null;
        Integer postbusnummer = null;


        // STRAATADRES
        if (adrestype.equals("SAN")) {
            postcode = readApplicableString(attributen, "POSTCODE", resultSet);
            woonplaatsnaam = readApplicableString(attributen, "WOONPLAATS", resultSet);
            gemeentenaam = readApplicableString(attributen, "GEMEENTENAAM", resultSet);
            straatnaam = readApplicableString(attributen, "STRAATNAAM", resultSet);
            huisnummer = readApplicableNullableInteger(attributen, "HUISNR", resultSet);
            huisnummerToevoeging = readApplicableString(attributen, "HUISNR_TOEV", resultSet);
            locatieomschrijving = readApplicableString(attributen, "LOCATIE_OMSCH", resultSet);
        // POSTBUSADRES
        } else {
            postbusPostcode = readApplicablePostbusString(attributen, "POSTBUS_POSTCODE", "POSTCODE", resultSet);
            postbusWoonplaatsnaam = readApplicablePostbusString(attributen, "POSTBUS_WOONPLAATS", "WOONPLAATS", resultSet);
            postbusnummer = readApplicableNullableInteger(attributen, "POSTBUSNR", resultSet);
        }

        straatadresWg = AdresNederlandStraatadresWg.builder()
                .postcode(postcode)
                .woonplaatsnaam(woonplaatsnaam)
                .gemeentenaam(gemeentenaam)
                .straatnaam(straatnaam)
                .huisnummer(huisnummer)
                .huisnummerToevoeging(huisnummerToevoeging)
                .locatieomschrijving(locatieomschrijving)
                .build();

        postbusadresWg = AdresNederlandPostbusadresWg.builder()
                .postcode(postbusPostcode)
                .woonplaatsnaam(postbusWoonplaatsnaam)
                .postbusnummer(postbusnummer)
                .build();

        return AdresNederlandWg.builder()
                    .codeAdresrol(codeAdresrol)
                    .datumAanvangAdreshouding(datumAanvangAdreshouding)
                    .datumEindeAdreshouding(datumEindeAdreshouding)
                    .straatadresWg(straatadresWg)
                    .postbusadresWg(postbusadresWg)
                    .build();
    }

    private String readApplicablePostbusString(List<String> attributen, String attributeLabel, String columnLabel, ResultSet resultSet) throws SQLException {
        return attributen.contains(attributeLabel) ? resultSet.getString(columnLabel) : null;
    }
}
