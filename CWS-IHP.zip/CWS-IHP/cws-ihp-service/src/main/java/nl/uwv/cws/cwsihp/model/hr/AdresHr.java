package nl.uwv.cws.cwsihp.model.hr;

import lombok.Getter;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

import java.sql.Date;

@SuperBuilder
@Getter
@ToString
public abstract class AdresHr {
    private Date datumEindeAdreshouding;
    private boolean isAdresActief;
}
