package nl.uwv.cws.cwsihp.model.ihp;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import nl.uwv.cws.cwsihp.model.hr.NietNatuurlijkPersoonHr;
import nl.uwv.cws.cwsihp.model.wg.NietNatuurlijkPersoonWg;

@Builder
@Getter
@Setter
public class NietNatuurlijkPersoonIhp {

    private NietNatuurlijkPersoonHr nietNatuurlijkPersoonHr;
    private NietNatuurlijkPersoonWg nietNatuurlijkPersoonWg;
}
