package nl.uwv.cws.cwsihp.service;

import nl.uwv.cws.common.dao.configuratie.ConfiguratieAttribuutDao;
import nl.uwv.cws.common.dao.configuratie.ConfiguratieDao;
import nl.uwv.cws.common.model.configuratie.Configuratie;
import nl.uwv.cws.common.model.configuratie.ConfiguratieAttribuut;
import nl.uwv.cws.common.model.configuratie.ConfiguratieKey;
import nl.uwv.cws.common.service.ConfiguratieService;
import nl.uwv.cws.cwsihp.model.CwsIhpConstants;
import nl.uwv.cws.cwsihp.model.configuratie.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Component
@CacheConfig(cacheNames = {"configuratie"})
public class CwsIhpConfiguratieService {

    @Autowired
    private ConfiguratieService<ConfiguratieSoortSelectie, ConfiguratieGroepenGegevens> configuratieService;

    @Autowired
    private ConfiguratieDao<ConfiguratieSoortSelectie, ConfiguratieGroepenGegevens> configuratieDao;

    @Autowired
    private ConfiguratieAttribuutDao configuratieAttribuutDao;

    @Cacheable({"configuratie"})
    public CwsIhpConfiguratie getConfiguratie(ConfiguratieKey configuratieKey) {
        Configuratie<ConfiguratieSoortSelectie, ConfiguratieGroepenGegevens> configuratie = configuratieService.findByConfiguratieKey(configuratieKey);
        CwsIhpConfiguratie cwsIhpConfiguratie = CwsIhpConfiguratie.deepCopy(configuratie);
        configuratieService.validateFoundConfiguratie(cwsIhpConfiguratie);

        ConfiguratieSoortSelectie soortSelectie = setUpSoortSelectie(cwsIhpConfiguratie.getCconId());
        ConfiguratieGroepenGegevens groepenGegevens = setUpGroepenGegevens(cwsIhpConfiguratie.getCconId());

        cwsIhpConfiguratie.setSoortSelectie(soortSelectie);
        cwsIhpConfiguratie.setGroepenGegevens(groepenGegevens);

        return cwsIhpConfiguratie;
    }

   private ConfiguratieSoortSelectie setUpSoortSelectie(Long cconId) {
        Map<String, String> filterKeyValues = configuratieDao.findFilterKeyValuesByCconIdAndLevCd(cconId, CwsIhpConstants.LEV_CD);
        return ConfiguratieSoortSelectie.build(filterKeyValues);
    }

    private ConfiguratieGroepenGegevens setUpGroepenGegevens(Long cconId) {
        ConfiguratieGroepenGegevens groepenGegevens = new ConfiguratieGroepenGegevens();
        List<ConfiguratieAttribuut> configuratieAttribuutList = configuratieAttribuutDao.findByCconId(cconId);
        groepenGegevens.applyConfiguratieAttribuutData(configuratieAttribuutList);
        return groepenGegevens;
    }

}
