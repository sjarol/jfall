package nl.uwv.cws.cwsihp.dao.mapper;

import nl.uwv.cws.common.dao.mapper.CwsRowMapper;
import nl.uwv.cws.cwsihp.model.wg.RechtsvormWg;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import static nl.uwv.cws.common.util.ConverterUtil.totDatumToTotEnMetDatum;

@Component
public class RechtsvormWgRowMapper extends CwsRowMapper<RechtsvormWg> {

    @Override
    public RechtsvormWg mapRow(final ResultSet resultSet, final List<String> attributen) throws SQLException {
        final String codeRechtsvorm = readApplicableString(attributen, "CODE_RECHTSVORM_CGM", resultSet);
        final Long datumAanvang = readApplicableNullableLong(attributen, "DATUM_AANVANG_CGM", resultSet);
        final Long datumEinde = totDatumToTotEnMetDatum(readApplicableNullableLong(attributen, "DATUM_EINDE_CGM", resultSet));

        return RechtsvormWg.builder()
                .codeRechtsvorm(codeRechtsvorm)
                .datumAanvangRechtsvorm(datumAanvang)
                .datumEindeRechtsvorm(datumEinde)
                .build();
    }
}
