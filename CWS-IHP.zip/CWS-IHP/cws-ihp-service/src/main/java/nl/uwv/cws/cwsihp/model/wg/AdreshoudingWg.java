package nl.uwv.cws.cwsihp.model.wg;

import lombok.Builder;
import lombok.Getter;

import java.util.List;


@Getter
@Builder
public class AdreshoudingWg {
    private List<AdresNederlandWg> adresNederlandWgList;
    private List<AdresBuitenlandWg> adresBuitenlandWgList;
    private List<AdresBuitenlandOngestructureerdWg> adresBuitenlandOngestructureerdWgList;
}
