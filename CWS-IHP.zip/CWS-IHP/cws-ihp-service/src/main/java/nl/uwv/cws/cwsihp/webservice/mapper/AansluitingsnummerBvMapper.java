package nl.uwv.cws.cwsihp.webservice.mapper;

import nl.uwv.cws.common.VisibleForTesting;
import nl.uwv.cws.cwsihp.model.wg.AansluitingsnummerBvWg;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0007.CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.AansluitingsnrBv;
import org.springframework.stereotype.Component;

import static nl.uwv.cws.common.util.MapperUtil.collectNonEmptyObject;
import static nl.uwv.cws.common.util.NullValueUtil.extractStringValueOrNull;
import static nl.uwv.cws.cwsihp.model.CwsIhpConstants.*;

@Component
public class AansluitingsnummerBvMapper extends BaseMapper {

    @VisibleForTesting
    protected AansluitingsnrBv mapToJaxbAansluitingsnummerBv(AansluitingsnummerBvWg aansluitingsnummerBvWg) {
        AansluitingsnrBv aansluitingsnrBv = new AansluitingsnrBv();

        final Long codeSectorOsv = aansluitingsnummerBvWg.getCodeSectorOsv();
        final Long risicoPremiegroep = aansluitingsnummerBvWg.getRisicoPremiegroep();
        final Long aansluitingsnummerBv = aansluitingsnummerBvWg.getAansluitingsnummerBv();
        final Long datumAanvangAansluitingsnummerBv = aansluitingsnummerBvWg.getDatumAanvangAansluitingsnummerBv();

        ruleExecutor.setTransformedValue(aansluitingsnrBv, XSD_CDSECTOROSV, extractStringValueOrNull(codeSectorOsv));
        ruleExecutor.setTransformedValue(aansluitingsnrBv, XSD_CDRISICOPREMIEGROEP, extractStringValueOrNull(risicoPremiegroep));
        ruleExecutor.setTransformedValue(aansluitingsnrBv, XSD_AANSLUITINGSNRBV, extractStringValueOrNull(aansluitingsnummerBv));
        ruleExecutor.setTransformedValue(aansluitingsnrBv, XSD_DATBAANSLUITINGSNRBV, extractStringValueOrNull(datumAanvangAansluitingsnummerBv));

        return collectNonEmptyObject(aansluitingsnrBv);
    }
}
