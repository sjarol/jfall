package nl.uwv.cws.cwsihp.model.wg;

import lombok.Getter;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@SuperBuilder
@Getter
@ToString
public abstract class AdresWg {
    private String codeAdresrol;
}
