package nl.uwv.cws.cwsihp.dao.mapper;

import nl.uwv.cws.common.dao.mapper.CwsRowMapper;
import nl.uwv.cws.cwsihp.model.hr.ActiviteitHandelsregisterHr;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Component
public class ActiviteitHandelsregisterHrRowMapper extends CwsRowMapper<ActiviteitHandelsregisterHr> {

    @Override
    public ActiviteitHandelsregisterHr mapRow(final ResultSet resultSet, final List<String> attributen) throws SQLException {

        final Long activiteitId = resultSet.getLong("ACTIVITEIT_ID");
        final String omschrijving = readApplicableString(attributen, "OMSCHRIJVING", resultSet);

        return ActiviteitHandelsregisterHr.builder()
                .activiteitId(activiteitId)
                .omschrijving(omschrijving)
                .build();
    }
}
