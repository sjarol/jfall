package nl.uwv.cws.cwsihp.dao.ihp;

import nl.uwv.cws.cwsihp.model.configuratie.CwsIhpConfiguratie;
import nl.uwv.cws.cwsihp.dao.mapper.ActiviteitHandelsregisterHrRowMapper;
import nl.uwv.cws.cwsihp.model.hr.ActiviteitHandelsregisterHr;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

import static nl.uwv.cws.common.util.DaoUtil.findOneOrNone;

@Repository
public class ActiviteitHandelsregisterHrDao extends BaseDao {

    @Autowired
    private ActiviteitHandelsregisterHrRowMapper activiteitHandelsregisterHrRowMapper;

    public ActiviteitHandelsregisterHr findActiviteitHandelsregisterRechtspersoon(final Long activiteitId, final LocalDateTime beschouwingsmoment, final CwsIhpConfiguratie cwsIhpConfiguratie) {

        List<String> attributen = cwsIhpConfiguratie.getGroepenGegevens().getRequiredColumnsActiviteitHandelsregisterRechtspersoon();
        return findActiviteitHandelsregister(activiteitId, beschouwingsmoment, attributen);
    }

    public ActiviteitHandelsregisterHr findActiviteitHandelsregisterVestigingHandelsregister(final Long activiteitId, final LocalDateTime beschouwingsmoment, final CwsIhpConfiguratie cwsIhpConfiguratie) {

        List<String> attributen = cwsIhpConfiguratie.getGroepenGegevens().getRequiredColumnsActiviteitHandelsregisterVestigingHandelsregister();
        return findActiviteitHandelsregister(activiteitId, beschouwingsmoment, attributen);
    }

    private ActiviteitHandelsregisterHr findActiviteitHandelsregister(final Long activiteitId, final LocalDateTime beschouwingsmoment, final List<String> attributen) {
        final String sql = "SELECT activiteit_id, " +
                "omschrijving " +
                "FROM uh_activiteiten " +
                "WHERE activiteit_id = :activiteitId " +
                "AND his_ts_in  <= :beschouwingsmoment " +
                "AND his_ts_end > :beschouwingsmoment";

        final Timestamp beschouwingsmomentTimestamp = Timestamp.valueOf(beschouwingsmoment);
        SqlParameterSource namedParameters = new MapSqlParameterSource()
                .addValue("activiteitId", activiteitId)
                .addValue("beschouwingsmoment", beschouwingsmomentTimestamp);


        List<ActiviteitHandelsregisterHr> results = jdbcTemplate.query(sql, namedParameters, (resultSet, i) -> activiteitHandelsregisterHrRowMapper.mapRow(resultSet, attributen));
        String errorMessage = "Meerdere rijen gevonden";
        return findOneOrNone(errorMessage, results);
    }
}

