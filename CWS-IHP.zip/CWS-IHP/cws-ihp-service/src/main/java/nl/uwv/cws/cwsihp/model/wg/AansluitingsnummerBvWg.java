package nl.uwv.cws.cwsihp.model.wg;

import lombok.Builder;
import lombok.Getter;

@Builder
@Getter
public class AansluitingsnummerBvWg {
    private Long codeSectorOsv;
    private Long risicoPremiegroep;
    private Long aansluitingsnummerBv;
    private Long datumAanvangAansluitingsnummerBv;
}
