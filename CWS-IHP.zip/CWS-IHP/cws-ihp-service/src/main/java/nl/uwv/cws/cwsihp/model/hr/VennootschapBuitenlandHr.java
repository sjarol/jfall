package nl.uwv.cws.cwsihp.model.hr;

import lombok.Builder;
import lombok.Getter;

import java.sql.Date;

@Builder
@Getter
public class VennootschapBuitenlandHr {

    private Date datumAanvangVennootschapBuitenland;
    private Integer codeFictieveDatumAanvang;
    private Date datumEindeVennootschapBuitenland;
    private Integer codeFictieveDatumEinde;

}
