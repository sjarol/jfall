package nl.uwv.cws.cwsihp.webservice.mapper;

import nl.uwv.cws.cwsihp.model.ihp.HuwelijkGeregistreerdPartnerIhp;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0007.CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NatuurlijkPersoon.HuwelijkGeregistreerdPartner;
import org.springframework.stereotype.Component;

import java.util.Optional;

import static nl.uwv.cws.common.util.MapperUtil.collectNonEmptyObject;
import static nl.uwv.cws.common.util.NullValueUtil.extractStringValueOrNull;
import static nl.uwv.cws.cwsihp.model.CwsIhpConstants.XSD_SIGNIFICANTDEELACHTERNAAMECHTG;
import static nl.uwv.cws.cwsihp.model.CwsIhpConstants.XSD_VOORVOEGSELECHTGENOOT;

@Component
public class HuwelijkGeregistreerdPartnerMapper extends BaseMapper {

    protected Optional<HuwelijkGeregistreerdPartner> mapToJaxbHuwelijkGeregistreerdPartner(HuwelijkGeregistreerdPartnerIhp huwelijkGeregistreerdPartnerIhp) {
        return Optional.ofNullable(huwelijkGeregistreerdPartnerIhp).map(notNullableHuwelijkGeregistreerdPartner -> {
            HuwelijkGeregistreerdPartner huwelijkGeregistreerdPartner = new HuwelijkGeregistreerdPartner();

            final String voorvoegselPartner = notNullableHuwelijkGeregistreerdPartner.getVoorvoegselGeslachtsnaamPartner();
            final String geslachtsnaamPartner = notNullableHuwelijkGeregistreerdPartner.getGeslachtsnaamPartner();

            ruleExecutor.setTransformedValue(huwelijkGeregistreerdPartner, XSD_VOORVOEGSELECHTGENOOT, extractStringValueOrNull(voorvoegselPartner));
            ruleExecutor.setTransformedValue(huwelijkGeregistreerdPartner, XSD_SIGNIFICANTDEELACHTERNAAMECHTG, extractStringValueOrNull(geslachtsnaamPartner));

            return collectNonEmptyObject(huwelijkGeregistreerdPartner);
        });
    }
}
