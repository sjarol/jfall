package nl.uwv.cws.cwsihp.exception;

import nl.uwv.schemas.uwvml.services.cwsinhoudingsplichtige_v0007.Fault;

public class CwsIhpResponseXsdInvalidException extends Fault {
    public CwsIhpResponseXsdInvalidException(String message) {
        super(message);
    }
}
