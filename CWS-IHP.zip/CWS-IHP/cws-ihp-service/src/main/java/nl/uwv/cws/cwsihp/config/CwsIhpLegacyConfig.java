package nl.uwv.cws.cwsihp.config;

import nl.uwv.appconf.dao.NonCoreFuncDao;
import nl.uwv.appconf.spring.DbPropertyLoader;
import nl.uwv.commons.ws.UwvPerformanceLogger;
import nl.uwv.commons.ws.UwvQueryLogger;
import nl.uwv.cws.common.config.BaseLegacyConfig;
import nl.uwv.cws.common.model.querylog.QueryLogEntry;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import javax.sql.DataSource;
import java.util.ArrayList;
import java.util.List;

import static nl.uwv.cws.common.model.CwsCommonConstants.*;

@Configuration
@Profile("prod")
public class CwsIhpLegacyConfig extends BaseLegacyConfig {

    @Autowired
    private NonCoreFuncDao nonCoreFuncDao;

    @Bean
    public UwvQueryLogger queryLogger(@Qualifier("cwsIhpDataSource") DataSource dataSource) {
        final List<QueryLogEntry> queryLogEntryList = createQueryLogEntries();

        return setupQueryLogger(dataSource, queryLogEntryList);
    }

    @Bean
    public UwvPerformanceLogger performanceLogger(@Qualifier("cwsIhpDataSource") DataSource dataSource, DbPropertyLoader dbPropertyLoader) {
        return setupPerformanceLogger(dataSource, dbPropertyLoader);
    }

    @Bean
    public DbPropertyLoader dbPropertyLoader(NonCoreFuncDao nonCoreFuncDao) {
        return setupPropertyLoader(nonCoreFuncDao);
    }

    private List<QueryLogEntry> createQueryLogEntries() {
        List<QueryLogEntry> listToReturn = new ArrayList<>();
        QueryLogEntry queryLogEntryKvkNr = QueryLogEntry.builder()
                .referenceKey(QUERYLOG_REQUEST_KVKNUMMER)
                .logTableName(LOG_TABLE_NAME)
                .logTableColumn("KVK_NUMMER")
                .columnValuePattern("^[0-9]+$")
                .build();
        listToReturn.add(queryLogEntryKvkNr);
        QueryLogEntry queryLogEntryNrIhp = QueryLogEntry.builder()
                .referenceKey(QUERYLOG_REQUEST_NR_IHP)
                .logTableName(LOG_TABLE_NAME)
                .logTableColumn("NR_IHP")
                .columnValuePattern("^[0-9]+$")
                .build();
        listToReturn.add(queryLogEntryNrIhp);
        QueryLogEntry queryLogEntryLhnr = QueryLogEntry.builder()
                .referenceKey(QUERYLOG_REQUEST_LHNR)
                .logTableName(LOG_TABLE_NAME)
                .logTableColumn("LHNR")
                .columnValuePattern(PATTERN_LOONHEFFINGENNUMMER)
                .build();
        listToReturn.add(queryLogEntryLhnr);

        return listToReturn;
    }
}
