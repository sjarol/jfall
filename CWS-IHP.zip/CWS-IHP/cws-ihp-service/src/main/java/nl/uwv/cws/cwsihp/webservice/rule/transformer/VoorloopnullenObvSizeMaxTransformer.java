package nl.uwv.cws.cwsihp.webservice.rule.transformer;

import nl.uwv.cws.common.model.rule.AttributeRuleProperties;
import nl.uwv.cws.common.webservice.rule.transformer.RuleValueTransformer;
import nl.uwv.cws.cwsihp.model.rule.CwsIhpAttributeRule;
import org.springframework.stereotype.Component;

import static nl.uwv.cws.common.util.ConverterUtil.codeToCodeMetVoorloopnul;
import static nl.uwv.cws.cwsihp.model.rule.CwsIhpAttributeRule.VOORLOOPNULLEN_OBV_SIZE_MAX;

@Component
public class VoorloopnullenObvSizeMaxTransformer implements RuleValueTransformer<String, String> {
    @Override
    public CwsIhpAttributeRule getTransformRule() {
        return VOORLOOPNULLEN_OBV_SIZE_MAX;
    }

    @Override
    public String transform(String originalValue, AttributeRuleProperties attributeRuleProperties) {
        return codeToCodeMetVoorloopnul(originalValue, attributeRuleProperties.getSizeMax());
    }
}
