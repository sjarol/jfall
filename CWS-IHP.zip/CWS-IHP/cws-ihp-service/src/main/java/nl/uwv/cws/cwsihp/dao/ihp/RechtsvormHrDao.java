package nl.uwv.cws.cwsihp.dao.ihp;

import nl.uwv.cws.cwsihp.dao.mapper.RechtsvormHrRowMapper;
import nl.uwv.cws.cwsihp.model.configuratie.CwsIhpConfiguratie;
import nl.uwv.cws.cwsihp.model.hr.RechtsvormHr;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public class RechtsvormHrDao extends BaseDao {

    @Autowired
    private RechtsvormHrRowMapper rechtsvormHrRowMapper;

    public List<RechtsvormHr> findRechtsvorm(final Long persoonId, final LocalDateTime beschouwingsmoment, final CwsIhpConfiguratie cwsIhpConfiguratie) {
        final String sql = "SELECT " +
                "code_rechtsvorm_cgm, " +
                "datum_aanvang_cgm, " +
                "cd_datum_aanvang_cgm, " +
                "datum_einde_cgm,  " +
                "cd_datum_einde_cgm " +
                "FROM uh_persoon " +
                "WHERE persoon_id = :persoonId " +
                "AND his_ts_in  <= :beschouwingsmoment " +
                "AND his_ts_end > :beschouwingsmoment";

        Timestamp beschouwingsmomentTimestamp = Timestamp.valueOf(beschouwingsmoment);

        SqlParameterSource namedParameters = new MapSqlParameterSource()
                .addValue("persoonId", persoonId.toString())
                .addValue("beschouwingsmoment", beschouwingsmomentTimestamp);
        List<String> attributen = cwsIhpConfiguratie.getGroepenGegevens().getRequiredColumnsRechtsvorm();
        return jdbcTemplate.query(sql, namedParameters, (resultSet, i) -> rechtsvormHrRowMapper.mapRow(resultSet, attributen));
    }
}
