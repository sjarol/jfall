package nl.uwv.cws.cwsihp.webservice.mapper;

import nl.uwv.cws.common.VisibleForTesting;
import nl.uwv.cws.cwsihp.model.wg.PremiepercentageIndividueelWg;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0007.CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.PremiepercIndividueel;
import org.springframework.stereotype.Component;

import static nl.uwv.cws.common.util.MapperUtil.collectNonEmptyObject;
import static nl.uwv.cws.common.util.NullValueUtil.extractBigDecimalValueOrNull;
import static nl.uwv.cws.common.util.NullValueUtil.extractStringValueOrNull;
import static nl.uwv.cws.cwsihp.model.CwsIhpConstants.*;

@Component
public class PremiepercentageIndividueelMapper extends BaseMapper {

    @VisibleForTesting
    protected PremiepercIndividueel mapToJaxbPremiepercentageIndividueel(PremiepercentageIndividueelWg premiepercentageIndividueelWg) {
        PremiepercIndividueel premiepercentageIndividueel = new PremiepercIndividueel();

        final String codeSzProduct = premiepercentageIndividueelWg.getCodeSzProduct();
        final Double percentage = premiepercentageIndividueelWg.getPercentage();
        final Long datumAanvangPremiepercentageIndividueel = premiepercentageIndividueelWg.getDatumAanvangPremiepercentageIndividueel();
        final Long datumEindePremiepercentageIndividueel = premiepercentageIndividueelWg.getDatumEindePremiepercentageIndividueel();

        ruleExecutor.setTransformedValue(premiepercentageIndividueel, XSD_CDSZPRODUCT, codeSzProduct);
        ruleExecutor.setTransformedValue(premiepercentageIndividueel, XSD_PERC, extractBigDecimalValueOrNull(percentage));
        ruleExecutor.setTransformedValue(premiepercentageIndividueel, XSD_DATBPRPERCINDIVIDUEEL, extractStringValueOrNull(datumAanvangPremiepercentageIndividueel));
        ruleExecutor.setTransformedValue(premiepercentageIndividueel, XSD_DATEPRPERCINDIVIDUEEL, extractStringValueOrNull(datumEindePremiepercentageIndividueel));

        return collectNonEmptyObject(premiepercentageIndividueel);
    }
}
