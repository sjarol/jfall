package nl.uwv.cws.cwsihp.dao.mapper;

import nl.uwv.cws.common.dao.mapper.CwsRowMapper;
import nl.uwv.cws.cwsihp.model.wg.VoortzettingsrelatieVoorgangerWg;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Component
public class VoortzettingsrelatieVoorgangerWgRowMapper extends CwsRowMapper<VoortzettingsrelatieVoorgangerWg> {

    @Override
    public VoortzettingsrelatieVoorgangerWg mapRow(final ResultSet resultSet, final List<String> attributen) throws SQLException {
        final Long datumAanvangVoortzettingsrelatieVoorganger = readApplicableNullableLong(attributen, "DAT_VOORTZET", resultSet);
        final Double percentageLoonsomOvergegaan = readApplicableNullableDouble(attributen, "PERC_VOORTZET", resultSet);
        final String lhnrVoorganger = readApplicableString(attributen, "LHNR_VOOR", resultSet);

        return VoortzettingsrelatieVoorgangerWg.builder()
                .datumAanvangVoortzettingsrelatieVoorganger(datumAanvangVoortzettingsrelatieVoorganger)
                .percentageLoonsomOvergegaan(percentageLoonsomOvergegaan)
                .lhnrVoorganger(lhnrVoorganger)
                .build();
    }
}
