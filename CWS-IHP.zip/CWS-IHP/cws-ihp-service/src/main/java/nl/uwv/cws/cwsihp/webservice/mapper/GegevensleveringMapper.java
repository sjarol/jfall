package nl.uwv.cws.cwsihp.webservice.mapper;

import nl.uwv.cws.common.VisibleForTesting;
import nl.uwv.cws.cwsihp.model.selection.SelectionParameters;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0007.CwsInhoudingsplichtigeResponse.Gegevenslevering;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import static nl.uwv.cws.cwsihp.model.CwsIhpConstants.*;

@Component
public class GegevensleveringMapper extends BaseMapper {

    @VisibleForTesting
    Gegevenslevering mapToJaxbGegevenslevering(final SelectionParameters selectionParameters) {
        Gegevenslevering gegevenslevering = new Gegevenslevering();
        String beschouwingsmoment = selectionParameters.getBeschouwingsmoment().format(BESCHOUWING_TIMESTAMP_FORMATTER);
        final String kvknummer = selectionParameters.getKvknummer();
        final String bsn = selectionParameters.getBsn();
        final String rsin = selectionParameters.getRsin();
        final String nrInhoudingsplichtige = StringUtils.hasText(bsn) ? bsn : rsin;
        final String loonheffingennummer = selectionParameters.getLoonheffingennummer();

        ruleExecutor.setTransformedValue(gegevenslevering, XSD_DATTIJDBESCHOUWINGGEBVSELECTIE, beschouwingsmoment);
        ruleExecutor.setTransformedValue(gegevenslevering, XSD_KVKNR, kvknummer);
        if (!StringUtils.hasText(kvknummer) && !StringUtils.hasText(loonheffingennummer)) {
            ruleExecutor.setTransformedValue(gegevenslevering, XSD_NRINHOUDINGSPLICHTIGE, nrInhoudingsplichtige);
        }
        ruleExecutor.setTransformedValue(gegevenslevering, XSD_LOONHEFFINGENNR, loonheffingennummer);

        return gegevenslevering;
    }
}
