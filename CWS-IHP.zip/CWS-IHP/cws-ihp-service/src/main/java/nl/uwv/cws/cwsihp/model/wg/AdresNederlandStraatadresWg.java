package nl.uwv.cws.cwsihp.model.wg;

import lombok.Builder;
import lombok.Getter;

@Builder
@Getter
public class AdresNederlandStraatadresWg {
    private String postcode;
    private String woonplaatsnaam;
    private String gemeentenaam;
    private String straatnaam;
    private Integer huisnummer;
    private String huisnummerToevoeging;
    private String locatieomschrijving;
}
