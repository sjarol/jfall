package nl.uwv.cws.cwsihp.model.wg;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Builder
@Getter
@Setter
public class AdministratieveEenheidWg {

    private Long aehId;
    private String loonheffingennummer;
    private String naamAdministratieveEenheid;
    private Long datumAanvangAdministratieveEenheid;
    private Long datumEindeAdministratieveEenheid;

    protected List<SectorRisicogroepWg> sectorRisicogroepList;
    protected List<PremiepercentageIndividueelWg> premiepercentageIndividueelList;
    protected List<EigenRisicoDragerWg> eigenRisicoDragerList;
    protected AdreshoudingWg adreshouding;
    protected List<VoortzettingsrelatieOpvolgerWg> voortzettingsrelatieOpvolgerList;
    protected List<VoortzettingsrelatieVoorgangerWg> voortzettingsrelatieVoorgangerList;
    protected List<AangifteFrequentieAdministratieveEenheidWg> aangiftefrequentieAdministratieveEenheidList;
    protected List<AansluitingsnummerBvWg> aansluitingsnummerBvList;
	
}
