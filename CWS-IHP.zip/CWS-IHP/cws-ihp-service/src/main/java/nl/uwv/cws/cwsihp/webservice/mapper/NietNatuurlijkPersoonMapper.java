package nl.uwv.cws.cwsihp.webservice.mapper;

import nl.uwv.cws.cwsihp.model.hr.NietNatuurlijkPersoonHr;
import nl.uwv.cws.cwsihp.model.ihp.NietNatuurlijkPersoonIhp;
import nl.uwv.cws.cwsihp.model.wg.NietNatuurlijkPersoonWg;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0007.CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NietNatuurlijkPersoon;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.sql.Date;
import java.util.Optional;

import static nl.uwv.cws.common.util.MapperUtil.collectNonEmptyObject;
import static nl.uwv.cws.common.util.NullValueUtil.extractStringFromDateValueOrNull;
import static nl.uwv.cws.common.util.NullValueUtil.extractStringValueOrNull;
import static nl.uwv.cws.cwsihp.model.CwsIhpConstants.*;

@Component
public class NietNatuurlijkPersoonMapper extends BaseMapper {

    @Autowired
    private RechtspersoonMapper rechtspersoonMapper;

    @Autowired
    private VennootschapBuitenlandMapper vennootschapBuitenlandMapper;

    public Optional<NietNatuurlijkPersoon> mapToJaxbNietNatuurlijkPersoon(final NietNatuurlijkPersoonIhp nietNatuurlijkPersoonIhp) {
        return Optional.ofNullable(nietNatuurlijkPersoonIhp).map(notNullableNietNatuurlijkPersoon -> {

            NietNatuurlijkPersoonHr nietNatuurlijkPersoonHr = nietNatuurlijkPersoonIhp.getNietNatuurlijkPersoonHr();
            NietNatuurlijkPersoonWg nietNatuurlijkPersoonWg = nietNatuurlijkPersoonIhp.getNietNatuurlijkPersoonWg();
            NietNatuurlijkPersoon nietNatuurlijkPersoon = new NietNatuurlijkPersoon();
            if (nietNatuurlijkPersoonHr != null) {
                mapToJaxbNietNatuurlijkPersoonHr(nietNatuurlijkPersoonHr, nietNatuurlijkPersoon);

                Optional<NietNatuurlijkPersoon.Rechtspersoon> rechtspersoon = rechtspersoonMapper.mapToJaxbRechtspersoon(nietNatuurlijkPersoonHr.getRechtspersoonHr());
                rechtspersoon.ifPresent(nietNatuurlijkPersoon::setRechtspersoon);

                Optional<NietNatuurlijkPersoon.VennootschapBuitenland> vennootschapBuitenland = vennootschapBuitenlandMapper.mapToJaxbVennootschapBuitenland(nietNatuurlijkPersoonHr.getVennootschapBuitenlandHr());
                vennootschapBuitenland.ifPresent(nietNatuurlijkPersoon::setVennootschapBuitenland);
            } else {
                mapToJaxbNietNatuurlijkPersoonWg(nietNatuurlijkPersoonWg, nietNatuurlijkPersoon);
            }

            return collectNonEmptyObject(nietNatuurlijkPersoon);
        });
    }

    private void mapToJaxbNietNatuurlijkPersoonHr(NietNatuurlijkPersoonHr nietNatuurlijkPersoonHr, NietNatuurlijkPersoon nietNatuurlijkPersoon) {
        final Integer rsin = nietNatuurlijkPersoonHr.getRsin();
        final Date datumAanvangNietNatuurlijkPersoon = nietNatuurlijkPersoonHr.getDatumAanvangNietNatuurlijkPersoon();
        Integer codeFictieveDatumAanvang = null;
        if (datumAanvangNietNatuurlijkPersoon != null) {
            codeFictieveDatumAanvang = nietNatuurlijkPersoonHr.getCodeFictieveDatumAanvang();
        }
        final Date datumEindeNietNatuurlijkPersoon = nietNatuurlijkPersoonHr.getDatumEindeNietNatuurlijkPersoon();
        Integer codeFictieveDatumEinde = null;
        if (datumEindeNietNatuurlijkPersoon != null) {
            codeFictieveDatumEinde = nietNatuurlijkPersoonHr.getCodeFictieveDatumEinde();
        }
        final String volledigeNaamNietNatuurlijkPersoon = nietNatuurlijkPersoonHr.getVolledigeNaamNietNatuurlijkPersoon();

        ruleExecutor.setTransformedValue(nietNatuurlijkPersoon, XSD_RSIN, extractStringValueOrNull(rsin));
        ruleExecutor.setTransformedValue(nietNatuurlijkPersoon, XSD_DATBNIETNATUURLIJKPERSOON, extractStringFromDateValueOrNull(datumAanvangNietNatuurlijkPersoon));
        ruleExecutor.setTransformedValue(nietNatuurlijkPersoon, XSD_CDFICTIEVEDATB, extractStringValueOrNull(codeFictieveDatumAanvang));
        ruleExecutor.setTransformedValue(nietNatuurlijkPersoon, XSD_DATENIETNATUURLIJKPERSOON, extractStringFromDateValueOrNull(datumEindeNietNatuurlijkPersoon));
        ruleExecutor.setTransformedValue(nietNatuurlijkPersoon, XSD_CDFICTIEVEDATE, extractStringValueOrNull(codeFictieveDatumEinde));
        ruleExecutor.setTransformedValue(nietNatuurlijkPersoon, XSD_VOLLEDIGENMNIETNATUURLIJKPERSOON, volledigeNaamNietNatuurlijkPersoon);
    }

    private void mapToJaxbNietNatuurlijkPersoonWg(NietNatuurlijkPersoonWg nietNatuurlijkPersoonWg, NietNatuurlijkPersoon nietNatuurlijkPersoon) {
        final Integer rsin = nietNatuurlijkPersoonWg.getRsin();
        final String naam = nietNatuurlijkPersoonWg.getNaamNietNatuurlijkPersoon();
        final Long datumOprichting = nietNatuurlijkPersoonWg.getDatumOprichtingNietNatuurlijkPersoon();
        final Long datumOntbinding = nietNatuurlijkPersoonWg.getDatumOntbindingNietNatuurlijkPersoon();

        ruleExecutor.setTransformedValue(nietNatuurlijkPersoon, XSD_RSIN, extractStringValueOrNull(rsin));
        ruleExecutor.setTransformedValue(nietNatuurlijkPersoon, XSD_DATOPRICHTINGRECHTSPSAMENWERKING, extractStringValueOrNull(datumOprichting));
        ruleExecutor.setTransformedValue(nietNatuurlijkPersoon, XSD_DATONTBINDINGRECHTSPSAMENWERKING, extractStringValueOrNull(datumOntbinding));
        ruleExecutor.setTransformedValue(nietNatuurlijkPersoon, XSD_VOLLEDIGENMNIETNATUURLIJKPERSOON, naam);
    }
}
