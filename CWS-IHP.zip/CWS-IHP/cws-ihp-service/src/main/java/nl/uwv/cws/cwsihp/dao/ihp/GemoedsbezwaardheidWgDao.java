package nl.uwv.cws.cwsihp.dao.ihp;

import nl.uwv.cws.cwsihp.dao.mapper.GemoedsbezwaardheidWgRowMapper;
import nl.uwv.cws.cwsihp.model.configuratie.CwsIhpConfiguratie;
import nl.uwv.cws.cwsihp.model.wg.GemoedsbezwaardheidWg;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public class GemoedsbezwaardheidWgDao extends BaseDao {

    @Autowired
    private GemoedsbezwaardheidWgRowMapper gemoedsbezwaardheidWgRowMapper;

    // Voor selecties van IHP alleen in WGA
    public List<GemoedsbezwaardheidWg> findGemoedsbezwaardheidByPersoonId(final Long persoonId, final LocalDateTime beschouwingsmoment, final CwsIhpConfiguratie cwsIhpConfiguratie) {
        Timestamp beschouwingsmomentTimestamp = Timestamp.valueOf(beschouwingsmoment);
        final String sql =
                " SELECT sz_product_code " +
                        "      , dataanv " +
                        "      , dateind " +
                        " FROM wga_gemoedsbezwaardheid " +
                        " WHERE per_id = :persoonId " +
                        " AND his_ts_in <= :beschouwingsmoment " +
                        " AND his_ts_end > :beschouwingsmoment";

        SqlParameterSource namedParameters = new MapSqlParameterSource()
                .addValue("persoonId", persoonId.toString())
                .addValue("beschouwingsmoment", beschouwingsmomentTimestamp);
        List<String> attributen = cwsIhpConfiguratie.getGroepenGegevens().getRequiredColumnsGemoedsbezwaardheid();

        return jdbcTemplate.query(sql, namedParameters, (resultSet, i) -> gemoedsbezwaardheidWgRowMapper.mapRow(resultSet, attributen));
    }

    // Voor selecties van IHP in UHR en WGA
    public List<GemoedsbezwaardheidWg> findGemoedsbezwaardheidByNrihp(final String nrihp, final LocalDateTime beschouwingsmoment, final CwsIhpConfiguratie cwsIhpConfiguratie) {
        Timestamp beschouwingsmomentTimestamp = Timestamp.valueOf(beschouwingsmoment);
        final String sql =
                " SELECT sz_product_code " +
                        "      , dataanv " +
                        "      , dateind " +
                        " FROM wga_gemoedsbezwaardheid gem" +
                        " INNER JOIN wga_persoon per " +
                        " ON gem.per_id = per.per_id " +
                        " WHERE (per.finr = :nrihp OR per.sofinr = :nrihp)" +
                        " AND his_ts_in <= :beschouwingsmoment " +
                        " AND his_ts_end > :beschouwingsmoment";

        SqlParameterSource namedParameters = new MapSqlParameterSource()
                .addValue("nrihp", nrihp)
                .addValue("beschouwingsmoment", beschouwingsmomentTimestamp);
        List<String> attributen = cwsIhpConfiguratie.getGroepenGegevens().getRequiredColumnsGemoedsbezwaardheid();

        return jdbcTemplate.query(sql, namedParameters, (resultSet, i) -> gemoedsbezwaardheidWgRowMapper.mapRow(resultSet, attributen));
    }
}
