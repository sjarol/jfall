package nl.uwv.cws.cwsihp.config;

import nl.uwv.cws.common.model.CwsAuditInformation;
import nl.uwv.cws.common.model.rule.XsdInvalidDataCollector;
import nl.uwv.cws.common.webservice.interceptor.*;
import nl.uwv.cws.common.webservice.rule.CwsRuleExecutor;
import nl.uwv.cws.common.webservice.rule.CwsRulesHolder;
import nl.uwv.cws.cwsihp.model.rule.CwsIhpAttributeRule;
import nl.uwv.cws.cwsihp.webservice.CwsInhoudingsplichtigeWebService;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0007.CwsInhoudingsplichtigeResponse;
import org.apache.cxf.Bus;
import org.apache.cxf.jaxws.EndpointImpl;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.YamlPropertiesFactoryBean;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.*;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jndi.JndiObjectFactoryBean;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.request.RequestContextListener;

import javax.naming.NamingException;
import javax.sql.DataSource;
import javax.xml.namespace.QName;
import javax.xml.ws.Endpoint;

import static org.apache.cxf.annotations.SchemaValidation.SchemaValidationType.IN;
import static org.apache.cxf.message.Message.SCHEMA_VALIDATION_ENABLED;
import static org.apache.cxf.message.Message.SCHEMA_VALIDATION_TYPE;

@Configuration
@EnableScheduling
@EnableCaching
public class CwsIhpConfig {
    private static final String JAXB_ROOT_RESPONSE_CANONICAL_NAME = CwsInhoudingsplichtigeResponse.class.getCanonicalName();
    private static final String BINDING_URI = "http://schemas.uwv.nl/UwvML/Services/CwsInhoudingsplichtige-v0007";
    private static final String WSDL_LOCATION = "/soap/UwvML-CwsInhoudingsplichtige-v0007-b01.wsdl";
    private static final String SOAP_ADDRESS = "/UwvML_CwsInhoudingsplichtige";
    private static final String PUBLIC_RELATIVE_CONTEXT = "/services/cwsihp";

    @Value("${cws.weblogic.jndi}")
    private String cwsWeblogicJndi;

    @Bean
    public Endpoint cwsEndpoint(Bus bus, CwsInhoudingsplichtigeWebService cwsInhoudingsplichtigeWebService,
                                PerformanceInStartInterceptor performanceInStartInterceptor, PerformanceInEndInterceptor performanceInEndInterceptor,
                                PerformanceOutStartInterceptor performanceOutStartInterceptor, PerformanceOutEndInterceptor performanceOutEndInterceptor,
                                CwsOutFaultInterceptor cwsOutFaultInterceptor) {
        EndpointImpl endpoint = new EndpointImpl(bus, cwsInhoudingsplichtigeWebService);
        endpoint.setServiceName(new QName(BINDING_URI, "CwsInhoudingsplichtigeService"));
        endpoint.setWsdlLocation(WSDL_LOCATION);
        endpoint.getProperties().put(SCHEMA_VALIDATION_ENABLED, true);
        endpoint.getProperties().put(SCHEMA_VALIDATION_TYPE, IN);
        endpoint.setPublishedEndpointUrl(PUBLIC_RELATIVE_CONTEXT);
        endpoint.publish(SOAP_ADDRESS);

        endpoint.getInInterceptors().add(performanceInStartInterceptor);
        endpoint.getInInterceptors().add(performanceInEndInterceptor);

        endpoint.getOutInterceptors().add(performanceOutStartInterceptor);
        endpoint.getOutInterceptors().add(performanceOutEndInterceptor);

        endpoint.getOutFaultInterceptors().add(cwsOutFaultInterceptor);
        return endpoint;
    }

    @Bean("ppls_cws")
    public NamedParameterJdbcTemplate namedJdbcCwsIhp(@Qualifier("cwsIhpDataSource")DataSource dataSource) {
        return new NamedParameterJdbcTemplate(dataSource);
    }

    @Bean(name = "cwsIhpDataSource", destroyMethod = "")
    @Profile("prod")
    @Primary
    public DataSource cwsIhpDataSource() throws NamingException {
        JndiObjectFactoryBean jndiObjectFactoryBean = new JndiObjectFactoryBean();
        jndiObjectFactoryBean.setJndiName(cwsWeblogicJndi);
        jndiObjectFactoryBean.setResourceRef(true);
        jndiObjectFactoryBean.setProxyInterface(DataSource.class);
        jndiObjectFactoryBean.setLookupOnStartup(false);
        jndiObjectFactoryBean.afterPropertiesSet();
        return (DataSource) jndiObjectFactoryBean.getObject();
    }

    // NOTE: This bean is required to allow for @Scope(SCOPE_REQUEST) to work
    @Bean
    public RequestContextListener requestContextListener() {
        return new RequestContextListener();
    }

    @Bean
    @Scope(value = WebApplicationContext.SCOPE_REQUEST, proxyMode = ScopedProxyMode.TARGET_CLASS)
    public XsdInvalidDataCollector requestScopedXsdInvalidDataCollector() {
        return new XsdInvalidDataCollector();
    }

    @Bean(name = "requestScopedBean")
    @Scope (value = WebApplicationContext.SCOPE_REQUEST, proxyMode = ScopedProxyMode.TARGET_CLASS)
    public CwsAuditInformation requestScopedBean() { return new CwsAuditInformation(); }

    @Bean
    public CwsRulesHolder<CwsIhpAttributeRule> cwsIhpRules() {
        YamlPropertiesFactoryBean yaml = new YamlPropertiesFactoryBean();
        yaml.setResources(new ClassPathResource("/rules/cws-ihp-rules.yml"));
        return new CwsRulesHolder<>(yaml.getObject(), CwsIhpAttributeRule.class);
    }

    @Bean
    @DependsOn({"cwsIhpRules"})
    public CwsRuleExecutor<CwsIhpAttributeRule> ruleExecutor() {
        return new CwsRuleExecutor<>(JAXB_ROOT_RESPONSE_CANONICAL_NAME);
    }
}
