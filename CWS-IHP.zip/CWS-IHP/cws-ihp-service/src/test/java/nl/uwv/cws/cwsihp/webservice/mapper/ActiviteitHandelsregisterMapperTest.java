package nl.uwv.cws.cwsihp.webservice.mapper;

import nl.uwv.cws.cwsihp.model.hr.ActiviteitHandelsregisterHr;
import nl.uwv.cws.cwsihp.model.hr.SbiklasseHr;
import nl.uwv.cws.common.webservice.rule.CwsRuleExecutor;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
public class ActiviteitHandelsregisterMapperTest {

    @InjectMocks
    private ActiviteitHandelsregisterMapper activiteitHandelsregisterMapper;

    @Mock
    private SbiklasseMapper sbiklasseMapper;

    @Mock
    private CwsRuleExecutor ruleExecutor;

    @Captor
    private ArgumentCaptor<Object> hrFieldCaptor;

    @Captor
    private ArgumentCaptor<String> xsdFieldCaptor;

    @Test
    @DisplayName("Given ActiviteitHandelsregisterHr test mapping fields to JaxB is successful")
    public void testMapToJaxbActiviteitHandelsregister() {
        ActiviteitHandelsregisterHr activiteitHandelsregisterHr = createActiviteitHandelsregisterHr();
        activiteitHandelsregisterMapper.mapToJaxbActiviteitHandelsregisterVestigingHandelsregister(activiteitHandelsregisterHr);

        verify(ruleExecutor, times(1)).setTransformedValue(any(Object.class), xsdFieldCaptor.capture(), hrFieldCaptor.capture());
        List<String> hrFieldValues = Arrays.asList("Omschrijving");
        List<String> xsdFieldValues = Arrays.asList("omsActiviteitHandelsregister");
        assertArrayEquals(hrFieldValues.toArray(), hrFieldCaptor.getAllValues().toArray());
        assertEquals(xsdFieldValues, xsdFieldCaptor.getAllValues());
    }

    @Test
    @DisplayName("Given OndernemingHr with SbiKlasse verify sbiklasseMapper is called")
    public void testMapToJaxbOndernemingVestigingHandelsregisterWithSbiKlasse() {
        ActiviteitHandelsregisterHr activiteitHandelsregisterHr = createActiviteitHandelsregisterHr();
        SbiklasseHr sbiklasseHr = createSbiklasseHr();
        SbiklasseHr sbiklasseHrOther = createSbiklasseHr();
        activiteitHandelsregisterHr.setSbiklasseHrList(Arrays.asList(sbiklasseHr, sbiklasseHrOther));

        activiteitHandelsregisterMapper.mapToJaxbActiviteitHandelsregisterVestigingHandelsregister(activiteitHandelsregisterHr);
        verify(sbiklasseMapper,times(2)).mapToJaxbSbiklasseActiviteitHandelsregister(any(SbiklasseHr.class));
    }

    private ActiviteitHandelsregisterHr createActiviteitHandelsregisterHr() {
        return ActiviteitHandelsregisterHr.builder()
                .omschrijving("Omschrijving")
                .build();
    }

    private SbiklasseHr createSbiklasseHr() {
        return SbiklasseHr.builder().build();
    }
}
