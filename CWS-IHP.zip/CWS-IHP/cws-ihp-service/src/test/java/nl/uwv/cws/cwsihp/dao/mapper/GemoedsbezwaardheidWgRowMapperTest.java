package nl.uwv.cws.cwsihp.dao.mapper;

import nl.uwv.cws.cwsihp.model.wg.AdministratieveEenheidWg;
import nl.uwv.cws.cwsihp.model.wg.GemoedsbezwaardheidWg;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.Mockito.when;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@ExtendWith(MockitoExtension.class)
public class GemoedsbezwaardheidWgRowMapperTest {

    @InjectMocks
    private GemoedsbezwaardheidWgRowMapper gemoedsbezwaardheidWgRowMapper;

    @Mock
    private ResultSet resultSet;

    @Test
    @DisplayName("Should successfully map fields for GemoedsbezwaardheidWg and map DatumEinde to -1")
    public void testMapRowDatumEindeTotEnMet() throws SQLException {
        when(resultSet.getString("SZ_PRODUCT_CODE")).thenReturn("WGA");
        when(resultSet.getObject("DATAANV")).thenReturn(1);
        when(resultSet.getObject("DATEIND")).thenReturn(1);
        when(resultSet.getLong("DATAANV")).thenReturn(20210101L);
        when(resultSet.getLong("DATEIND")).thenReturn(20210601L);

        List<String> attributen = Arrays.asList("SZ_PRODUCT_CODE", "DATAANV", "DATEIND");

        GemoedsbezwaardheidWg gemoedsbezwaardheidWg = gemoedsbezwaardheidWgRowMapper.mapRow(resultSet, attributen);
        assertThat(gemoedsbezwaardheidWg, is(notNullValue()));
        assertThat(gemoedsbezwaardheidWg.getCodeSzProduct(), is(equalTo("WGA")));
        assertThat(gemoedsbezwaardheidWg.getDatumAanvangGemoedsbezwaardheid(), is(equalTo(20210101L)));
        assertThat(gemoedsbezwaardheidWg.getDatumEindeGemoedsbezwaardheid(), is(equalTo(20210531L)));
    }

    @Test
    @DisplayName("Should successfully map fields for GemoedsbezwaardheidWg and map DatumEinde to NULL")
    public void testMapRowDatumEindeNULL() throws SQLException {
        when(resultSet.getObject("DATEIND")).thenReturn(1);
        when(resultSet.getLong("DATEIND")).thenReturn(99991231L);

        List<String> attributen = Arrays.asList("DATEIND");

        GemoedsbezwaardheidWg gemoedsbezwaardheidWg = gemoedsbezwaardheidWgRowMapper.mapRow(resultSet, attributen);
        assertThat(gemoedsbezwaardheidWg, is(notNullValue()));
        assertThat(gemoedsbezwaardheidWg.getDatumEindeGemoedsbezwaardheid(), is(equalTo(null)));
    }
}
