package nl.uwv.cws.cwsihp.dao.mapper;

import nl.uwv.cws.cwsihp.model.wg.FaillissementSurseanceWg;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.Mockito.when;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@ExtendWith(MockitoExtension.class)
public class FaillissementSurseanceWgRowMapperTest {

    @InjectMocks
    private FaillissementSurseanceWgRowMapper faillissementSurseanceWgRowMapper;

    @Mock
    private ResultSet resultSet;

    @BeforeEach
    public void setup() throws SQLException {
        when(resultSet.getObject("DATEIND")).thenReturn(1);
    }

    @Test
    @DisplayName("Should successfully map fields for FaillissementSurseanceWg and map DatumEinde to -1")
    public void testMapRowDatumEindeTotEnMet() throws SQLException {
        when(resultSet.getString("FAIL_SURS_IND")).thenReturn("Code FailSurs");
        when(resultSet.getString("FAIL_SURS_CODE")).thenReturn("Code reden einde FailSurs");
        when(resultSet.getObject("DATAANV")).thenReturn(1);
        when(resultSet.getLong("DATAANV")).thenReturn(20200101L);
        when(resultSet.getLong("DATEIND")).thenReturn(20200601L);

        List<String> attributen = Arrays.asList("FAIL_SURS_IND", "FAIL_SURS_CODE", "DATAANV", "CD_DATUM_AANVANG_CGM", "DATEIND", "CD_DATUM_EINDE_CGM");

        FaillissementSurseanceWg faillissementSurseanceWg = faillissementSurseanceWgRowMapper.mapRow(resultSet, attributen);
        assertThat(faillissementSurseanceWg, is(notNullValue()));
        assertThat(faillissementSurseanceWg.getCodeFaillissementSurseance(), is(equalTo("Code FailSurs")));
        assertThat(faillissementSurseanceWg.getCodeRedenEindeFaillissementSurseance(), is(equalTo("Code reden einde FailSurs")));
        assertThat(faillissementSurseanceWg.getDatumAanvangFaillissementSurseance(), is(equalTo(20200101L)));
        assertThat(faillissementSurseanceWg.getDatumEindeFaillissementSurseance(), is(equalTo(20200531L)));
    }

    @Test
    @DisplayName("Should successfully map fields for FaillissementSurseanceWg and map DatumEinde to NULL")
    public void testMapRowDatumEindeNULL() throws SQLException {
        when(resultSet.getLong("DATEIND")).thenReturn(99991231L);

        List<String> attributen = Arrays.asList("DATEIND");

        FaillissementSurseanceWg faillissementSurseanceWg = faillissementSurseanceWgRowMapper.mapRow(resultSet, attributen);
        assertThat(faillissementSurseanceWg, is(notNullValue()));
        assertThat(faillissementSurseanceWg.getDatumEindeFaillissementSurseance(), is(equalTo(null)));
    }
}
