package nl.uwv.cws.cwsihp.dao.mapper;

import nl.uwv.cws.cwsihp.model.hr.NietNatuurlijkPersoonHr;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.Mockito.when;

@TestInstance(Lifecycle.PER_CLASS)
@ExtendWith(MockitoExtension.class)
public class NietNatuurlijkPersoonHrRowMapperTest {

    @InjectMocks
    private NietNatuurlijkPersoonHrRowMapper nietNatuurlijkPersoonHrRowMapper;

    @Mock
    private ResultSet resultSet;

    @BeforeEach
    public void setup() throws SQLException {
        when(resultSet.getObject("RSIN")).thenReturn(999999990);
        when(resultSet.getObject("CD_DATUM_AANVANG_CGM")).thenReturn(1);
        when(resultSet.getObject("CD_DATUM_EINDE_CGM")).thenReturn(2);
        when(resultSet.getObject("RECHTSPERSOON_ID")).thenReturn(1);
        when(resultSet.getObject("BUITENLANDSEVENNOOTSCHAP_ID")).thenReturn(2);
    }

    @Test
    @DisplayName("Should successfully map fields for NietNatuurlijkPersoonHr")
    public void testMapRow() throws SQLException {
        when(resultSet.getInt("RSIN")).thenReturn(999999990);
        when(resultSet.getDate("DATUM_AANVANG_CGM")).thenReturn(Date.valueOf(LocalDate.of(2020, 1, 1)));
        when(resultSet.getInt("CD_DATUM_AANVANG_CGM")).thenReturn(1);
        when(resultSet.getDate("DATUM_EINDE_CGM")).thenReturn(Date.valueOf(LocalDate.of(2020, 1, 31)));
        when(resultSet.getInt("CD_DATUM_EINDE_CGM")).thenReturn(2);
        when(resultSet.getString("VOLLEDIGENAAM")).thenReturn("VolledigeNaam");
        when(resultSet.getLong("RECHTSPERSOON_ID")).thenReturn(1L);
        when(resultSet.getLong("BUITENLANDSEVENNOOTSCHAP_ID")).thenReturn(2L);

        List<String> attributen = Arrays.asList("RSIN", "DATUM_AANVANG_CGM",
                "CD_DATUM_AANVANG_CGM", "DATUM_EINDE_CGM", "CD_DATUM_EINDE_CGM", "VOLLEDIGENAAM");

        NietNatuurlijkPersoonHr nietNatuurlijkPersoonHr = nietNatuurlijkPersoonHrRowMapper.mapRow(resultSet, attributen);
        assertThat(nietNatuurlijkPersoonHr, is(notNullValue()));
        assertThat(nietNatuurlijkPersoonHr.getRsin(), is(equalTo(999999990)));
        assertThat(nietNatuurlijkPersoonHr.getDatumAanvangNietNatuurlijkPersoon(), is(Date.valueOf(LocalDate.of(2020, 1, 1))));
        assertThat(nietNatuurlijkPersoonHr.getCodeFictieveDatumAanvang(), is(equalTo(1)));
        assertThat(nietNatuurlijkPersoonHr.getDatumEindeNietNatuurlijkPersoon(), is(Date.valueOf(LocalDate.of(2020, 1, 31))));
        assertThat(nietNatuurlijkPersoonHr.getCodeFictieveDatumEinde(), is(equalTo(2)));
        assertThat(nietNatuurlijkPersoonHr.getVolledigeNaamNietNatuurlijkPersoon(), is(equalTo("VolledigeNaam")));
        assertThat(nietNatuurlijkPersoonHr.getRechtspersoonId(), is(equalTo(1L)));
        assertThat(nietNatuurlijkPersoonHr.getBuitenlandseVennootschapId(), is(equalTo(2L)));
    }
}
