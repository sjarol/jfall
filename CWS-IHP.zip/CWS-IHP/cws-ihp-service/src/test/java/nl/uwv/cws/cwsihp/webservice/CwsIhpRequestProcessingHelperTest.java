package nl.uwv.cws.cwsihp.webservice;

import nl.uwv.cws.common.model.CwsAuditInformation;
import nl.uwv.cws.common.model.configuratie.ConfiguratieKey;
import nl.uwv.cws.common.service.CwsAuditLoggerService;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigerequest_v0007.CwsInhoudingsplichtigeRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;

import javax.xml.ws.WebServiceContext;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.time.LocalDateTime;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalToIgnoringCase;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
public class CwsIhpRequestProcessingHelperTest {

    @InjectMocks
    private CwsIhpRequestProcessingHelper cwsIhpRequestProcessingHelper;

    @Mock
    private CwsAuditInformation cwsAuditInformation;

    @Mock
    private CwsAuditLoggerService cwsAuditLoggerService;

    @Mock
    private Logger logger;

    @Captor
    private ArgumentCaptor<String> firstArgumentCaptor, secondArgumentCaptor;

    CwsInhoudingsplichtigeRequest cwsInhoudingsplichtigeRequest;
    CwsInhoudingsplichtigeRequest.Gegevensvraag gegevensvraag;

    @BeforeEach
    public void setup() throws Exception {
        setFinalStatic(CwsIhpRequestProcessingHelper.class.getDeclaredField("log"), logger);

        cwsInhoudingsplichtigeRequest = new CwsInhoudingsplichtigeRequest();
        gegevensvraag = new CwsInhoudingsplichtigeRequest.Gegevensvraag();
        CwsInhoudingsplichtigeRequest.Gegevensvraag.ContractGegevenslevering contractGegevenslevering = new CwsInhoudingsplichtigeRequest.Gegevensvraag.ContractGegevenslevering();
        contractGegevenslevering.setContractnrGegevenslevering("1234567890");
        contractGegevenslevering.setDatBContractGegevenslevering("20220701");
        CwsInhoudingsplichtigeRequest.Gegevensvraag.ContractGegevenslevering.GegevensafnemerConfiguratie configuratie = new CwsInhoudingsplichtigeRequest.Gegevensvraag.ContractGegevenslevering.GegevensafnemerConfiguratie();
        configuratie.setVersienrGegevensafnemerConf("1");
        contractGegevenslevering.setGegevensafnemerConfiguratie(configuratie);
        gegevensvraag.setContractGegevenslevering(contractGegevenslevering);
    }

    @Test
    @DisplayName("Should log correct line using PersoonInhoudingsplichtige")
    public void testLogRequestPartUsingPersoonInhoudingsplichtige(){
        CwsInhoudingsplichtigeRequest.Gegevensvraag.PersoonInhoudingsplichtige persoonInhoudingsplichtige = new CwsInhoudingsplichtigeRequest.Gegevensvraag.PersoonInhoudingsplichtige();
        persoonInhoudingsplichtige.setNrInhoudingsplichtige("888779922");
        gegevensvraag.setPersoonInhoudingsplichtige(persoonInhoudingsplichtige);
        cwsInhoudingsplichtigeRequest.setGegevensvraag(gegevensvraag);

        cwsIhpRequestProcessingHelper.logRequestPart(cwsInhoudingsplichtigeRequest);

        verify(logger, Mockito.atLeastOnce()).info(firstArgumentCaptor.capture());

        List<String> allValues = firstArgumentCaptor.getAllValues();
        assertThat(allValues, is(notNullValue()));
        final String expectedMessage = "Contractnummer: 1234567890; Datum aanvang contract: 20220701; Versienummer gegevensafnemer configuratie: 1; Nummer Inhoudingsplichtige: ******922";
        final String actualMessage = allValues.get(0);
        assertThat(actualMessage, equalToIgnoringCase(expectedMessage));
    }

    @Test
    @DisplayName("Should log correct line using AdministratieveEenheid")
    public void testLogRequestPartUsingAdministratieveEenheid(){
        CwsInhoudingsplichtigeRequest.Gegevensvraag.AdministratieveEenheid administratieveEenheid = new CwsInhoudingsplichtigeRequest.Gegevensvraag.AdministratieveEenheid();
        administratieveEenheid.setLoonheffingennr("123456789L01");
        gegevensvraag.setAdministratieveEenheid(administratieveEenheid);
        cwsInhoudingsplichtigeRequest.setGegevensvraag(gegevensvraag);

        cwsIhpRequestProcessingHelper.logRequestPart(cwsInhoudingsplichtigeRequest);
        verify(logger, Mockito.atLeastOnce()).info(firstArgumentCaptor.capture(), secondArgumentCaptor.capture());

        List<String> firstArgumentValues = firstArgumentCaptor.getAllValues();
        assertThat(firstArgumentValues, is(notNullValue()));
        final String expectedMessageText = "Contractnummer: 1234567890; Datum aanvang contract: 20220701; Versienummer gegevensafnemer configuratie: 1; Loonheffingennummer: {}";
        final String actualMessage = firstArgumentValues.get(0);
        assertThat(actualMessage, equalToIgnoringCase(expectedMessageText));

        List<String> secondArgumentValues = secondArgumentCaptor.getAllValues();
        final String expectedMessageLhNr = "123456789L01";
        final String actualMessageLhNr = secondArgumentValues.get(0);
        assertThat(actualMessageLhNr, equalToIgnoringCase(expectedMessageLhNr));
    }

    @Test
    @DisplayName("Should log correct line using KVK")
    public void testLogRequestPartUsingKvk(){
        CwsInhoudingsplichtigeRequest.Gegevensvraag.WerkgeverKvk werkgeverKvk = new CwsInhoudingsplichtigeRequest.Gegevensvraag.WerkgeverKvk();
        werkgeverKvk.setKvkNr("123456789");
        gegevensvraag.setWerkgeverKvk(werkgeverKvk);
        cwsInhoudingsplichtigeRequest.setGegevensvraag(gegevensvraag);

        cwsIhpRequestProcessingHelper.logRequestPart(cwsInhoudingsplichtigeRequest);
        verify(logger, Mockito.atLeastOnce()).info(firstArgumentCaptor.capture(), secondArgumentCaptor.capture());

        List<String> firstArgumentValues = firstArgumentCaptor.getAllValues();
        assertThat(firstArgumentValues, is(notNullValue()));
        final String expectedMessageText = "Contractnummer: 1234567890; Datum aanvang contract: 20220701; Versienummer gegevensafnemer configuratie: 1; Kvk Nummer: {}";
        final String actualMessage = firstArgumentValues.get(0);
        assertThat(actualMessage, equalToIgnoringCase(expectedMessageText));

        List<String> secondArgumentValues = secondArgumentCaptor.getAllValues();
        final String expectedMessageKvkNr = "123456789";
        final String actualMessageKvkNr = secondArgumentValues.get(0);
        assertThat(actualMessageKvkNr, equalToIgnoringCase(expectedMessageKvkNr));
    }

    @Test
    @DisplayName("Should log correctly log audit using NrInhoudingsplichtige")
    public void testLogAuditUsingNrInhoudingsplichtige(){
        CwsInhoudingsplichtigeRequest.Gegevensvraag.PersoonInhoudingsplichtige persoonInhoudingsplichtige = new CwsInhoudingsplichtigeRequest.Gegevensvraag.PersoonInhoudingsplichtige();
        persoonInhoudingsplichtige.setNrInhoudingsplichtige("888779922");
        gegevensvraag.setPersoonInhoudingsplichtige(persoonInhoudingsplichtige);
        cwsInhoudingsplichtigeRequest.setGegevensvraag(gegevensvraag);

        boolean gegevensGeleverd = true;
        WebServiceContext webServiceContext = mock(WebServiceContext.class);
        cwsIhpRequestProcessingHelper.logAudit(webServiceContext, cwsInhoudingsplichtigeRequest, gegevensGeleverd);

        verify(cwsAuditInformation, Mockito.atLeastOnce()).setNrInhoudingsplichtige("888779922");
        verify(cwsAuditInformation, Mockito.atLeastOnce()).addDeterminedBeschouwingsmoment(any());
        verify(cwsAuditInformation, Mockito.atLeastOnce()).setContractId("1234567890");
        verify(cwsAuditLoggerService, Mockito.atLeastOnce()).log(cwsAuditInformation, webServiceContext, gegevensGeleverd);
    }

    @Test
    @DisplayName("Should log correctly log audit using WerkgeverKvk")
    public void testLogAuditUsingWerkgeverKvk(){
        CwsInhoudingsplichtigeRequest.Gegevensvraag.WerkgeverKvk werkgeverKvk = new CwsInhoudingsplichtigeRequest.Gegevensvraag.WerkgeverKvk();
        werkgeverKvk.setKvkNr("123456789");
        gegevensvraag.setWerkgeverKvk(werkgeverKvk);
        cwsInhoudingsplichtigeRequest.setGegevensvraag(gegevensvraag);

        boolean gegevensGeleverd = true;
        WebServiceContext webServiceContext = mock(WebServiceContext.class);
        cwsIhpRequestProcessingHelper.logAudit(webServiceContext, cwsInhoudingsplichtigeRequest, gegevensGeleverd);

        verify(cwsAuditInformation, Mockito.atLeastOnce()).setKvkNummer("123456789");
        verify(cwsAuditInformation, Mockito.atLeastOnce()).addDeterminedBeschouwingsmoment(any());
        verify(cwsAuditInformation, Mockito.atLeastOnce()).setContractId("1234567890");
        verify(cwsAuditLoggerService, Mockito.atLeastOnce()).log(cwsAuditInformation, webServiceContext, gegevensGeleverd);
    }

    @Test
    @DisplayName("Should log correctly log audit using Loonheffingennr")
    public void testLogAuditUsingLoonheffingennr(){
        CwsInhoudingsplichtigeRequest.Gegevensvraag.AdministratieveEenheid administratieveEenheid = new CwsInhoudingsplichtigeRequest.Gegevensvraag.AdministratieveEenheid();
        administratieveEenheid.setLoonheffingennr("123456789L01");
        gegevensvraag.setAdministratieveEenheid(administratieveEenheid);
        cwsInhoudingsplichtigeRequest.setGegevensvraag(gegevensvraag);

        boolean gegevensGeleverd = true;
        WebServiceContext webServiceContext = mock(WebServiceContext.class);
        cwsIhpRequestProcessingHelper.logAudit(webServiceContext, cwsInhoudingsplichtigeRequest, gegevensGeleverd);

        verify(cwsAuditInformation, Mockito.atLeastOnce()).setLoonheffingennr("123456789L01");
        verify(cwsAuditInformation, Mockito.atLeastOnce()).addDeterminedBeschouwingsmoment(any());
        verify(cwsAuditInformation, Mockito.atLeastOnce()).setContractId("1234567890");
        verify(cwsAuditLoggerService, Mockito.atLeastOnce()).log(cwsAuditInformation, webServiceContext, gegevensGeleverd);
    }

    @Test
    @DisplayName("Should extract ConfiguratieKeycorrectly")
    public void testExtractConfiguratieKey(){
        cwsInhoudingsplichtigeRequest.setGegevensvraag(gegevensvraag);
        ConfiguratieKey configuratieKey = cwsIhpRequestProcessingHelper.extractConfiguratieKey(cwsInhoudingsplichtigeRequest);
        assertThat(configuratieKey.getContractNummer(), equalToIgnoringCase("1234567890"));
        assertThat(configuratieKey.getContractStartDate(), equalToIgnoringCase("20220701"));
        assertThat(configuratieKey.getVersie(), equalToIgnoringCase("1"));
    }

    static void setFinalStatic(Field field, Object newValue) throws Exception {
        field.setAccessible(true);
        Field modifiersField = Field.class.getDeclaredField("modifiers");
        modifiersField.setAccessible(true);
        modifiersField.setInt(field, field.getModifiers() & ~Modifier.FINAL);
        field.set(null, newValue);
    }
}
