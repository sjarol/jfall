package nl.uwv.cws.cwsihp.webservice.mapper;

import nl.uwv.cws.cwsihp.model.hr.RechtsvormHr;
import nl.uwv.cws.cwsihp.model.wg.RechtsvormWg;
import nl.uwv.cws.common.webservice.rule.CwsRuleExecutor;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0007.CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Rechtsvorm;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Date;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
public class RechtsvormMapperTest {

    @InjectMocks
    private RechtsvormMapper rechtsvormMapper;

    @Mock
    private CwsRuleExecutor ruleExecutor;

    @Captor
    private ArgumentCaptor<Object> ihpFieldCaptor;

    @Captor
    private ArgumentCaptor<String> xsdFieldCaptor;

    @Test
    @DisplayName("Given RechtsvormHr test mapping fields to JaxB is successful")
    public void testMapToJaxbRechtsvormHr() {
        RechtsvormHr rechtsvormHr = createRechtsvormHr();
        rechtsvormMapper.mapToJaxbRechtsvormHr(rechtsvormHr);

        verify(ruleExecutor, times(5)).setTransformedValue(any(Rechtsvorm.class), xsdFieldCaptor.capture(), ihpFieldCaptor.capture());
        List<String> hrFieldValues = Arrays.asList( "codeRechtsvorm", "20180201","0", "20190201", "0");
        List<String> xsdFieldValues = Arrays.asList("cdRechtsvorm", "datBRechtsvorm", "cdFictieveDatB", "datERechtsvorm", "cdFictieveDatE");

        assertArrayEquals(hrFieldValues.toArray(), ihpFieldCaptor.getAllValues().toArray());
        assertEquals(xsdFieldValues, xsdFieldCaptor.getAllValues());
    }

    private RechtsvormHr createRechtsvormHr() {
        return RechtsvormHr.builder()
                .codeRechtsvorm("codeRechtsvorm")
                .datumAanvangRechtsvorm(Date.valueOf(LocalDate.of(2018,2,1)))
                .codeFictieveDatumAanvang(0)
                .datumEindeRechtsvorm(Date.valueOf(LocalDate.of(2019,2,1)))
                .codeFictieveDatumEinde(0)
                .build();
    }

    @Test
    @DisplayName("Given RechtsvormWg test mapping fields to JaxB is successful")
    public void testMapToJaxbRechtsvormWg() {
        RechtsvormWg rechtsvormWg = createRechtsvormWg();
        rechtsvormMapper.mapToJaxbRechtsvormWg(rechtsvormWg);

        verify(ruleExecutor, times(5)).setTransformedValue(any(Object.class), xsdFieldCaptor.capture(), ihpFieldCaptor.capture());
        List<String> wgFieldValues = Arrays.asList("code rechtsvorm","20210601", "0", "20231201", "0");
        List<String> xsdFieldValues = Arrays.asList("cdRechtsvorm", "datBRechtsvorm", "cdFictieveDatB", "datERechtsvorm", "cdFictieveDatE");
        assertArrayEquals(wgFieldValues.toArray(), ihpFieldCaptor.getAllValues().toArray());
        assertEquals(xsdFieldValues, xsdFieldCaptor.getAllValues());
    }

    private RechtsvormWg createRechtsvormWg() {
        return RechtsvormWg.builder()
                .codeRechtsvorm("code rechtsvorm")
                .datumAanvangRechtsvorm(20210601L)
                .datumEindeRechtsvorm(20231201L)
                .build();
    }
}
