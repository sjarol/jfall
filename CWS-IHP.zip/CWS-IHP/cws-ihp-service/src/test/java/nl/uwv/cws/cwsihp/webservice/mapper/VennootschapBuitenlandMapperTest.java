package nl.uwv.cws.cwsihp.webservice.mapper;

import nl.uwv.cws.cwsihp.model.hr.VennootschapBuitenlandHr;
import nl.uwv.cws.common.webservice.rule.CwsRuleExecutor;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Date;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
public class VennootschapBuitenlandMapperTest {
    @InjectMocks
    private VennootschapBuitenlandMapper vennootschapBuitenlandMapper;

    @Mock
    private CwsRuleExecutor ruleExecutor;

    @Captor
    private ArgumentCaptor<Object> ihpFieldCaptor;

    @Captor
    private ArgumentCaptor<String> xsdFieldCaptor;

    @Test
    @DisplayName("Given VennootschapBuitenlandHr test mapping fields to JaxB is successful")
    public void testMapToJaxbVennootschapBuitenland() {
        VennootschapBuitenlandHr vennootschapBuitenlandHr = createVennootschapBuitenlandHr();
        vennootschapBuitenlandMapper.mapToJaxbVennootschapBuitenland(vennootschapBuitenlandHr);

        verify(ruleExecutor, times(4)).setTransformedValue(any(Object.class), xsdFieldCaptor.capture(), ihpFieldCaptor.capture());
        List<String> hrFieldValues = Arrays.asList("20200101","1", "20200131", "2");
        List<String> xsdFieldValues = Arrays.asList("datBVennootschapBuitenland", "cdFictieveDatB", "datEVennootschapBuitenland", "cdFictieveDatE");
        assertArrayEquals(hrFieldValues.toArray(), ihpFieldCaptor.getAllValues().toArray());
        assertEquals(xsdFieldValues, xsdFieldCaptor.getAllValues());
    }

    @Test
    @DisplayName("Given VennootschapBuitenlandHr WithoutDates test mapping fields to JaxB is successful")
    public void testMapToJaxbVennootschapBuitenlandWithoutDates() {
        VennootschapBuitenlandHr vennootschapBuitenlandHr = createVennootschapBuitenlandHrWithoutDates();
        vennootschapBuitenlandMapper.mapToJaxbVennootschapBuitenland(vennootschapBuitenlandHr);

        verify(ruleExecutor, times(4)).setTransformedValue(any(Object.class), xsdFieldCaptor.capture(), ihpFieldCaptor.capture());
        List<String> hrFieldValues = Arrays.asList(null,null, null, null);
        List<String> xsdFieldValues = Arrays.asList("datBVennootschapBuitenland", "cdFictieveDatB", "datEVennootschapBuitenland", "cdFictieveDatE");
        assertArrayEquals(hrFieldValues.toArray(), ihpFieldCaptor.getAllValues().toArray());
        assertEquals(xsdFieldValues, xsdFieldCaptor.getAllValues());
    }

    private VennootschapBuitenlandHr createVennootschapBuitenlandHr() {
        return VennootschapBuitenlandHr.builder()
                .datumAanvangVennootschapBuitenland(Date.valueOf(LocalDate.of(2020,1,1)))
                .codeFictieveDatumAanvang(1)
                .datumEindeVennootschapBuitenland(Date.valueOf(LocalDate.of(2020,1,31)))
                .codeFictieveDatumEinde(2)
                .build();
    }

    private VennootschapBuitenlandHr createVennootschapBuitenlandHrWithoutDates() {
        return VennootschapBuitenlandHr.builder()
                .datumAanvangVennootschapBuitenland(null)
                .codeFictieveDatumAanvang(1)
                .datumEindeVennootschapBuitenland(null)
                .codeFictieveDatumEinde(2)
                .build();
    }
}
