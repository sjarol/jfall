package nl.uwv.cws.cwsihp.webservice.rule.transformer;

import nl.uwv.cws.common.model.rule.AttributeRuleProperties;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static nl.uwv.cws.cwsihp.model.rule.CwsIhpAttributeRule.AFKAPPEN_OBV_SIZE_MAX_EN_MES1_OF_NULL;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;

public class AfkappenObvSizeMaxEnMes1OfNullTransformerTest {

    private AfkappenObvSizeMaxEnMes1OfNullTransformer afkappenObvSizeMaxEnMes1OfNullTransformer;
    private AttributeRuleProperties attributeRuleProperties;

    @BeforeEach
    public void setup() {
        afkappenObvSizeMaxEnMes1OfNullTransformer = new AfkappenObvSizeMaxEnMes1OfNullTransformer();
        attributeRuleProperties = new AttributeRuleProperties();
        attributeRuleProperties.setSizeMax(10);
    }

    @Test
    @DisplayName("Should use correct rule type")
    public void givenValueShouldUseCorrectRuletype() {
        assertThat(afkappenObvSizeMaxEnMes1OfNullTransformer.getTransformRule(), is(AFKAPPEN_OBV_SIZE_MAX_EN_MES1_OF_NULL));
    }

    @Test
    @DisplayName("Should apply MES-1 and cut off when too long")
    public void givenValueApplyRuleToolong() {
        String originalValue = "vąluƔNoƏMesTooLong";
        String transformedValue = afkappenObvSizeMaxEnMes1OfNullTransformer.transform(originalValue, attributeRuleProperties);
        assertThat(transformedValue, is("vąlu?No?Me"));
    }

    @Test
    @DisplayName("Should return null when contains digits")
    public void givenValueApplyRuleNullWhenContainsNumber() {
        String originalValue = "vąluƔ123";
        String transformedValue = afkappenObvSizeMaxEnMes1OfNullTransformer.transform(originalValue, attributeRuleProperties);
        assertThat(transformedValue, is(nullValue()));
    }

    @Test
    @DisplayName("Should return null when null")
    public void givenValueApplyRuleNullWhenEmpty() {
        String originalValue = null;
        String transformedValue = afkappenObvSizeMaxEnMes1OfNullTransformer.transform(originalValue, attributeRuleProperties);
        assertThat(transformedValue, is(nullValue()));
    }
}
