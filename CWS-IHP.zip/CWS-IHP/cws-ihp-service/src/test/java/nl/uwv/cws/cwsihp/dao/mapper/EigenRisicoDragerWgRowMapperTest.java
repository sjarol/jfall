package nl.uwv.cws.cwsihp.dao.mapper;

import nl.uwv.cws.cwsihp.model.wg.EigenRisicoDragerWg;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.Mockito.when;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@ExtendWith(MockitoExtension.class)
public class EigenRisicoDragerWgRowMapperTest {

    @InjectMocks
    private EigenRisicoDragerWgRowMapper eigenRisicoDragerWgRowMapper;

    @Mock
    private ResultSet resultSet;

    @BeforeEach
    public void setup() throws SQLException {
        when(resultSet.getObject("DATEIND")).thenReturn(1);
    }

    @Test
    @DisplayName("Should successfully map fields for EigenRisicoDragerWg and map DatumEinde to -1")
    public void testMapRowDatumEindeTotEnMet() throws SQLException {
        when(resultSet.getString("SZ_PRODUCT_CODE")).thenReturn("Productcode SZ");
        when(resultSet.getObject("DATAANV")).thenReturn(1);
        when(resultSet.getLong("DATAANV")).thenReturn(20210101L);
        when(resultSet.getLong("DATEIND")).thenReturn(20210601L);

        List<String> attributen = Arrays.asList("SZ_PRODUCT_CODE", "PERCENTAGE", "DATAANV", "DATEIND");

        EigenRisicoDragerWg eigenRisicoDragerWg = eigenRisicoDragerWgRowMapper.mapRow(resultSet, attributen);
        assertThat(eigenRisicoDragerWg, is(notNullValue()));
        assertThat(eigenRisicoDragerWg.getCodeSzProduct(), is(equalTo("Productcode SZ")));
        assertThat(eigenRisicoDragerWg.getDatumAanvangEigenRisicoDrager(), is(equalTo(20210101L)));
        assertThat(eigenRisicoDragerWg.getDatumEindeEigenRisicoDrager(), is(equalTo(20210531L)));
    }

    @Test
    @DisplayName("Should successfully map fields for EigenRisicoDragerWg and map DatumEinde to NULL")
    public void testMapRowDatumEindeNULL() throws SQLException {
        when(resultSet.getLong("DATEIND")).thenReturn(99991231L);

        List<String> attributen = Arrays.asList("DATEIND");

        EigenRisicoDragerWg eigenRisicoDragerWg = eigenRisicoDragerWgRowMapper.mapRow(resultSet, attributen);
        assertThat(eigenRisicoDragerWg, is(notNullValue()));
        assertThat(eigenRisicoDragerWg.getDatumEindeEigenRisicoDrager(), is(equalTo(null)));
    }
}
