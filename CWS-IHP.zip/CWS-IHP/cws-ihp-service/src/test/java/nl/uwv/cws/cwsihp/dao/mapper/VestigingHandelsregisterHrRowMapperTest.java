package nl.uwv.cws.cwsihp.dao.mapper;

import nl.uwv.cws.cwsihp.model.hr.VestigingHandelsregisterHr;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class VestigingHandelsregisterHrRowMapperTest {

    @InjectMocks
    private VestigingHandelsregisterHrRowMapper vestigingHandelsregisterHrRowMapper;

    @Mock
    private ResultSet resultSet;

    @BeforeEach
    public void setup() throws SQLException {
        when(resultSet.getObject("CD_DATUM_AANVANG_CGM")).thenReturn(1);
        when(resultSet.getObject("CD_DATUM_EINDE_CGM")).thenReturn(2);
    }

    @Test
    @DisplayName("Should successfully set field of VestigingHandelsregisterHr")
    public void testMapRow() throws SQLException {
        when(resultSet.getLong("KVK_NUMMER")).thenReturn(88888888L);
        when(resultSet.getLong("VESTIGINGS_NUMMER")).thenReturn(123456789L);
        when(resultSet.getString("EERSTE_HANDELSNAAM")).thenReturn("Eerste Handelsnaam");
        when(resultSet.getDate("DATUM_AANVANG_CGM")).thenReturn(Date.valueOf(LocalDate.of(2020,1,1)));
        when(resultSet.getInt("CD_DATUM_AANVANG_CGM")).thenReturn(1);
        when(resultSet.getDate("DATUM_EINDE_CGM")).thenReturn(Date.valueOf(LocalDate.of(2020,1,31)));
        when(resultSet.getInt("CD_DATUM_EINDE_CGM")).thenReturn(2);

        List<String> attributen = Arrays.asList("VESTIGINGS_NUMMER", "EERSTE_HANDELSNAAM", "DATUM_AANVANG_CGM",
                "CD_DATUM_AANVANG_CGM", "DATUM_EINDE_CGM", "CD_DATUM_EINDE_CGM");

        VestigingHandelsregisterHr vestigingHandelsregisterHr = vestigingHandelsregisterHrRowMapper.mapRow(resultSet, attributen);
        assertThat(vestigingHandelsregisterHr, is(notNullValue()));
        assertThat(vestigingHandelsregisterHr.getKvkNummer(), is(equalTo("88888888")));
        assertThat(vestigingHandelsregisterHr.getVestigingsNummer(), is(equalTo(123456789L)));
        assertThat(vestigingHandelsregisterHr.isConfigurationIncludesVestigingsNummer(), is(true));
        assertThat(vestigingHandelsregisterHr.getEersteHandelsnaam(), is(equalTo("Eerste Handelsnaam")));
        assertThat(vestigingHandelsregisterHr.getDatumAanvangVestigingHandelsregister(), is(Date.valueOf(LocalDate.of(2020,1,1))));
        assertThat(vestigingHandelsregisterHr.getCodeFictieveDatumAanvang(), is(equalTo(1)));
        assertThat(vestigingHandelsregisterHr.getDatumEindeVestigingHandelsregister(), is(Date.valueOf(LocalDate.of(2020,1,31))));
        assertThat(vestigingHandelsregisterHr.getCodeFictieveDatumEinde(), is(equalTo(2)));
    }
}
