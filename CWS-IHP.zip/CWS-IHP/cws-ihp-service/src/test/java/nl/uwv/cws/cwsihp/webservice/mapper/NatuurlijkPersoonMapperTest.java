package nl.uwv.cws.cwsihp.webservice.mapper;

import nl.uwv.cws.cwsihp.model.hr.NatuurlijkPersoonHr;
import nl.uwv.cws.cwsihp.model.ihp.HuwelijkGeregistreerdPartnerIhp;
import nl.uwv.cws.cwsihp.model.ihp.NatuurlijkPersoonIhp;
import nl.uwv.cws.cwsihp.model.wg.NatuurlijkPersoonWg;
import nl.uwv.cws.common.webservice.rule.CwsRuleExecutor;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Date;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
public class NatuurlijkPersoonMapperTest {
    @InjectMocks
    private NatuurlijkPersoonMapper natuurlijkPersoonMapper;

    @Mock
    private HuwelijkGeregistreerdPartnerMapper huwelijkGeregistreerdPartnerMapper;

    @Mock
    private CwsRuleExecutor ruleExecutor;

    @Captor
    private ArgumentCaptor<Object> ihpFieldCaptor;

    @Captor
    private ArgumentCaptor<String> xsdFieldCaptor;

    @Test
    @DisplayName("Given NatuurlijkPersoonHr test mapping fields to JaxB is successful")
    public void testMapToJaxbNatuurlijkPersoonHr() {

        NatuurlijkPersoonIhp natuurlijkPersoonIhp = createNatuurlijkPersoonHr();
        natuurlijkPersoonMapper.mapToJaxbNatuurlijkPersoon(natuurlijkPersoonIhp);

        verify(ruleExecutor, times(9)).setTransformedValue(any(Object.class), xsdFieldCaptor.capture(), ihpFieldCaptor.capture());
        List<Object> hrFieldValues = Arrays.asList("999999990", null, "Voornamen", "Voorvoegsel", "Achternaam", "2",
                "19700101","0", null);
        List<String> xsdFieldValues = Arrays.asList("burgerservicenr", "voorletters", "voornamen", "voorvoegsel",
                "significantDeelVanDeAchternaam", "cdAanduidingNaamgebruik", "geboortedat", "cdFictieveGeboortedat", "geslacht");

        assertArrayEquals(hrFieldValues.toArray(), ihpFieldCaptor.getAllValues().toArray());
        assertEquals(xsdFieldValues, xsdFieldCaptor.getAllValues());
    }

    @Test
    @DisplayName("Given NatuurlijkPersoonWg test mapping fields to JaxB is successful")
    public void testMapToJaxbNatuurlijkPersoonWg() {

        NatuurlijkPersoonIhp natuurlijkPersoonIhp = createNatuurlijkPersoonWg();
        natuurlijkPersoonMapper.mapToJaxbNatuurlijkPersoon(natuurlijkPersoonIhp);

        verify(ruleExecutor, times(9)).setTransformedValue(any(Object.class), xsdFieldCaptor.capture(), ihpFieldCaptor.capture());
        List<Object> hrFieldValues = Arrays.asList("999999990", "Voorletters", "Voornamen", "Voorvoegsel", "Achternaam", "2",
                "19700101","0", "M");
        List<String> xsdFieldValues = Arrays.asList("burgerservicenr", "voorletters", "voornamen", "voorvoegsel",
                "significantDeelVanDeAchternaam", "cdAanduidingNaamgebruik", "geboortedat", "cdFictieveGeboortedat", "geslacht");

        assertArrayEquals(hrFieldValues.toArray(), ihpFieldCaptor.getAllValues().toArray());
        assertEquals(xsdFieldValues, xsdFieldCaptor.getAllValues());
    }

    @Test
    @DisplayName("Given NatuurlijkPersoonIhp with HuwelijkGeregistreerdPartnerIhp verify huwelijkGeregistreerdPartnerMapper is called")
    public void testMapToJaxbNatuurlijkPersoonWithHuwelijkGeregistreerdPartnerHr() {
        NatuurlijkPersoonIhp natuurlijkPersoonIhp = createNatuurlijkPersoonHr();

        HuwelijkGeregistreerdPartnerIhp huwelijkGeregistreerdPartnerIhp = createHuwelijkGeregistreerdPartner();
        NatuurlijkPersoonHr natuurlijkPersoonHr = NatuurlijkPersoonHr.builder().huwelijkGeregistreerdPartnerIhp(huwelijkGeregistreerdPartnerIhp).build();
        natuurlijkPersoonIhp.setNatuurlijkPersoonHr(natuurlijkPersoonHr);

        natuurlijkPersoonMapper.mapToJaxbNatuurlijkPersoon(natuurlijkPersoonIhp);

        verify(huwelijkGeregistreerdPartnerMapper,times(1)).mapToJaxbHuwelijkGeregistreerdPartner(any(HuwelijkGeregistreerdPartnerIhp.class));
    }

    private NatuurlijkPersoonIhp createNatuurlijkPersoonHr() {

        NatuurlijkPersoonHr natuurlijkPersoonHr = NatuurlijkPersoonHr.builder()
                .burgerservicenummer(999999990)
                .voorletters(null)
                .voornamen("Voornamen")
                .voorvoegsel("Voorvoegsel")
                .achternaam("Achternaam")
                .codeAanduidingNaamgebruik(2)
                .geboorteDatum(Date.valueOf(LocalDate.of(1970,1,1)))
                .codeFictieveGeboortedatum(0)
                .geslacht(null)
                .build();

        return NatuurlijkPersoonIhp.builder().natuurlijkPersoonHr(natuurlijkPersoonHr).build();
    }

    private NatuurlijkPersoonIhp createNatuurlijkPersoonWg() {

        NatuurlijkPersoonWg natuurlijkPersoonWg = NatuurlijkPersoonWg.builder()
                .burgerservicenummer(999999990)
                .voorletters("Voorletters")
                .voornamen("Voornamen")
                .voorvoegsel("Voorvoegsel")
                .achternaam("Achternaam")
                .codeAanduidingNaamgebruik(2)
                .geboorteDatum(19700101)
                .codeFictieveGeboortedatum(0)
                .geslacht("M")
                .build();

        return NatuurlijkPersoonIhp.builder().natuurlijkPersoonWg(natuurlijkPersoonWg).build();
    }

    private HuwelijkGeregistreerdPartnerIhp createHuwelijkGeregistreerdPartner() {
        return HuwelijkGeregistreerdPartnerIhp.builder()
                .voorvoegselGeslachtsnaamPartner("VoorvoegselPartner")
                .geslachtsnaamPartner("GeslachtsnaamPartner")
                .build();
    }
}
