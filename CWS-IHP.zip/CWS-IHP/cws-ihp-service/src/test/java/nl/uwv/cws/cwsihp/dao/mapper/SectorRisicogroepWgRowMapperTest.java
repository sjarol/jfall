package nl.uwv.cws.cwsihp.dao.mapper;

import nl.uwv.cws.cwsihp.model.wg.SectorRisicogroepWg;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.Mockito.when;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@ExtendWith(MockitoExtension.class)
public class SectorRisicogroepWgRowMapperTest {

    @InjectMocks
    private SectorRisicogroepWgRowMapper sectorRisicogroepWgRowMapper;

    @Mock
    private ResultSet resultSet;

    @BeforeEach
    public void setup() throws SQLException {
        when(resultSet.getObject("DATEIND")).thenReturn(1);
    }

    @Test
    @DisplayName("Should successfully map fields for SectorRisicogroepWg and map DatumEinde to -1")
    public void testMapRowDatumEindeTotEnMet() throws SQLException {
        when(resultSet.getString("SECT_RISICOGRP_CODE")).thenReturn("codeSectorRisicogroep");
        when(resultSet.getString("SECT_CODE")).thenReturn("codeSectorOsv");
        when(resultSet.getObject("DATAANV")).thenReturn(1);
        when(resultSet.getLong("DATAANV")).thenReturn(20210101L);
        when(resultSet.getLong("DATEIND")).thenReturn(20210601L);

        List<String> attributen = Arrays.asList("SECT_RISICOGRP_CODE", "SECT_CODE", "DATAANV", "DATEIND");

        SectorRisicogroepWg sectorRisicogroepWg = sectorRisicogroepWgRowMapper.mapRow(resultSet, attributen);
        assertThat(sectorRisicogroepWg, is(notNullValue()));
        assertThat(sectorRisicogroepWg.getCodeRisicopremiegroep(), is(equalTo("codeSectorRisicogroep")));
        assertThat(sectorRisicogroepWg.getCodeSectorOsv(), is(equalTo("codeSectorOsv")));
        assertThat(sectorRisicogroepWg.getDatumAanvangSectorRisicogroep(), is(equalTo(20210101L)));
        assertThat(sectorRisicogroepWg.getDatumEindeSectorRisicogroep(), is(equalTo(20210531L)));
    }

    @Test
    @DisplayName("Should successfully map fields for SectorRisicogroepWg and map DatumEinde to NULL")
    public void testMapRowDatumEindeNULL() throws SQLException {
        when(resultSet.getLong("DATEIND")).thenReturn(99991231L);

        List<String> attributen = Arrays.asList("DATEIND");

        SectorRisicogroepWg sectorRisicogroepWg = sectorRisicogroepWgRowMapper.mapRow(resultSet, attributen);
        assertThat(sectorRisicogroepWg, is(notNullValue()));
        assertThat(sectorRisicogroepWg.getDatumEindeSectorRisicogroep(), is(equalTo(null)));
    }
}
