package nl.uwv.cws.cwsihp.dao.mapper;

import nl.uwv.cws.cwsihp.model.wg.AdresBuitenlandOngestructureerdWg;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.Mockito.when;

@TestInstance(Lifecycle.PER_CLASS)
@ExtendWith(MockitoExtension.class)
public class AdresBuitenlandOngestructureerdWgRowMapperTest {

    @InjectMocks
    private AdresBuitenlandOngestructureerdWgRowMapper adresBuitenlandOngestructureerdWgRowMapper;

    @Mock
    private ResultSet resultSet;

    @Test
    @DisplayName("Should successfully map fields for AdresBuitenlandOngestructureerd")
    public void testMapAdresBuitenlandOngestructureerd() throws SQLException {
        when(resultSet.getString("ADRESROL")).thenReturn("C");
        when(resultSet.getObject("DATAANV")).thenReturn(1);
        when(resultSet.getLong("DATAANV")).thenReturn(20210101L);
        when(resultSet.getObject("DATEIND")).thenReturn(1);
        when(resultSet.getLong("DATEIND")).thenReturn(20210201L);

        when(resultSet.getString("B_ADRESREGEL")).thenReturn("Adresregel1Buitenland");
        when(resultSet.getString("B_WOONPL_LANDREGEL")).thenReturn("Adresregel2Buitenland");
        when(resultSet.getString("REGIONAAM")).thenReturn("Adresregel3Buitenland");
        when(resultSet.getString("LANDCODE")).thenReturn("NL");

        List<String> attributen = Arrays.asList("ADRESROL","DATAANV","DATEIND","B_ADRESREGEL","B_WOONPL_LANDREGEL","REGIONAAM","LANDCODE");

        AdresBuitenlandOngestructureerdWg adresBuitenlandOngestructureerdWg = adresBuitenlandOngestructureerdWgRowMapper.mapRow(resultSet, attributen);
        assertThat(adresBuitenlandOngestructureerdWg, is(notNullValue()));
        assertThat(adresBuitenlandOngestructureerdWg.getCodeAdresrol(), is(equalTo("C")));
        assertThat(adresBuitenlandOngestructureerdWg.getDatumAanvangAdreshouding(), is(equalTo(20210101L)));
        assertThat(adresBuitenlandOngestructureerdWg.getDatumEindeAdreshouding(), is(equalTo(20210131L)));

        assertThat(adresBuitenlandOngestructureerdWg.getAdresregel1Buitenland(), is(equalTo("Adresregel1Buitenland")));
        assertThat(adresBuitenlandOngestructureerdWg.getAdresregel2Buitenland(), is(equalTo("Adresregel2Buitenland")));
        assertThat(adresBuitenlandOngestructureerdWg.getAdresregel3Buitenland(), is(equalTo("Adresregel3Buitenland")));
        assertThat(adresBuitenlandOngestructureerdWg.getLandcodeIso(), is(equalTo("NL")));
    }
}
