package nl.uwv.cws.cwsihp.model.selection;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class SelectionParametersTest {

    @Test
    @DisplayName("Should return true")
    public void test_isPersoonInhoudingsplichtigeHr() {
        SelectionParameters selectionparameters = SelectionParameters.builder()
                .inhoudingsplichtigeIsPresentInHr(true)
                .inhoudingsplichtigeIsPresentInWg(false)
                .build();
        assertTrue(selectionparameters.isPersoonInhoudingsplichtigeHr());
    }

    @Test
    @DisplayName("Should return false")
    public void test_isNotPersoonInhoudingsplichtigeHr_notPresentInHr() {
        SelectionParameters selectionparameters = SelectionParameters.builder()
                .inhoudingsplichtigeIsPresentInHr(false)
                .inhoudingsplichtigeIsPresentInWg(false)
                .build();
        assertFalse(selectionparameters.isPersoonInhoudingsplichtigeHr());
    }

    @Test
    @DisplayName("Should return false")
    public void test_isNotPersoonInhoudingsplichtigeHr_presentInWg() {
        SelectionParameters selectionparameters = SelectionParameters.builder()
                .inhoudingsplichtigeIsPresentInHr(true)
                .inhoudingsplichtigeIsPresentInWg(true)
                .build();
        assertFalse(selectionparameters.isPersoonInhoudingsplichtigeHr());
    }

    @Test
    @DisplayName("Should return false")
    public void test_isNotPersoonInhoudingsplichtigeHr() {
        SelectionParameters selectionparameters = SelectionParameters.builder()
                .inhoudingsplichtigeIsPresentInHr(false)
                .inhoudingsplichtigeIsPresentInWg(true)
                .build();
        assertFalse(selectionparameters.isPersoonInhoudingsplichtigeHr());
    }

    @Test
    @DisplayName("Should return true")
    public void test_isPersoonInhoudingsplichtigeHrWg() {
        SelectionParameters selectionparameters = SelectionParameters.builder()
                .inhoudingsplichtigeIsPresentInHr(true)
                .inhoudingsplichtigeIsPresentInWg(true)
                .build();
        assertTrue(selectionparameters.isPersoonInhoudingsplichtigeHrWg());
    }

    @Test
    @DisplayName("Should return false")
    public void test_isNotPersoonInhoudingsplichtigeHrWg_notPresentInHr() {
        SelectionParameters selectionparameters = SelectionParameters.builder()
                .inhoudingsplichtigeIsPresentInHr(false)
                .inhoudingsplichtigeIsPresentInWg(true)
                .build();
        assertFalse(selectionparameters.isPersoonInhoudingsplichtigeHrWg());
    }

    @Test
    @DisplayName("Should return false")
    public void test_isNotPersoonInhoudingsplichtigeHrWg_notPresentInWg() {
        SelectionParameters selectionparameters = SelectionParameters.builder()
                .inhoudingsplichtigeIsPresentInHr(true)
                .inhoudingsplichtigeIsPresentInWg(false)
                .build();
        assertFalse(selectionparameters.isPersoonInhoudingsplichtigeHrWg());
    }

    @Test
    @DisplayName("Should return false")
    public void test_isNotPersoonInhoudingsplichtigeHrWg() {
        SelectionParameters selectionparameters = SelectionParameters.builder()
                .inhoudingsplichtigeIsPresentInHr(false)
                .inhoudingsplichtigeIsPresentInWg(false)
                .build();
        assertFalse(selectionparameters.isPersoonInhoudingsplichtigeHrWg());
    }
}
