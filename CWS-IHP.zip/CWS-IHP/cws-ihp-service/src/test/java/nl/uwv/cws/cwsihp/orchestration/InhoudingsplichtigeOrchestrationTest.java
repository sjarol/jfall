package nl.uwv.cws.cwsihp.orchestration;


import nl.uwv.cws.common.exception.ApplicatieMeldingException;
import nl.uwv.cws.common.model.CwsAuditInformation;
import nl.uwv.cws.common.model.configuratie.ConfiguratieKey;
import nl.uwv.cws.common.service.AfnemerService;
import nl.uwv.cws.cwsihp.model.configuratie.CwsIhpConfiguratie;
import nl.uwv.cws.cwsihp.model.ihp.Inhoudingsplichtige;
import nl.uwv.cws.cwsihp.service.BeschouwingsmomentService;
import nl.uwv.cws.cwsihp.service.CwsIhpConfiguratieService;
import nl.uwv.cws.cwsihp.service.IdentifierStatusService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalToIgnoringCase;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class InhoudingsplichtigeOrchestrationTest {

    @InjectMocks
    private InhoudingsplichtigeOrchestration inhoudingsplichtigeOrchestration;

    @Mock
    private CwsAuditInformation cwsIhpAuditInformation;

    @Mock
    private IdentifierStatusService identifierStatusService;

    @Mock
    private AfnemerService afnemerService;

    @Mock
    private CwsIhpConfiguratieService cwsIhpConfiguratieService;

    @Mock
    private BeschouwingsmomentService beschouwingsmomentService;

    @Test
    @DisplayName("Should throw Exception code F065 when Werkgever admin does not contain this loonheffingennummer")
    public void testCollectInhoudingsplichtigeUsingLoonheffingNummer() {
        ConfiguratieKey configuratieKey = ConfiguratieKey.builder().build();
        String loonheffingenNummer = "123456789L01";

        CwsIhpConfiguratie configuratie = new CwsIhpConfiguratie();
        when(cwsIhpConfiguratieService.getConfiguratie(configuratieKey)).thenReturn(configuratie);

        LocalDateTime beschouwingsmoment = LocalDateTime.of(2022,7,22,12,45);
        when(beschouwingsmomentService.getBeschouwingsmoment()).thenReturn(beschouwingsmoment);
        when(identifierStatusService.isAdministratieveEenheidPresent(loonheffingenNummer, beschouwingsmoment)).thenReturn(false);

        ApplicatieMeldingException exception = assertThrows(ApplicatieMeldingException.class, () ->
                inhoudingsplichtigeOrchestration.collectInhoudingsplichtigeUsingLoonheffingNummer(configuratieKey, loonheffingenNummer));

        String actualMessage = exception.getFoutmelding().getMessage();
        String foutCode = exception.getFoutmelding().getCode();
        String soort = exception.getFoutmelding().getSoort();

        assertThat(actualMessage, equalToIgnoringCase("Loonheffingennummer niet gevonden in de werkgeversadministratie"));
        assertThat(foutCode, equalToIgnoringCase("065"));
        assertThat(soort, equalToIgnoringCase("F"));
    }

    @Test
    @DisplayName("Should throw Exception code 042 when UHR does not contain this Werkgever")
    public void testCollectInhoudingsplichtigeUsingKvkNummer() {
        ConfiguratieKey configuratieKey = ConfiguratieKey.builder().build();
        String kvkNr = "12345678";

        CwsIhpConfiguratie configuratie = new CwsIhpConfiguratie();
        when(cwsIhpConfiguratieService.getConfiguratie(configuratieKey)).thenReturn(configuratie);
        Inhoudingsplichtige inhoudingsplichtigeUhr = Inhoudingsplichtige.builder().bsn(null).build();

        LocalDateTime beschouwingsmoment = LocalDateTime.of(2022,7,22,12,45);
        when(beschouwingsmomentService.getBeschouwingsmoment()).thenReturn(beschouwingsmoment);
        when(identifierStatusService.isWerkgeverPresent(kvkNr, beschouwingsmoment)).thenReturn(false);

        ApplicatieMeldingException exception = assertThrows(ApplicatieMeldingException.class, () ->
                inhoudingsplichtigeOrchestration.collectInhoudingsplichtigeUsingKvkNummer(configuratieKey, kvkNr));

        String actualMessage = exception.getFoutmelding().getMessage();
        String foutCode = exception.getFoutmelding().getCode();
        String soort = exception.getFoutmelding().getSoort();

        assertThat(actualMessage, equalToIgnoringCase("KvK-nummer niet gevonden"));
        assertThat(foutCode, equalToIgnoringCase("042"));
        assertThat(soort, equalToIgnoringCase("F"));
    }

    @Test
    @DisplayName("Should throw Exception code 071 when UHR and WGA does not contain this nrihp")
    public void testCollectInhoudingsplichtigeUsingNummerInhoudingsplichtige() {
        ConfiguratieKey configuratieKey = ConfiguratieKey.builder().build();
        String nrIhp = "123456789";

        CwsIhpConfiguratie configuratie = new CwsIhpConfiguratie();
        when(cwsIhpConfiguratieService.getConfiguratie(configuratieKey)).thenReturn(configuratie);
        Inhoudingsplichtige inhoudingsplichtigeUhr = Inhoudingsplichtige.builder().bsn(null).build();

        LocalDateTime beschouwingsmoment = LocalDateTime.of(2022,7,22,12,45);
        when(beschouwingsmomentService.getBeschouwingsmoment()).thenReturn(beschouwingsmoment);
        when(identifierStatusService.isInhoudingsplichtigePresentInHr(nrIhp, beschouwingsmoment)).thenReturn(false);
        when(identifierStatusService.isInhoudingsplichtigePresentInWga(nrIhp, beschouwingsmoment)).thenReturn(false);

        ApplicatieMeldingException exception = assertThrows(ApplicatieMeldingException.class, () ->
                inhoudingsplichtigeOrchestration.collectInhoudingsplichtigeUsingNummerInhoudingsplichtige(configuratieKey, nrIhp));

        String actualMessage = exception.getFoutmelding().getMessage();
        String foutCode = exception.getFoutmelding().getCode();
        String soort = exception.getFoutmelding().getSoort();

        assertThat(actualMessage, equalToIgnoringCase("Inhoudingsplichtige niet gevonden in het handelsregister of de werkgeversadministratie"));
        assertThat(foutCode, equalToIgnoringCase("071"));
        assertThat(soort, equalToIgnoringCase("F"));
    }
}
