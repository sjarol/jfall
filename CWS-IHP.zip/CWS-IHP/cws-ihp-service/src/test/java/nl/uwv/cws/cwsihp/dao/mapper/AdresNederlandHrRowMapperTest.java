package nl.uwv.cws.cwsihp.dao.mapper;

import nl.uwv.cws.cwsihp.model.hr.AdresNederlandHr;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.Mockito.when;

@TestInstance(Lifecycle.PER_CLASS)
@ExtendWith(MockitoExtension.class)
public class AdresNederlandHrRowMapperTest {

    @InjectMocks
    private AdresNederlandHrRowMapper adresNederlandHrRowMapper;

    @Mock
    private ResultSet resultSet;

    @BeforeEach
    public void setup() throws SQLException {
        when(resultSet.getObject("CD_DATUM_AANVANG_CGM")).thenReturn(1);
        when(resultSet.getObject("CD_DATUM_EINDE_CGM")).thenReturn(1);
        when(resultSet.getObject("IND_AFGESCHERMD_ADRES_CGM")).thenReturn(1);
    }

    @Test
    @DisplayName("Should successfully map fields for Postbusadres when StatusAdres is A")
    public void testMapPostbusAdresStatusAdresAuto() throws SQLException {
        when(resultSet.getString("CODE_ADRESROL_CGM")).thenReturn("C");
        when(resultSet.getDate("DATUM_AANVANG_CGM")).thenReturn(Date.valueOf(LocalDate.of(2020,1,1)));
        when(resultSet.getInt("CD_DATUM_AANVANG_CGM")).thenReturn(1);
        when(resultSet.getDate("DATUM_EINDE_CGM")).thenReturn(Date.valueOf(LocalDate.of(2020,1,31)));
        when(resultSet.getInt("CD_DATUM_EINDE_CGM")).thenReturn(2);
        when(resultSet.getInt("IND_AFGESCHERMD_ADRES_CGM")).thenReturn(1);

        when(resultSet.getObject("POSTBUSNUMMER")).thenReturn(1);
        when(resultSet.getInt("POSTBUSNUMMER")).thenReturn(123);
        when(resultSet.getString("STATUS_ADRES")).thenReturn("A");
        when(resultSet.getString("POSTCODE")).thenReturn("Postcode");
        when(resultSet.getString("WOONPLAATSNAAM_CGM")).thenReturn("WoonplaatsCgm");

        List<String> attributen = Arrays.asList("CODE_ADRESROL_CGM", "DATUM_AANVANG_CGM", "CD_DATUM_AANVANG_CGM", "DATUM_EINDE_CGM", "CD_DATUM_EINDE_CGM"
                , "IND_AFGESCHERMD_ADRES_CGM", "POSTBUS_POSTCODE", "POSTBUS_WOONPLAATSNAAM_CGM", "CODE_AAND_BIJ_HUISNUMMER_CGM", "POSTBUSNUMMER");

        AdresNederlandHr adresNederlandHr = adresNederlandHrRowMapper.mapRow(resultSet, attributen);
        assertThat(adresNederlandHr, is(notNullValue()));
        assertThat(adresNederlandHr.getCodeAdresrol(), is(equalTo("C")));
        assertThat(adresNederlandHr.getDatumAanvangAdreshouding(), is(Date.valueOf(LocalDate.of(2020,1,1))));
        assertThat(adresNederlandHr.getCodeFictieveDatumAanvang(), is(equalTo(1)));
        assertThat(adresNederlandHr.getDatumEindeAdreshouding(), is(Date.valueOf(LocalDate.of(2020,1,31))));
        assertThat(adresNederlandHr.getCodeFictieveDatumEinde(), is(equalTo(2)));

        assertThat(adresNederlandHr.getPostbusadresHr().getPostcode(), is(equalTo("Postcode")));
        assertThat(adresNederlandHr.getPostbusadresHr().getWoonplaatsnaam(), is(equalTo("WoonplaatsCgm")));
        assertThat(adresNederlandHr.getPostbusadresHr().getPostbusnummer(), is(equalTo(123)));
    }

    @Test
    @DisplayName("Should successfully map fields for Straat AdresNederland when StatusAdres is N")
    public void testMapRowStraatAdresStatusAdresHandmatig() throws SQLException {
        when(resultSet.getObject("HUISNUMMER")).thenReturn(1);
        when(resultSet.getString("CODE_ADRESROL_CGM")).thenReturn("C");
        when(resultSet.getDate("DATUM_AANVANG_CGM")).thenReturn(Date.valueOf(LocalDate.of(2020,1,1)));
        when(resultSet.getInt("CD_DATUM_AANVANG_CGM")).thenReturn(1);
        when(resultSet.getDate("DATUM_EINDE_CGM")).thenReturn(Date.valueOf(LocalDate.of(2020,1,31)));
        when(resultSet.getInt("CD_DATUM_EINDE_CGM")).thenReturn(2);
        when(resultSet.getInt("IND_AFGESCHERMD_ADRES_CGM")).thenReturn(1);

        when(resultSet.getObject("POSTBUSNUMMER")).thenReturn(null);
        when(resultSet.getString("STATUS_ADRES")).thenReturn("N");
        when(resultSet.getString("POSTCODE")).thenReturn("Postcode");
        when(resultSet.getString("WOONPLAATSNAAM_CGM")).thenReturn("WoonplaatsCgm");
        when(resultSet.getString("PLAATS")).thenReturn("Plaats");
        when(resultSet.getString("STRAATNAAM_CGM")).thenReturn("Straatnaam");
        when(resultSet.getInt("HUISNUMMER")).thenReturn(1);
        when(resultSet.getString("HUISLETTER")).thenReturn("Huisletter");
        when(resultSet.getString("HUISNUMMER_TOEVOEGING_CGM")).thenReturn("HuisnummerToevoegingCgm");
        when(resultSet.getString("HUISNUMMER_TOEVOEGING")).thenReturn("HuisnummerToevoeging");
        when(resultSet.getString("CODE_AAND_BIJ_HUISNUMMER_CGM")).thenReturn("CodeAanduiding");
        when(resultSet.getString("STRAATNAAM")).thenReturn("NaamOpenbareRuimte");

        List<String> attributen = Arrays.asList("CODE_ADRESROL_CGM", "DATUM_AANVANG_CGM", "CD_DATUM_AANVANG_CGM", "DATUM_EINDE_CGM", "CD_DATUM_EINDE_CGM"
                , "IND_AFGESCHERMD_ADRES_CGM", "POSTCODE", "WOONPLAATSNAAM_CGM", "STRAATNAAM_CGM", "HUISNUMMER"
                , "HUISLETTER", "HUISNUMMER_TOEVOEGING_CGM", "CODE_AAND_BIJ_HUISNUMMER_CGM", "STRAATNAAM");

        AdresNederlandHr adresNederlandHr = adresNederlandHrRowMapper.mapRow(resultSet, attributen);
        assertThat(adresNederlandHr, is(notNullValue()));
        assertThat(adresNederlandHr.getCodeAdresrol(), is(equalTo("C")));
        assertThat(adresNederlandHr.getDatumAanvangAdreshouding(), is(Date.valueOf(LocalDate.of(2020,1,1))));
        assertThat(adresNederlandHr.getCodeFictieveDatumAanvang(), is(equalTo(1)));
        assertThat(adresNederlandHr.getDatumEindeAdreshouding(), is(Date.valueOf(LocalDate.of(2020,1,31))));
        assertThat(adresNederlandHr.getCodeFictieveDatumEinde(), is(equalTo(2)));

        assertThat(adresNederlandHr.getStraatadresHr().getPostcode(), is(equalTo("Postcode")));
        assertThat(adresNederlandHr.getStraatadresHr().getWoonplaatsnaam(), is(equalTo("Plaats")));
        assertThat(adresNederlandHr.getStraatadresHr().getStraatnaam(), is(equalTo("NaamOpenbareRuimte")));
        assertThat(adresNederlandHr.getStraatadresHr().getHuisnummer(), is(equalTo(1)));
        assertThat(adresNederlandHr.getStraatadresHr().getHuisletter(), is(equalTo("Huisletter")));
        assertThat(adresNederlandHr.getStraatadresHr().getHuisnummertoevoeging(), is(equalTo("HuisnummerToevoeging")));
        assertThat(adresNederlandHr.getStraatadresHr().getCodeAanduidingBijHuisnummer(), is(equalTo("CodeAanduiding")));
        assertThat(adresNederlandHr.getStraatadresHr().getNaamOpenbareRuimte(), is(equalTo("NaamOpenbareRuimte")));
    }
}
