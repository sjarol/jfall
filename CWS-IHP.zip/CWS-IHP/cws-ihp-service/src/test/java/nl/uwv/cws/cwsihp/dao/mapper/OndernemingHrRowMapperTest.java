package nl.uwv.cws.cwsihp.dao.mapper;

import nl.uwv.cws.cwsihp.model.hr.OndernemingHr;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.Mockito.when;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@ExtendWith(MockitoExtension.class)
public class OndernemingHrRowMapperTest {

    @InjectMocks
    private OndernemingHrRowMapper ondernemingHrRowMapper;

    @Mock
    private ResultSet resultSet;

    @BeforeEach
    public void setup() throws SQLException {
        when(resultSet.getObject("CD_DATUM_AANVANG_CGM")).thenReturn(1);
        when(resultSet.getObject("CD_DATUM_EINDE_CGM")).thenReturn(1);
    }

    @Test
    @DisplayName("Should successfully map fields for OndernemingHr")
    public void testMapRow() throws SQLException {
        when(resultSet.getLong("KVK_NUMMER")).thenReturn(123456789L);
        when(resultSet.getDate("DATUM_AANVANG_CGM")).thenReturn(Date.valueOf(LocalDate.of(2020,1,1)));
        when(resultSet.getInt("CD_DATUM_AANVANG_CGM")).thenReturn(1);
        when(resultSet.getDate("DATUM_EINDE_CGM")).thenReturn(Date.valueOf(LocalDate.of(2020,1,31)));
        when(resultSet.getInt("CD_DATUM_EINDE_CGM")).thenReturn(2);

        List<String> attributen = Arrays.asList("KVK_NUMMER", "DATUM_AANVANG_CGM",
                "CD_DATUM_AANVANG_CGM", "DATUM_EINDE_CGM", "CD_DATUM_EINDE_CGM");

        OndernemingHr ondernemingHr = ondernemingHrRowMapper.mapRow(resultSet, attributen);
        assertThat(ondernemingHr, is(notNullValue()));
        assertThat(ondernemingHr.getKvkNummer(), is(equalTo("123456789")));
        assertThat(ondernemingHr.isConfigurationIncludesKvkNummer(), is(true));
        assertThat(ondernemingHr.getDatumAanvangOnderneming(), is(Date.valueOf(LocalDate.of(2020,1,1))));
        assertThat(ondernemingHr.getCodeFictieveDatumAanvang(), is(equalTo(1)));
        assertThat(ondernemingHr.getDatumEindeOnderneming(), is(Date.valueOf(LocalDate.of(2020,1,31))));
        assertThat(ondernemingHr.getCodeFictieveDatumEinde(), is(equalTo(2)));
    }
}
