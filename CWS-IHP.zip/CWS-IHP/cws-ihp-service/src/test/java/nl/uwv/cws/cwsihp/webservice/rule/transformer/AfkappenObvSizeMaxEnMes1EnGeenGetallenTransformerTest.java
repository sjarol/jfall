package nl.uwv.cws.cwsihp.webservice.rule.transformer;

import nl.uwv.cws.common.model.rule.AttributeRuleProperties;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static nl.uwv.cws.cwsihp.model.rule.CwsIhpAttributeRule.AFKAPPEN_OBV_SIZE_MAX_EN_MES1_EN_GEEN_GETALLEN;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

public class AfkappenObvSizeMaxEnMes1EnGeenGetallenTransformerTest {

    private AfkappenObvSizeMaxEnMes1EnGeenGetallenTransformer afkappenObvSizeMaxEnMes1EnGeenGetallenTransformer;
    private AttributeRuleProperties attributeRuleProperties;

    @BeforeEach
    public void setup() {
        afkappenObvSizeMaxEnMes1EnGeenGetallenTransformer = new AfkappenObvSizeMaxEnMes1EnGeenGetallenTransformer();
        attributeRuleProperties = new AttributeRuleProperties();
        attributeRuleProperties.setSizeMax(14);
    }

    @Test
    @DisplayName("Should use correct rule type")
    public void givenValueShouldUseCorrectRuletype() {
        assertThat(afkappenObvSizeMaxEnMes1EnGeenGetallenTransformer.getTransformRule(), is(AFKAPPEN_OBV_SIZE_MAX_EN_MES1_EN_GEEN_GETALLEN));
    }

    @Test
    @DisplayName("Should replace non MES-1 and digits with ?")
    public void givenValueShouldApplyMes1() {
        String originalValue = "vąluƔNoƏMes123";
        String transformedValue = afkappenObvSizeMaxEnMes1EnGeenGetallenTransformer.transform(originalValue, attributeRuleProperties);
        assertThat(transformedValue, is("vąlu?No?Mes???"));
    }

    @Test
    @DisplayName("Should not replace")
    public void givenValueNotShouldApply() {
        String originalValue = "valueNotMes";
        String transformedValue = afkappenObvSizeMaxEnMes1EnGeenGetallenTransformer.transform(originalValue, attributeRuleProperties);
        assertThat(transformedValue, is("valueNotMes"));
    }

    @Test
    @DisplayName("Should return empty")
    public void givenValueShouldReturnEmpty() {
        String originalValue = "";
        String transformedValue = afkappenObvSizeMaxEnMes1EnGeenGetallenTransformer.transform(originalValue, attributeRuleProperties);
        assertThat(transformedValue, is(""));
    }
}
