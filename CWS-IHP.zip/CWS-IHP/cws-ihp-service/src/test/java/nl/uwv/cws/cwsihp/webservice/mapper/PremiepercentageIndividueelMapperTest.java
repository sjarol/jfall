package nl.uwv.cws.cwsihp.webservice.mapper;

import nl.uwv.cws.cwsihp.model.wg.PremiepercentageIndividueelWg;
import nl.uwv.cws.common.webservice.rule.CwsRuleExecutor;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
public class PremiepercentageIndividueelMapperTest {

    @InjectMocks
    private PremiepercentageIndividueelMapper premiepercentageIndividueelMapper;

    @Mock
    private CwsRuleExecutor ruleExecutor;

    @Captor
    private ArgumentCaptor<String> wgFieldCaptor;

    @Captor
    private ArgumentCaptor<String> xsdFieldCaptor;

    @Test
    @DisplayName("Given PremiepercentageIndividueelWg test mapping fields to JaxB is successful")
    public void testMapToJaxbPremiepercentageIndividueel() {
        PremiepercentageIndividueelWg premiepercentageIndividueelWg = createPremiepercentageIndividueelWg();
        premiepercentageIndividueelMapper.mapToJaxbPremiepercentageIndividueel(premiepercentageIndividueelWg);

        verify(ruleExecutor, times(4)).setTransformedValue(any(Object.class), xsdFieldCaptor.capture(), wgFieldCaptor.capture());
        List<Object> wgFieldValues = Arrays.asList("code premiepercentageIndividueel", new BigDecimal("-50.95"),"20210601", "20231201");
        List<Object> xsdFieldValues = Arrays.asList("cdSzProduct", "perc", "datBPrpercIndividueel", "datEPrpercIndividueel");
        assertArrayEquals(wgFieldValues.toArray(), wgFieldCaptor.getAllValues().toArray());
        assertEquals(xsdFieldValues, xsdFieldCaptor.getAllValues());
    }

    private PremiepercentageIndividueelWg createPremiepercentageIndividueelWg() {
        return PremiepercentageIndividueelWg.builder()
                .codeSzProduct("code premiepercentageIndividueel")
                .percentage(-50.95)
                .datumAanvangPremiepercentageIndividueel(20210601L)
                .datumEindePremiepercentageIndividueel(20231201L)
                .build();
    }
}
