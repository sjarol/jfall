package nl.uwv.cws.cwsihp.model.configuratie;

import nl.uwv.cws.common.model.configuratie.Configuratie;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.Date;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalToIgnoringCase;

public class CwsIhpConfiguratieTest {

    CwsIhpConfiguratie cwsIhpConfiguratie;

    @Test
    @DisplayName("Should map right fields to right attributes")
    public void testDeepCopy(){
        Configuratie configuratie = new Configuratie();
        configuratie.setCconId(1L);
        configuratie.setContractId(2L);
        configuratie.setContractStartDate(3L);
        configuratie.setNaam("naam");
        configuratie.setVersion(1L);
        configuratie.setStatus("concept");
        configuratie.setStartDate(20220701L);
        configuratie.setEndDate(20220702L);
        configuratie.setStartTransactionTimestamp(new Date());
        configuratie.setEndTransactionTimestamp(new Date());

        CwsIhpConfiguratie cwsIhpConfiguratie = CwsIhpConfiguratie.deepCopy(configuratie);

        assertThat(cwsIhpConfiguratie.getCconId(), is(1L));
        assertThat(cwsIhpConfiguratie.getContractId(), is(2L));
        assertThat(cwsIhpConfiguratie.getContractStartDate(), is(3L));
        assertThat(cwsIhpConfiguratie.getNaam(), equalToIgnoringCase("naam"));
        assertThat(cwsIhpConfiguratie.getVersion(), is(1L));
        assertThat(cwsIhpConfiguratie.getStatus(), equalToIgnoringCase("concept"));
        assertThat(cwsIhpConfiguratie.getStartDate(), is(20220701L));
        assertThat(cwsIhpConfiguratie.getEndDate(), is(20220702L));
        assertThat(cwsIhpConfiguratie.getStartTransactionTimestamp(), is(notNullValue()));
    }
}
