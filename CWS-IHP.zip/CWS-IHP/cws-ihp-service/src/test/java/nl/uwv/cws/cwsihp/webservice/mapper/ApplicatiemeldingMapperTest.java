package nl.uwv.cws.cwsihp.webservice.mapper;

import nl.uwv.cws.common.model.Foutmelding;
import nl.uwv.cws.common.webservice.rule.CwsRuleExecutor;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0007.CwsInhoudingsplichtigeResponse.Applicatiemelding;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
public class ApplicatiemeldingMapperTest {

    @InjectMocks
    private ApplicatiemeldingMapper applicatiemeldingMapper;

    @Mock
    private CwsRuleExecutor ruleExecutor;

    @Captor
    private ArgumentCaptor<String> gbaFieldCaptor;

    @Captor
    private ArgumentCaptor<String> xsdFieldCaptor;

    @Test
    public void given_mapToJaxbApplicatieMelding_verifyTransformSetsCorrectXsdField() {
        applicatiemeldingMapper.mapToJaxbApplicatieMelding(createFoutmelding());

        verify(ruleExecutor, times(3)).setTransformedValue(any(Applicatiemelding.class), xsdFieldCaptor.capture(), gbaFieldCaptor.capture());
        List<String> hrFieldValues = Arrays.asList("F","003","somethings is wrong");
        List<String> xsdFieldValues = Arrays.asList("cdSrtApplicatiemelding", "cdApplicatiemelding", "toelApplicatiemelding");

        assertArrayEquals(hrFieldValues.toArray(), gbaFieldCaptor.getAllValues().toArray());
        assertEquals(xsdFieldValues, xsdFieldCaptor.getAllValues());
    }

    private Foutmelding createFoutmelding() {
        return new Foutmelding() {

            @Override
            public String getSoort() {
                return "F";
            }

            @Override
            public String getCode() {
                return "003";
            }

            @Override
            public String getMessage() {
                return "somethings is wrong";
            }
        };
    }
}
