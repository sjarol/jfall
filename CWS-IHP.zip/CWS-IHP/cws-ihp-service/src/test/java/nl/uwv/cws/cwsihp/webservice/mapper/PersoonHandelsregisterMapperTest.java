package nl.uwv.cws.cwsihp.webservice.mapper;

import nl.uwv.cws.cwsihp.model.hr.PersoonHandelsregisterHr;
import nl.uwv.cws.common.webservice.rule.CwsRuleExecutor;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0007.CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.PersoonHandelsregister;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Date;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
public class PersoonHandelsregisterMapperTest {

    @InjectMocks
    PersoonHandelsregisterMapper persoonHandelsregisterMapper;

    @Mock
    private CwsRuleExecutor ruleExecutor;

    @Captor
    private ArgumentCaptor<Object> ihpFieldCaptor;

    @Captor
    private ArgumentCaptor<String> xsdFieldCaptor;

    @Test
    @DisplayName("Given PersoonHandelsregisterHr test mapping fields to JaxB is successful")
    public void testMapToJaxbPersoonHandelsregister() {
        PersoonHandelsregisterHr persoonHandelsregisterHr = createPersoonHandelsregisterHr();
        persoonHandelsregisterMapper.mapToJaxbPersoonHandelsregister(persoonHandelsregisterHr);

        verify(ruleExecutor, times(6)).setTransformedValue(any(PersoonHandelsregister.class), xsdFieldCaptor.capture(), ihpFieldCaptor.capture());
        List<String> hrFieldValues = Arrays.asList( "20180201","1", "20190201", "2", "NaamPersoonHr", "VolledigeNaamPersoonHr");
        List<String> xsdFieldValues = Arrays.asList("datBPersoonHandelsregister", "cdFictieveDatB", "datEPersoonHandelsregister", "cdFictieveDatE", "naamPersoonHandelsregister", "volledigeNmPersHandelsregister");

        assertArrayEquals(hrFieldValues.toArray(), ihpFieldCaptor.getAllValues().toArray());
        assertEquals(xsdFieldValues, xsdFieldCaptor.getAllValues());
    }

    @Test
    @DisplayName("Given PersoonHandelsregisterHr test mapping fields to JaxB is successful")
    public void testMapToJaxbPersoonHandelsregisterWithoutDates() {
        PersoonHandelsregisterHr persoonHandelsregisterHr = createPersoonHandelsregisterHrWithoutDates();
        persoonHandelsregisterMapper.mapToJaxbPersoonHandelsregister(persoonHandelsregisterHr);

        verify(ruleExecutor, times(6)).setTransformedValue(any(PersoonHandelsregister.class), xsdFieldCaptor.capture(), ihpFieldCaptor.capture());
        List<String> hrFieldValues = Arrays.asList( null,null, null, null, "NaamPersoonHr", "VolledigeNaamPersoonHr");
        List<String> xsdFieldValues = Arrays.asList("datBPersoonHandelsregister", "cdFictieveDatB", "datEPersoonHandelsregister", "cdFictieveDatE", "naamPersoonHandelsregister", "volledigeNmPersHandelsregister");

        assertArrayEquals(hrFieldValues.toArray(), ihpFieldCaptor.getAllValues().toArray());
        assertEquals(xsdFieldValues, xsdFieldCaptor.getAllValues());
    }

    private PersoonHandelsregisterHr createPersoonHandelsregisterHr() {
        return PersoonHandelsregisterHr.builder()
                .datumAanvangPersoonHandelsregister(Date.valueOf(LocalDate.of(2018,2,1)))
                .codeFictieveDatumAanvang(1)
                .datumEindePersoonHandelsregister(Date.valueOf(LocalDate.of(2019,2,1)))
                .codeFictieveDatumEinde(2)
                .naamPersoonHandelsregister("NaamPersoonHr")
                .volledigeNaamPersoonHandelsregister("VolledigeNaamPersoonHr")
                .build();
    }

    private PersoonHandelsregisterHr createPersoonHandelsregisterHrWithoutDates() {
        return PersoonHandelsregisterHr.builder()
                .datumAanvangPersoonHandelsregister(null)
                .codeFictieveDatumAanvang(1)
                .datumEindePersoonHandelsregister(null)
                .codeFictieveDatumEinde(2)
                .naamPersoonHandelsregister("NaamPersoonHr")
                .volledigeNaamPersoonHandelsregister("VolledigeNaamPersoonHr")
                .build();
    }
}
