package nl.uwv.cws.cwsihp.webservice.mapper;

import nl.uwv.cws.cwsihp.model.hr.HandelsnaamHr;
import nl.uwv.cws.common.webservice.rule.CwsRuleExecutor;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0007.CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigInteger;
import java.sql.Date;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
public class HandelsnaamMapperTest {

    @InjectMocks
    private HandelsnaamMapper handelsnaamMapper;

    @Mock
    private CwsRuleExecutor ruleExecutor;

    @Captor
    private ArgumentCaptor<Object> ihpFieldCaptor;

    @Captor
    private ArgumentCaptor<String> xsdFieldCaptor;

    @Test
    @DisplayName("Given HandelsnaamHr test mapping fields to Handelsnaam VestigingHandelsregister JaxB is successful")
    public void testMapToJaxbHandelsnaamVestigingHandelsregister() {
        HandelsnaamHr handelsnaamHr = createHandelsnaamHr();
        handelsnaamMapper.mapToJaxbHandelsnaamVestigingHandelsregister(handelsnaamHr);

        verify(ruleExecutor, times(6)).setTransformedValue(any(VestigingHandelsregister.Handelsnaam.class), xsdFieldCaptor.capture(), ihpFieldCaptor.capture());
        List<Object> hrFieldValues = Arrays.asList("naamHandelsnaam", BigInteger.valueOf(0), "20200101","1", "20200131", "2");
        List<String> xsdFieldValues = Arrays.asList("handelsnaam", "volgordeHandelsnaam", "datBHandelsnaam", "cdFictieveDatB", "datEHandelsnaam", "cdFictieveDatE");
        assertArrayEquals(hrFieldValues.toArray(), ihpFieldCaptor.getAllValues().toArray());
        assertEquals(xsdFieldValues, xsdFieldCaptor.getAllValues());
    }

    @Test
    @DisplayName("Given HandelsnaamHr WithoutDates test mapping fields to Handelsnaam VestigingHandelsregister JaxB is successful")
    public void testMapToJaxbHandelsnaamVestigingHandelsregisterWithoutDates() {
        HandelsnaamHr handelsnaamHr = createHandelsnaamHrWithoutDates();
        handelsnaamMapper.mapToJaxbHandelsnaamVestigingHandelsregister(handelsnaamHr);

        verify(ruleExecutor, times(6)).setTransformedValue(any(VestigingHandelsregister.Handelsnaam.class), xsdFieldCaptor.capture(), ihpFieldCaptor.capture());
        List<Object> hrFieldValues = Arrays.asList("naamHandelsnaam", BigInteger.valueOf(0), null,null, null, null);
        List<String> xsdFieldValues = Arrays.asList("handelsnaam", "volgordeHandelsnaam", "datBHandelsnaam", "cdFictieveDatB", "datEHandelsnaam", "cdFictieveDatE");
        assertArrayEquals(hrFieldValues.toArray(), ihpFieldCaptor.getAllValues().toArray());
        assertEquals(xsdFieldValues, xsdFieldCaptor.getAllValues());
    }

    @Test
    @DisplayName("Given HandelsnaamHr test mapping fields to Handelsnaam Onderneming VestigingHandelsregister JaxB is successful")
    public void testMapToJaxbHandelsnaamOndernemingVestigingHandelsregister() {
        HandelsnaamHr handelsnaamHr = createHandelsnaamHr();
        handelsnaamMapper.mapToJaxbHandelsnaamOnderneming(handelsnaamHr);

        verify(ruleExecutor, times(6)).setTransformedValue(any(VestigingHandelsregister.Onderneming.Handelsnaam.class), xsdFieldCaptor.capture(), ihpFieldCaptor.capture());

        List<Object> hrFieldValues = Arrays.asList("naamHandelsnaam", BigInteger.valueOf(0), "20200101","1", "20200131", "2");
        List<String> xsdFieldValues = Arrays.asList("handelsnaam", "volgordeHandelsnaam", "datBHandelsnaam", "cdFictieveDatB", "datEHandelsnaam", "cdFictieveDatE");
        assertArrayEquals(hrFieldValues.toArray(), ihpFieldCaptor.getAllValues().toArray());
        assertEquals(xsdFieldValues, xsdFieldCaptor.getAllValues());
    }

    private HandelsnaamHr createHandelsnaamHr() {
        return HandelsnaamHr.builder()
                .naam("naamHandelsnaam")
                .volgorde(0)
                .datumAanvangHandelsnaam(Date.valueOf(LocalDate.of(2020,1,1)))
                .codeFictieveDatumAanvang(1)
                .datumEindeHandelsnaam(Date.valueOf(LocalDate.of(2020,1,31)))
                .codeFictieveDatumEinde(2)
                .build();
    }

    private HandelsnaamHr createHandelsnaamHrWithoutDates() {
        return HandelsnaamHr.builder()
                .naam("naamHandelsnaam")
                .volgorde(0)
                .datumAanvangHandelsnaam(null)
                .codeFictieveDatumAanvang(1)
                .datumEindeHandelsnaam(null)
                .codeFictieveDatumEinde(2)
                .build();
    }
}
