package nl.uwv.cws.cwsihp.dao.mapper;

import nl.uwv.cws.cwsihp.model.wg.AdresNederlandWg;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.Mockito.when;

@TestInstance(Lifecycle.PER_CLASS)
@ExtendWith(MockitoExtension.class)
public class AdresNederlandWgRowMapperTest {

    @InjectMocks
    private AdresNederlandWgRowMapper adresNederlandWgRowMapper;

    @Mock
    private ResultSet resultSet;

    @Test
    @DisplayName("Should successfully map fields for PostbusadresNederland")
    public void testMapPostbusAdresNederland() throws SQLException {
        when(resultSet.getString("ADRESROL")).thenReturn("C");
        when(resultSet.getObject("DATAANV")).thenReturn(1);
        when(resultSet.getLong("DATAANV")).thenReturn(20210101L);
        when(resultSet.getObject("DATEIND")).thenReturn(1);
        when(resultSet.getLong("DATEIND")).thenReturn(20210201L);
        when(resultSet.getString("ADRESTYPEK33")).thenReturn("PAN");

        when(resultSet.getString("POSTCODE")).thenReturn("Postcode");
        when(resultSet.getString("WOONPLAATS")).thenReturn("Woonplaats");
        when(resultSet.getObject("POSTBUSNR")).thenReturn(1);
        when(resultSet.getInt("POSTBUSNR")).thenReturn(12345);

        List<String> attributen = Arrays.asList("ADRESROL", "DATAANV", "DATEIND", "POSTBUS_POSTCODE","POSTBUS_WOONPLAATS","POSTBUSNR");

        AdresNederlandWg adresNederlandWg = adresNederlandWgRowMapper.mapRow(resultSet, attributen);
        assertThat(adresNederlandWg, is(notNullValue()));
        assertThat(adresNederlandWg.getCodeAdresrol(), is(equalTo("C")));
        assertThat(adresNederlandWg.getDatumAanvangAdreshouding(), is(equalTo(20210101L)));
        assertThat(adresNederlandWg.getDatumEindeAdreshouding(), is(equalTo(20210131L)));

        assertThat(adresNederlandWg.getPostbusadresWg().getPostcode(), is(equalTo("Postcode")));
        assertThat(adresNederlandWg.getPostbusadresWg().getWoonplaatsnaam(), is(equalTo("Woonplaats")));
        assertThat(adresNederlandWg.getPostbusadresWg().getPostbusnummer(), is(equalTo(12345)));
    }

    @Test
    @DisplayName("Should successfully map fields for StraatadresNederland")
    public void testMapRowStraatAdresNederland() throws SQLException {
        when(resultSet.getString("ADRESROL")).thenReturn("C");
        when(resultSet.getObject("DATAANV")).thenReturn(1);
        when(resultSet.getLong("DATAANV")).thenReturn(20210101L);
        when(resultSet.getObject("DATEIND")).thenReturn(1);
        when(resultSet.getLong("DATEIND")).thenReturn(20210201L);
        when(resultSet.getString("ADRESTYPEK33")).thenReturn("SAN");

        when(resultSet.getString("POSTCODE")).thenReturn("Postcode");
        when(resultSet.getString("WOONPLAATS")).thenReturn("Woonplaats");
        when(resultSet.getString("GEMEENTENAAM")).thenReturn("Gemeentenaam");
        when(resultSet.getString("STRAATNAAM")).thenReturn("Straatnaam");
        when(resultSet.getObject("HUISNR")).thenReturn(1);
        when(resultSet.getInt("HUISNR")).thenReturn(230);
        when(resultSet.getString("HUISNR_TOEV")).thenReturn("a");
        when(resultSet.getString("LOCATIE_OMSCH")).thenReturn("Locatieomschrijving");

        List<String> attributen = Arrays.asList("ADRESROL", "DATAANV", "DATEIND", "POSTCODE","WOONPLAATS","GEMEENTENAAM","STRAATNAAM","HUISNR","HUISNR_TOEV","LOCATIE_OMSCH");

        AdresNederlandWg adresNederlandWg = adresNederlandWgRowMapper.mapRow(resultSet, attributen);
        assertThat(adresNederlandWg, is(notNullValue()));
        assertThat(adresNederlandWg.getCodeAdresrol(), is(equalTo("C")));
        assertThat(adresNederlandWg.getDatumAanvangAdreshouding(), is(equalTo(20210101L)));
        assertThat(adresNederlandWg.getDatumEindeAdreshouding(), is(equalTo(20210131L)));

        assertThat(adresNederlandWg.getStraatadresWg().getPostcode(), is(equalTo("Postcode")));
        assertThat(adresNederlandWg.getStraatadresWg().getWoonplaatsnaam(), is(equalTo("Woonplaats")));
        assertThat(adresNederlandWg.getStraatadresWg().getGemeentenaam(), is(equalTo("Gemeentenaam")));
        assertThat(adresNederlandWg.getStraatadresWg().getStraatnaam(), is(equalTo("Straatnaam")));
        assertThat(adresNederlandWg.getStraatadresWg().getHuisnummer(), is(equalTo(230)));
        assertThat(adresNederlandWg.getStraatadresWg().getHuisnummerToevoeging(), is(equalTo("a")));
        assertThat(adresNederlandWg.getStraatadresWg().getLocatieomschrijving(), is(equalTo("Locatieomschrijving")));
    }
}
