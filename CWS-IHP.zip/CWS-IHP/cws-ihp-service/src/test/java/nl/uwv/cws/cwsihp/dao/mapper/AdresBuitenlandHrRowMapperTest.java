package nl.uwv.cws.cwsihp.dao.mapper;

import nl.uwv.cws.cwsihp.model.hr.AdresBuitenlandHr;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.Mockito.when;

@TestInstance(Lifecycle.PER_CLASS)
@ExtendWith(MockitoExtension.class)
public class AdresBuitenlandHrRowMapperTest {

    @InjectMocks
    private AdresBuitenlandHrRowMapper adresBuitenlandHrRowMapper;

    @Mock
    private ResultSet resultSet;

    @BeforeEach
    public void setup() throws SQLException {
        when(resultSet.getObject("CD_DATUM_AANVANG_CGM")).thenReturn(1);
        when(resultSet.getObject("CD_DATUM_EINDE_CGM")).thenReturn(1);
        when(resultSet.getObject("IND_AFGESCHERMD_ADRES_CGM")).thenReturn(1);
    }

    @Test
    @DisplayName("Should successfully map fields for PostbusadresBuitenland")
    public void testMapPostbusAdresStatusAdresAuto() throws SQLException {
        when(resultSet.getString("CODE_ADRESROL_CGM")).thenReturn("C");
        when(resultSet.getDate("DATUM_AANVANG_CGM")).thenReturn(Date.valueOf(LocalDate.of(2020,1,1)));
        when(resultSet.getInt("CD_DATUM_AANVANG_CGM")).thenReturn(1);
        when(resultSet.getDate("DATUM_EINDE_CGM")).thenReturn(Date.valueOf(LocalDate.of(2020,1,31)));
        when(resultSet.getInt("CD_DATUM_EINDE_CGM")).thenReturn(2);
        when(resultSet.getInt("IND_AFGESCHERMD_ADRES_CGM")).thenReturn(1);

        when(resultSet.getString("POSTBUSNUMMER_BUITENLAND_CGM")).thenReturn("12345");
        when(resultSet.getString("POSTCODEBUITENLAND_CGM")).thenReturn("PostcodeCgm");
        when(resultSet.getString("WOONPLAATSNAAMBUITENLAND_CGM")).thenReturn("WoonplaatsCgm");
        when(resultSet.getString("REGIONAAMBUITENLAND_CGM")).thenReturn("RegionaamCgm");
        when(resultSet.getObject("LANDCODE_GBA_CGM")).thenReturn(333);
        when(resultSet.getInt("LANDCODE_GBA_CGM")).thenReturn(333);
        when(resultSet.getString("LANDCODE_ISO_CGM")).thenReturn("NL");
        when(resultSet.getString("LANDSNAAM_CGM")).thenReturn("LandsnaamCgm");

        List<String> attributen = Arrays.asList("CODE_ADRESROL_CGM", "DATUM_AANVANG_CGM", "CD_DATUM_AANVANG_CGM", "DATUM_EINDE_CGM", "CD_DATUM_EINDE_CGM"
                , "IND_AFGESCHERMD_ADRES_CGM", "POSTBUS_POSTCODEBL_CGM", "POSTBUS_WOONPLAATSNAAMBL_CGM", "POSTBUSNUMMER_BUITENLAND_CGM"
                , "POSTBUS_REGIONAAMBL_CGM", "POSTBUS_LANDCODE_GBA_CGM", "POSTBUS_LANDCODE_ISO_CGM", "POSTBUS_LANDSNAAM_CGM");

        AdresBuitenlandHr adresBuitenlandHr = adresBuitenlandHrRowMapper.mapRow(resultSet, attributen);
        assertThat(adresBuitenlandHr, is(notNullValue()));
        assertThat(adresBuitenlandHr.getCodeAdresrol(), is(equalTo("C")));
        assertThat(adresBuitenlandHr.getDatumAanvangAdreshouding(), is(Date.valueOf(LocalDate.of(2020,1,1))));
        assertThat(adresBuitenlandHr.getCodeFictieveDatumAanvang(), is(equalTo(1)));
        assertThat(adresBuitenlandHr.getDatumEindeAdreshouding(), is(Date.valueOf(LocalDate.of(2020,1,31))));
        assertThat(adresBuitenlandHr.getCodeFictieveDatumEinde(), is(equalTo(2)));

        assertThat(adresBuitenlandHr.getPostbusadresHr().getPostcodeBuitenland(), is(equalTo("PostcodeCgm")));
        assertThat(adresBuitenlandHr.getPostbusadresHr().getWoonplaatsnaamBuitenland(), is(equalTo("WoonplaatsCgm")));
        assertThat(adresBuitenlandHr.getPostbusadresHr().getPostbusnummerBuitenland(), is(equalTo("12345")));
        assertThat(adresBuitenlandHr.getPostbusadresHr().getLandcodeGba(), is(equalTo(333)));
        assertThat(adresBuitenlandHr.getPostbusadresHr().getLandcodeIso(), is(equalTo("NL")));
        assertThat(adresBuitenlandHr.getPostbusadresHr().getLandsnaam(), is(equalTo("LandsnaamCgm")));
        assertThat(adresBuitenlandHr.getPostbusadresHr().getRegionaamBuitenland(), is(equalTo("RegionaamCgm")));
    }

    @Test
    @DisplayName("Should successfully map fields for StraatadresBuitenland")
    public void testMapRowStraatAdresStatusAdresHandmatig() throws SQLException {
        when(resultSet.getString("CODE_ADRESROL_CGM")).thenReturn("C");
        when(resultSet.getDate("DATUM_AANVANG_CGM")).thenReturn(Date.valueOf(LocalDate.of(2020,1,1)));
        when(resultSet.getInt("CD_DATUM_AANVANG_CGM")).thenReturn(1);
        when(resultSet.getDate("DATUM_EINDE_CGM")).thenReturn(Date.valueOf(LocalDate.of(2020,2,1)));
        when(resultSet.getInt("CD_DATUM_EINDE_CGM")).thenReturn(0);
        when(resultSet.getInt("IND_AFGESCHERMD_ADRES_CGM")).thenReturn(1);

        when(resultSet.getString("POSTBUSNUMMER_BUITENLAND_CGM")).thenReturn(null);
        when(resultSet.getString("POSTCODEBUITENLAND_CGM")).thenReturn("PostcodeCgm");
        when(resultSet.getString("WOONPLAATSNAAMBUITENLAND_CGM")).thenReturn("WoonplaatsCgm");
        when(resultSet.getString("STRAATNAAMBUITENLAND_CGM")).thenReturn("StraatnaamCgm");
        when(resultSet.getString("HUISNUMMERBUITENLAND_CGM")).thenReturn("230");
        when(resultSet.getString("LOCATIEOMSCHRIJVING_CGM")).thenReturn("LocatieomschrijvingCgm");
        when(resultSet.getString("REGIONAAMBUITENLAND_CGM")).thenReturn("RegionaamCgm");
        when(resultSet.getObject("LANDCODE_GBA_CGM")).thenReturn(1);
        when(resultSet.getInt("LANDCODE_GBA_CGM")).thenReturn(111);
        when(resultSet.getString("LANDCODE_ISO_CGM")).thenReturn("NL");
        when(resultSet.getString("LANDSNAAM_CGM")).thenReturn("LandsnaamCgm");

        List<String> attributen = Arrays.asList("CODE_ADRESROL_CGM", "DATUM_AANVANG_CGM", "CD_DATUM_AANVANG_CGM", "DATUM_EINDE_CGM", "CD_DATUM_EINDE_CGM"
                , "IND_AFGESCHERMD_ADRES_CGM", "POSTCODEBUITENLAND_CGM", "WOONPLAATSNAAMBUITENLAND_CGM", "STRAATNAAMBUITENLAND_CGM", "HUISNUMMERBUITENLAND_CGM"
                , "LOCATIEOMSCHRIJVING_CGM", "REGIONAAMBUITENLAND_CGM", "LANDCODE_GBA_CGM", "LANDCODE_ISO_CGM", "LANDSNAAM_CGM");

        AdresBuitenlandHr adresBuitenlandHr = adresBuitenlandHrRowMapper.mapRow(resultSet, attributen);
        assertThat(adresBuitenlandHr, is(notNullValue()));
        assertThat(adresBuitenlandHr.getCodeAdresrol(), is(equalTo("C")));
        assertThat(adresBuitenlandHr.getDatumAanvangAdreshouding(), is(Date.valueOf(LocalDate.of(2020,1,1))));
        assertThat(adresBuitenlandHr.getCodeFictieveDatumAanvang(), is(equalTo(1)));
        assertThat(adresBuitenlandHr.getDatumEindeAdreshouding(), is(Date.valueOf(LocalDate.of(2020,1,31))));
        assertThat(adresBuitenlandHr.getCodeFictieveDatumEinde(), is(equalTo(0)));

        assertThat(adresBuitenlandHr.getStraatadresHr().getPostcodeBuitenland(), is(equalTo("PostcodeCgm")));
        assertThat(adresBuitenlandHr.getStraatadresHr().getWoonplaatsnaamBuitenland(), is(equalTo("WoonplaatsCgm")));
        assertThat(adresBuitenlandHr.getStraatadresHr().getStraatnaamBuitenland(), is(equalTo("StraatnaamCgm")));
        assertThat(adresBuitenlandHr.getStraatadresHr().getHuisnummerBuitenland(), is(equalTo("230")));
        assertThat(adresBuitenlandHr.getStraatadresHr().getLocatieomschrijvingBuitenland(), is(equalTo("LocatieomschrijvingCgm")));
        assertThat(adresBuitenlandHr.getStraatadresHr().getLandcodeGba(), is(equalTo(111)));
        assertThat(adresBuitenlandHr.getStraatadresHr().getLandcodeIso(), is(equalTo("NL")));
        assertThat(adresBuitenlandHr.getStraatadresHr().getLandsnaam(), is(equalTo("LandsnaamCgm")));
        assertThat(adresBuitenlandHr.getStraatadresHr().getRegionaamBuitenland(), is(equalTo("RegionaamCgm")));
    }
}
