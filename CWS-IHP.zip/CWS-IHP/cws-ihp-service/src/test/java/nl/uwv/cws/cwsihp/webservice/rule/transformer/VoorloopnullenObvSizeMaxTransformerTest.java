package nl.uwv.cws.cwsihp.webservice.rule.transformer;

import nl.uwv.cws.common.model.rule.AttributeRuleProperties;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static nl.uwv.cws.cwsihp.model.rule.CwsIhpAttributeRule.VOORLOOPNULLEN_OBV_SIZE_MAX;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

public class VoorloopnullenObvSizeMaxTransformerTest {

    private VoorloopnullenObvSizeMaxTransformer voorloopnullenObvSizeMaxTransformer;
    private AttributeRuleProperties attributeRuleProperties;

    @BeforeEach
    public void setup() {
        voorloopnullenObvSizeMaxTransformer = new VoorloopnullenObvSizeMaxTransformer();
        attributeRuleProperties = new AttributeRuleProperties();
        attributeRuleProperties.setSizeMax(6);
    }

    @Test
    @DisplayName("Should use correct rule type")
    public void given_voorloopnullenObvSizeMaxTransformer_shouldUseCorrectType() {
        assertThat(voorloopnullenObvSizeMaxTransformer.getTransformRule(), is(VOORLOOPNULLEN_OBV_SIZE_MAX));
    }

    @Test
    @DisplayName("Should return transformed value when size is smaller than sizemax")
    public void given_valueNeedsLeftpad_shouldAddCorrectSizeLeftPad() {
        String originalValue = "5060";
        String transformedValue = voorloopnullenObvSizeMaxTransformer.transform(originalValue, attributeRuleProperties);
        assertThat(transformedValue, is("005060"));
    }

    @Test
    @DisplayName("Should return original value when size equals sizemax")
    public void given_valueDoesNotNeedsLeftpad_shouldNotAddLeftPad() {
        String originalValue = "005060";
        String transformedValue = voorloopnullenObvSizeMaxTransformer.transform(originalValue, attributeRuleProperties);
        assertThat(transformedValue, is("005060"));
    }

    @Test
    @DisplayName("Null should return empty")
    public void given_valueEmpty_shouldReturnEmpty() {
        String originalValue = "";
        String transformedValue = voorloopnullenObvSizeMaxTransformer.transform(originalValue, attributeRuleProperties);
        assertThat(transformedValue, is(nullValue()));
    }
}
