package nl.uwv.cws.cwsihp.webservice.rule.transformer;

import nl.uwv.cws.common.model.rule.AttributeRuleProperties;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static nl.uwv.cws.cwsihp.model.rule.CwsIhpAttributeRule.GEEN;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

public class GeenTransformerTest {


    private GeenTransformer geenTransformer;
    private AttributeRuleProperties attributeRuleProperties;

    @BeforeEach
    public void setup() {
        geenTransformer = new GeenTransformer();
        attributeRuleProperties = new AttributeRuleProperties();
    }

    @Test
    @DisplayName("Should use correct rule type")
    public void givenValueShouldUseCorrectRuletype() {
        assertThat(geenTransformer.getTransformRule(), is(GEEN));
    }

    @Test
    @DisplayName("Should return the original value")
    public void givenValueShouldShouldReturnNull() {
        String originalValue = "abc123";
        Object transformedValue = geenTransformer.transform(originalValue, attributeRuleProperties);
        assertThat(transformedValue, is("abc123"));
    }
}
