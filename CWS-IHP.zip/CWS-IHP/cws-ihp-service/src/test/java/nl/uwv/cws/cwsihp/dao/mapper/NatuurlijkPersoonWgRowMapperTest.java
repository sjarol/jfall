package nl.uwv.cws.cwsihp.dao.mapper;

import nl.uwv.cws.cwsihp.model.wg.NatuurlijkPersoonWg;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.Mockito.when;

@TestInstance(Lifecycle.PER_CLASS)
@ExtendWith(MockitoExtension.class)
public class NatuurlijkPersoonWgRowMapperTest {

    @InjectMocks
    private NatuurlijkPersoonWgRowMapper natuurlijkPersoonWgRowMapper;

    @Mock
    private ResultSet resultSet;

    @Test
    @DisplayName("Should successfully map fields for NatuurlijkPersoon")
    public void testMapNatuurlijkPersoon() throws SQLException {
        when(resultSet.getObject("BSN")).thenReturn(0);
        when(resultSet.getString("VOORLETTERS")).thenReturn("C");
        when(resultSet.getInt("BSN")).thenReturn(999999990);
        when(resultSet.getString("VOORNAMEN")).thenReturn("Voornamen");
        when(resultSet.getString("VOORVOEGSEL")).thenReturn("de");
        when(resultSet.getString("ACHTERNAAM")).thenReturn("Achternaam");
        when(resultSet.getObject("CD_AANDUIDING_NAAMGEBRUIK_CGM")).thenReturn(1);
        when(resultSet.getInt("CD_AANDUIDING_NAAMGEBRUIK_CGM")).thenReturn(1);
        when(resultSet.getObject("GEBOORTEDATUM_CGM")).thenReturn(1);
        when(resultSet.getInt("GEBOORTEDATUM_CGM")).thenReturn(19900101);
        when(resultSet.getString("GESLACHT")).thenReturn("M");
        when(resultSet.getString("VOORV_GESLACHTSNM_PARTNER")).thenReturn("van");
        when(resultSet.getString("GESLACHTSNAAMPARTNER")).thenReturn("AchternaamPartner");

        List<String> attributen = Arrays.asList("BSN", "VOORLETTERS", "VOORNAMEN", "VOORVOEGSEL", "ACHTERNAAM", "CD_AANDUIDING_NAAMGEBRUIK_CGM",
                "GEBOORTEDATUM_CGM", "GESLACHT", "VOORV_GESLACHTSNM_PARTNER", "GESLACHTSNAAMPARTNER");

        NatuurlijkPersoonWg natuurlijkPersoonWg = natuurlijkPersoonWgRowMapper.mapRow(resultSet, attributen);

        assertThat(natuurlijkPersoonWg, is(notNullValue()));
        assertThat(natuurlijkPersoonWg.getBurgerservicenummer(), is(equalTo(999999990)));
        assertThat(natuurlijkPersoonWg.getVoorletters(), is(equalTo("C")));
        assertThat(natuurlijkPersoonWg.getVoornamen(), is(equalTo("Voornamen")));
        assertThat(natuurlijkPersoonWg.getVoorvoegsel(), is(equalTo("de")));
        assertThat(natuurlijkPersoonWg.getAchternaam(), is(equalTo("Achternaam")));
        assertThat(natuurlijkPersoonWg.getCodeAanduidingNaamgebruik(), is(equalTo(1)));
        assertThat(natuurlijkPersoonWg.getGeboorteDatum(), is(equalTo(19900101)));
        assertThat(natuurlijkPersoonWg.getGeslacht(), is(equalTo("M")));
        assertThat(natuurlijkPersoonWg.getHuwelijkGeregistreerdPartnerIhp().getVoorvoegselGeslachtsnaamPartner(), is(equalTo("van")));
        assertThat(natuurlijkPersoonWg.getHuwelijkGeregistreerdPartnerIhp().getGeslachtsnaamPartner(), is(equalTo("AchternaamPartner")));
    }

    @Test
    @DisplayName("Should successfully map fields CodeFictief for NatuurlijkPersoon")
    public void testMapNatuurlijkPersoon_CodeFictief() throws SQLException {
        when(resultSet.getObject("GEBOORTEDATUM_CGM")).thenReturn(1);
        when(resultSet.getInt("GEBOORTEDATUM_CGM")).thenReturn(19900101);;

        List<String> attributen = Arrays.asList("GEBOORTEDATUM_CGM", "CD_GEBOORTEDATUM_CGM");

        NatuurlijkPersoonWg natuurlijkPersoonWg = natuurlijkPersoonWgRowMapper.mapRow(resultSet, attributen);

        assertThat(natuurlijkPersoonWg, is(notNullValue()));
        assertThat(natuurlijkPersoonWg.getGeboorteDatum(), is(equalTo(19900101)));
        assertThat(natuurlijkPersoonWg.getCodeFictieveGeboortedatum(), is(equalTo(0)));
    }

    @Test
    @DisplayName("Should successfully map fields CodeFictief for NatuurlijkPersoon")
    public void testMapNatuurlijkPersoon_CodeFictiefNull() throws SQLException {
        when(resultSet.getObject("GEBOORTEDATUM_CGM")).thenReturn(null);

        List<String> attributen = Arrays.asList("CD_GEBOORTEDATUM_CGM");

        NatuurlijkPersoonWg natuurlijkPersoonWg = natuurlijkPersoonWgRowMapper.mapRow(resultSet, attributen);

        assertThat(natuurlijkPersoonWg, is(notNullValue()));
        assertThat(natuurlijkPersoonWg.getCodeFictieveGeboortedatum(), is(nullValue()));
    }
}
