package nl.uwv.cws.cwsihp.service;

import nl.uwv.cws.cwsihp.dao.ihp.*;
import nl.uwv.cws.cwsihp.model.configuratie.CwsIhpConfiguratie;
import nl.uwv.cws.cwsihp.model.wg.*;
import nl.uwv.cws.cwsihp.service.wg.BaseWgService;
import nl.uwv.cws.cwsihp.service.wg.RechtsvormWgService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class BaseWgServiceTest {

    @InjectMocks
    private ConcreteBaseWgService baseWgService;

    @Mock
    protected PersoonWgDao persoonWgDao;

    @Mock
    protected NietNatuurlijkPersoonWgDao nietNatuurlijkPersoonWgDao;

    @Mock
    protected NatuurlijkPersoonWgDao natuurlijkPersoonWgDao;

    @Mock
    protected FaillissementSurseanceWgDao faillissementSurseanceWgDao;

    @Mock
    protected RechtsvormWgService rechtsvormWgService;

    @Mock
    protected GemoedsbezwaardheidWgDao gemoedsbezwaardheidWgDao;

    @Mock
    protected AdministratieveEenheidWgDao administratieveEenheidWgDao;

    @Mock
    protected SectorRisicogroepWgDao sectorRisicogroepWgDao;

    @Mock
    protected PremiepercentageIndividueelWgDao premiepercentageIndividueelWgDao;

    @Mock
    protected EigenRisicoDragerWgDao eigenRisicoDragerWgDao;

    @Mock
    protected AdresNederlandWgDao adresNederlandWgDao;

    @Mock
    protected AdresBuitenlandWgDao adresBuitenlandWgDao;

    @Mock
    protected AdresBuitenlandOngestructureerdWgDao adresBuitenlandOngestructureerdWgDao;

    @Mock
    protected VoortzettingsrelatieOpvolgerWgDao voortzettingsrelatieOpvolgerWgDao;

    @Mock
    protected VoortzettingsrelatieVoorgangerWgDao voortzettingsrelatieVoorgangerWgDao;

    @Mock
    protected AangifteFrequentieAdministratieveEenheidWgDao aangifteFrequentieAdministratieveEenheidWgDao;

    @Mock
    protected AansluitingsnummerBvWgDao aansluitingsnummerBvWgDao;

    @Test
    @DisplayName("Should call AdministratieveEenheid Members")
    public void testGetAdministratieveEenheidWgIfRequired(){
        final LocalDateTime beschouwingsmoment = LocalDateTime.of(2022,7,1,12,23);

        CwsIhpConfiguratie configuratie = mock(CwsIhpConfiguratie.class);
        when(configuratie.requiresSectorRisicogroep()).thenReturn(true);
        when(configuratie.requiresPremiepercentageIndividueel()).thenReturn(true);
        when(configuratie.requiresEigenRisicoDrager()).thenReturn(true);
        when(configuratie.requiresVoortzettingsrelatieOpvolger()).thenReturn(true);
        when(configuratie.requiresVoortzettingsrelatieVoorganger()).thenReturn(true);
        when(configuratie.requiresAangifteFrequentieAdministratieveEenheid()).thenReturn(true);
        when(configuratie.requiresAansluitingsnummerBv()).thenReturn(true);

        List<SectorRisicogroepWg> sectorRisicogroepWgList = new ArrayList<>();
        when(sectorRisicogroepWgDao.findSectorRisicogroep(123L, beschouwingsmoment, configuratie)).thenReturn(sectorRisicogroepWgList);

        List<PremiepercentageIndividueelWg> premiepercentageIndividueelWgList = new ArrayList<>();
        when(premiepercentageIndividueelWgDao.findPremiepercentageIndividueel(any(Long.class), any(LocalDateTime.class), any(CwsIhpConfiguratie.class))).thenReturn(premiepercentageIndividueelWgList);

        List<EigenRisicoDragerWg> eigenRisicoDragerWgList = new ArrayList<>();
        when(eigenRisicoDragerWgDao.findEigenRisicoDrager(any(Long.class), any(LocalDateTime.class), any(CwsIhpConfiguratie.class))).thenReturn(eigenRisicoDragerWgList);

        List<VoortzettingsrelatieOpvolgerWg> voortzettingsrelatieOpvolgerWgList = new ArrayList<>();
        when(voortzettingsrelatieOpvolgerWgDao.findVoortzettingsrelatieOpvolger(any(Long.class), any(LocalDateTime.class), any(CwsIhpConfiguratie.class))).thenReturn(voortzettingsrelatieOpvolgerWgList);

        List<VoortzettingsrelatieVoorgangerWg> voortzettingsrelatieVoorgangerWgList = new ArrayList<>();
        when(voortzettingsrelatieVoorgangerWgDao.findVoortzettingsrelatieVoorganger(any(Long.class), any(LocalDateTime.class), any(CwsIhpConfiguratie.class))).thenReturn(voortzettingsrelatieVoorgangerWgList);

        List<AangifteFrequentieAdministratieveEenheidWg> aangifteFrequentieAdministratieveEenheidWgList = new ArrayList<>();
        when(aangifteFrequentieAdministratieveEenheidWgDao.findAangifteFrequentieAdministratieveEenheid(any(Long.class), any(LocalDateTime.class), any(CwsIhpConfiguratie.class))).thenReturn(aangifteFrequentieAdministratieveEenheidWgList);

        List<AansluitingsnummerBvWg> aansluitingsnummerBvWgList = new ArrayList<>();
        when(aansluitingsnummerBvWgDao.findAansluitingsnummerBv(any(Long.class), any(LocalDateTime.class), any(CwsIhpConfiguratie.class))).thenReturn(aansluitingsnummerBvWgList);

        AdministratieveEenheidWg administratieveEenheidWg = AdministratieveEenheidWg.builder().aehId(123L).build();


        ReflectionTestUtils.invokeMethod(baseWgService, "findAndAttachAdministratieveEenheidMembers",
                administratieveEenheidWg, beschouwingsmoment, configuratie);

        assertThat(administratieveEenheidWg.getSectorRisicogroepList()).isNotNull();
        assertThat(administratieveEenheidWg.getPremiepercentageIndividueelList()).isNotNull();
        assertThat(administratieveEenheidWg.getEigenRisicoDragerList()).isNotNull();
        assertThat(administratieveEenheidWg.getVoortzettingsrelatieOpvolgerList()).isNotNull();
        assertThat(administratieveEenheidWg.getVoortzettingsrelatieVoorgangerList()).isNotNull();
        assertThat(administratieveEenheidWg.getAangiftefrequentieAdministratieveEenheidList()).isNotNull();
        assertThat(administratieveEenheidWg.getAansluitingsnummerBvList()).isNotNull();
    }

    @Test
    @DisplayName("Should call AdministratieveEenheid Members but not set Sector risico groep")
    public void testGetAdministratieveEenheidWgIfRequiredSectorRisicoGroep(){
        final LocalDateTime beschouwingsmoment = LocalDateTime.of(2022,7,1,12,23);

        CwsIhpConfiguratie configuratie = mock(CwsIhpConfiguratie.class);
        when(configuratie.requiresSectorRisicogroep()).thenReturn(false);

        AdministratieveEenheidWg administratieveEenheidWg = AdministratieveEenheidWg.builder().aehId(123L).build();


        ReflectionTestUtils.invokeMethod(baseWgService, "findAndAttachAdministratieveEenheidMembers",
                administratieveEenheidWg, beschouwingsmoment, configuratie);

        assertThat(administratieveEenheidWg.getSectorRisicogroepList()).isNull();
    }

    @Test
    @DisplayName("Should call AdministratieveEenheid Members but not set Premiepercentage Individueel")
    public void testGetAdministratieveEenheidWgIfRequiredPremiepercentageIndividueel(){
        final LocalDateTime beschouwingsmoment = LocalDateTime.of(2022,7,1,12,23);

        CwsIhpConfiguratie configuratie = mock(CwsIhpConfiguratie.class);
        when(configuratie.requiresPremiepercentageIndividueel()).thenReturn(false);
        AdministratieveEenheidWg administratieveEenheidWg = AdministratieveEenheidWg.builder().aehId(123L).build();

        ReflectionTestUtils.invokeMethod(baseWgService, "findAndAttachAdministratieveEenheidMembers",
                administratieveEenheidWg, beschouwingsmoment, configuratie);

        assertThat(administratieveEenheidWg.getPremiepercentageIndividueelList()).isNull();
    }

    @Test
    @DisplayName("Should call AdministratieveEenheid Members biut not set EigenRisicoDrager")
    public void testGetAdministratieveEenheidWgIfRequiredEigenRisicoDrager(){
        final LocalDateTime beschouwingsmoment = LocalDateTime.of(2022,7,1,12,23);
        CwsIhpConfiguratie configuratie = mock(CwsIhpConfiguratie.class);
        when(configuratie.requiresEigenRisicoDrager()).thenReturn(false);

        AdministratieveEenheidWg administratieveEenheidWg = AdministratieveEenheidWg.builder().aehId(123L).build();


        ReflectionTestUtils.invokeMethod(baseWgService, "findAndAttachAdministratieveEenheidMembers",
                administratieveEenheidWg, beschouwingsmoment, configuratie);

        assertThat(administratieveEenheidWg.getEigenRisicoDragerList()).isNull();
    }

    @Test
    @DisplayName("Should call AdministratieveEenheid Members but not set VoortzettingsrelatieOpvolger")
    public void testGetAdministratieveEenheidWgIfRequiredVoortzettingsrelatieOpvolger(){
        final LocalDateTime beschouwingsmoment = LocalDateTime.of(2022,7,1,12,23);
        CwsIhpConfiguratie configuratie = mock(CwsIhpConfiguratie.class);
        when(configuratie.requiresVoortzettingsrelatieOpvolger()).thenReturn(false);

        AdministratieveEenheidWg administratieveEenheidWg = AdministratieveEenheidWg.builder().aehId(123L).build();

        ReflectionTestUtils.invokeMethod(baseWgService, "findAndAttachAdministratieveEenheidMembers",
                administratieveEenheidWg, beschouwingsmoment, configuratie);

        assertThat(administratieveEenheidWg.getVoortzettingsrelatieOpvolgerList()).isNull();
    }

    @Test
    @DisplayName("Should call AdministratieveEenheid Members but not set VoortzettingsrelatieVoorganger")
    public void testGetAdministratieveEenheidWgIfRequiredVoortzettingsrelatieVoorganger(){
        final LocalDateTime beschouwingsmoment = LocalDateTime.of(2022,7,1,12,23);

        CwsIhpConfiguratie configuratie = mock(CwsIhpConfiguratie.class);
        when(configuratie.requiresVoortzettingsrelatieVoorganger()).thenReturn(false);
        AdministratieveEenheidWg administratieveEenheidWg = AdministratieveEenheidWg.builder().aehId(123L).build();


        ReflectionTestUtils.invokeMethod(baseWgService, "findAndAttachAdministratieveEenheidMembers",
                administratieveEenheidWg, beschouwingsmoment, configuratie);

        assertThat(administratieveEenheidWg.getVoortzettingsrelatieVoorgangerList()).isNull();
    }

    @Test
    @DisplayName("Should call AdministratieveEenheid Members but not set AangifteFrequentieAdministratieveEenheid")
    public void testGetAdministratieveEenheidWgIfRequiredAangifteFrequentieAdministratieveEenheid(){
        final LocalDateTime beschouwingsmoment = LocalDateTime.of(2022,7,1,12,23);
        CwsIhpConfiguratie configuratie = mock(CwsIhpConfiguratie.class);
        when(configuratie.requiresAangifteFrequentieAdministratieveEenheid()).thenReturn(false);
        AdministratieveEenheidWg administratieveEenheidWg = AdministratieveEenheidWg.builder().aehId(123L).build();

        ReflectionTestUtils.invokeMethod(baseWgService, "findAndAttachAdministratieveEenheidMembers",
                administratieveEenheidWg, beschouwingsmoment, configuratie);

        assertThat(administratieveEenheidWg.getAangiftefrequentieAdministratieveEenheidList()).isNull();
    }

    @Test
    @DisplayName("Should call AdministratieveEenheid Members but not set AansluitingsnummerBv")
    public void testGetAdministratieveEenheidWgIfRequiredAansluitingsnummerBv(){
        final LocalDateTime beschouwingsmoment = LocalDateTime.of(2022,7,1,12,23);

        CwsIhpConfiguratie configuratie = mock(CwsIhpConfiguratie.class);
        when(configuratie.requiresAansluitingsnummerBv()).thenReturn(false);
        AdministratieveEenheidWg administratieveEenheidWg = AdministratieveEenheidWg.builder().aehId(123L).build();

        ReflectionTestUtils.invokeMethod(baseWgService, "findAndAttachAdministratieveEenheidMembers",
                administratieveEenheidWg, beschouwingsmoment, configuratie);

        assertThat(administratieveEenheidWg.getAansluitingsnummerBvList()).isNull();
    }

    @Test
    @DisplayName("Should call Adreshouding Members")
    void testFindAdres(){
        final Long aehId = 123L;
        final LocalDateTime beschouwingsmoment = LocalDateTime.of(2022,7,1,12,23);

        CwsIhpConfiguratie configuratie = mock(CwsIhpConfiguratie.class);
        when(configuratie.requiresAnyAdresNederlandWg()).thenReturn(true);
        when(configuratie.requiresAnyAdresBuitenlandWg()).thenReturn(true);
        when(configuratie.requiresAdresBuitenlandOngestructureerdWg()).thenReturn(true);

        AdreshoudingWg adreshoudingWg = ReflectionTestUtils.invokeMethod(baseWgService, "findAdres",
                aehId, beschouwingsmoment, configuratie);

        assertThat(adreshoudingWg).isNotNull();
        assertThat(adreshoudingWg.getAdresNederlandWgList()).isNotNull();
        assertThat(adreshoudingWg.getAdresBuitenlandWgList()).isNotNull();
        assertThat(adreshoudingWg.getAdresBuitenlandOngestructureerdWgList()).isNotNull();
    }

    @Test
    @DisplayName("Should call Adreshouding Members but not set AdresNederlandWg")
    void testFindAdresAdresNederlandWg(){
        final Long aehId = 123L;
        final LocalDateTime beschouwingsmoment = LocalDateTime.of(2022,7,1,12,23);

        CwsIhpConfiguratie configuratie = mock(CwsIhpConfiguratie.class);
        when(configuratie.requiresAnyAdresNederlandWg()).thenReturn(false);
        AdreshoudingWg adreshoudingWg = ReflectionTestUtils.invokeMethod(baseWgService, "findAdres",
                aehId, beschouwingsmoment, configuratie);

        assertThat(adreshoudingWg).isNotNull();
        assertThat(adreshoudingWg.getAdresNederlandWgList()).isNull();
    }

    @Test
    @DisplayName("Should call Adreshouding Members but not set AdresBuitenlandWg")
    void testFindAdresAdresBuitenlandWg(){
        final Long aehId = 123L;
        final LocalDateTime beschouwingsmoment = LocalDateTime.of(2022,7,1,12,23);

        CwsIhpConfiguratie configuratie = mock(CwsIhpConfiguratie.class);
        when(configuratie.requiresAnyAdresBuitenlandWg()).thenReturn(true);

        AdreshoudingWg adreshoudingWg = ReflectionTestUtils.invokeMethod(baseWgService, "findAdres",
                aehId, beschouwingsmoment, configuratie);

        assertThat(adreshoudingWg).isNotNull();
        assertThat(adreshoudingWg.getAdresBuitenlandWgList()).isNotNull();
    }

    @Test
    @DisplayName("Should call Adreshouding Members but not set AdresBuitenlandOngestructureerdWg")
    void testFindAdresAdresBuitenlandOngestructureerdWg(){
        final Long aehId = 123L;
        final LocalDateTime beschouwingsmoment = LocalDateTime.of(2022,7,1,12,23);

        CwsIhpConfiguratie configuratie = mock(CwsIhpConfiguratie.class);
        when(configuratie.requiresAdresBuitenlandOngestructureerdWg()).thenReturn(false);

        AdreshoudingWg adreshoudingWg = ReflectionTestUtils.invokeMethod(baseWgService, "findAdres",
                aehId, beschouwingsmoment, configuratie);

        assertThat(adreshoudingWg).isNotNull();
        assertThat(adreshoudingWg.getAdresBuitenlandOngestructureerdWgList()).isNull();
    }

    static class ConcreteBaseWgService extends BaseWgService{
    }
}
