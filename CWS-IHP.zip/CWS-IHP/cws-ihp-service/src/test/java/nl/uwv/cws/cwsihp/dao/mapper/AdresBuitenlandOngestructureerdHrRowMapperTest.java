package nl.uwv.cws.cwsihp.dao.mapper;

import nl.uwv.cws.cwsihp.model.hr.AdresBuitenlandOngestructureerdHr;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.Mockito.when;

@TestInstance(Lifecycle.PER_CLASS)
@ExtendWith(MockitoExtension.class)
public class AdresBuitenlandOngestructureerdHrRowMapperTest {

    @InjectMocks
    private AdresBuitenlandOngestructureerdHrRowMapper adresBuitenlandOngestructureerdHrRowMapper;

    @Mock
    private ResultSet resultSet;

    @BeforeEach
    public void setup() throws SQLException {
        when(resultSet.getObject("CD_DATUM_AANVANG_CGM")).thenReturn(1);
        when(resultSet.getObject("CD_DATUM_EINDE_CGM")).thenReturn(1);
        when(resultSet.getObject("IND_AFGESCHERMD_ADRES_CGM")).thenReturn(1);
        when(resultSet.getObject("LANDCODE_GBA_CGM")).thenReturn(1);
    }

    @Test
    @DisplayName("Should successfully map fields for AdresBuitenlandOngestructureerd")
    public void testMapPostbusAdresStatusAdresAuto() throws SQLException {
        when(resultSet.getString("CODE_ADRESROL_CGM")).thenReturn("C");
        when(resultSet.getDate("DATUM_AANVANG_CGM")).thenReturn(Date.valueOf(LocalDate.of(2020,1,1)));
        when(resultSet.getInt("CD_DATUM_AANVANG_CGM")).thenReturn(1);
        when(resultSet.getDate("DATUM_EINDE_CGM")).thenReturn(Date.valueOf(LocalDate.of(2020,1,31)));
        when(resultSet.getInt("CD_DATUM_EINDE_CGM")).thenReturn(2);
        when(resultSet.getInt("IND_AFGESCHERMD_ADRES_CGM")).thenReturn(1);

        when(resultSet.getString("ADRESREGEL_1_BUITENLAND_CGM")).thenReturn("Adresregel1BuitenlandCgm");
        when(resultSet.getString("ADRESREGEL_2_BUITENLAND_CGM")).thenReturn("Adresregel2BuitenlandCgm");
        when(resultSet.getString("ADRESREGEL_3_BUITENLAND_CGM")).thenReturn("Adresregel3BuitenlandCgm");
        when(resultSet.getInt("LANDCODE_GBA_CGM")).thenReturn(333);
        when(resultSet.getString("LANDSNAAM_GBA_CGM")).thenReturn("LandsnaamGbaCgm");
        when(resultSet.getString("LANDCODE_ISO_CGM")).thenReturn("NL");
        when(resultSet.getString("LANDSNAAM_CGM")).thenReturn("LandsnaamCgm");

        List<String> attributen = Arrays.asList("CODE_ADRESROL_CGM", "DATUM_AANVANG_CGM", "CD_DATUM_AANVANG_CGM", "DATUM_EINDE_CGM", "CD_DATUM_EINDE_CGM"
                , "IND_AFGESCHERMD_ADRES_CGM", "ADRESREGEL_1_BUITENLAND_CGM", "ADRESREGEL_2_BUITENLAND_CGM", "ADRESREGEL_3_BUITENLAND_CGM"
                , "LANDCODE_GBA_CGM", "LANDSNAAM_GBA_CGM", "LANDCODE_ISO_CGM", "LANDSNAAM_CGM");

        AdresBuitenlandOngestructureerdHr adresBuitenlandOngestructureerdHr = adresBuitenlandOngestructureerdHrRowMapper.mapRow(resultSet, attributen);
        assertThat(adresBuitenlandOngestructureerdHr, is(notNullValue()));
        assertThat(adresBuitenlandOngestructureerdHr.getCodeAdresrol(), is(equalTo("C")));
        assertThat(adresBuitenlandOngestructureerdHr.getDatumAanvangAdreshouding(), is(Date.valueOf(LocalDate.of(2020,1,1))));
        assertThat(adresBuitenlandOngestructureerdHr.getCodeFictieveDatumAanvang(), is(equalTo(1)));
        assertThat(adresBuitenlandOngestructureerdHr.getDatumEindeAdreshouding(), is(Date.valueOf(LocalDate.of(2020,1,31))));
        assertThat(adresBuitenlandOngestructureerdHr.getCodeFictieveDatumEinde(), is(equalTo(2)));

        assertThat(adresBuitenlandOngestructureerdHr.getAdresregel1Buitenland(), is(equalTo("Adresregel1BuitenlandCgm")));
        assertThat(adresBuitenlandOngestructureerdHr.getAdresregel2Buitenland(), is(equalTo("Adresregel2BuitenlandCgm")));
        assertThat(adresBuitenlandOngestructureerdHr.getAdresregel3Buitenland(), is(equalTo("Adresregel3BuitenlandCgm")));
        assertThat(adresBuitenlandOngestructureerdHr.getLandcodeGba(), is(equalTo(333)));
        assertThat(adresBuitenlandOngestructureerdHr.getLandsnaamGba(), is(equalTo("LandsnaamGbaCgm")));
        assertThat(adresBuitenlandOngestructureerdHr.getLandcodeIso(), is(equalTo("NL")));
        assertThat(adresBuitenlandOngestructureerdHr.getLandsnaam(), is(equalTo("LandsnaamCgm")));
    }
}
