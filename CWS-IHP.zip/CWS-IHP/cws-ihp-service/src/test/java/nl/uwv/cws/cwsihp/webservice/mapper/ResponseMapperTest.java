package nl.uwv.cws.cwsihp.webservice.mapper;

import nl.uwv.cws.common.exception.ApplicatieMeldingException;
import nl.uwv.cws.common.model.Foutmelding;
import nl.uwv.cws.cwsihp.exception.CwsIhpResponseXsdInvalidException;
import nl.uwv.cws.cwsihp.model.CwsIhpCollectResult;
import nl.uwv.cws.cwsihp.model.ihp.PersoonIhp;
import nl.uwv.cws.cwsihp.model.selection.SelectionParameters;
import nl.uwv.cws.common.webservice.rule.CwsRuleExecutor;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0007.CwsInhoudingsplichtigeResponse.Gegevenslevering;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.Arrays;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class ResponseMapperTest {

    @InjectMocks
    private ResponseMapper responseMapper;

    @Mock
    private ApplicatiemeldingMapper applicatiemeldingMapper;

    @Mock
    private GegevensleveringMapper gegevensleveringMapper;

    @Mock
    private PersoonInhoudingsplichtigeMapper persoonInhoudingsplichtigeMapper;

    @Mock
    private CwsRuleExecutor ruleExecutor;

    @Test
    @DisplayName("Given CwsIhpCollectResult should call other mappers")
    public void testMapToJaxb() throws CwsIhpResponseXsdInvalidException {
        Gegevenslevering.PersoonInhoudingsplichtige persoonInhoudingsplichtige = createPersoonInhoudingsplichtige();
        CwsIhpCollectResult cwsIhpCollectResult = createCwsIhpCollectResult();

        when(persoonInhoudingsplichtigeMapper.mapToJaxbPersoonIhp(cwsIhpCollectResult.getPersoonIhpList().get(0)))
                .thenReturn(persoonInhoudingsplichtige);
        when(gegevensleveringMapper.mapToJaxbGegevenslevering(any(SelectionParameters.class))).thenReturn(new Gegevenslevering());
        responseMapper.mapToJaxb(cwsIhpCollectResult);

        verify(gegevensleveringMapper,times(1)).mapToJaxbGegevenslevering(any(SelectionParameters.class));
        verify(persoonInhoudingsplichtigeMapper,times(1)).mapToJaxbPersoonIhp(any(PersoonIhp.class));
    }

    @Test
    @DisplayName("Given Foutmelding should call applicatiemeldingMapper")
    public void testMapToJaxbApplicatieMelding() {
        Foutmelding foutmelding = createFoutmelding();
        responseMapper.mapToJaxbApplicatieMelding(foutmelding);

        verify(applicatiemeldingMapper,times(1)).mapToJaxbApplicatieMelding(any(Foutmelding.class));
    }

    @Test
    @DisplayName("Validation should fail when PersoonInhoudingsplichtige is null")
    public void testMapToJaxbGegevensleveringThrowsException() throws CwsIhpResponseXsdInvalidException {
        CwsIhpCollectResult cwsIhpCollectResult = createEmptyCwsIhpCollectResult();

        when(gegevensleveringMapper.mapToJaxbGegevenslevering(any(SelectionParameters.class)))
                .thenReturn(new Gegevenslevering());

        ApplicatieMeldingException exception = assertThrows(
                ApplicatieMeldingException.class,
                () -> responseMapper.mapToJaxb(cwsIhpCollectResult));

        assertThat(exception.getFoutmelding().getMessage(), is(equalTo("Geen gegevens gevonden")));
        assertThat(exception.getFoutmelding().getSoort(), is(equalTo("F")));
        assertThat(exception.getFoutmelding().getCode(), is(equalTo("072")));
    }

    private Foutmelding createFoutmelding() {
        return new Foutmelding() {
            @Override
            public String getSoort() {
                return null;
            }

            @Override
            public String getCode() {
                return null;
            }

            @Override
            public String getMessage() {
                return null;
            }
        };
    }

    private CwsIhpCollectResult createCwsIhpCollectResult() {
        SelectionParameters selectionParameters = createSelectionParameters();
        PersoonIhp persoonIhp = createPersoonIhp();

        return CwsIhpCollectResult.builder()
                .selectionParameters(selectionParameters)
                .persoonIhpList(Arrays.asList(persoonIhp))
                .build();
    }

    private CwsIhpCollectResult createEmptyCwsIhpCollectResult() {
        SelectionParameters selectionParameters = createSelectionParameters();
        PersoonIhp persoonIhp = createPersoonIhp();

        return CwsIhpCollectResult.builder()
                .selectionParameters(selectionParameters)
                .build();
    }

    private SelectionParameters createSelectionParameters() {
        return SelectionParameters.builder().beschouwingsmoment(LocalDateTime.now()).build();
    }

    private PersoonIhp createPersoonIhp() {
        return PersoonIhp.builder().build();
    }

    private Gegevenslevering.PersoonInhoudingsplichtige createPersoonInhoudingsplichtige() {
        return new Gegevenslevering.PersoonInhoudingsplichtige();
    }
}
