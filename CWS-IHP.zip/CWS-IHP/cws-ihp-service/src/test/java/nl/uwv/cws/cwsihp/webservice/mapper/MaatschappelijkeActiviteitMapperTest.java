package nl.uwv.cws.cwsihp.webservice.mapper;

import nl.uwv.cws.cwsihp.model.hr.MaatschappelijkeActiviteitHr;
import nl.uwv.cws.cwsihp.model.hr.SbiklasseHr;
import nl.uwv.cws.cwsihp.model.hr.VestigingHandelsregisterHr;
import nl.uwv.cws.common.webservice.rule.CwsRuleExecutor;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0007.CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Date;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
public class MaatschappelijkeActiviteitMapperTest {

    @InjectMocks
    private MaatschappelijkeActiviteitMapper maatschappelijkeActiviteitMapper;

    @Mock
    private SbiklasseMapper sbiklasseMapper;

    @Mock
    private AdreshoudingMapper adreshoudingMapper;

    @Mock
    private VestigingHandelsregisterMapper vestigingHandelsregisterMapper;

    @Mock
    private CwsRuleExecutor ruleExecutor;

    @Captor
    private ArgumentCaptor<String> ihpFieldCaptor;

    @Captor
    private ArgumentCaptor<String> xsdFieldCaptor;

    @Test
    @DisplayName("Given kvkNr should correctly map field to JaxB")
    public void testMapToJaxbMaatschappelijkeActiviteit() {
        maatschappelijkeActiviteitMapper.mapToJaxbMaatschappelijkeActiviteit(createMaatschappelijkeActiviteitHr());

        verify(ruleExecutor, times(5)).setTransformedValue(any(MaatschappelijkeActiviteit.class), xsdFieldCaptor.capture(), ihpFieldCaptor.capture());

        List<String> hrFieldValues = Arrays.asList( "123456789", "20180201","0", "20190201", "0");
        List<String> xsdFieldValues = Arrays.asList("kvkNr", "datBMaatschappelijkeActiviteit", "cdFictieveDatB", "datEMaatschappelijkeActiviteit", "cdFictieveDatE");

        assertArrayEquals(hrFieldValues.toArray(), ihpFieldCaptor.getAllValues().toArray());
        assertEquals(xsdFieldValues, xsdFieldCaptor.getAllValues());;
    }

    @Test
    @DisplayName("Given MaatschappelijkeActiviteitHr with SbiklasseHr test mapping fields to JaxB maatschappelijkeActiviteit is successful and sbiklasseMapper called")
    public void testMapMaatschappelijkeActiviteitWithSbiKlasse() {
        MaatschappelijkeActiviteitHr maatschappelijkeActiviteitHr = createMaatschappelijkeActiviteitHr();
        SbiklasseHr sbiklasseHr = SbiklasseHr.builder().build();
        SbiklasseHr sbiklasseHrOther = SbiklasseHr.builder().build();
        maatschappelijkeActiviteitHr.setSbiklasseHrList(Arrays.asList(sbiklasseHr, sbiklasseHrOther));

        maatschappelijkeActiviteitMapper.mapToJaxbMaatschappelijkeActiviteit(maatschappelijkeActiviteitHr);
        verify(sbiklasseMapper,times(2)).mapToJaxbSbiklasseMaatschappelijkeActiviteit(any(SbiklasseHr.class));
    }

    @Test
    @DisplayName("Given MaatschappelijkeActiviteitHr with VestigingHandelsregisterHr test mapping fields to JaxB maatschappelijkeActiviteit is successful and vestigingHandelsregisterMapper called")
    public void testMapMaatschappelijkeActiviteitWithVestigingHandelsregister() {
        MaatschappelijkeActiviteitHr maatschappelijkeActiviteitHr = createMaatschappelijkeActiviteitHr();
        VestigingHandelsregisterHr vestigingHandelsregisterHr = VestigingHandelsregisterHr.builder().build();
        maatschappelijkeActiviteitHr.setVestigingHandelsregisterHrList(Arrays.asList(vestigingHandelsregisterHr));

        maatschappelijkeActiviteitMapper.mapToJaxbMaatschappelijkeActiviteit(maatschappelijkeActiviteitHr);
        verify(vestigingHandelsregisterMapper,times(1)).mapToJaxbVestigingHandelsregister(any(VestigingHandelsregisterHr.class));
    }

    private MaatschappelijkeActiviteitHr createMaatschappelijkeActiviteitHr() {
        MaatschappelijkeActiviteitHr maatschappelijkeActiviteitHr = MaatschappelijkeActiviteitHr.builder()
                .kvkNummer("123456789")
                .configurationIncludesKvkNummer(true)
                .datumAanvangMaatschappelijkeActiviteit(Date.valueOf(LocalDate.of(2018,2,1)))
                .codeFictieveDatumAanvang(0)
                .datumEindeMaatschappelijkeActiviteit(Date.valueOf(LocalDate.of(2019,2,1)))
                .codeFictieveDatumEinde(0)
                .build();
        return maatschappelijkeActiviteitHr;
    }
}
