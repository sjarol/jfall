package nl.uwv.cws.cwsihp.webservice.mapper;

import nl.uwv.cws.cwsihp.model.wg.EigenRisicoDragerWg;
import nl.uwv.cws.common.webservice.rule.CwsRuleExecutor;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
public class EigenRisicoDragerMapperTest {

    @InjectMocks
    private EigenRisicoDragerMapper eigenRisicoDragerMapper;

    @Mock
    private CwsRuleExecutor ruleExecutor;

    @Captor
    private ArgumentCaptor<String> wgFieldCaptor;

    @Captor
    private ArgumentCaptor<String> xsdFieldCaptor;

    @Test
    @DisplayName("Given EigenRisicoDragerWg test mapping fields to JaxB is successful")
    public void testMapToJaxbEigenRisicoDrager() {
        EigenRisicoDragerWg eigenRisicoDragerWg = createEigenRisicoDragerWg();
        eigenRisicoDragerMapper.mapToJaxbEigenRisicoDrager(eigenRisicoDragerWg);

        verify(ruleExecutor, times(3)).setTransformedValue(any(Object.class), xsdFieldCaptor.capture(), wgFieldCaptor.capture());
        List<Object> wgFieldValues = Arrays.asList("code eigenRisicoDrager", "20210601", "20231201");
        List<Object> xsdFieldValues = Arrays.asList("cdSzProduct", "datBEigenrisicodrager", "datEEigenrisicodrager");
        assertArrayEquals(wgFieldValues.toArray(), wgFieldCaptor.getAllValues().toArray());
        assertEquals(xsdFieldValues, xsdFieldCaptor.getAllValues());
    }

    private EigenRisicoDragerWg createEigenRisicoDragerWg() {
        return EigenRisicoDragerWg.builder()
                .codeSzProduct("code eigenRisicoDrager")
                .datumAanvangEigenRisicoDrager(20210601L)
                .datumEindeEigenRisicoDrager(20231201L)
                .build();
    }
}
