package nl.uwv.cws.cwsihp.webservice.mapper;

import nl.uwv.cws.cwsihp.model.wg.AansluitingsnummerBvWg;
import nl.uwv.cws.common.webservice.rule.CwsRuleExecutor;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
public class AansluitingsnummerBvMapperTest {

    @InjectMocks
    private AansluitingsnummerBvMapper aansluitingsnummerBvMapper;

    @Mock
    private CwsRuleExecutor ruleExecutor;

    @Captor
    private ArgumentCaptor<String> wgFieldCaptor;

    @Captor
    private ArgumentCaptor<String> xsdFieldCaptor;

    @Test
    @DisplayName("Given AansluitingsnummerBvWg test mapping fields to JaxB is successful")
    public void testMapToJaxbAansluitingsnummerBv() {
        AansluitingsnummerBvWg aansluitingsnummerBvWg = createAansluitingsnummerBvWg();
        aansluitingsnummerBvMapper.mapToJaxbAansluitingsnummerBv(aansluitingsnummerBvWg);

        verify(ruleExecutor, times(4)).setTransformedValue(any(Object.class), xsdFieldCaptor.capture(), wgFieldCaptor.capture());
        List<Object> wgFieldValues = Arrays.asList("57", "1", "123456789012345", "20210601");
        List<Object> xsdFieldValues = Arrays.asList("cdSectorOsv", "cdRisicopremiegroep", "aansluitingsnrBV", "datBAansluitingsnrBv");
        assertArrayEquals(wgFieldValues.toArray(), wgFieldCaptor.getAllValues().toArray());
        assertEquals(xsdFieldValues, xsdFieldCaptor.getAllValues());
    }

    private AansluitingsnummerBvWg createAansluitingsnummerBvWg() {
        return AansluitingsnummerBvWg.builder()
                .codeSectorOsv(57L)
                .risicoPremiegroep(1L)
                .aansluitingsnummerBv(123456789012345L)
                .datumAanvangAansluitingsnummerBv(20210601L)
                .build();
    }
}
