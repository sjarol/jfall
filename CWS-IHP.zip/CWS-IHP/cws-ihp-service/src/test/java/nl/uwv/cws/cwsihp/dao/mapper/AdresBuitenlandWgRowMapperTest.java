package nl.uwv.cws.cwsihp.dao.mapper;

import nl.uwv.cws.cwsihp.model.wg.AdresBuitenlandWg;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.Mockito.when;

@TestInstance(Lifecycle.PER_CLASS)
@ExtendWith(MockitoExtension.class)
public class AdresBuitenlandWgRowMapperTest {

    @InjectMocks
    private AdresBuitenlandWgRowMapper adresBuitenlandWgRowMapper;

    @Mock
    private ResultSet resultSet;

    @Test
    @DisplayName("Should successfully map fields for PostbusadresBuitenland")
    public void testMapPostbusAdresBuitenland() throws SQLException {
        when(resultSet.getString("ADRESROL")).thenReturn("C");
        when(resultSet.getObject("DATAANV")).thenReturn(1);
        when(resultSet.getLong("DATAANV")).thenReturn(20210101L);
        when(resultSet.getObject("DATEIND")).thenReturn(1);
        when(resultSet.getLong("DATEIND")).thenReturn(20210201L);
        when(resultSet.getString("ADRESTYPESTRUCT")).thenReturn("PAB");

        when(resultSet.getString("POSTCODE")).thenReturn("Postcode");
        when(resultSet.getString("WOONPLAATS")).thenReturn("Woonplaats");
        when(resultSet.getString("REGIONAAM")).thenReturn("Regionaam");
        when(resultSet.getString("LANDCODE_ISO")).thenReturn("NL");
        when(resultSet.getString("POSTBUSNR")).thenReturn("12345");

        List<String> attributen = Arrays.asList("ADRESROL", "DATAANV", "DATEIND", "POSTBUS_POSTCODE","POSTBUS_WOONPLAATS","POSTBUS_REGIONAAM","POSTBUS_LANDCODE_ISO","POSTBUSNR");

        AdresBuitenlandWg adresBuitenlandWg = adresBuitenlandWgRowMapper.mapRow(resultSet, attributen);
        assertThat(adresBuitenlandWg, is(notNullValue()));
        assertThat(adresBuitenlandWg.getCodeAdresrol(), is(equalTo("C")));
        assertThat(adresBuitenlandWg.getDatumAanvangAdreshouding(), is(equalTo(20210101L)));
        assertThat(adresBuitenlandWg.getDatumEindeAdreshouding(), is(equalTo(20210131L)));

        assertThat(adresBuitenlandWg.getPostbusadresWg().getPostcodeBuitenland(), is(equalTo("Postcode")));
        assertThat(adresBuitenlandWg.getPostbusadresWg().getWoonplaatsnaamBuitenland(), is(equalTo("Woonplaats")));
        assertThat(adresBuitenlandWg.getPostbusadresWg().getPostbusnummerBuitenland(), is(equalTo("12345")));
        assertThat(adresBuitenlandWg.getPostbusadresWg().getLandcodeIso(), is(equalTo("NL")));
        assertThat(adresBuitenlandWg.getPostbusadresWg().getRegionaamBuitenland(), is(equalTo("Regionaam")));
    }

    @Test
    @DisplayName("Should successfully map fields for StraatadresBuitenland")
    public void testMapRowStraatAdresBuitenland() throws SQLException {
        when(resultSet.getString("ADRESROL")).thenReturn("C");
        when(resultSet.getObject("DATAANV")).thenReturn(1);
        when(resultSet.getLong("DATAANV")).thenReturn(20210101L);
        when(resultSet.getObject("DATEIND")).thenReturn(1);
        when(resultSet.getLong("DATEIND")).thenReturn(20210201L);
        when(resultSet.getString("ADRESTYPESTRUCT")).thenReturn("SAB");

        when(resultSet.getString("POSTCODE")).thenReturn("Postcode");
        when(resultSet.getString("WOONPLAATS")).thenReturn("Woonplaats");
        when(resultSet.getString("STRAATNAAM")).thenReturn("Straatnaam");
        when(resultSet.getString("HUISNR")).thenReturn("230");
        when(resultSet.getString("REGIONAAM")).thenReturn("Regionaam");
        when(resultSet.getString("LANDCODE_ISO")).thenReturn("NL");
        when(resultSet.getString("LOCATIE_OMSCH")).thenReturn("Locatieomschrijving");

        List<String> attributen = Arrays.asList("ADRESROL", "DATAANV", "DATEIND", "POSTCODE","WOONPLAATS","REGIONAAM","LANDCODE_ISO","STRAATNAAM","HUISNR","LOCATIE_OMSCH");

        AdresBuitenlandWg adresBuitenlandWg = adresBuitenlandWgRowMapper.mapRow(resultSet, attributen);
        assertThat(adresBuitenlandWg, is(notNullValue()));
        assertThat(adresBuitenlandWg.getCodeAdresrol(), is(equalTo("C")));
        assertThat(adresBuitenlandWg.getDatumAanvangAdreshouding(), is(equalTo(20210101L)));
        assertThat(adresBuitenlandWg.getDatumEindeAdreshouding(), is(equalTo(20210131L)));

        assertThat(adresBuitenlandWg.getStraatadresWg().getPostcodeBuitenland(), is(equalTo("Postcode")));
        assertThat(adresBuitenlandWg.getStraatadresWg().getWoonplaatsnaamBuitenland(), is(equalTo("Woonplaats")));
        assertThat(adresBuitenlandWg.getStraatadresWg().getStraatnaamBuitenland(), is(equalTo("Straatnaam")));
        assertThat(adresBuitenlandWg.getStraatadresWg().getHuisnummerBuitenland(), is(equalTo("230")));
        assertThat(adresBuitenlandWg.getStraatadresWg().getLandcodeIso(), is(equalTo("NL")));
        assertThat(adresBuitenlandWg.getStraatadresWg().getRegionaamBuitenland(), is(equalTo("Regionaam")));
        assertThat(adresBuitenlandWg.getStraatadresWg().getLocatieomschrijvingBuitenland(), is(equalTo("Locatieomschrijving")));
    }
}
