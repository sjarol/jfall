package nl.uwv.cws.cwsihp.service;

import nl.uwv.cws.cwsihp.dao.ihp.*;
import nl.uwv.cws.cwsihp.model.configuratie.CwsIhpConfiguratie;
import nl.uwv.cws.cwsihp.model.hr.*;
import nl.uwv.cws.cwsihp.model.ihp.PersoonIhp;
import nl.uwv.cws.cwsihp.model.selection.SelectionParameters;
import nl.uwv.cws.cwsihp.model.wg.AdministratieveEenheidWg;
import nl.uwv.cws.cwsihp.model.wg.AdresBuitenlandOngestructureerdWg;
import nl.uwv.cws.cwsihp.model.wg.AdresBuitenlandWg;
import nl.uwv.cws.cwsihp.model.wg.AdresNederlandWg;
import nl.uwv.cws.cwsihp.service.hr.BsnHrService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Date;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static java.lang.Boolean.TRUE;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class BsnHrServiceTest {

    @InjectMocks
    private BsnHrService bsnHrService;

    @Mock
    private PersoonHrDao persoonHrDao;

    @Mock
    private AdreshoudingHrDao adreshoudingHrDao;

    @Mock
    private AdministratieveEenheidWgDao administratieveEenheidWgDao;

    @Mock
    private AdresNederlandWgDao adresNederlandWgDao;

    @Mock
    protected AdresBuitenlandWgDao adresBuitenlandWgDao;

    @Mock
    protected AdresBuitenlandOngestructureerdWgDao adresBuitenlandOngestructureerdWgDao;

    @Mock
    private VestigingHandelsregisterHrDao vestigingHandelsregisterHrDao;

    @Mock
    private MaatschappelijkeActiviteitHrDao maatschappelijkeActiviteitHrDao;

    private static final Date END_OF_TIME = Date.valueOf("9999-12-31");

    @Test
    @DisplayName("Should filter all feitelijkadressen from AEH")
    public void givenAdresNederlandUhrShouldFilterFeitelijkadresFromAeh() {
        PersoonHr persoonHr = PersoonHr.builder()
                .persoonId(1000L)
                .natuurlijkePersoonId(2000L)
                .naamPersoonId(3000L)
                .build();
        final List<PersoonHr> persoonHrList = Arrays.asList(persoonHr);
        when(persoonHrDao.findPersoonHrByBsn(anyString(), any(LocalDateTime.class))).thenReturn(persoonHrList);

        CwsIhpConfiguratie cwsIhpConfiguratie = mock(CwsIhpConfiguratie.class);
        when(cwsIhpConfiguratie.requiresAnyAdresBuitenlandPersoon()).thenReturn(TRUE);
        when(cwsIhpConfiguratie.requiresAdministratieveEenheid()).thenReturn(TRUE);
        when(cwsIhpConfiguratie.requiresAnyAdresNederlandWg()).thenReturn(TRUE);
        when(cwsIhpConfiguratie.requiresAnyAdresBuitenlandWg()).thenReturn(TRUE);
        when(cwsIhpConfiguratie.requiresMaatschappelijkeActiviteit()).thenReturn(TRUE);
        when(cwsIhpConfiguratie.requiresAdresBuitenlandOngestructureerdWg()).thenReturn(TRUE);

        AdresBuitenlandHr actiefAdresHr = AdresBuitenlandHr.builder()
                .datumEindeAdreshouding(END_OF_TIME)
                .isAdresActief(true)
                .build();
        List<AdresBuitenlandHr> adresBuitenlandHrList = Arrays.asList(actiefAdresHr);
        when(adreshoudingHrDao.findAdresBuitenlandPersoon(anyLong(), anyLong(), anyLong(), any(LocalDateTime.class), any(CwsIhpConfiguratie.class)))
                .thenReturn(adresBuitenlandHrList);


        final LocalDateTime beschouwingMoment = LocalDateTime.of(2022,2,22,21,30, 5);
        AdministratieveEenheidWg administratieveEenheidWgOne = AdministratieveEenheidWg.builder()
                .aehId(123L)
                .build();
        AdministratieveEenheidWg administratieveEenheidWgTwo = AdministratieveEenheidWg.builder()
                .aehId(456L)
                .build();
        final List<AdministratieveEenheidWg> administratieveEenheidWgList = Arrays.asList(administratieveEenheidWgOne, administratieveEenheidWgTwo);
        when(administratieveEenheidWgDao.findAdministratieveEenheidByNrihp(anyString(), anyString(), any(LocalDateTime.class), any(CwsIhpConfiguratie.class)))
                .thenReturn(administratieveEenheidWgList);

        //Adres Nederland
        AdresNederlandWg feitelijkAdresNederlandWg = AdresNederlandWg.builder()
                .codeAdresrol("F")
                .build();
        AdresNederlandWg otherFeitelijkAdresNederlandWg = AdresNederlandWg.builder()
                .codeAdresrol("F")
                .build();
        AdresNederlandWg correspondentieAdresNederlandWg = AdresNederlandWg.builder()
                .codeAdresrol("C")
                .build();
        List<AdresNederlandWg> adresNederlandWgList = new ArrayList<>(
                Arrays.asList(feitelijkAdresNederlandWg, otherFeitelijkAdresNederlandWg, correspondentieAdresNederlandWg));
        when(adresNederlandWgDao.findAdresNederland(anyLong(), any(LocalDateTime.class), any(CwsIhpConfiguratie.class)))
                .thenReturn(adresNederlandWgList);


        //Adres Buitenland
        AdresBuitenlandWg feitelijkBuitenlandWg = AdresBuitenlandWg.builder()
                .codeAdresrol("F")
                .build();
        AdresBuitenlandWg correspondentieAdresBuitenlandWg = AdresBuitenlandWg.builder()
                .codeAdresrol("C")
                .build();
        List<AdresBuitenlandWg> adresBuitenlandWgList = new ArrayList<>(
                Arrays.asList(feitelijkBuitenlandWg, correspondentieAdresBuitenlandWg));
        when(adresBuitenlandWgDao.findAdresBuitenland(anyLong(), any(LocalDateTime.class), any(CwsIhpConfiguratie.class)))
                .thenReturn(adresBuitenlandWgList);


        //Adres Buitenland Ongestructureerd
        AdresBuitenlandOngestructureerdWg feitelijkAdresOngestructureerdWg = AdresBuitenlandOngestructureerdWg.builder()
                .codeAdresrol("F")
                .build();
        List<AdresBuitenlandOngestructureerdWg> adresWgList = new ArrayList<>(
                Arrays.asList(feitelijkAdresOngestructureerdWg));
        when(adresBuitenlandOngestructureerdWgDao.findAdresBuitenlandOngestructureerd(anyLong(), any(LocalDateTime.class), any(CwsIhpConfiguratie.class)))
                .thenReturn(adresWgList);

        SelectionParameters selectionParameters = SelectionParameters.builder()
                .bsn("123456789")
                .kvknummer("999999999")
                .loonheffingennummer("123456789L01")
                .cwsIhpConfiguratie(cwsIhpConfiguratie)
                .beschouwingsmoment(beschouwingMoment)
                .build();

        boolean includeAeh = true;
        List<PersoonIhp> persoonIhpList = bsnHrService.findPersoonIhp(selectionParameters, includeAeh);
        List<AdministratieveEenheidWg> selectedAdministratieveEenheidWgList = persoonIhpList.listIterator().next().getAdministratieveEenheidWgList();
        selectedAdministratieveEenheidWgList.forEach(administratieveEenheidWg -> {
            List<AdresNederlandWg> adresNederlandWgListToUse = administratieveEenheidWg.getAdreshouding().getAdresNederlandWgList();
            assertThat(adresNederlandWgListToUse.size()).isEqualTo(1);
            AdresNederlandWg adresNederlandWg = adresNederlandWgListToUse.listIterator().next();
            assertThat(adresNederlandWg.getCodeAdresrol()).isEqualTo("C");

            List<AdresBuitenlandWg> adresBuitenlandWgListToUse = administratieveEenheidWg.getAdreshouding().getAdresBuitenlandWgList();
            assertThat(adresBuitenlandWgListToUse.size()).isEqualTo(1);
            AdresBuitenlandWg adresBuitenlandWg = adresBuitenlandWgListToUse.listIterator().next();
            assertThat(adresBuitenlandWg.getCodeAdresrol()).isEqualTo("C");

            List<AdresBuitenlandOngestructureerdWg> adresBuitenlandOngestructureerdWgList = administratieveEenheidWg.getAdreshouding().getAdresBuitenlandOngestructureerdWgList();
            assertThat(adresBuitenlandOngestructureerdWgList.size()).isEqualTo(0);
        });
    }

    @Test
    @DisplayName("Should filter feitelijkadres Buitenland ongestructureerd from AEH")
    public void givenAdresUhrShouldFilterFeitelijkadresOngestructureerdFromAeh() {
        PersoonHr persoonHr = PersoonHr.builder()
                .persoonId(1000L)
                .natuurlijkePersoonId(2000L)
                .naamPersoonId(3000L)
                .build();
        when(persoonHrDao.findPersoonHrByBsn(anyString(), any(LocalDateTime.class))).thenReturn(Arrays.asList(persoonHr));

        MaatschappelijkeActiviteitHr maatschappelijkeActiviteitHr = MaatschappelijkeActiviteitHr.builder()
                .kvkNummer("1000")
                .build();
        List<MaatschappelijkeActiviteitHr> maatschappelijkeActiviteitHrList = Arrays.asList(maatschappelijkeActiviteitHr);
        when(maatschappelijkeActiviteitHrDao.findMaatschappelijkeActiviteitByKvkNummer(anyString(), any(LocalDateTime.class), any(CwsIhpConfiguratie.class)))
                .thenReturn(maatschappelijkeActiviteitHrList);

        VestigingHandelsregisterHr vestigingHandelsregisterHr = VestigingHandelsregisterHr.builder()
                .kvkNummer("1000")
                .vestigingsNummer(2000L)
                .build();
        final List<VestigingHandelsregisterHr> vestigingHandelsregisterHrList = Arrays.asList(vestigingHandelsregisterHr);
        when(vestigingHandelsregisterHrDao.findVestigingHandelsregister(anyString(), any(LocalDateTime.class), any(CwsIhpConfiguratie.class)))
                .thenReturn(vestigingHandelsregisterHrList);

        CwsIhpConfiguratie cwsIhpConfiguratie = mock(CwsIhpConfiguratie.class);
        when(cwsIhpConfiguratie.requiresAdministratieveEenheid()).thenReturn(TRUE);
        when(cwsIhpConfiguratie.requiresAdresBuitenlandOngestructureerdPersoon()).thenReturn(TRUE);
        when(cwsIhpConfiguratie.requiresAdresBuitenlandOngestructureerdWg()).thenReturn(TRUE);
        when(cwsIhpConfiguratie.requiresMaatschappelijkeActiviteit()).thenReturn(TRUE);
        when(cwsIhpConfiguratie.requiresVestigingHandelsregister()).thenReturn(TRUE);
        when(cwsIhpConfiguratie.requiresAdresBuitenlandOngestructureerdVestigingHandelsregister()).thenReturn(TRUE);

        AdresBuitenlandOngestructureerdHr actiefAdresHr = AdresBuitenlandOngestructureerdHr.builder()
                .datumEindeAdreshouding(END_OF_TIME)
                .isAdresActief(true)
                .build();
        List<AdresBuitenlandOngestructureerdHr> actiefAdresHrList = Arrays.asList(actiefAdresHr);
        when(adreshoudingHrDao.findAdresBuitenlandOngestructureerdVestigingHandelsregister(anyString(), anyLong(), any(LocalDateTime.class), any(CwsIhpConfiguratie.class)))
                .thenReturn(actiefAdresHrList);

        final LocalDateTime beschouwingMoment = LocalDateTime.of(2022,2,22,21,30, 5);
        AdministratieveEenheidWg administratieveEenheidWgOne = AdministratieveEenheidWg.builder()
                .aehId(123L)
                .build();

        final List<AdministratieveEenheidWg> administratieveEenheidWgList = Arrays.asList(administratieveEenheidWgOne);
        when(administratieveEenheidWgDao.findAdministratieveEenheidByNrihp(anyString(), anyString(), any(LocalDateTime.class), any(CwsIhpConfiguratie.class)))
                .thenReturn(administratieveEenheidWgList);

        AdresBuitenlandOngestructureerdWg feitelijkAdresOngestructureerdWg = AdresBuitenlandOngestructureerdWg.builder()
                .codeAdresrol("F")
                .build();
        AdresBuitenlandOngestructureerdWg correspondentieAdresOngestructureerdWg = AdresBuitenlandOngestructureerdWg.builder()
                .codeAdresrol("C")
                .build();
        List<AdresBuitenlandOngestructureerdWg> adresWgList = new ArrayList<>(
                Arrays.asList(feitelijkAdresOngestructureerdWg, correspondentieAdresOngestructureerdWg));
        when(adresBuitenlandOngestructureerdWgDao.findAdresBuitenlandOngestructureerd(anyLong(), any(LocalDateTime.class), any(CwsIhpConfiguratie.class)))
                .thenReturn(adresWgList);

        SelectionParameters selectionParameters = SelectionParameters.builder()
                .bsn("123456789")
                .kvknummer("999999999")
                .loonheffingennummer("123456789L01")
                .cwsIhpConfiguratie(cwsIhpConfiguratie)
                .beschouwingsmoment(beschouwingMoment)
                .build();

        boolean includeAeh = true;
        List<PersoonIhp> persoonIhpList = bsnHrService.findPersoonIhp(selectionParameters, includeAeh);

        List<AdministratieveEenheidWg> selectedAdministratieveEenheidWgList = persoonIhpList.listIterator().next().getAdministratieveEenheidWgList();
        selectedAdministratieveEenheidWgList.forEach(administratieveEenheidWg -> {
            List<AdresBuitenlandOngestructureerdWg> adresWgListToUse = administratieveEenheidWg.getAdreshouding().getAdresBuitenlandOngestructureerdWgList();
            assertThat(adresWgListToUse.size()).isEqualTo(1);

            AdresBuitenlandOngestructureerdWg adresBuitenlandOngestructureerdWg = adresWgListToUse.listIterator().next();
            assertThat(adresBuitenlandOngestructureerdWg.getCodeAdresrol()).isEqualTo("C");
        });
    }
}
