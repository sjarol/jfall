package nl.uwv.cws.cwsihp.dao.mapper;

import nl.uwv.cws.cwsihp.model.wg.AdministratieveEenheidWg;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.Mockito.when;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@ExtendWith(MockitoExtension.class)
public class AdministratieveEenheidWgRowMapperTest {

    @InjectMocks
    private AdministratieveEenheidWgRowMapper administratieveEenheidWgRowMapper;

    @Mock
    private ResultSet resultSet;

    @Test
    @DisplayName("Should successfully map fields for AdministratieveEenheidWg and map DatumEinde to -1")
    public void testMapRowDatumEindeTotEnMet() throws SQLException {
        when(resultSet.getLong("AEH_ID")).thenReturn(0L);
        when(resultSet.getString("LHNR")).thenReturn("999999990L01");
        when(resultSet.getString("AEH_NAAM")).thenReturn("Naam AEH");
        when(resultSet.getObject("DATAANV")).thenReturn(1);
        when(resultSet.getObject("DATEIND")).thenReturn(1);
        when(resultSet.getLong("DATAANV")).thenReturn(20210101L);
        when(resultSet.getLong("DATEIND")).thenReturn(20210601L);

        List<String> attributen = Arrays.asList("LHNR", "AEH_NAAM", "DATAANV", "DATEIND");

        AdministratieveEenheidWg administratieveEenheidWg = administratieveEenheidWgRowMapper.mapRow(resultSet, attributen);
        assertThat(administratieveEenheidWg, is(notNullValue()));
        assertThat(administratieveEenheidWg.getLoonheffingennummer(), is(equalTo("999999990L01")));
        assertThat(administratieveEenheidWg.getNaamAdministratieveEenheid(), is(equalTo("Naam AEH")));
        assertThat(administratieveEenheidWg.getDatumAanvangAdministratieveEenheid(), is(equalTo(20210101L)));
        assertThat(administratieveEenheidWg.getDatumEindeAdministratieveEenheid(), is(equalTo(20210531L)));
    }

    @Test
    @DisplayName("Should successfully map fields for AdministratieveEenheidWg and map DatumEinde to NULL")
    public void testMapRowDatumEindeNULL() throws SQLException {
        when(resultSet.getLong("AEH_ID")).thenReturn(0L);
        when(resultSet.getObject("DATEIND")).thenReturn(1);
        when(resultSet.getLong("DATEIND")).thenReturn(99991231L);

        List<String> attributen = Arrays.asList("DATEIND");

        AdministratieveEenheidWg administratieveEenheidWg = administratieveEenheidWgRowMapper.mapRow(resultSet, attributen);
        assertThat(administratieveEenheidWg, is(notNullValue()));
        assertThat(administratieveEenheidWg.getDatumEindeAdministratieveEenheid(), is(equalTo(null)));
    }
}
