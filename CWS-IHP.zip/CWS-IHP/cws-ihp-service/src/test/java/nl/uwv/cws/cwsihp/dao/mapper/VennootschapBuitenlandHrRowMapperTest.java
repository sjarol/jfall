package nl.uwv.cws.cwsihp.dao.mapper;

import nl.uwv.cws.cwsihp.model.hr.VennootschapBuitenlandHr;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.Mockito.when;

@TestInstance(Lifecycle.PER_CLASS)
@ExtendWith(MockitoExtension.class)
public class VennootschapBuitenlandHrRowMapperTest {

    @InjectMocks
    private VennootschapBuitenlandHrRowMapper vennootschapBuitenlandHrRowMapper;

    @Mock
    private ResultSet resultSet;

    @BeforeEach
    public void setup() throws SQLException {
        when(resultSet.getObject("CD_DATUM_AANVANG_CGM")).thenReturn(1);
        when(resultSet.getObject("CD_DATUM_EINDE_CGM")).thenReturn(2);
    }

    @Test
    @DisplayName("Should successfully map fields for VennootschapBuitenlandHr")
    public void testMapRow() throws SQLException {
        when(resultSet.getDate("DATUM_AANVANG_CGM")).thenReturn(Date.valueOf(LocalDate.of(2020,1,1)));
        when(resultSet.getInt("CD_DATUM_AANVANG_CGM")).thenReturn(1);
        when(resultSet.getDate("DATUM_EINDE_CGM")).thenReturn(Date.valueOf(LocalDate.of(2020,1,31)));
        when(resultSet.getInt("CD_DATUM_EINDE_CGM")).thenReturn(2);

        List<String> attributen = Arrays.asList("DATUM_AANVANG_CGM",
                "CD_DATUM_AANVANG_CGM", "DATUM_EINDE_CGM", "CD_DATUM_EINDE_CGM");

        VennootschapBuitenlandHr vennootschapBuitenlandHr = vennootschapBuitenlandHrRowMapper.mapRow(resultSet, attributen);
        assertThat(vennootschapBuitenlandHr, is(notNullValue()));
        assertThat(vennootschapBuitenlandHr.getDatumAanvangVennootschapBuitenland(), is(Date.valueOf(LocalDate.of(2020,1,1))));
        assertThat(vennootschapBuitenlandHr.getCodeFictieveDatumAanvang(), is(equalTo(1)));
        assertThat(vennootschapBuitenlandHr.getDatumEindeVennootschapBuitenland(), is(Date.valueOf(LocalDate.of(2020,1,31))));
        assertThat(vennootschapBuitenlandHr.getCodeFictieveDatumEinde(), is(equalTo(2)));

    }

    @Test
    @DisplayName("Should successfully map fields for VennootschapBuitenlandHr with codeFictieveDatumEinde is not 0")
    public void testMapRowCodeFictiefIsNot0() throws SQLException {
        when(resultSet.getDate("DATUM_AANVANG_CGM")).thenReturn(Date.valueOf(LocalDate.of(2020,1,1)));
        when(resultSet.getInt("CD_DATUM_AANVANG_CGM")).thenReturn(1);
        when(resultSet.getDate("DATUM_EINDE_CGM")).thenReturn(Date.valueOf(LocalDate.of(2020,1,31)));
        when(resultSet.getInt("CD_DATUM_EINDE_CGM")).thenReturn(2);

        List<String> attributen = Arrays.asList("DATUM_AANVANG_CGM",
                "CD_DATUM_AANVANG_CGM", "DATUM_EINDE_CGM", "CD_DATUM_EINDE_CGM");

        VennootschapBuitenlandHr vennootschapBuitenlandHr = vennootschapBuitenlandHrRowMapper.mapRow(resultSet, attributen);
        assertThat(vennootschapBuitenlandHr, is(notNullValue()));
        assertThat(vennootschapBuitenlandHr.getDatumAanvangVennootschapBuitenland(), is(Date.valueOf(LocalDate.of(2020,1,1))));
        assertThat(vennootschapBuitenlandHr.getCodeFictieveDatumAanvang(), is(equalTo(1)));
        assertThat(vennootschapBuitenlandHr.getDatumEindeVennootschapBuitenland(), is(Date.valueOf(LocalDate.of(2020,1,31))));
        assertThat(vennootschapBuitenlandHr.getCodeFictieveDatumEinde(), is(equalTo(2)));

    }

    @Test
    @DisplayName("Should successfully map fields for VennootschapBuitenlandHr with codeFictieveDatumEinde is 0")
    public void testMapRowCodeFictiefIs0() throws SQLException {
        when(resultSet.getDate("DATUM_AANVANG_CGM")).thenReturn(Date.valueOf(LocalDate.of(2020,1,1)));
        when(resultSet.getInt("CD_DATUM_AANVANG_CGM")).thenReturn(0);
        when(resultSet.getDate("DATUM_EINDE_CGM")).thenReturn(Date.valueOf(LocalDate.of(2020,2,1)));
        when(resultSet.getInt("CD_DATUM_EINDE_CGM")).thenReturn(0);

        List<String> attributen = Arrays.asList("DATUM_AANVANG_CGM",
                "CD_DATUM_AANVANG_CGM", "DATUM_EINDE_CGM", "CD_DATUM_EINDE_CGM");

        VennootschapBuitenlandHr vennootschapBuitenlandHr = vennootschapBuitenlandHrRowMapper.mapRow(resultSet, attributen);
        assertThat(vennootschapBuitenlandHr, is(notNullValue()));
        assertThat(vennootschapBuitenlandHr.getDatumAanvangVennootschapBuitenland(), is(Date.valueOf(LocalDate.of(2020,1,1))));
        assertThat(vennootschapBuitenlandHr.getCodeFictieveDatumAanvang(), is(equalTo(0)));
        assertThat(vennootschapBuitenlandHr.getDatumEindeVennootschapBuitenland(), is(Date.valueOf(LocalDate.of(2020,1,31))));
        assertThat(vennootschapBuitenlandHr.getCodeFictieveDatumEinde(), is(equalTo(0)));

    }
}
