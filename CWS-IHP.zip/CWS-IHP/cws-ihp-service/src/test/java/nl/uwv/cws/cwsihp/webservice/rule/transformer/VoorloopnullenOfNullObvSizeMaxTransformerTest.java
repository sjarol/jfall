package nl.uwv.cws.cwsihp.webservice.rule.transformer;

import nl.uwv.cws.common.model.rule.AttributeRuleProperties;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static nl.uwv.cws.cwsihp.model.rule.CwsIhpAttributeRule.NUMMER_MET_VOORLOOPNULLEN_OBV_SIZE_MAX_OF_NULL;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

public class VoorloopnullenOfNullObvSizeMaxTransformerTest {

    private VoorloopnullenOfNullObvSizeMaxTransformer voorloopnullenOfNullObvSizeMaxTransformer;
    private AttributeRuleProperties attributeRuleProperties;

    @BeforeEach
    public void setup() {
        voorloopnullenOfNullObvSizeMaxTransformer = new VoorloopnullenOfNullObvSizeMaxTransformer();
        attributeRuleProperties = new AttributeRuleProperties();
    }

    @Test
    public void given_voorloopnullenObvSizeMaxTransformer_shouldUseCorrectType() {
        assertThat(voorloopnullenOfNullObvSizeMaxTransformer.getTransformRule(), is(NUMMER_MET_VOORLOOPNULLEN_OBV_SIZE_MAX_OF_NULL));
    }

    @Test
    public void given_valueNeedsLeftpad_shouldAddCorrectSizeLeftPad() {
        attributeRuleProperties.setSizeMax(6);
        String originalValue = "5060";
        String transformedValue = voorloopnullenOfNullObvSizeMaxTransformer.transform(originalValue, attributeRuleProperties);
        assertThat(transformedValue, is("005060"));
    }

    @Test
    public void given_valueDoesNotNeedsLeftpad_shouldNotAddLeftPad() {
        attributeRuleProperties.setSizeMax(6);
        String originalValue = "005060";
        String transformedValue = voorloopnullenOfNullObvSizeMaxTransformer.transform(originalValue, attributeRuleProperties);
        assertThat(transformedValue, is("005060"));
    }

    @Test
    public void given_valueEmpty_shouldReturnEmpty() {
        attributeRuleProperties.setSizeMax(6);
        String originalValue = "";
        String transformedValue = voorloopnullenOfNullObvSizeMaxTransformer.transform(originalValue, attributeRuleProperties);
        assertThat(transformedValue, is(nullValue()));
    }

    @Test
    public void given_valueTooLong_shouldReturnEmpty() {
        attributeRuleProperties.setSizeMax(6);
        String originalValue = "1234567";
        String transformedValue = voorloopnullenOfNullObvSizeMaxTransformer.transform(originalValue, attributeRuleProperties);
        assertThat(transformedValue, is(nullValue()));
    }
}
