package nl.uwv.cws.cwsihp.webservice.mapper;

import nl.uwv.cws.cwsihp.model.hr.*;
import nl.uwv.cws.common.webservice.rule.CwsRuleExecutor;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0007.CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Onderneming;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Date;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
public class OndernemingMapperTest {

    @InjectMocks
    private OndernemingMapper ondernemingMapper;

    @Mock
    private SbiklasseMapper sbiklasseMapper;

    @Mock
    private HandelsnaamMapper handelsnaamMapper;

    @Mock
    private CwsRuleExecutor ruleExecutor;

    @Captor
    private ArgumentCaptor<Object> ihpFieldCaptor;

    @Captor
    private ArgumentCaptor<String> xsdFieldCaptor;

    @Test
    @DisplayName("Given OndernemingHr test mapping fields to JaxB Onderneming VestigingHandelsregister is successful")
    public void testMapToJaxbOndernemingVestigingHandelsregister() {
        OndernemingHr ondernemingHr = createOndernemingHr();
        ondernemingMapper.mapToJaxbOnderneming(ondernemingHr);

        verify(ruleExecutor, times(5)).setTransformedValue(any(Onderneming.class), xsdFieldCaptor.capture(), ihpFieldCaptor.capture());
        List<String> hrFieldValues = Arrays.asList( "123456789","20180201","0", "20190201", "0");
        List<String> xsdFieldValues = Arrays.asList("kvkNr", "datBOnderneming", "cdFictieveDatB", "datEOnderneming", "cdFictieveDatE");

        assertArrayEquals(hrFieldValues.toArray(), ihpFieldCaptor.getAllValues().toArray());
        assertEquals(xsdFieldValues, xsdFieldCaptor.getAllValues());
    }

    @Test
    @DisplayName("Given OndernemingHr WithoutKvkNrAndDates test mapping fields to JaxB Onderneming VestigingHandelsregister is successful")
    public void testMapToJaxbOndernemingVestigingHandelsregisterWithoutKvkNrAndDates() {
        OndernemingHr ondernemingHr = createOndernemingHrWithoutKvkNrAndDates();
        ondernemingMapper.mapToJaxbOnderneming(ondernemingHr);

        verify(ruleExecutor, times(5)).setTransformedValue(any(Onderneming.class), xsdFieldCaptor.capture(), ihpFieldCaptor.capture());
        List<String> hrFieldValues = Arrays.asList( null,null,null, null, null);
        List<String> xsdFieldValues = Arrays.asList("kvkNr", "datBOnderneming", "cdFictieveDatB", "datEOnderneming", "cdFictieveDatE");

        assertArrayEquals(hrFieldValues.toArray(), ihpFieldCaptor.getAllValues().toArray());
        assertEquals(xsdFieldValues, xsdFieldCaptor.getAllValues());
    }

    @Test
    @DisplayName("Given OndernemingHr with Sbiklasse verify sbiklasseMapper is called")
    public void testMapToJaxbOndernemingVestigingHandelsregisterWithSbiklasse() {
        OndernemingHr ondernemingHr = createOndernemingHr();
        SbiklasseHr sbiklasseHr = createSbiklasseHr();
        SbiklasseHr sbiklasseHrOther = createSbiklasseHr();
        ondernemingHr.setSbiklasseHrList(Arrays.asList(sbiklasseHr, sbiklasseHrOther));

        ondernemingMapper.mapToJaxbOnderneming(ondernemingHr);
        verify(sbiklasseMapper,times(2)).mapToJaxbSbiklasseOnderneming(any(SbiklasseHr.class));
    }

    @Test
    @DisplayName("Given OndernemingHr with Handelsnaam test mapping fields to JaxB Onderneming is successful and handelsnaamMapper called")
    public void testMapToJaxbOndernemingVestigingHandelsregisterWithHandelsnaam() {
        OndernemingHr ondernemingHr = createOndernemingHr();
        HandelsnaamHr handelsnaamHr = createHandelsnaamHr();
        ondernemingHr.setHandelsnaamHrList(Arrays.asList(handelsnaamHr));

        ondernemingMapper.mapToJaxbOnderneming(ondernemingHr);
        verify(handelsnaamMapper,times(1)).mapToJaxbHandelsnaamOnderneming(any(HandelsnaamHr.class));
    }

    @Test
    @DisplayName("Given OndernemingHr with SbiklasseHr sbiklasseMapper is called")
    public void testMapMaatschappelijkeActiviteitWithSbiKlasse() {
        OndernemingHr ondernemingHr = createOndernemingHr();
        SbiklasseHr sbiklasseHr = createSbiklasseHr();
        SbiklasseHr sbiklasseHrOther = createSbiklasseHr();
        ondernemingHr.setSbiklasseHrList(Arrays.asList(sbiklasseHr, sbiklasseHrOther));

        ondernemingMapper.mapToJaxbOnderneming(ondernemingHr);
        verify(sbiklasseMapper,times(2)).mapToJaxbSbiklasseOnderneming(any(SbiklasseHr.class));
    }

    private OndernemingHr createOndernemingHr() {
        return OndernemingHr.builder()
                .kvkNummer("123456789")
                .configurationIncludesKvkNummer(true)
                .datumAanvangOnderneming(Date.valueOf(LocalDate.of(2018,2,1)))
                .codeFictieveDatumAanvang(0)
                .datumEindeOnderneming(Date.valueOf(LocalDate.of(2019,2,1)))
                .codeFictieveDatumEinde(0)
                .build();
    }

    private OndernemingHr createOndernemingHrWithoutKvkNrAndDates() {
        return OndernemingHr.builder()
                .kvkNummer(String.valueOf(123456789L))
                .configurationIncludesKvkNummer(false)
                .datumAanvangOnderneming(null)
                .codeFictieveDatumAanvang(0)
                .datumEindeOnderneming(null)
                .codeFictieveDatumEinde(0)
                .build();
    }

    private SbiklasseHr createSbiklasseHr() {
        return SbiklasseHr.builder().build();
    }

    private HandelsnaamHr createHandelsnaamHr() {
        return HandelsnaamHr.builder().build();
    }

}
