package nl.uwv.cws.cwsihp.webservice.rule.transformer;

import nl.uwv.cws.common.model.rule.AttributeRuleProperties;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static nl.uwv.cws.cwsihp.model.rule.CwsIhpAttributeRule.FICTIEVE_GEBOORTEDATUM;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;

public class FictieveGeboortedatumTransformerTest {

    private FictieveGeboorteDatumTransformer fictieveGeboorteDatumTransformer;
    private AttributeRuleProperties attributeRuleProperties;

    @BeforeEach
    public void setup() {
        fictieveGeboorteDatumTransformer = new FictieveGeboorteDatumTransformer();
        attributeRuleProperties = new AttributeRuleProperties();
    }

    @Test
    @DisplayName("Should use correct rule type")
    public void given_afkappenObvSizeMaxTransformer_shouldUseCorrectType() {
        assertThat(fictieveGeboorteDatumTransformer.getTransformRule(), is(FICTIEVE_GEBOORTEDATUM));
    }

    @Test
    public void given_nonfictieveDatum_shouldBuildValidDatum() {
        String datumNotFicief = "20050603";
        String transformedDatum = fictieveGeboorteDatumTransformer.transform(datumNotFicief, attributeRuleProperties);
        assertThat(transformedDatum, is(datumNotFicief));
    }

    @Test
    public void given_fictieveDagIndatum_shouldBuildValidDatum() {
        String datumFicief = "20201100";
        String transformedDatum = fictieveGeboorteDatumTransformer.transform(datumFicief, attributeRuleProperties);
        assertThat(transformedDatum, is("20201116"));
    }

    @Test
    public void given_fictieveMaandIndatum_shouldBuildValidDatum() {
        String datumFicief = "20200025";
        String transformedDatum = fictieveGeboorteDatumTransformer.transform(datumFicief, attributeRuleProperties);
        assertThat(transformedDatum, is("20200725"));
    }

    @Test
    public void given_fictieveDagEnMaandIndatum_shouldBuildValidDatum() {
        String datumFicief = "20200000";
        String transformedDatum = fictieveGeboorteDatumTransformer.transform(datumFicief, attributeRuleProperties);
        assertThat(transformedDatum, is("20200701"));
    }

    @Test
    public void given_fictieveDagMaandJaarIndatum_shouldBuildValidDatum() {
        String datumFicief = "00000000";
        String transformedDatum = fictieveGeboorteDatumTransformer.transform(datumFicief, attributeRuleProperties);
        assertThat(transformedDatum, is("18500101"));
    }

    @Test
    public void given_empty_shouldReturnNull() {
        String datumFicief = "";
        String transformedDatum = fictieveGeboorteDatumTransformer.transform(datumFicief, attributeRuleProperties);
        assertThat(transformedDatum, is(nullValue()));
    }
}
