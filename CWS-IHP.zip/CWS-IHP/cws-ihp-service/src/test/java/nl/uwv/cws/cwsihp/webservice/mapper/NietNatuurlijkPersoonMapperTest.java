package nl.uwv.cws.cwsihp.webservice.mapper;

import nl.uwv.cws.cwsihp.model.hr.NietNatuurlijkPersoonHr;
import nl.uwv.cws.cwsihp.model.hr.RechtspersoonHr;
import nl.uwv.cws.cwsihp.model.hr.VennootschapBuitenlandHr;
import nl.uwv.cws.cwsihp.model.ihp.NietNatuurlijkPersoonIhp;
import nl.uwv.cws.cwsihp.model.wg.NietNatuurlijkPersoonWg;
import nl.uwv.cws.common.webservice.rule.CwsRuleExecutor;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Date;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
public class NietNatuurlijkPersoonMapperTest {

    @InjectMocks
    private NietNatuurlijkPersoonMapper nietNatuurlijkPersoonMapper;

    @Mock
    private RechtspersoonMapper rechtspersoonMapper;

    @Mock
    private VennootschapBuitenlandMapper vennootschapBuitenlandMapper;

    @Mock
    private CwsRuleExecutor ruleExecutor;

    @Captor
    private ArgumentCaptor<Object> ihpFieldCaptor;

    @Captor
    private ArgumentCaptor<String> xsdFieldCaptor;

    @Test
    @DisplayName("Given NietnatuurlijkPersoonHr test mapping fields to JaxB is successful")
    public void testMapToJaxbNietNatuurlijkPersoonHr() {
        NietNatuurlijkPersoonIhp nietNatuurlijkPersoonIhp = createNietNatuurlijkPersoonIhpForHr();
        nietNatuurlijkPersoonMapper.mapToJaxbNietNatuurlijkPersoon(nietNatuurlijkPersoonIhp);

        verify(ruleExecutor, times(6)).setTransformedValue(any(Object.class), xsdFieldCaptor.capture(), ihpFieldCaptor.capture());
        List<String> hrFieldValues = Arrays.asList("999999990","20200101","1", "20200131", "2", "VolledigeNaam");
        List<String> xsdFieldValues = Arrays.asList("rsin", "datBNietNatuurlijkPersoon", "cdFictieveDatB", "datENietNatuurlijkPersoon",
                "cdFictieveDatE", "volledigeNmNietNatuurlijkPersoon");
        assertArrayEquals(hrFieldValues.toArray(), ihpFieldCaptor.getAllValues().toArray());
        assertEquals(xsdFieldValues, xsdFieldCaptor.getAllValues());
    }

    @Test
    @DisplayName("Given NietnatuurlijkPersoonWg test mapping fields to JaxB is successful")
    public void testMapToJaxbNietNatuurlijkPersoonWg() {
        NietNatuurlijkPersoonIhp nietNatuurlijkPersoonIhp = createNietNatuurlijkPersoonIhpForWg();
        nietNatuurlijkPersoonMapper.mapToJaxbNietNatuurlijkPersoon(nietNatuurlijkPersoonIhp);

        verify(ruleExecutor, times(4)).setTransformedValue(any(Object.class), xsdFieldCaptor.capture(), ihpFieldCaptor.capture());
        List<String> hrFieldValues = Arrays.asList("999999990","20200101", "20200131", "naamVanNnp");
        List<String> xsdFieldValues = Arrays.asList("rsin", "datOprichtingRechtspSamenwerking", "datOntbindingRechtspSamenwerking",
               "volledigeNmNietNatuurlijkPersoon");
        assertArrayEquals(hrFieldValues.toArray(), ihpFieldCaptor.getAllValues().toArray());
        assertEquals(xsdFieldValues, xsdFieldCaptor.getAllValues());
    }

    @Test
    @DisplayName("Given NietNatuurlijkPersoonIhp with Rechtspersoon verify rechtspersoonMapper is called")
    public void testMapToJaxbNietNatuurlijkPersoonWithRechtspersoon() {
        NietNatuurlijkPersoonIhp nietNatuurlijkPersoonIhp = createNietNatuurlijkPersoonIhpForHr();

        RechtspersoonHr rechtspersoonHr = createRechtspersoon();
        NietNatuurlijkPersoonHr nietNatuurlijkPersoonHr = NietNatuurlijkPersoonHr.builder().rechtspersoonHr(rechtspersoonHr).build();
        nietNatuurlijkPersoonIhp.setNietNatuurlijkPersoonHr(nietNatuurlijkPersoonHr);

        nietNatuurlijkPersoonMapper.mapToJaxbNietNatuurlijkPersoon(nietNatuurlijkPersoonIhp);

        verify(rechtspersoonMapper,times(1)).mapToJaxbRechtspersoon(any(RechtspersoonHr.class));
    }

    @Test
    @DisplayName("Given NietNatuurlijkPersoonIhp with VennootschapBuitenland verify vennootschapBuitenlandMapper is called")
    public void testMapToJaxbNietNatuurlijkPersoonWithVennootschapBuitenland() {
        NietNatuurlijkPersoonIhp nietNatuurlijkPersoonIhp = createNietNatuurlijkPersoonIhpForHr();

        VennootschapBuitenlandHr vennootschapBuitenlandHr = createVennootschapBuitenland();
        NietNatuurlijkPersoonHr nietNatuurlijkPersoonHr = NietNatuurlijkPersoonHr.builder().vennootschapBuitenlandHr(vennootschapBuitenlandHr).build();
        nietNatuurlijkPersoonIhp.setNietNatuurlijkPersoonHr(nietNatuurlijkPersoonHr);

        nietNatuurlijkPersoonMapper.mapToJaxbNietNatuurlijkPersoon(nietNatuurlijkPersoonIhp);

        verify(vennootschapBuitenlandMapper,times(1)).mapToJaxbVennootschapBuitenland(any(VennootschapBuitenlandHr.class));
    }

    private NietNatuurlijkPersoonIhp createNietNatuurlijkPersoonIhpForHr() {
        NietNatuurlijkPersoonHr nietNatuurlijkPersoonHr = NietNatuurlijkPersoonHr.builder()
                .rsin(999999990)
                .datumAanvangNietNatuurlijkPersoon(Date.valueOf(LocalDate.of(2020,1,1)))
                .codeFictieveDatumAanvang(1)
                .datumEindeNietNatuurlijkPersoon(Date.valueOf(LocalDate.of(2020,1,31)))
                .codeFictieveDatumEinde(2)
                .volledigeNaamNietNatuurlijkPersoon("VolledigeNaam")
                .build();

        return NietNatuurlijkPersoonIhp.builder()
                .nietNatuurlijkPersoonHr(nietNatuurlijkPersoonHr)
                .build();
    }

    private RechtspersoonHr createRechtspersoon() {
        return RechtspersoonHr.builder()
                .activiteitId(1L)
                .statutaireZetel("a")
                .datumAanvangStatutaireZetel(Date.valueOf(LocalDate.of(1970,1,1)))
                .codeFictieveDatumAanvang(1).build();
    }

    private VennootschapBuitenlandHr createVennootschapBuitenland() {
        return VennootschapBuitenlandHr.builder()
                .datumAanvangVennootschapBuitenland(Date.valueOf(LocalDate.of(1970,1,1)))
                .codeFictieveDatumAanvang(0)
                .datumEindeVennootschapBuitenland(Date.valueOf(LocalDate.of(1970,1,1)))
                .codeFictieveDatumEinde(0)
                .build();
    }

    private NietNatuurlijkPersoonIhp createNietNatuurlijkPersoonIhpForWg() {
        NietNatuurlijkPersoonWg nietNatuurlijkPersoonWg = NietNatuurlijkPersoonWg.builder()
                .rsin(999999990)
                .datumOprichtingNietNatuurlijkPersoon(20200101L)
                .datumOntbindingNietNatuurlijkPersoon(20200131L)
                .naamNietNatuurlijkPersoon("naamVanNnp")
                .build();

        return NietNatuurlijkPersoonIhp.builder()
                .nietNatuurlijkPersoonWg(nietNatuurlijkPersoonWg)
                .build();
    }
}
