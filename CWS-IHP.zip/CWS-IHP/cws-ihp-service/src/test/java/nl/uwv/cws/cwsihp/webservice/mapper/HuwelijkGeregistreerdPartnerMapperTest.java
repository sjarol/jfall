package nl.uwv.cws.cwsihp.webservice.mapper;

import nl.uwv.cws.cwsihp.model.ihp.HuwelijkGeregistreerdPartnerIhp;
import nl.uwv.cws.common.webservice.rule.CwsRuleExecutor;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
public class HuwelijkGeregistreerdPartnerMapperTest {
    @InjectMocks
    private HuwelijkGeregistreerdPartnerMapper huwelijkGeregistreerdPartnerMapper;

    @Mock
    private CwsRuleExecutor ruleExecutor;

    @Captor
    private ArgumentCaptor<Object> ihpFieldCaptor;

    @Captor
    private ArgumentCaptor<String> xsdFieldCaptor;

    @Test
    @DisplayName("Given HuwelijkGeregistreerdPartnerIhp test mapping fields to JaxB is successful")
    public void testMapToJaxb() {

        HuwelijkGeregistreerdPartnerIhp huwelijkGeregistreerdPartnerIhp = createHuwelijkGeregistreerdPartner();
        huwelijkGeregistreerdPartnerMapper.mapToJaxbHuwelijkGeregistreerdPartner(huwelijkGeregistreerdPartnerIhp);

        verify(ruleExecutor, times(2)).setTransformedValue(any(Object.class), xsdFieldCaptor.capture(), ihpFieldCaptor.capture());
        List<Object> hrFieldValues = Arrays.asList("VoorvoegselPartner", "GeslachtsnaamPartner");
        List<String> xsdFieldValues = Arrays.asList("voorvoegselEchtgenoot", "significantDeelAchternaamEchtg");

        assertArrayEquals(hrFieldValues.toArray(), ihpFieldCaptor.getAllValues().toArray());
        assertEquals(xsdFieldValues, xsdFieldCaptor.getAllValues());
    }

    private HuwelijkGeregistreerdPartnerIhp createHuwelijkGeregistreerdPartner() {
        return HuwelijkGeregistreerdPartnerIhp.builder()
                .voorvoegselGeslachtsnaamPartner("VoorvoegselPartner")
                .geslachtsnaamPartner("GeslachtsnaamPartner")
                .build();
    }
}
