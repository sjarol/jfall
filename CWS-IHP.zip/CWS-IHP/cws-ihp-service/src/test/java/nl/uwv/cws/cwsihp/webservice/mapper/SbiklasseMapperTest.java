package nl.uwv.cws.cwsihp.webservice.mapper;

import nl.uwv.cws.cwsihp.model.hr.SbiklasseHr;
import nl.uwv.cws.common.webservice.rule.CwsRuleExecutor;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0007.CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.Sbiklasse;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Date;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
public class SbiklasseMapperTest {

    @InjectMocks
    private SbiklasseMapper sbiklasseMapper;

    @Mock
    private CwsRuleExecutor ruleExecutor;

    @Captor
    private ArgumentCaptor<String> sbiFieldCaptor;

    @Captor
    private ArgumentCaptor<String> xsdFieldCaptor;

    @Test
    @DisplayName("Given SbiklasseHr test mapping fields to JaxB Sbiklasse Maatschappelijkeactiviteit is successful")
    public void testMapToJaxbSbiKlasse() {
        SbiklasseHr sbiklasseHr = createSbiKlasseHr();
        sbiklasseMapper.mapToJaxbSbiklasseMaatschappelijkeActiviteit(sbiklasseHr);

        verify(ruleExecutor, times(7)).setTransformedValue(any(Sbiklasse.class), xsdFieldCaptor.capture(), sbiFieldCaptor.capture());
        // De "J" (danwel "N") moet omgezet worden naar "1" (respectievelijk "2") d.m.v. een rule,
        // maar dit lijkt hier niet uitgevoerd te worden. Daarom hier de waarde "J" in de test.
        // Er is een aparte unit test voor de J/N naar 1/2 conversie. */
        List<String> sbiFieldValues = Arrays.asList( "codeSbi","omschrijvingSbi","J","20180201","0", "20190201", "0");
        List<String> xsdFieldValues = Arrays.asList("cdSbi","omsSbi","indSbiHoofdactiviteit", "datBSbiactiviteit", "cdFictieveDatB", "datESbiactiviteit", "cdFictieveDatE");

        assertArrayEquals(sbiFieldValues.toArray(), sbiFieldCaptor.getAllValues().toArray());
        assertEquals(xsdFieldValues, xsdFieldCaptor.getAllValues());
    }

    @Test
    @DisplayName("Given SbiklasseHr WithoutDates test mapping fields to JaxB Sbiklasse is successful")
    public void testMapToJaxbOndernemingVestigingHandelsregisteWithoutDatesr() {
        SbiklasseHr sbiklasseHr = createSbiKlasseHrWithoutDates();
        sbiklasseMapper.mapToJaxbSbiklasseMaatschappelijkeActiviteit(sbiklasseHr);

        verify(ruleExecutor, times(7)).setTransformedValue(any(Sbiklasse.class), xsdFieldCaptor.capture(), sbiFieldCaptor.capture());
        // De "J" (danwel "N") moet omgezet worden naar "1" (respectievelijk "2") d.m.v. een rule,
        // maar dit lijkt hier niet uitgevoerd te worden. Daarom hier de waarde "J" in de test.
        // Er is een aparte unit test voor de J/N naar 1/2 conversie. */
        List<String> hrFieldValues = Arrays.asList( "codeSbi","omschrijvingSbi","J",null,null, null, null);
        List<String> xsdFieldValues = Arrays.asList("cdSbi","omsSbi","indSbiHoofdactiviteit", "datBSbiactiviteit", "cdFictieveDatB", "datESbiactiviteit", "cdFictieveDatE");

        assertArrayEquals(hrFieldValues.toArray(), sbiFieldCaptor.getAllValues().toArray());
        assertEquals(xsdFieldValues, xsdFieldCaptor.getAllValues());
    }


    private SbiklasseHr createSbiKlasseHr() {
        return SbiklasseHr.builder()
                .codeSbi("codeSbi")
                .omschrijvingSbi("omschrijvingSbi")
                .indicatieSbiHoofdactiviteit("J")
                .datumAanvangSbiActiviteit(Date.valueOf(LocalDate.of(2018, 2, 1)))
                .codeFictieveDatumAanvang(0)
                .datumEindeSbiActiviteit(Date.valueOf(LocalDate.of(2019, 2, 1)))
                .codeFictieveDatumEinde(0)
                .build();
    }

    private SbiklasseHr createSbiKlasseHrWithoutDates() {
        return SbiklasseHr.builder()
                .codeSbi("codeSbi")
                .omschrijvingSbi("omschrijvingSbi")
                .indicatieSbiHoofdactiviteit("J")
                .datumAanvangSbiActiviteit(null)
                .codeFictieveDatumAanvang(0)
                .datumEindeSbiActiviteit(null)
                .codeFictieveDatumEinde(0)
                .build();
    }
}
