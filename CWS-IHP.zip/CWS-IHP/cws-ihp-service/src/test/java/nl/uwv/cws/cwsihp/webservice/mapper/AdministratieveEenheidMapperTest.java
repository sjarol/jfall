package nl.uwv.cws.cwsihp.webservice.mapper;

import nl.uwv.cws.cwsihp.model.wg.*;
import nl.uwv.cws.common.webservice.rule.CwsRuleExecutor;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
public class AdministratieveEenheidMapperTest {

    @InjectMocks
    private AdministratieveEenheidMapper administratieveEenheidMapper;

    @Mock
    private CwsRuleExecutor ruleExecutor;

    @Captor
    private ArgumentCaptor<String> wgFieldCaptor;

    @Captor
    private ArgumentCaptor<String> xsdFieldCaptor;

    @Mock
    private SectorRisicogroepMapper sectorRisicogroepMapper;

    @Mock
    private PremiepercentageIndividueelMapper premiepercentageIndividueelMapper;

    @Mock
    private EigenRisicoDragerMapper eigenRisicoDragerMapper;

    @Mock
    private AdreshoudingMapper adreshoudingMapper;

    @Mock
    private VoortzettingsrelatieOpvolgerMapper voortzettingsrelatieOpvolgerMapper;

    @Mock
    private VoortzettingsrelatieVoorgangerMapper voortzettingsrelatieVoorgangerMapper;

    @Mock
    private AangifteFrequentieAdministratieveEenheidMapper aangifteFrequentieAdministratieveEenheidMapper;

    @Mock
    private AansluitingsnummerBvMapper aansluitingsnummerBvMapper;

    @Test
    @DisplayName("Given AdministratieveEenheidWg test mapping fields to JaxB is successful")
    public void testMapToJaxbAdministratieveEenheid() {
        AdministratieveEenheidWg administratieveEenheidWg = createAdministratieveEenheidWg();
        administratieveEenheidMapper.mapToJaxbAdministratieveEenheid(administratieveEenheidWg);

        verify(ruleExecutor, times(4)).setTransformedValue(any(Object.class), xsdFieldCaptor.capture(), wgFieldCaptor.capture());
        List<String> wgFieldValues = Arrays.asList("999999990L01","naam administratieveEenheid","20210601", "20231201");
        List<String> xsdFieldValues = Arrays.asList("loonheffingennr", "naamAdminEenheid", "datBAdminEenheid", "datEAdminEenheid");
        assertArrayEquals(wgFieldValues.toArray(), wgFieldCaptor.getAllValues().toArray());
        assertEquals(xsdFieldValues, xsdFieldCaptor.getAllValues());
    }

    @Test
    @DisplayName("Given AdministratieveEenheidWg with SectorRisicogroep verify sectorRisicogroepMapper is called")
    public void testMapToJaxbAdministratieveEenheidWgWithSectorRisicogroep() {
        AdministratieveEenheidWg administratieveEenheidWg = createAdministratieveEenheidWg();
        SectorRisicogroepWg sectorRisicogroepWg = createSectorRisicogroepWg();
        administratieveEenheidWg.setSectorRisicogroepList(Arrays.asList(sectorRisicogroepWg));
        administratieveEenheidMapper.mapToJaxbAdministratieveEenheid(administratieveEenheidWg);

        verify(sectorRisicogroepMapper,times(1)).mapToJaxbSectorRisicogroep(any(SectorRisicogroepWg.class));
    }

    @Test
    @DisplayName("Given AdministratieveEenheidWg with PremiepercentageIndividueel verify premiepercentageIndividueelMapper is called")
    public void testMapToJaxbAdministratieveEenheidWgWithPremiepercentageIndividueel() {
        AdministratieveEenheidWg administratieveEenheidWg = createAdministratieveEenheidWg();
        PremiepercentageIndividueelWg premiepercentageIndividueelWg = createPremiepercentageIndividueelWg();
        administratieveEenheidWg.setPremiepercentageIndividueelList(Arrays.asList(premiepercentageIndividueelWg));
        administratieveEenheidMapper.mapToJaxbAdministratieveEenheid(administratieveEenheidWg);

        verify(premiepercentageIndividueelMapper,times(1)).mapToJaxbPremiepercentageIndividueel(any(PremiepercentageIndividueelWg.class));
    }

    @Test
    @DisplayName("Given AdministratieveEenheidWg with EigenRisicoDrager verify eigenRisicoDragerMapper is called")
    public void testMapToJaxbAdministratieveEenheidWgWithEigenRisicoDrager() {
        AdministratieveEenheidWg administratieveEenheidWg = createAdministratieveEenheidWg();
        EigenRisicoDragerWg eigenRisicoDragerWg = createEigenRisicoDragerWg();
        administratieveEenheidWg.setEigenRisicoDragerList(Arrays.asList(eigenRisicoDragerWg));
        administratieveEenheidMapper.mapToJaxbAdministratieveEenheid(administratieveEenheidWg);

        verify(eigenRisicoDragerMapper,times(1)).mapToJaxbEigenRisicoDrager(any(EigenRisicoDragerWg.class));
    }

    @Test
    @DisplayName("Given AdministratieveEenheidWg with Adreshouding verify adreshoudingMapper is called")
    public void testMapToJaxbAdministratieveEenheidWgWithAdreshouding() {
        AdministratieveEenheidWg administratieveEenheidWg = createAdministratieveEenheidWg();
        AdreshoudingWg adreshoudingWg = createAdreshoudingWg();
        administratieveEenheidWg.setAdreshouding(adreshoudingWg);
        administratieveEenheidMapper.mapToJaxbAdministratieveEenheid(administratieveEenheidWg);

        verify(adreshoudingMapper,times(1)).mapToJaxbAdresNederlandWg(any(AdresNederlandWg.class));
        verify(adreshoudingMapper,times(1)).mapToJaxbAdresBuitenlandWg(any(AdresBuitenlandWg.class));
        verify(adreshoudingMapper,times(1)).mapToJaxbAdresBuitenlandOngestructureerdWg(any(AdresBuitenlandOngestructureerdWg.class));
    }

    @Test
    @DisplayName("Given AdministratieveEenheidWg with VoortzettingsrelatieOpvolger verify voortzettingsrelatieOpvolgerMapper is called")
    public void testMapToJaxbAdministratieveEenheidWgWithVoortzettingsrelatieOpvolger() {
        AdministratieveEenheidWg administratieveEenheidWg = createAdministratieveEenheidWg();
        VoortzettingsrelatieOpvolgerWg voortzettingsrelatieOpvolgerWg = createVoortzettingsrelatieOpvolgerWg();
        administratieveEenheidWg.setVoortzettingsrelatieOpvolgerList(Arrays.asList(voortzettingsrelatieOpvolgerWg));
        administratieveEenheidMapper.mapToJaxbAdministratieveEenheid(administratieveEenheidWg);

        verify(voortzettingsrelatieOpvolgerMapper,times(1)).mapToJaxbVoortzettingsrelatieOpvolger(any(VoortzettingsrelatieOpvolgerWg.class));
    }

    @Test
    @DisplayName("Given AdministratieveEenheidWg with VoortzettingsrelatieVoorganger verify voortzettingsrelatieVoorgangerMapper is called")
    public void testMapToJaxbAdministratieveEenheidWgWithVoortzettingsrelatieVoorganger() {
        AdministratieveEenheidWg administratieveEenheidWg = createAdministratieveEenheidWg();
        VoortzettingsrelatieVoorgangerWg voortzettingsrelatieVoorgangerWg = createVoortzettingsrelatieVoorgangerWg();
        administratieveEenheidWg.setVoortzettingsrelatieVoorgangerList(Arrays.asList(voortzettingsrelatieVoorgangerWg));
        administratieveEenheidMapper.mapToJaxbAdministratieveEenheid(administratieveEenheidWg);

        verify(voortzettingsrelatieVoorgangerMapper,times(1)).mapToJaxbVoortzettingsrelatieVoorganger(any(VoortzettingsrelatieVoorgangerWg.class));
    }

    @Test
    @DisplayName("Given AdministratieveEenheidWg with AangifteFrequentieAdministratieveEenheid verify aangifteFrequentieAdministratieveEenheidMapper is called")
    public void testMapToJaxbAdministratieveEenheidWgWithAangifteFrequentieAdministratieveEenheid() {
        AdministratieveEenheidWg administratieveEenheidWg = createAdministratieveEenheidWg();
        AangifteFrequentieAdministratieveEenheidWg aangifteFrequentieAdministratieveEenheidWg = createAangifteFrequentieAdministratieveEenheidWg();
        administratieveEenheidWg.setAangiftefrequentieAdministratieveEenheidList(Arrays.asList(aangifteFrequentieAdministratieveEenheidWg));
        administratieveEenheidMapper.mapToJaxbAdministratieveEenheid(administratieveEenheidWg);

        verify(aangifteFrequentieAdministratieveEenheidMapper,times(1)).mapToJaxbAangifteFrequentieAdministratieveEenheid(any(AangifteFrequentieAdministratieveEenheidWg.class));
    }

    @Test
    @DisplayName("Given AdministratieveEenheidWg with AansluitingsnummerBv verify aansluitingsnummerBvMapper is called")
    public void testMapToJaxbAdministratieveEenheidWgWithAansluitingsnummerBv() {
        AdministratieveEenheidWg administratieveEenheidWg = createAdministratieveEenheidWg();
        AansluitingsnummerBvWg aansluitingsnummerBvWg = createAansluitingsnummerBvWg();
        administratieveEenheidWg.setAansluitingsnummerBvList(Arrays.asList(aansluitingsnummerBvWg));
        administratieveEenheidMapper.mapToJaxbAdministratieveEenheid(administratieveEenheidWg);

        verify(aansluitingsnummerBvMapper,times(1)).mapToJaxbAansluitingsnummerBv(any(AansluitingsnummerBvWg.class));
    }

    private SectorRisicogroepWg createSectorRisicogroepWg() {
        return SectorRisicogroepWg.builder().build();
    }

    private PremiepercentageIndividueelWg createPremiepercentageIndividueelWg() {
        return PremiepercentageIndividueelWg.builder().build();
    }

    private EigenRisicoDragerWg createEigenRisicoDragerWg() {
        return EigenRisicoDragerWg.builder().build();
    }

    private AdreshoudingWg createAdreshoudingWg() {
        return AdreshoudingWg.builder()
                .adresNederlandWgList(Arrays.asList(AdresNederlandWg.builder().build()))
                .adresBuitenlandWgList(Arrays.asList(AdresBuitenlandWg.builder().build()))
                .adresBuitenlandOngestructureerdWgList(Arrays.asList(AdresBuitenlandOngestructureerdWg.builder().build()))
                .build();
    }

    private VoortzettingsrelatieOpvolgerWg createVoortzettingsrelatieOpvolgerWg() {
        return VoortzettingsrelatieOpvolgerWg.builder().build();
    }

    private VoortzettingsrelatieVoorgangerWg createVoortzettingsrelatieVoorgangerWg() {
        return VoortzettingsrelatieVoorgangerWg.builder().build();
    }

    private AangifteFrequentieAdministratieveEenheidWg createAangifteFrequentieAdministratieveEenheidWg() {
        return AangifteFrequentieAdministratieveEenheidWg.builder().build();
    }

    private AansluitingsnummerBvWg createAansluitingsnummerBvWg() {
        return AansluitingsnummerBvWg.builder().build();
    }

    private AdministratieveEenheidWg createAdministratieveEenheidWg() {
        return AdministratieveEenheidWg.builder()
                .loonheffingennummer("999999990L01")
                .naamAdministratieveEenheid("naam administratieveEenheid")
                .datumAanvangAdministratieveEenheid(20210601L)
                .datumEindeAdministratieveEenheid(20231201L)
                .sectorRisicogroepList(Arrays.asList(createSectorRisicogroepWg()))
                .premiepercentageIndividueelList(Arrays.asList(createPremiepercentageIndividueelWg()))
                .eigenRisicoDragerList(Arrays.asList(createEigenRisicoDragerWg()))
                .adreshouding(createAdreshoudingWg())
                .voortzettingsrelatieOpvolgerList(Arrays.asList(createVoortzettingsrelatieOpvolgerWg()))
                .voortzettingsrelatieVoorgangerList(Arrays.asList(createVoortzettingsrelatieVoorgangerWg()))
                .aangiftefrequentieAdministratieveEenheidList(Arrays.asList(createAangifteFrequentieAdministratieveEenheidWg()))
                .aansluitingsnummerBvList(Arrays.asList(createAansluitingsnummerBvWg()))
                .build();
    }
}
