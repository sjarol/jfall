package nl.uwv.cws.cwsihp;

import nl.uwv.cws.common.webservice.WebserviceHeaderProcessingHelper;
import nl.uwv.cws.cwsihp.orchestration.InhoudingsplichtigeOrchestration;
import nl.uwv.cws.cwsihp.webservice.CwsInhoudingsplichtigeWebService;
import nl.uwv.cws.cwsihp.webservice.RequestValidator;
import nl.uwv.cws.cwsihp.webservice.CwsIhpRequestProcessingHelper;
import nl.uwv.cws.cwsihp.webservice.mapper.ResponseMapper;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigerequest_v0007.CwsInhoudingsplichtigeRequest;
import nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0007.CwsInhoudingsplichtigeResponse;
import nl.uwv.schemas.uwvml.header_v0202.UwvMLHeader;
import nl.uwv.schemas.uwvml.services.cwsinhoudingsplichtige_v0007.Fault;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import javax.xml.ws.Holder;
import javax.xml.ws.WebServiceContext;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;

@ExtendWith(MockitoExtension.class)
public class CwsInhoudingsplichtigeWebServiceTest {

    @InjectMocks
    private CwsInhoudingsplichtigeWebService cwsInhoudingsplichtigeWebService;

    @Mock
    private WebServiceContext webServiceContext;

    @Mock
    private InhoudingsplichtigeOrchestration inhoudingsplichtigeOrchestration;

    @Mock
    private RequestValidator requestValidator;

    @Mock
    private ResponseMapper responseMapper;

    @Mock
    private CwsIhpRequestProcessingHelper messageProcessingHelper;

    @Mock
    private WebserviceHeaderProcessingHelper webserviceHeaderProcessingHelper;

    @Test
    @DisplayName("Given incoming Soap request should successfully construct a response")
    public void testUwvMLCwsInhoudingsplichtige() throws Fault {
        CwsInhoudingsplichtigeRequest request = new CwsInhoudingsplichtigeRequest();
        CwsInhoudingsplichtigeRequest.Gegevensvraag gegevensvraag = new CwsInhoudingsplichtigeRequest.Gegevensvraag();
        CwsInhoudingsplichtigeRequest.Gegevensvraag.WerkgeverKvk werkgeverKvk = new CwsInhoudingsplichtigeRequest.Gegevensvraag.WerkgeverKvk();
        werkgeverKvk.setKvkNr("999999999");
        gegevensvraag.setWerkgeverKvk(werkgeverKvk);
        request.setGegevensvraag(gegevensvraag);

        UwvMLHeader uwvMLHeader = new UwvMLHeader();
        Holder<UwvMLHeader> holder = new Holder<UwvMLHeader>(uwvMLHeader);
        CwsInhoudingsplichtigeResponse cwsInhoudingsplichtigeResponse = cwsInhoudingsplichtigeWebService.uwvMLCwsInhoudingsplichtige(request, holder);

        assertThat(cwsInhoudingsplichtigeResponse, is(notNullValue()));
    }
}
