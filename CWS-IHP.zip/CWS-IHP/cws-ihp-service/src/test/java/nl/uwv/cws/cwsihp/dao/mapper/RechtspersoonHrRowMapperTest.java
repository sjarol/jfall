package nl.uwv.cws.cwsihp.dao.mapper;

import nl.uwv.cws.cwsihp.model.hr.RechtspersoonHr;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.Mockito.when;

@TestInstance(Lifecycle.PER_CLASS)
@ExtendWith(MockitoExtension.class)
public class RechtspersoonHrRowMapperTest {

    @InjectMocks
    private RechtspersoonHrRowMapper rechtspersoonHrRowMapper;

    @Mock
    private ResultSet resultSet;

    @BeforeEach
    public void setup() throws SQLException {
        when(resultSet.getObject("CD_AANVANG_STATUTAIREZETEL_CGM")).thenReturn(1);
    }

    @Test
    @DisplayName("Should successfully map fields for RechtspersoonHr")
    public void testMapRow() throws SQLException {
        when(resultSet.getString("STATUTAIREZETEL")).thenReturn("Statutaire zetel");
        when(resultSet.getDate("AANVANG_STATUTAIREZETEL_CGM")).thenReturn(Date.valueOf(LocalDate.of(2020,1,1)));
        when(resultSet.getInt("CD_AANVANG_STATUTAIREZETEL_CGM")).thenReturn(1);

        List<String> attributen = Arrays.asList("STATUTAIREZETEL", "AANVANG_STATUTAIREZETEL_CGM", "CD_AANVANG_STATUTAIREZETEL_CGM");

        RechtspersoonHr rechtspersoonHr = rechtspersoonHrRowMapper.mapRow(resultSet, attributen);
        assertThat(rechtspersoonHr, is(notNullValue()));
        assertThat(rechtspersoonHr.getStatutaireZetel(), is(equalTo("Statutaire zetel")));
        assertThat(rechtspersoonHr.getDatumAanvangStatutaireZetel(), is(Date.valueOf(LocalDate.of(2020,1,1))));
        assertThat(rechtspersoonHr.getCodeFictieveDatumAanvang(), is(equalTo(1)));

    }
}
