package nl.uwv.cws.cwsihp.service;

import nl.uwv.cws.common.dao.configuratie.ConfiguratieAttribuutDao;
import nl.uwv.cws.common.dao.configuratie.ConfiguratieDao;
import nl.uwv.cws.common.model.configuratie.Configuratie;
import nl.uwv.cws.common.model.configuratie.ConfiguratieAttribuut;
import nl.uwv.cws.common.model.configuratie.ConfiguratieKey;
import nl.uwv.cws.common.service.ConfiguratieService;
import nl.uwv.cws.cwsihp.model.configuratie.CwsIhpConfiguratie;
import nl.uwv.cws.cwsihp.model.configuratie.ConfiguratieGroepenGegevens;
import nl.uwv.cws.cwsihp.model.configuratie.ConfiguratieSoortSelectie;
import nl.uwv.cws.cwsihp.model.configuratie.CwsIhpFilterType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.*;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
public class CwsIhpConfiguratieServiceTest {

    @InjectMocks
    private CwsIhpConfiguratieService cwsIhpConfiguratieService;

    @Mock
    private ConfiguratieService configuratieService;

    @Mock
    private ConfiguratieDao configuratieDao;

    @Mock
    private ConfiguratieAttribuutDao configuratieAttribuutDao;

    @BeforeEach
    void setUp() {
    }

    @Test
    @DisplayName("Should map right fields to right attributes")
    public void givenconfiguratieKey_shouldMapRightFields() {
        Configuratie configuratie = new Configuratie();
        configuratie.setCconId(1L);
        Mockito.when(configuratieService.findByConfiguratieKey(any())).thenReturn(configuratie);

        Map<String,String> filterKeyMap = createFilterKeyMap();
        Mockito.when(configuratieDao.findFilterKeyValuesByCconIdAndLevCd(anyLong(), anyString())).thenReturn(filterKeyMap);

        List<ConfiguratieAttribuut> configuratieAttribuutList = createConfiguratieAttribuut();
        Mockito.when(configuratieAttribuutDao.findByCconId(anyLong())).thenReturn(configuratieAttribuutList);

        ConfiguratieKey configuratieKey = ConfiguratieKey.builder()
                .contractNummer("1234")
                .contractStartDate("20200101")
                .versie("1")
                .build();
        CwsIhpConfiguratie cwsIhpConfiguratie = cwsIhpConfiguratieService.getConfiguratie(configuratieKey);
        ConfiguratieGroepenGegevens groepenGegevens = cwsIhpConfiguratie.getGroepenGegevens();
        ConfiguratieSoortSelectie soortSelectie = cwsIhpConfiguratie.getSoortSelectie();

        assertThat(groepenGegevens, is(notNullValue()));
        assertThat(soortSelectie, is(notNullValue()));
        assertThat(soortSelectie.isBeeindigdAdresUitsluiten(), is(true));

        assertTrue(cwsIhpConfiguratie.excludeBeeindigdAdres());
        assertFalse(cwsIhpConfiguratie.requiresNietNatuurlijkPersoon() );
        assertFalse(cwsIhpConfiguratie.requiresRechtspersoon());
        assertFalse(cwsIhpConfiguratie.requiresActiviteitHandelsregisterRechtspersoon());
        assertFalse(cwsIhpConfiguratie.requiresVennootschapBuitenland());
        assertFalse(cwsIhpConfiguratie.requiresAnyNatuurlijkPersoon());
        assertFalse(cwsIhpConfiguratie.requiresNatuurlijkPersoon());
        assertFalse(cwsIhpConfiguratie.requiresHuwelijkGeregistreerdPartnerschap());
        assertFalse(cwsIhpConfiguratie.requiresPersoonHandelsregister());
        assertFalse(cwsIhpConfiguratie.requiresRechtsvorm());
        assertFalse(cwsIhpConfiguratie.requiresFaillissementSurseance());
        assertFalse(cwsIhpConfiguratie.requiresGemoedsbezwaardheid());
        assertFalse(cwsIhpConfiguratie.requiresAnyAdresNederlandPersoon());
        assertFalse(cwsIhpConfiguratie.requiresAdresNederlandPersoon());
        assertFalse(cwsIhpConfiguratie.requiresStraatadresNederlandPersoon());
        assertFalse(cwsIhpConfiguratie.requiresPostbusadresNederlandPersoon());
        assertFalse(cwsIhpConfiguratie.requiresAnyAdresBuitenlandPersoon());
        assertFalse(cwsIhpConfiguratie.requiresAdresBuitenlandPersoon());
        assertFalse(cwsIhpConfiguratie.requiresStraatadresBuitenlandPersoon());
        assertFalse(cwsIhpConfiguratie.requiresPostbusadresBuitenlandPersoon());
        assertFalse(cwsIhpConfiguratie.requiresAdresBuitenlandOngestructureerdPersoon());
        assertTrue(cwsIhpConfiguratie.requiresMaatschappelijkeActiviteit());
        assertFalse(cwsIhpConfiguratie.requiresSbiklasseMaatschappelijkeActiviteit());
        assertFalse(cwsIhpConfiguratie.requiresVestigingHandelsregister());
        assertFalse(cwsIhpConfiguratie.requiresAnyAdresNederlandVestigingHandelsregister());
        assertFalse(cwsIhpConfiguratie.requiresAdresNederlandVestigingHandelsregister());
        assertFalse(cwsIhpConfiguratie.requiresStraatadresNederlandVestigingHandelsregister());
        assertFalse(cwsIhpConfiguratie.requiresPostbusadresNederlandVestigingHandelsregister());
        assertFalse(cwsIhpConfiguratie.requiresAnyAdresBuitenlandVestigingHandelsregister());
        assertFalse(cwsIhpConfiguratie.requiresAdresBuitenlandVestigingHandelsregister());
        assertFalse(cwsIhpConfiguratie.requiresStraatadresBuitenlandVestigingHandelsregister());
        assertFalse(cwsIhpConfiguratie.requiresPostbusadresBuitenlandVestigingHandelsregister());
        assertFalse(cwsIhpConfiguratie.requiresAdresBuitenlandOngestructureerdVestigingHandelsregister());
        assertFalse(cwsIhpConfiguratie.requiresActiviteitHandelsregisterVestigingHandelsregister());
        assertFalse(cwsIhpConfiguratie.requiresSbiklasseActiviteitHandelsregister());
        assertFalse(cwsIhpConfiguratie.requiresOnderneming());
        assertFalse(cwsIhpConfiguratie.requiresSbiklasseOnderneming());
        assertFalse(cwsIhpConfiguratie.requiresHandelsnaamOnderneming());
        assertFalse(cwsIhpConfiguratie.requiresHandelsnaamVestigingHandelsregister());
        assertFalse(cwsIhpConfiguratie.requiresAdministratieveEenheid());
        assertFalse(cwsIhpConfiguratie.requiresSectorRisicogroep());
        assertFalse(cwsIhpConfiguratie.requiresPremiepercentageIndividueel());
        assertFalse(cwsIhpConfiguratie.requiresEigenRisicoDrager());
        assertFalse(cwsIhpConfiguratie.requiresAnyAdresNederlandWg());
        assertFalse(cwsIhpConfiguratie.requiresAdresNederlandWg());
        assertFalse(cwsIhpConfiguratie.requiresStraatadresNederlandWg());
        assertFalse(cwsIhpConfiguratie.requiresPostbusadresNederlandWg());
        assertFalse(cwsIhpConfiguratie.requiresAnyAdresBuitenlandWg());
        assertFalse(cwsIhpConfiguratie.requiresAdresBuitenlandWg());
        assertFalse(cwsIhpConfiguratie.requiresStraatadresBuitenlandWg());
        assertFalse(cwsIhpConfiguratie.requiresPostbusadresBuitenlandWg());
        assertFalse(cwsIhpConfiguratie.requiresAdresBuitenlandOngestructureerdWg());
        assertFalse(cwsIhpConfiguratie.requiresVoortzettingsrelatieOpvolger());
        assertFalse(cwsIhpConfiguratie.requiresVoortzettingsrelatieVoorganger());
        assertFalse(cwsIhpConfiguratie.requiresAangifteFrequentieAdministratieveEenheid());
        assertFalse(cwsIhpConfiguratie.requiresAansluitingsnummerBv());

        verify(configuratieService).validateFoundConfiguratie(any(CwsIhpConfiguratie.class));
    }

    private Map<String,String> createFilterKeyMap() {
        Map<String, String> filterKeyMap = new HashMap<>();
        filterKeyMap.put(CwsIhpFilterType.BEEINDIGD_ADRES_UITSLUITEN_IHP.name(), "J");

        return filterKeyMap;
    }

    private List<ConfiguratieAttribuut> createConfiguratieAttribuut() {
        ConfiguratieAttribuut configuratieAttribuutOne = new ConfiguratieAttribuut();
        configuratieAttribuutOne.setId("id_one");
        configuratieAttribuutOne.setTable("tabel_one");
        configuratieAttribuutOne.setColumn("column_one");
        configuratieAttribuutOne.setParentId("parentId_one");

        ConfiguratieAttribuut configuratieAttribuutTwo = new ConfiguratieAttribuut();
        configuratieAttribuutTwo.setId("id_two");
        configuratieAttribuutTwo.setTable("tabel_two");
        configuratieAttribuutTwo.setColumn("column_two");
        configuratieAttribuutTwo.setParentId(null);

        ConfiguratieAttribuut configuratieAttribuutChildOfTwo = new ConfiguratieAttribuut();
        configuratieAttribuutChildOfTwo.setId("id_three");
        configuratieAttribuutChildOfTwo.setTable("tabel_two_child");
        configuratieAttribuutChildOfTwo.setColumn("column_two_child");
        configuratieAttribuutChildOfTwo.setParentId("id_two");

        ConfiguratieAttribuut configuratieAttribuutChildOfChildOfTwo = new ConfiguratieAttribuut();
        configuratieAttribuutChildOfTwo.setId("id_four");
        configuratieAttribuutChildOfTwo.setTable("UH_MAATSCHAPPELIJKE_ACTIVITEIT");
        configuratieAttribuutChildOfTwo.setColumn("column_two_child");
        configuratieAttribuutChildOfTwo.setParentId("id_three");

        return Arrays.asList(configuratieAttribuutOne, configuratieAttribuutTwo, configuratieAttribuutChildOfTwo);
    }
}
