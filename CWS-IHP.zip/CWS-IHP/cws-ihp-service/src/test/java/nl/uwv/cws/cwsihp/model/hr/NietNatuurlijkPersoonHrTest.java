package nl.uwv.cws.cwsihp.model.hr;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class NietNatuurlijkPersoonHrTest {

    @Test
    @DisplayName("Rechtspersoon should return true")
    public void test_isRechtspersoon() {
        NietNatuurlijkPersoonHr nietNatuurlijkPersoonHr = NietNatuurlijkPersoonHr.builder().rechtspersoonId(123L).build();
        assertTrue(nietNatuurlijkPersoonHr.isRechtspersoon());
    }

    @Test
    @DisplayName("Rechtspersoon should return false")
    public void test_isNotPRechtspersoon() {
        NietNatuurlijkPersoonHr nietNatuurlijkPersoonHr = NietNatuurlijkPersoonHr.builder().rechtspersoonId(null).build();
        assertFalse(nietNatuurlijkPersoonHr.isRechtspersoon());
    }

    @Test
    @DisplayName("VennootschapBuitenland should return true")
    public void test_isVennootschapBuitenland() {
        NietNatuurlijkPersoonHr nietNatuurlijkPersoonHr = NietNatuurlijkPersoonHr.builder().buitenlandseVennootschapId(123L).build();
        assertTrue(nietNatuurlijkPersoonHr.isVennootschapBuitenland());
    }

    @Test
    @DisplayName("VennootschapBuitenland should return false")
    public void test_isNotVennootschapBuitenland() {
        NietNatuurlijkPersoonHr nietNatuurlijkPersoonHr = NietNatuurlijkPersoonHr.builder().buitenlandseVennootschapId(null).build();
        assertFalse(nietNatuurlijkPersoonHr.isVennootschapBuitenland());
    }
}
