package nl.uwv.cws.cwsihp.dao.mapper;

import nl.uwv.cws.cwsihp.model.hr.MaatschappelijkeActiviteitHr;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class MaatschappelijkeActiviteitHrRowMapperTest {

    @InjectMocks
    private MaatschappelijkeActiviteitHrRowMapper maatschappelijkeActiviteitRowMapper;

    @Mock
    private ResultSet resultSet;

    @Test
    @DisplayName("Should successfully set field of MaatschappelijkeActiviteitHr")
    public void testMapRow() throws SQLException {
        when(resultSet.getString("KVK_NUMMER")).thenReturn("123456789");
        when(resultSet.getDate("DATUM_AANVANG_CGM")).thenReturn(Date.valueOf(LocalDate.of(2020,1,1)));
        when(resultSet.getObject("CD_DATUM_AANVANG_CGM")).thenReturn(1);
        when(resultSet.getInt("CD_DATUM_AANVANG_CGM")).thenReturn(1);
        when(resultSet.getDate("DATUM_EINDE_CGM")).thenReturn(Date.valueOf(LocalDate.of(2020,1,31)));
        when(resultSet.getObject("CD_DATUM_EINDE_CGM")).thenReturn(1);
        when(resultSet.getInt("CD_DATUM_EINDE_CGM")).thenReturn(2);

        List<String> attributen = Arrays.asList("KVK_NUMMER", "DATUM_AANVANG_CGM",
                "CD_DATUM_AANVANG_CGM", "DATUM_EINDE_CGM", "CD_DATUM_EINDE_CGM");

        MaatschappelijkeActiviteitHr maatschappelijkeActiviteitHr = maatschappelijkeActiviteitRowMapper.mapRow(resultSet, attributen);
        assertThat(maatschappelijkeActiviteitHr.getKvkNummer(), is(equalTo("123456789")));
        assertThat(maatschappelijkeActiviteitHr.isConfigurationIncludesKvkNummer(), is(true));
        assertThat(maatschappelijkeActiviteitHr.getDatumAanvangMaatschappelijkeActiviteit(), is(Date.valueOf(LocalDate.of(2020,1,1))));
        assertThat(maatschappelijkeActiviteitHr.getCodeFictieveDatumAanvang(), is(equalTo(1)));
        assertThat(maatschappelijkeActiviteitHr.getDatumEindeMaatschappelijkeActiviteit(), is(Date.valueOf(LocalDate.of(2020,1,31))));
        assertThat(maatschappelijkeActiviteitHr.getCodeFictieveDatumEinde(), is(equalTo(2)));
    }
}
