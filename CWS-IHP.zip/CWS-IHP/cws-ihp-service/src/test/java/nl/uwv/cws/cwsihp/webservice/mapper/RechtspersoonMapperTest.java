package nl.uwv.cws.cwsihp.webservice.mapper;

import nl.uwv.cws.cwsihp.model.hr.*;
import nl.uwv.cws.common.webservice.rule.CwsRuleExecutor;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Date;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
public class RechtspersoonMapperTest {
    @InjectMocks
    private RechtspersoonMapper rechtspersoonMapper;

    @Mock
    private ActiviteitHandelsregisterMapper activiteitHandelsregisterMapper;

    @Mock
    private CwsRuleExecutor ruleExecutor;

    @Captor
    private ArgumentCaptor<Object> ihpFieldCaptor;

    @Captor
    private ArgumentCaptor<String> xsdFieldCaptor;

    @Test
    @DisplayName("Given RechtspersoonHr test mapping fields to JaxB is successful")
    public void testMapToJaxbRechtspersoon() {
        RechtspersoonHr rechtspersoonHr = createRechtspersoonHr();
        rechtspersoonMapper.mapToJaxbRechtspersoon(rechtspersoonHr);

        verify(ruleExecutor, times(3)).setTransformedValue(any(Object.class), xsdFieldCaptor.capture(), ihpFieldCaptor.capture());
        List<String> hrFieldValues = Arrays.asList("Statutaire zetel","20200101","1");
        List<String> xsdFieldValues = Arrays.asList("statutaireZetel", "datBStatutaireZetel", "cdFictieveDatB");
        assertArrayEquals(hrFieldValues.toArray(), ihpFieldCaptor.getAllValues().toArray());
        assertEquals(xsdFieldValues, xsdFieldCaptor.getAllValues());
    }

    @Test
    @DisplayName("Given RechtspersoonHr WithoutDate test mapping fields to JaxB is successful")
    public void testMapToJaxbRechtspersoonWithoutDate() {
        RechtspersoonHr rechtspersoonHr = createRechtspersoonHrWithoutDate();
        rechtspersoonMapper.mapToJaxbRechtspersoon(rechtspersoonHr);

        verify(ruleExecutor, times(3)).setTransformedValue(any(Object.class), xsdFieldCaptor.capture(), ihpFieldCaptor.capture());
        List<String> hrFieldValues = Arrays.asList("Statutaire zetel",null,null);
        List<String> xsdFieldValues = Arrays.asList("statutaireZetel", "datBStatutaireZetel", "cdFictieveDatB");
        assertArrayEquals(hrFieldValues.toArray(), ihpFieldCaptor.getAllValues().toArray());
        assertEquals(xsdFieldValues, xsdFieldCaptor.getAllValues());
    }

    @Test
    @DisplayName("Given RechtspersoonHr with ActiviteitHandelsregisterHr verify activiteitHandelsregisterMapper is called")
    public void testMapToJaxbRechtspersoonWithVestigingHandelsregisterHr() {
        RechtspersoonHr rechtspersoonHr = createRechtspersoonHr();

        ActiviteitHandelsregisterHr activiteitHandelsregisterHr = createActiviteitHandelsregisterHr();
        rechtspersoonHr.setActiviteitHandelsregisterHr(activiteitHandelsregisterHr);

        rechtspersoonMapper.mapToJaxbRechtspersoon(rechtspersoonHr);

        verify(activiteitHandelsregisterMapper,times(1)).mapToJaxbActiviteitHandelsregisterRechtspersoon(any(ActiviteitHandelsregisterHr.class));
    }

    private RechtspersoonHr createRechtspersoonHr() {

        return RechtspersoonHr.builder()
                .statutaireZetel("Statutaire zetel")
                .datumAanvangStatutaireZetel(Date.valueOf(LocalDate.of(2020,01,01)))
                .codeFictieveDatumAanvang(1)
                .build();
    }

    private RechtspersoonHr createRechtspersoonHrWithoutDate() {

        return RechtspersoonHr.builder()
                .statutaireZetel("Statutaire zetel")
                .datumAanvangStatutaireZetel(null)
                .codeFictieveDatumAanvang(1)
                .build();
    }

    private ActiviteitHandelsregisterHr createActiviteitHandelsregisterHr() {
        return ActiviteitHandelsregisterHr.builder()
                .build();
    }
}
