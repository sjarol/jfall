package nl.uwv.cws.cwsihp.webservice.rule.transformer;

import nl.uwv.cws.common.model.rule.AttributeRuleProperties;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static nl.uwv.cws.cwsihp.model.rule.CwsIhpAttributeRule.POSTCODE_NL_GEEN_SPATIE_OF_NULL;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;

public class PostcodeNlGeenSpatieOfNullTransformerTest {

    private PostcodeNlGeenSpatieOfNullTransformer postcodeNlGeenSpatieOfNullTransformer;
    private AttributeRuleProperties attributeRuleProperties;

    @BeforeEach
    public void setup() {
        postcodeNlGeenSpatieOfNullTransformer = new PostcodeNlGeenSpatieOfNullTransformer();
        attributeRuleProperties = new AttributeRuleProperties();
    }

    @Test
    @DisplayName("Should use correct rule type")
    public void givenValueShouldUseCorrectRuletype() {
        assertThat(postcodeNlGeenSpatieOfNullTransformer.getTransformRule(), is(POSTCODE_NL_GEEN_SPATIE_OF_NULL));
    }

    @Test
    @DisplayName("Should return original value when postcode format is correct")
    public void givenValueShouldApplyReturnPostcode() {
        String originalValue = "1000AA";
        String transformedValue = postcodeNlGeenSpatieOfNullTransformer.transform(originalValue, attributeRuleProperties);
        assertThat(transformedValue, is("1000AA"));
    }

    @Test
    @DisplayName("Should return transformed value when postcode format is correct")
    public void givenValueShouldTransformPostcode() {
        String originalValue = "1000 AA";
        String transformedValue = postcodeNlGeenSpatieOfNullTransformer.transform(originalValue, attributeRuleProperties);
        assertThat(transformedValue, is("1000AA"));
    }

    @Test
    @DisplayName("Should return null value when postcode format is incorrect")
    public void givenValueShouldShouldReturnNull() {
        String originalValue = "10000 AAA";
        String transformedValue = postcodeNlGeenSpatieOfNullTransformer.transform(originalValue, attributeRuleProperties);
        assertThat(transformedValue, is(nullValue()));
    }
}
