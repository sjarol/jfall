package nl.uwv.cws.cwsihp.dao.mapper;

import nl.uwv.cws.cwsihp.model.hr.HandelsnaamHr;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.Mockito.when;

@TestInstance(Lifecycle.PER_CLASS)
@ExtendWith(MockitoExtension.class)
public class HandelsnaamHrRowMapperTest {

    @InjectMocks
    private HandelsnaamHrRowMapper handelsnaamHrRowMapper;

    @Mock
    private ResultSet resultSet;

    @BeforeEach
    public void setup() throws SQLException {
        when(resultSet.getObject("VOLGORDE")).thenReturn(3);
        when(resultSet.getObject("CD_DATUM_AANVANG_CGM")).thenReturn(1);
        when(resultSet.getObject("CD_DATUM_EINDE_CGM")).thenReturn(2);
    }

    @Test
    @DisplayName("Should successfully map fields for HandelsnaamHr")
    public void testMapRow() throws SQLException {
        when(resultSet.getString("HANDELSNAAM")).thenReturn("handelsnaam");
        when(resultSet.getInt("VOLGORDE")).thenReturn(3);
        when(resultSet.getDate("DATUM_AANVANG_CGM")).thenReturn(Date.valueOf(LocalDate.of(2020,1,1)));
        when(resultSet.getInt("CD_DATUM_AANVANG_CGM")).thenReturn(1);
        when(resultSet.getDate("DATUM_EINDE_CGM")).thenReturn(Date.valueOf(LocalDate.of(2020,1,31)));
        when(resultSet.getInt("CD_DATUM_EINDE_CGM")).thenReturn(2);

        List<String> attributen = Arrays.asList("HANDELSNAAM","VOLGORDE","DATUM_AANVANG_CGM",
                "CD_DATUM_AANVANG_CGM", "DATUM_EINDE_CGM", "CD_DATUM_EINDE_CGM");

        HandelsnaamHr handelsnaamHr = handelsnaamHrRowMapper.mapRow(resultSet, attributen);
        assertThat(handelsnaamHr, is(notNullValue()));
        assertThat(handelsnaamHr.getNaam(), is("handelsnaam"));
        assertThat(handelsnaamHr.getVolgorde(), is(equalTo(3)));
        assertThat(handelsnaamHr.getDatumAanvangHandelsnaam(), is(Date.valueOf(LocalDate.of(2020,1,1))));
        assertThat(handelsnaamHr.getCodeFictieveDatumAanvang(), is(equalTo(1)));
        assertThat(handelsnaamHr.getDatumEindeHandelsnaam(), is(Date.valueOf(LocalDate.of(2020,1,31))));
        assertThat(handelsnaamHr.getCodeFictieveDatumEinde(), is(equalTo(2)));
    }
}
