package nl.uwv.cws.cwsihp.dao.mapper;

import nl.uwv.cws.cwsihp.model.hr.NatuurlijkPersoonHr;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.Mockito.when;

@TestInstance(Lifecycle.PER_CLASS)
@ExtendWith(MockitoExtension.class)
public class NatuurlijkPersoonHrRowMapperTest {

    @InjectMocks
    private NatuurlijkPersoonHrRowMapper natuurlijkPersoonHrRowMapper;

    @Mock
    private ResultSet resultSet;

    @Test
    @DisplayName("Should successfully map fields for NatuurlijkPersoon")
    public void testMapRow() throws SQLException {
        when(resultSet.getObject("BSN")).thenReturn(0);
        when(resultSet.getInt("BSN")).thenReturn(999999990);
        when(resultSet.getString("VOORLETTERS")).thenReturn("C");
        when(resultSet.getString("VOORNAMEN")).thenReturn("Voornamen");
        when(resultSet.getString("VOORVOEGSEL")).thenReturn("Voorvoegsel");
        when(resultSet.getString("ACHTERNAAM")).thenReturn("Achternaam");
        when(resultSet.getObject("CD_AANDUIDING_NAAMGEBRUIK_CGM")).thenReturn(2);
        when(resultSet.getInt("CD_AANDUIDING_NAAMGEBRUIK_CGM")).thenReturn(2);
        when(resultSet.getDate("GEBOORTEDATUM_CGM")).thenReturn(Date.valueOf(LocalDate.of(1970,1,1)));
        when(resultSet.getObject("CD_GEBOORTEDATUM_CGM")).thenReturn(0);
        when(resultSet.getInt("CD_GEBOORTEDATUM_CGM")).thenReturn(0);
        when(resultSet.getString("GESLACHT")).thenReturn("M");
        when(resultSet.getString("VOORV_GESLACHTSNM_PARTNER")).thenReturn("VoorvoegselPartner");
        when(resultSet.getString("GESLACHTSNAAMPARTNER")).thenReturn("GeslachtsnaamPartner");

        List<String> attributen = Arrays.asList("BSN", "VOORLETTERS", "VOORNAMEN",
                "VOORVOEGSEL", "ACHTERNAAM", "CD_AANDUIDING_NAAMGEBRUIK_CGM", "GEBOORTEDATUM_CGM", "CD_GEBOORTEDATUM_CGM",
                "GESLACHT", "VOORV_GESLACHTSNM_PARTNER", "GESLACHTSNAAMPARTNER");

        NatuurlijkPersoonHr natuurlijkPersoonHr = natuurlijkPersoonHrRowMapper.mapRow(resultSet, attributen);
        assertThat(natuurlijkPersoonHr, is(notNullValue()));
        assertThat(natuurlijkPersoonHr.getBurgerservicenummer(), is(equalTo(999999990)));
        assertThat(natuurlijkPersoonHr.getVoorletters(), is(equalTo("C")));
        assertThat(natuurlijkPersoonHr.getVoornamen(), is(equalTo("Voornamen")));
        assertThat(natuurlijkPersoonHr.getVoorvoegsel(), is(equalTo("Voorvoegsel")));
        assertThat(natuurlijkPersoonHr.getAchternaam(), is(equalTo("Achternaam")));
        assertThat(natuurlijkPersoonHr.getCodeAanduidingNaamgebruik(), is(equalTo(2)));
        assertThat(natuurlijkPersoonHr.getGeboorteDatum(), is(Date.valueOf(LocalDate.of(1970,1,1))));
        assertThat(natuurlijkPersoonHr.getCodeFictieveGeboortedatum(), is(equalTo(0)));
        assertThat(natuurlijkPersoonHr.getGeslacht(), is(equalTo("M")));

        assertThat(natuurlijkPersoonHr.getHuwelijkGeregistreerdPartnerIhp().getVoorvoegselGeslachtsnaamPartner(), is(equalTo("VoorvoegselPartner")));
        assertThat(natuurlijkPersoonHr.getHuwelijkGeregistreerdPartnerIhp().getGeslachtsnaamPartner(), is(equalTo("GeslachtsnaamPartner")));
    }
}
