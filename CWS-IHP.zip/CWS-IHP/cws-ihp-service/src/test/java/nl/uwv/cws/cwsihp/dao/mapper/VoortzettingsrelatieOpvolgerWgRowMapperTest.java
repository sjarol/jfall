package nl.uwv.cws.cwsihp.dao.mapper;

import nl.uwv.cws.cwsihp.model.wg.VoortzettingsrelatieOpvolgerWg;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.Mockito.when;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@ExtendWith(MockitoExtension.class)
public class VoortzettingsrelatieOpvolgerWgRowMapperTest {

    @InjectMocks
    private VoortzettingsrelatieOpvolgerWgRowMapper voortzettingsrelatieOpvolgerWgRowMapper;

    @Mock
    private ResultSet resultSet;

    @Test
    @DisplayName("Should successfully map fields for VoortzettingsrelatieOpvolgerWg")
    public void testMapRow() throws SQLException {
        when(resultSet.getObject("DAT_VOORTZET")).thenReturn(1);
        when(resultSet.getLong("DAT_VOORTZET")).thenReturn(20210101L);
        when(resultSet.getObject("PERC_VOORTZET")).thenReturn(1);
        when(resultSet.getDouble("PERC_VOORTZET")).thenReturn(100.00);
        when(resultSet.getString("LHNR_OPV")).thenReturn("123456789L01");

        List<String> attributen = Arrays.asList("DAT_VOORTZET", "PERC_VOORTZET", "LHNR_OPV");

        VoortzettingsrelatieOpvolgerWg voortzettingsrelatieOpvolgerWg = voortzettingsrelatieOpvolgerWgRowMapper.mapRow(resultSet, attributen);
        assertThat(voortzettingsrelatieOpvolgerWg, is(notNullValue()));
        assertThat(voortzettingsrelatieOpvolgerWg.getDatumAanvangVoortzettingsrelatieOpvolger(), is(equalTo(20210101L)));
        assertThat(voortzettingsrelatieOpvolgerWg.getPercentageLoonsomOvergegaan(), is(equalTo(100.00)));
        assertThat(voortzettingsrelatieOpvolgerWg.getLhnrOpvolger(), is(equalTo("123456789L01")));
    }
}
