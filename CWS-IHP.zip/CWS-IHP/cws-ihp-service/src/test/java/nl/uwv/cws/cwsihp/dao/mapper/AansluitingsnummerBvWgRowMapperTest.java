package nl.uwv.cws.cwsihp.dao.mapper;

import nl.uwv.cws.cwsihp.model.wg.AansluitingsnummerBvWg;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.Mockito.when;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@ExtendWith(MockitoExtension.class)
public class AansluitingsnummerBvWgRowMapperTest {

    @InjectMocks
    private AansluitingsnummerBvWgRowMapper aansluitingsnummerBvWgRowMapper;

    @Mock
    private ResultSet resultSet;

    @Test
    @DisplayName("Should successfully map fields for AansluitingsnummerBv")
    public void testMapRow() throws SQLException {
        when(resultSet.getObject("CODESECTOROSV")).thenReturn(1);
        when(resultSet.getLong("CODESECTOROSV")).thenReturn(57L);
        when(resultSet.getObject("RISICOPREMIEGROEP")).thenReturn(1);
        when(resultSet.getLong("RISICOPREMIEGROEP")).thenReturn(1L);
        when(resultSet.getObject("AANSLUITINGSNRBV")).thenReturn(1);
        when(resultSet.getLong("AANSLUITINGSNRBV")).thenReturn(123456789012345L);
        when(resultSet.getObject("DATAANV")).thenReturn(1);
        when(resultSet.getLong("DATAANV")).thenReturn(20210101L);

        List<String> attributen = Arrays.asList("CODESECTOROSV", "RISICOPREMIEGROEP", "AANSLUITINGSNRBV", "DATAANV");

        AansluitingsnummerBvWg aansluitingsnummerBvWg = aansluitingsnummerBvWgRowMapper.mapRow(resultSet, attributen);
        assertThat(aansluitingsnummerBvWg, is(notNullValue()));
        assertThat(aansluitingsnummerBvWg.getCodeSectorOsv(), is(equalTo(57L)));
        assertThat(aansluitingsnummerBvWg.getRisicoPremiegroep(), is(equalTo(1L)));
        assertThat(aansluitingsnummerBvWg.getAansluitingsnummerBv(), is(equalTo(123456789012345L)));
        assertThat(aansluitingsnummerBvWg.getDatumAanvangAansluitingsnummerBv(), is(equalTo(20210101L)));
    }
}
