package nl.uwv.cws.cwsihp.webservice.mapper;

import nl.uwv.cws.cwsihp.model.hr.*;
import nl.uwv.cws.cwsihp.model.wg.*;
import nl.uwv.cws.common.webservice.rule.CwsRuleExecutor;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigInteger;
import java.sql.Date;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
public class AdreshoudingMapperTest {
    @InjectMocks
    private AdreshoudingMapper adreshoudingMapper;

    @Mock
    private CwsRuleExecutor ruleExecutor;

    @Captor
    private ArgumentCaptor<Object> ihpFieldCaptor;

    @Captor
    private ArgumentCaptor<String> xsdFieldCaptor;

    @Test
    @DisplayName("Given Straatadres en Postadres AdresNederlandHr for Persoon verify mapping fields to JaxB is successful")
    public void testMapToJaxbStraatEnPostadresAdresNederlandPersoon() {
        AdresNederlandHr adresNederlandHr = createAdresNederlandWithStraatEnPostadres();
        adreshoudingMapper.mapToJaxbAdresNederlandUhrPersoon(adresNederlandHr);

        verify(ruleExecutor, times(17)).setTransformedValue(any(Object.class), xsdFieldCaptor.capture(), ihpFieldCaptor.capture());
        List<Object> hrFieldValues = Arrays.asList(null, null, null, null, null, null,
                "1000AA",
                "testWoonplaatsnaam",
                "testStraatnaam",
                BigInteger.valueOf(1),
                "B",
                "rood",
                "A",
                "testNaamOpenbareruimte",
                "1000AA",
                "testWoonplaatsnaam",
                BigInteger.valueOf(12345678));
        List<String> xsdFieldValues = Arrays.asList("cdAdresrol", "datBAdreshouding", "cdFictieveDatB", "datEAdreshouding", "cdFictieveDatE", "cdAfgeschermdAdres",
                "postcd",
                "woonplaatsnaam",
                "straatnaam",
                "huisnr",
                "huisletter",
                "huisnrtoevoeging",
                "cdAanduidingBijHuisnr",
                "naamOpenbareRuimte",
                "postcd",
                "woonplaatsnaam",
                "postbusnr");

        assertArrayEquals(hrFieldValues.toArray(), ihpFieldCaptor.getAllValues().toArray());
        assertEquals(xsdFieldValues, xsdFieldCaptor.getAllValues());
    }

    @Test
    @DisplayName("Given AdresNederlandHr for Persoon with DatumAanvag verify mapping fields to JaxB is successful")
    public void testMapToJaxbAdresNederlandPersoon() {
        AdresNederlandHr adresNederlandHr = createAdresNederlandWithDatumAanvang();
        adreshoudingMapper.mapToJaxbAdresNederlandUhrPersoon(adresNederlandHr);

        verify(ruleExecutor, times(17)).setTransformedValue(any(Object.class), xsdFieldCaptor.capture(), ihpFieldCaptor.capture());
        List<Object> ihpFieldValues = Arrays.asList("C", "20180201", "0", "20190201", "0", "1",
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null);
        List<String> xsdFieldValues = Arrays.asList("cdAdresrol", "datBAdreshouding", "cdFictieveDatB", "datEAdreshouding", "cdFictieveDatE", "cdAfgeschermdAdres",
                "postcd",
                "woonplaatsnaam",
                "straatnaam",
                "huisnr",
                "huisletter",
                "huisnrtoevoeging",
                "cdAanduidingBijHuisnr",
                "naamOpenbareRuimte",
                "postcd",
                "woonplaatsnaam",
                "postbusnr");

        assertArrayEquals(ihpFieldValues.toArray(), ihpFieldCaptor.getAllValues().toArray());
        assertEquals(xsdFieldValues, xsdFieldCaptor.getAllValues());
    }

    @Test
    @DisplayName("Given Straatadres en Postadres AdresNederlandHr for vestiging handelsregister verify mapping fields to JaxB is successful")
    public void testMapToJaxbStraatEnPostadresAdresNederlandVestigingHandelsregister() {
        AdresNederlandHr adresNederlandHr = createAdresNederlandWithStraatEnPostadres();
        adreshoudingMapper.mapToJaxbAdresNederlandUhrVestigingHandelsregister(adresNederlandHr);

        verify(ruleExecutor, times(17)).setTransformedValue(any(Object.class), xsdFieldCaptor.capture(), ihpFieldCaptor.capture());
        List<Object> hrFieldValues = Arrays.asList(null, null, null, null, null, null,
                "1000AA",
                "testWoonplaatsnaam",
                "testStraatnaam",
                BigInteger.valueOf(1),
                "B",
                "rood",
                "A",
                "testNaamOpenbareruimte",
                "1000AA",
                "testWoonplaatsnaam",
                BigInteger.valueOf(12345678));
        List<String> xsdFieldValues = Arrays.asList("cdAdresrol", "datBAdreshouding", "cdFictieveDatB", "datEAdreshouding", "cdFictieveDatE", "cdAfgeschermdAdres",
                "postcd",
                "woonplaatsnaam",
                "straatnaam",
                "huisnr",
                "huisletter",
                "huisnrtoevoeging",
                "cdAanduidingBijHuisnr",
                "naamOpenbareRuimte",
                "postcd",
                "woonplaatsnaam",
                "postbusnr");

        assertArrayEquals(hrFieldValues.toArray(), ihpFieldCaptor.getAllValues().toArray());
        assertEquals(xsdFieldValues, xsdFieldCaptor.getAllValues());
    }

    @Test
    @DisplayName("Given AdresNederlandHr for VestigingHandelsregister with DatumAanvag verify mapping fields to JaxB is successful")
    public void testMapToJaxbAdresNederlandVestigingHandelsregister() {
        AdresNederlandHr adresNederlandHr = createAdresNederlandWithDatumAanvang();
        adreshoudingMapper.mapToJaxbAdresNederlandUhrVestigingHandelsregister(adresNederlandHr);

        verify(ruleExecutor, times(17)).setTransformedValue(any(Object.class), xsdFieldCaptor.capture(), ihpFieldCaptor.capture());
        List<Object> ihpFieldValues = Arrays.asList("C", "20180201", "0", "20190201", "0", "1",
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null);
        List<String> xsdFieldValues = Arrays.asList("cdAdresrol", "datBAdreshouding", "cdFictieveDatB", "datEAdreshouding", "cdFictieveDatE", "cdAfgeschermdAdres",
                "postcd",
                "woonplaatsnaam",
                "straatnaam",
                "huisnr",
                "huisletter",
                "huisnrtoevoeging",
                "cdAanduidingBijHuisnr",
                "naamOpenbareRuimte",
                "postcd",
                "woonplaatsnaam",
                "postbusnr");

        assertArrayEquals(ihpFieldValues.toArray(), ihpFieldCaptor.getAllValues().toArray());
        assertEquals(xsdFieldValues, xsdFieldCaptor.getAllValues());
    }

    @Test
    @DisplayName("Given Straatadres en Postadres AdresBuitenlandHr for Persoon verify mapping fields to JaxB is successful")
    public void testMapToJaxbStraatEnPostadresAdresBuitenlandPersoon() {
        AdresBuitenlandHr adresBuitenlandHr = createAdresBuitenlandWithStraatEnPostadres();
        adreshoudingMapper.mapToJaxbAdresBuitenlandPersoon(adresBuitenlandHr);

        verify(ruleExecutor, times(22)).setTransformedValue(any(Object.class), xsdFieldCaptor.capture(), ihpFieldCaptor.capture());
        List<Object> hrFieldValues = Arrays.asList(null, null, null, null, null, null,
                "1000AA",
                "testWoonplaatsnaamBuitenland",
                "testStraatnaamBuitenland",
                "2a",
                "testLocatieomschrijvingBuitenland",
                "testRegionaamBuitenland",
                "10",
                "testLandcodeIso",
                "testLandsnaam",
                "1000AA",
                "testWoonplaatsnaam",
                "12345678",
                "testRegionaamBuitenland",
                "10",
                "testLandcodeIso",
                "testLandsnaam");
        List<String> xsdFieldValues = Arrays.asList("cdAdresrol", "datBAdreshouding", "cdFictieveDatB", "datEAdreshouding", "cdFictieveDatE", "cdAfgeschermdAdres",
                "postcdBuitenland",
                "woonplaatsnaamBuitenland",
                "straatnaamBuitenland",
                "huisnrBuitenland",
                "locatieomsBuitenland",
                "regionaamBuitenland",
                "landcodeGba",
                "landcodeIso",
                "landsnaam",
                "postcdBuitenland",
                "woonplaatsnaamBuitenland",
                "postbusnrBuitenland",
                "regionaamBuitenland",
                "landcodeGba",
                "landcodeIso",
                "landsnaam");

        assertArrayEquals(hrFieldValues.toArray(), ihpFieldCaptor.getAllValues().toArray());
        assertEquals(xsdFieldValues, xsdFieldCaptor.getAllValues());
    }

    @Test
    @DisplayName("Given AdresBuitenlandHr for Persoon with DatumAanvag verify mapping fields to JaxB is successful")
    public void testMapToJaxbAdresBuitenlandPersoon() {
        AdresBuitenlandHr adresBuitenlandHr = createAdresBuitenlandWithDatumAanvang();
        adreshoudingMapper.mapToJaxbAdresBuitenlandPersoon(adresBuitenlandHr);

        verify(ruleExecutor, times(22)).setTransformedValue(any(Object.class), xsdFieldCaptor.capture(), ihpFieldCaptor.capture());
        List<Object> ihpFieldValues = Arrays.asList("C", "20180201", "0", "20190201", "0", "1",
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null);
        List<String> xsdFieldValues = Arrays.asList("cdAdresrol", "datBAdreshouding", "cdFictieveDatB", "datEAdreshouding", "cdFictieveDatE", "cdAfgeschermdAdres",
                "postcdBuitenland",
                "woonplaatsnaamBuitenland",
                "straatnaamBuitenland",
                "huisnrBuitenland",
                "locatieomsBuitenland",
                "regionaamBuitenland",
                "landcodeGba",
                "landcodeIso",
                "landsnaam",
                "postcdBuitenland",
                "woonplaatsnaamBuitenland",
                "postbusnrBuitenland",
                "regionaamBuitenland",
                "landcodeGba",
                "landcodeIso",
                "landsnaam");

        assertArrayEquals(ihpFieldValues.toArray(), ihpFieldCaptor.getAllValues().toArray());
        assertEquals(xsdFieldValues, xsdFieldCaptor.getAllValues());
    }

    @Test
    @DisplayName("Given Straatadres en Postadres AdresBuitenlandHr for vestiging handelsregister verify mapping fields to JaxB is successful")
    public void testMapToJaxbStraatEnPostadresAdresBuitenlandVestigingHandelsregister() {
        AdresBuitenlandHr adresBuitenlandHr = createAdresBuitenlandWithStraatEnPostadres();
        adreshoudingMapper.mapToJaxbAdresBuitenlandVestigingHandelsregister(adresBuitenlandHr);

        verify(ruleExecutor, times(22)).setTransformedValue(any(Object.class), xsdFieldCaptor.capture(), ihpFieldCaptor.capture());
        List<Object> hrFieldValues = Arrays.asList(null, null, null, null, null, null,
                "1000AA",
                "testWoonplaatsnaamBuitenland",
                "testStraatnaamBuitenland",
                "2a",
                "testLocatieomschrijvingBuitenland",
                "testRegionaamBuitenland",
                "10",
                "testLandcodeIso",
                "testLandsnaam",
                "1000AA",
                "testWoonplaatsnaam",
                "12345678",
                "testRegionaamBuitenland",
                "10",
                "testLandcodeIso",
                "testLandsnaam");
        List<String> xsdFieldValues = Arrays.asList("cdAdresrol", "datBAdreshouding", "cdFictieveDatB", "datEAdreshouding", "cdFictieveDatE", "cdAfgeschermdAdres",
                "postcdBuitenland",
                "woonplaatsnaamBuitenland",
                "straatnaamBuitenland",
                "huisnrBuitenland",
                "locatieomsBuitenland",
                "regionaamBuitenland",
                "landcodeGba",
                "landcodeIso",
                "landsnaam",
                "postcdBuitenland",
                "woonplaatsnaamBuitenland",
                "postbusnrBuitenland",
                "regionaamBuitenland",
                "landcodeGba",
                "landcodeIso",
                "landsnaam");

        assertArrayEquals(hrFieldValues.toArray(), ihpFieldCaptor.getAllValues().toArray());
        assertEquals(xsdFieldValues, xsdFieldCaptor.getAllValues());
    }

    @Test
    @DisplayName("Given AdresBuitenlandHr for VestigingHandelsregister with DatumAanvag verify mapping fields to JaxB is successful")
    public void testMapToJaxbAdresBuitenlandVestigingHandelsregister() {
        AdresBuitenlandHr adresBuitenlandHr = createAdresBuitenlandWithDatumAanvang();
        adreshoudingMapper.mapToJaxbAdresBuitenlandVestigingHandelsregister(adresBuitenlandHr);

        verify(ruleExecutor, times(22)).setTransformedValue(any(Object.class), xsdFieldCaptor.capture(), ihpFieldCaptor.capture());
        List<Object> ihpFieldValues = Arrays.asList("C", "20180201", "0", "20190201", "0", "1",
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null);
        List<String> xsdFieldValues = Arrays.asList("cdAdresrol", "datBAdreshouding", "cdFictieveDatB", "datEAdreshouding", "cdFictieveDatE", "cdAfgeschermdAdres",
                "postcdBuitenland",
                "woonplaatsnaamBuitenland",
                "straatnaamBuitenland",
                "huisnrBuitenland",
                "locatieomsBuitenland",
                "regionaamBuitenland",
                "landcodeGba",
                "landcodeIso",
                "landsnaam",
                "postcdBuitenland",
                "woonplaatsnaamBuitenland",
                "postbusnrBuitenland",
                "regionaamBuitenland",
                "landcodeGba",
                "landcodeIso",
                "landsnaam");

        assertArrayEquals(ihpFieldValues.toArray(), ihpFieldCaptor.getAllValues().toArray());
        assertEquals(xsdFieldValues, xsdFieldCaptor.getAllValues());
    }

    @Test
    @DisplayName("Given AdresBuitenlandHr Ongestructureerd for Persoon test mapping fields to JaxB is successful")
    public void testMapToJaxbAdresBuitenlandOngestructureerdPersoon() {
        AdresBuitenlandOngestructureerdHr adresBuitenlandOngestructureerdHr = createAdresBuitenlandOngestructureerd();
        adreshoudingMapper.mapToJaxbAdresBuitenlandOngestructureerdPersoon(adresBuitenlandOngestructureerdHr);

        verify(ruleExecutor, times(13)).setTransformedValue(any(Object.class), xsdFieldCaptor.capture(), ihpFieldCaptor.capture());
        List<Object> hrFieldValues = Arrays.asList("C","20180201","0", "20190201", "0", "1"
                , "testAdresregelBuitenland1"
                , "testAdresregelBuitenland2"
                , "testAdresregelBuitenland3"
                , "10"
                , "testLandsnaamGba"
                , "testLandcodeIso"
                , "testLandsnaam");
        List<String> xsdFieldValues = Arrays.asList("cdAdresrol", "datBAdreshouding", "cdFictieveDatB", "datEAdreshouding", "cdFictieveDatE", "cdAfgeschermdAdres",
                "adresregel1Buitenland",
                "adresregel2Buitenland",
                "adresregel3Buitenland",
                "landcodeGba",
                "landsnaamGba",
                "landcodeIso",
                "landsnaam");

        assertArrayEquals(hrFieldValues.toArray(), ihpFieldCaptor.getAllValues().toArray());
        assertEquals(xsdFieldValues, xsdFieldCaptor.getAllValues());
    }

    @Test
    @DisplayName("Given AdresBuitenlandHr Ongestructureerd with DatumAanvang for vestiging handelsregister test mapping fields to JaxB is successful")
    public void testMapToJaxbAdresBuitenlandOngestructureerdWithDatumAanvang() {
        AdresBuitenlandOngestructureerdHr adresBuitenlandOngestructureerdHr = createAdresBuitenlandOngestructureerdWithDatumAanvang();
        adreshoudingMapper.mapToJaxbAdresBuitenlandOngestructureerdVestigingHandelsregister(adresBuitenlandOngestructureerdHr);

        verify(ruleExecutor, times(13)).setTransformedValue(any(Object.class), xsdFieldCaptor.capture(), ihpFieldCaptor.capture());
        List<Object> ihpFieldValues = Arrays.asList("C","20180201","0", "20190201", "0", "1"
                , null
                , null
                , null
                , null
                , null
                , null
                , null);
        List<String> xsdFieldValues = Arrays.asList("cdAdresrol", "datBAdreshouding", "cdFictieveDatB", "datEAdreshouding", "cdFictieveDatE", "cdAfgeschermdAdres",
                "adresregel1Buitenland",
                "adresregel2Buitenland",
                "adresregel3Buitenland",
                "landcodeGba",
                "landsnaamGba",
                "landcodeIso",
                "landsnaam");

        assertArrayEquals(ihpFieldValues.toArray(), ihpFieldCaptor.getAllValues().toArray());
        assertEquals(xsdFieldValues, xsdFieldCaptor.getAllValues());
    }

    @Test
    @DisplayName("Given AdresBuitenlandHr Ongestructureerd for vestiging handelsregister test mapping fields to JaxB is successful")
    public void testMapToJaxbAdresBuitenlandOngestructureerdVestigingHandelsregister() {
        AdresBuitenlandOngestructureerdHr adresBuitenlandOngestructureerdHr = createAdresBuitenlandOngestructureerd();
        adreshoudingMapper.mapToJaxbAdresBuitenlandOngestructureerdVestigingHandelsregister(adresBuitenlandOngestructureerdHr);

        verify(ruleExecutor, times(13)).setTransformedValue(any(Object.class), xsdFieldCaptor.capture(), ihpFieldCaptor.capture());
        List<Object> hrFieldValues = Arrays.asList("C","20180201","0", "20190201", "0", "1"
                , "testAdresregelBuitenland1"
                , "testAdresregelBuitenland2"
                , "testAdresregelBuitenland3"
                , "10"
                , "testLandsnaamGba"
                , "testLandcodeIso"
                , "testLandsnaam");
        List<String> xsdFieldValues = Arrays.asList("cdAdresrol", "datBAdreshouding", "cdFictieveDatB", "datEAdreshouding", "cdFictieveDatE", "cdAfgeschermdAdres",
                "adresregel1Buitenland",
                "adresregel2Buitenland",
                "adresregel3Buitenland",
                "landcodeGba",
                "landsnaamGba",
                "landcodeIso",
                "landsnaam");

        assertArrayEquals(hrFieldValues.toArray(), ihpFieldCaptor.getAllValues().toArray());
        assertEquals(xsdFieldValues, xsdFieldCaptor.getAllValues());
    }

    @Test
    @DisplayName("Given AdresBuitenlandHr Ongestructureerd WithoutDates test mapping fields to JaxB is successful")
    public void testMapToJaxbAdresBuitenlandOngestructureerdWithoutDates() {
        AdresBuitenlandOngestructureerdHr adresBuitenlandOngestructureerdHr = createAdresBuitenlandOngestructureerdWithoutDates();
        adreshoudingMapper.mapToJaxbAdresBuitenlandOngestructureerdVestigingHandelsregister(adresBuitenlandOngestructureerdHr);

        verify(ruleExecutor, times(13)).setTransformedValue(any(Object.class), xsdFieldCaptor.capture(), ihpFieldCaptor.capture());
        List<Object> hrFieldValues = Arrays.asList("C",null,null, null, null, "1"
                , "testAdresregelBuitenland1"
                , "testAdresregelBuitenland2"
                , "testAdresregelBuitenland3"
                , "10"
                , "testLandsnaamGba"
                , "testLandcodeIso"
                , "testLandsnaam");
        List<String> xsdFieldValues = Arrays.asList("cdAdresrol", "datBAdreshouding", "cdFictieveDatB", "datEAdreshouding", "cdFictieveDatE", "cdAfgeschermdAdres",
                "adresregel1Buitenland",
                "adresregel2Buitenland",
                "adresregel3Buitenland",
                "landcodeGba",
                "landsnaamGba",
                "landcodeIso",
                "landsnaam");

        assertArrayEquals(hrFieldValues.toArray(), ihpFieldCaptor.getAllValues().toArray());
        assertEquals(xsdFieldValues, xsdFieldCaptor.getAllValues());
    }

    @Test
    @DisplayName("Given AdresNederlandWg verify mapping fields to JaxB is successful")
    public void testMapToJaxbAdresNederland() {
        AdresNederlandWg adresNederlandWg = createAdresNederlandWg();
        adreshoudingMapper.mapToJaxbAdresNederlandWg(adresNederlandWg);

        verify(ruleExecutor, times(13)).setTransformedValue(any(Object.class), xsdFieldCaptor.capture(), ihpFieldCaptor.capture());
        List<Object> hrFieldValues = Arrays.asList("C", "20180201", "20190201",
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null);
        List<String> xsdFieldValues = Arrays.asList("cdAdresrol", "datBAdreshouding", "datEAdreshouding",
                "postcd",
                "woonplaatsnaam",
                "gemeentenaam",
                "straatnaam",
                "huisnr",
                "huisnrtoevoeging",
                "locatieoms",
                "postcd",
                "woonplaatsnaam",
                "postbusnr");

        assertArrayEquals(hrFieldValues.toArray(), ihpFieldCaptor.getAllValues().toArray());
        assertEquals(xsdFieldValues, xsdFieldCaptor.getAllValues());
    }

    @Test
    @DisplayName("Given Straatadres en Postadres AdresNederlandWg verify mapping fields to JaxB is successful")
    public void testMapToJaxbStraatEnPostadresAdresNederland() {
        AdresNederlandWg adresNederlandWg = createAdresNederlandWgWithStraatEnPostadres();
        adreshoudingMapper.mapToJaxbAdresNederlandWg(adresNederlandWg);

        verify(ruleExecutor, times(13)).setTransformedValue(any(Object.class), xsdFieldCaptor.capture(), ihpFieldCaptor.capture());
        List<Object> hrFieldValues = Arrays.asList(null, null, null,
                "1000AA",
                "testWoonplaatsnaam",
                "testGemeentenaam",
                "testStraatnaam",
                "11",
                "B",
                "testLocatieomschrijving",
                "1000AA",
                "testWoonplaatsnaam",
                BigInteger.valueOf(12345678));
        List<String> xsdFieldValues = Arrays.asList("cdAdresrol", "datBAdreshouding", "datEAdreshouding",
                "postcd",
                "woonplaatsnaam",
                "gemeentenaam",
                "straatnaam",
                "huisnr",
                "huisnrtoevoeging",
                "locatieoms",
                "postcd",
                "woonplaatsnaam",
                "postbusnr");

        assertArrayEquals(hrFieldValues.toArray(), ihpFieldCaptor.getAllValues().toArray());
        assertEquals(xsdFieldValues, xsdFieldCaptor.getAllValues());
    }

    @Test
    @DisplayName("Given AdresBuitenlandWg verify mapping fields to JaxB is successful")
    public void testMapToJaxbAdresBuitenland() {
        AdresBuitenlandWg adresBuitenlandWg = createAdresBuitenlandWg();
        adreshoudingMapper.mapToJaxbAdresBuitenlandWg(adresBuitenlandWg);

        verify(ruleExecutor, times(15)).setTransformedValue(any(Object.class), xsdFieldCaptor.capture(), ihpFieldCaptor.capture());
        List<Object> hrFieldValues = Arrays.asList("C", "20180201", "20190201",
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null);
        List<String> xsdFieldValues = Arrays.asList("cdAdresrol", "datBAdreshouding", "datEAdreshouding",
                "postcdBuitenland",
                "woonplaatsnaamBuitenland",
                "regionaamBuitenland",
                "landcodeIso",
                "straatnaamBuitenland",
                "huisnrBuitenland",
                "locatieomsBuitenland",
                "postcdBuitenland",
                "woonplaatsnaamBuitenland",
                "regionaamBuitenland",
                "landcodeIso",
                "postbusnrBuitenland");

        assertArrayEquals(hrFieldValues.toArray(), ihpFieldCaptor.getAllValues().toArray());
        assertEquals(xsdFieldValues, xsdFieldCaptor.getAllValues());
    }

    @Test
    @DisplayName("Given Straatadres en Postadres AdresBuitenlandWg verify mapping fields to JaxB is successful")
    public void testMapToJaxbStraatEnPostadresAdresBuitenland() {
        AdresBuitenlandWg adresBuitenlandWg = createAdresBuitenlandWithStraatEnPostadresWg();
        adreshoudingMapper.mapToJaxbAdresBuitenlandWg(adresBuitenlandWg);

        verify(ruleExecutor, times(15)).setTransformedValue(any(Object.class), xsdFieldCaptor.capture(), ihpFieldCaptor.capture());
        List<Object> hrFieldValues = Arrays.asList(null, null, null,
                "1000AA",
                "testWoonplaatsnaamBuitenland",
                "testRegionaamBuitenland",
                "testLandcodeIso",
                "testStraatnaamBuitenland",
                "2a",
                "testLocatieomsBuitenland",
                "1000AA",
                "testWoonplaatsnaam",
                "testRegionaamBuitenland",
                "testLandcodeIso",
                "12345678");
        List<String> xsdFieldValues = Arrays.asList("cdAdresrol", "datBAdreshouding", "datEAdreshouding",
                "postcdBuitenland",
                "woonplaatsnaamBuitenland",
                "regionaamBuitenland",
                "landcodeIso",
                "straatnaamBuitenland",
                "huisnrBuitenland",
                "locatieomsBuitenland",
                "postcdBuitenland",
                "woonplaatsnaamBuitenland",
                "regionaamBuitenland",
                "landcodeIso",
                "postbusnrBuitenland");

        assertArrayEquals(hrFieldValues.toArray(), ihpFieldCaptor.getAllValues().toArray());
        assertEquals(xsdFieldValues, xsdFieldCaptor.getAllValues());
    }

    @Test
    @DisplayName("Given AdresBuitenlandWg Ongestructureerd test mapping fields to JaxB is successful")
    public void testMapToJaxbAdresBuitenlandOngestructureerdWg() {
        AdresBuitenlandOngestructureerdWg adresBuitenlandOngestructureerdWg = createAdresBuitenlandOngestructureerdWg();
        adreshoudingMapper.mapToJaxbAdresBuitenlandOngestructureerdWg(adresBuitenlandOngestructureerdWg);

        verify(ruleExecutor, times(7)).setTransformedValue(any(Object.class), xsdFieldCaptor.capture(), ihpFieldCaptor.capture());
        List<Object> hrFieldValues = Arrays.asList("C","20180201", "20190201"
                , "testAdresregelBuitenland1"
                , "testAdresregelBuitenland2"
                , "testAdresregelBuitenland3"
                , "testLandcodeIso");
        List<String> xsdFieldValues = Arrays.asList("cdAdresrol", "datBAdreshouding", "datEAdreshouding",
                "adresregel1Buitenland",
                "adresregel2Buitenland",
                "adresregel3Buitenland",
                "landcodeIso");

        assertArrayEquals(hrFieldValues.toArray(), ihpFieldCaptor.getAllValues().toArray());
        assertEquals(xsdFieldValues, xsdFieldCaptor.getAllValues());
    }

    private AdresNederlandHr createAdresNederlandWithDatumAanvang() {
        return AdresNederlandHr.builder()
                .codeAdresrol("C")
                .datumAanvangAdreshouding(Date.valueOf(LocalDate.of(2018,2,1)))
                .codeFictieveDatumAanvang(0)
                .datumEindeAdreshouding(Date.valueOf(LocalDate.of(2019,2,1)))
                .codeFictieveDatumEinde(0)
                .codeAfgeschermdAdres(1)
                .codeAfgeschermdAdres(1)
                .straatadresHr(AdresNederlandStraatadresHr.builder().build())
                .postbusadresHr(AdresNederlandPostbusadresHr.builder().build())
                .build();
    }

    private AdresNederlandHr createAdresNederlandWithStraatEnPostadres() {
        AdresNederlandStraatadresHr straatadresHr = createStraatadresAdresNederland();
        AdresNederlandPostbusadresHr postbusadresHr = createPostadresAdresNederland();

        return AdresNederlandHr.builder()
                .straatadresHr(straatadresHr)
                .postbusadresHr(postbusadresHr)
                .build();
    }

    private AdresNederlandStraatadresHr createStraatadresAdresNederland() {
        return AdresNederlandStraatadresHr.builder()
                .postcode("1000AA")
                .woonplaatsnaam("testWoonplaatsnaam")
                .straatnaam("testStraatnaam")
                .huisnummer(1)
                .huisletter("B")
                .huisnummertoevoeging("rood")
                .codeAanduidingBijHuisnummer("A")
                .naamOpenbareRuimte("testNaamOpenbareruimte")
                .build();
    }

    private AdresNederlandPostbusadresHr createPostadresAdresNederland() {
        return AdresNederlandPostbusadresHr.builder()
                .postcode("1000AA")
                .woonplaatsnaam("testWoonplaatsnaam")
                .postbusnummer(12345678)
                .build();
    }

    private AdresBuitenlandHr createAdresBuitenlandWithDatumAanvang() {
        return AdresBuitenlandHr.builder()
                .codeAdresrol("C")
                .datumAanvangAdreshouding(Date.valueOf(LocalDate.of(2018,2,1)))
                .codeFictieveDatumAanvang(0)
                .datumEindeAdreshouding(Date.valueOf(LocalDate.of(2019,2,1)))
                .codeFictieveDatumEinde(0)
                .codeAfgeschermdAdres(1)
                .straatadresHr(AdresBuitenlandStraatadresHr.builder().build())
                .postbusadresHr(AdresBuitenlandPostbusadresHr.builder().build())
                .build();
    }

    private AdresBuitenlandHr createAdresBuitenlandWithStraatEnPostadres() {
        AdresBuitenlandStraatadresHr straatadresHr = createStraatadresAdresBuitenland();
        AdresBuitenlandPostbusadresHr postbusadresHr = createPostadresAdresBuitenland();

        return AdresBuitenlandHr.builder()
                .straatadresHr(straatadresHr)
                .postbusadresHr(postbusadresHr)
                .build();
    }

    private AdresBuitenlandStraatadresHr createStraatadresAdresBuitenland() {
        return AdresBuitenlandStraatadresHr.builder()
                .postcodeBuitenland("1000AA")
                .woonplaatsnaamBuitenland("testWoonplaatsnaamBuitenland")
                .straatnaamBuitenland("testStraatnaamBuitenland")
                .huisnummerBuitenland("2a")
                .locatieomschrijvingBuitenland("testLocatieomschrijvingBuitenland")
                .regionaamBuitenland("testRegionaamBuitenland")
                .landcodeGba(10)
                .landcodeIso("testLandcodeIso")
                .landsnaam("testLandsnaam")
                .build();
    }

    private AdresBuitenlandPostbusadresHr createPostadresAdresBuitenland() {
        return AdresBuitenlandPostbusadresHr.builder()
                .postcodeBuitenland("1000AA")
                .woonplaatsnaamBuitenland("testWoonplaatsnaam")
                .postbusnummerBuitenland("12345678")
                .regionaamBuitenland("testRegionaamBuitenland")
                .landcodeGba(10)
                .landcodeIso("testLandcodeIso")
                .landsnaam("testLandsnaam")
                .build();
    }

    private AdresBuitenlandOngestructureerdHr createAdresBuitenlandOngestructureerdWithDatumAanvang() {
        return AdresBuitenlandOngestructureerdHr.builder()
                .codeAdresrol("C")
                .datumAanvangAdreshouding(Date.valueOf(LocalDate.of(2018,02,01)))
                .codeFictieveDatumAanvang(0)
                .datumEindeAdreshouding(Date.valueOf(LocalDate.of(2019,02,01)))
                .codeFictieveDatumEinde(0)
                .codeAfgeschermdAdres(1)
                .build();
    }

    private AdresBuitenlandOngestructureerdHr createAdresBuitenlandOngestructureerd() {
        return AdresBuitenlandOngestructureerdHr.builder()
                .codeAdresrol("C")
                .datumAanvangAdreshouding(Date.valueOf(LocalDate.of(2018,2,1)))
                .codeFictieveDatumAanvang(0)
                .datumEindeAdreshouding(Date.valueOf(LocalDate.of(2019,2,1)))
                .codeFictieveDatumEinde(0)
                .codeAfgeschermdAdres(1)
                .adresregel1Buitenland("testAdresregelBuitenland1")
                .adresregel2Buitenland("testAdresregelBuitenland2")
                .adresregel3Buitenland("testAdresregelBuitenland3")
                .landcodeGba(10)
                .landsnaamGba("testLandsnaamGba")
                .landcodeIso("testLandcodeIso")
                .landsnaam("testLandsnaam")
                .isAdresActief(true)
                .build();
    }

    private AdresBuitenlandOngestructureerdHr createAdresBuitenlandOngestructureerdWithoutDates() {
        return AdresBuitenlandOngestructureerdHr.builder()
                .codeAdresrol("C")
                .datumAanvangAdreshouding(null)
                .codeFictieveDatumAanvang(0)
                .datumEindeAdreshouding(null)
                .codeFictieveDatumEinde(0)
                .codeAfgeschermdAdres(1)
                .adresregel1Buitenland("testAdresregelBuitenland1")
                .adresregel2Buitenland("testAdresregelBuitenland2")
                .adresregel3Buitenland("testAdresregelBuitenland3")
                .landcodeGba(10)
                .landsnaamGba("testLandsnaamGba")
                .landcodeIso("testLandcodeIso")
                .landsnaam("testLandsnaam")
                .isAdresActief(true)
                .build();
    }

    private AdresNederlandWg createAdresNederlandWg() {
        return AdresNederlandWg.builder()
                .codeAdresrol("C")
                .datumAanvangAdreshouding(20180201L)
                .datumEindeAdreshouding(20190201L)
                .straatadresWg(AdresNederlandStraatadresWg.builder().build())
                .postbusadresWg(AdresNederlandPostbusadresWg.builder().build())
                .build();
    }

    private AdresNederlandWg createAdresNederlandWgWithStraatEnPostadres() {
        AdresNederlandStraatadresWg straatadresWg = createStraatadresAdresNederlandWg();
        AdresNederlandPostbusadresWg postbusadresWg = createPostadresAdresNederlandWg();

        return AdresNederlandWg.builder()
                .straatadresWg(straatadresWg)
                .postbusadresWg(postbusadresWg)
                .build();
    }

    private AdresNederlandStraatadresWg createStraatadresAdresNederlandWg() {
        return AdresNederlandStraatadresWg.builder()
                .postcode("1000AA")
                .woonplaatsnaam("testWoonplaatsnaam")
                .gemeentenaam("testGemeentenaam")
                .straatnaam("testStraatnaam")
                .huisnummer(11)
                .huisnummerToevoeging("B")
                .locatieomschrijving("testLocatieomschrijving")
                .build();
    }

    private AdresNederlandPostbusadresWg createPostadresAdresNederlandWg() {
        return AdresNederlandPostbusadresWg.builder()
                .postcode("1000AA")
                .woonplaatsnaam("testWoonplaatsnaam")
                .postbusnummer(12345678)
                .build();
    }

    private AdresBuitenlandWg createAdresBuitenlandWg() {
        return AdresBuitenlandWg.builder()
                .codeAdresrol("C")
                .datumAanvangAdreshouding(20180201L)
                .datumEindeAdreshouding(20190201L)
                .straatadresWg(AdresBuitenlandStraatadresWg.builder().build())
                .postbusadresWg(AdresBuitenlandPostbusadresWg.builder().build())
                .build();
    }

    private AdresBuitenlandWg createAdresBuitenlandWithStraatEnPostadresWg() {
        AdresBuitenlandStraatadresWg straatadresWg = createStraatadresAdresBuitenlandWg();
        AdresBuitenlandPostbusadresWg postbusadresWg = createPostadresAdresBuitenlandWg();

        return AdresBuitenlandWg.builder()
                .straatadresWg(straatadresWg)
                .postbusadresWg(postbusadresWg)
                .build();
    }

    private AdresBuitenlandStraatadresWg createStraatadresAdresBuitenlandWg() {
        return AdresBuitenlandStraatadresWg.builder()
                .postcodeBuitenland("1000AA")
                .woonplaatsnaamBuitenland("testWoonplaatsnaamBuitenland")
                .straatnaamBuitenland("testStraatnaamBuitenland")
                .huisnummerBuitenland("2a")
                .regionaamBuitenland("testRegionaamBuitenland")
                .landcodeIso("testLandcodeIso")
                .locatieomschrijvingBuitenland("testLocatieomsBuitenland")
                .build();
    }

    private AdresBuitenlandPostbusadresWg createPostadresAdresBuitenlandWg() {
        return AdresBuitenlandPostbusadresWg.builder()
                .postcodeBuitenland("1000AA")
                .woonplaatsnaamBuitenland("testWoonplaatsnaam")
                .postbusnummerBuitenland("12345678")
                .regionaamBuitenland("testRegionaamBuitenland")
                .landcodeIso("testLandcodeIso")
                .build();
    }

    private AdresBuitenlandOngestructureerdWg createAdresBuitenlandOngestructureerdWg() {
        return AdresBuitenlandOngestructureerdWg.builder()
                .codeAdresrol("C")
                .datumAanvangAdreshouding(20180201L)
                .datumEindeAdreshouding(20190201L)
                .adresregel1Buitenland("testAdresregelBuitenland1")
                .adresregel2Buitenland("testAdresregelBuitenland2")
                .adresregel3Buitenland("testAdresregelBuitenland3")
                .landcodeIso("testLandcodeIso")
                .build();
    }
}
