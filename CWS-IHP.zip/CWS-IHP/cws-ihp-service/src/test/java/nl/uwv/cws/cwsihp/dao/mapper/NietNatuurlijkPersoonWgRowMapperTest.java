package nl.uwv.cws.cwsihp.dao.mapper;

import nl.uwv.cws.cwsihp.model.wg.NietNatuurlijkPersoonWg;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.Mockito.when;

@TestInstance(Lifecycle.PER_CLASS)
@ExtendWith(MockitoExtension.class)
public class NietNatuurlijkPersoonWgRowMapperTest {

    @InjectMocks
    private NietNatuurlijkPersoonWgRowMapper nietNatuurlijkPersoonWgRowMapper;

    @Mock
    private ResultSet resultSet;

    @BeforeEach
    public void setup() throws SQLException {
        when(resultSet.getObject("RSIN")).thenReturn(999999990);
        when(resultSet.getObject("DAT_OPR")).thenReturn(1);
        when(resultSet.getObject("DAT_ONTB")).thenReturn(2);
    }

    @Test
    @DisplayName("Should successfully map fields for NietNatuurlijkPersoonWg")
    public void testMapRow() throws SQLException {
        when(resultSet.getInt("RSIN")).thenReturn(999999990);
        when(resultSet.getLong("DAT_OPR")).thenReturn(20200101L);
        when(resultSet.getLong("DAT_ONTB")).thenReturn(20200131L);
        when(resultSet.getString("VOLLEDIGENAAM")).thenReturn("naamVanNnp");

        List<String> attributen = Arrays.asList("RSIN", "DAT_OPR", "DAT_ONTB","VOLLEDIGENAAM");

        NietNatuurlijkPersoonWg nietNatuurlijkPersoonWg = nietNatuurlijkPersoonWgRowMapper.mapRow(resultSet, attributen);
        assertThat(nietNatuurlijkPersoonWg, is(notNullValue()));
        assertThat(nietNatuurlijkPersoonWg.getRsin(), is(equalTo(999999990)));
        assertThat(nietNatuurlijkPersoonWg.getDatumOprichtingNietNatuurlijkPersoon(), is(20200101L));
        assertThat(nietNatuurlijkPersoonWg.getDatumOntbindingNietNatuurlijkPersoon(), is(20200131L));
        assertThat(nietNatuurlijkPersoonWg.getNaamNietNatuurlijkPersoon(), is(equalTo("naamVanNnp")));
    }
}
