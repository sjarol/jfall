package nl.uwv.cws.cwsihp.webservice.rule.transformer;

import nl.uwv.cws.common.model.rule.AttributeRuleProperties;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static nl.uwv.cws.cwsihp.model.rule.CwsIhpAttributeRule.INDICATIE_JA_NEE_OF_NULL;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.CoreMatchers.*;

public class IndicatieJaNeeOfNullTransformerTest {

    private IndicatieJaNeeOfNullTransformer indicatieJaNeeOfNullTransformer;
    private AttributeRuleProperties attributeRuleProperties;

    @BeforeEach
    public void setup() {
        indicatieJaNeeOfNullTransformer = new IndicatieJaNeeOfNullTransformer();
        attributeRuleProperties = new AttributeRuleProperties();
    }

    @Test
    public void given_indicatieJaNeeOfNullTransformer_shouldUseCorrectType() {
        assertThat(indicatieJaNeeOfNullTransformer.getTransformRule(), is(INDICATIE_JA_NEE_OF_NULL));
    }

    @Test
    public void given_valueNull_shouldReturnNull() {
        String originalValue = null;
        String transformedValue = indicatieJaNeeOfNullTransformer.transform(originalValue, attributeRuleProperties);
        assertThat(transformedValue, is(nullValue()));
    }

    @Test
    public void given_valueJ_shouldReturn1() {
        String originalValue = "J";
        String transformedValue = indicatieJaNeeOfNullTransformer.transform(originalValue, attributeRuleProperties);
        assertThat(transformedValue, is("1"));
    }

    @Test
    public void given_valueN_shouldReturn2() {
        String originalValue = "N";
        String transformedValue = indicatieJaNeeOfNullTransformer.transform(originalValue, attributeRuleProperties);
        assertThat(transformedValue, is("2"));
    }

    @Test
    public void given_valueX_shouldReturnNull() {
        String originalValue = "X";
        String transformedValue = indicatieJaNeeOfNullTransformer.transform(originalValue, attributeRuleProperties);
        assertThat(transformedValue, is(nullValue()));
    }
}
