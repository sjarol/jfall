package nl.uwv.cws.cwsihp.webservice.mapper;

import nl.uwv.cws.cwsihp.model.wg.VoortzettingsrelatieVoorgangerWg;
import nl.uwv.cws.common.webservice.rule.CwsRuleExecutor;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
public class VoortzettingsrelatieVoorgangerMapperTest {

    @InjectMocks
    private VoortzettingsrelatieVoorgangerMapper voortzettingsrelatieVoorgangerMapper;

    @Mock
    private CwsRuleExecutor ruleExecutor;

    @Captor
    private ArgumentCaptor<String> wgFieldCaptor;

    @Captor
    private ArgumentCaptor<String> xsdFieldCaptor;

    @Test
    @DisplayName("Given VoortzettingsrelatieVoorgangerWg test mapping fields to JaxB is successful")
    public void testMapToJaxbVoortzettingsrelatieVoorganger() {
        VoortzettingsrelatieVoorgangerWg voortzettingsrelatieVoorgangerWg = createVoortzettingsrelatieVoorgangerWg();
        voortzettingsrelatieVoorgangerMapper.mapToJaxbVoortzettingsrelatieVoorganger(voortzettingsrelatieVoorgangerWg);

        verify(ruleExecutor, times(3)).setTransformedValue(any(Object.class), xsdFieldCaptor.capture(), wgFieldCaptor.capture());
        List<Object> wgFieldValues = Arrays.asList("20210601", new BigDecimal("100.00"), "123456789L01");
        List<Object> xsdFieldValues = Arrays.asList("datBVoortzettingsrelatie", "percLoonsomOvergegaanInOpvolger", "loonheffingennr");
        assertArrayEquals(wgFieldValues.toArray(), wgFieldCaptor.getAllValues().toArray());
        assertEquals(xsdFieldValues, xsdFieldCaptor.getAllValues());
    }

    private VoortzettingsrelatieVoorgangerWg createVoortzettingsrelatieVoorgangerWg() {
        return VoortzettingsrelatieVoorgangerWg.builder()
                .datumAanvangVoortzettingsrelatieVoorganger(20210601L)
                .percentageLoonsomOvergegaan(100.00D)
                .lhnrVoorganger("123456789L01")
                .build();
    }
}
