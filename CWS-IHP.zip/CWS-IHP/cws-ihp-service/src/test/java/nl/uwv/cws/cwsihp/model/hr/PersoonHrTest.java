package nl.uwv.cws.cwsihp.model.hr;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class PersoonHrTest {

    @Test
    @DisplayName("PersoonHandelsregister should return true")
    public void test_isPersoonHandelsregister() {
        PersoonHr persoonHr = PersoonHr.builder().persoonId(0L).naamPersoonId(123L).natuurlijkePersoonId(0L).build();
        assertTrue(persoonHr.isPersoonHandelsregister());
    }

    @Test
    @DisplayName("PersoonHandelsregister should return false")
    public void test_isNotPersoonHandelsregister() {
        PersoonHr persoonHr = PersoonHr.builder().persoonId(0L).naamPersoonId(null).natuurlijkePersoonId(0L).build();
        assertFalse(persoonHr.isPersoonHandelsregister());
    }

    @Test
    @DisplayName("NatuurlijkePersoon should return true")
    public void test_isNatuurlijkePersoon() {
        PersoonHr persoonHr = PersoonHr.builder().persoonId(0L).naamPersoonId(0L).natuurlijkePersoonId(123L).build();
        assertTrue(persoonHr.isNatuurlijkPersoon());
    }

    @Test
    @DisplayName("NatuurlijkePersoon should return false")
    public void test_isNotNatuurlijkePersoon() {
        PersoonHr persoonHr = PersoonHr.builder().persoonId(0L).naamPersoonId(0L).natuurlijkePersoonId(null).build();
        assertFalse(persoonHr.isNatuurlijkPersoon());
    }

    @Test
    @DisplayName("NietNatuurlijkePersoon should return true")
    public void test_isNietNatuurlijkePersoon() {
        PersoonHr persoonHr = PersoonHr.builder().persoonId(0L).naamPersoonId(null).natuurlijkePersoonId(null).build();
        assertTrue(persoonHr.isNietNatuurlijkPersoon());
    }

    @Test
    @DisplayName("NietNatuurlijkePersoon should return false because is PersoonHandelsregister")
    public void test_isNotNietNatuurlijkePersoonisPersoonHandelsregister() {
        PersoonHr persoonHr = PersoonHr.builder().persoonId(0L).naamPersoonId(123L).natuurlijkePersoonId(null).build();
        assertFalse(persoonHr.isNietNatuurlijkPersoon());
    }

    @Test
    @DisplayName("NietNatuurlijkePersoon should return false because is NatuurlijkePersoon")
    public void test_isNotNietNatuurlijkePersoonisNatuurlijkePersoon() {
        PersoonHr persoonHr = PersoonHr.builder().persoonId(0L).naamPersoonId(null).natuurlijkePersoonId(123L).build();
        assertFalse(persoonHr.isNietNatuurlijkPersoon());
    }
}
