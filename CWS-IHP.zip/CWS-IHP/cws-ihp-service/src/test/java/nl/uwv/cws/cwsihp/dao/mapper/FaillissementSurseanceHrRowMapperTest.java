package nl.uwv.cws.cwsihp.dao.mapper;

import nl.uwv.cws.cwsihp.model.hr.FaillissementSurseanceHr;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.Mockito.when;

@TestInstance(Lifecycle.PER_CLASS)
@ExtendWith(MockitoExtension.class)
public class FaillissementSurseanceHrRowMapperTest {

    @InjectMocks
    private FaillissementSurseanceHrRowMapper faillissementSurseanceHrRowMapper;

    @Mock
    private ResultSet resultSet;

    @BeforeEach
    public void setup() throws SQLException {
        when(resultSet.getObject("CD_DATUM_AANVANG_CGM")).thenReturn(1);
        when(resultSet.getObject("CD_DATUM_EINDE_CGM")).thenReturn(1);
    }

    @Test
    @DisplayName("Should successfully map fields for FaillissementSurseanceHr")
    public void testMapRow() throws SQLException {
        when(resultSet.getString("FAIL_SURS_IND")).thenReturn("C");
        when(resultSet.getDate("DATAANV")).thenReturn(Date.valueOf(LocalDate.of(2020,1,1)));
        when(resultSet.getInt("CD_DATUM_AANVANG_CGM")).thenReturn(1);
        when(resultSet.getDate("DATEIND")).thenReturn(Date.valueOf(LocalDate.of(2020,1,31)));
        when(resultSet.getInt("CD_DATUM_EINDE_CGM")).thenReturn(2);

        List<String> attributen = Arrays.asList("FAIL_SURS_IND", "DATAANV",
                "CD_DATUM_AANVANG_CGM", "DATEIND", "CD_DATUM_EINDE_CGM");

        FaillissementSurseanceHr faillissementSurseanceHr = faillissementSurseanceHrRowMapper.mapRow(resultSet, attributen);
        assertThat(faillissementSurseanceHr, is(notNullValue()));
        assertThat(faillissementSurseanceHr.getCodeFaillissementSurseance(), is(equalTo("C")));
        assertThat(faillissementSurseanceHr.getDatumAanvangFaillissementSurseance(), is(Date.valueOf(LocalDate.of(2020,1,1))));
        assertThat(faillissementSurseanceHr.getCodeFictieveDatumAanvang(), is(equalTo(1)));
        assertThat(faillissementSurseanceHr.getDatumEindeFaillissementSurseance(), is(Date.valueOf(LocalDate.of(2020,1,31))));
        assertThat(faillissementSurseanceHr.getCodeFictieveDatumEinde(), is(equalTo(2)));

    }
}
