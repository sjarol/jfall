package nl.uwv.cws.cwsihp.webservice.rule.transformer;

import nl.uwv.cws.common.model.rule.AttributeRuleProperties;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.math.BigInteger;

import static nl.uwv.cws.cwsihp.model.rule.CwsIhpAttributeRule.NUMMER_TUSSEN_1_EN_99999_OF_NULL;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;

public class NummerTussen1En99999OfNullTransformerTest {

    private NummerTussen1En99999OfNullTransformer nummerTussen1En99999OfNullTransformer;
    private AttributeRuleProperties attributeRuleProperties;

    @BeforeEach
    public void setup() {
        nummerTussen1En99999OfNullTransformer = new NummerTussen1En99999OfNullTransformer();
        attributeRuleProperties = new AttributeRuleProperties();
    }

    @Test
    @DisplayName("Should use correct rule type")
    public void givenValueShouldUseCorrectRuletype() {
        assertThat(nummerTussen1En99999OfNullTransformer.getTransformRule(), is(NUMMER_TUSSEN_1_EN_99999_OF_NULL));
    }

    @Test
    @DisplayName("Should return null when value is out of range")
    public void givenValueIsUnderRange() {
        String originalValue = "-1";
        BigInteger transformedValue = nummerTussen1En99999OfNullTransformer.transform(originalValue, attributeRuleProperties);
        assertThat(transformedValue, is(nullValue()));
    }

    @Test
    @DisplayName("Should return null when value is out of range")
    public void givenValueIsOverRange() {
        String originalValue = "999999";
        BigInteger transformedValue = nummerTussen1En99999OfNullTransformer.transform(originalValue, attributeRuleProperties);
        assertThat(transformedValue, is(nullValue()));
    }

    @Test
    @DisplayName("Should return null when value is empty")
    public void givenValueIsEmpty() {
        String originalValue = null;
        BigInteger transformedValue = nummerTussen1En99999OfNullTransformer.transform(originalValue, attributeRuleProperties);
        assertThat(transformedValue, is(nullValue()));
    }

    @Test
    @DisplayName("Should return transformed value when value is in range")
    public void givenValueIsInRange() {
        String originalValue = "15";
        BigInteger transformedValue = nummerTussen1En99999OfNullTransformer.transform(originalValue, attributeRuleProperties);
        assertThat(transformedValue, is(BigInteger.valueOf(15)));
    }
}
