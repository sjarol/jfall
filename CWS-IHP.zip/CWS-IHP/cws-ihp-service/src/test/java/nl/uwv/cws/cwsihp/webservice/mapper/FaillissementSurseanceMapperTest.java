package nl.uwv.cws.cwsihp.webservice.mapper;

import nl.uwv.cws.cwsihp.model.hr.FaillissementSurseanceHr;
import nl.uwv.cws.cwsihp.model.wg.FaillissementSurseanceWg;
import nl.uwv.cws.common.webservice.rule.CwsRuleExecutor;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Date;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
public class FaillissementSurseanceMapperTest {

    @InjectMocks
    private FaillissementSurseanceMapper faillissementSurseanceMapper;

    @Mock
    private CwsRuleExecutor ruleExecutor;

    @Captor
    private ArgumentCaptor<String> ihpFieldCaptor;

    @Captor
    private ArgumentCaptor<String> xsdFieldCaptor;

    @Test
    @DisplayName("Given FaillissementSurseanceWg test mapping fields to JaxB is successful")
    public void testMapToJaxbFaillissementSurseanceWg() {
        FaillissementSurseanceWg faillissementSurseanceWg = createFaillissementSurseanceWg();
        faillissementSurseanceMapper.mapToJaxbFaillissementSurseanceWg(faillissementSurseanceWg);

        verify(ruleExecutor, times(6)).setTransformedValue(any(Object.class), xsdFieldCaptor.capture(), ihpFieldCaptor.capture());
        List<Object> ihpFieldValues = Arrays.asList("code faillissementSurseance", "code reden einde faillissementSurseance", "20210201", "0", "20221201", "0");
        List<Object> xsdFieldValues = Arrays.asList("cdFaillSurs", "cdRedenEindeFaillSurs", "datBFaillissementSurseance", "cdFictieveDatB", "datEFaillissementSurseance", "cdFictieveDatE");
        assertArrayEquals(ihpFieldValues.toArray(), ihpFieldCaptor.getAllValues().toArray());
        assertEquals(xsdFieldValues, xsdFieldCaptor.getAllValues());
    }

    @Test
    @DisplayName("Given FaillissementSurseanceWg test mapping fields to JaxB is successful")
    public void testMapToJaxbFaillissementSurseanceWgWithoutDates() {
        FaillissementSurseanceWg faillissementSurseanceWg = createFaillissementSurseanceWgWithoutDates();
        faillissementSurseanceMapper.mapToJaxbFaillissementSurseanceWg(faillissementSurseanceWg);

        verify(ruleExecutor, times(6)).setTransformedValue(any(Object.class), xsdFieldCaptor.capture(), ihpFieldCaptor.capture());
        List<Object> ihpFieldValues = Arrays.asList("code faillissementSurseance", "code reden einde faillissementSurseance", null, null, null, null);
        List<Object> xsdFieldValues = Arrays.asList("cdFaillSurs", "cdRedenEindeFaillSurs", "datBFaillissementSurseance", "cdFictieveDatB", "datEFaillissementSurseance", "cdFictieveDatE");
        assertArrayEquals(ihpFieldValues.toArray(), ihpFieldCaptor.getAllValues().toArray());
        assertEquals(xsdFieldValues, xsdFieldCaptor.getAllValues());
    }

    private FaillissementSurseanceWg createFaillissementSurseanceWg() {
        return FaillissementSurseanceWg.builder()
                .codeFaillissementSurseance("code faillissementSurseance")
                .codeRedenEindeFaillissementSurseance("code reden einde faillissementSurseance")
                .datumAanvangFaillissementSurseance(20210201L)
                .datumEindeFaillissementSurseance(20221201L)
                .build();
    }

    private FaillissementSurseanceWg createFaillissementSurseanceWgWithoutDates() {
        return FaillissementSurseanceWg.builder()
                .codeFaillissementSurseance("code faillissementSurseance")
                .codeRedenEindeFaillissementSurseance("code reden einde faillissementSurseance")
                .datumAanvangFaillissementSurseance(null)
                .datumEindeFaillissementSurseance(null)
                .build();
    }

    @Test
    @DisplayName("Given FaillissementSurseanceHr test mapping fields to JaxB is successful")
    public void testMapToJaxbFaillissementSurseanceHr() {
        FaillissementSurseanceHr faillissementSurseanceHr = createFaillissementSurseanceHr();
        faillissementSurseanceMapper.mapToJaxbFaillissementSurseanceHr(faillissementSurseanceHr);

        verify(ruleExecutor, times(5)).setTransformedValue(any(Object.class), xsdFieldCaptor.capture(), ihpFieldCaptor.capture());
        List<String> hrFieldValues = Arrays.asList( "C","20180201","0", "20190201", "0");
        List<String> xsdFieldValues = Arrays.asList("cdFaillSurs", "datBFaillissementSurseance", "cdFictieveDatB", "datEFaillissementSurseance", "cdFictieveDatE");

        assertArrayEquals(hrFieldValues.toArray(), ihpFieldCaptor.getAllValues().toArray());
        assertEquals(xsdFieldValues, xsdFieldCaptor.getAllValues());
    }

    @Test
    @DisplayName("Given FaillissementSurseanceHr WithoutDates test mapping fields to JaxB is successful")
    public void testMapToJaxbFaillissementSurseanceWithoutDates() {
        FaillissementSurseanceHr faillissementSurseanceHr = createFaillissementSurseanceHrWithoutDates();
        faillissementSurseanceMapper.mapToJaxbFaillissementSurseanceHr(faillissementSurseanceHr);

        verify(ruleExecutor, times(5)).setTransformedValue(any(Object.class), xsdFieldCaptor.capture(), ihpFieldCaptor.capture());
        List<String> hrFieldValues = Arrays.asList( "C",null,null, null, null);
        List<String> xsdFieldValues = Arrays.asList("cdFaillSurs", "datBFaillissementSurseance", "cdFictieveDatB", "datEFaillissementSurseance", "cdFictieveDatE");

        assertArrayEquals(hrFieldValues.toArray(), ihpFieldCaptor.getAllValues().toArray());
        assertEquals(xsdFieldValues, xsdFieldCaptor.getAllValues());
    }

    private FaillissementSurseanceHr createFaillissementSurseanceHr() {
        return FaillissementSurseanceHr.builder()
                .codeFaillissementSurseance("C")
                .datumAanvangFaillissementSurseance(Date.valueOf(LocalDate.of(2018,2,1)))
                .codeFictieveDatumAanvang(0)
                .datumEindeFaillissementSurseance(Date.valueOf(LocalDate.of(2019,2,1)))
                .codeFictieveDatumEinde(0)
                .build();
    }

    private FaillissementSurseanceHr createFaillissementSurseanceHrWithoutDates() {
        return FaillissementSurseanceHr.builder()
                .codeFaillissementSurseance("C")
                .datumAanvangFaillissementSurseance(null)
                .codeFictieveDatumAanvang(0)
                .datumEindeFaillissementSurseance(null)
                .codeFictieveDatumEinde(0)
                .build();
    }
}
