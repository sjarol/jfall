package nl.uwv.cws.cwsihp.webservice.rule.transformer;

import nl.uwv.cws.common.model.rule.AttributeRuleProperties;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static nl.uwv.cws.cwsihp.model.rule.CwsIhpAttributeRule.AFKAPPEN_OBV_SIZE_MAX;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

public class AfkappenObvSizeMaxTransformerTest {

    private AfkappenObvSizeMaxTransformer afkappenObvSizeMaxTransformer;
    private AttributeRuleProperties attributeRuleProperties;

    @BeforeEach
    public void setup() {
        afkappenObvSizeMaxTransformer = new AfkappenObvSizeMaxTransformer();
        attributeRuleProperties = new AttributeRuleProperties();
        attributeRuleProperties.setSizeMax(24);
    }

    @Test
    @DisplayName("Should use correct rule type")
    public void given_afkappenObvSizeMaxTransformer_shouldUseCorrectType() {
        assertThat(afkappenObvSizeMaxTransformer.getTransformRule(), is(AFKAPPEN_OBV_SIZE_MAX));
    }

    @Test
    @DisplayName("Should return transformed value when size is bigger than sizemax")
    public void given_valueBiggerNeedsTruncate_shouldTruncate() {
        String originalValue = "Straatnaambuitenlandistelang";
        String transformedValue = afkappenObvSizeMaxTransformer.transform(originalValue, attributeRuleProperties);
        assertThat(transformedValue, is("Straatnaambuitenlandiste"));
    }

    @Test
    @DisplayName("Should return original value when size is smaller than sizemax")
    public void given_valueSmallerDoesNotNeedTruncate_shouldNotTruncate() {
        String originalValue = "Kortenaam";
        String transformedValue = afkappenObvSizeMaxTransformer.transform(originalValue, attributeRuleProperties);
        assertThat(transformedValue, is("Kortenaam"));
    }

    @Test
    @DisplayName("Should return original value when size equals sizemax")
    public void given_valueEqualDoesNotNeedTruncate_shouldNotTruncate() {
        String originalValue = "Preciesjuistelengte naam";
        String transformedValue = afkappenObvSizeMaxTransformer.transform(originalValue, attributeRuleProperties);
        assertThat(transformedValue, is("Preciesjuistelengte naam"));
    }
}
