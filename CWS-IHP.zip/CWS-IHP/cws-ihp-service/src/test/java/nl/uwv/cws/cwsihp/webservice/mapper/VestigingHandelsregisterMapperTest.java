package nl.uwv.cws.cwsihp.webservice.mapper;

import nl.uwv.cws.cwsihp.model.hr.*;
import nl.uwv.cws.common.webservice.rule.CwsRuleExecutor;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Date;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
public class VestigingHandelsregisterMapperTest {

    @InjectMocks
    private VestigingHandelsregisterMapper vestigingHandelsregisterMapper;

    @Mock
    private OndernemingMapper ondernemingMapper;

    @Mock
    private ActiviteitHandelsregisterMapper activiteitHandelsregisterMapper;

    @Mock
    private AdreshoudingMapper adreshoudingMapper;

    @Mock
    private HandelsnaamMapper handelsnaamMapper;

    @Mock
    private SbiklasseMapper sbiklasseMapper;

    @Mock
    private CwsRuleExecutor ruleExecutor;

    @Captor
    private ArgumentCaptor<Object> ihpFieldCaptor;

    @Captor
    private ArgumentCaptor<String> xsdFieldCaptor;

    @Test
    @DisplayName("Given VestigingHandelsregisterHr test mapping fields to JaxB is successful")
    public void testMapToJaxbVestigingHandelsregister() {
        VestigingHandelsregisterHr vestigingHandelsregisterHr = createVestigingHandelsregisterHr();
        vestigingHandelsregisterMapper.mapToJaxbVestigingHandelsregister(vestigingHandelsregisterHr);

        verify(ruleExecutor, times(6)).setTransformedValue(any(Object.class), xsdFieldCaptor.capture(), ihpFieldCaptor.capture());
        List<String> hrFieldValues = Arrays.asList("123456789","Eerste Handelsnaam","20200101", "1", "20200131", "2");
        List<String> xsdFieldValues = Arrays.asList("vestigingsnrHandelsregister", "eersteHandelsnaam",
                "datBVestigingHandelsregister", "cdFictieveDatB", "datEVestigingHandelsregister", "cdFictieveDatE");
        assertArrayEquals(hrFieldValues.toArray(), ihpFieldCaptor.getAllValues().toArray());
        assertEquals(xsdFieldValues, xsdFieldCaptor.getAllValues());
    }

    @Test
    @DisplayName("Given VestigingHandelsregisterHr without KvkNr and dates test mapping fields to JaxB is successful")
    public void testMapToJaxbVestigingHandelsregisterWithoutKvkNrAndDates() {
        VestigingHandelsregisterHr vestigingHandelsregisterHr = createVestigingHandelsregisterHrWithoutKvkNrAndDates();
        vestigingHandelsregisterMapper.mapToJaxbVestigingHandelsregister(vestigingHandelsregisterHr);

        verify(ruleExecutor, times(6)).setTransformedValue(any(Object.class), xsdFieldCaptor.capture(), ihpFieldCaptor.capture());
        List<String> hrFieldValues = Arrays.asList(null,"Eerste Handelsnaam",null, null, null, null);
        List<String> xsdFieldValues = Arrays.asList("vestigingsnrHandelsregister", "eersteHandelsnaam",
                "datBVestigingHandelsregister", "cdFictieveDatB", "datEVestigingHandelsregister", "cdFictieveDatE");
        assertArrayEquals(hrFieldValues.toArray(), ihpFieldCaptor.getAllValues().toArray());
        assertEquals(xsdFieldValues, xsdFieldCaptor.getAllValues());
    }

    @Test
    @DisplayName("Given VestigingHandelsregisterHr with subentities verify mappers are called")
    public void testMapToJaxbVestigingHandelsregisterWithOnderneming() {
        VestigingHandelsregisterHr vestigingHandelsregisterHr = createVestigingHandelsregisterHr();
        OndernemingHr ondernemingHr = createOndernemingHr();
        vestigingHandelsregisterHr.setOndernemingHrList(Arrays.asList(ondernemingHr));
        vestigingHandelsregisterMapper.mapToJaxbVestigingHandelsregister(vestigingHandelsregisterHr);

        verify(ondernemingMapper,times(1)).mapToJaxbOnderneming(any(OndernemingHr.class));
    }

    @Test
    @DisplayName("Given VestigingHandelsregisterHr with ActiviteitHandelsregisterHr verify activiteitHandelsregisterMapper is called")
    public void testMapToJaxbVestigingHandelsregisterWithVestigingHandelsregisterHr() {
        VestigingHandelsregisterHr vestigingHandelsregisterHr = createVestigingHandelsregisterHr();
        OndernemingHr ondernemingHr = createOndernemingHr();
        vestigingHandelsregisterHr.setOndernemingHrList(Arrays.asList(ondernemingHr));

        ActiviteitHandelsregisterHr activiteitHandelsregisterHr = createActiviteitHandelsregisterHr();
        vestigingHandelsregisterHr.setActiviteitHandelsregisterHr(activiteitHandelsregisterHr);

        HandelsnaamHr handelsnaamHr = createHandelsnaamHr();
        vestigingHandelsregisterHr.setHandelsnaamHrList(Arrays.asList(handelsnaamHr));

        AdreshoudingHr adreshoudingHr = createAdreshoudingHr();
        vestigingHandelsregisterHr.setAdreshoudingHr(adreshoudingHr);

        vestigingHandelsregisterMapper.mapToJaxbVestigingHandelsregister(vestigingHandelsregisterHr);

        verify(ondernemingMapper,times(1)).mapToJaxbOnderneming(any(OndernemingHr.class));
        verify(activiteitHandelsregisterMapper,times(1)).mapToJaxbActiviteitHandelsregisterVestigingHandelsregister(any(ActiviteitHandelsregisterHr.class));
        verify(handelsnaamMapper,times(1)).mapToJaxbHandelsnaamVestigingHandelsregister(any(HandelsnaamHr.class));
        verify(adreshoudingMapper,times(1)).mapToJaxbAdresNederlandUhrVestigingHandelsregister(any(AdresNederlandHr.class));
        verify(adreshoudingMapper,times(1)).mapToJaxbAdresBuitenlandVestigingHandelsregister(any(AdresBuitenlandHr.class));
        verify(adreshoudingMapper,times(1)).mapToJaxbAdresBuitenlandOngestructureerdVestigingHandelsregister(any(AdresBuitenlandOngestructureerdHr.class));
    }

    private VestigingHandelsregisterHr createVestigingHandelsregisterHr() {
        return VestigingHandelsregisterHr.builder()
                .adreshoudingHr(AdreshoudingHr.builder().build())
                .vestigingsNummer(123456789L)
                .configurationIncludesVestigingsNummer(true)
                .eersteHandelsnaam("Eerste Handelsnaam")
                .datumAanvangVestigingHandelsregister(Date.valueOf(LocalDate.of(2020,1,1)))
                .codeFictieveDatumAanvang(1)
                .datumEindeVestigingHandelsregister(Date.valueOf(LocalDate.of(2020,1,31)))
                .codeFictieveDatumEinde(2)
                .build();
    }

    private VestigingHandelsregisterHr createVestigingHandelsregisterHrWithoutKvkNrAndDates() {
        return VestigingHandelsregisterHr.builder()
                .adreshoudingHr(AdreshoudingHr.builder().build())
                .vestigingsNummer(123456789L)
                .configurationIncludesVestigingsNummer(false)
                .eersteHandelsnaam("Eerste Handelsnaam")
                .datumAanvangVestigingHandelsregister(null)
                .codeFictieveDatumAanvang(1)
                .datumEindeVestigingHandelsregister(null)
                .codeFictieveDatumEinde(2)
                .build();
    }

    private OndernemingHr createOndernemingHr() {
        return OndernemingHr.builder()
                .build();
    }

    private ActiviteitHandelsregisterHr createActiviteitHandelsregisterHr() {
        return ActiviteitHandelsregisterHr.builder()
                .build();
    }

    private AdreshoudingHr createAdreshoudingHr() {
        return AdreshoudingHr.builder()
                .adresNederlandHrList(Arrays.asList(AdresNederlandHr.builder().codeAdresrol("W").build()))
                .adresBuitenlandHrList(Arrays.asList(AdresBuitenlandHr.builder().codeAdresrol("W").build()))
                .adresBuitenlandOngestructureerdHrList(Arrays.asList(AdresBuitenlandOngestructureerdHr.builder().landsnaam("Nederland").build()))
                .build();
    }

    private HandelsnaamHr createHandelsnaamHr() {
        return HandelsnaamHr.builder()
                .build();
    }
}
