package nl.uwv.cws.cwsihp.dao.mapper;

import nl.uwv.cws.cwsihp.model.ihp.Inhoudingsplichtige;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.ResultSet;
import java.sql.SQLException;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class InhoudingsplichtigeRowMapperTest {

    @InjectMocks
    private InhoudingsplichtigeRowMapper inhoudingsplichtigeRowMapper;

    @Mock
    private ResultSet resultSet;

    @Test
    @DisplayName("Should successfully set field of Inhoudingsplichtige NatuurlijkPersoon")
    public void testMapRow_NatuurlijkPersoon() throws SQLException {
        when(resultSet.getString("ID")).thenReturn("123456789");
        when(resultSet.getString("TYPE")).thenReturn("natuurlijkpersoon");

        Inhoudingsplichtige inhoudingsplichtige = inhoudingsplichtigeRowMapper.mapRow(resultSet, 1);
        assertThat(inhoudingsplichtige.getBsn(), is(equalTo("123456789")));
    }

    @Test
    @DisplayName("Should successfully set field of Inhoudingsplichtige NietNatuurlijkPersoon")
    public void testMapRow_NietNatuurlijkPersoon() throws SQLException {
        when(resultSet.getString("ID")).thenReturn("123456789");
        when(resultSet.getString("TYPE")).thenReturn("niet_natuurlijkpersoon");

        Inhoudingsplichtige inhoudingsplichtige = inhoudingsplichtigeRowMapper.mapRow(resultSet, 1);
        assertThat(inhoudingsplichtige.getRsin(), is(equalTo("123456789")));
    }
}
