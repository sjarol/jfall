WHENEVER SQLERROR EXIT SQL.SQLCODE
WHENEVER OSERROR  EXIT FAILURE

define version='1.2.0'
define instance='PPLS_WL'
define environment='PPLS'
define programmanm='CWS06'

select distinct program_version
from
   scaladiv.app_configuration
where
   upper(program_name) = upper('&programmanm')
   and (program_instance = '&instance' or replace(program_instance,'-','') like (replace(substr('&instance',1,instr('&instance','-',-1)-1),'-','') || '%') )
   and program_environment = '&environment'
order by 1 desc;

/*
 * Parameters for registering a program:
 *  program name, program major version, instance name, environment name
 */
call scaladiv.property_register_program(
	'&programmanm', '&version', '&instance', '&environment');

-- register webservice property default and description

/*
 * Parameters for registering properties and their defaults:
 *  - program name
 *  - program major version
 *  - instance name
 *  - environment name
 *  - property name
 *  - property default value
 *  - property description
 */
-- Eerst default waardes setten, dan kan er ook een description van de property toegevoegd worden.

call scaladiv.property_set_default(
	'&programmanm', '&version', '&instance', '&environment',
	'perf.log.max.sla', '3000', 'in mil sec: als een request langer dan deze value duurt, wordt een record toegevoegd in de performance tabel');

call scaladiv.property_set_default(
	'&programmanm', '&version', '&instance', '&environment',
	'perf.log.rate', '5', 'Het aantal requests dat een toevoeging van een record in de performance tabel triggert');

call scaladiv.property_set_default(
	'&programmanm', '&version', '&instance', '&environment',
	'cache.timeout', '5', 'timeout of de cache van ip-filtering ');

call scaladiv.property_set_default(
	'&programmanm', '&version', '&instance', '&environment',
	'logging.audit.enabled', 'true', 'audit logging actief');

call scaladiv.property_set_default(
	'&programmanm', '&version', '&instance', '&environment',
	'logging.audit.cachesize', '12', 'Cache grootte van de query logger op request niveau');

call scaladiv.property_set_default(
	'&programmanm', '&version', '&instance', '&environment',
	'log.response.active', 'false', 'Moet het antwoordbericht in het log bestand gelogd worden');
	
call scaladiv.property_set_default(
	'&programmanm', '&version', '&instance', '&environment',
    'perf.logging.active', 'true', 'performance logging actief');

-- Daarna property waardes expliciet zetten m.b.v. placeholders.
call scaladiv.property_set_value(
	'&programmanm', '&version', '&instance', '&environment',
	'perf.log.max.sla', '{{cws06_perf_log_max_sla}}');

call scaladiv.property_set_value(
	'&programmanm', '&version', '&instance', '&environment',
	'perf.log.rate', '{{cws06_perf_log_rate}}');

call scaladiv.property_set_value(
	'&programmanm', '&version', '&instance', '&environment',
	'cache.timeout', '{{cws06_cache_timeout}}');

call scaladiv.property_set_value(
	'&programmanm', '&version', '&instance', '&environment',
	'logging.audit.enabled', '{{cws06_logging_audit_enabled}}');

call scaladiv.property_set_value(
	'&programmanm', '&version', '&instance', '&environment',
	'logging.audit.cachesize', '{{cws06_logging_audit_cachesize}}');

call scaladiv.property_set_value(
	'&programmanm', '&version', '&instance', '&environment',
	'log.response.active', '{{cws06_log_response_active}}');

call scaladiv.property_set_value(
	'&programmanm', '&version', '&instance', '&environment',
    'perf.logging.active', '{{cws06_perf_logging_active}}');

commit;

PROMPT ===== setup_properties: Ok =====