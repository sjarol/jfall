WHENEVER SQLERROR EXIT SQL.SQLCODE
WHENEVER OSERROR  EXIT FAILURE

MERGE INTO scalameta.program A USING
 (SELECT
  1707 AS pgrm_id,
  'CWS06' AS name
  FROM DUAL) B
ON (A.pgrm_id = B.pgrm_id)
WHEN NOT MATCHED THEN
INSERT (pgrm_id, name)
VALUES (B.pgrm_id, B.name)
;

UPDATE scaladiv.programma_versie
SET pgrm_id = 1707
WHERE pgrm_id IN (SELECT pgrm_id FROM scalameta.program WHERE name = 'CWS06')
AND pgrm_id <> 1707;

DELETE FROM scalameta.program
WHERE pgrm_id IN (SELECT pgrm_id FROM scalameta.program WHERE name = 'CWS06')
AND pgrm_id <> 1707;

COMMIT;