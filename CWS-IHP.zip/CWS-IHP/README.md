# CWS-IHP

Use the maven profile generate-sources as:
**mvn clean install -Pgenerate-sources** to generate Java objects from WSDL for the first time build.

