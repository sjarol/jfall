
package nl.uwv.schemas.uwvml.uwvml_basetypes_v0439;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for StdCdAfnameInd.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <pre>
 * &lt;simpleType name="StdCdAfnameInd"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;length value="1"/&gt;
 *     &lt;pattern value="[A-Z]*"/&gt;
 *     &lt;enumeration value="A"/&gt;
 *     &lt;enumeration value="S"/&gt;
 *     &lt;enumeration value="U"/&gt;
 *     &lt;enumeration value="V"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "StdCdAfnameInd", namespace = "http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439")
@XmlEnum
public enum StdCdAfnameInd {


    /**
     * Aan
     * 
     */
    A,

    /**
     * Stopzetten
     * 
     */
    S,

    /**
     * Uit
     * 
     */
    U,

    /**
     * Voortzetten
     * 
     */
    V;

    public String value() {
        return name();
    }

    public static StdCdAfnameInd fromValue(String v) {
        return valueOf(v);
    }

}
