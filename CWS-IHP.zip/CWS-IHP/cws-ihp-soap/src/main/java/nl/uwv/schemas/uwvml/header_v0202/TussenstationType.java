
package nl.uwv.schemas.uwvml.header_v0202;

import java.util.ArrayList;
import java.util.List;
import javax.validation.Valid;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for TussenstationType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="TussenstationType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://schemas.uwv.nl/UwvML/Header-v0202}Partij"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Volgordenr" type="{http://www.w3.org/2001/XMLSchema}unsignedInt" minOccurs="0"/&gt;
 *         &lt;element name="DatTijdOntvangstBericht" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/&gt;
 *         &lt;element name="DatTijdVersturenBericht" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/&gt;
 *         &lt;element name="InnerTussenstation" type="{http://schemas.uwv.nl/UwvML/Header-v0202}TussenstationType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TussenstationType", propOrder = {
    "volgordenr",
    "datTijdOntvangstBericht",
    "datTijdVersturenBericht",
    "innerTussenstation"
})
public class TussenstationType
    extends Partij
{

    @XmlElement(name = "Volgordenr")
    @XmlSchemaType(name = "unsignedInt")
    @DecimalMax("4294967295")
    @DecimalMin("0")
    protected Long volgordenr;
    @XmlElement(name = "DatTijdOntvangstBericht")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar datTijdOntvangstBericht;
    @XmlElement(name = "DatTijdVersturenBericht")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar datTijdVersturenBericht;
    @XmlElement(name = "InnerTussenstation")
    @Valid
    protected List<TussenstationType> innerTussenstation;

    /**
     * Gets the value of the volgordenr property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getVolgordenr() {
        return volgordenr;
    }

    /**
     * Sets the value of the volgordenr property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setVolgordenr(Long value) {
        this.volgordenr = value;
    }

    /**
     * Gets the value of the datTijdOntvangstBericht property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDatTijdOntvangstBericht() {
        return datTijdOntvangstBericht;
    }

    /**
     * Sets the value of the datTijdOntvangstBericht property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDatTijdOntvangstBericht(XMLGregorianCalendar value) {
        this.datTijdOntvangstBericht = value;
    }

    /**
     * Gets the value of the datTijdVersturenBericht property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDatTijdVersturenBericht() {
        return datTijdVersturenBericht;
    }

    /**
     * Sets the value of the datTijdVersturenBericht property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDatTijdVersturenBericht(XMLGregorianCalendar value) {
        this.datTijdVersturenBericht = value;
    }

    /**
     * Gets the value of the innerTussenstation property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the innerTussenstation property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getInnerTussenstation().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link TussenstationType }
     * 
     * 
     */
    public List<TussenstationType> getInnerTussenstation() {
        if (innerTussenstation == null) {
            innerTussenstation = new ArrayList<TussenstationType>();
        }
        return this.innerTussenstation;
    }

}
