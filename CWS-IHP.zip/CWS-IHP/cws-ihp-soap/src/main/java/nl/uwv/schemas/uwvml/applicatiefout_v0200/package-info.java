@javax.xml.bind.annotation.XmlSchema(namespace = "http://schemas.uwv.nl/UwvML/ApplicatieFout-v0200")
package nl.uwv.schemas.uwvml.applicatiefout_v0200;
