
package nl.uwv.schemas.uwvml.uwvml_basetypes_v0439;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for StdCdContrvormOvertredInlplich.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <pre>
 * &lt;simpleType name="StdCdContrvormOvertredInlplich"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;maxLength value="12"/&gt;
 *     &lt;enumeration value="Beiden"/&gt;
 *     &lt;enumeration value="Stoelcontrole"/&gt;
 *     &lt;enumeration value="Zichtcontrole"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "StdCdContrvormOvertredInlplich", namespace = "http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439")
@XmlEnum
public enum StdCdContrvormOvertredInlplich {


    /**
     * Combinatie van zicht- en stoelcontrole
     * 
     */
    @XmlEnumValue("Beiden")
    BEIDEN("Beiden"),

    /**
     * Onderzoek a.d.h.v. gegevens in de verschillende systeme
     * 
     */
    @XmlEnumValue("Stoelcontrole")
    STOELCONTROLE("Stoelcontrole"),

    /**
     * Controle d.m.v. navraag
     * 
     */
    @XmlEnumValue("Zichtcontrole")
    ZICHTCONTROLE("Zichtcontrole");
    private final String value;

    StdCdContrvormOvertredInlplich(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static StdCdContrvormOvertredInlplich fromValue(String v) {
        for (StdCdContrvormOvertredInlplich c: StdCdContrvormOvertredInlplich.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
