
package nl.uwv.schemas.uwvml.header_v0202;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * Stuurgegevens ter ondersteuning van het UwvML protocol.
 * 
 * <p>Java class for UwvMLHeader complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="UwvMLHeader"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="RouteInformatie"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;extension base="{http://schemas.uwv.nl/UwvML/Header-v0202}RouteInformatie"&gt;
 *               &lt;/extension&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="BerichtIdentificatie" type="{http://schemas.uwv.nl/UwvML/Header-v0202}BerichtIdentificatie"/&gt;
 *         &lt;element name="Transactie" type="{http://schemas.uwv.nl/UwvML/Header-v0202}Transactie" minOccurs="0"/&gt;
 *         &lt;element name="Authenticatie" type="{http://schemas.uwv.nl/UwvML/Header-v0202}Authenticatie" minOccurs="0"/&gt;
 *         &lt;element name="TransportServiceWensen" type="{http://schemas.uwv.nl/UwvML/Header-v0202}TransportServiceWensen" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "UwvMLHeader", propOrder = {
    "routeInformatie",
    "berichtIdentificatie",
    "transactie",
    "authenticatie",
    "transportServiceWensen"
})
public class UwvMLHeader {

    @XmlElement(name = "RouteInformatie", required = true)
    @NotNull
    @Valid
    protected UwvMLHeader.RouteInformatie routeInformatie;
    @XmlElement(name = "BerichtIdentificatie", required = true)
    @NotNull
    @Valid
    protected BerichtIdentificatie berichtIdentificatie;
    @XmlElement(name = "Transactie")
    @Valid
    protected Transactie transactie;
    @XmlElement(name = "Authenticatie")
    @Valid
    protected Authenticatie authenticatie;
    @XmlElement(name = "TransportServiceWensen")
    @Valid
    protected TransportServiceWensen transportServiceWensen;

    /**
     * Gets the value of the routeInformatie property.
     * 
     * @return
     *     possible object is
     *     {@link UwvMLHeader.RouteInformatie }
     *     
     */
    public UwvMLHeader.RouteInformatie getRouteInformatie() {
        return routeInformatie;
    }

    /**
     * Sets the value of the routeInformatie property.
     * 
     * @param value
     *     allowed object is
     *     {@link UwvMLHeader.RouteInformatie }
     *     
     */
    public void setRouteInformatie(UwvMLHeader.RouteInformatie value) {
        this.routeInformatie = value;
    }

    /**
     * Gets the value of the berichtIdentificatie property.
     * 
     * @return
     *     possible object is
     *     {@link BerichtIdentificatie }
     *     
     */
    public BerichtIdentificatie getBerichtIdentificatie() {
        return berichtIdentificatie;
    }

    /**
     * Sets the value of the berichtIdentificatie property.
     * 
     * @param value
     *     allowed object is
     *     {@link BerichtIdentificatie }
     *     
     */
    public void setBerichtIdentificatie(BerichtIdentificatie value) {
        this.berichtIdentificatie = value;
    }

    /**
     * Gets the value of the transactie property.
     * 
     * @return
     *     possible object is
     *     {@link Transactie }
     *     
     */
    public Transactie getTransactie() {
        return transactie;
    }

    /**
     * Sets the value of the transactie property.
     * 
     * @param value
     *     allowed object is
     *     {@link Transactie }
     *     
     */
    public void setTransactie(Transactie value) {
        this.transactie = value;
    }

    /**
     * Gets the value of the authenticatie property.
     * 
     * @return
     *     possible object is
     *     {@link Authenticatie }
     *     
     */
    public Authenticatie getAuthenticatie() {
        return authenticatie;
    }

    /**
     * Sets the value of the authenticatie property.
     * 
     * @param value
     *     allowed object is
     *     {@link Authenticatie }
     *     
     */
    public void setAuthenticatie(Authenticatie value) {
        this.authenticatie = value;
    }

    /**
     * Gets the value of the transportServiceWensen property.
     * 
     * @return
     *     possible object is
     *     {@link TransportServiceWensen }
     *     
     */
    public TransportServiceWensen getTransportServiceWensen() {
        return transportServiceWensen;
    }

    /**
     * Sets the value of the transportServiceWensen property.
     * 
     * @param value
     *     allowed object is
     *     {@link TransportServiceWensen }
     *     
     */
    public void setTransportServiceWensen(TransportServiceWensen value) {
        this.transportServiceWensen = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;extension base="{http://schemas.uwv.nl/UwvML/Header-v0202}RouteInformatie"&gt;
     *     &lt;/extension&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    public static class RouteInformatie
        extends nl.uwv.schemas.uwvml.header_v0202.RouteInformatie
    {


    }

}
