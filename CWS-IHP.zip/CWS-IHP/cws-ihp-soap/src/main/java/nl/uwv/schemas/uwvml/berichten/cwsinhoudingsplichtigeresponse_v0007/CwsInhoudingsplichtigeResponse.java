
package nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0007;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import javax.validation.Valid;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;choice&gt;
 *           &lt;element name="Gegevenslevering"&gt;
 *             &lt;complexType&gt;
 *               &lt;complexContent&gt;
 *                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                   &lt;sequence&gt;
 *                     &lt;element name="DatTijdBeschouwingGebVSelectie" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatTijd20" minOccurs="0"/&gt;
 *                     &lt;element name="KvkNr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdKvkNr" minOccurs="0"/&gt;
 *                     &lt;element name="NrInhoudingsplichtige" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdNrInhoudingsplichtige" minOccurs="0"/&gt;
 *                     &lt;element name="Loonheffingennr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLoonheffingennr" minOccurs="0"/&gt;
 *                     &lt;element name="PersoonInhoudingsplichtige" maxOccurs="unbounded" minOccurs="0"&gt;
 *                       &lt;complexType&gt;
 *                         &lt;complexContent&gt;
 *                           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                             &lt;sequence&gt;
 *                               &lt;choice minOccurs="0"&gt;
 *                                 &lt;element name="NietNatuurlijkPersoon" minOccurs="0"&gt;
 *                                   &lt;complexType&gt;
 *                                     &lt;complexContent&gt;
 *                                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                         &lt;sequence&gt;
 *                                           &lt;element name="DatOntbindingRechtspSamenwerking" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                           &lt;element name="DatOprichtingRechtspSamenwerking" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                           &lt;element name="Rsin" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdRsin" minOccurs="0"/&gt;
 *                                           &lt;element name="DatBNietNatuurlijkPersoon" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                           &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
 *                                           &lt;element name="DatENietNatuurlijkPersoon" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                           &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
 *                                           &lt;element name="VolledigeNmNietNatuurlijkPersoon" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar500" minOccurs="0"/&gt;
 *                                           &lt;element name="Rechtspersoon" minOccurs="0"&gt;
 *                                             &lt;complexType&gt;
 *                                               &lt;complexContent&gt;
 *                                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                                   &lt;sequence&gt;
 *                                                     &lt;element name="StatutaireZetel" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar60" minOccurs="0"/&gt;
 *                                                     &lt;element name="DatBStatutaireZetel" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                                     &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
 *                                                     &lt;element name="ActiviteitHandelsregister" minOccurs="0"&gt;
 *                                                       &lt;complexType&gt;
 *                                                         &lt;complexContent&gt;
 *                                                           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                                             &lt;sequence&gt;
 *                                                               &lt;element name="OmsActiviteitHandelsregister" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdTekstAnVar2000" minOccurs="0"/&gt;
 *                                                             &lt;/sequence&gt;
 *                                                           &lt;/restriction&gt;
 *                                                         &lt;/complexContent&gt;
 *                                                       &lt;/complexType&gt;
 *                                                     &lt;/element&gt;
 *                                                   &lt;/sequence&gt;
 *                                                 &lt;/restriction&gt;
 *                                               &lt;/complexContent&gt;
 *                                             &lt;/complexType&gt;
 *                                           &lt;/element&gt;
 *                                           &lt;element name="VennootschapBuitenland" minOccurs="0"&gt;
 *                                             &lt;complexType&gt;
 *                                               &lt;complexContent&gt;
 *                                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                                   &lt;sequence&gt;
 *                                                     &lt;element name="DatBVennootschapBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                                     &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
 *                                                     &lt;element name="DatEVennootschapBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                                     &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
 *                                                   &lt;/sequence&gt;
 *                                                 &lt;/restriction&gt;
 *                                               &lt;/complexContent&gt;
 *                                             &lt;/complexType&gt;
 *                                           &lt;/element&gt;
 *                                         &lt;/sequence&gt;
 *                                       &lt;/restriction&gt;
 *                                     &lt;/complexContent&gt;
 *                                   &lt;/complexType&gt;
 *                                 &lt;/element&gt;
 *                                 &lt;element name="NatuurlijkPersoon" minOccurs="0"&gt;
 *                                   &lt;complexType&gt;
 *                                     &lt;complexContent&gt;
 *                                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                         &lt;sequence&gt;
 *                                           &lt;element name="Burgerservicenr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdBurgerservicenr" minOccurs="0"/&gt;
 *                                           &lt;element name="Voorletters" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdVoorletters" minOccurs="0"/&gt;
 *                                           &lt;element name="Voornamen" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdVoornamen" minOccurs="0"/&gt;
 *                                           &lt;element name="Voorvoegsel" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdVoorvoegsel" minOccurs="0"/&gt;
 *                                           &lt;element name="SignificantDeelVanDeAchternaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdSignificantDeelAchtern" minOccurs="0"/&gt;
 *                                           &lt;element name="CdAanduidingNaamgebruik" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAanduidingNaamgebruik_nocodes" minOccurs="0"/&gt;
 *                                           &lt;element name="Geboortedat" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                           &lt;element name="CdFictieveGeboortedat" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
 *                                           &lt;element name="Geslacht" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdGeslacht_nocodes" minOccurs="0"/&gt;
 *                                           &lt;element name="HuwelijkGeregistreerdPartner" minOccurs="0"&gt;
 *                                             &lt;complexType&gt;
 *                                               &lt;complexContent&gt;
 *                                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                                   &lt;sequence&gt;
 *                                                     &lt;element name="VoorvoegselEchtgenoot" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdVoorvoegsel" minOccurs="0"/&gt;
 *                                                     &lt;element name="SignificantDeelAchternaamEchtg" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdSignificantDeelAchtern" minOccurs="0"/&gt;
 *                                                   &lt;/sequence&gt;
 *                                                 &lt;/restriction&gt;
 *                                               &lt;/complexContent&gt;
 *                                             &lt;/complexType&gt;
 *                                           &lt;/element&gt;
 *                                         &lt;/sequence&gt;
 *                                       &lt;/restriction&gt;
 *                                     &lt;/complexContent&gt;
 *                                   &lt;/complexType&gt;
 *                                 &lt;/element&gt;
 *                                 &lt;element name="PersoonHandelsregister" minOccurs="0"&gt;
 *                                   &lt;complexType&gt;
 *                                     &lt;complexContent&gt;
 *                                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                         &lt;sequence&gt;
 *                                           &lt;element name="DatBPersoonHandelsregister" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                           &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
 *                                           &lt;element name="DatEPersoonHandelsregister" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                           &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
 *                                           &lt;element name="NaamPersoonHandelsregister" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar300" minOccurs="0"/&gt;
 *                                           &lt;element name="VolledigeNmPersHandelsregister" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar500" minOccurs="0"/&gt;
 *                                         &lt;/sequence&gt;
 *                                       &lt;/restriction&gt;
 *                                     &lt;/complexContent&gt;
 *                                   &lt;/complexType&gt;
 *                                 &lt;/element&gt;
 *                               &lt;/choice&gt;
 *                               &lt;element name="Rechtsvorm" maxOccurs="unbounded" minOccurs="0"&gt;
 *                                 &lt;complexType&gt;
 *                                   &lt;complexContent&gt;
 *                                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                       &lt;sequence&gt;
 *                                         &lt;element name="CdRechtsvorm" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdCdRechtsvorm" minOccurs="0"/&gt;
 *                                         &lt;element name="DatBRechtsvorm" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                         &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
 *                                         &lt;element name="DatERechtsvorm" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                         &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
 *                                       &lt;/sequence&gt;
 *                                     &lt;/restriction&gt;
 *                                   &lt;/complexContent&gt;
 *                                 &lt;/complexType&gt;
 *                               &lt;/element&gt;
 *                               &lt;element name="FaillSurs" maxOccurs="unbounded" minOccurs="0"&gt;
 *                                 &lt;complexType&gt;
 *                                   &lt;complexContent&gt;
 *                                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                       &lt;sequence&gt;
 *                                         &lt;element name="CdFaillSurs" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFaillissementSurseance_nocodes" minOccurs="0"/&gt;
 *                                         &lt;element name="CdRedenEindeFaillSurs" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdRedenEindeFaillisSurseance_nocodes" minOccurs="0"/&gt;
 *                                         &lt;element name="DatBFaillissementSurseance" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                         &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
 *                                         &lt;element name="DatEFaillissementSurseance" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                         &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
 *                                       &lt;/sequence&gt;
 *                                     &lt;/restriction&gt;
 *                                   &lt;/complexContent&gt;
 *                                 &lt;/complexType&gt;
 *                               &lt;/element&gt;
 *                               &lt;element name="Gemoedsbezwaardheid" maxOccurs="unbounded" minOccurs="0"&gt;
 *                                 &lt;complexType&gt;
 *                                   &lt;complexContent&gt;
 *                                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                       &lt;sequence&gt;
 *                                         &lt;element name="CdSzProduct" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdSzProduct_nocodes" minOccurs="0"/&gt;
 *                                         &lt;element name="DatBGemoedsbezwaardheid" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                         &lt;element name="DatEGemoedsbezwaardheid" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                       &lt;/sequence&gt;
 *                                     &lt;/restriction&gt;
 *                                   &lt;/complexContent&gt;
 *                                 &lt;/complexType&gt;
 *                               &lt;/element&gt;
 *                               &lt;element name="Adreshouding" maxOccurs="unbounded" minOccurs="0"&gt;
 *                                 &lt;complexType&gt;
 *                                   &lt;complexContent&gt;
 *                                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                       &lt;sequence&gt;
 *                                         &lt;choice&gt;
 *                                           &lt;element name="AdresNederlandUhr"&gt;
 *                                             &lt;complexType&gt;
 *                                               &lt;complexContent&gt;
 *                                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                                   &lt;sequence&gt;
 *                                                     &lt;element name="CdAdresrol" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAdresrol_nocodes" minOccurs="0"/&gt;
 *                                                     &lt;element name="DatBAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                                     &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
 *                                                     &lt;element name="DatEAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                                     &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
 *                                                     &lt;element name="CdAfgeschermdAdres" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdOJNNvt_nocodes" minOccurs="0"/&gt;
 *                                                     &lt;choice minOccurs="0"&gt;
 *                                                       &lt;element name="StraatadresUhr" minOccurs="0"&gt;
 *                                                         &lt;complexType&gt;
 *                                                           &lt;complexContent&gt;
 *                                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                                               &lt;sequence&gt;
 *                                                                 &lt;element name="Postcd" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcd" minOccurs="0"/&gt;
 *                                                                 &lt;element name="Woonplaatsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
 *                                                                 &lt;element name="Straatnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdStraatnaam" minOccurs="0"/&gt;
 *                                                                 &lt;element name="Huisnr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisnr" minOccurs="0"/&gt;
 *                                                                 &lt;element name="Huisletter" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisletter" minOccurs="0"/&gt;
 *                                                                 &lt;element name="Huisnrtoevoeging" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar4" minOccurs="0"/&gt;
 *                                                                 &lt;element name="CdAanduidingBijHuisnr" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAanduidingBijHuisnr_nocodes" minOccurs="0"/&gt;
 *                                                                 &lt;element name="NaamOpenbareRuimte" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar80" minOccurs="0"/&gt;
 *                                                               &lt;/sequence&gt;
 *                                                             &lt;/restriction&gt;
 *                                                           &lt;/complexContent&gt;
 *                                                         &lt;/complexType&gt;
 *                                                       &lt;/element&gt;
 *                                                       &lt;element name="PostbusadresUhr" minOccurs="0"&gt;
 *                                                         &lt;complexType&gt;
 *                                                           &lt;complexContent&gt;
 *                                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                                               &lt;sequence&gt;
 *                                                                 &lt;element name="Postcd" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcd" minOccurs="0"/&gt;
 *                                                                 &lt;element name="Woonplaatsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
 *                                                                 &lt;element name="Postbusnr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostbusnr" minOccurs="0"/&gt;
 *                                                               &lt;/sequence&gt;
 *                                                             &lt;/restriction&gt;
 *                                                           &lt;/complexContent&gt;
 *                                                         &lt;/complexType&gt;
 *                                                       &lt;/element&gt;
 *                                                     &lt;/choice&gt;
 *                                                   &lt;/sequence&gt;
 *                                                 &lt;/restriction&gt;
 *                                               &lt;/complexContent&gt;
 *                                             &lt;/complexType&gt;
 *                                           &lt;/element&gt;
 *                                           &lt;element name="AdresBuitenlandUhr"&gt;
 *                                             &lt;complexType&gt;
 *                                               &lt;complexContent&gt;
 *                                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                                   &lt;sequence&gt;
 *                                                     &lt;element name="CdAdresrol" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAdresrol_nocodes" minOccurs="0"/&gt;
 *                                                     &lt;element name="DatBAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                                     &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
 *                                                     &lt;element name="DatEAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                                     &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
 *                                                     &lt;element name="CdAfgeschermdAdres" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdOJNNvt_nocodes" minOccurs="0"/&gt;
 *                                                     &lt;choice minOccurs="0"&gt;
 *                                                       &lt;element name="StraatadresBuitenlandUhr" minOccurs="0"&gt;
 *                                                         &lt;complexType&gt;
 *                                                           &lt;complexContent&gt;
 *                                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                                               &lt;sequence&gt;
 *                                                                 &lt;element name="PostcdBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcdBuitenland" minOccurs="0"/&gt;
 *                                                                 &lt;element name="WoonplaatsnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
 *                                                                 &lt;element name="RegionaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar24" minOccurs="0"/&gt;
 *                                                                 &lt;element name="LandcodeGba" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeGba" minOccurs="0"/&gt;
 *                                                                 &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
 *                                                                 &lt;element name="Landsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandsnaam" minOccurs="0"/&gt;
 *                                                                 &lt;element name="StraatnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdStraatnaam" minOccurs="0"/&gt;
 *                                                                 &lt;element name="HuisnrBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisnrBuitenland" minOccurs="0"/&gt;
 *                                                                 &lt;element name="LocatieomsBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar128" minOccurs="0"/&gt;
 *                                                               &lt;/sequence&gt;
 *                                                             &lt;/restriction&gt;
 *                                                           &lt;/complexContent&gt;
 *                                                         &lt;/complexType&gt;
 *                                                       &lt;/element&gt;
 *                                                       &lt;element name="PostbusadresBuitenlandUhr" minOccurs="0"&gt;
 *                                                         &lt;complexType&gt;
 *                                                           &lt;complexContent&gt;
 *                                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                                               &lt;sequence&gt;
 *                                                                 &lt;element name="PostcdBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcdBuitenland" minOccurs="0"/&gt;
 *                                                                 &lt;element name="WoonplaatsnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
 *                                                                 &lt;element name="RegionaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar24" minOccurs="0"/&gt;
 *                                                                 &lt;element name="LandcodeGba" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeGba" minOccurs="0"/&gt;
 *                                                                 &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
 *                                                                 &lt;element name="Landsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandsnaam" minOccurs="0"/&gt;
 *                                                                 &lt;element name="PostbusnrBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdReferentienrAnVar8" minOccurs="0"/&gt;
 *                                                               &lt;/sequence&gt;
 *                                                             &lt;/restriction&gt;
 *                                                           &lt;/complexContent&gt;
 *                                                         &lt;/complexType&gt;
 *                                                       &lt;/element&gt;
 *                                                     &lt;/choice&gt;
 *                                                   &lt;/sequence&gt;
 *                                                 &lt;/restriction&gt;
 *                                               &lt;/complexContent&gt;
 *                                             &lt;/complexType&gt;
 *                                           &lt;/element&gt;
 *                                           &lt;element name="AdresBuitenlandOngestructureerdUhr"&gt;
 *                                             &lt;complexType&gt;
 *                                               &lt;complexContent&gt;
 *                                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                                   &lt;sequence&gt;
 *                                                     &lt;element name="CdAdresrol" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAdresrol_nocodes" minOccurs="0"/&gt;
 *                                                     &lt;element name="DatBAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                                     &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
 *                                                     &lt;element name="DatEAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                                     &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
 *                                                     &lt;element name="CdAfgeschermdAdres" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdOJNNvt_nocodes" minOccurs="0"/&gt;
 *                                                     &lt;element name="Adresregel1Buitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar35" minOccurs="0"/&gt;
 *                                                     &lt;element name="Adresregel2Buitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar35" minOccurs="0"/&gt;
 *                                                     &lt;element name="Adresregel3Buitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar35" minOccurs="0"/&gt;
 *                                                     &lt;element name="LandcodeGba" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeGba" minOccurs="0"/&gt;
 *                                                     &lt;element name="LandsnaamGba" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar40" minOccurs="0"/&gt;
 *                                                     &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
 *                                                     &lt;element name="Landsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandsnaam" minOccurs="0"/&gt;
 *                                                   &lt;/sequence&gt;
 *                                                 &lt;/restriction&gt;
 *                                               &lt;/complexContent&gt;
 *                                             &lt;/complexType&gt;
 *                                           &lt;/element&gt;
 *                                         &lt;/choice&gt;
 *                                       &lt;/sequence&gt;
 *                                     &lt;/restriction&gt;
 *                                   &lt;/complexContent&gt;
 *                                 &lt;/complexType&gt;
 *                               &lt;/element&gt;
 *                               &lt;element name="MaatschappelijkeActiviteit" maxOccurs="unbounded" minOccurs="0"&gt;
 *                                 &lt;complexType&gt;
 *                                   &lt;complexContent&gt;
 *                                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                       &lt;sequence&gt;
 *                                         &lt;element name="KvkNr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdKvkNr" minOccurs="0"/&gt;
 *                                         &lt;element name="DatBMaatschappelijkeActiviteit" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                         &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
 *                                         &lt;element name="DatEMaatschappelijkeActiviteit" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                         &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
 *                                         &lt;element name="Sbiklasse" maxOccurs="unbounded" minOccurs="0"&gt;
 *                                           &lt;complexType&gt;
 *                                             &lt;complexContent&gt;
 *                                               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                                 &lt;sequence&gt;
 *                                                   &lt;element name="CdSbi" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdSbi" minOccurs="0"/&gt;
 *                                                   &lt;element name="OmsSbi" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar300" minOccurs="0"/&gt;
 *                                                   &lt;element name="IndSbiHoofdactiviteit" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdIndJN_nocodes" minOccurs="0"/&gt;
 *                                                   &lt;element name="DatBSbiactiviteit" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                                   &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
 *                                                   &lt;element name="DatESbiactiviteit" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                                   &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
 *                                                 &lt;/sequence&gt;
 *                                               &lt;/restriction&gt;
 *                                             &lt;/complexContent&gt;
 *                                           &lt;/complexType&gt;
 *                                         &lt;/element&gt;
 *                                         &lt;element name="VestigingHandelsregister" maxOccurs="unbounded" minOccurs="0"&gt;
 *                                           &lt;complexType&gt;
 *                                             &lt;complexContent&gt;
 *                                               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                                 &lt;sequence&gt;
 *                                                   &lt;element name="VestigingsnrHandelsregister" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdVestigingsnrHandelsregister" minOccurs="0"/&gt;
 *                                                   &lt;element name="EersteHandelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar200" minOccurs="0"/&gt;
 *                                                   &lt;element name="DatBVestigingHandelsregister" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                                   &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
 *                                                   &lt;element name="DatEVestigingHandelsregister" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                                   &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
 *                                                   &lt;element name="Adreshouding" maxOccurs="unbounded" minOccurs="0"&gt;
 *                                                     &lt;complexType&gt;
 *                                                       &lt;complexContent&gt;
 *                                                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                                           &lt;sequence&gt;
 *                                                             &lt;choice&gt;
 *                                                               &lt;element name="AdresNederlandUhr"&gt;
 *                                                                 &lt;complexType&gt;
 *                                                                   &lt;complexContent&gt;
 *                                                                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                                                       &lt;sequence&gt;
 *                                                                         &lt;element name="CdAdresrol" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAdresrol_nocodes" minOccurs="0"/&gt;
 *                                                                         &lt;element name="DatBAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                                                         &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
 *                                                                         &lt;element name="DatEAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                                                         &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
 *                                                                         &lt;element name="CdAfgeschermdAdres" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdOJNNvt_nocodes" minOccurs="0"/&gt;
 *                                                                         &lt;choice minOccurs="0"&gt;
 *                                                                           &lt;element name="StraatadresUhr" minOccurs="0"&gt;
 *                                                                             &lt;complexType&gt;
 *                                                                               &lt;complexContent&gt;
 *                                                                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                                                                   &lt;sequence&gt;
 *                                                                                     &lt;element name="Postcd" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcd" minOccurs="0"/&gt;
 *                                                                                     &lt;element name="Woonplaatsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
 *                                                                                     &lt;element name="Straatnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdStraatnaam" minOccurs="0"/&gt;
 *                                                                                     &lt;element name="Huisnr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisnr" minOccurs="0"/&gt;
 *                                                                                     &lt;element name="Huisletter" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisletter" minOccurs="0"/&gt;
 *                                                                                     &lt;element name="Huisnrtoevoeging" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar4" minOccurs="0"/&gt;
 *                                                                                     &lt;element name="CdAanduidingBijHuisnr" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAanduidingBijHuisnr_nocodes" minOccurs="0"/&gt;
 *                                                                                     &lt;element name="NaamOpenbareRuimte" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar80" minOccurs="0"/&gt;
 *                                                                                   &lt;/sequence&gt;
 *                                                                                 &lt;/restriction&gt;
 *                                                                               &lt;/complexContent&gt;
 *                                                                             &lt;/complexType&gt;
 *                                                                           &lt;/element&gt;
 *                                                                           &lt;element name="PostbusadresUhr" minOccurs="0"&gt;
 *                                                                             &lt;complexType&gt;
 *                                                                               &lt;complexContent&gt;
 *                                                                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                                                                   &lt;sequence&gt;
 *                                                                                     &lt;element name="Postcd" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcd" minOccurs="0"/&gt;
 *                                                                                     &lt;element name="Woonplaatsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
 *                                                                                     &lt;element name="Postbusnr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostbusnr" minOccurs="0"/&gt;
 *                                                                                   &lt;/sequence&gt;
 *                                                                                 &lt;/restriction&gt;
 *                                                                               &lt;/complexContent&gt;
 *                                                                             &lt;/complexType&gt;
 *                                                                           &lt;/element&gt;
 *                                                                         &lt;/choice&gt;
 *                                                                       &lt;/sequence&gt;
 *                                                                     &lt;/restriction&gt;
 *                                                                   &lt;/complexContent&gt;
 *                                                                 &lt;/complexType&gt;
 *                                                               &lt;/element&gt;
 *                                                               &lt;element name="AdresBuitenlandUhr"&gt;
 *                                                                 &lt;complexType&gt;
 *                                                                   &lt;complexContent&gt;
 *                                                                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                                                       &lt;sequence&gt;
 *                                                                         &lt;element name="CdAdresrol" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAdresrol_nocodes" minOccurs="0"/&gt;
 *                                                                         &lt;element name="DatBAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                                                         &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
 *                                                                         &lt;element name="DatEAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                                                         &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
 *                                                                         &lt;element name="CdAfgeschermdAdres" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdOJNNvt_nocodes" minOccurs="0"/&gt;
 *                                                                         &lt;choice minOccurs="0"&gt;
 *                                                                           &lt;element name="StraatadresBuitenlandUhr" minOccurs="0"&gt;
 *                                                                             &lt;complexType&gt;
 *                                                                               &lt;complexContent&gt;
 *                                                                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                                                                   &lt;sequence&gt;
 *                                                                                     &lt;element name="PostcdBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcdBuitenland" minOccurs="0"/&gt;
 *                                                                                     &lt;element name="WoonplaatsnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
 *                                                                                     &lt;element name="RegionaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar24" minOccurs="0"/&gt;
 *                                                                                     &lt;element name="LandcodeGba" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeGba" minOccurs="0"/&gt;
 *                                                                                     &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
 *                                                                                     &lt;element name="Landsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandsnaam" minOccurs="0"/&gt;
 *                                                                                     &lt;element name="StraatnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdStraatnaam" minOccurs="0"/&gt;
 *                                                                                     &lt;element name="HuisnrBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisnrBuitenland" minOccurs="0"/&gt;
 *                                                                                     &lt;element name="LocatieomsBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar128" minOccurs="0"/&gt;
 *                                                                                   &lt;/sequence&gt;
 *                                                                                 &lt;/restriction&gt;
 *                                                                               &lt;/complexContent&gt;
 *                                                                             &lt;/complexType&gt;
 *                                                                           &lt;/element&gt;
 *                                                                           &lt;element name="PostbusadresBuitenlandUhr" minOccurs="0"&gt;
 *                                                                             &lt;complexType&gt;
 *                                                                               &lt;complexContent&gt;
 *                                                                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                                                                   &lt;sequence&gt;
 *                                                                                     &lt;element name="PostcdBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcdBuitenland" minOccurs="0"/&gt;
 *                                                                                     &lt;element name="WoonplaatsnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
 *                                                                                     &lt;element name="RegionaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar24" minOccurs="0"/&gt;
 *                                                                                     &lt;element name="LandcodeGba" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeGba" minOccurs="0"/&gt;
 *                                                                                     &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
 *                                                                                     &lt;element name="Landsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandsnaam" minOccurs="0"/&gt;
 *                                                                                     &lt;element name="PostbusnrBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdReferentienrAnVar8" minOccurs="0"/&gt;
 *                                                                                   &lt;/sequence&gt;
 *                                                                                 &lt;/restriction&gt;
 *                                                                               &lt;/complexContent&gt;
 *                                                                             &lt;/complexType&gt;
 *                                                                           &lt;/element&gt;
 *                                                                         &lt;/choice&gt;
 *                                                                       &lt;/sequence&gt;
 *                                                                     &lt;/restriction&gt;
 *                                                                   &lt;/complexContent&gt;
 *                                                                 &lt;/complexType&gt;
 *                                                               &lt;/element&gt;
 *                                                               &lt;element name="AdresBuitenlandOngestructureerdUhr"&gt;
 *                                                                 &lt;complexType&gt;
 *                                                                   &lt;complexContent&gt;
 *                                                                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                                                       &lt;sequence&gt;
 *                                                                         &lt;element name="CdAdresrol" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAdresrol_nocodes" minOccurs="0"/&gt;
 *                                                                         &lt;element name="DatBAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                                                         &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
 *                                                                         &lt;element name="DatEAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                                                         &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
 *                                                                         &lt;element name="CdAfgeschermdAdres" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdOJNNvt_nocodes" minOccurs="0"/&gt;
 *                                                                         &lt;element name="Adresregel1Buitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar35" minOccurs="0"/&gt;
 *                                                                         &lt;element name="Adresregel2Buitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar35" minOccurs="0"/&gt;
 *                                                                         &lt;element name="Adresregel3Buitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar35" minOccurs="0"/&gt;
 *                                                                         &lt;element name="LandcodeGba" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeGba" minOccurs="0"/&gt;
 *                                                                         &lt;element name="LandsnaamGba" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar40" minOccurs="0"/&gt;
 *                                                                         &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
 *                                                                         &lt;element name="Landsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandsnaam" minOccurs="0"/&gt;
 *                                                                       &lt;/sequence&gt;
 *                                                                     &lt;/restriction&gt;
 *                                                                   &lt;/complexContent&gt;
 *                                                                 &lt;/complexType&gt;
 *                                                               &lt;/element&gt;
 *                                                             &lt;/choice&gt;
 *                                                           &lt;/sequence&gt;
 *                                                         &lt;/restriction&gt;
 *                                                       &lt;/complexContent&gt;
 *                                                     &lt;/complexType&gt;
 *                                                   &lt;/element&gt;
 *                                                   &lt;element name="ActiviteitHandelsregister" minOccurs="0"&gt;
 *                                                     &lt;complexType&gt;
 *                                                       &lt;complexContent&gt;
 *                                                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                                           &lt;sequence&gt;
 *                                                             &lt;element name="OmsActiviteitHandelsregister" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdTekstAnVar2000" minOccurs="0"/&gt;
 *                                                             &lt;element name="Sbiklasse" maxOccurs="unbounded" minOccurs="0"&gt;
 *                                                               &lt;complexType&gt;
 *                                                                 &lt;complexContent&gt;
 *                                                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                                                     &lt;sequence&gt;
 *                                                                       &lt;element name="CdSbi" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdSbi" minOccurs="0"/&gt;
 *                                                                       &lt;element name="OmsSbi" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar300" minOccurs="0"/&gt;
 *                                                                       &lt;element name="IndSbiHoofdactiviteit" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdIndJN_nocodes" minOccurs="0"/&gt;
 *                                                                       &lt;element name="DatBSbiactiviteit" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                                                       &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
 *                                                                       &lt;element name="DatESbiactiviteit" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                                                       &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
 *                                                                     &lt;/sequence&gt;
 *                                                                   &lt;/restriction&gt;
 *                                                                 &lt;/complexContent&gt;
 *                                                               &lt;/complexType&gt;
 *                                                             &lt;/element&gt;
 *                                                           &lt;/sequence&gt;
 *                                                         &lt;/restriction&gt;
 *                                                       &lt;/complexContent&gt;
 *                                                     &lt;/complexType&gt;
 *                                                   &lt;/element&gt;
 *                                                   &lt;element name="Onderneming" maxOccurs="unbounded" minOccurs="0"&gt;
 *                                                     &lt;complexType&gt;
 *                                                       &lt;complexContent&gt;
 *                                                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                                           &lt;sequence&gt;
 *                                                             &lt;element name="KvkNr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdKvkNr" minOccurs="0"/&gt;
 *                                                             &lt;element name="DatBOnderneming" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                                             &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
 *                                                             &lt;element name="DatEOnderneming" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                                             &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
 *                                                             &lt;element name="Sbiklasse" maxOccurs="unbounded" minOccurs="0"&gt;
 *                                                               &lt;complexType&gt;
 *                                                                 &lt;complexContent&gt;
 *                                                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                                                     &lt;sequence&gt;
 *                                                                       &lt;element name="CdSbi" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdSbi" minOccurs="0"/&gt;
 *                                                                       &lt;element name="OmsSbi" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar300" minOccurs="0"/&gt;
 *                                                                       &lt;element name="IndSbiHoofdactiviteit" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdIndJN_nocodes" minOccurs="0"/&gt;
 *                                                                       &lt;element name="DatBSbiactiviteit" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                                                       &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
 *                                                                       &lt;element name="DatESbiactiviteit" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                                                       &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
 *                                                                     &lt;/sequence&gt;
 *                                                                   &lt;/restriction&gt;
 *                                                                 &lt;/complexContent&gt;
 *                                                               &lt;/complexType&gt;
 *                                                             &lt;/element&gt;
 *                                                             &lt;element name="Handelsnaam" maxOccurs="unbounded" minOccurs="0"&gt;
 *                                                               &lt;complexType&gt;
 *                                                                 &lt;complexContent&gt;
 *                                                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                                                     &lt;sequence&gt;
 *                                                                       &lt;element name="Handelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar625" minOccurs="0"/&gt;
 *                                                                       &lt;element name="VolgordeHandelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdAantNietNegatiefVar4" minOccurs="0"/&gt;
 *                                                                       &lt;element name="DatBHandelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                                                       &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
 *                                                                       &lt;element name="DatEHandelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                                                       &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
 *                                                                     &lt;/sequence&gt;
 *                                                                   &lt;/restriction&gt;
 *                                                                 &lt;/complexContent&gt;
 *                                                               &lt;/complexType&gt;
 *                                                             &lt;/element&gt;
 *                                                           &lt;/sequence&gt;
 *                                                         &lt;/restriction&gt;
 *                                                       &lt;/complexContent&gt;
 *                                                     &lt;/complexType&gt;
 *                                                   &lt;/element&gt;
 *                                                   &lt;element name="Handelsnaam" maxOccurs="unbounded" minOccurs="0"&gt;
 *                                                     &lt;complexType&gt;
 *                                                       &lt;complexContent&gt;
 *                                                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                                           &lt;sequence&gt;
 *                                                             &lt;element name="Handelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar625" minOccurs="0"/&gt;
 *                                                             &lt;element name="VolgordeHandelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdAantNietNegatiefVar4" minOccurs="0"/&gt;
 *                                                             &lt;element name="DatBHandelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                                             &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
 *                                                             &lt;element name="DatEHandelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                                             &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
 *                                                           &lt;/sequence&gt;
 *                                                         &lt;/restriction&gt;
 *                                                       &lt;/complexContent&gt;
 *                                                     &lt;/complexType&gt;
 *                                                   &lt;/element&gt;
 *                                                 &lt;/sequence&gt;
 *                                               &lt;/restriction&gt;
 *                                             &lt;/complexContent&gt;
 *                                           &lt;/complexType&gt;
 *                                         &lt;/element&gt;
 *                                       &lt;/sequence&gt;
 *                                     &lt;/restriction&gt;
 *                                   &lt;/complexContent&gt;
 *                                 &lt;/complexType&gt;
 *                               &lt;/element&gt;
 *                               &lt;element name="AdministratieveEenheid" maxOccurs="unbounded" minOccurs="0"&gt;
 *                                 &lt;complexType&gt;
 *                                   &lt;complexContent&gt;
 *                                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                       &lt;sequence&gt;
 *                                         &lt;element name="Loonheffingennr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLoonheffingennr" minOccurs="0"/&gt;
 *                                         &lt;element name="NaamAdminEenheid" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar200" minOccurs="0"/&gt;
 *                                         &lt;element name="DatBAdminEenheid" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                         &lt;element name="DatEAdminEenheid" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                         &lt;element name="SectorRisicogroep" maxOccurs="unbounded" minOccurs="0"&gt;
 *                                           &lt;complexType&gt;
 *                                             &lt;complexContent&gt;
 *                                               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                                 &lt;sequence&gt;
 *                                                   &lt;element name="CdRisicopremiegroep" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdCdRisicopremiegroep" minOccurs="0"/&gt;
 *                                                   &lt;element name="CdSectorOsv" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdCdSectorOsv" minOccurs="0"/&gt;
 *                                                   &lt;element name="DatB" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                                   &lt;element name="DatE" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                                 &lt;/sequence&gt;
 *                                               &lt;/restriction&gt;
 *                                             &lt;/complexContent&gt;
 *                                           &lt;/complexType&gt;
 *                                         &lt;/element&gt;
 *                                         &lt;element name="PremiepercIndividueel" maxOccurs="unbounded" minOccurs="0"&gt;
 *                                           &lt;complexType&gt;
 *                                             &lt;complexContent&gt;
 *                                               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                                 &lt;sequence&gt;
 *                                                   &lt;element name="Perc" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPercDec2" minOccurs="0"/&gt;
 *                                                   &lt;element name="CdSzProduct" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdSzProduct_nocodes" minOccurs="0"/&gt;
 *                                                   &lt;element name="DatBPrpercIndividueel" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                                   &lt;element name="DatEPrpercIndividueel" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                                 &lt;/sequence&gt;
 *                                               &lt;/restriction&gt;
 *                                             &lt;/complexContent&gt;
 *                                           &lt;/complexType&gt;
 *                                         &lt;/element&gt;
 *                                         &lt;element name="EigenRisicoDrager" maxOccurs="unbounded" minOccurs="0"&gt;
 *                                           &lt;complexType&gt;
 *                                             &lt;complexContent&gt;
 *                                               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                                 &lt;sequence&gt;
 *                                                   &lt;element name="CdSzProduct" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdSzProduct_nocodes" minOccurs="0"/&gt;
 *                                                   &lt;element name="DatBEigenrisicodrager" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                                   &lt;element name="DatEEigenrisicodrager" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                                 &lt;/sequence&gt;
 *                                               &lt;/restriction&gt;
 *                                             &lt;/complexContent&gt;
 *                                           &lt;/complexType&gt;
 *                                         &lt;/element&gt;
 *                                         &lt;element name="Adreshouding" maxOccurs="unbounded" minOccurs="0"&gt;
 *                                           &lt;complexType&gt;
 *                                             &lt;complexContent&gt;
 *                                               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                                 &lt;sequence&gt;
 *                                                   &lt;choice&gt;
 *                                                     &lt;element name="AdresNederlandWga"&gt;
 *                                                       &lt;complexType&gt;
 *                                                         &lt;complexContent&gt;
 *                                                           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                                             &lt;sequence&gt;
 *                                                               &lt;element name="CdAdresrol" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAdresrol_nocodes" minOccurs="0"/&gt;
 *                                                               &lt;element name="DatBAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                                               &lt;element name="DatEAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                                               &lt;choice minOccurs="0"&gt;
 *                                                                 &lt;element name="StraatadresWga" minOccurs="0"&gt;
 *                                                                   &lt;complexType&gt;
 *                                                                     &lt;complexContent&gt;
 *                                                                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                                                         &lt;sequence&gt;
 *                                                                           &lt;element name="Postcd" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcd" minOccurs="0"/&gt;
 *                                                                           &lt;element name="Woonplaatsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
 *                                                                           &lt;element name="Gemeentenaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdGemeentenaam" minOccurs="0"/&gt;
 *                                                                           &lt;element name="Straatnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdStraatnaam" minOccurs="0"/&gt;
 *                                                                           &lt;element name="Huisnr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisnr" minOccurs="0"/&gt;
 *                                                                           &lt;element name="Huisnrtoevoeging" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar4" minOccurs="0"/&gt;
 *                                                                           &lt;element name="Locatieoms" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar70" minOccurs="0"/&gt;
 *                                                                         &lt;/sequence&gt;
 *                                                                       &lt;/restriction&gt;
 *                                                                     &lt;/complexContent&gt;
 *                                                                   &lt;/complexType&gt;
 *                                                                 &lt;/element&gt;
 *                                                                 &lt;element name="PostbusadresWga" minOccurs="0"&gt;
 *                                                                   &lt;complexType&gt;
 *                                                                     &lt;complexContent&gt;
 *                                                                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                                                         &lt;sequence&gt;
 *                                                                           &lt;element name="Postcd" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcd" minOccurs="0"/&gt;
 *                                                                           &lt;element name="Woonplaatsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
 *                                                                           &lt;element name="Postbusnr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostbusnr" minOccurs="0"/&gt;
 *                                                                         &lt;/sequence&gt;
 *                                                                       &lt;/restriction&gt;
 *                                                                     &lt;/complexContent&gt;
 *                                                                   &lt;/complexType&gt;
 *                                                                 &lt;/element&gt;
 *                                                               &lt;/choice&gt;
 *                                                             &lt;/sequence&gt;
 *                                                           &lt;/restriction&gt;
 *                                                         &lt;/complexContent&gt;
 *                                                       &lt;/complexType&gt;
 *                                                     &lt;/element&gt;
 *                                                     &lt;element name="AdresBuitenlandWga"&gt;
 *                                                       &lt;complexType&gt;
 *                                                         &lt;complexContent&gt;
 *                                                           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                                             &lt;sequence&gt;
 *                                                               &lt;element name="CdAdresrol" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAdresrol_nocodes" minOccurs="0"/&gt;
 *                                                               &lt;element name="DatBAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                                               &lt;element name="DatEAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                                               &lt;choice minOccurs="0"&gt;
 *                                                                 &lt;element name="StraatadresBuitenlandWga" minOccurs="0"&gt;
 *                                                                   &lt;complexType&gt;
 *                                                                     &lt;complexContent&gt;
 *                                                                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                                                         &lt;sequence&gt;
 *                                                                           &lt;element name="PostcdBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcdBuitenland" minOccurs="0"/&gt;
 *                                                                           &lt;element name="WoonplaatsnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
 *                                                                           &lt;element name="RegionaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar24" minOccurs="0"/&gt;
 *                                                                           &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
 *                                                                           &lt;element name="StraatnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdStraatnaam" minOccurs="0"/&gt;
 *                                                                           &lt;element name="HuisnrBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisnrBuitenland" minOccurs="0"/&gt;
 *                                                                           &lt;element name="LocatieomsBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar128" minOccurs="0"/&gt;
 *                                                                         &lt;/sequence&gt;
 *                                                                       &lt;/restriction&gt;
 *                                                                     &lt;/complexContent&gt;
 *                                                                   &lt;/complexType&gt;
 *                                                                 &lt;/element&gt;
 *                                                                 &lt;element name="PostbusadresBuitenlandWga" minOccurs="0"&gt;
 *                                                                   &lt;complexType&gt;
 *                                                                     &lt;complexContent&gt;
 *                                                                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                                                         &lt;sequence&gt;
 *                                                                           &lt;element name="PostcdBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcdBuitenland" minOccurs="0"/&gt;
 *                                                                           &lt;element name="WoonplaatsnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
 *                                                                           &lt;element name="RegionaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar24" minOccurs="0"/&gt;
 *                                                                           &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
 *                                                                           &lt;element name="PostbusnrBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdReferentienrAnVar8" minOccurs="0"/&gt;
 *                                                                         &lt;/sequence&gt;
 *                                                                       &lt;/restriction&gt;
 *                                                                     &lt;/complexContent&gt;
 *                                                                   &lt;/complexType&gt;
 *                                                                 &lt;/element&gt;
 *                                                               &lt;/choice&gt;
 *                                                             &lt;/sequence&gt;
 *                                                           &lt;/restriction&gt;
 *                                                         &lt;/complexContent&gt;
 *                                                       &lt;/complexType&gt;
 *                                                     &lt;/element&gt;
 *                                                     &lt;element name="AdresBuitenlandOngestructureerdWga"&gt;
 *                                                       &lt;complexType&gt;
 *                                                         &lt;complexContent&gt;
 *                                                           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                                             &lt;sequence&gt;
 *                                                               &lt;element name="CdAdresrol" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAdresrol_nocodes" minOccurs="0"/&gt;
 *                                                               &lt;element name="DatBAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                                               &lt;element name="DatEAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                                               &lt;element name="Adresregel1Buitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar35" minOccurs="0"/&gt;
 *                                                               &lt;element name="Adresregel2Buitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar35" minOccurs="0"/&gt;
 *                                                               &lt;element name="Adresregel3Buitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar35" minOccurs="0"/&gt;
 *                                                               &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
 *                                                             &lt;/sequence&gt;
 *                                                           &lt;/restriction&gt;
 *                                                         &lt;/complexContent&gt;
 *                                                       &lt;/complexType&gt;
 *                                                     &lt;/element&gt;
 *                                                   &lt;/choice&gt;
 *                                                 &lt;/sequence&gt;
 *                                               &lt;/restriction&gt;
 *                                             &lt;/complexContent&gt;
 *                                           &lt;/complexType&gt;
 *                                         &lt;/element&gt;
 *                                         &lt;element name="VoortzettingsrelatieOpvolger" maxOccurs="unbounded" minOccurs="0"&gt;
 *                                           &lt;complexType&gt;
 *                                             &lt;complexContent&gt;
 *                                               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                                 &lt;sequence&gt;
 *                                                   &lt;element name="DatBVoortzettingsrelatie" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                                   &lt;element name="PercLoonsomOvergegaanInOpvolger" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPercNietNegatiefDec2" minOccurs="0"/&gt;
 *                                                   &lt;element name="LoonheffingennrOpvolger" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLoonheffingennr" minOccurs="0"/&gt;
 *                                                 &lt;/sequence&gt;
 *                                               &lt;/restriction&gt;
 *                                             &lt;/complexContent&gt;
 *                                           &lt;/complexType&gt;
 *                                         &lt;/element&gt;
 *                                         &lt;element name="VoortzettingsrelatieVoorganger" maxOccurs="unbounded" minOccurs="0"&gt;
 *                                           &lt;complexType&gt;
 *                                             &lt;complexContent&gt;
 *                                               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                                 &lt;sequence&gt;
 *                                                   &lt;element name="DatBVoortzettingsrelatie" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                                   &lt;element name="PercLoonsomOvergegaanInOpvolger" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPercNietNegatiefDec2" minOccurs="0"/&gt;
 *                                                   &lt;element name="Loonheffingennr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLoonheffingennr" minOccurs="0"/&gt;
 *                                                 &lt;/sequence&gt;
 *                                               &lt;/restriction&gt;
 *                                             &lt;/complexContent&gt;
 *                                           &lt;/complexType&gt;
 *                                         &lt;/element&gt;
 *                                         &lt;element name="AangifteFrequentieAdminEenheid" maxOccurs="unbounded" minOccurs="0"&gt;
 *                                           &lt;complexType&gt;
 *                                             &lt;complexContent&gt;
 *                                               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                                 &lt;sequence&gt;
 *                                                   &lt;element name="DatBAangiftefreqAdminEenheid" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                                   &lt;element name="CdAangiftefrequentieAdminEenheid" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAangiftefreqAdminEenheid_nocodes" minOccurs="0"/&gt;
 *                                                   &lt;element name="DatEAangiftefreqAdminEenheid" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                                 &lt;/sequence&gt;
 *                                               &lt;/restriction&gt;
 *                                             &lt;/complexContent&gt;
 *                                           &lt;/complexType&gt;
 *                                         &lt;/element&gt;
 *                                         &lt;element name="AansluitingsnrBv" maxOccurs="unbounded" minOccurs="0"&gt;
 *                                           &lt;complexType&gt;
 *                                             &lt;complexContent&gt;
 *                                               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                                                 &lt;sequence&gt;
 *                                                   &lt;element name="CdSectorOsv" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdCdSectorOsv" minOccurs="0"/&gt;
 *                                                   &lt;element name="CdRisicopremiegroep" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdCdRisicopremiegroep" minOccurs="0"/&gt;
 *                                                   &lt;element name="AansluitingsnrBV" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdAansluitingsnrBV" minOccurs="0"/&gt;
 *                                                   &lt;element name="DatBAansluitingsnrBv" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
 *                                                 &lt;/sequence&gt;
 *                                               &lt;/restriction&gt;
 *                                             &lt;/complexContent&gt;
 *                                           &lt;/complexType&gt;
 *                                         &lt;/element&gt;
 *                                       &lt;/sequence&gt;
 *                                     &lt;/restriction&gt;
 *                                   &lt;/complexContent&gt;
 *                                 &lt;/complexType&gt;
 *                               &lt;/element&gt;
 *                             &lt;/sequence&gt;
 *                           &lt;/restriction&gt;
 *                         &lt;/complexContent&gt;
 *                       &lt;/complexType&gt;
 *                     &lt;/element&gt;
 *                   &lt;/sequence&gt;
 *                 &lt;/restriction&gt;
 *               &lt;/complexContent&gt;
 *             &lt;/complexType&gt;
 *           &lt;/element&gt;
 *           &lt;element name="Applicatiemelding"&gt;
 *             &lt;complexType&gt;
 *               &lt;complexContent&gt;
 *                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                   &lt;sequence&gt;
 *                     &lt;element name="CdSrtApplicatiemelding" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdSrtApplicatiemelding_nocodes" minOccurs="0"/&gt;
 *                     &lt;element name="CdApplicatiemelding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdCdApplicatiemelding" minOccurs="0"/&gt;
 *                     &lt;element name="ToelApplicatiemelding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar256" minOccurs="0"/&gt;
 *                   &lt;/sequence&gt;
 *                 &lt;/restriction&gt;
 *               &lt;/complexContent&gt;
 *             &lt;/complexType&gt;
 *           &lt;/element&gt;
 *         &lt;/choice&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "gegevenslevering",
    "applicatiemelding"
})
@XmlRootElement(name = "CwsInhoudingsplichtigeResponse")
public class CwsInhoudingsplichtigeResponse {

    @XmlElement(name = "Gegevenslevering")
    @Valid
    protected CwsInhoudingsplichtigeResponse.Gegevenslevering gegevenslevering;
    @XmlElement(name = "Applicatiemelding")
    @Valid
    protected CwsInhoudingsplichtigeResponse.Applicatiemelding applicatiemelding;

    /**
     * Gets the value of the gegevenslevering property.
     * 
     * @return
     *     possible object is
     *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering }
     *     
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering getGegevenslevering() {
        return gegevenslevering;
    }

    /**
     * Sets the value of the gegevenslevering property.
     * 
     * @param value
     *     allowed object is
     *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering }
     *     
     */
    public void setGegevenslevering(CwsInhoudingsplichtigeResponse.Gegevenslevering value) {
        this.gegevenslevering = value;
    }

    /**
     * Gets the value of the applicatiemelding property.
     * 
     * @return
     *     possible object is
     *     {@link CwsInhoudingsplichtigeResponse.Applicatiemelding }
     *     
     */
    public CwsInhoudingsplichtigeResponse.Applicatiemelding getApplicatiemelding() {
        return applicatiemelding;
    }

    /**
     * Sets the value of the applicatiemelding property.
     * 
     * @param value
     *     allowed object is
     *     {@link CwsInhoudingsplichtigeResponse.Applicatiemelding }
     *     
     */
    public void setApplicatiemelding(CwsInhoudingsplichtigeResponse.Applicatiemelding value) {
        this.applicatiemelding = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="CdSrtApplicatiemelding" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdSrtApplicatiemelding_nocodes" minOccurs="0"/&gt;
     *         &lt;element name="CdApplicatiemelding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdCdApplicatiemelding" minOccurs="0"/&gt;
     *         &lt;element name="ToelApplicatiemelding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar256" minOccurs="0"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "cdSrtApplicatiemelding",
        "cdApplicatiemelding",
        "toelApplicatiemelding"
    })
    public static class Applicatiemelding {

        @XmlElement(name = "CdSrtApplicatiemelding")
        @Size(min = 1, max = 1)
        @Pattern(regexp = "[A-Z]*")
        protected String cdSrtApplicatiemelding;
        @XmlElement(name = "CdApplicatiemelding")
        @Size(max = 10)
        protected String cdApplicatiemelding;
        @XmlElement(name = "ToelApplicatiemelding")
        @Size(max = 256)
        protected String toelApplicatiemelding;

        /**
         * Gets the value of the cdSrtApplicatiemelding property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCdSrtApplicatiemelding() {
            return cdSrtApplicatiemelding;
        }

        /**
         * Sets the value of the cdSrtApplicatiemelding property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCdSrtApplicatiemelding(String value) {
            this.cdSrtApplicatiemelding = value;
        }

        /**
         * Gets the value of the cdApplicatiemelding property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCdApplicatiemelding() {
            return cdApplicatiemelding;
        }

        /**
         * Sets the value of the cdApplicatiemelding property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCdApplicatiemelding(String value) {
            this.cdApplicatiemelding = value;
        }

        /**
         * Gets the value of the toelApplicatiemelding property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getToelApplicatiemelding() {
            return toelApplicatiemelding;
        }

        /**
         * Sets the value of the toelApplicatiemelding property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setToelApplicatiemelding(String value) {
            this.toelApplicatiemelding = value;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="DatTijdBeschouwingGebVSelectie" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatTijd20" minOccurs="0"/&gt;
     *         &lt;element name="KvkNr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdKvkNr" minOccurs="0"/&gt;
     *         &lt;element name="NrInhoudingsplichtige" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdNrInhoudingsplichtige" minOccurs="0"/&gt;
     *         &lt;element name="Loonheffingennr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLoonheffingennr" minOccurs="0"/&gt;
     *         &lt;element name="PersoonInhoudingsplichtige" maxOccurs="unbounded" minOccurs="0"&gt;
     *           &lt;complexType&gt;
     *             &lt;complexContent&gt;
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                 &lt;sequence&gt;
     *                   &lt;choice minOccurs="0"&gt;
     *                     &lt;element name="NietNatuurlijkPersoon" minOccurs="0"&gt;
     *                       &lt;complexType&gt;
     *                         &lt;complexContent&gt;
     *                           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                             &lt;sequence&gt;
     *                               &lt;element name="DatOntbindingRechtspSamenwerking" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                               &lt;element name="DatOprichtingRechtspSamenwerking" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                               &lt;element name="Rsin" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdRsin" minOccurs="0"/&gt;
     *                               &lt;element name="DatBNietNatuurlijkPersoon" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                               &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
     *                               &lt;element name="DatENietNatuurlijkPersoon" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                               &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
     *                               &lt;element name="VolledigeNmNietNatuurlijkPersoon" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar500" minOccurs="0"/&gt;
     *                               &lt;element name="Rechtspersoon" minOccurs="0"&gt;
     *                                 &lt;complexType&gt;
     *                                   &lt;complexContent&gt;
     *                                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                       &lt;sequence&gt;
     *                                         &lt;element name="StatutaireZetel" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar60" minOccurs="0"/&gt;
     *                                         &lt;element name="DatBStatutaireZetel" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                                         &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
     *                                         &lt;element name="ActiviteitHandelsregister" minOccurs="0"&gt;
     *                                           &lt;complexType&gt;
     *                                             &lt;complexContent&gt;
     *                                               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                                 &lt;sequence&gt;
     *                                                   &lt;element name="OmsActiviteitHandelsregister" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdTekstAnVar2000" minOccurs="0"/&gt;
     *                                                 &lt;/sequence&gt;
     *                                               &lt;/restriction&gt;
     *                                             &lt;/complexContent&gt;
     *                                           &lt;/complexType&gt;
     *                                         &lt;/element&gt;
     *                                       &lt;/sequence&gt;
     *                                     &lt;/restriction&gt;
     *                                   &lt;/complexContent&gt;
     *                                 &lt;/complexType&gt;
     *                               &lt;/element&gt;
     *                               &lt;element name="VennootschapBuitenland" minOccurs="0"&gt;
     *                                 &lt;complexType&gt;
     *                                   &lt;complexContent&gt;
     *                                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                       &lt;sequence&gt;
     *                                         &lt;element name="DatBVennootschapBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                                         &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
     *                                         &lt;element name="DatEVennootschapBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                                         &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
     *                                       &lt;/sequence&gt;
     *                                     &lt;/restriction&gt;
     *                                   &lt;/complexContent&gt;
     *                                 &lt;/complexType&gt;
     *                               &lt;/element&gt;
     *                             &lt;/sequence&gt;
     *                           &lt;/restriction&gt;
     *                         &lt;/complexContent&gt;
     *                       &lt;/complexType&gt;
     *                     &lt;/element&gt;
     *                     &lt;element name="NatuurlijkPersoon" minOccurs="0"&gt;
     *                       &lt;complexType&gt;
     *                         &lt;complexContent&gt;
     *                           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                             &lt;sequence&gt;
     *                               &lt;element name="Burgerservicenr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdBurgerservicenr" minOccurs="0"/&gt;
     *                               &lt;element name="Voorletters" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdVoorletters" minOccurs="0"/&gt;
     *                               &lt;element name="Voornamen" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdVoornamen" minOccurs="0"/&gt;
     *                               &lt;element name="Voorvoegsel" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdVoorvoegsel" minOccurs="0"/&gt;
     *                               &lt;element name="SignificantDeelVanDeAchternaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdSignificantDeelAchtern" minOccurs="0"/&gt;
     *                               &lt;element name="CdAanduidingNaamgebruik" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAanduidingNaamgebruik_nocodes" minOccurs="0"/&gt;
     *                               &lt;element name="Geboortedat" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                               &lt;element name="CdFictieveGeboortedat" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
     *                               &lt;element name="Geslacht" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdGeslacht_nocodes" minOccurs="0"/&gt;
     *                               &lt;element name="HuwelijkGeregistreerdPartner" minOccurs="0"&gt;
     *                                 &lt;complexType&gt;
     *                                   &lt;complexContent&gt;
     *                                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                       &lt;sequence&gt;
     *                                         &lt;element name="VoorvoegselEchtgenoot" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdVoorvoegsel" minOccurs="0"/&gt;
     *                                         &lt;element name="SignificantDeelAchternaamEchtg" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdSignificantDeelAchtern" minOccurs="0"/&gt;
     *                                       &lt;/sequence&gt;
     *                                     &lt;/restriction&gt;
     *                                   &lt;/complexContent&gt;
     *                                 &lt;/complexType&gt;
     *                               &lt;/element&gt;
     *                             &lt;/sequence&gt;
     *                           &lt;/restriction&gt;
     *                         &lt;/complexContent&gt;
     *                       &lt;/complexType&gt;
     *                     &lt;/element&gt;
     *                     &lt;element name="PersoonHandelsregister" minOccurs="0"&gt;
     *                       &lt;complexType&gt;
     *                         &lt;complexContent&gt;
     *                           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                             &lt;sequence&gt;
     *                               &lt;element name="DatBPersoonHandelsregister" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                               &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
     *                               &lt;element name="DatEPersoonHandelsregister" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                               &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
     *                               &lt;element name="NaamPersoonHandelsregister" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar300" minOccurs="0"/&gt;
     *                               &lt;element name="VolledigeNmPersHandelsregister" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar500" minOccurs="0"/&gt;
     *                             &lt;/sequence&gt;
     *                           &lt;/restriction&gt;
     *                         &lt;/complexContent&gt;
     *                       &lt;/complexType&gt;
     *                     &lt;/element&gt;
     *                   &lt;/choice&gt;
     *                   &lt;element name="Rechtsvorm" maxOccurs="unbounded" minOccurs="0"&gt;
     *                     &lt;complexType&gt;
     *                       &lt;complexContent&gt;
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                           &lt;sequence&gt;
     *                             &lt;element name="CdRechtsvorm" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdCdRechtsvorm" minOccurs="0"/&gt;
     *                             &lt;element name="DatBRechtsvorm" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                             &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
     *                             &lt;element name="DatERechtsvorm" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                             &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
     *                           &lt;/sequence&gt;
     *                         &lt;/restriction&gt;
     *                       &lt;/complexContent&gt;
     *                     &lt;/complexType&gt;
     *                   &lt;/element&gt;
     *                   &lt;element name="FaillSurs" maxOccurs="unbounded" minOccurs="0"&gt;
     *                     &lt;complexType&gt;
     *                       &lt;complexContent&gt;
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                           &lt;sequence&gt;
     *                             &lt;element name="CdFaillSurs" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFaillissementSurseance_nocodes" minOccurs="0"/&gt;
     *                             &lt;element name="CdRedenEindeFaillSurs" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdRedenEindeFaillisSurseance_nocodes" minOccurs="0"/&gt;
     *                             &lt;element name="DatBFaillissementSurseance" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                             &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
     *                             &lt;element name="DatEFaillissementSurseance" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                             &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
     *                           &lt;/sequence&gt;
     *                         &lt;/restriction&gt;
     *                       &lt;/complexContent&gt;
     *                     &lt;/complexType&gt;
     *                   &lt;/element&gt;
     *                   &lt;element name="Gemoedsbezwaardheid" maxOccurs="unbounded" minOccurs="0"&gt;
     *                     &lt;complexType&gt;
     *                       &lt;complexContent&gt;
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                           &lt;sequence&gt;
     *                             &lt;element name="CdSzProduct" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdSzProduct_nocodes" minOccurs="0"/&gt;
     *                             &lt;element name="DatBGemoedsbezwaardheid" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                             &lt;element name="DatEGemoedsbezwaardheid" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                           &lt;/sequence&gt;
     *                         &lt;/restriction&gt;
     *                       &lt;/complexContent&gt;
     *                     &lt;/complexType&gt;
     *                   &lt;/element&gt;
     *                   &lt;element name="Adreshouding" maxOccurs="unbounded" minOccurs="0"&gt;
     *                     &lt;complexType&gt;
     *                       &lt;complexContent&gt;
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                           &lt;sequence&gt;
     *                             &lt;choice&gt;
     *                               &lt;element name="AdresNederlandUhr"&gt;
     *                                 &lt;complexType&gt;
     *                                   &lt;complexContent&gt;
     *                                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                       &lt;sequence&gt;
     *                                         &lt;element name="CdAdresrol" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAdresrol_nocodes" minOccurs="0"/&gt;
     *                                         &lt;element name="DatBAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                                         &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
     *                                         &lt;element name="DatEAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                                         &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
     *                                         &lt;element name="CdAfgeschermdAdres" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdOJNNvt_nocodes" minOccurs="0"/&gt;
     *                                         &lt;choice minOccurs="0"&gt;
     *                                           &lt;element name="StraatadresUhr" minOccurs="0"&gt;
     *                                             &lt;complexType&gt;
     *                                               &lt;complexContent&gt;
     *                                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                                   &lt;sequence&gt;
     *                                                     &lt;element name="Postcd" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcd" minOccurs="0"/&gt;
     *                                                     &lt;element name="Woonplaatsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
     *                                                     &lt;element name="Straatnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdStraatnaam" minOccurs="0"/&gt;
     *                                                     &lt;element name="Huisnr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisnr" minOccurs="0"/&gt;
     *                                                     &lt;element name="Huisletter" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisletter" minOccurs="0"/&gt;
     *                                                     &lt;element name="Huisnrtoevoeging" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar4" minOccurs="0"/&gt;
     *                                                     &lt;element name="CdAanduidingBijHuisnr" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAanduidingBijHuisnr_nocodes" minOccurs="0"/&gt;
     *                                                     &lt;element name="NaamOpenbareRuimte" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar80" minOccurs="0"/&gt;
     *                                                   &lt;/sequence&gt;
     *                                                 &lt;/restriction&gt;
     *                                               &lt;/complexContent&gt;
     *                                             &lt;/complexType&gt;
     *                                           &lt;/element&gt;
     *                                           &lt;element name="PostbusadresUhr" minOccurs="0"&gt;
     *                                             &lt;complexType&gt;
     *                                               &lt;complexContent&gt;
     *                                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                                   &lt;sequence&gt;
     *                                                     &lt;element name="Postcd" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcd" minOccurs="0"/&gt;
     *                                                     &lt;element name="Woonplaatsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
     *                                                     &lt;element name="Postbusnr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostbusnr" minOccurs="0"/&gt;
     *                                                   &lt;/sequence&gt;
     *                                                 &lt;/restriction&gt;
     *                                               &lt;/complexContent&gt;
     *                                             &lt;/complexType&gt;
     *                                           &lt;/element&gt;
     *                                         &lt;/choice&gt;
     *                                       &lt;/sequence&gt;
     *                                     &lt;/restriction&gt;
     *                                   &lt;/complexContent&gt;
     *                                 &lt;/complexType&gt;
     *                               &lt;/element&gt;
     *                               &lt;element name="AdresBuitenlandUhr"&gt;
     *                                 &lt;complexType&gt;
     *                                   &lt;complexContent&gt;
     *                                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                       &lt;sequence&gt;
     *                                         &lt;element name="CdAdresrol" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAdresrol_nocodes" minOccurs="0"/&gt;
     *                                         &lt;element name="DatBAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                                         &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
     *                                         &lt;element name="DatEAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                                         &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
     *                                         &lt;element name="CdAfgeschermdAdres" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdOJNNvt_nocodes" minOccurs="0"/&gt;
     *                                         &lt;choice minOccurs="0"&gt;
     *                                           &lt;element name="StraatadresBuitenlandUhr" minOccurs="0"&gt;
     *                                             &lt;complexType&gt;
     *                                               &lt;complexContent&gt;
     *                                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                                   &lt;sequence&gt;
     *                                                     &lt;element name="PostcdBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcdBuitenland" minOccurs="0"/&gt;
     *                                                     &lt;element name="WoonplaatsnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
     *                                                     &lt;element name="RegionaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar24" minOccurs="0"/&gt;
     *                                                     &lt;element name="LandcodeGba" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeGba" minOccurs="0"/&gt;
     *                                                     &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
     *                                                     &lt;element name="Landsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandsnaam" minOccurs="0"/&gt;
     *                                                     &lt;element name="StraatnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdStraatnaam" minOccurs="0"/&gt;
     *                                                     &lt;element name="HuisnrBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisnrBuitenland" minOccurs="0"/&gt;
     *                                                     &lt;element name="LocatieomsBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar128" minOccurs="0"/&gt;
     *                                                   &lt;/sequence&gt;
     *                                                 &lt;/restriction&gt;
     *                                               &lt;/complexContent&gt;
     *                                             &lt;/complexType&gt;
     *                                           &lt;/element&gt;
     *                                           &lt;element name="PostbusadresBuitenlandUhr" minOccurs="0"&gt;
     *                                             &lt;complexType&gt;
     *                                               &lt;complexContent&gt;
     *                                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                                   &lt;sequence&gt;
     *                                                     &lt;element name="PostcdBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcdBuitenland" minOccurs="0"/&gt;
     *                                                     &lt;element name="WoonplaatsnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
     *                                                     &lt;element name="RegionaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar24" minOccurs="0"/&gt;
     *                                                     &lt;element name="LandcodeGba" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeGba" minOccurs="0"/&gt;
     *                                                     &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
     *                                                     &lt;element name="Landsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandsnaam" minOccurs="0"/&gt;
     *                                                     &lt;element name="PostbusnrBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdReferentienrAnVar8" minOccurs="0"/&gt;
     *                                                   &lt;/sequence&gt;
     *                                                 &lt;/restriction&gt;
     *                                               &lt;/complexContent&gt;
     *                                             &lt;/complexType&gt;
     *                                           &lt;/element&gt;
     *                                         &lt;/choice&gt;
     *                                       &lt;/sequence&gt;
     *                                     &lt;/restriction&gt;
     *                                   &lt;/complexContent&gt;
     *                                 &lt;/complexType&gt;
     *                               &lt;/element&gt;
     *                               &lt;element name="AdresBuitenlandOngestructureerdUhr"&gt;
     *                                 &lt;complexType&gt;
     *                                   &lt;complexContent&gt;
     *                                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                       &lt;sequence&gt;
     *                                         &lt;element name="CdAdresrol" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAdresrol_nocodes" minOccurs="0"/&gt;
     *                                         &lt;element name="DatBAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                                         &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
     *                                         &lt;element name="DatEAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                                         &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
     *                                         &lt;element name="CdAfgeschermdAdres" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdOJNNvt_nocodes" minOccurs="0"/&gt;
     *                                         &lt;element name="Adresregel1Buitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar35" minOccurs="0"/&gt;
     *                                         &lt;element name="Adresregel2Buitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar35" minOccurs="0"/&gt;
     *                                         &lt;element name="Adresregel3Buitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar35" minOccurs="0"/&gt;
     *                                         &lt;element name="LandcodeGba" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeGba" minOccurs="0"/&gt;
     *                                         &lt;element name="LandsnaamGba" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar40" minOccurs="0"/&gt;
     *                                         &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
     *                                         &lt;element name="Landsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandsnaam" minOccurs="0"/&gt;
     *                                       &lt;/sequence&gt;
     *                                     &lt;/restriction&gt;
     *                                   &lt;/complexContent&gt;
     *                                 &lt;/complexType&gt;
     *                               &lt;/element&gt;
     *                             &lt;/choice&gt;
     *                           &lt;/sequence&gt;
     *                         &lt;/restriction&gt;
     *                       &lt;/complexContent&gt;
     *                     &lt;/complexType&gt;
     *                   &lt;/element&gt;
     *                   &lt;element name="MaatschappelijkeActiviteit" maxOccurs="unbounded" minOccurs="0"&gt;
     *                     &lt;complexType&gt;
     *                       &lt;complexContent&gt;
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                           &lt;sequence&gt;
     *                             &lt;element name="KvkNr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdKvkNr" minOccurs="0"/&gt;
     *                             &lt;element name="DatBMaatschappelijkeActiviteit" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                             &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
     *                             &lt;element name="DatEMaatschappelijkeActiviteit" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                             &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
     *                             &lt;element name="Sbiklasse" maxOccurs="unbounded" minOccurs="0"&gt;
     *                               &lt;complexType&gt;
     *                                 &lt;complexContent&gt;
     *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                     &lt;sequence&gt;
     *                                       &lt;element name="CdSbi" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdSbi" minOccurs="0"/&gt;
     *                                       &lt;element name="OmsSbi" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar300" minOccurs="0"/&gt;
     *                                       &lt;element name="IndSbiHoofdactiviteit" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdIndJN_nocodes" minOccurs="0"/&gt;
     *                                       &lt;element name="DatBSbiactiviteit" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                                       &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
     *                                       &lt;element name="DatESbiactiviteit" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                                       &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
     *                                     &lt;/sequence&gt;
     *                                   &lt;/restriction&gt;
     *                                 &lt;/complexContent&gt;
     *                               &lt;/complexType&gt;
     *                             &lt;/element&gt;
     *                             &lt;element name="VestigingHandelsregister" maxOccurs="unbounded" minOccurs="0"&gt;
     *                               &lt;complexType&gt;
     *                                 &lt;complexContent&gt;
     *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                     &lt;sequence&gt;
     *                                       &lt;element name="VestigingsnrHandelsregister" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdVestigingsnrHandelsregister" minOccurs="0"/&gt;
     *                                       &lt;element name="EersteHandelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar200" minOccurs="0"/&gt;
     *                                       &lt;element name="DatBVestigingHandelsregister" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                                       &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
     *                                       &lt;element name="DatEVestigingHandelsregister" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                                       &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
     *                                       &lt;element name="Adreshouding" maxOccurs="unbounded" minOccurs="0"&gt;
     *                                         &lt;complexType&gt;
     *                                           &lt;complexContent&gt;
     *                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                               &lt;sequence&gt;
     *                                                 &lt;choice&gt;
     *                                                   &lt;element name="AdresNederlandUhr"&gt;
     *                                                     &lt;complexType&gt;
     *                                                       &lt;complexContent&gt;
     *                                                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                                           &lt;sequence&gt;
     *                                                             &lt;element name="CdAdresrol" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAdresrol_nocodes" minOccurs="0"/&gt;
     *                                                             &lt;element name="DatBAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                                                             &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
     *                                                             &lt;element name="DatEAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                                                             &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
     *                                                             &lt;element name="CdAfgeschermdAdres" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdOJNNvt_nocodes" minOccurs="0"/&gt;
     *                                                             &lt;choice minOccurs="0"&gt;
     *                                                               &lt;element name="StraatadresUhr" minOccurs="0"&gt;
     *                                                                 &lt;complexType&gt;
     *                                                                   &lt;complexContent&gt;
     *                                                                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                                                       &lt;sequence&gt;
     *                                                                         &lt;element name="Postcd" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcd" minOccurs="0"/&gt;
     *                                                                         &lt;element name="Woonplaatsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
     *                                                                         &lt;element name="Straatnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdStraatnaam" minOccurs="0"/&gt;
     *                                                                         &lt;element name="Huisnr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisnr" minOccurs="0"/&gt;
     *                                                                         &lt;element name="Huisletter" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisletter" minOccurs="0"/&gt;
     *                                                                         &lt;element name="Huisnrtoevoeging" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar4" minOccurs="0"/&gt;
     *                                                                         &lt;element name="CdAanduidingBijHuisnr" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAanduidingBijHuisnr_nocodes" minOccurs="0"/&gt;
     *                                                                         &lt;element name="NaamOpenbareRuimte" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar80" minOccurs="0"/&gt;
     *                                                                       &lt;/sequence&gt;
     *                                                                     &lt;/restriction&gt;
     *                                                                   &lt;/complexContent&gt;
     *                                                                 &lt;/complexType&gt;
     *                                                               &lt;/element&gt;
     *                                                               &lt;element name="PostbusadresUhr" minOccurs="0"&gt;
     *                                                                 &lt;complexType&gt;
     *                                                                   &lt;complexContent&gt;
     *                                                                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                                                       &lt;sequence&gt;
     *                                                                         &lt;element name="Postcd" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcd" minOccurs="0"/&gt;
     *                                                                         &lt;element name="Woonplaatsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
     *                                                                         &lt;element name="Postbusnr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostbusnr" minOccurs="0"/&gt;
     *                                                                       &lt;/sequence&gt;
     *                                                                     &lt;/restriction&gt;
     *                                                                   &lt;/complexContent&gt;
     *                                                                 &lt;/complexType&gt;
     *                                                               &lt;/element&gt;
     *                                                             &lt;/choice&gt;
     *                                                           &lt;/sequence&gt;
     *                                                         &lt;/restriction&gt;
     *                                                       &lt;/complexContent&gt;
     *                                                     &lt;/complexType&gt;
     *                                                   &lt;/element&gt;
     *                                                   &lt;element name="AdresBuitenlandUhr"&gt;
     *                                                     &lt;complexType&gt;
     *                                                       &lt;complexContent&gt;
     *                                                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                                           &lt;sequence&gt;
     *                                                             &lt;element name="CdAdresrol" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAdresrol_nocodes" minOccurs="0"/&gt;
     *                                                             &lt;element name="DatBAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                                                             &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
     *                                                             &lt;element name="DatEAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                                                             &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
     *                                                             &lt;element name="CdAfgeschermdAdres" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdOJNNvt_nocodes" minOccurs="0"/&gt;
     *                                                             &lt;choice minOccurs="0"&gt;
     *                                                               &lt;element name="StraatadresBuitenlandUhr" minOccurs="0"&gt;
     *                                                                 &lt;complexType&gt;
     *                                                                   &lt;complexContent&gt;
     *                                                                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                                                       &lt;sequence&gt;
     *                                                                         &lt;element name="PostcdBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcdBuitenland" minOccurs="0"/&gt;
     *                                                                         &lt;element name="WoonplaatsnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
     *                                                                         &lt;element name="RegionaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar24" minOccurs="0"/&gt;
     *                                                                         &lt;element name="LandcodeGba" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeGba" minOccurs="0"/&gt;
     *                                                                         &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
     *                                                                         &lt;element name="Landsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandsnaam" minOccurs="0"/&gt;
     *                                                                         &lt;element name="StraatnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdStraatnaam" minOccurs="0"/&gt;
     *                                                                         &lt;element name="HuisnrBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisnrBuitenland" minOccurs="0"/&gt;
     *                                                                         &lt;element name="LocatieomsBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar128" minOccurs="0"/&gt;
     *                                                                       &lt;/sequence&gt;
     *                                                                     &lt;/restriction&gt;
     *                                                                   &lt;/complexContent&gt;
     *                                                                 &lt;/complexType&gt;
     *                                                               &lt;/element&gt;
     *                                                               &lt;element name="PostbusadresBuitenlandUhr" minOccurs="0"&gt;
     *                                                                 &lt;complexType&gt;
     *                                                                   &lt;complexContent&gt;
     *                                                                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                                                       &lt;sequence&gt;
     *                                                                         &lt;element name="PostcdBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcdBuitenland" minOccurs="0"/&gt;
     *                                                                         &lt;element name="WoonplaatsnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
     *                                                                         &lt;element name="RegionaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar24" minOccurs="0"/&gt;
     *                                                                         &lt;element name="LandcodeGba" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeGba" minOccurs="0"/&gt;
     *                                                                         &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
     *                                                                         &lt;element name="Landsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandsnaam" minOccurs="0"/&gt;
     *                                                                         &lt;element name="PostbusnrBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdReferentienrAnVar8" minOccurs="0"/&gt;
     *                                                                       &lt;/sequence&gt;
     *                                                                     &lt;/restriction&gt;
     *                                                                   &lt;/complexContent&gt;
     *                                                                 &lt;/complexType&gt;
     *                                                               &lt;/element&gt;
     *                                                             &lt;/choice&gt;
     *                                                           &lt;/sequence&gt;
     *                                                         &lt;/restriction&gt;
     *                                                       &lt;/complexContent&gt;
     *                                                     &lt;/complexType&gt;
     *                                                   &lt;/element&gt;
     *                                                   &lt;element name="AdresBuitenlandOngestructureerdUhr"&gt;
     *                                                     &lt;complexType&gt;
     *                                                       &lt;complexContent&gt;
     *                                                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                                           &lt;sequence&gt;
     *                                                             &lt;element name="CdAdresrol" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAdresrol_nocodes" minOccurs="0"/&gt;
     *                                                             &lt;element name="DatBAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                                                             &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
     *                                                             &lt;element name="DatEAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                                                             &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
     *                                                             &lt;element name="CdAfgeschermdAdres" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdOJNNvt_nocodes" minOccurs="0"/&gt;
     *                                                             &lt;element name="Adresregel1Buitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar35" minOccurs="0"/&gt;
     *                                                             &lt;element name="Adresregel2Buitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar35" minOccurs="0"/&gt;
     *                                                             &lt;element name="Adresregel3Buitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar35" minOccurs="0"/&gt;
     *                                                             &lt;element name="LandcodeGba" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeGba" minOccurs="0"/&gt;
     *                                                             &lt;element name="LandsnaamGba" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar40" minOccurs="0"/&gt;
     *                                                             &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
     *                                                             &lt;element name="Landsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandsnaam" minOccurs="0"/&gt;
     *                                                           &lt;/sequence&gt;
     *                                                         &lt;/restriction&gt;
     *                                                       &lt;/complexContent&gt;
     *                                                     &lt;/complexType&gt;
     *                                                   &lt;/element&gt;
     *                                                 &lt;/choice&gt;
     *                                               &lt;/sequence&gt;
     *                                             &lt;/restriction&gt;
     *                                           &lt;/complexContent&gt;
     *                                         &lt;/complexType&gt;
     *                                       &lt;/element&gt;
     *                                       &lt;element name="ActiviteitHandelsregister" minOccurs="0"&gt;
     *                                         &lt;complexType&gt;
     *                                           &lt;complexContent&gt;
     *                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                               &lt;sequence&gt;
     *                                                 &lt;element name="OmsActiviteitHandelsregister" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdTekstAnVar2000" minOccurs="0"/&gt;
     *                                                 &lt;element name="Sbiklasse" maxOccurs="unbounded" minOccurs="0"&gt;
     *                                                   &lt;complexType&gt;
     *                                                     &lt;complexContent&gt;
     *                                                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                                         &lt;sequence&gt;
     *                                                           &lt;element name="CdSbi" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdSbi" minOccurs="0"/&gt;
     *                                                           &lt;element name="OmsSbi" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar300" minOccurs="0"/&gt;
     *                                                           &lt;element name="IndSbiHoofdactiviteit" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdIndJN_nocodes" minOccurs="0"/&gt;
     *                                                           &lt;element name="DatBSbiactiviteit" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                                                           &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
     *                                                           &lt;element name="DatESbiactiviteit" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                                                           &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
     *                                                         &lt;/sequence&gt;
     *                                                       &lt;/restriction&gt;
     *                                                     &lt;/complexContent&gt;
     *                                                   &lt;/complexType&gt;
     *                                                 &lt;/element&gt;
     *                                               &lt;/sequence&gt;
     *                                             &lt;/restriction&gt;
     *                                           &lt;/complexContent&gt;
     *                                         &lt;/complexType&gt;
     *                                       &lt;/element&gt;
     *                                       &lt;element name="Onderneming" maxOccurs="unbounded" minOccurs="0"&gt;
     *                                         &lt;complexType&gt;
     *                                           &lt;complexContent&gt;
     *                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                               &lt;sequence&gt;
     *                                                 &lt;element name="KvkNr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdKvkNr" minOccurs="0"/&gt;
     *                                                 &lt;element name="DatBOnderneming" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                                                 &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
     *                                                 &lt;element name="DatEOnderneming" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                                                 &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
     *                                                 &lt;element name="Sbiklasse" maxOccurs="unbounded" minOccurs="0"&gt;
     *                                                   &lt;complexType&gt;
     *                                                     &lt;complexContent&gt;
     *                                                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                                         &lt;sequence&gt;
     *                                                           &lt;element name="CdSbi" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdSbi" minOccurs="0"/&gt;
     *                                                           &lt;element name="OmsSbi" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar300" minOccurs="0"/&gt;
     *                                                           &lt;element name="IndSbiHoofdactiviteit" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdIndJN_nocodes" minOccurs="0"/&gt;
     *                                                           &lt;element name="DatBSbiactiviteit" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                                                           &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
     *                                                           &lt;element name="DatESbiactiviteit" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                                                           &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
     *                                                         &lt;/sequence&gt;
     *                                                       &lt;/restriction&gt;
     *                                                     &lt;/complexContent&gt;
     *                                                   &lt;/complexType&gt;
     *                                                 &lt;/element&gt;
     *                                                 &lt;element name="Handelsnaam" maxOccurs="unbounded" minOccurs="0"&gt;
     *                                                   &lt;complexType&gt;
     *                                                     &lt;complexContent&gt;
     *                                                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                                         &lt;sequence&gt;
     *                                                           &lt;element name="Handelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar625" minOccurs="0"/&gt;
     *                                                           &lt;element name="VolgordeHandelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdAantNietNegatiefVar4" minOccurs="0"/&gt;
     *                                                           &lt;element name="DatBHandelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                                                           &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
     *                                                           &lt;element name="DatEHandelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                                                           &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
     *                                                         &lt;/sequence&gt;
     *                                                       &lt;/restriction&gt;
     *                                                     &lt;/complexContent&gt;
     *                                                   &lt;/complexType&gt;
     *                                                 &lt;/element&gt;
     *                                               &lt;/sequence&gt;
     *                                             &lt;/restriction&gt;
     *                                           &lt;/complexContent&gt;
     *                                         &lt;/complexType&gt;
     *                                       &lt;/element&gt;
     *                                       &lt;element name="Handelsnaam" maxOccurs="unbounded" minOccurs="0"&gt;
     *                                         &lt;complexType&gt;
     *                                           &lt;complexContent&gt;
     *                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                               &lt;sequence&gt;
     *                                                 &lt;element name="Handelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar625" minOccurs="0"/&gt;
     *                                                 &lt;element name="VolgordeHandelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdAantNietNegatiefVar4" minOccurs="0"/&gt;
     *                                                 &lt;element name="DatBHandelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                                                 &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
     *                                                 &lt;element name="DatEHandelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                                                 &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
     *                                               &lt;/sequence&gt;
     *                                             &lt;/restriction&gt;
     *                                           &lt;/complexContent&gt;
     *                                         &lt;/complexType&gt;
     *                                       &lt;/element&gt;
     *                                     &lt;/sequence&gt;
     *                                   &lt;/restriction&gt;
     *                                 &lt;/complexContent&gt;
     *                               &lt;/complexType&gt;
     *                             &lt;/element&gt;
     *                           &lt;/sequence&gt;
     *                         &lt;/restriction&gt;
     *                       &lt;/complexContent&gt;
     *                     &lt;/complexType&gt;
     *                   &lt;/element&gt;
     *                   &lt;element name="AdministratieveEenheid" maxOccurs="unbounded" minOccurs="0"&gt;
     *                     &lt;complexType&gt;
     *                       &lt;complexContent&gt;
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                           &lt;sequence&gt;
     *                             &lt;element name="Loonheffingennr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLoonheffingennr" minOccurs="0"/&gt;
     *                             &lt;element name="NaamAdminEenheid" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar200" minOccurs="0"/&gt;
     *                             &lt;element name="DatBAdminEenheid" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                             &lt;element name="DatEAdminEenheid" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                             &lt;element name="SectorRisicogroep" maxOccurs="unbounded" minOccurs="0"&gt;
     *                               &lt;complexType&gt;
     *                                 &lt;complexContent&gt;
     *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                     &lt;sequence&gt;
     *                                       &lt;element name="CdRisicopremiegroep" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdCdRisicopremiegroep" minOccurs="0"/&gt;
     *                                       &lt;element name="CdSectorOsv" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdCdSectorOsv" minOccurs="0"/&gt;
     *                                       &lt;element name="DatB" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                                       &lt;element name="DatE" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                                     &lt;/sequence&gt;
     *                                   &lt;/restriction&gt;
     *                                 &lt;/complexContent&gt;
     *                               &lt;/complexType&gt;
     *                             &lt;/element&gt;
     *                             &lt;element name="PremiepercIndividueel" maxOccurs="unbounded" minOccurs="0"&gt;
     *                               &lt;complexType&gt;
     *                                 &lt;complexContent&gt;
     *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                     &lt;sequence&gt;
     *                                       &lt;element name="Perc" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPercDec2" minOccurs="0"/&gt;
     *                                       &lt;element name="CdSzProduct" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdSzProduct_nocodes" minOccurs="0"/&gt;
     *                                       &lt;element name="DatBPrpercIndividueel" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                                       &lt;element name="DatEPrpercIndividueel" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                                     &lt;/sequence&gt;
     *                                   &lt;/restriction&gt;
     *                                 &lt;/complexContent&gt;
     *                               &lt;/complexType&gt;
     *                             &lt;/element&gt;
     *                             &lt;element name="EigenRisicoDrager" maxOccurs="unbounded" minOccurs="0"&gt;
     *                               &lt;complexType&gt;
     *                                 &lt;complexContent&gt;
     *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                     &lt;sequence&gt;
     *                                       &lt;element name="CdSzProduct" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdSzProduct_nocodes" minOccurs="0"/&gt;
     *                                       &lt;element name="DatBEigenrisicodrager" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                                       &lt;element name="DatEEigenrisicodrager" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                                     &lt;/sequence&gt;
     *                                   &lt;/restriction&gt;
     *                                 &lt;/complexContent&gt;
     *                               &lt;/complexType&gt;
     *                             &lt;/element&gt;
     *                             &lt;element name="Adreshouding" maxOccurs="unbounded" minOccurs="0"&gt;
     *                               &lt;complexType&gt;
     *                                 &lt;complexContent&gt;
     *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                     &lt;sequence&gt;
     *                                       &lt;choice&gt;
     *                                         &lt;element name="AdresNederlandWga"&gt;
     *                                           &lt;complexType&gt;
     *                                             &lt;complexContent&gt;
     *                                               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                                 &lt;sequence&gt;
     *                                                   &lt;element name="CdAdresrol" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAdresrol_nocodes" minOccurs="0"/&gt;
     *                                                   &lt;element name="DatBAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                                                   &lt;element name="DatEAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                                                   &lt;choice minOccurs="0"&gt;
     *                                                     &lt;element name="StraatadresWga" minOccurs="0"&gt;
     *                                                       &lt;complexType&gt;
     *                                                         &lt;complexContent&gt;
     *                                                           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                                             &lt;sequence&gt;
     *                                                               &lt;element name="Postcd" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcd" minOccurs="0"/&gt;
     *                                                               &lt;element name="Woonplaatsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
     *                                                               &lt;element name="Gemeentenaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdGemeentenaam" minOccurs="0"/&gt;
     *                                                               &lt;element name="Straatnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdStraatnaam" minOccurs="0"/&gt;
     *                                                               &lt;element name="Huisnr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisnr" minOccurs="0"/&gt;
     *                                                               &lt;element name="Huisnrtoevoeging" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar4" minOccurs="0"/&gt;
     *                                                               &lt;element name="Locatieoms" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar70" minOccurs="0"/&gt;
     *                                                             &lt;/sequence&gt;
     *                                                           &lt;/restriction&gt;
     *                                                         &lt;/complexContent&gt;
     *                                                       &lt;/complexType&gt;
     *                                                     &lt;/element&gt;
     *                                                     &lt;element name="PostbusadresWga" minOccurs="0"&gt;
     *                                                       &lt;complexType&gt;
     *                                                         &lt;complexContent&gt;
     *                                                           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                                             &lt;sequence&gt;
     *                                                               &lt;element name="Postcd" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcd" minOccurs="0"/&gt;
     *                                                               &lt;element name="Woonplaatsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
     *                                                               &lt;element name="Postbusnr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostbusnr" minOccurs="0"/&gt;
     *                                                             &lt;/sequence&gt;
     *                                                           &lt;/restriction&gt;
     *                                                         &lt;/complexContent&gt;
     *                                                       &lt;/complexType&gt;
     *                                                     &lt;/element&gt;
     *                                                   &lt;/choice&gt;
     *                                                 &lt;/sequence&gt;
     *                                               &lt;/restriction&gt;
     *                                             &lt;/complexContent&gt;
     *                                           &lt;/complexType&gt;
     *                                         &lt;/element&gt;
     *                                         &lt;element name="AdresBuitenlandWga"&gt;
     *                                           &lt;complexType&gt;
     *                                             &lt;complexContent&gt;
     *                                               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                                 &lt;sequence&gt;
     *                                                   &lt;element name="CdAdresrol" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAdresrol_nocodes" minOccurs="0"/&gt;
     *                                                   &lt;element name="DatBAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                                                   &lt;element name="DatEAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                                                   &lt;choice minOccurs="0"&gt;
     *                                                     &lt;element name="StraatadresBuitenlandWga" minOccurs="0"&gt;
     *                                                       &lt;complexType&gt;
     *                                                         &lt;complexContent&gt;
     *                                                           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                                             &lt;sequence&gt;
     *                                                               &lt;element name="PostcdBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcdBuitenland" minOccurs="0"/&gt;
     *                                                               &lt;element name="WoonplaatsnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
     *                                                               &lt;element name="RegionaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar24" minOccurs="0"/&gt;
     *                                                               &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
     *                                                               &lt;element name="StraatnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdStraatnaam" minOccurs="0"/&gt;
     *                                                               &lt;element name="HuisnrBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisnrBuitenland" minOccurs="0"/&gt;
     *                                                               &lt;element name="LocatieomsBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar128" minOccurs="0"/&gt;
     *                                                             &lt;/sequence&gt;
     *                                                           &lt;/restriction&gt;
     *                                                         &lt;/complexContent&gt;
     *                                                       &lt;/complexType&gt;
     *                                                     &lt;/element&gt;
     *                                                     &lt;element name="PostbusadresBuitenlandWga" minOccurs="0"&gt;
     *                                                       &lt;complexType&gt;
     *                                                         &lt;complexContent&gt;
     *                                                           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                                             &lt;sequence&gt;
     *                                                               &lt;element name="PostcdBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcdBuitenland" minOccurs="0"/&gt;
     *                                                               &lt;element name="WoonplaatsnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
     *                                                               &lt;element name="RegionaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar24" minOccurs="0"/&gt;
     *                                                               &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
     *                                                               &lt;element name="PostbusnrBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdReferentienrAnVar8" minOccurs="0"/&gt;
     *                                                             &lt;/sequence&gt;
     *                                                           &lt;/restriction&gt;
     *                                                         &lt;/complexContent&gt;
     *                                                       &lt;/complexType&gt;
     *                                                     &lt;/element&gt;
     *                                                   &lt;/choice&gt;
     *                                                 &lt;/sequence&gt;
     *                                               &lt;/restriction&gt;
     *                                             &lt;/complexContent&gt;
     *                                           &lt;/complexType&gt;
     *                                         &lt;/element&gt;
     *                                         &lt;element name="AdresBuitenlandOngestructureerdWga"&gt;
     *                                           &lt;complexType&gt;
     *                                             &lt;complexContent&gt;
     *                                               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                                 &lt;sequence&gt;
     *                                                   &lt;element name="CdAdresrol" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAdresrol_nocodes" minOccurs="0"/&gt;
     *                                                   &lt;element name="DatBAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                                                   &lt;element name="DatEAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                                                   &lt;element name="Adresregel1Buitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar35" minOccurs="0"/&gt;
     *                                                   &lt;element name="Adresregel2Buitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar35" minOccurs="0"/&gt;
     *                                                   &lt;element name="Adresregel3Buitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar35" minOccurs="0"/&gt;
     *                                                   &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
     *                                                 &lt;/sequence&gt;
     *                                               &lt;/restriction&gt;
     *                                             &lt;/complexContent&gt;
     *                                           &lt;/complexType&gt;
     *                                         &lt;/element&gt;
     *                                       &lt;/choice&gt;
     *                                     &lt;/sequence&gt;
     *                                   &lt;/restriction&gt;
     *                                 &lt;/complexContent&gt;
     *                               &lt;/complexType&gt;
     *                             &lt;/element&gt;
     *                             &lt;element name="VoortzettingsrelatieOpvolger" maxOccurs="unbounded" minOccurs="0"&gt;
     *                               &lt;complexType&gt;
     *                                 &lt;complexContent&gt;
     *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                     &lt;sequence&gt;
     *                                       &lt;element name="DatBVoortzettingsrelatie" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                                       &lt;element name="PercLoonsomOvergegaanInOpvolger" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPercNietNegatiefDec2" minOccurs="0"/&gt;
     *                                       &lt;element name="LoonheffingennrOpvolger" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLoonheffingennr" minOccurs="0"/&gt;
     *                                     &lt;/sequence&gt;
     *                                   &lt;/restriction&gt;
     *                                 &lt;/complexContent&gt;
     *                               &lt;/complexType&gt;
     *                             &lt;/element&gt;
     *                             &lt;element name="VoortzettingsrelatieVoorganger" maxOccurs="unbounded" minOccurs="0"&gt;
     *                               &lt;complexType&gt;
     *                                 &lt;complexContent&gt;
     *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                     &lt;sequence&gt;
     *                                       &lt;element name="DatBVoortzettingsrelatie" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                                       &lt;element name="PercLoonsomOvergegaanInOpvolger" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPercNietNegatiefDec2" minOccurs="0"/&gt;
     *                                       &lt;element name="Loonheffingennr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLoonheffingennr" minOccurs="0"/&gt;
     *                                     &lt;/sequence&gt;
     *                                   &lt;/restriction&gt;
     *                                 &lt;/complexContent&gt;
     *                               &lt;/complexType&gt;
     *                             &lt;/element&gt;
     *                             &lt;element name="AangifteFrequentieAdminEenheid" maxOccurs="unbounded" minOccurs="0"&gt;
     *                               &lt;complexType&gt;
     *                                 &lt;complexContent&gt;
     *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                     &lt;sequence&gt;
     *                                       &lt;element name="DatBAangiftefreqAdminEenheid" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                                       &lt;element name="CdAangiftefrequentieAdminEenheid" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAangiftefreqAdminEenheid_nocodes" minOccurs="0"/&gt;
     *                                       &lt;element name="DatEAangiftefreqAdminEenheid" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                                     &lt;/sequence&gt;
     *                                   &lt;/restriction&gt;
     *                                 &lt;/complexContent&gt;
     *                               &lt;/complexType&gt;
     *                             &lt;/element&gt;
     *                             &lt;element name="AansluitingsnrBv" maxOccurs="unbounded" minOccurs="0"&gt;
     *                               &lt;complexType&gt;
     *                                 &lt;complexContent&gt;
     *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                                     &lt;sequence&gt;
     *                                       &lt;element name="CdSectorOsv" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdCdSectorOsv" minOccurs="0"/&gt;
     *                                       &lt;element name="CdRisicopremiegroep" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdCdRisicopremiegroep" minOccurs="0"/&gt;
     *                                       &lt;element name="AansluitingsnrBV" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdAansluitingsnrBV" minOccurs="0"/&gt;
     *                                       &lt;element name="DatBAansluitingsnrBv" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
     *                                     &lt;/sequence&gt;
     *                                   &lt;/restriction&gt;
     *                                 &lt;/complexContent&gt;
     *                               &lt;/complexType&gt;
     *                             &lt;/element&gt;
     *                           &lt;/sequence&gt;
     *                         &lt;/restriction&gt;
     *                       &lt;/complexContent&gt;
     *                     &lt;/complexType&gt;
     *                   &lt;/element&gt;
     *                 &lt;/sequence&gt;
     *               &lt;/restriction&gt;
     *             &lt;/complexContent&gt;
     *           &lt;/complexType&gt;
     *         &lt;/element&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "datTijdBeschouwingGebVSelectie",
        "kvkNr",
        "nrInhoudingsplichtige",
        "loonheffingennr",
        "persoonInhoudingsplichtige"
    })
    public static class Gegevenslevering {

        @XmlElement(name = "DatTijdBeschouwingGebVSelectie")
        @Size(max = 20)
        protected String datTijdBeschouwingGebVSelectie;
        @XmlElement(name = "KvkNr")
        @Size(min = 8, max = 8)
        @Pattern(regexp = "\\d*")
        protected String kvkNr;
        @XmlElement(name = "NrInhoudingsplichtige")
        @Size(min = 9, max = 9)
        @Pattern(regexp = "\\d*")
        protected String nrInhoudingsplichtige;
        @XmlElement(name = "Loonheffingennr")
        @Size(min = 12, max = 12)
        protected String loonheffingennr;
        @XmlElement(name = "PersoonInhoudingsplichtige")
        @Valid
        protected List<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige> persoonInhoudingsplichtige;

        /**
         * Gets the value of the datTijdBeschouwingGebVSelectie property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getDatTijdBeschouwingGebVSelectie() {
            return datTijdBeschouwingGebVSelectie;
        }

        /**
         * Sets the value of the datTijdBeschouwingGebVSelectie property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setDatTijdBeschouwingGebVSelectie(String value) {
            this.datTijdBeschouwingGebVSelectie = value;
        }

        /**
         * Gets the value of the kvkNr property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getKvkNr() {
            return kvkNr;
        }

        /**
         * Sets the value of the kvkNr property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setKvkNr(String value) {
            this.kvkNr = value;
        }

        /**
         * Gets the value of the nrInhoudingsplichtige property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getNrInhoudingsplichtige() {
            return nrInhoudingsplichtige;
        }

        /**
         * Sets the value of the nrInhoudingsplichtige property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setNrInhoudingsplichtige(String value) {
            this.nrInhoudingsplichtige = value;
        }

        /**
         * Gets the value of the loonheffingennr property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getLoonheffingennr() {
            return loonheffingennr;
        }

        /**
         * Sets the value of the loonheffingennr property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setLoonheffingennr(String value) {
            this.loonheffingennr = value;
        }

        /**
         * Gets the value of the persoonInhoudingsplichtige property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the persoonInhoudingsplichtige property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getPersoonInhoudingsplichtige().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige }
         * 
         * 
         */
        public List<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige> getPersoonInhoudingsplichtige() {
            if (persoonInhoudingsplichtige == null) {
                persoonInhoudingsplichtige = new ArrayList<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige>();
            }
            return this.persoonInhoudingsplichtige;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType&gt;
         *   &lt;complexContent&gt;
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *       &lt;sequence&gt;
         *         &lt;choice minOccurs="0"&gt;
         *           &lt;element name="NietNatuurlijkPersoon" minOccurs="0"&gt;
         *             &lt;complexType&gt;
         *               &lt;complexContent&gt;
         *                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                   &lt;sequence&gt;
         *                     &lt;element name="DatOntbindingRechtspSamenwerking" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                     &lt;element name="DatOprichtingRechtspSamenwerking" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                     &lt;element name="Rsin" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdRsin" minOccurs="0"/&gt;
         *                     &lt;element name="DatBNietNatuurlijkPersoon" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                     &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
         *                     &lt;element name="DatENietNatuurlijkPersoon" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                     &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
         *                     &lt;element name="VolledigeNmNietNatuurlijkPersoon" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar500" minOccurs="0"/&gt;
         *                     &lt;element name="Rechtspersoon" minOccurs="0"&gt;
         *                       &lt;complexType&gt;
         *                         &lt;complexContent&gt;
         *                           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                             &lt;sequence&gt;
         *                               &lt;element name="StatutaireZetel" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar60" minOccurs="0"/&gt;
         *                               &lt;element name="DatBStatutaireZetel" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                               &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
         *                               &lt;element name="ActiviteitHandelsregister" minOccurs="0"&gt;
         *                                 &lt;complexType&gt;
         *                                   &lt;complexContent&gt;
         *                                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                                       &lt;sequence&gt;
         *                                         &lt;element name="OmsActiviteitHandelsregister" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdTekstAnVar2000" minOccurs="0"/&gt;
         *                                       &lt;/sequence&gt;
         *                                     &lt;/restriction&gt;
         *                                   &lt;/complexContent&gt;
         *                                 &lt;/complexType&gt;
         *                               &lt;/element&gt;
         *                             &lt;/sequence&gt;
         *                           &lt;/restriction&gt;
         *                         &lt;/complexContent&gt;
         *                       &lt;/complexType&gt;
         *                     &lt;/element&gt;
         *                     &lt;element name="VennootschapBuitenland" minOccurs="0"&gt;
         *                       &lt;complexType&gt;
         *                         &lt;complexContent&gt;
         *                           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                             &lt;sequence&gt;
         *                               &lt;element name="DatBVennootschapBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                               &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
         *                               &lt;element name="DatEVennootschapBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                               &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
         *                             &lt;/sequence&gt;
         *                           &lt;/restriction&gt;
         *                         &lt;/complexContent&gt;
         *                       &lt;/complexType&gt;
         *                     &lt;/element&gt;
         *                   &lt;/sequence&gt;
         *                 &lt;/restriction&gt;
         *               &lt;/complexContent&gt;
         *             &lt;/complexType&gt;
         *           &lt;/element&gt;
         *           &lt;element name="NatuurlijkPersoon" minOccurs="0"&gt;
         *             &lt;complexType&gt;
         *               &lt;complexContent&gt;
         *                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                   &lt;sequence&gt;
         *                     &lt;element name="Burgerservicenr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdBurgerservicenr" minOccurs="0"/&gt;
         *                     &lt;element name="Voorletters" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdVoorletters" minOccurs="0"/&gt;
         *                     &lt;element name="Voornamen" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdVoornamen" minOccurs="0"/&gt;
         *                     &lt;element name="Voorvoegsel" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdVoorvoegsel" minOccurs="0"/&gt;
         *                     &lt;element name="SignificantDeelVanDeAchternaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdSignificantDeelAchtern" minOccurs="0"/&gt;
         *                     &lt;element name="CdAanduidingNaamgebruik" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAanduidingNaamgebruik_nocodes" minOccurs="0"/&gt;
         *                     &lt;element name="Geboortedat" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                     &lt;element name="CdFictieveGeboortedat" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
         *                     &lt;element name="Geslacht" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdGeslacht_nocodes" minOccurs="0"/&gt;
         *                     &lt;element name="HuwelijkGeregistreerdPartner" minOccurs="0"&gt;
         *                       &lt;complexType&gt;
         *                         &lt;complexContent&gt;
         *                           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                             &lt;sequence&gt;
         *                               &lt;element name="VoorvoegselEchtgenoot" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdVoorvoegsel" minOccurs="0"/&gt;
         *                               &lt;element name="SignificantDeelAchternaamEchtg" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdSignificantDeelAchtern" minOccurs="0"/&gt;
         *                             &lt;/sequence&gt;
         *                           &lt;/restriction&gt;
         *                         &lt;/complexContent&gt;
         *                       &lt;/complexType&gt;
         *                     &lt;/element&gt;
         *                   &lt;/sequence&gt;
         *                 &lt;/restriction&gt;
         *               &lt;/complexContent&gt;
         *             &lt;/complexType&gt;
         *           &lt;/element&gt;
         *           &lt;element name="PersoonHandelsregister" minOccurs="0"&gt;
         *             &lt;complexType&gt;
         *               &lt;complexContent&gt;
         *                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                   &lt;sequence&gt;
         *                     &lt;element name="DatBPersoonHandelsregister" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                     &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
         *                     &lt;element name="DatEPersoonHandelsregister" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                     &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
         *                     &lt;element name="NaamPersoonHandelsregister" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar300" minOccurs="0"/&gt;
         *                     &lt;element name="VolledigeNmPersHandelsregister" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar500" minOccurs="0"/&gt;
         *                   &lt;/sequence&gt;
         *                 &lt;/restriction&gt;
         *               &lt;/complexContent&gt;
         *             &lt;/complexType&gt;
         *           &lt;/element&gt;
         *         &lt;/choice&gt;
         *         &lt;element name="Rechtsvorm" maxOccurs="unbounded" minOccurs="0"&gt;
         *           &lt;complexType&gt;
         *             &lt;complexContent&gt;
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                 &lt;sequence&gt;
         *                   &lt;element name="CdRechtsvorm" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdCdRechtsvorm" minOccurs="0"/&gt;
         *                   &lt;element name="DatBRechtsvorm" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                   &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
         *                   &lt;element name="DatERechtsvorm" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                   &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
         *                 &lt;/sequence&gt;
         *               &lt;/restriction&gt;
         *             &lt;/complexContent&gt;
         *           &lt;/complexType&gt;
         *         &lt;/element&gt;
         *         &lt;element name="FaillSurs" maxOccurs="unbounded" minOccurs="0"&gt;
         *           &lt;complexType&gt;
         *             &lt;complexContent&gt;
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                 &lt;sequence&gt;
         *                   &lt;element name="CdFaillSurs" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFaillissementSurseance_nocodes" minOccurs="0"/&gt;
         *                   &lt;element name="CdRedenEindeFaillSurs" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdRedenEindeFaillisSurseance_nocodes" minOccurs="0"/&gt;
         *                   &lt;element name="DatBFaillissementSurseance" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                   &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
         *                   &lt;element name="DatEFaillissementSurseance" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                   &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
         *                 &lt;/sequence&gt;
         *               &lt;/restriction&gt;
         *             &lt;/complexContent&gt;
         *           &lt;/complexType&gt;
         *         &lt;/element&gt;
         *         &lt;element name="Gemoedsbezwaardheid" maxOccurs="unbounded" minOccurs="0"&gt;
         *           &lt;complexType&gt;
         *             &lt;complexContent&gt;
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                 &lt;sequence&gt;
         *                   &lt;element name="CdSzProduct" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdSzProduct_nocodes" minOccurs="0"/&gt;
         *                   &lt;element name="DatBGemoedsbezwaardheid" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                   &lt;element name="DatEGemoedsbezwaardheid" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                 &lt;/sequence&gt;
         *               &lt;/restriction&gt;
         *             &lt;/complexContent&gt;
         *           &lt;/complexType&gt;
         *         &lt;/element&gt;
         *         &lt;element name="Adreshouding" maxOccurs="unbounded" minOccurs="0"&gt;
         *           &lt;complexType&gt;
         *             &lt;complexContent&gt;
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                 &lt;sequence&gt;
         *                   &lt;choice&gt;
         *                     &lt;element name="AdresNederlandUhr"&gt;
         *                       &lt;complexType&gt;
         *                         &lt;complexContent&gt;
         *                           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                             &lt;sequence&gt;
         *                               &lt;element name="CdAdresrol" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAdresrol_nocodes" minOccurs="0"/&gt;
         *                               &lt;element name="DatBAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                               &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
         *                               &lt;element name="DatEAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                               &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
         *                               &lt;element name="CdAfgeschermdAdres" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdOJNNvt_nocodes" minOccurs="0"/&gt;
         *                               &lt;choice minOccurs="0"&gt;
         *                                 &lt;element name="StraatadresUhr" minOccurs="0"&gt;
         *                                   &lt;complexType&gt;
         *                                     &lt;complexContent&gt;
         *                                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                                         &lt;sequence&gt;
         *                                           &lt;element name="Postcd" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcd" minOccurs="0"/&gt;
         *                                           &lt;element name="Woonplaatsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
         *                                           &lt;element name="Straatnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdStraatnaam" minOccurs="0"/&gt;
         *                                           &lt;element name="Huisnr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisnr" minOccurs="0"/&gt;
         *                                           &lt;element name="Huisletter" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisletter" minOccurs="0"/&gt;
         *                                           &lt;element name="Huisnrtoevoeging" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar4" minOccurs="0"/&gt;
         *                                           &lt;element name="CdAanduidingBijHuisnr" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAanduidingBijHuisnr_nocodes" minOccurs="0"/&gt;
         *                                           &lt;element name="NaamOpenbareRuimte" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar80" minOccurs="0"/&gt;
         *                                         &lt;/sequence&gt;
         *                                       &lt;/restriction&gt;
         *                                     &lt;/complexContent&gt;
         *                                   &lt;/complexType&gt;
         *                                 &lt;/element&gt;
         *                                 &lt;element name="PostbusadresUhr" minOccurs="0"&gt;
         *                                   &lt;complexType&gt;
         *                                     &lt;complexContent&gt;
         *                                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                                         &lt;sequence&gt;
         *                                           &lt;element name="Postcd" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcd" minOccurs="0"/&gt;
         *                                           &lt;element name="Woonplaatsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
         *                                           &lt;element name="Postbusnr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostbusnr" minOccurs="0"/&gt;
         *                                         &lt;/sequence&gt;
         *                                       &lt;/restriction&gt;
         *                                     &lt;/complexContent&gt;
         *                                   &lt;/complexType&gt;
         *                                 &lt;/element&gt;
         *                               &lt;/choice&gt;
         *                             &lt;/sequence&gt;
         *                           &lt;/restriction&gt;
         *                         &lt;/complexContent&gt;
         *                       &lt;/complexType&gt;
         *                     &lt;/element&gt;
         *                     &lt;element name="AdresBuitenlandUhr"&gt;
         *                       &lt;complexType&gt;
         *                         &lt;complexContent&gt;
         *                           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                             &lt;sequence&gt;
         *                               &lt;element name="CdAdresrol" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAdresrol_nocodes" minOccurs="0"/&gt;
         *                               &lt;element name="DatBAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                               &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
         *                               &lt;element name="DatEAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                               &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
         *                               &lt;element name="CdAfgeschermdAdres" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdOJNNvt_nocodes" minOccurs="0"/&gt;
         *                               &lt;choice minOccurs="0"&gt;
         *                                 &lt;element name="StraatadresBuitenlandUhr" minOccurs="0"&gt;
         *                                   &lt;complexType&gt;
         *                                     &lt;complexContent&gt;
         *                                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                                         &lt;sequence&gt;
         *                                           &lt;element name="PostcdBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcdBuitenland" minOccurs="0"/&gt;
         *                                           &lt;element name="WoonplaatsnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
         *                                           &lt;element name="RegionaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar24" minOccurs="0"/&gt;
         *                                           &lt;element name="LandcodeGba" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeGba" minOccurs="0"/&gt;
         *                                           &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
         *                                           &lt;element name="Landsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandsnaam" minOccurs="0"/&gt;
         *                                           &lt;element name="StraatnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdStraatnaam" minOccurs="0"/&gt;
         *                                           &lt;element name="HuisnrBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisnrBuitenland" minOccurs="0"/&gt;
         *                                           &lt;element name="LocatieomsBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar128" minOccurs="0"/&gt;
         *                                         &lt;/sequence&gt;
         *                                       &lt;/restriction&gt;
         *                                     &lt;/complexContent&gt;
         *                                   &lt;/complexType&gt;
         *                                 &lt;/element&gt;
         *                                 &lt;element name="PostbusadresBuitenlandUhr" minOccurs="0"&gt;
         *                                   &lt;complexType&gt;
         *                                     &lt;complexContent&gt;
         *                                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                                         &lt;sequence&gt;
         *                                           &lt;element name="PostcdBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcdBuitenland" minOccurs="0"/&gt;
         *                                           &lt;element name="WoonplaatsnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
         *                                           &lt;element name="RegionaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar24" minOccurs="0"/&gt;
         *                                           &lt;element name="LandcodeGba" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeGba" minOccurs="0"/&gt;
         *                                           &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
         *                                           &lt;element name="Landsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandsnaam" minOccurs="0"/&gt;
         *                                           &lt;element name="PostbusnrBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdReferentienrAnVar8" minOccurs="0"/&gt;
         *                                         &lt;/sequence&gt;
         *                                       &lt;/restriction&gt;
         *                                     &lt;/complexContent&gt;
         *                                   &lt;/complexType&gt;
         *                                 &lt;/element&gt;
         *                               &lt;/choice&gt;
         *                             &lt;/sequence&gt;
         *                           &lt;/restriction&gt;
         *                         &lt;/complexContent&gt;
         *                       &lt;/complexType&gt;
         *                     &lt;/element&gt;
         *                     &lt;element name="AdresBuitenlandOngestructureerdUhr"&gt;
         *                       &lt;complexType&gt;
         *                         &lt;complexContent&gt;
         *                           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                             &lt;sequence&gt;
         *                               &lt;element name="CdAdresrol" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAdresrol_nocodes" minOccurs="0"/&gt;
         *                               &lt;element name="DatBAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                               &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
         *                               &lt;element name="DatEAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                               &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
         *                               &lt;element name="CdAfgeschermdAdres" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdOJNNvt_nocodes" minOccurs="0"/&gt;
         *                               &lt;element name="Adresregel1Buitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar35" minOccurs="0"/&gt;
         *                               &lt;element name="Adresregel2Buitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar35" minOccurs="0"/&gt;
         *                               &lt;element name="Adresregel3Buitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar35" minOccurs="0"/&gt;
         *                               &lt;element name="LandcodeGba" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeGba" minOccurs="0"/&gt;
         *                               &lt;element name="LandsnaamGba" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar40" minOccurs="0"/&gt;
         *                               &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
         *                               &lt;element name="Landsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandsnaam" minOccurs="0"/&gt;
         *                             &lt;/sequence&gt;
         *                           &lt;/restriction&gt;
         *                         &lt;/complexContent&gt;
         *                       &lt;/complexType&gt;
         *                     &lt;/element&gt;
         *                   &lt;/choice&gt;
         *                 &lt;/sequence&gt;
         *               &lt;/restriction&gt;
         *             &lt;/complexContent&gt;
         *           &lt;/complexType&gt;
         *         &lt;/element&gt;
         *         &lt;element name="MaatschappelijkeActiviteit" maxOccurs="unbounded" minOccurs="0"&gt;
         *           &lt;complexType&gt;
         *             &lt;complexContent&gt;
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                 &lt;sequence&gt;
         *                   &lt;element name="KvkNr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdKvkNr" minOccurs="0"/&gt;
         *                   &lt;element name="DatBMaatschappelijkeActiviteit" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                   &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
         *                   &lt;element name="DatEMaatschappelijkeActiviteit" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                   &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
         *                   &lt;element name="Sbiklasse" maxOccurs="unbounded" minOccurs="0"&gt;
         *                     &lt;complexType&gt;
         *                       &lt;complexContent&gt;
         *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                           &lt;sequence&gt;
         *                             &lt;element name="CdSbi" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdSbi" minOccurs="0"/&gt;
         *                             &lt;element name="OmsSbi" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar300" minOccurs="0"/&gt;
         *                             &lt;element name="IndSbiHoofdactiviteit" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdIndJN_nocodes" minOccurs="0"/&gt;
         *                             &lt;element name="DatBSbiactiviteit" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                             &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
         *                             &lt;element name="DatESbiactiviteit" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                             &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
         *                           &lt;/sequence&gt;
         *                         &lt;/restriction&gt;
         *                       &lt;/complexContent&gt;
         *                     &lt;/complexType&gt;
         *                   &lt;/element&gt;
         *                   &lt;element name="VestigingHandelsregister" maxOccurs="unbounded" minOccurs="0"&gt;
         *                     &lt;complexType&gt;
         *                       &lt;complexContent&gt;
         *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                           &lt;sequence&gt;
         *                             &lt;element name="VestigingsnrHandelsregister" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdVestigingsnrHandelsregister" minOccurs="0"/&gt;
         *                             &lt;element name="EersteHandelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar200" minOccurs="0"/&gt;
         *                             &lt;element name="DatBVestigingHandelsregister" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                             &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
         *                             &lt;element name="DatEVestigingHandelsregister" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                             &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
         *                             &lt;element name="Adreshouding" maxOccurs="unbounded" minOccurs="0"&gt;
         *                               &lt;complexType&gt;
         *                                 &lt;complexContent&gt;
         *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                                     &lt;sequence&gt;
         *                                       &lt;choice&gt;
         *                                         &lt;element name="AdresNederlandUhr"&gt;
         *                                           &lt;complexType&gt;
         *                                             &lt;complexContent&gt;
         *                                               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                                                 &lt;sequence&gt;
         *                                                   &lt;element name="CdAdresrol" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAdresrol_nocodes" minOccurs="0"/&gt;
         *                                                   &lt;element name="DatBAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                                                   &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
         *                                                   &lt;element name="DatEAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                                                   &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
         *                                                   &lt;element name="CdAfgeschermdAdres" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdOJNNvt_nocodes" minOccurs="0"/&gt;
         *                                                   &lt;choice minOccurs="0"&gt;
         *                                                     &lt;element name="StraatadresUhr" minOccurs="0"&gt;
         *                                                       &lt;complexType&gt;
         *                                                         &lt;complexContent&gt;
         *                                                           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                                                             &lt;sequence&gt;
         *                                                               &lt;element name="Postcd" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcd" minOccurs="0"/&gt;
         *                                                               &lt;element name="Woonplaatsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
         *                                                               &lt;element name="Straatnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdStraatnaam" minOccurs="0"/&gt;
         *                                                               &lt;element name="Huisnr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisnr" minOccurs="0"/&gt;
         *                                                               &lt;element name="Huisletter" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisletter" minOccurs="0"/&gt;
         *                                                               &lt;element name="Huisnrtoevoeging" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar4" minOccurs="0"/&gt;
         *                                                               &lt;element name="CdAanduidingBijHuisnr" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAanduidingBijHuisnr_nocodes" minOccurs="0"/&gt;
         *                                                               &lt;element name="NaamOpenbareRuimte" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar80" minOccurs="0"/&gt;
         *                                                             &lt;/sequence&gt;
         *                                                           &lt;/restriction&gt;
         *                                                         &lt;/complexContent&gt;
         *                                                       &lt;/complexType&gt;
         *                                                     &lt;/element&gt;
         *                                                     &lt;element name="PostbusadresUhr" minOccurs="0"&gt;
         *                                                       &lt;complexType&gt;
         *                                                         &lt;complexContent&gt;
         *                                                           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                                                             &lt;sequence&gt;
         *                                                               &lt;element name="Postcd" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcd" minOccurs="0"/&gt;
         *                                                               &lt;element name="Woonplaatsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
         *                                                               &lt;element name="Postbusnr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostbusnr" minOccurs="0"/&gt;
         *                                                             &lt;/sequence&gt;
         *                                                           &lt;/restriction&gt;
         *                                                         &lt;/complexContent&gt;
         *                                                       &lt;/complexType&gt;
         *                                                     &lt;/element&gt;
         *                                                   &lt;/choice&gt;
         *                                                 &lt;/sequence&gt;
         *                                               &lt;/restriction&gt;
         *                                             &lt;/complexContent&gt;
         *                                           &lt;/complexType&gt;
         *                                         &lt;/element&gt;
         *                                         &lt;element name="AdresBuitenlandUhr"&gt;
         *                                           &lt;complexType&gt;
         *                                             &lt;complexContent&gt;
         *                                               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                                                 &lt;sequence&gt;
         *                                                   &lt;element name="CdAdresrol" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAdresrol_nocodes" minOccurs="0"/&gt;
         *                                                   &lt;element name="DatBAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                                                   &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
         *                                                   &lt;element name="DatEAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                                                   &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
         *                                                   &lt;element name="CdAfgeschermdAdres" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdOJNNvt_nocodes" minOccurs="0"/&gt;
         *                                                   &lt;choice minOccurs="0"&gt;
         *                                                     &lt;element name="StraatadresBuitenlandUhr" minOccurs="0"&gt;
         *                                                       &lt;complexType&gt;
         *                                                         &lt;complexContent&gt;
         *                                                           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                                                             &lt;sequence&gt;
         *                                                               &lt;element name="PostcdBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcdBuitenland" minOccurs="0"/&gt;
         *                                                               &lt;element name="WoonplaatsnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
         *                                                               &lt;element name="RegionaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar24" minOccurs="0"/&gt;
         *                                                               &lt;element name="LandcodeGba" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeGba" minOccurs="0"/&gt;
         *                                                               &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
         *                                                               &lt;element name="Landsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandsnaam" minOccurs="0"/&gt;
         *                                                               &lt;element name="StraatnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdStraatnaam" minOccurs="0"/&gt;
         *                                                               &lt;element name="HuisnrBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisnrBuitenland" minOccurs="0"/&gt;
         *                                                               &lt;element name="LocatieomsBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar128" minOccurs="0"/&gt;
         *                                                             &lt;/sequence&gt;
         *                                                           &lt;/restriction&gt;
         *                                                         &lt;/complexContent&gt;
         *                                                       &lt;/complexType&gt;
         *                                                     &lt;/element&gt;
         *                                                     &lt;element name="PostbusadresBuitenlandUhr" minOccurs="0"&gt;
         *                                                       &lt;complexType&gt;
         *                                                         &lt;complexContent&gt;
         *                                                           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                                                             &lt;sequence&gt;
         *                                                               &lt;element name="PostcdBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcdBuitenland" minOccurs="0"/&gt;
         *                                                               &lt;element name="WoonplaatsnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
         *                                                               &lt;element name="RegionaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar24" minOccurs="0"/&gt;
         *                                                               &lt;element name="LandcodeGba" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeGba" minOccurs="0"/&gt;
         *                                                               &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
         *                                                               &lt;element name="Landsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandsnaam" minOccurs="0"/&gt;
         *                                                               &lt;element name="PostbusnrBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdReferentienrAnVar8" minOccurs="0"/&gt;
         *                                                             &lt;/sequence&gt;
         *                                                           &lt;/restriction&gt;
         *                                                         &lt;/complexContent&gt;
         *                                                       &lt;/complexType&gt;
         *                                                     &lt;/element&gt;
         *                                                   &lt;/choice&gt;
         *                                                 &lt;/sequence&gt;
         *                                               &lt;/restriction&gt;
         *                                             &lt;/complexContent&gt;
         *                                           &lt;/complexType&gt;
         *                                         &lt;/element&gt;
         *                                         &lt;element name="AdresBuitenlandOngestructureerdUhr"&gt;
         *                                           &lt;complexType&gt;
         *                                             &lt;complexContent&gt;
         *                                               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                                                 &lt;sequence&gt;
         *                                                   &lt;element name="CdAdresrol" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAdresrol_nocodes" minOccurs="0"/&gt;
         *                                                   &lt;element name="DatBAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                                                   &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
         *                                                   &lt;element name="DatEAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                                                   &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
         *                                                   &lt;element name="CdAfgeschermdAdres" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdOJNNvt_nocodes" minOccurs="0"/&gt;
         *                                                   &lt;element name="Adresregel1Buitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar35" minOccurs="0"/&gt;
         *                                                   &lt;element name="Adresregel2Buitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar35" minOccurs="0"/&gt;
         *                                                   &lt;element name="Adresregel3Buitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar35" minOccurs="0"/&gt;
         *                                                   &lt;element name="LandcodeGba" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeGba" minOccurs="0"/&gt;
         *                                                   &lt;element name="LandsnaamGba" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar40" minOccurs="0"/&gt;
         *                                                   &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
         *                                                   &lt;element name="Landsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandsnaam" minOccurs="0"/&gt;
         *                                                 &lt;/sequence&gt;
         *                                               &lt;/restriction&gt;
         *                                             &lt;/complexContent&gt;
         *                                           &lt;/complexType&gt;
         *                                         &lt;/element&gt;
         *                                       &lt;/choice&gt;
         *                                     &lt;/sequence&gt;
         *                                   &lt;/restriction&gt;
         *                                 &lt;/complexContent&gt;
         *                               &lt;/complexType&gt;
         *                             &lt;/element&gt;
         *                             &lt;element name="ActiviteitHandelsregister" minOccurs="0"&gt;
         *                               &lt;complexType&gt;
         *                                 &lt;complexContent&gt;
         *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                                     &lt;sequence&gt;
         *                                       &lt;element name="OmsActiviteitHandelsregister" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdTekstAnVar2000" minOccurs="0"/&gt;
         *                                       &lt;element name="Sbiklasse" maxOccurs="unbounded" minOccurs="0"&gt;
         *                                         &lt;complexType&gt;
         *                                           &lt;complexContent&gt;
         *                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                                               &lt;sequence&gt;
         *                                                 &lt;element name="CdSbi" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdSbi" minOccurs="0"/&gt;
         *                                                 &lt;element name="OmsSbi" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar300" minOccurs="0"/&gt;
         *                                                 &lt;element name="IndSbiHoofdactiviteit" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdIndJN_nocodes" minOccurs="0"/&gt;
         *                                                 &lt;element name="DatBSbiactiviteit" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                                                 &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
         *                                                 &lt;element name="DatESbiactiviteit" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                                                 &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
         *                                               &lt;/sequence&gt;
         *                                             &lt;/restriction&gt;
         *                                           &lt;/complexContent&gt;
         *                                         &lt;/complexType&gt;
         *                                       &lt;/element&gt;
         *                                     &lt;/sequence&gt;
         *                                   &lt;/restriction&gt;
         *                                 &lt;/complexContent&gt;
         *                               &lt;/complexType&gt;
         *                             &lt;/element&gt;
         *                             &lt;element name="Onderneming" maxOccurs="unbounded" minOccurs="0"&gt;
         *                               &lt;complexType&gt;
         *                                 &lt;complexContent&gt;
         *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                                     &lt;sequence&gt;
         *                                       &lt;element name="KvkNr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdKvkNr" minOccurs="0"/&gt;
         *                                       &lt;element name="DatBOnderneming" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                                       &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
         *                                       &lt;element name="DatEOnderneming" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                                       &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
         *                                       &lt;element name="Sbiklasse" maxOccurs="unbounded" minOccurs="0"&gt;
         *                                         &lt;complexType&gt;
         *                                           &lt;complexContent&gt;
         *                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                                               &lt;sequence&gt;
         *                                                 &lt;element name="CdSbi" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdSbi" minOccurs="0"/&gt;
         *                                                 &lt;element name="OmsSbi" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar300" minOccurs="0"/&gt;
         *                                                 &lt;element name="IndSbiHoofdactiviteit" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdIndJN_nocodes" minOccurs="0"/&gt;
         *                                                 &lt;element name="DatBSbiactiviteit" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                                                 &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
         *                                                 &lt;element name="DatESbiactiviteit" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                                                 &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
         *                                               &lt;/sequence&gt;
         *                                             &lt;/restriction&gt;
         *                                           &lt;/complexContent&gt;
         *                                         &lt;/complexType&gt;
         *                                       &lt;/element&gt;
         *                                       &lt;element name="Handelsnaam" maxOccurs="unbounded" minOccurs="0"&gt;
         *                                         &lt;complexType&gt;
         *                                           &lt;complexContent&gt;
         *                                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                                               &lt;sequence&gt;
         *                                                 &lt;element name="Handelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar625" minOccurs="0"/&gt;
         *                                                 &lt;element name="VolgordeHandelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdAantNietNegatiefVar4" minOccurs="0"/&gt;
         *                                                 &lt;element name="DatBHandelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                                                 &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
         *                                                 &lt;element name="DatEHandelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                                                 &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
         *                                               &lt;/sequence&gt;
         *                                             &lt;/restriction&gt;
         *                                           &lt;/complexContent&gt;
         *                                         &lt;/complexType&gt;
         *                                       &lt;/element&gt;
         *                                     &lt;/sequence&gt;
         *                                   &lt;/restriction&gt;
         *                                 &lt;/complexContent&gt;
         *                               &lt;/complexType&gt;
         *                             &lt;/element&gt;
         *                             &lt;element name="Handelsnaam" maxOccurs="unbounded" minOccurs="0"&gt;
         *                               &lt;complexType&gt;
         *                                 &lt;complexContent&gt;
         *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                                     &lt;sequence&gt;
         *                                       &lt;element name="Handelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar625" minOccurs="0"/&gt;
         *                                       &lt;element name="VolgordeHandelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdAantNietNegatiefVar4" minOccurs="0"/&gt;
         *                                       &lt;element name="DatBHandelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                                       &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
         *                                       &lt;element name="DatEHandelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                                       &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
         *                                     &lt;/sequence&gt;
         *                                   &lt;/restriction&gt;
         *                                 &lt;/complexContent&gt;
         *                               &lt;/complexType&gt;
         *                             &lt;/element&gt;
         *                           &lt;/sequence&gt;
         *                         &lt;/restriction&gt;
         *                       &lt;/complexContent&gt;
         *                     &lt;/complexType&gt;
         *                   &lt;/element&gt;
         *                 &lt;/sequence&gt;
         *               &lt;/restriction&gt;
         *             &lt;/complexContent&gt;
         *           &lt;/complexType&gt;
         *         &lt;/element&gt;
         *         &lt;element name="AdministratieveEenheid" maxOccurs="unbounded" minOccurs="0"&gt;
         *           &lt;complexType&gt;
         *             &lt;complexContent&gt;
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                 &lt;sequence&gt;
         *                   &lt;element name="Loonheffingennr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLoonheffingennr" minOccurs="0"/&gt;
         *                   &lt;element name="NaamAdminEenheid" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar200" minOccurs="0"/&gt;
         *                   &lt;element name="DatBAdminEenheid" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                   &lt;element name="DatEAdminEenheid" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                   &lt;element name="SectorRisicogroep" maxOccurs="unbounded" minOccurs="0"&gt;
         *                     &lt;complexType&gt;
         *                       &lt;complexContent&gt;
         *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                           &lt;sequence&gt;
         *                             &lt;element name="CdRisicopremiegroep" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdCdRisicopremiegroep" minOccurs="0"/&gt;
         *                             &lt;element name="CdSectorOsv" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdCdSectorOsv" minOccurs="0"/&gt;
         *                             &lt;element name="DatB" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                             &lt;element name="DatE" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                           &lt;/sequence&gt;
         *                         &lt;/restriction&gt;
         *                       &lt;/complexContent&gt;
         *                     &lt;/complexType&gt;
         *                   &lt;/element&gt;
         *                   &lt;element name="PremiepercIndividueel" maxOccurs="unbounded" minOccurs="0"&gt;
         *                     &lt;complexType&gt;
         *                       &lt;complexContent&gt;
         *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                           &lt;sequence&gt;
         *                             &lt;element name="Perc" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPercDec2" minOccurs="0"/&gt;
         *                             &lt;element name="CdSzProduct" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdSzProduct_nocodes" minOccurs="0"/&gt;
         *                             &lt;element name="DatBPrpercIndividueel" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                             &lt;element name="DatEPrpercIndividueel" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                           &lt;/sequence&gt;
         *                         &lt;/restriction&gt;
         *                       &lt;/complexContent&gt;
         *                     &lt;/complexType&gt;
         *                   &lt;/element&gt;
         *                   &lt;element name="EigenRisicoDrager" maxOccurs="unbounded" minOccurs="0"&gt;
         *                     &lt;complexType&gt;
         *                       &lt;complexContent&gt;
         *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                           &lt;sequence&gt;
         *                             &lt;element name="CdSzProduct" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdSzProduct_nocodes" minOccurs="0"/&gt;
         *                             &lt;element name="DatBEigenrisicodrager" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                             &lt;element name="DatEEigenrisicodrager" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                           &lt;/sequence&gt;
         *                         &lt;/restriction&gt;
         *                       &lt;/complexContent&gt;
         *                     &lt;/complexType&gt;
         *                   &lt;/element&gt;
         *                   &lt;element name="Adreshouding" maxOccurs="unbounded" minOccurs="0"&gt;
         *                     &lt;complexType&gt;
         *                       &lt;complexContent&gt;
         *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                           &lt;sequence&gt;
         *                             &lt;choice&gt;
         *                               &lt;element name="AdresNederlandWga"&gt;
         *                                 &lt;complexType&gt;
         *                                   &lt;complexContent&gt;
         *                                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                                       &lt;sequence&gt;
         *                                         &lt;element name="CdAdresrol" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAdresrol_nocodes" minOccurs="0"/&gt;
         *                                         &lt;element name="DatBAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                                         &lt;element name="DatEAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                                         &lt;choice minOccurs="0"&gt;
         *                                           &lt;element name="StraatadresWga" minOccurs="0"&gt;
         *                                             &lt;complexType&gt;
         *                                               &lt;complexContent&gt;
         *                                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                                                   &lt;sequence&gt;
         *                                                     &lt;element name="Postcd" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcd" minOccurs="0"/&gt;
         *                                                     &lt;element name="Woonplaatsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
         *                                                     &lt;element name="Gemeentenaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdGemeentenaam" minOccurs="0"/&gt;
         *                                                     &lt;element name="Straatnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdStraatnaam" minOccurs="0"/&gt;
         *                                                     &lt;element name="Huisnr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisnr" minOccurs="0"/&gt;
         *                                                     &lt;element name="Huisnrtoevoeging" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar4" minOccurs="0"/&gt;
         *                                                     &lt;element name="Locatieoms" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar70" minOccurs="0"/&gt;
         *                                                   &lt;/sequence&gt;
         *                                                 &lt;/restriction&gt;
         *                                               &lt;/complexContent&gt;
         *                                             &lt;/complexType&gt;
         *                                           &lt;/element&gt;
         *                                           &lt;element name="PostbusadresWga" minOccurs="0"&gt;
         *                                             &lt;complexType&gt;
         *                                               &lt;complexContent&gt;
         *                                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                                                   &lt;sequence&gt;
         *                                                     &lt;element name="Postcd" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcd" minOccurs="0"/&gt;
         *                                                     &lt;element name="Woonplaatsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
         *                                                     &lt;element name="Postbusnr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostbusnr" minOccurs="0"/&gt;
         *                                                   &lt;/sequence&gt;
         *                                                 &lt;/restriction&gt;
         *                                               &lt;/complexContent&gt;
         *                                             &lt;/complexType&gt;
         *                                           &lt;/element&gt;
         *                                         &lt;/choice&gt;
         *                                       &lt;/sequence&gt;
         *                                     &lt;/restriction&gt;
         *                                   &lt;/complexContent&gt;
         *                                 &lt;/complexType&gt;
         *                               &lt;/element&gt;
         *                               &lt;element name="AdresBuitenlandWga"&gt;
         *                                 &lt;complexType&gt;
         *                                   &lt;complexContent&gt;
         *                                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                                       &lt;sequence&gt;
         *                                         &lt;element name="CdAdresrol" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAdresrol_nocodes" minOccurs="0"/&gt;
         *                                         &lt;element name="DatBAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                                         &lt;element name="DatEAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                                         &lt;choice minOccurs="0"&gt;
         *                                           &lt;element name="StraatadresBuitenlandWga" minOccurs="0"&gt;
         *                                             &lt;complexType&gt;
         *                                               &lt;complexContent&gt;
         *                                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                                                   &lt;sequence&gt;
         *                                                     &lt;element name="PostcdBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcdBuitenland" minOccurs="0"/&gt;
         *                                                     &lt;element name="WoonplaatsnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
         *                                                     &lt;element name="RegionaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar24" minOccurs="0"/&gt;
         *                                                     &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
         *                                                     &lt;element name="StraatnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdStraatnaam" minOccurs="0"/&gt;
         *                                                     &lt;element name="HuisnrBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisnrBuitenland" minOccurs="0"/&gt;
         *                                                     &lt;element name="LocatieomsBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar128" minOccurs="0"/&gt;
         *                                                   &lt;/sequence&gt;
         *                                                 &lt;/restriction&gt;
         *                                               &lt;/complexContent&gt;
         *                                             &lt;/complexType&gt;
         *                                           &lt;/element&gt;
         *                                           &lt;element name="PostbusadresBuitenlandWga" minOccurs="0"&gt;
         *                                             &lt;complexType&gt;
         *                                               &lt;complexContent&gt;
         *                                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                                                   &lt;sequence&gt;
         *                                                     &lt;element name="PostcdBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcdBuitenland" minOccurs="0"/&gt;
         *                                                     &lt;element name="WoonplaatsnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
         *                                                     &lt;element name="RegionaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar24" minOccurs="0"/&gt;
         *                                                     &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
         *                                                     &lt;element name="PostbusnrBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdReferentienrAnVar8" minOccurs="0"/&gt;
         *                                                   &lt;/sequence&gt;
         *                                                 &lt;/restriction&gt;
         *                                               &lt;/complexContent&gt;
         *                                             &lt;/complexType&gt;
         *                                           &lt;/element&gt;
         *                                         &lt;/choice&gt;
         *                                       &lt;/sequence&gt;
         *                                     &lt;/restriction&gt;
         *                                   &lt;/complexContent&gt;
         *                                 &lt;/complexType&gt;
         *                               &lt;/element&gt;
         *                               &lt;element name="AdresBuitenlandOngestructureerdWga"&gt;
         *                                 &lt;complexType&gt;
         *                                   &lt;complexContent&gt;
         *                                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                                       &lt;sequence&gt;
         *                                         &lt;element name="CdAdresrol" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAdresrol_nocodes" minOccurs="0"/&gt;
         *                                         &lt;element name="DatBAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                                         &lt;element name="DatEAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                                         &lt;element name="Adresregel1Buitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar35" minOccurs="0"/&gt;
         *                                         &lt;element name="Adresregel2Buitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar35" minOccurs="0"/&gt;
         *                                         &lt;element name="Adresregel3Buitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar35" minOccurs="0"/&gt;
         *                                         &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
         *                                       &lt;/sequence&gt;
         *                                     &lt;/restriction&gt;
         *                                   &lt;/complexContent&gt;
         *                                 &lt;/complexType&gt;
         *                               &lt;/element&gt;
         *                             &lt;/choice&gt;
         *                           &lt;/sequence&gt;
         *                         &lt;/restriction&gt;
         *                       &lt;/complexContent&gt;
         *                     &lt;/complexType&gt;
         *                   &lt;/element&gt;
         *                   &lt;element name="VoortzettingsrelatieOpvolger" maxOccurs="unbounded" minOccurs="0"&gt;
         *                     &lt;complexType&gt;
         *                       &lt;complexContent&gt;
         *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                           &lt;sequence&gt;
         *                             &lt;element name="DatBVoortzettingsrelatie" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                             &lt;element name="PercLoonsomOvergegaanInOpvolger" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPercNietNegatiefDec2" minOccurs="0"/&gt;
         *                             &lt;element name="LoonheffingennrOpvolger" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLoonheffingennr" minOccurs="0"/&gt;
         *                           &lt;/sequence&gt;
         *                         &lt;/restriction&gt;
         *                       &lt;/complexContent&gt;
         *                     &lt;/complexType&gt;
         *                   &lt;/element&gt;
         *                   &lt;element name="VoortzettingsrelatieVoorganger" maxOccurs="unbounded" minOccurs="0"&gt;
         *                     &lt;complexType&gt;
         *                       &lt;complexContent&gt;
         *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                           &lt;sequence&gt;
         *                             &lt;element name="DatBVoortzettingsrelatie" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                             &lt;element name="PercLoonsomOvergegaanInOpvolger" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPercNietNegatiefDec2" minOccurs="0"/&gt;
         *                             &lt;element name="Loonheffingennr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLoonheffingennr" minOccurs="0"/&gt;
         *                           &lt;/sequence&gt;
         *                         &lt;/restriction&gt;
         *                       &lt;/complexContent&gt;
         *                     &lt;/complexType&gt;
         *                   &lt;/element&gt;
         *                   &lt;element name="AangifteFrequentieAdminEenheid" maxOccurs="unbounded" minOccurs="0"&gt;
         *                     &lt;complexType&gt;
         *                       &lt;complexContent&gt;
         *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                           &lt;sequence&gt;
         *                             &lt;element name="DatBAangiftefreqAdminEenheid" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                             &lt;element name="CdAangiftefrequentieAdminEenheid" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAangiftefreqAdminEenheid_nocodes" minOccurs="0"/&gt;
         *                             &lt;element name="DatEAangiftefreqAdminEenheid" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                           &lt;/sequence&gt;
         *                         &lt;/restriction&gt;
         *                       &lt;/complexContent&gt;
         *                     &lt;/complexType&gt;
         *                   &lt;/element&gt;
         *                   &lt;element name="AansluitingsnrBv" maxOccurs="unbounded" minOccurs="0"&gt;
         *                     &lt;complexType&gt;
         *                       &lt;complexContent&gt;
         *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *                           &lt;sequence&gt;
         *                             &lt;element name="CdSectorOsv" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdCdSectorOsv" minOccurs="0"/&gt;
         *                             &lt;element name="CdRisicopremiegroep" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdCdRisicopremiegroep" minOccurs="0"/&gt;
         *                             &lt;element name="AansluitingsnrBV" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdAansluitingsnrBV" minOccurs="0"/&gt;
         *                             &lt;element name="DatBAansluitingsnrBv" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
         *                           &lt;/sequence&gt;
         *                         &lt;/restriction&gt;
         *                       &lt;/complexContent&gt;
         *                     &lt;/complexType&gt;
         *                   &lt;/element&gt;
         *                 &lt;/sequence&gt;
         *               &lt;/restriction&gt;
         *             &lt;/complexContent&gt;
         *           &lt;/complexType&gt;
         *         &lt;/element&gt;
         *       &lt;/sequence&gt;
         *     &lt;/restriction&gt;
         *   &lt;/complexContent&gt;
         * &lt;/complexType&gt;
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "nietNatuurlijkPersoon",
            "natuurlijkPersoon",
            "persoonHandelsregister",
            "rechtsvorm",
            "faillSurs",
            "gemoedsbezwaardheid",
            "adreshouding",
            "maatschappelijkeActiviteit",
            "administratieveEenheid"
        })
        public static class PersoonInhoudingsplichtige {

            @XmlElement(name = "NietNatuurlijkPersoon")
            @Valid
            protected CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NietNatuurlijkPersoon nietNatuurlijkPersoon;
            @XmlElement(name = "NatuurlijkPersoon")
            @Valid
            protected CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NatuurlijkPersoon natuurlijkPersoon;
            @XmlElement(name = "PersoonHandelsregister")
            @Valid
            protected CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.PersoonHandelsregister persoonHandelsregister;
            @XmlElement(name = "Rechtsvorm")
            @Valid
            protected List<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Rechtsvorm> rechtsvorm;
            @XmlElement(name = "FaillSurs")
            @Valid
            protected List<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.FaillSurs> faillSurs;
            @XmlElement(name = "Gemoedsbezwaardheid")
            @Valid
            protected List<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Gemoedsbezwaardheid> gemoedsbezwaardheid;
            @XmlElement(name = "Adreshouding")
            @Valid
            protected List<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding> adreshouding;
            @XmlElement(name = "MaatschappelijkeActiviteit")
            @Valid
            protected List<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit> maatschappelijkeActiviteit;
            @XmlElement(name = "AdministratieveEenheid")
            @Valid
            protected List<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid> administratieveEenheid;

            /**
             * Gets the value of the nietNatuurlijkPersoon property.
             * 
             * @return
             *     possible object is
             *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NietNatuurlijkPersoon }
             *     
             */
            public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NietNatuurlijkPersoon getNietNatuurlijkPersoon() {
                return nietNatuurlijkPersoon;
            }

            /**
             * Sets the value of the nietNatuurlijkPersoon property.
             * 
             * @param value
             *     allowed object is
             *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NietNatuurlijkPersoon }
             *     
             */
            public void setNietNatuurlijkPersoon(CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NietNatuurlijkPersoon value) {
                this.nietNatuurlijkPersoon = value;
            }

            /**
             * Gets the value of the natuurlijkPersoon property.
             * 
             * @return
             *     possible object is
             *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NatuurlijkPersoon }
             *     
             */
            public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NatuurlijkPersoon getNatuurlijkPersoon() {
                return natuurlijkPersoon;
            }

            /**
             * Sets the value of the natuurlijkPersoon property.
             * 
             * @param value
             *     allowed object is
             *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NatuurlijkPersoon }
             *     
             */
            public void setNatuurlijkPersoon(CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NatuurlijkPersoon value) {
                this.natuurlijkPersoon = value;
            }

            /**
             * Gets the value of the persoonHandelsregister property.
             * 
             * @return
             *     possible object is
             *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.PersoonHandelsregister }
             *     
             */
            public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.PersoonHandelsregister getPersoonHandelsregister() {
                return persoonHandelsregister;
            }

            /**
             * Sets the value of the persoonHandelsregister property.
             * 
             * @param value
             *     allowed object is
             *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.PersoonHandelsregister }
             *     
             */
            public void setPersoonHandelsregister(CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.PersoonHandelsregister value) {
                this.persoonHandelsregister = value;
            }

            /**
             * Gets the value of the rechtsvorm property.
             * 
             * <p>
             * This accessor method returns a reference to the live list,
             * not a snapshot. Therefore any modification you make to the
             * returned list will be present inside the JAXB object.
             * This is why there is not a <CODE>set</CODE> method for the rechtsvorm property.
             * 
             * <p>
             * For example, to add a new item, do as follows:
             * <pre>
             *    getRechtsvorm().add(newItem);
             * </pre>
             * 
             * 
             * <p>
             * Objects of the following type(s) are allowed in the list
             * {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Rechtsvorm }
             * 
             * 
             */
            public List<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Rechtsvorm> getRechtsvorm() {
                if (rechtsvorm == null) {
                    rechtsvorm = new ArrayList<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Rechtsvorm>();
                }
                return this.rechtsvorm;
            }

            /**
             * Gets the value of the faillSurs property.
             * 
             * <p>
             * This accessor method returns a reference to the live list,
             * not a snapshot. Therefore any modification you make to the
             * returned list will be present inside the JAXB object.
             * This is why there is not a <CODE>set</CODE> method for the faillSurs property.
             * 
             * <p>
             * For example, to add a new item, do as follows:
             * <pre>
             *    getFaillSurs().add(newItem);
             * </pre>
             * 
             * 
             * <p>
             * Objects of the following type(s) are allowed in the list
             * {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.FaillSurs }
             * 
             * 
             */
            public List<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.FaillSurs> getFaillSurs() {
                if (faillSurs == null) {
                    faillSurs = new ArrayList<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.FaillSurs>();
                }
                return this.faillSurs;
            }

            /**
             * Gets the value of the gemoedsbezwaardheid property.
             * 
             * <p>
             * This accessor method returns a reference to the live list,
             * not a snapshot. Therefore any modification you make to the
             * returned list will be present inside the JAXB object.
             * This is why there is not a <CODE>set</CODE> method for the gemoedsbezwaardheid property.
             * 
             * <p>
             * For example, to add a new item, do as follows:
             * <pre>
             *    getGemoedsbezwaardheid().add(newItem);
             * </pre>
             * 
             * 
             * <p>
             * Objects of the following type(s) are allowed in the list
             * {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Gemoedsbezwaardheid }
             * 
             * 
             */
            public List<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Gemoedsbezwaardheid> getGemoedsbezwaardheid() {
                if (gemoedsbezwaardheid == null) {
                    gemoedsbezwaardheid = new ArrayList<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Gemoedsbezwaardheid>();
                }
                return this.gemoedsbezwaardheid;
            }

            /**
             * Gets the value of the adreshouding property.
             * 
             * <p>
             * This accessor method returns a reference to the live list,
             * not a snapshot. Therefore any modification you make to the
             * returned list will be present inside the JAXB object.
             * This is why there is not a <CODE>set</CODE> method for the adreshouding property.
             * 
             * <p>
             * For example, to add a new item, do as follows:
             * <pre>
             *    getAdreshouding().add(newItem);
             * </pre>
             * 
             * 
             * <p>
             * Objects of the following type(s) are allowed in the list
             * {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding }
             * 
             * 
             */
            public List<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding> getAdreshouding() {
                if (adreshouding == null) {
                    adreshouding = new ArrayList<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding>();
                }
                return this.adreshouding;
            }

            /**
             * Gets the value of the maatschappelijkeActiviteit property.
             * 
             * <p>
             * This accessor method returns a reference to the live list,
             * not a snapshot. Therefore any modification you make to the
             * returned list will be present inside the JAXB object.
             * This is why there is not a <CODE>set</CODE> method for the maatschappelijkeActiviteit property.
             * 
             * <p>
             * For example, to add a new item, do as follows:
             * <pre>
             *    getMaatschappelijkeActiviteit().add(newItem);
             * </pre>
             * 
             * 
             * <p>
             * Objects of the following type(s) are allowed in the list
             * {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit }
             * 
             * 
             */
            public List<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit> getMaatschappelijkeActiviteit() {
                if (maatschappelijkeActiviteit == null) {
                    maatschappelijkeActiviteit = new ArrayList<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit>();
                }
                return this.maatschappelijkeActiviteit;
            }

            /**
             * Gets the value of the administratieveEenheid property.
             * 
             * <p>
             * This accessor method returns a reference to the live list,
             * not a snapshot. Therefore any modification you make to the
             * returned list will be present inside the JAXB object.
             * This is why there is not a <CODE>set</CODE> method for the administratieveEenheid property.
             * 
             * <p>
             * For example, to add a new item, do as follows:
             * <pre>
             *    getAdministratieveEenheid().add(newItem);
             * </pre>
             * 
             * 
             * <p>
             * Objects of the following type(s) are allowed in the list
             * {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid }
             * 
             * 
             */
            public List<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid> getAdministratieveEenheid() {
                if (administratieveEenheid == null) {
                    administratieveEenheid = new ArrayList<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid>();
                }
                return this.administratieveEenheid;
            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType&gt;
             *   &lt;complexContent&gt;
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *       &lt;sequence&gt;
             *         &lt;element name="Loonheffingennr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLoonheffingennr" minOccurs="0"/&gt;
             *         &lt;element name="NaamAdminEenheid" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar200" minOccurs="0"/&gt;
             *         &lt;element name="DatBAdminEenheid" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *         &lt;element name="DatEAdminEenheid" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *         &lt;element name="SectorRisicogroep" maxOccurs="unbounded" minOccurs="0"&gt;
             *           &lt;complexType&gt;
             *             &lt;complexContent&gt;
             *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                 &lt;sequence&gt;
             *                   &lt;element name="CdRisicopremiegroep" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdCdRisicopremiegroep" minOccurs="0"/&gt;
             *                   &lt;element name="CdSectorOsv" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdCdSectorOsv" minOccurs="0"/&gt;
             *                   &lt;element name="DatB" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *                   &lt;element name="DatE" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *                 &lt;/sequence&gt;
             *               &lt;/restriction&gt;
             *             &lt;/complexContent&gt;
             *           &lt;/complexType&gt;
             *         &lt;/element&gt;
             *         &lt;element name="PremiepercIndividueel" maxOccurs="unbounded" minOccurs="0"&gt;
             *           &lt;complexType&gt;
             *             &lt;complexContent&gt;
             *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                 &lt;sequence&gt;
             *                   &lt;element name="Perc" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPercDec2" minOccurs="0"/&gt;
             *                   &lt;element name="CdSzProduct" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdSzProduct_nocodes" minOccurs="0"/&gt;
             *                   &lt;element name="DatBPrpercIndividueel" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *                   &lt;element name="DatEPrpercIndividueel" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *                 &lt;/sequence&gt;
             *               &lt;/restriction&gt;
             *             &lt;/complexContent&gt;
             *           &lt;/complexType&gt;
             *         &lt;/element&gt;
             *         &lt;element name="EigenRisicoDrager" maxOccurs="unbounded" minOccurs="0"&gt;
             *           &lt;complexType&gt;
             *             &lt;complexContent&gt;
             *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                 &lt;sequence&gt;
             *                   &lt;element name="CdSzProduct" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdSzProduct_nocodes" minOccurs="0"/&gt;
             *                   &lt;element name="DatBEigenrisicodrager" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *                   &lt;element name="DatEEigenrisicodrager" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *                 &lt;/sequence&gt;
             *               &lt;/restriction&gt;
             *             &lt;/complexContent&gt;
             *           &lt;/complexType&gt;
             *         &lt;/element&gt;
             *         &lt;element name="Adreshouding" maxOccurs="unbounded" minOccurs="0"&gt;
             *           &lt;complexType&gt;
             *             &lt;complexContent&gt;
             *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                 &lt;sequence&gt;
             *                   &lt;choice&gt;
             *                     &lt;element name="AdresNederlandWga"&gt;
             *                       &lt;complexType&gt;
             *                         &lt;complexContent&gt;
             *                           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                             &lt;sequence&gt;
             *                               &lt;element name="CdAdresrol" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAdresrol_nocodes" minOccurs="0"/&gt;
             *                               &lt;element name="DatBAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *                               &lt;element name="DatEAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *                               &lt;choice minOccurs="0"&gt;
             *                                 &lt;element name="StraatadresWga" minOccurs="0"&gt;
             *                                   &lt;complexType&gt;
             *                                     &lt;complexContent&gt;
             *                                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                                         &lt;sequence&gt;
             *                                           &lt;element name="Postcd" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcd" minOccurs="0"/&gt;
             *                                           &lt;element name="Woonplaatsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
             *                                           &lt;element name="Gemeentenaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdGemeentenaam" minOccurs="0"/&gt;
             *                                           &lt;element name="Straatnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdStraatnaam" minOccurs="0"/&gt;
             *                                           &lt;element name="Huisnr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisnr" minOccurs="0"/&gt;
             *                                           &lt;element name="Huisnrtoevoeging" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar4" minOccurs="0"/&gt;
             *                                           &lt;element name="Locatieoms" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar70" minOccurs="0"/&gt;
             *                                         &lt;/sequence&gt;
             *                                       &lt;/restriction&gt;
             *                                     &lt;/complexContent&gt;
             *                                   &lt;/complexType&gt;
             *                                 &lt;/element&gt;
             *                                 &lt;element name="PostbusadresWga" minOccurs="0"&gt;
             *                                   &lt;complexType&gt;
             *                                     &lt;complexContent&gt;
             *                                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                                         &lt;sequence&gt;
             *                                           &lt;element name="Postcd" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcd" minOccurs="0"/&gt;
             *                                           &lt;element name="Woonplaatsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
             *                                           &lt;element name="Postbusnr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostbusnr" minOccurs="0"/&gt;
             *                                         &lt;/sequence&gt;
             *                                       &lt;/restriction&gt;
             *                                     &lt;/complexContent&gt;
             *                                   &lt;/complexType&gt;
             *                                 &lt;/element&gt;
             *                               &lt;/choice&gt;
             *                             &lt;/sequence&gt;
             *                           &lt;/restriction&gt;
             *                         &lt;/complexContent&gt;
             *                       &lt;/complexType&gt;
             *                     &lt;/element&gt;
             *                     &lt;element name="AdresBuitenlandWga"&gt;
             *                       &lt;complexType&gt;
             *                         &lt;complexContent&gt;
             *                           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                             &lt;sequence&gt;
             *                               &lt;element name="CdAdresrol" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAdresrol_nocodes" minOccurs="0"/&gt;
             *                               &lt;element name="DatBAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *                               &lt;element name="DatEAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *                               &lt;choice minOccurs="0"&gt;
             *                                 &lt;element name="StraatadresBuitenlandWga" minOccurs="0"&gt;
             *                                   &lt;complexType&gt;
             *                                     &lt;complexContent&gt;
             *                                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                                         &lt;sequence&gt;
             *                                           &lt;element name="PostcdBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcdBuitenland" minOccurs="0"/&gt;
             *                                           &lt;element name="WoonplaatsnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
             *                                           &lt;element name="RegionaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar24" minOccurs="0"/&gt;
             *                                           &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
             *                                           &lt;element name="StraatnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdStraatnaam" minOccurs="0"/&gt;
             *                                           &lt;element name="HuisnrBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisnrBuitenland" minOccurs="0"/&gt;
             *                                           &lt;element name="LocatieomsBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar128" minOccurs="0"/&gt;
             *                                         &lt;/sequence&gt;
             *                                       &lt;/restriction&gt;
             *                                     &lt;/complexContent&gt;
             *                                   &lt;/complexType&gt;
             *                                 &lt;/element&gt;
             *                                 &lt;element name="PostbusadresBuitenlandWga" minOccurs="0"&gt;
             *                                   &lt;complexType&gt;
             *                                     &lt;complexContent&gt;
             *                                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                                         &lt;sequence&gt;
             *                                           &lt;element name="PostcdBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcdBuitenland" minOccurs="0"/&gt;
             *                                           &lt;element name="WoonplaatsnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
             *                                           &lt;element name="RegionaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar24" minOccurs="0"/&gt;
             *                                           &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
             *                                           &lt;element name="PostbusnrBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdReferentienrAnVar8" minOccurs="0"/&gt;
             *                                         &lt;/sequence&gt;
             *                                       &lt;/restriction&gt;
             *                                     &lt;/complexContent&gt;
             *                                   &lt;/complexType&gt;
             *                                 &lt;/element&gt;
             *                               &lt;/choice&gt;
             *                             &lt;/sequence&gt;
             *                           &lt;/restriction&gt;
             *                         &lt;/complexContent&gt;
             *                       &lt;/complexType&gt;
             *                     &lt;/element&gt;
             *                     &lt;element name="AdresBuitenlandOngestructureerdWga"&gt;
             *                       &lt;complexType&gt;
             *                         &lt;complexContent&gt;
             *                           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                             &lt;sequence&gt;
             *                               &lt;element name="CdAdresrol" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAdresrol_nocodes" minOccurs="0"/&gt;
             *                               &lt;element name="DatBAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *                               &lt;element name="DatEAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *                               &lt;element name="Adresregel1Buitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar35" minOccurs="0"/&gt;
             *                               &lt;element name="Adresregel2Buitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar35" minOccurs="0"/&gt;
             *                               &lt;element name="Adresregel3Buitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar35" minOccurs="0"/&gt;
             *                               &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
             *                             &lt;/sequence&gt;
             *                           &lt;/restriction&gt;
             *                         &lt;/complexContent&gt;
             *                       &lt;/complexType&gt;
             *                     &lt;/element&gt;
             *                   &lt;/choice&gt;
             *                 &lt;/sequence&gt;
             *               &lt;/restriction&gt;
             *             &lt;/complexContent&gt;
             *           &lt;/complexType&gt;
             *         &lt;/element&gt;
             *         &lt;element name="VoortzettingsrelatieOpvolger" maxOccurs="unbounded" minOccurs="0"&gt;
             *           &lt;complexType&gt;
             *             &lt;complexContent&gt;
             *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                 &lt;sequence&gt;
             *                   &lt;element name="DatBVoortzettingsrelatie" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *                   &lt;element name="PercLoonsomOvergegaanInOpvolger" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPercNietNegatiefDec2" minOccurs="0"/&gt;
             *                   &lt;element name="LoonheffingennrOpvolger" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLoonheffingennr" minOccurs="0"/&gt;
             *                 &lt;/sequence&gt;
             *               &lt;/restriction&gt;
             *             &lt;/complexContent&gt;
             *           &lt;/complexType&gt;
             *         &lt;/element&gt;
             *         &lt;element name="VoortzettingsrelatieVoorganger" maxOccurs="unbounded" minOccurs="0"&gt;
             *           &lt;complexType&gt;
             *             &lt;complexContent&gt;
             *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                 &lt;sequence&gt;
             *                   &lt;element name="DatBVoortzettingsrelatie" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *                   &lt;element name="PercLoonsomOvergegaanInOpvolger" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPercNietNegatiefDec2" minOccurs="0"/&gt;
             *                   &lt;element name="Loonheffingennr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLoonheffingennr" minOccurs="0"/&gt;
             *                 &lt;/sequence&gt;
             *               &lt;/restriction&gt;
             *             &lt;/complexContent&gt;
             *           &lt;/complexType&gt;
             *         &lt;/element&gt;
             *         &lt;element name="AangifteFrequentieAdminEenheid" maxOccurs="unbounded" minOccurs="0"&gt;
             *           &lt;complexType&gt;
             *             &lt;complexContent&gt;
             *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                 &lt;sequence&gt;
             *                   &lt;element name="DatBAangiftefreqAdminEenheid" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *                   &lt;element name="CdAangiftefrequentieAdminEenheid" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAangiftefreqAdminEenheid_nocodes" minOccurs="0"/&gt;
             *                   &lt;element name="DatEAangiftefreqAdminEenheid" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *                 &lt;/sequence&gt;
             *               &lt;/restriction&gt;
             *             &lt;/complexContent&gt;
             *           &lt;/complexType&gt;
             *         &lt;/element&gt;
             *         &lt;element name="AansluitingsnrBv" maxOccurs="unbounded" minOccurs="0"&gt;
             *           &lt;complexType&gt;
             *             &lt;complexContent&gt;
             *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                 &lt;sequence&gt;
             *                   &lt;element name="CdSectorOsv" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdCdSectorOsv" minOccurs="0"/&gt;
             *                   &lt;element name="CdRisicopremiegroep" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdCdRisicopremiegroep" minOccurs="0"/&gt;
             *                   &lt;element name="AansluitingsnrBV" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdAansluitingsnrBV" minOccurs="0"/&gt;
             *                   &lt;element name="DatBAansluitingsnrBv" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *                 &lt;/sequence&gt;
             *               &lt;/restriction&gt;
             *             &lt;/complexContent&gt;
             *           &lt;/complexType&gt;
             *         &lt;/element&gt;
             *       &lt;/sequence&gt;
             *     &lt;/restriction&gt;
             *   &lt;/complexContent&gt;
             * &lt;/complexType&gt;
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "loonheffingennr",
                "naamAdminEenheid",
                "datBAdminEenheid",
                "datEAdminEenheid",
                "sectorRisicogroep",
                "premiepercIndividueel",
                "eigenRisicoDrager",
                "adreshouding",
                "voortzettingsrelatieOpvolger",
                "voortzettingsrelatieVoorganger",
                "aangifteFrequentieAdminEenheid",
                "aansluitingsnrBv"
            })
            public static class AdministratieveEenheid {

                @XmlElement(name = "Loonheffingennr")
                @Size(min = 12, max = 12)
                protected String loonheffingennr;
                @XmlElement(name = "NaamAdminEenheid")
                @Size(max = 200)
                protected String naamAdminEenheid;
                @XmlElement(name = "DatBAdminEenheid")
                @Size(max = 8)
                protected String datBAdminEenheid;
                @XmlElement(name = "DatEAdminEenheid")
                @Size(max = 8)
                protected String datEAdminEenheid;
                @XmlElement(name = "SectorRisicogroep")
                @Valid
                protected List<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.SectorRisicogroep> sectorRisicogroep;
                @XmlElement(name = "PremiepercIndividueel")
                @Valid
                protected List<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.PremiepercIndividueel> premiepercIndividueel;
                @XmlElement(name = "EigenRisicoDrager")
                @Valid
                protected List<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.EigenRisicoDrager> eigenRisicoDrager;
                @XmlElement(name = "Adreshouding")
                @Valid
                protected List<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding> adreshouding;
                @XmlElement(name = "VoortzettingsrelatieOpvolger")
                @Valid
                protected List<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.VoortzettingsrelatieOpvolger> voortzettingsrelatieOpvolger;
                @XmlElement(name = "VoortzettingsrelatieVoorganger")
                @Valid
                protected List<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.VoortzettingsrelatieVoorganger> voortzettingsrelatieVoorganger;
                @XmlElement(name = "AangifteFrequentieAdminEenheid")
                @Valid
                protected List<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.AangifteFrequentieAdminEenheid> aangifteFrequentieAdminEenheid;
                @XmlElement(name = "AansluitingsnrBv")
                @Valid
                protected List<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.AansluitingsnrBv> aansluitingsnrBv;

                /**
                 * Gets the value of the loonheffingennr property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getLoonheffingennr() {
                    return loonheffingennr;
                }

                /**
                 * Sets the value of the loonheffingennr property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setLoonheffingennr(String value) {
                    this.loonheffingennr = value;
                }

                /**
                 * Gets the value of the naamAdminEenheid property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getNaamAdminEenheid() {
                    return naamAdminEenheid;
                }

                /**
                 * Sets the value of the naamAdminEenheid property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setNaamAdminEenheid(String value) {
                    this.naamAdminEenheid = value;
                }

                /**
                 * Gets the value of the datBAdminEenheid property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getDatBAdminEenheid() {
                    return datBAdminEenheid;
                }

                /**
                 * Sets the value of the datBAdminEenheid property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setDatBAdminEenheid(String value) {
                    this.datBAdminEenheid = value;
                }

                /**
                 * Gets the value of the datEAdminEenheid property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getDatEAdminEenheid() {
                    return datEAdminEenheid;
                }

                /**
                 * Sets the value of the datEAdminEenheid property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setDatEAdminEenheid(String value) {
                    this.datEAdminEenheid = value;
                }

                /**
                 * Gets the value of the sectorRisicogroep property.
                 * 
                 * <p>
                 * This accessor method returns a reference to the live list,
                 * not a snapshot. Therefore any modification you make to the
                 * returned list will be present inside the JAXB object.
                 * This is why there is not a <CODE>set</CODE> method for the sectorRisicogroep property.
                 * 
                 * <p>
                 * For example, to add a new item, do as follows:
                 * <pre>
                 *    getSectorRisicogroep().add(newItem);
                 * </pre>
                 * 
                 * 
                 * <p>
                 * Objects of the following type(s) are allowed in the list
                 * {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.SectorRisicogroep }
                 * 
                 * 
                 */
                public List<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.SectorRisicogroep> getSectorRisicogroep() {
                    if (sectorRisicogroep == null) {
                        sectorRisicogroep = new ArrayList<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.SectorRisicogroep>();
                    }
                    return this.sectorRisicogroep;
                }

                /**
                 * Gets the value of the premiepercIndividueel property.
                 * 
                 * <p>
                 * This accessor method returns a reference to the live list,
                 * not a snapshot. Therefore any modification you make to the
                 * returned list will be present inside the JAXB object.
                 * This is why there is not a <CODE>set</CODE> method for the premiepercIndividueel property.
                 * 
                 * <p>
                 * For example, to add a new item, do as follows:
                 * <pre>
                 *    getPremiepercIndividueel().add(newItem);
                 * </pre>
                 * 
                 * 
                 * <p>
                 * Objects of the following type(s) are allowed in the list
                 * {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.PremiepercIndividueel }
                 * 
                 * 
                 */
                public List<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.PremiepercIndividueel> getPremiepercIndividueel() {
                    if (premiepercIndividueel == null) {
                        premiepercIndividueel = new ArrayList<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.PremiepercIndividueel>();
                    }
                    return this.premiepercIndividueel;
                }

                /**
                 * Gets the value of the eigenRisicoDrager property.
                 * 
                 * <p>
                 * This accessor method returns a reference to the live list,
                 * not a snapshot. Therefore any modification you make to the
                 * returned list will be present inside the JAXB object.
                 * This is why there is not a <CODE>set</CODE> method for the eigenRisicoDrager property.
                 * 
                 * <p>
                 * For example, to add a new item, do as follows:
                 * <pre>
                 *    getEigenRisicoDrager().add(newItem);
                 * </pre>
                 * 
                 * 
                 * <p>
                 * Objects of the following type(s) are allowed in the list
                 * {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.EigenRisicoDrager }
                 * 
                 * 
                 */
                public List<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.EigenRisicoDrager> getEigenRisicoDrager() {
                    if (eigenRisicoDrager == null) {
                        eigenRisicoDrager = new ArrayList<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.EigenRisicoDrager>();
                    }
                    return this.eigenRisicoDrager;
                }

                /**
                 * Gets the value of the adreshouding property.
                 * 
                 * <p>
                 * This accessor method returns a reference to the live list,
                 * not a snapshot. Therefore any modification you make to the
                 * returned list will be present inside the JAXB object.
                 * This is why there is not a <CODE>set</CODE> method for the adreshouding property.
                 * 
                 * <p>
                 * For example, to add a new item, do as follows:
                 * <pre>
                 *    getAdreshouding().add(newItem);
                 * </pre>
                 * 
                 * 
                 * <p>
                 * Objects of the following type(s) are allowed in the list
                 * {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding }
                 * 
                 * 
                 */
                public List<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding> getAdreshouding() {
                    if (adreshouding == null) {
                        adreshouding = new ArrayList<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding>();
                    }
                    return this.adreshouding;
                }

                /**
                 * Gets the value of the voortzettingsrelatieOpvolger property.
                 * 
                 * <p>
                 * This accessor method returns a reference to the live list,
                 * not a snapshot. Therefore any modification you make to the
                 * returned list will be present inside the JAXB object.
                 * This is why there is not a <CODE>set</CODE> method for the voortzettingsrelatieOpvolger property.
                 * 
                 * <p>
                 * For example, to add a new item, do as follows:
                 * <pre>
                 *    getVoortzettingsrelatieOpvolger().add(newItem);
                 * </pre>
                 * 
                 * 
                 * <p>
                 * Objects of the following type(s) are allowed in the list
                 * {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.VoortzettingsrelatieOpvolger }
                 * 
                 * 
                 */
                public List<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.VoortzettingsrelatieOpvolger> getVoortzettingsrelatieOpvolger() {
                    if (voortzettingsrelatieOpvolger == null) {
                        voortzettingsrelatieOpvolger = new ArrayList<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.VoortzettingsrelatieOpvolger>();
                    }
                    return this.voortzettingsrelatieOpvolger;
                }

                /**
                 * Gets the value of the voortzettingsrelatieVoorganger property.
                 * 
                 * <p>
                 * This accessor method returns a reference to the live list,
                 * not a snapshot. Therefore any modification you make to the
                 * returned list will be present inside the JAXB object.
                 * This is why there is not a <CODE>set</CODE> method for the voortzettingsrelatieVoorganger property.
                 * 
                 * <p>
                 * For example, to add a new item, do as follows:
                 * <pre>
                 *    getVoortzettingsrelatieVoorganger().add(newItem);
                 * </pre>
                 * 
                 * 
                 * <p>
                 * Objects of the following type(s) are allowed in the list
                 * {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.VoortzettingsrelatieVoorganger }
                 * 
                 * 
                 */
                public List<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.VoortzettingsrelatieVoorganger> getVoortzettingsrelatieVoorganger() {
                    if (voortzettingsrelatieVoorganger == null) {
                        voortzettingsrelatieVoorganger = new ArrayList<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.VoortzettingsrelatieVoorganger>();
                    }
                    return this.voortzettingsrelatieVoorganger;
                }

                /**
                 * Gets the value of the aangifteFrequentieAdminEenheid property.
                 * 
                 * <p>
                 * This accessor method returns a reference to the live list,
                 * not a snapshot. Therefore any modification you make to the
                 * returned list will be present inside the JAXB object.
                 * This is why there is not a <CODE>set</CODE> method for the aangifteFrequentieAdminEenheid property.
                 * 
                 * <p>
                 * For example, to add a new item, do as follows:
                 * <pre>
                 *    getAangifteFrequentieAdminEenheid().add(newItem);
                 * </pre>
                 * 
                 * 
                 * <p>
                 * Objects of the following type(s) are allowed in the list
                 * {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.AangifteFrequentieAdminEenheid }
                 * 
                 * 
                 */
                public List<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.AangifteFrequentieAdminEenheid> getAangifteFrequentieAdminEenheid() {
                    if (aangifteFrequentieAdminEenheid == null) {
                        aangifteFrequentieAdminEenheid = new ArrayList<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.AangifteFrequentieAdminEenheid>();
                    }
                    return this.aangifteFrequentieAdminEenheid;
                }

                /**
                 * Gets the value of the aansluitingsnrBv property.
                 * 
                 * <p>
                 * This accessor method returns a reference to the live list,
                 * not a snapshot. Therefore any modification you make to the
                 * returned list will be present inside the JAXB object.
                 * This is why there is not a <CODE>set</CODE> method for the aansluitingsnrBv property.
                 * 
                 * <p>
                 * For example, to add a new item, do as follows:
                 * <pre>
                 *    getAansluitingsnrBv().add(newItem);
                 * </pre>
                 * 
                 * 
                 * <p>
                 * Objects of the following type(s) are allowed in the list
                 * {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.AansluitingsnrBv }
                 * 
                 * 
                 */
                public List<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.AansluitingsnrBv> getAansluitingsnrBv() {
                    if (aansluitingsnrBv == null) {
                        aansluitingsnrBv = new ArrayList<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.AansluitingsnrBv>();
                    }
                    return this.aansluitingsnrBv;
                }


                /**
                 * <p>Java class for anonymous complex type.
                 * 
                 * <p>The following schema fragment specifies the expected content contained within this class.
                 * 
                 * <pre>
                 * &lt;complexType&gt;
                 *   &lt;complexContent&gt;
                 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                 *       &lt;sequence&gt;
                 *         &lt;element name="DatBAangiftefreqAdminEenheid" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                 *         &lt;element name="CdAangiftefrequentieAdminEenheid" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAangiftefreqAdminEenheid_nocodes" minOccurs="0"/&gt;
                 *         &lt;element name="DatEAangiftefreqAdminEenheid" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                 *       &lt;/sequence&gt;
                 *     &lt;/restriction&gt;
                 *   &lt;/complexContent&gt;
                 * &lt;/complexType&gt;
                 * </pre>
                 * 
                 * 
                 */
                @XmlAccessorType(XmlAccessType.FIELD)
                @XmlType(name = "", propOrder = {
                    "datBAangiftefreqAdminEenheid",
                    "cdAangiftefrequentieAdminEenheid",
                    "datEAangiftefreqAdminEenheid"
                })
                public static class AangifteFrequentieAdminEenheid {

                    @XmlElement(name = "DatBAangiftefreqAdminEenheid")
                    @Size(max = 8)
                    protected String datBAangiftefreqAdminEenheid;
                    @XmlElement(name = "CdAangiftefrequentieAdminEenheid")
                    @Size(max = 2)
                    protected String cdAangiftefrequentieAdminEenheid;
                    @XmlElement(name = "DatEAangiftefreqAdminEenheid")
                    @Size(max = 8)
                    protected String datEAangiftefreqAdminEenheid;

                    /**
                     * Gets the value of the datBAangiftefreqAdminEenheid property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getDatBAangiftefreqAdminEenheid() {
                        return datBAangiftefreqAdminEenheid;
                    }

                    /**
                     * Sets the value of the datBAangiftefreqAdminEenheid property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setDatBAangiftefreqAdminEenheid(String value) {
                        this.datBAangiftefreqAdminEenheid = value;
                    }

                    /**
                     * Gets the value of the cdAangiftefrequentieAdminEenheid property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getCdAangiftefrequentieAdminEenheid() {
                        return cdAangiftefrequentieAdminEenheid;
                    }

                    /**
                     * Sets the value of the cdAangiftefrequentieAdminEenheid property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setCdAangiftefrequentieAdminEenheid(String value) {
                        this.cdAangiftefrequentieAdminEenheid = value;
                    }

                    /**
                     * Gets the value of the datEAangiftefreqAdminEenheid property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getDatEAangiftefreqAdminEenheid() {
                        return datEAangiftefreqAdminEenheid;
                    }

                    /**
                     * Sets the value of the datEAangiftefreqAdminEenheid property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setDatEAangiftefreqAdminEenheid(String value) {
                        this.datEAangiftefreqAdminEenheid = value;
                    }

                }


                /**
                 * <p>Java class for anonymous complex type.
                 * 
                 * <p>The following schema fragment specifies the expected content contained within this class.
                 * 
                 * <pre>
                 * &lt;complexType&gt;
                 *   &lt;complexContent&gt;
                 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                 *       &lt;sequence&gt;
                 *         &lt;element name="CdSectorOsv" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdCdSectorOsv" minOccurs="0"/&gt;
                 *         &lt;element name="CdRisicopremiegroep" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdCdRisicopremiegroep" minOccurs="0"/&gt;
                 *         &lt;element name="AansluitingsnrBV" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdAansluitingsnrBV" minOccurs="0"/&gt;
                 *         &lt;element name="DatBAansluitingsnrBv" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                 *       &lt;/sequence&gt;
                 *     &lt;/restriction&gt;
                 *   &lt;/complexContent&gt;
                 * &lt;/complexType&gt;
                 * </pre>
                 * 
                 * 
                 */
                @XmlAccessorType(XmlAccessType.FIELD)
                @XmlType(name = "", propOrder = {
                    "cdSectorOsv",
                    "cdRisicopremiegroep",
                    "aansluitingsnrBV",
                    "datBAansluitingsnrBv"
                })
                public static class AansluitingsnrBv {

                    @XmlElement(name = "CdSectorOsv")
                    @Size(min = 3, max = 3)
                    @Pattern(regexp = "[0-9]*")
                    protected String cdSectorOsv;
                    @XmlElement(name = "CdRisicopremiegroep")
                    @Size(min = 2, max = 2)
                    @Pattern(regexp = "[0-9]*")
                    protected String cdRisicopremiegroep;
                    @XmlElement(name = "AansluitingsnrBV")
                    @Size(min = 15, max = 15)
                    @Pattern(regexp = "0[0-9]{14}")
                    protected String aansluitingsnrBV;
                    @XmlElement(name = "DatBAansluitingsnrBv")
                    @Size(max = 8)
                    protected String datBAansluitingsnrBv;

                    /**
                     * Gets the value of the cdSectorOsv property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getCdSectorOsv() {
                        return cdSectorOsv;
                    }

                    /**
                     * Sets the value of the cdSectorOsv property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setCdSectorOsv(String value) {
                        this.cdSectorOsv = value;
                    }

                    /**
                     * Gets the value of the cdRisicopremiegroep property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getCdRisicopremiegroep() {
                        return cdRisicopremiegroep;
                    }

                    /**
                     * Sets the value of the cdRisicopremiegroep property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setCdRisicopremiegroep(String value) {
                        this.cdRisicopremiegroep = value;
                    }

                    /**
                     * Gets the value of the aansluitingsnrBV property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getAansluitingsnrBV() {
                        return aansluitingsnrBV;
                    }

                    /**
                     * Sets the value of the aansluitingsnrBV property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setAansluitingsnrBV(String value) {
                        this.aansluitingsnrBV = value;
                    }

                    /**
                     * Gets the value of the datBAansluitingsnrBv property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getDatBAansluitingsnrBv() {
                        return datBAansluitingsnrBv;
                    }

                    /**
                     * Sets the value of the datBAansluitingsnrBv property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setDatBAansluitingsnrBv(String value) {
                        this.datBAansluitingsnrBv = value;
                    }

                }


                /**
                 * <p>Java class for anonymous complex type.
                 * 
                 * <p>The following schema fragment specifies the expected content contained within this class.
                 * 
                 * <pre>
                 * &lt;complexType&gt;
                 *   &lt;complexContent&gt;
                 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                 *       &lt;sequence&gt;
                 *         &lt;choice&gt;
                 *           &lt;element name="AdresNederlandWga"&gt;
                 *             &lt;complexType&gt;
                 *               &lt;complexContent&gt;
                 *                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                 *                   &lt;sequence&gt;
                 *                     &lt;element name="CdAdresrol" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAdresrol_nocodes" minOccurs="0"/&gt;
                 *                     &lt;element name="DatBAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                 *                     &lt;element name="DatEAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                 *                     &lt;choice minOccurs="0"&gt;
                 *                       &lt;element name="StraatadresWga" minOccurs="0"&gt;
                 *                         &lt;complexType&gt;
                 *                           &lt;complexContent&gt;
                 *                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                 *                               &lt;sequence&gt;
                 *                                 &lt;element name="Postcd" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcd" minOccurs="0"/&gt;
                 *                                 &lt;element name="Woonplaatsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
                 *                                 &lt;element name="Gemeentenaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdGemeentenaam" minOccurs="0"/&gt;
                 *                                 &lt;element name="Straatnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdStraatnaam" minOccurs="0"/&gt;
                 *                                 &lt;element name="Huisnr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisnr" minOccurs="0"/&gt;
                 *                                 &lt;element name="Huisnrtoevoeging" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar4" minOccurs="0"/&gt;
                 *                                 &lt;element name="Locatieoms" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar70" minOccurs="0"/&gt;
                 *                               &lt;/sequence&gt;
                 *                             &lt;/restriction&gt;
                 *                           &lt;/complexContent&gt;
                 *                         &lt;/complexType&gt;
                 *                       &lt;/element&gt;
                 *                       &lt;element name="PostbusadresWga" minOccurs="0"&gt;
                 *                         &lt;complexType&gt;
                 *                           &lt;complexContent&gt;
                 *                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                 *                               &lt;sequence&gt;
                 *                                 &lt;element name="Postcd" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcd" minOccurs="0"/&gt;
                 *                                 &lt;element name="Woonplaatsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
                 *                                 &lt;element name="Postbusnr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostbusnr" minOccurs="0"/&gt;
                 *                               &lt;/sequence&gt;
                 *                             &lt;/restriction&gt;
                 *                           &lt;/complexContent&gt;
                 *                         &lt;/complexType&gt;
                 *                       &lt;/element&gt;
                 *                     &lt;/choice&gt;
                 *                   &lt;/sequence&gt;
                 *                 &lt;/restriction&gt;
                 *               &lt;/complexContent&gt;
                 *             &lt;/complexType&gt;
                 *           &lt;/element&gt;
                 *           &lt;element name="AdresBuitenlandWga"&gt;
                 *             &lt;complexType&gt;
                 *               &lt;complexContent&gt;
                 *                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                 *                   &lt;sequence&gt;
                 *                     &lt;element name="CdAdresrol" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAdresrol_nocodes" minOccurs="0"/&gt;
                 *                     &lt;element name="DatBAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                 *                     &lt;element name="DatEAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                 *                     &lt;choice minOccurs="0"&gt;
                 *                       &lt;element name="StraatadresBuitenlandWga" minOccurs="0"&gt;
                 *                         &lt;complexType&gt;
                 *                           &lt;complexContent&gt;
                 *                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                 *                               &lt;sequence&gt;
                 *                                 &lt;element name="PostcdBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcdBuitenland" minOccurs="0"/&gt;
                 *                                 &lt;element name="WoonplaatsnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
                 *                                 &lt;element name="RegionaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar24" minOccurs="0"/&gt;
                 *                                 &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
                 *                                 &lt;element name="StraatnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdStraatnaam" minOccurs="0"/&gt;
                 *                                 &lt;element name="HuisnrBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisnrBuitenland" minOccurs="0"/&gt;
                 *                                 &lt;element name="LocatieomsBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar128" minOccurs="0"/&gt;
                 *                               &lt;/sequence&gt;
                 *                             &lt;/restriction&gt;
                 *                           &lt;/complexContent&gt;
                 *                         &lt;/complexType&gt;
                 *                       &lt;/element&gt;
                 *                       &lt;element name="PostbusadresBuitenlandWga" minOccurs="0"&gt;
                 *                         &lt;complexType&gt;
                 *                           &lt;complexContent&gt;
                 *                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                 *                               &lt;sequence&gt;
                 *                                 &lt;element name="PostcdBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcdBuitenland" minOccurs="0"/&gt;
                 *                                 &lt;element name="WoonplaatsnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
                 *                                 &lt;element name="RegionaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar24" minOccurs="0"/&gt;
                 *                                 &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
                 *                                 &lt;element name="PostbusnrBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdReferentienrAnVar8" minOccurs="0"/&gt;
                 *                               &lt;/sequence&gt;
                 *                             &lt;/restriction&gt;
                 *                           &lt;/complexContent&gt;
                 *                         &lt;/complexType&gt;
                 *                       &lt;/element&gt;
                 *                     &lt;/choice&gt;
                 *                   &lt;/sequence&gt;
                 *                 &lt;/restriction&gt;
                 *               &lt;/complexContent&gt;
                 *             &lt;/complexType&gt;
                 *           &lt;/element&gt;
                 *           &lt;element name="AdresBuitenlandOngestructureerdWga"&gt;
                 *             &lt;complexType&gt;
                 *               &lt;complexContent&gt;
                 *                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                 *                   &lt;sequence&gt;
                 *                     &lt;element name="CdAdresrol" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAdresrol_nocodes" minOccurs="0"/&gt;
                 *                     &lt;element name="DatBAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                 *                     &lt;element name="DatEAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                 *                     &lt;element name="Adresregel1Buitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar35" minOccurs="0"/&gt;
                 *                     &lt;element name="Adresregel2Buitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar35" minOccurs="0"/&gt;
                 *                     &lt;element name="Adresregel3Buitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar35" minOccurs="0"/&gt;
                 *                     &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
                 *                   &lt;/sequence&gt;
                 *                 &lt;/restriction&gt;
                 *               &lt;/complexContent&gt;
                 *             &lt;/complexType&gt;
                 *           &lt;/element&gt;
                 *         &lt;/choice&gt;
                 *       &lt;/sequence&gt;
                 *     &lt;/restriction&gt;
                 *   &lt;/complexContent&gt;
                 * &lt;/complexType&gt;
                 * </pre>
                 * 
                 * 
                 */
                @XmlAccessorType(XmlAccessType.FIELD)
                @XmlType(name = "", propOrder = {
                    "adresNederlandWga",
                    "adresBuitenlandWga",
                    "adresBuitenlandOngestructureerdWga"
                })
                public static class Adreshouding {

                    @XmlElement(name = "AdresNederlandWga")
                    @Valid
                    protected CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresNederlandWga adresNederlandWga;
                    @XmlElement(name = "AdresBuitenlandWga")
                    @Valid
                    protected CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresBuitenlandWga adresBuitenlandWga;
                    @XmlElement(name = "AdresBuitenlandOngestructureerdWga")
                    @Valid
                    protected CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresBuitenlandOngestructureerdWga adresBuitenlandOngestructureerdWga;

                    /**
                     * Gets the value of the adresNederlandWga property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresNederlandWga }
                     *     
                     */
                    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresNederlandWga getAdresNederlandWga() {
                        return adresNederlandWga;
                    }

                    /**
                     * Sets the value of the adresNederlandWga property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresNederlandWga }
                     *     
                     */
                    public void setAdresNederlandWga(CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresNederlandWga value) {
                        this.adresNederlandWga = value;
                    }

                    /**
                     * Gets the value of the adresBuitenlandWga property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresBuitenlandWga }
                     *     
                     */
                    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresBuitenlandWga getAdresBuitenlandWga() {
                        return adresBuitenlandWga;
                    }

                    /**
                     * Sets the value of the adresBuitenlandWga property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresBuitenlandWga }
                     *     
                     */
                    public void setAdresBuitenlandWga(CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresBuitenlandWga value) {
                        this.adresBuitenlandWga = value;
                    }

                    /**
                     * Gets the value of the adresBuitenlandOngestructureerdWga property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresBuitenlandOngestructureerdWga }
                     *     
                     */
                    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresBuitenlandOngestructureerdWga getAdresBuitenlandOngestructureerdWga() {
                        return adresBuitenlandOngestructureerdWga;
                    }

                    /**
                     * Sets the value of the adresBuitenlandOngestructureerdWga property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresBuitenlandOngestructureerdWga }
                     *     
                     */
                    public void setAdresBuitenlandOngestructureerdWga(CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresBuitenlandOngestructureerdWga value) {
                        this.adresBuitenlandOngestructureerdWga = value;
                    }


                    /**
                     * <p>Java class for anonymous complex type.
                     * 
                     * <p>The following schema fragment specifies the expected content contained within this class.
                     * 
                     * <pre>
                     * &lt;complexType&gt;
                     *   &lt;complexContent&gt;
                     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                     *       &lt;sequence&gt;
                     *         &lt;element name="CdAdresrol" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAdresrol_nocodes" minOccurs="0"/&gt;
                     *         &lt;element name="DatBAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                     *         &lt;element name="DatEAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                     *         &lt;element name="Adresregel1Buitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar35" minOccurs="0"/&gt;
                     *         &lt;element name="Adresregel2Buitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar35" minOccurs="0"/&gt;
                     *         &lt;element name="Adresregel3Buitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar35" minOccurs="0"/&gt;
                     *         &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
                     *       &lt;/sequence&gt;
                     *     &lt;/restriction&gt;
                     *   &lt;/complexContent&gt;
                     * &lt;/complexType&gt;
                     * </pre>
                     * 
                     * 
                     */
                    @XmlAccessorType(XmlAccessType.FIELD)
                    @XmlType(name = "", propOrder = {
                        "cdAdresrol",
                        "datBAdreshouding",
                        "datEAdreshouding",
                        "adresregel1Buitenland",
                        "adresregel2Buitenland",
                        "adresregel3Buitenland",
                        "landcodeIso"
                    })
                    public static class AdresBuitenlandOngestructureerdWga {

                        @XmlElement(name = "CdAdresrol")
                        @Size(min = 1, max = 1)
                        @Pattern(regexp = "\\D*")
                        protected String cdAdresrol;
                        @XmlElement(name = "DatBAdreshouding")
                        @Size(max = 8)
                        protected String datBAdreshouding;
                        @XmlElement(name = "DatEAdreshouding")
                        @Size(max = 8)
                        protected String datEAdreshouding;
                        @XmlElement(name = "Adresregel1Buitenland")
                        @Size(max = 35)
                        protected String adresregel1Buitenland;
                        @XmlElement(name = "Adresregel2Buitenland")
                        @Size(max = 35)
                        protected String adresregel2Buitenland;
                        @XmlElement(name = "Adresregel3Buitenland")
                        @Size(max = 35)
                        protected String adresregel3Buitenland;
                        @XmlElement(name = "LandcodeIso")
                        @Size(min = 2, max = 2)
                        @Pattern(regexp = "[A-Z]*")
                        protected String landcodeIso;

                        /**
                         * Gets the value of the cdAdresrol property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getCdAdresrol() {
                            return cdAdresrol;
                        }

                        /**
                         * Sets the value of the cdAdresrol property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setCdAdresrol(String value) {
                            this.cdAdresrol = value;
                        }

                        /**
                         * Gets the value of the datBAdreshouding property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getDatBAdreshouding() {
                            return datBAdreshouding;
                        }

                        /**
                         * Sets the value of the datBAdreshouding property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setDatBAdreshouding(String value) {
                            this.datBAdreshouding = value;
                        }

                        /**
                         * Gets the value of the datEAdreshouding property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getDatEAdreshouding() {
                            return datEAdreshouding;
                        }

                        /**
                         * Sets the value of the datEAdreshouding property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setDatEAdreshouding(String value) {
                            this.datEAdreshouding = value;
                        }

                        /**
                         * Gets the value of the adresregel1Buitenland property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getAdresregel1Buitenland() {
                            return adresregel1Buitenland;
                        }

                        /**
                         * Sets the value of the adresregel1Buitenland property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setAdresregel1Buitenland(String value) {
                            this.adresregel1Buitenland = value;
                        }

                        /**
                         * Gets the value of the adresregel2Buitenland property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getAdresregel2Buitenland() {
                            return adresregel2Buitenland;
                        }

                        /**
                         * Sets the value of the adresregel2Buitenland property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setAdresregel2Buitenland(String value) {
                            this.adresregel2Buitenland = value;
                        }

                        /**
                         * Gets the value of the adresregel3Buitenland property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getAdresregel3Buitenland() {
                            return adresregel3Buitenland;
                        }

                        /**
                         * Sets the value of the adresregel3Buitenland property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setAdresregel3Buitenland(String value) {
                            this.adresregel3Buitenland = value;
                        }

                        /**
                         * Gets the value of the landcodeIso property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getLandcodeIso() {
                            return landcodeIso;
                        }

                        /**
                         * Sets the value of the landcodeIso property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setLandcodeIso(String value) {
                            this.landcodeIso = value;
                        }

                    }


                    /**
                     * <p>Java class for anonymous complex type.
                     * 
                     * <p>The following schema fragment specifies the expected content contained within this class.
                     * 
                     * <pre>
                     * &lt;complexType&gt;
                     *   &lt;complexContent&gt;
                     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                     *       &lt;sequence&gt;
                     *         &lt;element name="CdAdresrol" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAdresrol_nocodes" minOccurs="0"/&gt;
                     *         &lt;element name="DatBAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                     *         &lt;element name="DatEAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                     *         &lt;choice minOccurs="0"&gt;
                     *           &lt;element name="StraatadresBuitenlandWga" minOccurs="0"&gt;
                     *             &lt;complexType&gt;
                     *               &lt;complexContent&gt;
                     *                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                     *                   &lt;sequence&gt;
                     *                     &lt;element name="PostcdBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcdBuitenland" minOccurs="0"/&gt;
                     *                     &lt;element name="WoonplaatsnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
                     *                     &lt;element name="RegionaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar24" minOccurs="0"/&gt;
                     *                     &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
                     *                     &lt;element name="StraatnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdStraatnaam" minOccurs="0"/&gt;
                     *                     &lt;element name="HuisnrBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisnrBuitenland" minOccurs="0"/&gt;
                     *                     &lt;element name="LocatieomsBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar128" minOccurs="0"/&gt;
                     *                   &lt;/sequence&gt;
                     *                 &lt;/restriction&gt;
                     *               &lt;/complexContent&gt;
                     *             &lt;/complexType&gt;
                     *           &lt;/element&gt;
                     *           &lt;element name="PostbusadresBuitenlandWga" minOccurs="0"&gt;
                     *             &lt;complexType&gt;
                     *               &lt;complexContent&gt;
                     *                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                     *                   &lt;sequence&gt;
                     *                     &lt;element name="PostcdBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcdBuitenland" minOccurs="0"/&gt;
                     *                     &lt;element name="WoonplaatsnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
                     *                     &lt;element name="RegionaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar24" minOccurs="0"/&gt;
                     *                     &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
                     *                     &lt;element name="PostbusnrBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdReferentienrAnVar8" minOccurs="0"/&gt;
                     *                   &lt;/sequence&gt;
                     *                 &lt;/restriction&gt;
                     *               &lt;/complexContent&gt;
                     *             &lt;/complexType&gt;
                     *           &lt;/element&gt;
                     *         &lt;/choice&gt;
                     *       &lt;/sequence&gt;
                     *     &lt;/restriction&gt;
                     *   &lt;/complexContent&gt;
                     * &lt;/complexType&gt;
                     * </pre>
                     * 
                     * 
                     */
                    @XmlAccessorType(XmlAccessType.FIELD)
                    @XmlType(name = "", propOrder = {
                        "cdAdresrol",
                        "datBAdreshouding",
                        "datEAdreshouding",
                        "straatadresBuitenlandWga",
                        "postbusadresBuitenlandWga"
                    })
                    public static class AdresBuitenlandWga {

                        @XmlElement(name = "CdAdresrol")
                        @Size(min = 1, max = 1)
                        @Pattern(regexp = "\\D*")
                        protected String cdAdresrol;
                        @XmlElement(name = "DatBAdreshouding")
                        @Size(max = 8)
                        protected String datBAdreshouding;
                        @XmlElement(name = "DatEAdreshouding")
                        @Size(max = 8)
                        protected String datEAdreshouding;
                        @XmlElement(name = "StraatadresBuitenlandWga")
                        @Valid
                        protected CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresBuitenlandWga.StraatadresBuitenlandWga straatadresBuitenlandWga;
                        @XmlElement(name = "PostbusadresBuitenlandWga")
                        @Valid
                        protected CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresBuitenlandWga.PostbusadresBuitenlandWga postbusadresBuitenlandWga;

                        /**
                         * Gets the value of the cdAdresrol property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getCdAdresrol() {
                            return cdAdresrol;
                        }

                        /**
                         * Sets the value of the cdAdresrol property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setCdAdresrol(String value) {
                            this.cdAdresrol = value;
                        }

                        /**
                         * Gets the value of the datBAdreshouding property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getDatBAdreshouding() {
                            return datBAdreshouding;
                        }

                        /**
                         * Sets the value of the datBAdreshouding property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setDatBAdreshouding(String value) {
                            this.datBAdreshouding = value;
                        }

                        /**
                         * Gets the value of the datEAdreshouding property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getDatEAdreshouding() {
                            return datEAdreshouding;
                        }

                        /**
                         * Sets the value of the datEAdreshouding property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setDatEAdreshouding(String value) {
                            this.datEAdreshouding = value;
                        }

                        /**
                         * Gets the value of the straatadresBuitenlandWga property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresBuitenlandWga.StraatadresBuitenlandWga }
                         *     
                         */
                        public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresBuitenlandWga.StraatadresBuitenlandWga getStraatadresBuitenlandWga() {
                            return straatadresBuitenlandWga;
                        }

                        /**
                         * Sets the value of the straatadresBuitenlandWga property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresBuitenlandWga.StraatadresBuitenlandWga }
                         *     
                         */
                        public void setStraatadresBuitenlandWga(CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresBuitenlandWga.StraatadresBuitenlandWga value) {
                            this.straatadresBuitenlandWga = value;
                        }

                        /**
                         * Gets the value of the postbusadresBuitenlandWga property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresBuitenlandWga.PostbusadresBuitenlandWga }
                         *     
                         */
                        public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresBuitenlandWga.PostbusadresBuitenlandWga getPostbusadresBuitenlandWga() {
                            return postbusadresBuitenlandWga;
                        }

                        /**
                         * Sets the value of the postbusadresBuitenlandWga property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresBuitenlandWga.PostbusadresBuitenlandWga }
                         *     
                         */
                        public void setPostbusadresBuitenlandWga(CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresBuitenlandWga.PostbusadresBuitenlandWga value) {
                            this.postbusadresBuitenlandWga = value;
                        }


                        /**
                         * <p>Java class for anonymous complex type.
                         * 
                         * <p>The following schema fragment specifies the expected content contained within this class.
                         * 
                         * <pre>
                         * &lt;complexType&gt;
                         *   &lt;complexContent&gt;
                         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                         *       &lt;sequence&gt;
                         *         &lt;element name="PostcdBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcdBuitenland" minOccurs="0"/&gt;
                         *         &lt;element name="WoonplaatsnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
                         *         &lt;element name="RegionaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar24" minOccurs="0"/&gt;
                         *         &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
                         *         &lt;element name="PostbusnrBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdReferentienrAnVar8" minOccurs="0"/&gt;
                         *       &lt;/sequence&gt;
                         *     &lt;/restriction&gt;
                         *   &lt;/complexContent&gt;
                         * &lt;/complexType&gt;
                         * </pre>
                         * 
                         * 
                         */
                        @XmlAccessorType(XmlAccessType.FIELD)
                        @XmlType(name = "", propOrder = {
                            "postcdBuitenland",
                            "woonplaatsnaamBuitenland",
                            "regionaamBuitenland",
                            "landcodeIso",
                            "postbusnrBuitenland"
                        })
                        public static class PostbusadresBuitenlandWga {

                            @XmlElement(name = "PostcdBuitenland")
                            @Size(max = 9)
                            protected String postcdBuitenland;
                            @XmlElement(name = "WoonplaatsnaamBuitenland")
                            @Size(max = 80)
                            protected String woonplaatsnaamBuitenland;
                            @XmlElement(name = "RegionaamBuitenland")
                            @Size(max = 24)
                            protected String regionaamBuitenland;
                            @XmlElement(name = "LandcodeIso")
                            @Size(min = 2, max = 2)
                            @Pattern(regexp = "[A-Z]*")
                            protected String landcodeIso;
                            @XmlElement(name = "PostbusnrBuitenland")
                            @Size(max = 8)
                            protected String postbusnrBuitenland;

                            /**
                             * Gets the value of the postcdBuitenland property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getPostcdBuitenland() {
                                return postcdBuitenland;
                            }

                            /**
                             * Sets the value of the postcdBuitenland property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setPostcdBuitenland(String value) {
                                this.postcdBuitenland = value;
                            }

                            /**
                             * Gets the value of the woonplaatsnaamBuitenland property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getWoonplaatsnaamBuitenland() {
                                return woonplaatsnaamBuitenland;
                            }

                            /**
                             * Sets the value of the woonplaatsnaamBuitenland property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setWoonplaatsnaamBuitenland(String value) {
                                this.woonplaatsnaamBuitenland = value;
                            }

                            /**
                             * Gets the value of the regionaamBuitenland property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getRegionaamBuitenland() {
                                return regionaamBuitenland;
                            }

                            /**
                             * Sets the value of the regionaamBuitenland property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setRegionaamBuitenland(String value) {
                                this.regionaamBuitenland = value;
                            }

                            /**
                             * Gets the value of the landcodeIso property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getLandcodeIso() {
                                return landcodeIso;
                            }

                            /**
                             * Sets the value of the landcodeIso property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setLandcodeIso(String value) {
                                this.landcodeIso = value;
                            }

                            /**
                             * Gets the value of the postbusnrBuitenland property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getPostbusnrBuitenland() {
                                return postbusnrBuitenland;
                            }

                            /**
                             * Sets the value of the postbusnrBuitenland property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setPostbusnrBuitenland(String value) {
                                this.postbusnrBuitenland = value;
                            }

                        }


                        /**
                         * <p>Java class for anonymous complex type.
                         * 
                         * <p>The following schema fragment specifies the expected content contained within this class.
                         * 
                         * <pre>
                         * &lt;complexType&gt;
                         *   &lt;complexContent&gt;
                         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                         *       &lt;sequence&gt;
                         *         &lt;element name="PostcdBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcdBuitenland" minOccurs="0"/&gt;
                         *         &lt;element name="WoonplaatsnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
                         *         &lt;element name="RegionaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar24" minOccurs="0"/&gt;
                         *         &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
                         *         &lt;element name="StraatnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdStraatnaam" minOccurs="0"/&gt;
                         *         &lt;element name="HuisnrBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisnrBuitenland" minOccurs="0"/&gt;
                         *         &lt;element name="LocatieomsBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar128" minOccurs="0"/&gt;
                         *       &lt;/sequence&gt;
                         *     &lt;/restriction&gt;
                         *   &lt;/complexContent&gt;
                         * &lt;/complexType&gt;
                         * </pre>
                         * 
                         * 
                         */
                        @XmlAccessorType(XmlAccessType.FIELD)
                        @XmlType(name = "", propOrder = {
                            "postcdBuitenland",
                            "woonplaatsnaamBuitenland",
                            "regionaamBuitenland",
                            "landcodeIso",
                            "straatnaamBuitenland",
                            "huisnrBuitenland",
                            "locatieomsBuitenland"
                        })
                        public static class StraatadresBuitenlandWga {

                            @XmlElement(name = "PostcdBuitenland")
                            @Size(max = 9)
                            protected String postcdBuitenland;
                            @XmlElement(name = "WoonplaatsnaamBuitenland")
                            @Size(max = 80)
                            protected String woonplaatsnaamBuitenland;
                            @XmlElement(name = "RegionaamBuitenland")
                            @Size(max = 24)
                            protected String regionaamBuitenland;
                            @XmlElement(name = "LandcodeIso")
                            @Size(min = 2, max = 2)
                            @Pattern(regexp = "[A-Z]*")
                            protected String landcodeIso;
                            @XmlElement(name = "StraatnaamBuitenland")
                            @Size(max = 24)
                            protected String straatnaamBuitenland;
                            @XmlElement(name = "HuisnrBuitenland")
                            @Size(max = 9)
                            protected String huisnrBuitenland;
                            @XmlElement(name = "LocatieomsBuitenland")
                            @Size(max = 128)
                            protected String locatieomsBuitenland;

                            /**
                             * Gets the value of the postcdBuitenland property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getPostcdBuitenland() {
                                return postcdBuitenland;
                            }

                            /**
                             * Sets the value of the postcdBuitenland property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setPostcdBuitenland(String value) {
                                this.postcdBuitenland = value;
                            }

                            /**
                             * Gets the value of the woonplaatsnaamBuitenland property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getWoonplaatsnaamBuitenland() {
                                return woonplaatsnaamBuitenland;
                            }

                            /**
                             * Sets the value of the woonplaatsnaamBuitenland property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setWoonplaatsnaamBuitenland(String value) {
                                this.woonplaatsnaamBuitenland = value;
                            }

                            /**
                             * Gets the value of the regionaamBuitenland property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getRegionaamBuitenland() {
                                return regionaamBuitenland;
                            }

                            /**
                             * Sets the value of the regionaamBuitenland property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setRegionaamBuitenland(String value) {
                                this.regionaamBuitenland = value;
                            }

                            /**
                             * Gets the value of the landcodeIso property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getLandcodeIso() {
                                return landcodeIso;
                            }

                            /**
                             * Sets the value of the landcodeIso property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setLandcodeIso(String value) {
                                this.landcodeIso = value;
                            }

                            /**
                             * Gets the value of the straatnaamBuitenland property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getStraatnaamBuitenland() {
                                return straatnaamBuitenland;
                            }

                            /**
                             * Sets the value of the straatnaamBuitenland property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setStraatnaamBuitenland(String value) {
                                this.straatnaamBuitenland = value;
                            }

                            /**
                             * Gets the value of the huisnrBuitenland property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getHuisnrBuitenland() {
                                return huisnrBuitenland;
                            }

                            /**
                             * Sets the value of the huisnrBuitenland property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setHuisnrBuitenland(String value) {
                                this.huisnrBuitenland = value;
                            }

                            /**
                             * Gets the value of the locatieomsBuitenland property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getLocatieomsBuitenland() {
                                return locatieomsBuitenland;
                            }

                            /**
                             * Sets the value of the locatieomsBuitenland property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setLocatieomsBuitenland(String value) {
                                this.locatieomsBuitenland = value;
                            }

                        }

                    }


                    /**
                     * <p>Java class for anonymous complex type.
                     * 
                     * <p>The following schema fragment specifies the expected content contained within this class.
                     * 
                     * <pre>
                     * &lt;complexType&gt;
                     *   &lt;complexContent&gt;
                     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                     *       &lt;sequence&gt;
                     *         &lt;element name="CdAdresrol" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAdresrol_nocodes" minOccurs="0"/&gt;
                     *         &lt;element name="DatBAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                     *         &lt;element name="DatEAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                     *         &lt;choice minOccurs="0"&gt;
                     *           &lt;element name="StraatadresWga" minOccurs="0"&gt;
                     *             &lt;complexType&gt;
                     *               &lt;complexContent&gt;
                     *                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                     *                   &lt;sequence&gt;
                     *                     &lt;element name="Postcd" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcd" minOccurs="0"/&gt;
                     *                     &lt;element name="Woonplaatsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
                     *                     &lt;element name="Gemeentenaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdGemeentenaam" minOccurs="0"/&gt;
                     *                     &lt;element name="Straatnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdStraatnaam" minOccurs="0"/&gt;
                     *                     &lt;element name="Huisnr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisnr" minOccurs="0"/&gt;
                     *                     &lt;element name="Huisnrtoevoeging" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar4" minOccurs="0"/&gt;
                     *                     &lt;element name="Locatieoms" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar70" minOccurs="0"/&gt;
                     *                   &lt;/sequence&gt;
                     *                 &lt;/restriction&gt;
                     *               &lt;/complexContent&gt;
                     *             &lt;/complexType&gt;
                     *           &lt;/element&gt;
                     *           &lt;element name="PostbusadresWga" minOccurs="0"&gt;
                     *             &lt;complexType&gt;
                     *               &lt;complexContent&gt;
                     *                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                     *                   &lt;sequence&gt;
                     *                     &lt;element name="Postcd" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcd" minOccurs="0"/&gt;
                     *                     &lt;element name="Woonplaatsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
                     *                     &lt;element name="Postbusnr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostbusnr" minOccurs="0"/&gt;
                     *                   &lt;/sequence&gt;
                     *                 &lt;/restriction&gt;
                     *               &lt;/complexContent&gt;
                     *             &lt;/complexType&gt;
                     *           &lt;/element&gt;
                     *         &lt;/choice&gt;
                     *       &lt;/sequence&gt;
                     *     &lt;/restriction&gt;
                     *   &lt;/complexContent&gt;
                     * &lt;/complexType&gt;
                     * </pre>
                     * 
                     * 
                     */
                    @XmlAccessorType(XmlAccessType.FIELD)
                    @XmlType(name = "", propOrder = {
                        "cdAdresrol",
                        "datBAdreshouding",
                        "datEAdreshouding",
                        "straatadresWga",
                        "postbusadresWga"
                    })
                    public static class AdresNederlandWga {

                        @XmlElement(name = "CdAdresrol")
                        @Size(min = 1, max = 1)
                        @Pattern(regexp = "\\D*")
                        protected String cdAdresrol;
                        @XmlElement(name = "DatBAdreshouding")
                        @Size(max = 8)
                        protected String datBAdreshouding;
                        @XmlElement(name = "DatEAdreshouding")
                        @Size(max = 8)
                        protected String datEAdreshouding;
                        @XmlElement(name = "StraatadresWga")
                        @Valid
                        protected CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresNederlandWga.StraatadresWga straatadresWga;
                        @XmlElement(name = "PostbusadresWga")
                        @Valid
                        protected CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresNederlandWga.PostbusadresWga postbusadresWga;

                        /**
                         * Gets the value of the cdAdresrol property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getCdAdresrol() {
                            return cdAdresrol;
                        }

                        /**
                         * Sets the value of the cdAdresrol property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setCdAdresrol(String value) {
                            this.cdAdresrol = value;
                        }

                        /**
                         * Gets the value of the datBAdreshouding property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getDatBAdreshouding() {
                            return datBAdreshouding;
                        }

                        /**
                         * Sets the value of the datBAdreshouding property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setDatBAdreshouding(String value) {
                            this.datBAdreshouding = value;
                        }

                        /**
                         * Gets the value of the datEAdreshouding property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getDatEAdreshouding() {
                            return datEAdreshouding;
                        }

                        /**
                         * Sets the value of the datEAdreshouding property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setDatEAdreshouding(String value) {
                            this.datEAdreshouding = value;
                        }

                        /**
                         * Gets the value of the straatadresWga property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresNederlandWga.StraatadresWga }
                         *     
                         */
                        public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresNederlandWga.StraatadresWga getStraatadresWga() {
                            return straatadresWga;
                        }

                        /**
                         * Sets the value of the straatadresWga property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresNederlandWga.StraatadresWga }
                         *     
                         */
                        public void setStraatadresWga(CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresNederlandWga.StraatadresWga value) {
                            this.straatadresWga = value;
                        }

                        /**
                         * Gets the value of the postbusadresWga property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresNederlandWga.PostbusadresWga }
                         *     
                         */
                        public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresNederlandWga.PostbusadresWga getPostbusadresWga() {
                            return postbusadresWga;
                        }

                        /**
                         * Sets the value of the postbusadresWga property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresNederlandWga.PostbusadresWga }
                         *     
                         */
                        public void setPostbusadresWga(CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresNederlandWga.PostbusadresWga value) {
                            this.postbusadresWga = value;
                        }


                        /**
                         * <p>Java class for anonymous complex type.
                         * 
                         * <p>The following schema fragment specifies the expected content contained within this class.
                         * 
                         * <pre>
                         * &lt;complexType&gt;
                         *   &lt;complexContent&gt;
                         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                         *       &lt;sequence&gt;
                         *         &lt;element name="Postcd" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcd" minOccurs="0"/&gt;
                         *         &lt;element name="Woonplaatsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
                         *         &lt;element name="Postbusnr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostbusnr" minOccurs="0"/&gt;
                         *       &lt;/sequence&gt;
                         *     &lt;/restriction&gt;
                         *   &lt;/complexContent&gt;
                         * &lt;/complexType&gt;
                         * </pre>
                         * 
                         * 
                         */
                        @XmlAccessorType(XmlAccessType.FIELD)
                        @XmlType(name = "", propOrder = {
                            "postcd",
                            "woonplaatsnaam",
                            "postbusnr"
                        })
                        public static class PostbusadresWga {

                            @XmlElement(name = "Postcd")
                            @Size(min = 6, max = 6)
                            @Pattern(regexp = "[1-9][0-9]{3}[A-Z]{2}")
                            protected String postcd;
                            @XmlElement(name = "Woonplaatsnaam")
                            @Size(max = 80)
                            protected String woonplaatsnaam;
                            @XmlElement(name = "Postbusnr")
                            @XmlSchemaType(name = "nonNegativeInteger")
                            @DecimalMin("1")
                            @Digits(integer = 5, fraction = 0)
                            protected BigInteger postbusnr;

                            /**
                             * Gets the value of the postcd property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getPostcd() {
                                return postcd;
                            }

                            /**
                             * Sets the value of the postcd property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setPostcd(String value) {
                                this.postcd = value;
                            }

                            /**
                             * Gets the value of the woonplaatsnaam property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getWoonplaatsnaam() {
                                return woonplaatsnaam;
                            }

                            /**
                             * Sets the value of the woonplaatsnaam property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setWoonplaatsnaam(String value) {
                                this.woonplaatsnaam = value;
                            }

                            /**
                             * Gets the value of the postbusnr property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link BigInteger }
                             *     
                             */
                            public BigInteger getPostbusnr() {
                                return postbusnr;
                            }

                            /**
                             * Sets the value of the postbusnr property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link BigInteger }
                             *     
                             */
                            public void setPostbusnr(BigInteger value) {
                                this.postbusnr = value;
                            }

                        }


                        /**
                         * <p>Java class for anonymous complex type.
                         * 
                         * <p>The following schema fragment specifies the expected content contained within this class.
                         * 
                         * <pre>
                         * &lt;complexType&gt;
                         *   &lt;complexContent&gt;
                         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                         *       &lt;sequence&gt;
                         *         &lt;element name="Postcd" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcd" minOccurs="0"/&gt;
                         *         &lt;element name="Woonplaatsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
                         *         &lt;element name="Gemeentenaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdGemeentenaam" minOccurs="0"/&gt;
                         *         &lt;element name="Straatnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdStraatnaam" minOccurs="0"/&gt;
                         *         &lt;element name="Huisnr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisnr" minOccurs="0"/&gt;
                         *         &lt;element name="Huisnrtoevoeging" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar4" minOccurs="0"/&gt;
                         *         &lt;element name="Locatieoms" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar70" minOccurs="0"/&gt;
                         *       &lt;/sequence&gt;
                         *     &lt;/restriction&gt;
                         *   &lt;/complexContent&gt;
                         * &lt;/complexType&gt;
                         * </pre>
                         * 
                         * 
                         */
                        @XmlAccessorType(XmlAccessType.FIELD)
                        @XmlType(name = "", propOrder = {
                            "postcd",
                            "woonplaatsnaam",
                            "gemeentenaam",
                            "straatnaam",
                            "huisnr",
                            "huisnrtoevoeging",
                            "locatieoms"
                        })
                        public static class StraatadresWga {

                            @XmlElement(name = "Postcd")
                            @Size(min = 6, max = 6)
                            @Pattern(regexp = "[1-9][0-9]{3}[A-Z]{2}")
                            protected String postcd;
                            @XmlElement(name = "Woonplaatsnaam")
                            @Size(max = 80)
                            protected String woonplaatsnaam;
                            @XmlElement(name = "Gemeentenaam")
                            @Size(max = 40)
                            protected String gemeentenaam;
                            @XmlElement(name = "Straatnaam")
                            @Size(max = 24)
                            protected String straatnaam;
                            @XmlElement(name = "Huisnr")
                            @XmlSchemaType(name = "nonNegativeInteger")
                            @DecimalMin("1")
                            @Digits(integer = 5, fraction = 0)
                            protected BigInteger huisnr;
                            @XmlElement(name = "Huisnrtoevoeging")
                            @Size(max = 4)
                            protected String huisnrtoevoeging;
                            @XmlElement(name = "Locatieoms")
                            @Size(max = 70)
                            protected String locatieoms;

                            /**
                             * Gets the value of the postcd property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getPostcd() {
                                return postcd;
                            }

                            /**
                             * Sets the value of the postcd property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setPostcd(String value) {
                                this.postcd = value;
                            }

                            /**
                             * Gets the value of the woonplaatsnaam property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getWoonplaatsnaam() {
                                return woonplaatsnaam;
                            }

                            /**
                             * Sets the value of the woonplaatsnaam property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setWoonplaatsnaam(String value) {
                                this.woonplaatsnaam = value;
                            }

                            /**
                             * Gets the value of the gemeentenaam property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getGemeentenaam() {
                                return gemeentenaam;
                            }

                            /**
                             * Sets the value of the gemeentenaam property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setGemeentenaam(String value) {
                                this.gemeentenaam = value;
                            }

                            /**
                             * Gets the value of the straatnaam property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getStraatnaam() {
                                return straatnaam;
                            }

                            /**
                             * Sets the value of the straatnaam property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setStraatnaam(String value) {
                                this.straatnaam = value;
                            }

                            /**
                             * Gets the value of the huisnr property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link BigInteger }
                             *     
                             */
                            public BigInteger getHuisnr() {
                                return huisnr;
                            }

                            /**
                             * Sets the value of the huisnr property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link BigInteger }
                             *     
                             */
                            public void setHuisnr(BigInteger value) {
                                this.huisnr = value;
                            }

                            /**
                             * Gets the value of the huisnrtoevoeging property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getHuisnrtoevoeging() {
                                return huisnrtoevoeging;
                            }

                            /**
                             * Sets the value of the huisnrtoevoeging property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setHuisnrtoevoeging(String value) {
                                this.huisnrtoevoeging = value;
                            }

                            /**
                             * Gets the value of the locatieoms property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getLocatieoms() {
                                return locatieoms;
                            }

                            /**
                             * Sets the value of the locatieoms property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setLocatieoms(String value) {
                                this.locatieoms = value;
                            }

                        }

                    }

                }


                /**
                 * <p>Java class for anonymous complex type.
                 * 
                 * <p>The following schema fragment specifies the expected content contained within this class.
                 * 
                 * <pre>
                 * &lt;complexType&gt;
                 *   &lt;complexContent&gt;
                 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                 *       &lt;sequence&gt;
                 *         &lt;element name="CdSzProduct" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdSzProduct_nocodes" minOccurs="0"/&gt;
                 *         &lt;element name="DatBEigenrisicodrager" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                 *         &lt;element name="DatEEigenrisicodrager" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                 *       &lt;/sequence&gt;
                 *     &lt;/restriction&gt;
                 *   &lt;/complexContent&gt;
                 * &lt;/complexType&gt;
                 * </pre>
                 * 
                 * 
                 */
                @XmlAccessorType(XmlAccessType.FIELD)
                @XmlType(name = "", propOrder = {
                    "cdSzProduct",
                    "datBEigenrisicodrager",
                    "datEEigenrisicodrager"
                })
                public static class EigenRisicoDrager {

                    @XmlElement(name = "CdSzProduct")
                    @Size(max = 5)
                    @Pattern(regexp = "[A-Z]*")
                    protected String cdSzProduct;
                    @XmlElement(name = "DatBEigenrisicodrager")
                    @Size(max = 8)
                    protected String datBEigenrisicodrager;
                    @XmlElement(name = "DatEEigenrisicodrager")
                    @Size(max = 8)
                    protected String datEEigenrisicodrager;

                    /**
                     * Gets the value of the cdSzProduct property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getCdSzProduct() {
                        return cdSzProduct;
                    }

                    /**
                     * Sets the value of the cdSzProduct property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setCdSzProduct(String value) {
                        this.cdSzProduct = value;
                    }

                    /**
                     * Gets the value of the datBEigenrisicodrager property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getDatBEigenrisicodrager() {
                        return datBEigenrisicodrager;
                    }

                    /**
                     * Sets the value of the datBEigenrisicodrager property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setDatBEigenrisicodrager(String value) {
                        this.datBEigenrisicodrager = value;
                    }

                    /**
                     * Gets the value of the datEEigenrisicodrager property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getDatEEigenrisicodrager() {
                        return datEEigenrisicodrager;
                    }

                    /**
                     * Sets the value of the datEEigenrisicodrager property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setDatEEigenrisicodrager(String value) {
                        this.datEEigenrisicodrager = value;
                    }

                }


                /**
                 * <p>Java class for anonymous complex type.
                 * 
                 * <p>The following schema fragment specifies the expected content contained within this class.
                 * 
                 * <pre>
                 * &lt;complexType&gt;
                 *   &lt;complexContent&gt;
                 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                 *       &lt;sequence&gt;
                 *         &lt;element name="Perc" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPercDec2" minOccurs="0"/&gt;
                 *         &lt;element name="CdSzProduct" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdSzProduct_nocodes" minOccurs="0"/&gt;
                 *         &lt;element name="DatBPrpercIndividueel" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                 *         &lt;element name="DatEPrpercIndividueel" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                 *       &lt;/sequence&gt;
                 *     &lt;/restriction&gt;
                 *   &lt;/complexContent&gt;
                 * &lt;/complexType&gt;
                 * </pre>
                 * 
                 * 
                 */
                @XmlAccessorType(XmlAccessType.FIELD)
                @XmlType(name = "", propOrder = {
                    "perc",
                    "cdSzProduct",
                    "datBPrpercIndividueel",
                    "datEPrpercIndividueel"
                })
                public static class PremiepercIndividueel {

                    @XmlElement(name = "Perc")
                    @Digits(integer = 5, fraction = 2)
                    protected BigDecimal perc;
                    @XmlElement(name = "CdSzProduct")
                    @Size(max = 5)
                    @Pattern(regexp = "[A-Z]*")
                    protected String cdSzProduct;
                    @XmlElement(name = "DatBPrpercIndividueel")
                    @Size(max = 8)
                    protected String datBPrpercIndividueel;
                    @XmlElement(name = "DatEPrpercIndividueel")
                    @Size(max = 8)
                    protected String datEPrpercIndividueel;

                    /**
                     * Gets the value of the perc property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link BigDecimal }
                     *     
                     */
                    public BigDecimal getPerc() {
                        return perc;
                    }

                    /**
                     * Sets the value of the perc property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link BigDecimal }
                     *     
                     */
                    public void setPerc(BigDecimal value) {
                        this.perc = value;
                    }

                    /**
                     * Gets the value of the cdSzProduct property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getCdSzProduct() {
                        return cdSzProduct;
                    }

                    /**
                     * Sets the value of the cdSzProduct property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setCdSzProduct(String value) {
                        this.cdSzProduct = value;
                    }

                    /**
                     * Gets the value of the datBPrpercIndividueel property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getDatBPrpercIndividueel() {
                        return datBPrpercIndividueel;
                    }

                    /**
                     * Sets the value of the datBPrpercIndividueel property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setDatBPrpercIndividueel(String value) {
                        this.datBPrpercIndividueel = value;
                    }

                    /**
                     * Gets the value of the datEPrpercIndividueel property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getDatEPrpercIndividueel() {
                        return datEPrpercIndividueel;
                    }

                    /**
                     * Sets the value of the datEPrpercIndividueel property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setDatEPrpercIndividueel(String value) {
                        this.datEPrpercIndividueel = value;
                    }

                }


                /**
                 * <p>Java class for anonymous complex type.
                 * 
                 * <p>The following schema fragment specifies the expected content contained within this class.
                 * 
                 * <pre>
                 * &lt;complexType&gt;
                 *   &lt;complexContent&gt;
                 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                 *       &lt;sequence&gt;
                 *         &lt;element name="CdRisicopremiegroep" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdCdRisicopremiegroep" minOccurs="0"/&gt;
                 *         &lt;element name="CdSectorOsv" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdCdSectorOsv" minOccurs="0"/&gt;
                 *         &lt;element name="DatB" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                 *         &lt;element name="DatE" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                 *       &lt;/sequence&gt;
                 *     &lt;/restriction&gt;
                 *   &lt;/complexContent&gt;
                 * &lt;/complexType&gt;
                 * </pre>
                 * 
                 * 
                 */
                @XmlAccessorType(XmlAccessType.FIELD)
                @XmlType(name = "", propOrder = {
                    "cdRisicopremiegroep",
                    "cdSectorOsv",
                    "datB",
                    "datE"
                })
                public static class SectorRisicogroep {

                    @XmlElement(name = "CdRisicopremiegroep")
                    @Size(min = 2, max = 2)
                    @Pattern(regexp = "[0-9]*")
                    protected String cdRisicopremiegroep;
                    @XmlElement(name = "CdSectorOsv")
                    @Size(min = 3, max = 3)
                    @Pattern(regexp = "[0-9]*")
                    protected String cdSectorOsv;
                    @XmlElement(name = "DatB")
                    @Size(max = 8)
                    protected String datB;
                    @XmlElement(name = "DatE")
                    @Size(max = 8)
                    protected String datE;

                    /**
                     * Gets the value of the cdRisicopremiegroep property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getCdRisicopremiegroep() {
                        return cdRisicopremiegroep;
                    }

                    /**
                     * Sets the value of the cdRisicopremiegroep property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setCdRisicopremiegroep(String value) {
                        this.cdRisicopremiegroep = value;
                    }

                    /**
                     * Gets the value of the cdSectorOsv property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getCdSectorOsv() {
                        return cdSectorOsv;
                    }

                    /**
                     * Sets the value of the cdSectorOsv property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setCdSectorOsv(String value) {
                        this.cdSectorOsv = value;
                    }

                    /**
                     * Gets the value of the datB property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getDatB() {
                        return datB;
                    }

                    /**
                     * Sets the value of the datB property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setDatB(String value) {
                        this.datB = value;
                    }

                    /**
                     * Gets the value of the datE property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getDatE() {
                        return datE;
                    }

                    /**
                     * Sets the value of the datE property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setDatE(String value) {
                        this.datE = value;
                    }

                }


                /**
                 * <p>Java class for anonymous complex type.
                 * 
                 * <p>The following schema fragment specifies the expected content contained within this class.
                 * 
                 * <pre>
                 * &lt;complexType&gt;
                 *   &lt;complexContent&gt;
                 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                 *       &lt;sequence&gt;
                 *         &lt;element name="DatBVoortzettingsrelatie" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                 *         &lt;element name="PercLoonsomOvergegaanInOpvolger" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPercNietNegatiefDec2" minOccurs="0"/&gt;
                 *         &lt;element name="LoonheffingennrOpvolger" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLoonheffingennr" minOccurs="0"/&gt;
                 *       &lt;/sequence&gt;
                 *     &lt;/restriction&gt;
                 *   &lt;/complexContent&gt;
                 * &lt;/complexType&gt;
                 * </pre>
                 * 
                 * 
                 */
                @XmlAccessorType(XmlAccessType.FIELD)
                @XmlType(name = "", propOrder = {
                    "datBVoortzettingsrelatie",
                    "percLoonsomOvergegaanInOpvolger",
                    "loonheffingennrOpvolger"
                })
                public static class VoortzettingsrelatieOpvolger {

                    @XmlElement(name = "DatBVoortzettingsrelatie")
                    @Size(max = 8)
                    protected String datBVoortzettingsrelatie;
                    @XmlElement(name = "PercLoonsomOvergegaanInOpvolger")
                    @DecimalMin("0.00")
                    @Digits(integer = 5, fraction = 2)
                    protected BigDecimal percLoonsomOvergegaanInOpvolger;
                    @XmlElement(name = "LoonheffingennrOpvolger")
                    @Size(min = 12, max = 12)
                    protected String loonheffingennrOpvolger;

                    /**
                     * Gets the value of the datBVoortzettingsrelatie property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getDatBVoortzettingsrelatie() {
                        return datBVoortzettingsrelatie;
                    }

                    /**
                     * Sets the value of the datBVoortzettingsrelatie property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setDatBVoortzettingsrelatie(String value) {
                        this.datBVoortzettingsrelatie = value;
                    }

                    /**
                     * Gets the value of the percLoonsomOvergegaanInOpvolger property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link BigDecimal }
                     *     
                     */
                    public BigDecimal getPercLoonsomOvergegaanInOpvolger() {
                        return percLoonsomOvergegaanInOpvolger;
                    }

                    /**
                     * Sets the value of the percLoonsomOvergegaanInOpvolger property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link BigDecimal }
                     *     
                     */
                    public void setPercLoonsomOvergegaanInOpvolger(BigDecimal value) {
                        this.percLoonsomOvergegaanInOpvolger = value;
                    }

                    /**
                     * Gets the value of the loonheffingennrOpvolger property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getLoonheffingennrOpvolger() {
                        return loonheffingennrOpvolger;
                    }

                    /**
                     * Sets the value of the loonheffingennrOpvolger property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setLoonheffingennrOpvolger(String value) {
                        this.loonheffingennrOpvolger = value;
                    }

                }


                /**
                 * <p>Java class for anonymous complex type.
                 * 
                 * <p>The following schema fragment specifies the expected content contained within this class.
                 * 
                 * <pre>
                 * &lt;complexType&gt;
                 *   &lt;complexContent&gt;
                 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                 *       &lt;sequence&gt;
                 *         &lt;element name="DatBVoortzettingsrelatie" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                 *         &lt;element name="PercLoonsomOvergegaanInOpvolger" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPercNietNegatiefDec2" minOccurs="0"/&gt;
                 *         &lt;element name="Loonheffingennr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLoonheffingennr" minOccurs="0"/&gt;
                 *       &lt;/sequence&gt;
                 *     &lt;/restriction&gt;
                 *   &lt;/complexContent&gt;
                 * &lt;/complexType&gt;
                 * </pre>
                 * 
                 * 
                 */
                @XmlAccessorType(XmlAccessType.FIELD)
                @XmlType(name = "", propOrder = {
                    "datBVoortzettingsrelatie",
                    "percLoonsomOvergegaanInOpvolger",
                    "loonheffingennr"
                })
                public static class VoortzettingsrelatieVoorganger {

                    @XmlElement(name = "DatBVoortzettingsrelatie")
                    @Size(max = 8)
                    protected String datBVoortzettingsrelatie;
                    @XmlElement(name = "PercLoonsomOvergegaanInOpvolger")
                    @DecimalMin("0.00")
                    @Digits(integer = 5, fraction = 2)
                    protected BigDecimal percLoonsomOvergegaanInOpvolger;
                    @XmlElement(name = "Loonheffingennr")
                    @Size(min = 12, max = 12)
                    protected String loonheffingennr;

                    /**
                     * Gets the value of the datBVoortzettingsrelatie property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getDatBVoortzettingsrelatie() {
                        return datBVoortzettingsrelatie;
                    }

                    /**
                     * Sets the value of the datBVoortzettingsrelatie property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setDatBVoortzettingsrelatie(String value) {
                        this.datBVoortzettingsrelatie = value;
                    }

                    /**
                     * Gets the value of the percLoonsomOvergegaanInOpvolger property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link BigDecimal }
                     *     
                     */
                    public BigDecimal getPercLoonsomOvergegaanInOpvolger() {
                        return percLoonsomOvergegaanInOpvolger;
                    }

                    /**
                     * Sets the value of the percLoonsomOvergegaanInOpvolger property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link BigDecimal }
                     *     
                     */
                    public void setPercLoonsomOvergegaanInOpvolger(BigDecimal value) {
                        this.percLoonsomOvergegaanInOpvolger = value;
                    }

                    /**
                     * Gets the value of the loonheffingennr property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getLoonheffingennr() {
                        return loonheffingennr;
                    }

                    /**
                     * Sets the value of the loonheffingennr property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setLoonheffingennr(String value) {
                        this.loonheffingennr = value;
                    }

                }

            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType&gt;
             *   &lt;complexContent&gt;
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *       &lt;sequence&gt;
             *         &lt;choice&gt;
             *           &lt;element name="AdresNederlandUhr"&gt;
             *             &lt;complexType&gt;
             *               &lt;complexContent&gt;
             *                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                   &lt;sequence&gt;
             *                     &lt;element name="CdAdresrol" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAdresrol_nocodes" minOccurs="0"/&gt;
             *                     &lt;element name="DatBAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *                     &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
             *                     &lt;element name="DatEAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *                     &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
             *                     &lt;element name="CdAfgeschermdAdres" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdOJNNvt_nocodes" minOccurs="0"/&gt;
             *                     &lt;choice minOccurs="0"&gt;
             *                       &lt;element name="StraatadresUhr" minOccurs="0"&gt;
             *                         &lt;complexType&gt;
             *                           &lt;complexContent&gt;
             *                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                               &lt;sequence&gt;
             *                                 &lt;element name="Postcd" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcd" minOccurs="0"/&gt;
             *                                 &lt;element name="Woonplaatsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
             *                                 &lt;element name="Straatnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdStraatnaam" minOccurs="0"/&gt;
             *                                 &lt;element name="Huisnr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisnr" minOccurs="0"/&gt;
             *                                 &lt;element name="Huisletter" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisletter" minOccurs="0"/&gt;
             *                                 &lt;element name="Huisnrtoevoeging" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar4" minOccurs="0"/&gt;
             *                                 &lt;element name="CdAanduidingBijHuisnr" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAanduidingBijHuisnr_nocodes" minOccurs="0"/&gt;
             *                                 &lt;element name="NaamOpenbareRuimte" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar80" minOccurs="0"/&gt;
             *                               &lt;/sequence&gt;
             *                             &lt;/restriction&gt;
             *                           &lt;/complexContent&gt;
             *                         &lt;/complexType&gt;
             *                       &lt;/element&gt;
             *                       &lt;element name="PostbusadresUhr" minOccurs="0"&gt;
             *                         &lt;complexType&gt;
             *                           &lt;complexContent&gt;
             *                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                               &lt;sequence&gt;
             *                                 &lt;element name="Postcd" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcd" minOccurs="0"/&gt;
             *                                 &lt;element name="Woonplaatsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
             *                                 &lt;element name="Postbusnr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostbusnr" minOccurs="0"/&gt;
             *                               &lt;/sequence&gt;
             *                             &lt;/restriction&gt;
             *                           &lt;/complexContent&gt;
             *                         &lt;/complexType&gt;
             *                       &lt;/element&gt;
             *                     &lt;/choice&gt;
             *                   &lt;/sequence&gt;
             *                 &lt;/restriction&gt;
             *               &lt;/complexContent&gt;
             *             &lt;/complexType&gt;
             *           &lt;/element&gt;
             *           &lt;element name="AdresBuitenlandUhr"&gt;
             *             &lt;complexType&gt;
             *               &lt;complexContent&gt;
             *                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                   &lt;sequence&gt;
             *                     &lt;element name="CdAdresrol" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAdresrol_nocodes" minOccurs="0"/&gt;
             *                     &lt;element name="DatBAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *                     &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
             *                     &lt;element name="DatEAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *                     &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
             *                     &lt;element name="CdAfgeschermdAdres" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdOJNNvt_nocodes" minOccurs="0"/&gt;
             *                     &lt;choice minOccurs="0"&gt;
             *                       &lt;element name="StraatadresBuitenlandUhr" minOccurs="0"&gt;
             *                         &lt;complexType&gt;
             *                           &lt;complexContent&gt;
             *                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                               &lt;sequence&gt;
             *                                 &lt;element name="PostcdBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcdBuitenland" minOccurs="0"/&gt;
             *                                 &lt;element name="WoonplaatsnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
             *                                 &lt;element name="RegionaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar24" minOccurs="0"/&gt;
             *                                 &lt;element name="LandcodeGba" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeGba" minOccurs="0"/&gt;
             *                                 &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
             *                                 &lt;element name="Landsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandsnaam" minOccurs="0"/&gt;
             *                                 &lt;element name="StraatnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdStraatnaam" minOccurs="0"/&gt;
             *                                 &lt;element name="HuisnrBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisnrBuitenland" minOccurs="0"/&gt;
             *                                 &lt;element name="LocatieomsBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar128" minOccurs="0"/&gt;
             *                               &lt;/sequence&gt;
             *                             &lt;/restriction&gt;
             *                           &lt;/complexContent&gt;
             *                         &lt;/complexType&gt;
             *                       &lt;/element&gt;
             *                       &lt;element name="PostbusadresBuitenlandUhr" minOccurs="0"&gt;
             *                         &lt;complexType&gt;
             *                           &lt;complexContent&gt;
             *                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                               &lt;sequence&gt;
             *                                 &lt;element name="PostcdBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcdBuitenland" minOccurs="0"/&gt;
             *                                 &lt;element name="WoonplaatsnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
             *                                 &lt;element name="RegionaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar24" minOccurs="0"/&gt;
             *                                 &lt;element name="LandcodeGba" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeGba" minOccurs="0"/&gt;
             *                                 &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
             *                                 &lt;element name="Landsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandsnaam" minOccurs="0"/&gt;
             *                                 &lt;element name="PostbusnrBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdReferentienrAnVar8" minOccurs="0"/&gt;
             *                               &lt;/sequence&gt;
             *                             &lt;/restriction&gt;
             *                           &lt;/complexContent&gt;
             *                         &lt;/complexType&gt;
             *                       &lt;/element&gt;
             *                     &lt;/choice&gt;
             *                   &lt;/sequence&gt;
             *                 &lt;/restriction&gt;
             *               &lt;/complexContent&gt;
             *             &lt;/complexType&gt;
             *           &lt;/element&gt;
             *           &lt;element name="AdresBuitenlandOngestructureerdUhr"&gt;
             *             &lt;complexType&gt;
             *               &lt;complexContent&gt;
             *                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                   &lt;sequence&gt;
             *                     &lt;element name="CdAdresrol" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAdresrol_nocodes" minOccurs="0"/&gt;
             *                     &lt;element name="DatBAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *                     &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
             *                     &lt;element name="DatEAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *                     &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
             *                     &lt;element name="CdAfgeschermdAdres" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdOJNNvt_nocodes" minOccurs="0"/&gt;
             *                     &lt;element name="Adresregel1Buitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar35" minOccurs="0"/&gt;
             *                     &lt;element name="Adresregel2Buitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar35" minOccurs="0"/&gt;
             *                     &lt;element name="Adresregel3Buitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar35" minOccurs="0"/&gt;
             *                     &lt;element name="LandcodeGba" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeGba" minOccurs="0"/&gt;
             *                     &lt;element name="LandsnaamGba" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar40" minOccurs="0"/&gt;
             *                     &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
             *                     &lt;element name="Landsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandsnaam" minOccurs="0"/&gt;
             *                   &lt;/sequence&gt;
             *                 &lt;/restriction&gt;
             *               &lt;/complexContent&gt;
             *             &lt;/complexType&gt;
             *           &lt;/element&gt;
             *         &lt;/choice&gt;
             *       &lt;/sequence&gt;
             *     &lt;/restriction&gt;
             *   &lt;/complexContent&gt;
             * &lt;/complexType&gt;
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "adresNederlandUhr",
                "adresBuitenlandUhr",
                "adresBuitenlandOngestructureerdUhr"
            })
            public static class Adreshouding {

                @XmlElement(name = "AdresNederlandUhr")
                @Valid
                protected CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresNederlandUhr adresNederlandUhr;
                @XmlElement(name = "AdresBuitenlandUhr")
                @Valid
                protected CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresBuitenlandUhr adresBuitenlandUhr;
                @XmlElement(name = "AdresBuitenlandOngestructureerdUhr")
                @Valid
                protected CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresBuitenlandOngestructureerdUhr adresBuitenlandOngestructureerdUhr;

                /**
                 * Gets the value of the adresNederlandUhr property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresNederlandUhr }
                 *     
                 */
                public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresNederlandUhr getAdresNederlandUhr() {
                    return adresNederlandUhr;
                }

                /**
                 * Sets the value of the adresNederlandUhr property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresNederlandUhr }
                 *     
                 */
                public void setAdresNederlandUhr(CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresNederlandUhr value) {
                    this.adresNederlandUhr = value;
                }

                /**
                 * Gets the value of the adresBuitenlandUhr property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresBuitenlandUhr }
                 *     
                 */
                public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresBuitenlandUhr getAdresBuitenlandUhr() {
                    return adresBuitenlandUhr;
                }

                /**
                 * Sets the value of the adresBuitenlandUhr property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresBuitenlandUhr }
                 *     
                 */
                public void setAdresBuitenlandUhr(CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresBuitenlandUhr value) {
                    this.adresBuitenlandUhr = value;
                }

                /**
                 * Gets the value of the adresBuitenlandOngestructureerdUhr property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresBuitenlandOngestructureerdUhr }
                 *     
                 */
                public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresBuitenlandOngestructureerdUhr getAdresBuitenlandOngestructureerdUhr() {
                    return adresBuitenlandOngestructureerdUhr;
                }

                /**
                 * Sets the value of the adresBuitenlandOngestructureerdUhr property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresBuitenlandOngestructureerdUhr }
                 *     
                 */
                public void setAdresBuitenlandOngestructureerdUhr(CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresBuitenlandOngestructureerdUhr value) {
                    this.adresBuitenlandOngestructureerdUhr = value;
                }


                /**
                 * <p>Java class for anonymous complex type.
                 * 
                 * <p>The following schema fragment specifies the expected content contained within this class.
                 * 
                 * <pre>
                 * &lt;complexType&gt;
                 *   &lt;complexContent&gt;
                 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                 *       &lt;sequence&gt;
                 *         &lt;element name="CdAdresrol" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAdresrol_nocodes" minOccurs="0"/&gt;
                 *         &lt;element name="DatBAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                 *         &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                 *         &lt;element name="DatEAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                 *         &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                 *         &lt;element name="CdAfgeschermdAdres" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdOJNNvt_nocodes" minOccurs="0"/&gt;
                 *         &lt;element name="Adresregel1Buitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar35" minOccurs="0"/&gt;
                 *         &lt;element name="Adresregel2Buitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar35" minOccurs="0"/&gt;
                 *         &lt;element name="Adresregel3Buitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar35" minOccurs="0"/&gt;
                 *         &lt;element name="LandcodeGba" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeGba" minOccurs="0"/&gt;
                 *         &lt;element name="LandsnaamGba" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar40" minOccurs="0"/&gt;
                 *         &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
                 *         &lt;element name="Landsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandsnaam" minOccurs="0"/&gt;
                 *       &lt;/sequence&gt;
                 *     &lt;/restriction&gt;
                 *   &lt;/complexContent&gt;
                 * &lt;/complexType&gt;
                 * </pre>
                 * 
                 * 
                 */
                @XmlAccessorType(XmlAccessType.FIELD)
                @XmlType(name = "", propOrder = {
                    "cdAdresrol",
                    "datBAdreshouding",
                    "cdFictieveDatB",
                    "datEAdreshouding",
                    "cdFictieveDatE",
                    "cdAfgeschermdAdres",
                    "adresregel1Buitenland",
                    "adresregel2Buitenland",
                    "adresregel3Buitenland",
                    "landcodeGba",
                    "landsnaamGba",
                    "landcodeIso",
                    "landsnaam"
                })
                public static class AdresBuitenlandOngestructureerdUhr {

                    @XmlElement(name = "CdAdresrol")
                    @Size(min = 1, max = 1)
                    @Pattern(regexp = "\\D*")
                    protected String cdAdresrol;
                    @XmlElement(name = "DatBAdreshouding")
                    @Size(max = 8)
                    protected String datBAdreshouding;
                    @XmlElement(name = "CdFictieveDatB")
                    @Size(min = 1, max = 1)
                    @Pattern(regexp = "\\d*")
                    protected String cdFictieveDatB;
                    @XmlElement(name = "DatEAdreshouding")
                    @Size(max = 8)
                    protected String datEAdreshouding;
                    @XmlElement(name = "CdFictieveDatE")
                    @Size(min = 1, max = 1)
                    @Pattern(regexp = "\\d*")
                    protected String cdFictieveDatE;
                    @XmlElement(name = "CdAfgeschermdAdres")
                    @Size(min = 1, max = 1)
                    @Pattern(regexp = "\\d*")
                    protected String cdAfgeschermdAdres;
                    @XmlElement(name = "Adresregel1Buitenland")
                    @Size(max = 35)
                    protected String adresregel1Buitenland;
                    @XmlElement(name = "Adresregel2Buitenland")
                    @Size(max = 35)
                    protected String adresregel2Buitenland;
                    @XmlElement(name = "Adresregel3Buitenland")
                    @Size(max = 35)
                    protected String adresregel3Buitenland;
                    @XmlElement(name = "LandcodeGba")
                    @Size(min = 4, max = 4)
                    @Pattern(regexp = "[0-9]*")
                    protected String landcodeGba;
                    @XmlElement(name = "LandsnaamGba")
                    @Size(max = 40)
                    protected String landsnaamGba;
                    @XmlElement(name = "LandcodeIso")
                    @Size(min = 2, max = 2)
                    @Pattern(regexp = "[A-Z]*")
                    protected String landcodeIso;
                    @XmlElement(name = "Landsnaam")
                    @Size(max = 40)
                    protected String landsnaam;

                    /**
                     * Gets the value of the cdAdresrol property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getCdAdresrol() {
                        return cdAdresrol;
                    }

                    /**
                     * Sets the value of the cdAdresrol property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setCdAdresrol(String value) {
                        this.cdAdresrol = value;
                    }

                    /**
                     * Gets the value of the datBAdreshouding property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getDatBAdreshouding() {
                        return datBAdreshouding;
                    }

                    /**
                     * Sets the value of the datBAdreshouding property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setDatBAdreshouding(String value) {
                        this.datBAdreshouding = value;
                    }

                    /**
                     * Gets the value of the cdFictieveDatB property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getCdFictieveDatB() {
                        return cdFictieveDatB;
                    }

                    /**
                     * Sets the value of the cdFictieveDatB property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setCdFictieveDatB(String value) {
                        this.cdFictieveDatB = value;
                    }

                    /**
                     * Gets the value of the datEAdreshouding property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getDatEAdreshouding() {
                        return datEAdreshouding;
                    }

                    /**
                     * Sets the value of the datEAdreshouding property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setDatEAdreshouding(String value) {
                        this.datEAdreshouding = value;
                    }

                    /**
                     * Gets the value of the cdFictieveDatE property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getCdFictieveDatE() {
                        return cdFictieveDatE;
                    }

                    /**
                     * Sets the value of the cdFictieveDatE property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setCdFictieveDatE(String value) {
                        this.cdFictieveDatE = value;
                    }

                    /**
                     * Gets the value of the cdAfgeschermdAdres property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getCdAfgeschermdAdres() {
                        return cdAfgeschermdAdres;
                    }

                    /**
                     * Sets the value of the cdAfgeschermdAdres property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setCdAfgeschermdAdres(String value) {
                        this.cdAfgeschermdAdres = value;
                    }

                    /**
                     * Gets the value of the adresregel1Buitenland property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getAdresregel1Buitenland() {
                        return adresregel1Buitenland;
                    }

                    /**
                     * Sets the value of the adresregel1Buitenland property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setAdresregel1Buitenland(String value) {
                        this.adresregel1Buitenland = value;
                    }

                    /**
                     * Gets the value of the adresregel2Buitenland property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getAdresregel2Buitenland() {
                        return adresregel2Buitenland;
                    }

                    /**
                     * Sets the value of the adresregel2Buitenland property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setAdresregel2Buitenland(String value) {
                        this.adresregel2Buitenland = value;
                    }

                    /**
                     * Gets the value of the adresregel3Buitenland property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getAdresregel3Buitenland() {
                        return adresregel3Buitenland;
                    }

                    /**
                     * Sets the value of the adresregel3Buitenland property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setAdresregel3Buitenland(String value) {
                        this.adresregel3Buitenland = value;
                    }

                    /**
                     * Gets the value of the landcodeGba property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getLandcodeGba() {
                        return landcodeGba;
                    }

                    /**
                     * Sets the value of the landcodeGba property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setLandcodeGba(String value) {
                        this.landcodeGba = value;
                    }

                    /**
                     * Gets the value of the landsnaamGba property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getLandsnaamGba() {
                        return landsnaamGba;
                    }

                    /**
                     * Sets the value of the landsnaamGba property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setLandsnaamGba(String value) {
                        this.landsnaamGba = value;
                    }

                    /**
                     * Gets the value of the landcodeIso property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getLandcodeIso() {
                        return landcodeIso;
                    }

                    /**
                     * Sets the value of the landcodeIso property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setLandcodeIso(String value) {
                        this.landcodeIso = value;
                    }

                    /**
                     * Gets the value of the landsnaam property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getLandsnaam() {
                        return landsnaam;
                    }

                    /**
                     * Sets the value of the landsnaam property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setLandsnaam(String value) {
                        this.landsnaam = value;
                    }

                }


                /**
                 * <p>Java class for anonymous complex type.
                 * 
                 * <p>The following schema fragment specifies the expected content contained within this class.
                 * 
                 * <pre>
                 * &lt;complexType&gt;
                 *   &lt;complexContent&gt;
                 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                 *       &lt;sequence&gt;
                 *         &lt;element name="CdAdresrol" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAdresrol_nocodes" minOccurs="0"/&gt;
                 *         &lt;element name="DatBAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                 *         &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                 *         &lt;element name="DatEAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                 *         &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                 *         &lt;element name="CdAfgeschermdAdres" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdOJNNvt_nocodes" minOccurs="0"/&gt;
                 *         &lt;choice minOccurs="0"&gt;
                 *           &lt;element name="StraatadresBuitenlandUhr" minOccurs="0"&gt;
                 *             &lt;complexType&gt;
                 *               &lt;complexContent&gt;
                 *                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                 *                   &lt;sequence&gt;
                 *                     &lt;element name="PostcdBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcdBuitenland" minOccurs="0"/&gt;
                 *                     &lt;element name="WoonplaatsnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
                 *                     &lt;element name="RegionaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar24" minOccurs="0"/&gt;
                 *                     &lt;element name="LandcodeGba" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeGba" minOccurs="0"/&gt;
                 *                     &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
                 *                     &lt;element name="Landsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandsnaam" minOccurs="0"/&gt;
                 *                     &lt;element name="StraatnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdStraatnaam" minOccurs="0"/&gt;
                 *                     &lt;element name="HuisnrBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisnrBuitenland" minOccurs="0"/&gt;
                 *                     &lt;element name="LocatieomsBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar128" minOccurs="0"/&gt;
                 *                   &lt;/sequence&gt;
                 *                 &lt;/restriction&gt;
                 *               &lt;/complexContent&gt;
                 *             &lt;/complexType&gt;
                 *           &lt;/element&gt;
                 *           &lt;element name="PostbusadresBuitenlandUhr" minOccurs="0"&gt;
                 *             &lt;complexType&gt;
                 *               &lt;complexContent&gt;
                 *                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                 *                   &lt;sequence&gt;
                 *                     &lt;element name="PostcdBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcdBuitenland" minOccurs="0"/&gt;
                 *                     &lt;element name="WoonplaatsnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
                 *                     &lt;element name="RegionaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar24" minOccurs="0"/&gt;
                 *                     &lt;element name="LandcodeGba" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeGba" minOccurs="0"/&gt;
                 *                     &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
                 *                     &lt;element name="Landsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandsnaam" minOccurs="0"/&gt;
                 *                     &lt;element name="PostbusnrBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdReferentienrAnVar8" minOccurs="0"/&gt;
                 *                   &lt;/sequence&gt;
                 *                 &lt;/restriction&gt;
                 *               &lt;/complexContent&gt;
                 *             &lt;/complexType&gt;
                 *           &lt;/element&gt;
                 *         &lt;/choice&gt;
                 *       &lt;/sequence&gt;
                 *     &lt;/restriction&gt;
                 *   &lt;/complexContent&gt;
                 * &lt;/complexType&gt;
                 * </pre>
                 * 
                 * 
                 */
                @XmlAccessorType(XmlAccessType.FIELD)
                @XmlType(name = "", propOrder = {
                    "cdAdresrol",
                    "datBAdreshouding",
                    "cdFictieveDatB",
                    "datEAdreshouding",
                    "cdFictieveDatE",
                    "cdAfgeschermdAdres",
                    "straatadresBuitenlandUhr",
                    "postbusadresBuitenlandUhr"
                })
                public static class AdresBuitenlandUhr {

                    @XmlElement(name = "CdAdresrol")
                    @Size(min = 1, max = 1)
                    @Pattern(regexp = "\\D*")
                    protected String cdAdresrol;
                    @XmlElement(name = "DatBAdreshouding")
                    @Size(max = 8)
                    protected String datBAdreshouding;
                    @XmlElement(name = "CdFictieveDatB")
                    @Size(min = 1, max = 1)
                    @Pattern(regexp = "\\d*")
                    protected String cdFictieveDatB;
                    @XmlElement(name = "DatEAdreshouding")
                    @Size(max = 8)
                    protected String datEAdreshouding;
                    @XmlElement(name = "CdFictieveDatE")
                    @Size(min = 1, max = 1)
                    @Pattern(regexp = "\\d*")
                    protected String cdFictieveDatE;
                    @XmlElement(name = "CdAfgeschermdAdres")
                    @Size(min = 1, max = 1)
                    @Pattern(regexp = "\\d*")
                    protected String cdAfgeschermdAdres;
                    @XmlElement(name = "StraatadresBuitenlandUhr")
                    @Valid
                    protected CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresBuitenlandUhr.StraatadresBuitenlandUhr straatadresBuitenlandUhr;
                    @XmlElement(name = "PostbusadresBuitenlandUhr")
                    @Valid
                    protected CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresBuitenlandUhr.PostbusadresBuitenlandUhr postbusadresBuitenlandUhr;

                    /**
                     * Gets the value of the cdAdresrol property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getCdAdresrol() {
                        return cdAdresrol;
                    }

                    /**
                     * Sets the value of the cdAdresrol property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setCdAdresrol(String value) {
                        this.cdAdresrol = value;
                    }

                    /**
                     * Gets the value of the datBAdreshouding property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getDatBAdreshouding() {
                        return datBAdreshouding;
                    }

                    /**
                     * Sets the value of the datBAdreshouding property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setDatBAdreshouding(String value) {
                        this.datBAdreshouding = value;
                    }

                    /**
                     * Gets the value of the cdFictieveDatB property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getCdFictieveDatB() {
                        return cdFictieveDatB;
                    }

                    /**
                     * Sets the value of the cdFictieveDatB property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setCdFictieveDatB(String value) {
                        this.cdFictieveDatB = value;
                    }

                    /**
                     * Gets the value of the datEAdreshouding property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getDatEAdreshouding() {
                        return datEAdreshouding;
                    }

                    /**
                     * Sets the value of the datEAdreshouding property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setDatEAdreshouding(String value) {
                        this.datEAdreshouding = value;
                    }

                    /**
                     * Gets the value of the cdFictieveDatE property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getCdFictieveDatE() {
                        return cdFictieveDatE;
                    }

                    /**
                     * Sets the value of the cdFictieveDatE property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setCdFictieveDatE(String value) {
                        this.cdFictieveDatE = value;
                    }

                    /**
                     * Gets the value of the cdAfgeschermdAdres property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getCdAfgeschermdAdres() {
                        return cdAfgeschermdAdres;
                    }

                    /**
                     * Sets the value of the cdAfgeschermdAdres property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setCdAfgeschermdAdres(String value) {
                        this.cdAfgeschermdAdres = value;
                    }

                    /**
                     * Gets the value of the straatadresBuitenlandUhr property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresBuitenlandUhr.StraatadresBuitenlandUhr }
                     *     
                     */
                    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresBuitenlandUhr.StraatadresBuitenlandUhr getStraatadresBuitenlandUhr() {
                        return straatadresBuitenlandUhr;
                    }

                    /**
                     * Sets the value of the straatadresBuitenlandUhr property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresBuitenlandUhr.StraatadresBuitenlandUhr }
                     *     
                     */
                    public void setStraatadresBuitenlandUhr(CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresBuitenlandUhr.StraatadresBuitenlandUhr value) {
                        this.straatadresBuitenlandUhr = value;
                    }

                    /**
                     * Gets the value of the postbusadresBuitenlandUhr property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresBuitenlandUhr.PostbusadresBuitenlandUhr }
                     *     
                     */
                    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresBuitenlandUhr.PostbusadresBuitenlandUhr getPostbusadresBuitenlandUhr() {
                        return postbusadresBuitenlandUhr;
                    }

                    /**
                     * Sets the value of the postbusadresBuitenlandUhr property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresBuitenlandUhr.PostbusadresBuitenlandUhr }
                     *     
                     */
                    public void setPostbusadresBuitenlandUhr(CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresBuitenlandUhr.PostbusadresBuitenlandUhr value) {
                        this.postbusadresBuitenlandUhr = value;
                    }


                    /**
                     * <p>Java class for anonymous complex type.
                     * 
                     * <p>The following schema fragment specifies the expected content contained within this class.
                     * 
                     * <pre>
                     * &lt;complexType&gt;
                     *   &lt;complexContent&gt;
                     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                     *       &lt;sequence&gt;
                     *         &lt;element name="PostcdBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcdBuitenland" minOccurs="0"/&gt;
                     *         &lt;element name="WoonplaatsnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
                     *         &lt;element name="RegionaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar24" minOccurs="0"/&gt;
                     *         &lt;element name="LandcodeGba" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeGba" minOccurs="0"/&gt;
                     *         &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
                     *         &lt;element name="Landsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandsnaam" minOccurs="0"/&gt;
                     *         &lt;element name="PostbusnrBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdReferentienrAnVar8" minOccurs="0"/&gt;
                     *       &lt;/sequence&gt;
                     *     &lt;/restriction&gt;
                     *   &lt;/complexContent&gt;
                     * &lt;/complexType&gt;
                     * </pre>
                     * 
                     * 
                     */
                    @XmlAccessorType(XmlAccessType.FIELD)
                    @XmlType(name = "", propOrder = {
                        "postcdBuitenland",
                        "woonplaatsnaamBuitenland",
                        "regionaamBuitenland",
                        "landcodeGba",
                        "landcodeIso",
                        "landsnaam",
                        "postbusnrBuitenland"
                    })
                    public static class PostbusadresBuitenlandUhr {

                        @XmlElement(name = "PostcdBuitenland")
                        @Size(max = 9)
                        protected String postcdBuitenland;
                        @XmlElement(name = "WoonplaatsnaamBuitenland")
                        @Size(max = 80)
                        protected String woonplaatsnaamBuitenland;
                        @XmlElement(name = "RegionaamBuitenland")
                        @Size(max = 24)
                        protected String regionaamBuitenland;
                        @XmlElement(name = "LandcodeGba")
                        @Size(min = 4, max = 4)
                        @Pattern(regexp = "[0-9]*")
                        protected String landcodeGba;
                        @XmlElement(name = "LandcodeIso")
                        @Size(min = 2, max = 2)
                        @Pattern(regexp = "[A-Z]*")
                        protected String landcodeIso;
                        @XmlElement(name = "Landsnaam")
                        @Size(max = 40)
                        protected String landsnaam;
                        @XmlElement(name = "PostbusnrBuitenland")
                        @Size(max = 8)
                        protected String postbusnrBuitenland;

                        /**
                         * Gets the value of the postcdBuitenland property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getPostcdBuitenland() {
                            return postcdBuitenland;
                        }

                        /**
                         * Sets the value of the postcdBuitenland property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setPostcdBuitenland(String value) {
                            this.postcdBuitenland = value;
                        }

                        /**
                         * Gets the value of the woonplaatsnaamBuitenland property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getWoonplaatsnaamBuitenland() {
                            return woonplaatsnaamBuitenland;
                        }

                        /**
                         * Sets the value of the woonplaatsnaamBuitenland property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setWoonplaatsnaamBuitenland(String value) {
                            this.woonplaatsnaamBuitenland = value;
                        }

                        /**
                         * Gets the value of the regionaamBuitenland property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getRegionaamBuitenland() {
                            return regionaamBuitenland;
                        }

                        /**
                         * Sets the value of the regionaamBuitenland property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setRegionaamBuitenland(String value) {
                            this.regionaamBuitenland = value;
                        }

                        /**
                         * Gets the value of the landcodeGba property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getLandcodeGba() {
                            return landcodeGba;
                        }

                        /**
                         * Sets the value of the landcodeGba property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setLandcodeGba(String value) {
                            this.landcodeGba = value;
                        }

                        /**
                         * Gets the value of the landcodeIso property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getLandcodeIso() {
                            return landcodeIso;
                        }

                        /**
                         * Sets the value of the landcodeIso property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setLandcodeIso(String value) {
                            this.landcodeIso = value;
                        }

                        /**
                         * Gets the value of the landsnaam property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getLandsnaam() {
                            return landsnaam;
                        }

                        /**
                         * Sets the value of the landsnaam property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setLandsnaam(String value) {
                            this.landsnaam = value;
                        }

                        /**
                         * Gets the value of the postbusnrBuitenland property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getPostbusnrBuitenland() {
                            return postbusnrBuitenland;
                        }

                        /**
                         * Sets the value of the postbusnrBuitenland property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setPostbusnrBuitenland(String value) {
                            this.postbusnrBuitenland = value;
                        }

                    }


                    /**
                     * <p>Java class for anonymous complex type.
                     * 
                     * <p>The following schema fragment specifies the expected content contained within this class.
                     * 
                     * <pre>
                     * &lt;complexType&gt;
                     *   &lt;complexContent&gt;
                     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                     *       &lt;sequence&gt;
                     *         &lt;element name="PostcdBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcdBuitenland" minOccurs="0"/&gt;
                     *         &lt;element name="WoonplaatsnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
                     *         &lt;element name="RegionaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar24" minOccurs="0"/&gt;
                     *         &lt;element name="LandcodeGba" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeGba" minOccurs="0"/&gt;
                     *         &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
                     *         &lt;element name="Landsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandsnaam" minOccurs="0"/&gt;
                     *         &lt;element name="StraatnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdStraatnaam" minOccurs="0"/&gt;
                     *         &lt;element name="HuisnrBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisnrBuitenland" minOccurs="0"/&gt;
                     *         &lt;element name="LocatieomsBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar128" minOccurs="0"/&gt;
                     *       &lt;/sequence&gt;
                     *     &lt;/restriction&gt;
                     *   &lt;/complexContent&gt;
                     * &lt;/complexType&gt;
                     * </pre>
                     * 
                     * 
                     */
                    @XmlAccessorType(XmlAccessType.FIELD)
                    @XmlType(name = "", propOrder = {
                        "postcdBuitenland",
                        "woonplaatsnaamBuitenland",
                        "regionaamBuitenland",
                        "landcodeGba",
                        "landcodeIso",
                        "landsnaam",
                        "straatnaamBuitenland",
                        "huisnrBuitenland",
                        "locatieomsBuitenland"
                    })
                    public static class StraatadresBuitenlandUhr {

                        @XmlElement(name = "PostcdBuitenland")
                        @Size(max = 9)
                        protected String postcdBuitenland;
                        @XmlElement(name = "WoonplaatsnaamBuitenland")
                        @Size(max = 80)
                        protected String woonplaatsnaamBuitenland;
                        @XmlElement(name = "RegionaamBuitenland")
                        @Size(max = 24)
                        protected String regionaamBuitenland;
                        @XmlElement(name = "LandcodeGba")
                        @Size(min = 4, max = 4)
                        @Pattern(regexp = "[0-9]*")
                        protected String landcodeGba;
                        @XmlElement(name = "LandcodeIso")
                        @Size(min = 2, max = 2)
                        @Pattern(regexp = "[A-Z]*")
                        protected String landcodeIso;
                        @XmlElement(name = "Landsnaam")
                        @Size(max = 40)
                        protected String landsnaam;
                        @XmlElement(name = "StraatnaamBuitenland")
                        @Size(max = 24)
                        protected String straatnaamBuitenland;
                        @XmlElement(name = "HuisnrBuitenland")
                        @Size(max = 9)
                        protected String huisnrBuitenland;
                        @XmlElement(name = "LocatieomsBuitenland")
                        @Size(max = 128)
                        protected String locatieomsBuitenland;

                        /**
                         * Gets the value of the postcdBuitenland property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getPostcdBuitenland() {
                            return postcdBuitenland;
                        }

                        /**
                         * Sets the value of the postcdBuitenland property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setPostcdBuitenland(String value) {
                            this.postcdBuitenland = value;
                        }

                        /**
                         * Gets the value of the woonplaatsnaamBuitenland property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getWoonplaatsnaamBuitenland() {
                            return woonplaatsnaamBuitenland;
                        }

                        /**
                         * Sets the value of the woonplaatsnaamBuitenland property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setWoonplaatsnaamBuitenland(String value) {
                            this.woonplaatsnaamBuitenland = value;
                        }

                        /**
                         * Gets the value of the regionaamBuitenland property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getRegionaamBuitenland() {
                            return regionaamBuitenland;
                        }

                        /**
                         * Sets the value of the regionaamBuitenland property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setRegionaamBuitenland(String value) {
                            this.regionaamBuitenland = value;
                        }

                        /**
                         * Gets the value of the landcodeGba property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getLandcodeGba() {
                            return landcodeGba;
                        }

                        /**
                         * Sets the value of the landcodeGba property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setLandcodeGba(String value) {
                            this.landcodeGba = value;
                        }

                        /**
                         * Gets the value of the landcodeIso property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getLandcodeIso() {
                            return landcodeIso;
                        }

                        /**
                         * Sets the value of the landcodeIso property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setLandcodeIso(String value) {
                            this.landcodeIso = value;
                        }

                        /**
                         * Gets the value of the landsnaam property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getLandsnaam() {
                            return landsnaam;
                        }

                        /**
                         * Sets the value of the landsnaam property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setLandsnaam(String value) {
                            this.landsnaam = value;
                        }

                        /**
                         * Gets the value of the straatnaamBuitenland property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getStraatnaamBuitenland() {
                            return straatnaamBuitenland;
                        }

                        /**
                         * Sets the value of the straatnaamBuitenland property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setStraatnaamBuitenland(String value) {
                            this.straatnaamBuitenland = value;
                        }

                        /**
                         * Gets the value of the huisnrBuitenland property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getHuisnrBuitenland() {
                            return huisnrBuitenland;
                        }

                        /**
                         * Sets the value of the huisnrBuitenland property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setHuisnrBuitenland(String value) {
                            this.huisnrBuitenland = value;
                        }

                        /**
                         * Gets the value of the locatieomsBuitenland property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getLocatieomsBuitenland() {
                            return locatieomsBuitenland;
                        }

                        /**
                         * Sets the value of the locatieomsBuitenland property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setLocatieomsBuitenland(String value) {
                            this.locatieomsBuitenland = value;
                        }

                    }

                }


                /**
                 * <p>Java class for anonymous complex type.
                 * 
                 * <p>The following schema fragment specifies the expected content contained within this class.
                 * 
                 * <pre>
                 * &lt;complexType&gt;
                 *   &lt;complexContent&gt;
                 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                 *       &lt;sequence&gt;
                 *         &lt;element name="CdAdresrol" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAdresrol_nocodes" minOccurs="0"/&gt;
                 *         &lt;element name="DatBAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                 *         &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                 *         &lt;element name="DatEAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                 *         &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                 *         &lt;element name="CdAfgeschermdAdres" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdOJNNvt_nocodes" minOccurs="0"/&gt;
                 *         &lt;choice minOccurs="0"&gt;
                 *           &lt;element name="StraatadresUhr" minOccurs="0"&gt;
                 *             &lt;complexType&gt;
                 *               &lt;complexContent&gt;
                 *                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                 *                   &lt;sequence&gt;
                 *                     &lt;element name="Postcd" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcd" minOccurs="0"/&gt;
                 *                     &lt;element name="Woonplaatsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
                 *                     &lt;element name="Straatnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdStraatnaam" minOccurs="0"/&gt;
                 *                     &lt;element name="Huisnr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisnr" minOccurs="0"/&gt;
                 *                     &lt;element name="Huisletter" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisletter" minOccurs="0"/&gt;
                 *                     &lt;element name="Huisnrtoevoeging" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar4" minOccurs="0"/&gt;
                 *                     &lt;element name="CdAanduidingBijHuisnr" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAanduidingBijHuisnr_nocodes" minOccurs="0"/&gt;
                 *                     &lt;element name="NaamOpenbareRuimte" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar80" minOccurs="0"/&gt;
                 *                   &lt;/sequence&gt;
                 *                 &lt;/restriction&gt;
                 *               &lt;/complexContent&gt;
                 *             &lt;/complexType&gt;
                 *           &lt;/element&gt;
                 *           &lt;element name="PostbusadresUhr" minOccurs="0"&gt;
                 *             &lt;complexType&gt;
                 *               &lt;complexContent&gt;
                 *                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                 *                   &lt;sequence&gt;
                 *                     &lt;element name="Postcd" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcd" minOccurs="0"/&gt;
                 *                     &lt;element name="Woonplaatsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
                 *                     &lt;element name="Postbusnr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostbusnr" minOccurs="0"/&gt;
                 *                   &lt;/sequence&gt;
                 *                 &lt;/restriction&gt;
                 *               &lt;/complexContent&gt;
                 *             &lt;/complexType&gt;
                 *           &lt;/element&gt;
                 *         &lt;/choice&gt;
                 *       &lt;/sequence&gt;
                 *     &lt;/restriction&gt;
                 *   &lt;/complexContent&gt;
                 * &lt;/complexType&gt;
                 * </pre>
                 * 
                 * 
                 */
                @XmlAccessorType(XmlAccessType.FIELD)
                @XmlType(name = "", propOrder = {
                    "cdAdresrol",
                    "datBAdreshouding",
                    "cdFictieveDatB",
                    "datEAdreshouding",
                    "cdFictieveDatE",
                    "cdAfgeschermdAdres",
                    "straatadresUhr",
                    "postbusadresUhr"
                })
                public static class AdresNederlandUhr {

                    @XmlElement(name = "CdAdresrol")
                    @Size(min = 1, max = 1)
                    @Pattern(regexp = "\\D*")
                    protected String cdAdresrol;
                    @XmlElement(name = "DatBAdreshouding")
                    @Size(max = 8)
                    protected String datBAdreshouding;
                    @XmlElement(name = "CdFictieveDatB")
                    @Size(min = 1, max = 1)
                    @Pattern(regexp = "\\d*")
                    protected String cdFictieveDatB;
                    @XmlElement(name = "DatEAdreshouding")
                    @Size(max = 8)
                    protected String datEAdreshouding;
                    @XmlElement(name = "CdFictieveDatE")
                    @Size(min = 1, max = 1)
                    @Pattern(regexp = "\\d*")
                    protected String cdFictieveDatE;
                    @XmlElement(name = "CdAfgeschermdAdres")
                    @Size(min = 1, max = 1)
                    @Pattern(regexp = "\\d*")
                    protected String cdAfgeschermdAdres;
                    @XmlElement(name = "StraatadresUhr")
                    @Valid
                    protected CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresNederlandUhr.StraatadresUhr straatadresUhr;
                    @XmlElement(name = "PostbusadresUhr")
                    @Valid
                    protected CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresNederlandUhr.PostbusadresUhr postbusadresUhr;

                    /**
                     * Gets the value of the cdAdresrol property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getCdAdresrol() {
                        return cdAdresrol;
                    }

                    /**
                     * Sets the value of the cdAdresrol property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setCdAdresrol(String value) {
                        this.cdAdresrol = value;
                    }

                    /**
                     * Gets the value of the datBAdreshouding property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getDatBAdreshouding() {
                        return datBAdreshouding;
                    }

                    /**
                     * Sets the value of the datBAdreshouding property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setDatBAdreshouding(String value) {
                        this.datBAdreshouding = value;
                    }

                    /**
                     * Gets the value of the cdFictieveDatB property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getCdFictieveDatB() {
                        return cdFictieveDatB;
                    }

                    /**
                     * Sets the value of the cdFictieveDatB property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setCdFictieveDatB(String value) {
                        this.cdFictieveDatB = value;
                    }

                    /**
                     * Gets the value of the datEAdreshouding property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getDatEAdreshouding() {
                        return datEAdreshouding;
                    }

                    /**
                     * Sets the value of the datEAdreshouding property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setDatEAdreshouding(String value) {
                        this.datEAdreshouding = value;
                    }

                    /**
                     * Gets the value of the cdFictieveDatE property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getCdFictieveDatE() {
                        return cdFictieveDatE;
                    }

                    /**
                     * Sets the value of the cdFictieveDatE property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setCdFictieveDatE(String value) {
                        this.cdFictieveDatE = value;
                    }

                    /**
                     * Gets the value of the cdAfgeschermdAdres property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getCdAfgeschermdAdres() {
                        return cdAfgeschermdAdres;
                    }

                    /**
                     * Sets the value of the cdAfgeschermdAdres property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setCdAfgeschermdAdres(String value) {
                        this.cdAfgeschermdAdres = value;
                    }

                    /**
                     * Gets the value of the straatadresUhr property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresNederlandUhr.StraatadresUhr }
                     *     
                     */
                    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresNederlandUhr.StraatadresUhr getStraatadresUhr() {
                        return straatadresUhr;
                    }

                    /**
                     * Sets the value of the straatadresUhr property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresNederlandUhr.StraatadresUhr }
                     *     
                     */
                    public void setStraatadresUhr(CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresNederlandUhr.StraatadresUhr value) {
                        this.straatadresUhr = value;
                    }

                    /**
                     * Gets the value of the postbusadresUhr property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresNederlandUhr.PostbusadresUhr }
                     *     
                     */
                    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresNederlandUhr.PostbusadresUhr getPostbusadresUhr() {
                        return postbusadresUhr;
                    }

                    /**
                     * Sets the value of the postbusadresUhr property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresNederlandUhr.PostbusadresUhr }
                     *     
                     */
                    public void setPostbusadresUhr(CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresNederlandUhr.PostbusadresUhr value) {
                        this.postbusadresUhr = value;
                    }


                    /**
                     * <p>Java class for anonymous complex type.
                     * 
                     * <p>The following schema fragment specifies the expected content contained within this class.
                     * 
                     * <pre>
                     * &lt;complexType&gt;
                     *   &lt;complexContent&gt;
                     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                     *       &lt;sequence&gt;
                     *         &lt;element name="Postcd" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcd" minOccurs="0"/&gt;
                     *         &lt;element name="Woonplaatsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
                     *         &lt;element name="Postbusnr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostbusnr" minOccurs="0"/&gt;
                     *       &lt;/sequence&gt;
                     *     &lt;/restriction&gt;
                     *   &lt;/complexContent&gt;
                     * &lt;/complexType&gt;
                     * </pre>
                     * 
                     * 
                     */
                    @XmlAccessorType(XmlAccessType.FIELD)
                    @XmlType(name = "", propOrder = {
                        "postcd",
                        "woonplaatsnaam",
                        "postbusnr"
                    })
                    public static class PostbusadresUhr {

                        @XmlElement(name = "Postcd")
                        @Size(min = 6, max = 6)
                        @Pattern(regexp = "[1-9][0-9]{3}[A-Z]{2}")
                        protected String postcd;
                        @XmlElement(name = "Woonplaatsnaam")
                        @Size(max = 80)
                        protected String woonplaatsnaam;
                        @XmlElement(name = "Postbusnr")
                        @XmlSchemaType(name = "nonNegativeInteger")
                        @DecimalMin("1")
                        @Digits(integer = 5, fraction = 0)
                        protected BigInteger postbusnr;

                        /**
                         * Gets the value of the postcd property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getPostcd() {
                            return postcd;
                        }

                        /**
                         * Sets the value of the postcd property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setPostcd(String value) {
                            this.postcd = value;
                        }

                        /**
                         * Gets the value of the woonplaatsnaam property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getWoonplaatsnaam() {
                            return woonplaatsnaam;
                        }

                        /**
                         * Sets the value of the woonplaatsnaam property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setWoonplaatsnaam(String value) {
                            this.woonplaatsnaam = value;
                        }

                        /**
                         * Gets the value of the postbusnr property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link BigInteger }
                         *     
                         */
                        public BigInteger getPostbusnr() {
                            return postbusnr;
                        }

                        /**
                         * Sets the value of the postbusnr property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link BigInteger }
                         *     
                         */
                        public void setPostbusnr(BigInteger value) {
                            this.postbusnr = value;
                        }

                    }


                    /**
                     * <p>Java class for anonymous complex type.
                     * 
                     * <p>The following schema fragment specifies the expected content contained within this class.
                     * 
                     * <pre>
                     * &lt;complexType&gt;
                     *   &lt;complexContent&gt;
                     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                     *       &lt;sequence&gt;
                     *         &lt;element name="Postcd" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcd" minOccurs="0"/&gt;
                     *         &lt;element name="Woonplaatsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
                     *         &lt;element name="Straatnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdStraatnaam" minOccurs="0"/&gt;
                     *         &lt;element name="Huisnr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisnr" minOccurs="0"/&gt;
                     *         &lt;element name="Huisletter" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisletter" minOccurs="0"/&gt;
                     *         &lt;element name="Huisnrtoevoeging" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar4" minOccurs="0"/&gt;
                     *         &lt;element name="CdAanduidingBijHuisnr" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAanduidingBijHuisnr_nocodes" minOccurs="0"/&gt;
                     *         &lt;element name="NaamOpenbareRuimte" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar80" minOccurs="0"/&gt;
                     *       &lt;/sequence&gt;
                     *     &lt;/restriction&gt;
                     *   &lt;/complexContent&gt;
                     * &lt;/complexType&gt;
                     * </pre>
                     * 
                     * 
                     */
                    @XmlAccessorType(XmlAccessType.FIELD)
                    @XmlType(name = "", propOrder = {
                        "postcd",
                        "woonplaatsnaam",
                        "straatnaam",
                        "huisnr",
                        "huisletter",
                        "huisnrtoevoeging",
                        "cdAanduidingBijHuisnr",
                        "naamOpenbareRuimte"
                    })
                    public static class StraatadresUhr {

                        @XmlElement(name = "Postcd")
                        @Size(min = 6, max = 6)
                        @Pattern(regexp = "[1-9][0-9]{3}[A-Z]{2}")
                        protected String postcd;
                        @XmlElement(name = "Woonplaatsnaam")
                        @Size(max = 80)
                        protected String woonplaatsnaam;
                        @XmlElement(name = "Straatnaam")
                        @Size(max = 24)
                        protected String straatnaam;
                        @XmlElement(name = "Huisnr")
                        @XmlSchemaType(name = "nonNegativeInteger")
                        @DecimalMin("1")
                        @Digits(integer = 5, fraction = 0)
                        protected BigInteger huisnr;
                        @XmlElement(name = "Huisletter")
                        @Size(min = 1, max = 1)
                        @Pattern(regexp = "[a-zA-Z]")
                        protected String huisletter;
                        @XmlElement(name = "Huisnrtoevoeging")
                        @Size(max = 4)
                        protected String huisnrtoevoeging;
                        @XmlElement(name = "CdAanduidingBijHuisnr")
                        @Size(min = 2, max = 2)
                        @Pattern(regexp = "\\D*")
                        protected String cdAanduidingBijHuisnr;
                        @XmlElement(name = "NaamOpenbareRuimte")
                        @Size(max = 80)
                        protected String naamOpenbareRuimte;

                        /**
                         * Gets the value of the postcd property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getPostcd() {
                            return postcd;
                        }

                        /**
                         * Sets the value of the postcd property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setPostcd(String value) {
                            this.postcd = value;
                        }

                        /**
                         * Gets the value of the woonplaatsnaam property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getWoonplaatsnaam() {
                            return woonplaatsnaam;
                        }

                        /**
                         * Sets the value of the woonplaatsnaam property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setWoonplaatsnaam(String value) {
                            this.woonplaatsnaam = value;
                        }

                        /**
                         * Gets the value of the straatnaam property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getStraatnaam() {
                            return straatnaam;
                        }

                        /**
                         * Sets the value of the straatnaam property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setStraatnaam(String value) {
                            this.straatnaam = value;
                        }

                        /**
                         * Gets the value of the huisnr property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link BigInteger }
                         *     
                         */
                        public BigInteger getHuisnr() {
                            return huisnr;
                        }

                        /**
                         * Sets the value of the huisnr property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link BigInteger }
                         *     
                         */
                        public void setHuisnr(BigInteger value) {
                            this.huisnr = value;
                        }

                        /**
                         * Gets the value of the huisletter property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getHuisletter() {
                            return huisletter;
                        }

                        /**
                         * Sets the value of the huisletter property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setHuisletter(String value) {
                            this.huisletter = value;
                        }

                        /**
                         * Gets the value of the huisnrtoevoeging property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getHuisnrtoevoeging() {
                            return huisnrtoevoeging;
                        }

                        /**
                         * Sets the value of the huisnrtoevoeging property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setHuisnrtoevoeging(String value) {
                            this.huisnrtoevoeging = value;
                        }

                        /**
                         * Gets the value of the cdAanduidingBijHuisnr property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getCdAanduidingBijHuisnr() {
                            return cdAanduidingBijHuisnr;
                        }

                        /**
                         * Sets the value of the cdAanduidingBijHuisnr property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setCdAanduidingBijHuisnr(String value) {
                            this.cdAanduidingBijHuisnr = value;
                        }

                        /**
                         * Gets the value of the naamOpenbareRuimte property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getNaamOpenbareRuimte() {
                            return naamOpenbareRuimte;
                        }

                        /**
                         * Sets the value of the naamOpenbareRuimte property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setNaamOpenbareRuimte(String value) {
                            this.naamOpenbareRuimte = value;
                        }

                    }

                }

            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType&gt;
             *   &lt;complexContent&gt;
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *       &lt;sequence&gt;
             *         &lt;element name="CdFaillSurs" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFaillissementSurseance_nocodes" minOccurs="0"/&gt;
             *         &lt;element name="CdRedenEindeFaillSurs" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdRedenEindeFaillisSurseance_nocodes" minOccurs="0"/&gt;
             *         &lt;element name="DatBFaillissementSurseance" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *         &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
             *         &lt;element name="DatEFaillissementSurseance" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *         &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
             *       &lt;/sequence&gt;
             *     &lt;/restriction&gt;
             *   &lt;/complexContent&gt;
             * &lt;/complexType&gt;
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "cdFaillSurs",
                "cdRedenEindeFaillSurs",
                "datBFaillissementSurseance",
                "cdFictieveDatB",
                "datEFaillissementSurseance",
                "cdFictieveDatE"
            })
            public static class FaillSurs {

                @XmlElement(name = "CdFaillSurs")
                @Size(min = 1, max = 1)
                @Pattern(regexp = "\\D*")
                protected String cdFaillSurs;
                @XmlElement(name = "CdRedenEindeFaillSurs")
                @Size(min = 2, max = 2)
                @Pattern(regexp = "[A-Z]*")
                protected String cdRedenEindeFaillSurs;
                @XmlElement(name = "DatBFaillissementSurseance")
                @Size(max = 8)
                protected String datBFaillissementSurseance;
                @XmlElement(name = "CdFictieveDatB")
                @Size(min = 1, max = 1)
                @Pattern(regexp = "\\d*")
                protected String cdFictieveDatB;
                @XmlElement(name = "DatEFaillissementSurseance")
                @Size(max = 8)
                protected String datEFaillissementSurseance;
                @XmlElement(name = "CdFictieveDatE")
                @Size(min = 1, max = 1)
                @Pattern(regexp = "\\d*")
                protected String cdFictieveDatE;

                /**
                 * Gets the value of the cdFaillSurs property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getCdFaillSurs() {
                    return cdFaillSurs;
                }

                /**
                 * Sets the value of the cdFaillSurs property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setCdFaillSurs(String value) {
                    this.cdFaillSurs = value;
                }

                /**
                 * Gets the value of the cdRedenEindeFaillSurs property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getCdRedenEindeFaillSurs() {
                    return cdRedenEindeFaillSurs;
                }

                /**
                 * Sets the value of the cdRedenEindeFaillSurs property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setCdRedenEindeFaillSurs(String value) {
                    this.cdRedenEindeFaillSurs = value;
                }

                /**
                 * Gets the value of the datBFaillissementSurseance property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getDatBFaillissementSurseance() {
                    return datBFaillissementSurseance;
                }

                /**
                 * Sets the value of the datBFaillissementSurseance property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setDatBFaillissementSurseance(String value) {
                    this.datBFaillissementSurseance = value;
                }

                /**
                 * Gets the value of the cdFictieveDatB property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getCdFictieveDatB() {
                    return cdFictieveDatB;
                }

                /**
                 * Sets the value of the cdFictieveDatB property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setCdFictieveDatB(String value) {
                    this.cdFictieveDatB = value;
                }

                /**
                 * Gets the value of the datEFaillissementSurseance property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getDatEFaillissementSurseance() {
                    return datEFaillissementSurseance;
                }

                /**
                 * Sets the value of the datEFaillissementSurseance property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setDatEFaillissementSurseance(String value) {
                    this.datEFaillissementSurseance = value;
                }

                /**
                 * Gets the value of the cdFictieveDatE property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getCdFictieveDatE() {
                    return cdFictieveDatE;
                }

                /**
                 * Sets the value of the cdFictieveDatE property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setCdFictieveDatE(String value) {
                    this.cdFictieveDatE = value;
                }

            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType&gt;
             *   &lt;complexContent&gt;
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *       &lt;sequence&gt;
             *         &lt;element name="CdSzProduct" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdSzProduct_nocodes" minOccurs="0"/&gt;
             *         &lt;element name="DatBGemoedsbezwaardheid" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *         &lt;element name="DatEGemoedsbezwaardheid" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *       &lt;/sequence&gt;
             *     &lt;/restriction&gt;
             *   &lt;/complexContent&gt;
             * &lt;/complexType&gt;
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "cdSzProduct",
                "datBGemoedsbezwaardheid",
                "datEGemoedsbezwaardheid"
            })
            public static class Gemoedsbezwaardheid {

                @XmlElement(name = "CdSzProduct")
                @Size(max = 5)
                @Pattern(regexp = "[A-Z]*")
                protected String cdSzProduct;
                @XmlElement(name = "DatBGemoedsbezwaardheid")
                @Size(max = 8)
                protected String datBGemoedsbezwaardheid;
                @XmlElement(name = "DatEGemoedsbezwaardheid")
                @Size(max = 8)
                protected String datEGemoedsbezwaardheid;

                /**
                 * Gets the value of the cdSzProduct property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getCdSzProduct() {
                    return cdSzProduct;
                }

                /**
                 * Sets the value of the cdSzProduct property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setCdSzProduct(String value) {
                    this.cdSzProduct = value;
                }

                /**
                 * Gets the value of the datBGemoedsbezwaardheid property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getDatBGemoedsbezwaardheid() {
                    return datBGemoedsbezwaardheid;
                }

                /**
                 * Sets the value of the datBGemoedsbezwaardheid property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setDatBGemoedsbezwaardheid(String value) {
                    this.datBGemoedsbezwaardheid = value;
                }

                /**
                 * Gets the value of the datEGemoedsbezwaardheid property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getDatEGemoedsbezwaardheid() {
                    return datEGemoedsbezwaardheid;
                }

                /**
                 * Sets the value of the datEGemoedsbezwaardheid property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setDatEGemoedsbezwaardheid(String value) {
                    this.datEGemoedsbezwaardheid = value;
                }

            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType&gt;
             *   &lt;complexContent&gt;
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *       &lt;sequence&gt;
             *         &lt;element name="KvkNr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdKvkNr" minOccurs="0"/&gt;
             *         &lt;element name="DatBMaatschappelijkeActiviteit" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *         &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
             *         &lt;element name="DatEMaatschappelijkeActiviteit" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *         &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
             *         &lt;element name="Sbiklasse" maxOccurs="unbounded" minOccurs="0"&gt;
             *           &lt;complexType&gt;
             *             &lt;complexContent&gt;
             *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                 &lt;sequence&gt;
             *                   &lt;element name="CdSbi" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdSbi" minOccurs="0"/&gt;
             *                   &lt;element name="OmsSbi" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar300" minOccurs="0"/&gt;
             *                   &lt;element name="IndSbiHoofdactiviteit" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdIndJN_nocodes" minOccurs="0"/&gt;
             *                   &lt;element name="DatBSbiactiviteit" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *                   &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
             *                   &lt;element name="DatESbiactiviteit" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *                   &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
             *                 &lt;/sequence&gt;
             *               &lt;/restriction&gt;
             *             &lt;/complexContent&gt;
             *           &lt;/complexType&gt;
             *         &lt;/element&gt;
             *         &lt;element name="VestigingHandelsregister" maxOccurs="unbounded" minOccurs="0"&gt;
             *           &lt;complexType&gt;
             *             &lt;complexContent&gt;
             *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                 &lt;sequence&gt;
             *                   &lt;element name="VestigingsnrHandelsregister" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdVestigingsnrHandelsregister" minOccurs="0"/&gt;
             *                   &lt;element name="EersteHandelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar200" minOccurs="0"/&gt;
             *                   &lt;element name="DatBVestigingHandelsregister" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *                   &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
             *                   &lt;element name="DatEVestigingHandelsregister" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *                   &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
             *                   &lt;element name="Adreshouding" maxOccurs="unbounded" minOccurs="0"&gt;
             *                     &lt;complexType&gt;
             *                       &lt;complexContent&gt;
             *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                           &lt;sequence&gt;
             *                             &lt;choice&gt;
             *                               &lt;element name="AdresNederlandUhr"&gt;
             *                                 &lt;complexType&gt;
             *                                   &lt;complexContent&gt;
             *                                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                                       &lt;sequence&gt;
             *                                         &lt;element name="CdAdresrol" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAdresrol_nocodes" minOccurs="0"/&gt;
             *                                         &lt;element name="DatBAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *                                         &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
             *                                         &lt;element name="DatEAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *                                         &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
             *                                         &lt;element name="CdAfgeschermdAdres" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdOJNNvt_nocodes" minOccurs="0"/&gt;
             *                                         &lt;choice minOccurs="0"&gt;
             *                                           &lt;element name="StraatadresUhr" minOccurs="0"&gt;
             *                                             &lt;complexType&gt;
             *                                               &lt;complexContent&gt;
             *                                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                                                   &lt;sequence&gt;
             *                                                     &lt;element name="Postcd" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcd" minOccurs="0"/&gt;
             *                                                     &lt;element name="Woonplaatsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
             *                                                     &lt;element name="Straatnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdStraatnaam" minOccurs="0"/&gt;
             *                                                     &lt;element name="Huisnr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisnr" minOccurs="0"/&gt;
             *                                                     &lt;element name="Huisletter" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisletter" minOccurs="0"/&gt;
             *                                                     &lt;element name="Huisnrtoevoeging" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar4" minOccurs="0"/&gt;
             *                                                     &lt;element name="CdAanduidingBijHuisnr" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAanduidingBijHuisnr_nocodes" minOccurs="0"/&gt;
             *                                                     &lt;element name="NaamOpenbareRuimte" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar80" minOccurs="0"/&gt;
             *                                                   &lt;/sequence&gt;
             *                                                 &lt;/restriction&gt;
             *                                               &lt;/complexContent&gt;
             *                                             &lt;/complexType&gt;
             *                                           &lt;/element&gt;
             *                                           &lt;element name="PostbusadresUhr" minOccurs="0"&gt;
             *                                             &lt;complexType&gt;
             *                                               &lt;complexContent&gt;
             *                                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                                                   &lt;sequence&gt;
             *                                                     &lt;element name="Postcd" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcd" minOccurs="0"/&gt;
             *                                                     &lt;element name="Woonplaatsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
             *                                                     &lt;element name="Postbusnr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostbusnr" minOccurs="0"/&gt;
             *                                                   &lt;/sequence&gt;
             *                                                 &lt;/restriction&gt;
             *                                               &lt;/complexContent&gt;
             *                                             &lt;/complexType&gt;
             *                                           &lt;/element&gt;
             *                                         &lt;/choice&gt;
             *                                       &lt;/sequence&gt;
             *                                     &lt;/restriction&gt;
             *                                   &lt;/complexContent&gt;
             *                                 &lt;/complexType&gt;
             *                               &lt;/element&gt;
             *                               &lt;element name="AdresBuitenlandUhr"&gt;
             *                                 &lt;complexType&gt;
             *                                   &lt;complexContent&gt;
             *                                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                                       &lt;sequence&gt;
             *                                         &lt;element name="CdAdresrol" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAdresrol_nocodes" minOccurs="0"/&gt;
             *                                         &lt;element name="DatBAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *                                         &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
             *                                         &lt;element name="DatEAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *                                         &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
             *                                         &lt;element name="CdAfgeschermdAdres" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdOJNNvt_nocodes" minOccurs="0"/&gt;
             *                                         &lt;choice minOccurs="0"&gt;
             *                                           &lt;element name="StraatadresBuitenlandUhr" minOccurs="0"&gt;
             *                                             &lt;complexType&gt;
             *                                               &lt;complexContent&gt;
             *                                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                                                   &lt;sequence&gt;
             *                                                     &lt;element name="PostcdBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcdBuitenland" minOccurs="0"/&gt;
             *                                                     &lt;element name="WoonplaatsnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
             *                                                     &lt;element name="RegionaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar24" minOccurs="0"/&gt;
             *                                                     &lt;element name="LandcodeGba" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeGba" minOccurs="0"/&gt;
             *                                                     &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
             *                                                     &lt;element name="Landsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandsnaam" minOccurs="0"/&gt;
             *                                                     &lt;element name="StraatnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdStraatnaam" minOccurs="0"/&gt;
             *                                                     &lt;element name="HuisnrBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisnrBuitenland" minOccurs="0"/&gt;
             *                                                     &lt;element name="LocatieomsBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar128" minOccurs="0"/&gt;
             *                                                   &lt;/sequence&gt;
             *                                                 &lt;/restriction&gt;
             *                                               &lt;/complexContent&gt;
             *                                             &lt;/complexType&gt;
             *                                           &lt;/element&gt;
             *                                           &lt;element name="PostbusadresBuitenlandUhr" minOccurs="0"&gt;
             *                                             &lt;complexType&gt;
             *                                               &lt;complexContent&gt;
             *                                                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                                                   &lt;sequence&gt;
             *                                                     &lt;element name="PostcdBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcdBuitenland" minOccurs="0"/&gt;
             *                                                     &lt;element name="WoonplaatsnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
             *                                                     &lt;element name="RegionaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar24" minOccurs="0"/&gt;
             *                                                     &lt;element name="LandcodeGba" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeGba" minOccurs="0"/&gt;
             *                                                     &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
             *                                                     &lt;element name="Landsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandsnaam" minOccurs="0"/&gt;
             *                                                     &lt;element name="PostbusnrBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdReferentienrAnVar8" minOccurs="0"/&gt;
             *                                                   &lt;/sequence&gt;
             *                                                 &lt;/restriction&gt;
             *                                               &lt;/complexContent&gt;
             *                                             &lt;/complexType&gt;
             *                                           &lt;/element&gt;
             *                                         &lt;/choice&gt;
             *                                       &lt;/sequence&gt;
             *                                     &lt;/restriction&gt;
             *                                   &lt;/complexContent&gt;
             *                                 &lt;/complexType&gt;
             *                               &lt;/element&gt;
             *                               &lt;element name="AdresBuitenlandOngestructureerdUhr"&gt;
             *                                 &lt;complexType&gt;
             *                                   &lt;complexContent&gt;
             *                                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                                       &lt;sequence&gt;
             *                                         &lt;element name="CdAdresrol" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAdresrol_nocodes" minOccurs="0"/&gt;
             *                                         &lt;element name="DatBAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *                                         &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
             *                                         &lt;element name="DatEAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *                                         &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
             *                                         &lt;element name="CdAfgeschermdAdres" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdOJNNvt_nocodes" minOccurs="0"/&gt;
             *                                         &lt;element name="Adresregel1Buitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar35" minOccurs="0"/&gt;
             *                                         &lt;element name="Adresregel2Buitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar35" minOccurs="0"/&gt;
             *                                         &lt;element name="Adresregel3Buitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar35" minOccurs="0"/&gt;
             *                                         &lt;element name="LandcodeGba" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeGba" minOccurs="0"/&gt;
             *                                         &lt;element name="LandsnaamGba" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar40" minOccurs="0"/&gt;
             *                                         &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
             *                                         &lt;element name="Landsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandsnaam" minOccurs="0"/&gt;
             *                                       &lt;/sequence&gt;
             *                                     &lt;/restriction&gt;
             *                                   &lt;/complexContent&gt;
             *                                 &lt;/complexType&gt;
             *                               &lt;/element&gt;
             *                             &lt;/choice&gt;
             *                           &lt;/sequence&gt;
             *                         &lt;/restriction&gt;
             *                       &lt;/complexContent&gt;
             *                     &lt;/complexType&gt;
             *                   &lt;/element&gt;
             *                   &lt;element name="ActiviteitHandelsregister" minOccurs="0"&gt;
             *                     &lt;complexType&gt;
             *                       &lt;complexContent&gt;
             *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                           &lt;sequence&gt;
             *                             &lt;element name="OmsActiviteitHandelsregister" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdTekstAnVar2000" minOccurs="0"/&gt;
             *                             &lt;element name="Sbiklasse" maxOccurs="unbounded" minOccurs="0"&gt;
             *                               &lt;complexType&gt;
             *                                 &lt;complexContent&gt;
             *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                                     &lt;sequence&gt;
             *                                       &lt;element name="CdSbi" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdSbi" minOccurs="0"/&gt;
             *                                       &lt;element name="OmsSbi" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar300" minOccurs="0"/&gt;
             *                                       &lt;element name="IndSbiHoofdactiviteit" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdIndJN_nocodes" minOccurs="0"/&gt;
             *                                       &lt;element name="DatBSbiactiviteit" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *                                       &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
             *                                       &lt;element name="DatESbiactiviteit" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *                                       &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
             *                                     &lt;/sequence&gt;
             *                                   &lt;/restriction&gt;
             *                                 &lt;/complexContent&gt;
             *                               &lt;/complexType&gt;
             *                             &lt;/element&gt;
             *                           &lt;/sequence&gt;
             *                         &lt;/restriction&gt;
             *                       &lt;/complexContent&gt;
             *                     &lt;/complexType&gt;
             *                   &lt;/element&gt;
             *                   &lt;element name="Onderneming" maxOccurs="unbounded" minOccurs="0"&gt;
             *                     &lt;complexType&gt;
             *                       &lt;complexContent&gt;
             *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                           &lt;sequence&gt;
             *                             &lt;element name="KvkNr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdKvkNr" minOccurs="0"/&gt;
             *                             &lt;element name="DatBOnderneming" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *                             &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
             *                             &lt;element name="DatEOnderneming" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *                             &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
             *                             &lt;element name="Sbiklasse" maxOccurs="unbounded" minOccurs="0"&gt;
             *                               &lt;complexType&gt;
             *                                 &lt;complexContent&gt;
             *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                                     &lt;sequence&gt;
             *                                       &lt;element name="CdSbi" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdSbi" minOccurs="0"/&gt;
             *                                       &lt;element name="OmsSbi" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar300" minOccurs="0"/&gt;
             *                                       &lt;element name="IndSbiHoofdactiviteit" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdIndJN_nocodes" minOccurs="0"/&gt;
             *                                       &lt;element name="DatBSbiactiviteit" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *                                       &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
             *                                       &lt;element name="DatESbiactiviteit" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *                                       &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
             *                                     &lt;/sequence&gt;
             *                                   &lt;/restriction&gt;
             *                                 &lt;/complexContent&gt;
             *                               &lt;/complexType&gt;
             *                             &lt;/element&gt;
             *                             &lt;element name="Handelsnaam" maxOccurs="unbounded" minOccurs="0"&gt;
             *                               &lt;complexType&gt;
             *                                 &lt;complexContent&gt;
             *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                                     &lt;sequence&gt;
             *                                       &lt;element name="Handelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar625" minOccurs="0"/&gt;
             *                                       &lt;element name="VolgordeHandelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdAantNietNegatiefVar4" minOccurs="0"/&gt;
             *                                       &lt;element name="DatBHandelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *                                       &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
             *                                       &lt;element name="DatEHandelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *                                       &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
             *                                     &lt;/sequence&gt;
             *                                   &lt;/restriction&gt;
             *                                 &lt;/complexContent&gt;
             *                               &lt;/complexType&gt;
             *                             &lt;/element&gt;
             *                           &lt;/sequence&gt;
             *                         &lt;/restriction&gt;
             *                       &lt;/complexContent&gt;
             *                     &lt;/complexType&gt;
             *                   &lt;/element&gt;
             *                   &lt;element name="Handelsnaam" maxOccurs="unbounded" minOccurs="0"&gt;
             *                     &lt;complexType&gt;
             *                       &lt;complexContent&gt;
             *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                           &lt;sequence&gt;
             *                             &lt;element name="Handelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar625" minOccurs="0"/&gt;
             *                             &lt;element name="VolgordeHandelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdAantNietNegatiefVar4" minOccurs="0"/&gt;
             *                             &lt;element name="DatBHandelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *                             &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
             *                             &lt;element name="DatEHandelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *                             &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
             *                           &lt;/sequence&gt;
             *                         &lt;/restriction&gt;
             *                       &lt;/complexContent&gt;
             *                     &lt;/complexType&gt;
             *                   &lt;/element&gt;
             *                 &lt;/sequence&gt;
             *               &lt;/restriction&gt;
             *             &lt;/complexContent&gt;
             *           &lt;/complexType&gt;
             *         &lt;/element&gt;
             *       &lt;/sequence&gt;
             *     &lt;/restriction&gt;
             *   &lt;/complexContent&gt;
             * &lt;/complexType&gt;
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "kvkNr",
                "datBMaatschappelijkeActiviteit",
                "cdFictieveDatB",
                "datEMaatschappelijkeActiviteit",
                "cdFictieveDatE",
                "sbiklasse",
                "vestigingHandelsregister"
            })
            public static class MaatschappelijkeActiviteit {

                @XmlElement(name = "KvkNr")
                @Size(min = 8, max = 8)
                @Pattern(regexp = "\\d*")
                protected String kvkNr;
                @XmlElement(name = "DatBMaatschappelijkeActiviteit")
                @Size(max = 8)
                protected String datBMaatschappelijkeActiviteit;
                @XmlElement(name = "CdFictieveDatB")
                @Size(min = 1, max = 1)
                @Pattern(regexp = "\\d*")
                protected String cdFictieveDatB;
                @XmlElement(name = "DatEMaatschappelijkeActiviteit")
                @Size(max = 8)
                protected String datEMaatschappelijkeActiviteit;
                @XmlElement(name = "CdFictieveDatE")
                @Size(min = 1, max = 1)
                @Pattern(regexp = "\\d*")
                protected String cdFictieveDatE;
                @XmlElement(name = "Sbiklasse")
                @Valid
                protected List<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.Sbiklasse> sbiklasse;
                @XmlElement(name = "VestigingHandelsregister")
                @Valid
                protected List<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister> vestigingHandelsregister;

                /**
                 * Gets the value of the kvkNr property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getKvkNr() {
                    return kvkNr;
                }

                /**
                 * Sets the value of the kvkNr property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setKvkNr(String value) {
                    this.kvkNr = value;
                }

                /**
                 * Gets the value of the datBMaatschappelijkeActiviteit property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getDatBMaatschappelijkeActiviteit() {
                    return datBMaatschappelijkeActiviteit;
                }

                /**
                 * Sets the value of the datBMaatschappelijkeActiviteit property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setDatBMaatschappelijkeActiviteit(String value) {
                    this.datBMaatschappelijkeActiviteit = value;
                }

                /**
                 * Gets the value of the cdFictieveDatB property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getCdFictieveDatB() {
                    return cdFictieveDatB;
                }

                /**
                 * Sets the value of the cdFictieveDatB property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setCdFictieveDatB(String value) {
                    this.cdFictieveDatB = value;
                }

                /**
                 * Gets the value of the datEMaatschappelijkeActiviteit property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getDatEMaatschappelijkeActiviteit() {
                    return datEMaatschappelijkeActiviteit;
                }

                /**
                 * Sets the value of the datEMaatschappelijkeActiviteit property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setDatEMaatschappelijkeActiviteit(String value) {
                    this.datEMaatschappelijkeActiviteit = value;
                }

                /**
                 * Gets the value of the cdFictieveDatE property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getCdFictieveDatE() {
                    return cdFictieveDatE;
                }

                /**
                 * Sets the value of the cdFictieveDatE property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setCdFictieveDatE(String value) {
                    this.cdFictieveDatE = value;
                }

                /**
                 * Gets the value of the sbiklasse property.
                 * 
                 * <p>
                 * This accessor method returns a reference to the live list,
                 * not a snapshot. Therefore any modification you make to the
                 * returned list will be present inside the JAXB object.
                 * This is why there is not a <CODE>set</CODE> method for the sbiklasse property.
                 * 
                 * <p>
                 * For example, to add a new item, do as follows:
                 * <pre>
                 *    getSbiklasse().add(newItem);
                 * </pre>
                 * 
                 * 
                 * <p>
                 * Objects of the following type(s) are allowed in the list
                 * {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.Sbiklasse }
                 * 
                 * 
                 */
                public List<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.Sbiklasse> getSbiklasse() {
                    if (sbiklasse == null) {
                        sbiklasse = new ArrayList<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.Sbiklasse>();
                    }
                    return this.sbiklasse;
                }

                /**
                 * Gets the value of the vestigingHandelsregister property.
                 * 
                 * <p>
                 * This accessor method returns a reference to the live list,
                 * not a snapshot. Therefore any modification you make to the
                 * returned list will be present inside the JAXB object.
                 * This is why there is not a <CODE>set</CODE> method for the vestigingHandelsregister property.
                 * 
                 * <p>
                 * For example, to add a new item, do as follows:
                 * <pre>
                 *    getVestigingHandelsregister().add(newItem);
                 * </pre>
                 * 
                 * 
                 * <p>
                 * Objects of the following type(s) are allowed in the list
                 * {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister }
                 * 
                 * 
                 */
                public List<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister> getVestigingHandelsregister() {
                    if (vestigingHandelsregister == null) {
                        vestigingHandelsregister = new ArrayList<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister>();
                    }
                    return this.vestigingHandelsregister;
                }


                /**
                 * <p>Java class for anonymous complex type.
                 * 
                 * <p>The following schema fragment specifies the expected content contained within this class.
                 * 
                 * <pre>
                 * &lt;complexType&gt;
                 *   &lt;complexContent&gt;
                 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                 *       &lt;sequence&gt;
                 *         &lt;element name="CdSbi" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdSbi" minOccurs="0"/&gt;
                 *         &lt;element name="OmsSbi" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar300" minOccurs="0"/&gt;
                 *         &lt;element name="IndSbiHoofdactiviteit" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdIndJN_nocodes" minOccurs="0"/&gt;
                 *         &lt;element name="DatBSbiactiviteit" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                 *         &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                 *         &lt;element name="DatESbiactiviteit" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                 *         &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                 *       &lt;/sequence&gt;
                 *     &lt;/restriction&gt;
                 *   &lt;/complexContent&gt;
                 * &lt;/complexType&gt;
                 * </pre>
                 * 
                 * 
                 */
                @XmlAccessorType(XmlAccessType.FIELD)
                @XmlType(name = "", propOrder = {
                    "cdSbi",
                    "omsSbi",
                    "indSbiHoofdactiviteit",
                    "datBSbiactiviteit",
                    "cdFictieveDatB",
                    "datESbiactiviteit",
                    "cdFictieveDatE"
                })
                public static class Sbiklasse {

                    @XmlElement(name = "CdSbi")
                    @Size(max = 5)
                    @Pattern(regexp = "[0-9]*")
                    protected String cdSbi;
                    @XmlElement(name = "OmsSbi")
                    @Size(max = 300)
                    protected String omsSbi;
                    @XmlElement(name = "IndSbiHoofdactiviteit")
                    @Size(min = 1, max = 1)
                    @Pattern(regexp = "[0-9]*")
                    protected String indSbiHoofdactiviteit;
                    @XmlElement(name = "DatBSbiactiviteit")
                    @Size(max = 8)
                    protected String datBSbiactiviteit;
                    @XmlElement(name = "CdFictieveDatB")
                    @Size(min = 1, max = 1)
                    @Pattern(regexp = "\\d*")
                    protected String cdFictieveDatB;
                    @XmlElement(name = "DatESbiactiviteit")
                    @Size(max = 8)
                    protected String datESbiactiviteit;
                    @XmlElement(name = "CdFictieveDatE")
                    @Size(min = 1, max = 1)
                    @Pattern(regexp = "\\d*")
                    protected String cdFictieveDatE;

                    /**
                     * Gets the value of the cdSbi property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getCdSbi() {
                        return cdSbi;
                    }

                    /**
                     * Sets the value of the cdSbi property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setCdSbi(String value) {
                        this.cdSbi = value;
                    }

                    /**
                     * Gets the value of the omsSbi property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getOmsSbi() {
                        return omsSbi;
                    }

                    /**
                     * Sets the value of the omsSbi property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setOmsSbi(String value) {
                        this.omsSbi = value;
                    }

                    /**
                     * Gets the value of the indSbiHoofdactiviteit property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getIndSbiHoofdactiviteit() {
                        return indSbiHoofdactiviteit;
                    }

                    /**
                     * Sets the value of the indSbiHoofdactiviteit property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setIndSbiHoofdactiviteit(String value) {
                        this.indSbiHoofdactiviteit = value;
                    }

                    /**
                     * Gets the value of the datBSbiactiviteit property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getDatBSbiactiviteit() {
                        return datBSbiactiviteit;
                    }

                    /**
                     * Sets the value of the datBSbiactiviteit property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setDatBSbiactiviteit(String value) {
                        this.datBSbiactiviteit = value;
                    }

                    /**
                     * Gets the value of the cdFictieveDatB property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getCdFictieveDatB() {
                        return cdFictieveDatB;
                    }

                    /**
                     * Sets the value of the cdFictieveDatB property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setCdFictieveDatB(String value) {
                        this.cdFictieveDatB = value;
                    }

                    /**
                     * Gets the value of the datESbiactiviteit property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getDatESbiactiviteit() {
                        return datESbiactiviteit;
                    }

                    /**
                     * Sets the value of the datESbiactiviteit property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setDatESbiactiviteit(String value) {
                        this.datESbiactiviteit = value;
                    }

                    /**
                     * Gets the value of the cdFictieveDatE property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getCdFictieveDatE() {
                        return cdFictieveDatE;
                    }

                    /**
                     * Sets the value of the cdFictieveDatE property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setCdFictieveDatE(String value) {
                        this.cdFictieveDatE = value;
                    }

                }


                /**
                 * <p>Java class for anonymous complex type.
                 * 
                 * <p>The following schema fragment specifies the expected content contained within this class.
                 * 
                 * <pre>
                 * &lt;complexType&gt;
                 *   &lt;complexContent&gt;
                 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                 *       &lt;sequence&gt;
                 *         &lt;element name="VestigingsnrHandelsregister" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdVestigingsnrHandelsregister" minOccurs="0"/&gt;
                 *         &lt;element name="EersteHandelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar200" minOccurs="0"/&gt;
                 *         &lt;element name="DatBVestigingHandelsregister" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                 *         &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                 *         &lt;element name="DatEVestigingHandelsregister" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                 *         &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                 *         &lt;element name="Adreshouding" maxOccurs="unbounded" minOccurs="0"&gt;
                 *           &lt;complexType&gt;
                 *             &lt;complexContent&gt;
                 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                 *                 &lt;sequence&gt;
                 *                   &lt;choice&gt;
                 *                     &lt;element name="AdresNederlandUhr"&gt;
                 *                       &lt;complexType&gt;
                 *                         &lt;complexContent&gt;
                 *                           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                 *                             &lt;sequence&gt;
                 *                               &lt;element name="CdAdresrol" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAdresrol_nocodes" minOccurs="0"/&gt;
                 *                               &lt;element name="DatBAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                 *                               &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                 *                               &lt;element name="DatEAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                 *                               &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                 *                               &lt;element name="CdAfgeschermdAdres" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdOJNNvt_nocodes" minOccurs="0"/&gt;
                 *                               &lt;choice minOccurs="0"&gt;
                 *                                 &lt;element name="StraatadresUhr" minOccurs="0"&gt;
                 *                                   &lt;complexType&gt;
                 *                                     &lt;complexContent&gt;
                 *                                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                 *                                         &lt;sequence&gt;
                 *                                           &lt;element name="Postcd" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcd" minOccurs="0"/&gt;
                 *                                           &lt;element name="Woonplaatsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
                 *                                           &lt;element name="Straatnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdStraatnaam" minOccurs="0"/&gt;
                 *                                           &lt;element name="Huisnr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisnr" minOccurs="0"/&gt;
                 *                                           &lt;element name="Huisletter" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisletter" minOccurs="0"/&gt;
                 *                                           &lt;element name="Huisnrtoevoeging" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar4" minOccurs="0"/&gt;
                 *                                           &lt;element name="CdAanduidingBijHuisnr" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAanduidingBijHuisnr_nocodes" minOccurs="0"/&gt;
                 *                                           &lt;element name="NaamOpenbareRuimte" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar80" minOccurs="0"/&gt;
                 *                                         &lt;/sequence&gt;
                 *                                       &lt;/restriction&gt;
                 *                                     &lt;/complexContent&gt;
                 *                                   &lt;/complexType&gt;
                 *                                 &lt;/element&gt;
                 *                                 &lt;element name="PostbusadresUhr" minOccurs="0"&gt;
                 *                                   &lt;complexType&gt;
                 *                                     &lt;complexContent&gt;
                 *                                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                 *                                         &lt;sequence&gt;
                 *                                           &lt;element name="Postcd" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcd" minOccurs="0"/&gt;
                 *                                           &lt;element name="Woonplaatsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
                 *                                           &lt;element name="Postbusnr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostbusnr" minOccurs="0"/&gt;
                 *                                         &lt;/sequence&gt;
                 *                                       &lt;/restriction&gt;
                 *                                     &lt;/complexContent&gt;
                 *                                   &lt;/complexType&gt;
                 *                                 &lt;/element&gt;
                 *                               &lt;/choice&gt;
                 *                             &lt;/sequence&gt;
                 *                           &lt;/restriction&gt;
                 *                         &lt;/complexContent&gt;
                 *                       &lt;/complexType&gt;
                 *                     &lt;/element&gt;
                 *                     &lt;element name="AdresBuitenlandUhr"&gt;
                 *                       &lt;complexType&gt;
                 *                         &lt;complexContent&gt;
                 *                           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                 *                             &lt;sequence&gt;
                 *                               &lt;element name="CdAdresrol" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAdresrol_nocodes" minOccurs="0"/&gt;
                 *                               &lt;element name="DatBAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                 *                               &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                 *                               &lt;element name="DatEAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                 *                               &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                 *                               &lt;element name="CdAfgeschermdAdres" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdOJNNvt_nocodes" minOccurs="0"/&gt;
                 *                               &lt;choice minOccurs="0"&gt;
                 *                                 &lt;element name="StraatadresBuitenlandUhr" minOccurs="0"&gt;
                 *                                   &lt;complexType&gt;
                 *                                     &lt;complexContent&gt;
                 *                                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                 *                                         &lt;sequence&gt;
                 *                                           &lt;element name="PostcdBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcdBuitenland" minOccurs="0"/&gt;
                 *                                           &lt;element name="WoonplaatsnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
                 *                                           &lt;element name="RegionaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar24" minOccurs="0"/&gt;
                 *                                           &lt;element name="LandcodeGba" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeGba" minOccurs="0"/&gt;
                 *                                           &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
                 *                                           &lt;element name="Landsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandsnaam" minOccurs="0"/&gt;
                 *                                           &lt;element name="StraatnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdStraatnaam" minOccurs="0"/&gt;
                 *                                           &lt;element name="HuisnrBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisnrBuitenland" minOccurs="0"/&gt;
                 *                                           &lt;element name="LocatieomsBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar128" minOccurs="0"/&gt;
                 *                                         &lt;/sequence&gt;
                 *                                       &lt;/restriction&gt;
                 *                                     &lt;/complexContent&gt;
                 *                                   &lt;/complexType&gt;
                 *                                 &lt;/element&gt;
                 *                                 &lt;element name="PostbusadresBuitenlandUhr" minOccurs="0"&gt;
                 *                                   &lt;complexType&gt;
                 *                                     &lt;complexContent&gt;
                 *                                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                 *                                         &lt;sequence&gt;
                 *                                           &lt;element name="PostcdBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcdBuitenland" minOccurs="0"/&gt;
                 *                                           &lt;element name="WoonplaatsnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
                 *                                           &lt;element name="RegionaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar24" minOccurs="0"/&gt;
                 *                                           &lt;element name="LandcodeGba" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeGba" minOccurs="0"/&gt;
                 *                                           &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
                 *                                           &lt;element name="Landsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandsnaam" minOccurs="0"/&gt;
                 *                                           &lt;element name="PostbusnrBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdReferentienrAnVar8" minOccurs="0"/&gt;
                 *                                         &lt;/sequence&gt;
                 *                                       &lt;/restriction&gt;
                 *                                     &lt;/complexContent&gt;
                 *                                   &lt;/complexType&gt;
                 *                                 &lt;/element&gt;
                 *                               &lt;/choice&gt;
                 *                             &lt;/sequence&gt;
                 *                           &lt;/restriction&gt;
                 *                         &lt;/complexContent&gt;
                 *                       &lt;/complexType&gt;
                 *                     &lt;/element&gt;
                 *                     &lt;element name="AdresBuitenlandOngestructureerdUhr"&gt;
                 *                       &lt;complexType&gt;
                 *                         &lt;complexContent&gt;
                 *                           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                 *                             &lt;sequence&gt;
                 *                               &lt;element name="CdAdresrol" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAdresrol_nocodes" minOccurs="0"/&gt;
                 *                               &lt;element name="DatBAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                 *                               &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                 *                               &lt;element name="DatEAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                 *                               &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                 *                               &lt;element name="CdAfgeschermdAdres" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdOJNNvt_nocodes" minOccurs="0"/&gt;
                 *                               &lt;element name="Adresregel1Buitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar35" minOccurs="0"/&gt;
                 *                               &lt;element name="Adresregel2Buitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar35" minOccurs="0"/&gt;
                 *                               &lt;element name="Adresregel3Buitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar35" minOccurs="0"/&gt;
                 *                               &lt;element name="LandcodeGba" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeGba" minOccurs="0"/&gt;
                 *                               &lt;element name="LandsnaamGba" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar40" minOccurs="0"/&gt;
                 *                               &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
                 *                               &lt;element name="Landsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandsnaam" minOccurs="0"/&gt;
                 *                             &lt;/sequence&gt;
                 *                           &lt;/restriction&gt;
                 *                         &lt;/complexContent&gt;
                 *                       &lt;/complexType&gt;
                 *                     &lt;/element&gt;
                 *                   &lt;/choice&gt;
                 *                 &lt;/sequence&gt;
                 *               &lt;/restriction&gt;
                 *             &lt;/complexContent&gt;
                 *           &lt;/complexType&gt;
                 *         &lt;/element&gt;
                 *         &lt;element name="ActiviteitHandelsregister" minOccurs="0"&gt;
                 *           &lt;complexType&gt;
                 *             &lt;complexContent&gt;
                 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                 *                 &lt;sequence&gt;
                 *                   &lt;element name="OmsActiviteitHandelsregister" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdTekstAnVar2000" minOccurs="0"/&gt;
                 *                   &lt;element name="Sbiklasse" maxOccurs="unbounded" minOccurs="0"&gt;
                 *                     &lt;complexType&gt;
                 *                       &lt;complexContent&gt;
                 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                 *                           &lt;sequence&gt;
                 *                             &lt;element name="CdSbi" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdSbi" minOccurs="0"/&gt;
                 *                             &lt;element name="OmsSbi" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar300" minOccurs="0"/&gt;
                 *                             &lt;element name="IndSbiHoofdactiviteit" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdIndJN_nocodes" minOccurs="0"/&gt;
                 *                             &lt;element name="DatBSbiactiviteit" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                 *                             &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                 *                             &lt;element name="DatESbiactiviteit" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                 *                             &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                 *                           &lt;/sequence&gt;
                 *                         &lt;/restriction&gt;
                 *                       &lt;/complexContent&gt;
                 *                     &lt;/complexType&gt;
                 *                   &lt;/element&gt;
                 *                 &lt;/sequence&gt;
                 *               &lt;/restriction&gt;
                 *             &lt;/complexContent&gt;
                 *           &lt;/complexType&gt;
                 *         &lt;/element&gt;
                 *         &lt;element name="Onderneming" maxOccurs="unbounded" minOccurs="0"&gt;
                 *           &lt;complexType&gt;
                 *             &lt;complexContent&gt;
                 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                 *                 &lt;sequence&gt;
                 *                   &lt;element name="KvkNr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdKvkNr" minOccurs="0"/&gt;
                 *                   &lt;element name="DatBOnderneming" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                 *                   &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                 *                   &lt;element name="DatEOnderneming" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                 *                   &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                 *                   &lt;element name="Sbiklasse" maxOccurs="unbounded" minOccurs="0"&gt;
                 *                     &lt;complexType&gt;
                 *                       &lt;complexContent&gt;
                 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                 *                           &lt;sequence&gt;
                 *                             &lt;element name="CdSbi" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdSbi" minOccurs="0"/&gt;
                 *                             &lt;element name="OmsSbi" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar300" minOccurs="0"/&gt;
                 *                             &lt;element name="IndSbiHoofdactiviteit" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdIndJN_nocodes" minOccurs="0"/&gt;
                 *                             &lt;element name="DatBSbiactiviteit" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                 *                             &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                 *                             &lt;element name="DatESbiactiviteit" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                 *                             &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                 *                           &lt;/sequence&gt;
                 *                         &lt;/restriction&gt;
                 *                       &lt;/complexContent&gt;
                 *                     &lt;/complexType&gt;
                 *                   &lt;/element&gt;
                 *                   &lt;element name="Handelsnaam" maxOccurs="unbounded" minOccurs="0"&gt;
                 *                     &lt;complexType&gt;
                 *                       &lt;complexContent&gt;
                 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                 *                           &lt;sequence&gt;
                 *                             &lt;element name="Handelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar625" minOccurs="0"/&gt;
                 *                             &lt;element name="VolgordeHandelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdAantNietNegatiefVar4" minOccurs="0"/&gt;
                 *                             &lt;element name="DatBHandelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                 *                             &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                 *                             &lt;element name="DatEHandelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                 *                             &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                 *                           &lt;/sequence&gt;
                 *                         &lt;/restriction&gt;
                 *                       &lt;/complexContent&gt;
                 *                     &lt;/complexType&gt;
                 *                   &lt;/element&gt;
                 *                 &lt;/sequence&gt;
                 *               &lt;/restriction&gt;
                 *             &lt;/complexContent&gt;
                 *           &lt;/complexType&gt;
                 *         &lt;/element&gt;
                 *         &lt;element name="Handelsnaam" maxOccurs="unbounded" minOccurs="0"&gt;
                 *           &lt;complexType&gt;
                 *             &lt;complexContent&gt;
                 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                 *                 &lt;sequence&gt;
                 *                   &lt;element name="Handelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar625" minOccurs="0"/&gt;
                 *                   &lt;element name="VolgordeHandelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdAantNietNegatiefVar4" minOccurs="0"/&gt;
                 *                   &lt;element name="DatBHandelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                 *                   &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                 *                   &lt;element name="DatEHandelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                 *                   &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                 *                 &lt;/sequence&gt;
                 *               &lt;/restriction&gt;
                 *             &lt;/complexContent&gt;
                 *           &lt;/complexType&gt;
                 *         &lt;/element&gt;
                 *       &lt;/sequence&gt;
                 *     &lt;/restriction&gt;
                 *   &lt;/complexContent&gt;
                 * &lt;/complexType&gt;
                 * </pre>
                 * 
                 * 
                 */
                @XmlAccessorType(XmlAccessType.FIELD)
                @XmlType(name = "", propOrder = {
                    "vestigingsnrHandelsregister",
                    "eersteHandelsnaam",
                    "datBVestigingHandelsregister",
                    "cdFictieveDatB",
                    "datEVestigingHandelsregister",
                    "cdFictieveDatE",
                    "adreshouding",
                    "activiteitHandelsregister",
                    "onderneming",
                    "handelsnaam"
                })
                public static class VestigingHandelsregister {

                    @XmlElement(name = "VestigingsnrHandelsregister")
                    @Size(min = 12, max = 12)
                    @Pattern(regexp = "[0-9]*")
                    protected String vestigingsnrHandelsregister;
                    @XmlElement(name = "EersteHandelsnaam")
                    @Size(max = 200)
                    protected String eersteHandelsnaam;
                    @XmlElement(name = "DatBVestigingHandelsregister")
                    @Size(max = 8)
                    protected String datBVestigingHandelsregister;
                    @XmlElement(name = "CdFictieveDatB")
                    @Size(min = 1, max = 1)
                    @Pattern(regexp = "\\d*")
                    protected String cdFictieveDatB;
                    @XmlElement(name = "DatEVestigingHandelsregister")
                    @Size(max = 8)
                    protected String datEVestigingHandelsregister;
                    @XmlElement(name = "CdFictieveDatE")
                    @Size(min = 1, max = 1)
                    @Pattern(regexp = "\\d*")
                    protected String cdFictieveDatE;
                    @XmlElement(name = "Adreshouding")
                    @Valid
                    protected List<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding> adreshouding;
                    @XmlElement(name = "ActiviteitHandelsregister")
                    @Valid
                    protected CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.ActiviteitHandelsregister activiteitHandelsregister;
                    @XmlElement(name = "Onderneming")
                    @Valid
                    protected List<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Onderneming> onderneming;
                    @XmlElement(name = "Handelsnaam")
                    @Valid
                    protected List<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Handelsnaam> handelsnaam;

                    /**
                     * Gets the value of the vestigingsnrHandelsregister property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getVestigingsnrHandelsregister() {
                        return vestigingsnrHandelsregister;
                    }

                    /**
                     * Sets the value of the vestigingsnrHandelsregister property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setVestigingsnrHandelsregister(String value) {
                        this.vestigingsnrHandelsregister = value;
                    }

                    /**
                     * Gets the value of the eersteHandelsnaam property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getEersteHandelsnaam() {
                        return eersteHandelsnaam;
                    }

                    /**
                     * Sets the value of the eersteHandelsnaam property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setEersteHandelsnaam(String value) {
                        this.eersteHandelsnaam = value;
                    }

                    /**
                     * Gets the value of the datBVestigingHandelsregister property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getDatBVestigingHandelsregister() {
                        return datBVestigingHandelsregister;
                    }

                    /**
                     * Sets the value of the datBVestigingHandelsregister property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setDatBVestigingHandelsregister(String value) {
                        this.datBVestigingHandelsregister = value;
                    }

                    /**
                     * Gets the value of the cdFictieveDatB property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getCdFictieveDatB() {
                        return cdFictieveDatB;
                    }

                    /**
                     * Sets the value of the cdFictieveDatB property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setCdFictieveDatB(String value) {
                        this.cdFictieveDatB = value;
                    }

                    /**
                     * Gets the value of the datEVestigingHandelsregister property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getDatEVestigingHandelsregister() {
                        return datEVestigingHandelsregister;
                    }

                    /**
                     * Sets the value of the datEVestigingHandelsregister property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setDatEVestigingHandelsregister(String value) {
                        this.datEVestigingHandelsregister = value;
                    }

                    /**
                     * Gets the value of the cdFictieveDatE property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getCdFictieveDatE() {
                        return cdFictieveDatE;
                    }

                    /**
                     * Sets the value of the cdFictieveDatE property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setCdFictieveDatE(String value) {
                        this.cdFictieveDatE = value;
                    }

                    /**
                     * Gets the value of the adreshouding property.
                     * 
                     * <p>
                     * This accessor method returns a reference to the live list,
                     * not a snapshot. Therefore any modification you make to the
                     * returned list will be present inside the JAXB object.
                     * This is why there is not a <CODE>set</CODE> method for the adreshouding property.
                     * 
                     * <p>
                     * For example, to add a new item, do as follows:
                     * <pre>
                     *    getAdreshouding().add(newItem);
                     * </pre>
                     * 
                     * 
                     * <p>
                     * Objects of the following type(s) are allowed in the list
                     * {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding }
                     * 
                     * 
                     */
                    public List<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding> getAdreshouding() {
                        if (adreshouding == null) {
                            adreshouding = new ArrayList<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding>();
                        }
                        return this.adreshouding;
                    }

                    /**
                     * Gets the value of the activiteitHandelsregister property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.ActiviteitHandelsregister }
                     *     
                     */
                    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.ActiviteitHandelsregister getActiviteitHandelsregister() {
                        return activiteitHandelsregister;
                    }

                    /**
                     * Sets the value of the activiteitHandelsregister property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.ActiviteitHandelsregister }
                     *     
                     */
                    public void setActiviteitHandelsregister(CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.ActiviteitHandelsregister value) {
                        this.activiteitHandelsregister = value;
                    }

                    /**
                     * Gets the value of the onderneming property.
                     * 
                     * <p>
                     * This accessor method returns a reference to the live list,
                     * not a snapshot. Therefore any modification you make to the
                     * returned list will be present inside the JAXB object.
                     * This is why there is not a <CODE>set</CODE> method for the onderneming property.
                     * 
                     * <p>
                     * For example, to add a new item, do as follows:
                     * <pre>
                     *    getOnderneming().add(newItem);
                     * </pre>
                     * 
                     * 
                     * <p>
                     * Objects of the following type(s) are allowed in the list
                     * {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Onderneming }
                     * 
                     * 
                     */
                    public List<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Onderneming> getOnderneming() {
                        if (onderneming == null) {
                            onderneming = new ArrayList<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Onderneming>();
                        }
                        return this.onderneming;
                    }

                    /**
                     * Gets the value of the handelsnaam property.
                     * 
                     * <p>
                     * This accessor method returns a reference to the live list,
                     * not a snapshot. Therefore any modification you make to the
                     * returned list will be present inside the JAXB object.
                     * This is why there is not a <CODE>set</CODE> method for the handelsnaam property.
                     * 
                     * <p>
                     * For example, to add a new item, do as follows:
                     * <pre>
                     *    getHandelsnaam().add(newItem);
                     * </pre>
                     * 
                     * 
                     * <p>
                     * Objects of the following type(s) are allowed in the list
                     * {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Handelsnaam }
                     * 
                     * 
                     */
                    public List<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Handelsnaam> getHandelsnaam() {
                        if (handelsnaam == null) {
                            handelsnaam = new ArrayList<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Handelsnaam>();
                        }
                        return this.handelsnaam;
                    }


                    /**
                     * <p>Java class for anonymous complex type.
                     * 
                     * <p>The following schema fragment specifies the expected content contained within this class.
                     * 
                     * <pre>
                     * &lt;complexType&gt;
                     *   &lt;complexContent&gt;
                     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                     *       &lt;sequence&gt;
                     *         &lt;element name="OmsActiviteitHandelsregister" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdTekstAnVar2000" minOccurs="0"/&gt;
                     *         &lt;element name="Sbiklasse" maxOccurs="unbounded" minOccurs="0"&gt;
                     *           &lt;complexType&gt;
                     *             &lt;complexContent&gt;
                     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                     *                 &lt;sequence&gt;
                     *                   &lt;element name="CdSbi" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdSbi" minOccurs="0"/&gt;
                     *                   &lt;element name="OmsSbi" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar300" minOccurs="0"/&gt;
                     *                   &lt;element name="IndSbiHoofdactiviteit" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdIndJN_nocodes" minOccurs="0"/&gt;
                     *                   &lt;element name="DatBSbiactiviteit" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                     *                   &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                     *                   &lt;element name="DatESbiactiviteit" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                     *                   &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                     *                 &lt;/sequence&gt;
                     *               &lt;/restriction&gt;
                     *             &lt;/complexContent&gt;
                     *           &lt;/complexType&gt;
                     *         &lt;/element&gt;
                     *       &lt;/sequence&gt;
                     *     &lt;/restriction&gt;
                     *   &lt;/complexContent&gt;
                     * &lt;/complexType&gt;
                     * </pre>
                     * 
                     * 
                     */
                    @XmlAccessorType(XmlAccessType.FIELD)
                    @XmlType(name = "", propOrder = {
                        "omsActiviteitHandelsregister",
                        "sbiklasse"
                    })
                    public static class ActiviteitHandelsregister {

                        @XmlElement(name = "OmsActiviteitHandelsregister")
                        @Size(max = 2000)
                        protected String omsActiviteitHandelsregister;
                        @XmlElement(name = "Sbiklasse")
                        @Valid
                        protected List<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.ActiviteitHandelsregister.Sbiklasse> sbiklasse;

                        /**
                         * Gets the value of the omsActiviteitHandelsregister property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getOmsActiviteitHandelsregister() {
                            return omsActiviteitHandelsregister;
                        }

                        /**
                         * Sets the value of the omsActiviteitHandelsregister property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setOmsActiviteitHandelsregister(String value) {
                            this.omsActiviteitHandelsregister = value;
                        }

                        /**
                         * Gets the value of the sbiklasse property.
                         * 
                         * <p>
                         * This accessor method returns a reference to the live list,
                         * not a snapshot. Therefore any modification you make to the
                         * returned list will be present inside the JAXB object.
                         * This is why there is not a <CODE>set</CODE> method for the sbiklasse property.
                         * 
                         * <p>
                         * For example, to add a new item, do as follows:
                         * <pre>
                         *    getSbiklasse().add(newItem);
                         * </pre>
                         * 
                         * 
                         * <p>
                         * Objects of the following type(s) are allowed in the list
                         * {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.ActiviteitHandelsregister.Sbiklasse }
                         * 
                         * 
                         */
                        public List<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.ActiviteitHandelsregister.Sbiklasse> getSbiklasse() {
                            if (sbiklasse == null) {
                                sbiklasse = new ArrayList<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.ActiviteitHandelsregister.Sbiklasse>();
                            }
                            return this.sbiklasse;
                        }


                        /**
                         * <p>Java class for anonymous complex type.
                         * 
                         * <p>The following schema fragment specifies the expected content contained within this class.
                         * 
                         * <pre>
                         * &lt;complexType&gt;
                         *   &lt;complexContent&gt;
                         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                         *       &lt;sequence&gt;
                         *         &lt;element name="CdSbi" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdSbi" minOccurs="0"/&gt;
                         *         &lt;element name="OmsSbi" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar300" minOccurs="0"/&gt;
                         *         &lt;element name="IndSbiHoofdactiviteit" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdIndJN_nocodes" minOccurs="0"/&gt;
                         *         &lt;element name="DatBSbiactiviteit" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                         *         &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                         *         &lt;element name="DatESbiactiviteit" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                         *         &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                         *       &lt;/sequence&gt;
                         *     &lt;/restriction&gt;
                         *   &lt;/complexContent&gt;
                         * &lt;/complexType&gt;
                         * </pre>
                         * 
                         * 
                         */
                        @XmlAccessorType(XmlAccessType.FIELD)
                        @XmlType(name = "", propOrder = {
                            "cdSbi",
                            "omsSbi",
                            "indSbiHoofdactiviteit",
                            "datBSbiactiviteit",
                            "cdFictieveDatB",
                            "datESbiactiviteit",
                            "cdFictieveDatE"
                        })
                        public static class Sbiklasse {

                            @XmlElement(name = "CdSbi")
                            @Size(max = 5)
                            @Pattern(regexp = "[0-9]*")
                            protected String cdSbi;
                            @XmlElement(name = "OmsSbi")
                            @Size(max = 300)
                            protected String omsSbi;
                            @XmlElement(name = "IndSbiHoofdactiviteit")
                            @Size(min = 1, max = 1)
                            @Pattern(regexp = "[0-9]*")
                            protected String indSbiHoofdactiviteit;
                            @XmlElement(name = "DatBSbiactiviteit")
                            @Size(max = 8)
                            protected String datBSbiactiviteit;
                            @XmlElement(name = "CdFictieveDatB")
                            @Size(min = 1, max = 1)
                            @Pattern(regexp = "\\d*")
                            protected String cdFictieveDatB;
                            @XmlElement(name = "DatESbiactiviteit")
                            @Size(max = 8)
                            protected String datESbiactiviteit;
                            @XmlElement(name = "CdFictieveDatE")
                            @Size(min = 1, max = 1)
                            @Pattern(regexp = "\\d*")
                            protected String cdFictieveDatE;

                            /**
                             * Gets the value of the cdSbi property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getCdSbi() {
                                return cdSbi;
                            }

                            /**
                             * Sets the value of the cdSbi property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setCdSbi(String value) {
                                this.cdSbi = value;
                            }

                            /**
                             * Gets the value of the omsSbi property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getOmsSbi() {
                                return omsSbi;
                            }

                            /**
                             * Sets the value of the omsSbi property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setOmsSbi(String value) {
                                this.omsSbi = value;
                            }

                            /**
                             * Gets the value of the indSbiHoofdactiviteit property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getIndSbiHoofdactiviteit() {
                                return indSbiHoofdactiviteit;
                            }

                            /**
                             * Sets the value of the indSbiHoofdactiviteit property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setIndSbiHoofdactiviteit(String value) {
                                this.indSbiHoofdactiviteit = value;
                            }

                            /**
                             * Gets the value of the datBSbiactiviteit property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getDatBSbiactiviteit() {
                                return datBSbiactiviteit;
                            }

                            /**
                             * Sets the value of the datBSbiactiviteit property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setDatBSbiactiviteit(String value) {
                                this.datBSbiactiviteit = value;
                            }

                            /**
                             * Gets the value of the cdFictieveDatB property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getCdFictieveDatB() {
                                return cdFictieveDatB;
                            }

                            /**
                             * Sets the value of the cdFictieveDatB property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setCdFictieveDatB(String value) {
                                this.cdFictieveDatB = value;
                            }

                            /**
                             * Gets the value of the datESbiactiviteit property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getDatESbiactiviteit() {
                                return datESbiactiviteit;
                            }

                            /**
                             * Sets the value of the datESbiactiviteit property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setDatESbiactiviteit(String value) {
                                this.datESbiactiviteit = value;
                            }

                            /**
                             * Gets the value of the cdFictieveDatE property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getCdFictieveDatE() {
                                return cdFictieveDatE;
                            }

                            /**
                             * Sets the value of the cdFictieveDatE property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setCdFictieveDatE(String value) {
                                this.cdFictieveDatE = value;
                            }

                        }

                    }


                    /**
                     * <p>Java class for anonymous complex type.
                     * 
                     * <p>The following schema fragment specifies the expected content contained within this class.
                     * 
                     * <pre>
                     * &lt;complexType&gt;
                     *   &lt;complexContent&gt;
                     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                     *       &lt;sequence&gt;
                     *         &lt;choice&gt;
                     *           &lt;element name="AdresNederlandUhr"&gt;
                     *             &lt;complexType&gt;
                     *               &lt;complexContent&gt;
                     *                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                     *                   &lt;sequence&gt;
                     *                     &lt;element name="CdAdresrol" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAdresrol_nocodes" minOccurs="0"/&gt;
                     *                     &lt;element name="DatBAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                     *                     &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                     *                     &lt;element name="DatEAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                     *                     &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                     *                     &lt;element name="CdAfgeschermdAdres" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdOJNNvt_nocodes" minOccurs="0"/&gt;
                     *                     &lt;choice minOccurs="0"&gt;
                     *                       &lt;element name="StraatadresUhr" minOccurs="0"&gt;
                     *                         &lt;complexType&gt;
                     *                           &lt;complexContent&gt;
                     *                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                     *                               &lt;sequence&gt;
                     *                                 &lt;element name="Postcd" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcd" minOccurs="0"/&gt;
                     *                                 &lt;element name="Woonplaatsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
                     *                                 &lt;element name="Straatnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdStraatnaam" minOccurs="0"/&gt;
                     *                                 &lt;element name="Huisnr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisnr" minOccurs="0"/&gt;
                     *                                 &lt;element name="Huisletter" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisletter" minOccurs="0"/&gt;
                     *                                 &lt;element name="Huisnrtoevoeging" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar4" minOccurs="0"/&gt;
                     *                                 &lt;element name="CdAanduidingBijHuisnr" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAanduidingBijHuisnr_nocodes" minOccurs="0"/&gt;
                     *                                 &lt;element name="NaamOpenbareRuimte" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar80" minOccurs="0"/&gt;
                     *                               &lt;/sequence&gt;
                     *                             &lt;/restriction&gt;
                     *                           &lt;/complexContent&gt;
                     *                         &lt;/complexType&gt;
                     *                       &lt;/element&gt;
                     *                       &lt;element name="PostbusadresUhr" minOccurs="0"&gt;
                     *                         &lt;complexType&gt;
                     *                           &lt;complexContent&gt;
                     *                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                     *                               &lt;sequence&gt;
                     *                                 &lt;element name="Postcd" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcd" minOccurs="0"/&gt;
                     *                                 &lt;element name="Woonplaatsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
                     *                                 &lt;element name="Postbusnr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostbusnr" minOccurs="0"/&gt;
                     *                               &lt;/sequence&gt;
                     *                             &lt;/restriction&gt;
                     *                           &lt;/complexContent&gt;
                     *                         &lt;/complexType&gt;
                     *                       &lt;/element&gt;
                     *                     &lt;/choice&gt;
                     *                   &lt;/sequence&gt;
                     *                 &lt;/restriction&gt;
                     *               &lt;/complexContent&gt;
                     *             &lt;/complexType&gt;
                     *           &lt;/element&gt;
                     *           &lt;element name="AdresBuitenlandUhr"&gt;
                     *             &lt;complexType&gt;
                     *               &lt;complexContent&gt;
                     *                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                     *                   &lt;sequence&gt;
                     *                     &lt;element name="CdAdresrol" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAdresrol_nocodes" minOccurs="0"/&gt;
                     *                     &lt;element name="DatBAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                     *                     &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                     *                     &lt;element name="DatEAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                     *                     &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                     *                     &lt;element name="CdAfgeschermdAdres" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdOJNNvt_nocodes" minOccurs="0"/&gt;
                     *                     &lt;choice minOccurs="0"&gt;
                     *                       &lt;element name="StraatadresBuitenlandUhr" minOccurs="0"&gt;
                     *                         &lt;complexType&gt;
                     *                           &lt;complexContent&gt;
                     *                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                     *                               &lt;sequence&gt;
                     *                                 &lt;element name="PostcdBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcdBuitenland" minOccurs="0"/&gt;
                     *                                 &lt;element name="WoonplaatsnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
                     *                                 &lt;element name="RegionaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar24" minOccurs="0"/&gt;
                     *                                 &lt;element name="LandcodeGba" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeGba" minOccurs="0"/&gt;
                     *                                 &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
                     *                                 &lt;element name="Landsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandsnaam" minOccurs="0"/&gt;
                     *                                 &lt;element name="StraatnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdStraatnaam" minOccurs="0"/&gt;
                     *                                 &lt;element name="HuisnrBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisnrBuitenland" minOccurs="0"/&gt;
                     *                                 &lt;element name="LocatieomsBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar128" minOccurs="0"/&gt;
                     *                               &lt;/sequence&gt;
                     *                             &lt;/restriction&gt;
                     *                           &lt;/complexContent&gt;
                     *                         &lt;/complexType&gt;
                     *                       &lt;/element&gt;
                     *                       &lt;element name="PostbusadresBuitenlandUhr" minOccurs="0"&gt;
                     *                         &lt;complexType&gt;
                     *                           &lt;complexContent&gt;
                     *                             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                     *                               &lt;sequence&gt;
                     *                                 &lt;element name="PostcdBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcdBuitenland" minOccurs="0"/&gt;
                     *                                 &lt;element name="WoonplaatsnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
                     *                                 &lt;element name="RegionaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar24" minOccurs="0"/&gt;
                     *                                 &lt;element name="LandcodeGba" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeGba" minOccurs="0"/&gt;
                     *                                 &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
                     *                                 &lt;element name="Landsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandsnaam" minOccurs="0"/&gt;
                     *                                 &lt;element name="PostbusnrBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdReferentienrAnVar8" minOccurs="0"/&gt;
                     *                               &lt;/sequence&gt;
                     *                             &lt;/restriction&gt;
                     *                           &lt;/complexContent&gt;
                     *                         &lt;/complexType&gt;
                     *                       &lt;/element&gt;
                     *                     &lt;/choice&gt;
                     *                   &lt;/sequence&gt;
                     *                 &lt;/restriction&gt;
                     *               &lt;/complexContent&gt;
                     *             &lt;/complexType&gt;
                     *           &lt;/element&gt;
                     *           &lt;element name="AdresBuitenlandOngestructureerdUhr"&gt;
                     *             &lt;complexType&gt;
                     *               &lt;complexContent&gt;
                     *                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                     *                   &lt;sequence&gt;
                     *                     &lt;element name="CdAdresrol" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAdresrol_nocodes" minOccurs="0"/&gt;
                     *                     &lt;element name="DatBAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                     *                     &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                     *                     &lt;element name="DatEAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                     *                     &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                     *                     &lt;element name="CdAfgeschermdAdres" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdOJNNvt_nocodes" minOccurs="0"/&gt;
                     *                     &lt;element name="Adresregel1Buitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar35" minOccurs="0"/&gt;
                     *                     &lt;element name="Adresregel2Buitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar35" minOccurs="0"/&gt;
                     *                     &lt;element name="Adresregel3Buitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar35" minOccurs="0"/&gt;
                     *                     &lt;element name="LandcodeGba" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeGba" minOccurs="0"/&gt;
                     *                     &lt;element name="LandsnaamGba" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar40" minOccurs="0"/&gt;
                     *                     &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
                     *                     &lt;element name="Landsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandsnaam" minOccurs="0"/&gt;
                     *                   &lt;/sequence&gt;
                     *                 &lt;/restriction&gt;
                     *               &lt;/complexContent&gt;
                     *             &lt;/complexType&gt;
                     *           &lt;/element&gt;
                     *         &lt;/choice&gt;
                     *       &lt;/sequence&gt;
                     *     &lt;/restriction&gt;
                     *   &lt;/complexContent&gt;
                     * &lt;/complexType&gt;
                     * </pre>
                     * 
                     * 
                     */
                    @XmlAccessorType(XmlAccessType.FIELD)
                    @XmlType(name = "", propOrder = {
                        "adresNederlandUhr",
                        "adresBuitenlandUhr",
                        "adresBuitenlandOngestructureerdUhr"
                    })
                    public static class Adreshouding {

                        @XmlElement(name = "AdresNederlandUhr")
                        @Valid
                        protected CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresNederlandUhr adresNederlandUhr;
                        @XmlElement(name = "AdresBuitenlandUhr")
                        @Valid
                        protected CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresBuitenlandUhr adresBuitenlandUhr;
                        @XmlElement(name = "AdresBuitenlandOngestructureerdUhr")
                        @Valid
                        protected CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresBuitenlandOngestructureerdUhr adresBuitenlandOngestructureerdUhr;

                        /**
                         * Gets the value of the adresNederlandUhr property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresNederlandUhr }
                         *     
                         */
                        public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresNederlandUhr getAdresNederlandUhr() {
                            return adresNederlandUhr;
                        }

                        /**
                         * Sets the value of the adresNederlandUhr property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresNederlandUhr }
                         *     
                         */
                        public void setAdresNederlandUhr(CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresNederlandUhr value) {
                            this.adresNederlandUhr = value;
                        }

                        /**
                         * Gets the value of the adresBuitenlandUhr property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresBuitenlandUhr }
                         *     
                         */
                        public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresBuitenlandUhr getAdresBuitenlandUhr() {
                            return adresBuitenlandUhr;
                        }

                        /**
                         * Sets the value of the adresBuitenlandUhr property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresBuitenlandUhr }
                         *     
                         */
                        public void setAdresBuitenlandUhr(CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresBuitenlandUhr value) {
                            this.adresBuitenlandUhr = value;
                        }

                        /**
                         * Gets the value of the adresBuitenlandOngestructureerdUhr property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresBuitenlandOngestructureerdUhr }
                         *     
                         */
                        public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresBuitenlandOngestructureerdUhr getAdresBuitenlandOngestructureerdUhr() {
                            return adresBuitenlandOngestructureerdUhr;
                        }

                        /**
                         * Sets the value of the adresBuitenlandOngestructureerdUhr property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresBuitenlandOngestructureerdUhr }
                         *     
                         */
                        public void setAdresBuitenlandOngestructureerdUhr(CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresBuitenlandOngestructureerdUhr value) {
                            this.adresBuitenlandOngestructureerdUhr = value;
                        }


                        /**
                         * <p>Java class for anonymous complex type.
                         * 
                         * <p>The following schema fragment specifies the expected content contained within this class.
                         * 
                         * <pre>
                         * &lt;complexType&gt;
                         *   &lt;complexContent&gt;
                         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                         *       &lt;sequence&gt;
                         *         &lt;element name="CdAdresrol" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAdresrol_nocodes" minOccurs="0"/&gt;
                         *         &lt;element name="DatBAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                         *         &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                         *         &lt;element name="DatEAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                         *         &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                         *         &lt;element name="CdAfgeschermdAdres" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdOJNNvt_nocodes" minOccurs="0"/&gt;
                         *         &lt;element name="Adresregel1Buitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar35" minOccurs="0"/&gt;
                         *         &lt;element name="Adresregel2Buitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar35" minOccurs="0"/&gt;
                         *         &lt;element name="Adresregel3Buitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar35" minOccurs="0"/&gt;
                         *         &lt;element name="LandcodeGba" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeGba" minOccurs="0"/&gt;
                         *         &lt;element name="LandsnaamGba" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar40" minOccurs="0"/&gt;
                         *         &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
                         *         &lt;element name="Landsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandsnaam" minOccurs="0"/&gt;
                         *       &lt;/sequence&gt;
                         *     &lt;/restriction&gt;
                         *   &lt;/complexContent&gt;
                         * &lt;/complexType&gt;
                         * </pre>
                         * 
                         * 
                         */
                        @XmlAccessorType(XmlAccessType.FIELD)
                        @XmlType(name = "", propOrder = {
                            "cdAdresrol",
                            "datBAdreshouding",
                            "cdFictieveDatB",
                            "datEAdreshouding",
                            "cdFictieveDatE",
                            "cdAfgeschermdAdres",
                            "adresregel1Buitenland",
                            "adresregel2Buitenland",
                            "adresregel3Buitenland",
                            "landcodeGba",
                            "landsnaamGba",
                            "landcodeIso",
                            "landsnaam"
                        })
                        public static class AdresBuitenlandOngestructureerdUhr {

                            @XmlElement(name = "CdAdresrol")
                            @Size(min = 1, max = 1)
                            @Pattern(regexp = "\\D*")
                            protected String cdAdresrol;
                            @XmlElement(name = "DatBAdreshouding")
                            @Size(max = 8)
                            protected String datBAdreshouding;
                            @XmlElement(name = "CdFictieveDatB")
                            @Size(min = 1, max = 1)
                            @Pattern(regexp = "\\d*")
                            protected String cdFictieveDatB;
                            @XmlElement(name = "DatEAdreshouding")
                            @Size(max = 8)
                            protected String datEAdreshouding;
                            @XmlElement(name = "CdFictieveDatE")
                            @Size(min = 1, max = 1)
                            @Pattern(regexp = "\\d*")
                            protected String cdFictieveDatE;
                            @XmlElement(name = "CdAfgeschermdAdres")
                            @Size(min = 1, max = 1)
                            @Pattern(regexp = "\\d*")
                            protected String cdAfgeschermdAdres;
                            @XmlElement(name = "Adresregel1Buitenland")
                            @Size(max = 35)
                            protected String adresregel1Buitenland;
                            @XmlElement(name = "Adresregel2Buitenland")
                            @Size(max = 35)
                            protected String adresregel2Buitenland;
                            @XmlElement(name = "Adresregel3Buitenland")
                            @Size(max = 35)
                            protected String adresregel3Buitenland;
                            @XmlElement(name = "LandcodeGba")
                            @Size(min = 4, max = 4)
                            @Pattern(regexp = "[0-9]*")
                            protected String landcodeGba;
                            @XmlElement(name = "LandsnaamGba")
                            @Size(max = 40)
                            protected String landsnaamGba;
                            @XmlElement(name = "LandcodeIso")
                            @Size(min = 2, max = 2)
                            @Pattern(regexp = "[A-Z]*")
                            protected String landcodeIso;
                            @XmlElement(name = "Landsnaam")
                            @Size(max = 40)
                            protected String landsnaam;

                            /**
                             * Gets the value of the cdAdresrol property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getCdAdresrol() {
                                return cdAdresrol;
                            }

                            /**
                             * Sets the value of the cdAdresrol property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setCdAdresrol(String value) {
                                this.cdAdresrol = value;
                            }

                            /**
                             * Gets the value of the datBAdreshouding property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getDatBAdreshouding() {
                                return datBAdreshouding;
                            }

                            /**
                             * Sets the value of the datBAdreshouding property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setDatBAdreshouding(String value) {
                                this.datBAdreshouding = value;
                            }

                            /**
                             * Gets the value of the cdFictieveDatB property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getCdFictieveDatB() {
                                return cdFictieveDatB;
                            }

                            /**
                             * Sets the value of the cdFictieveDatB property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setCdFictieveDatB(String value) {
                                this.cdFictieveDatB = value;
                            }

                            /**
                             * Gets the value of the datEAdreshouding property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getDatEAdreshouding() {
                                return datEAdreshouding;
                            }

                            /**
                             * Sets the value of the datEAdreshouding property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setDatEAdreshouding(String value) {
                                this.datEAdreshouding = value;
                            }

                            /**
                             * Gets the value of the cdFictieveDatE property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getCdFictieveDatE() {
                                return cdFictieveDatE;
                            }

                            /**
                             * Sets the value of the cdFictieveDatE property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setCdFictieveDatE(String value) {
                                this.cdFictieveDatE = value;
                            }

                            /**
                             * Gets the value of the cdAfgeschermdAdres property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getCdAfgeschermdAdres() {
                                return cdAfgeschermdAdres;
                            }

                            /**
                             * Sets the value of the cdAfgeschermdAdres property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setCdAfgeschermdAdres(String value) {
                                this.cdAfgeschermdAdres = value;
                            }

                            /**
                             * Gets the value of the adresregel1Buitenland property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getAdresregel1Buitenland() {
                                return adresregel1Buitenland;
                            }

                            /**
                             * Sets the value of the adresregel1Buitenland property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setAdresregel1Buitenland(String value) {
                                this.adresregel1Buitenland = value;
                            }

                            /**
                             * Gets the value of the adresregel2Buitenland property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getAdresregel2Buitenland() {
                                return adresregel2Buitenland;
                            }

                            /**
                             * Sets the value of the adresregel2Buitenland property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setAdresregel2Buitenland(String value) {
                                this.adresregel2Buitenland = value;
                            }

                            /**
                             * Gets the value of the adresregel3Buitenland property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getAdresregel3Buitenland() {
                                return adresregel3Buitenland;
                            }

                            /**
                             * Sets the value of the adresregel3Buitenland property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setAdresregel3Buitenland(String value) {
                                this.adresregel3Buitenland = value;
                            }

                            /**
                             * Gets the value of the landcodeGba property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getLandcodeGba() {
                                return landcodeGba;
                            }

                            /**
                             * Sets the value of the landcodeGba property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setLandcodeGba(String value) {
                                this.landcodeGba = value;
                            }

                            /**
                             * Gets the value of the landsnaamGba property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getLandsnaamGba() {
                                return landsnaamGba;
                            }

                            /**
                             * Sets the value of the landsnaamGba property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setLandsnaamGba(String value) {
                                this.landsnaamGba = value;
                            }

                            /**
                             * Gets the value of the landcodeIso property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getLandcodeIso() {
                                return landcodeIso;
                            }

                            /**
                             * Sets the value of the landcodeIso property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setLandcodeIso(String value) {
                                this.landcodeIso = value;
                            }

                            /**
                             * Gets the value of the landsnaam property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getLandsnaam() {
                                return landsnaam;
                            }

                            /**
                             * Sets the value of the landsnaam property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setLandsnaam(String value) {
                                this.landsnaam = value;
                            }

                        }


                        /**
                         * <p>Java class for anonymous complex type.
                         * 
                         * <p>The following schema fragment specifies the expected content contained within this class.
                         * 
                         * <pre>
                         * &lt;complexType&gt;
                         *   &lt;complexContent&gt;
                         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                         *       &lt;sequence&gt;
                         *         &lt;element name="CdAdresrol" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAdresrol_nocodes" minOccurs="0"/&gt;
                         *         &lt;element name="DatBAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                         *         &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                         *         &lt;element name="DatEAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                         *         &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                         *         &lt;element name="CdAfgeschermdAdres" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdOJNNvt_nocodes" minOccurs="0"/&gt;
                         *         &lt;choice minOccurs="0"&gt;
                         *           &lt;element name="StraatadresBuitenlandUhr" minOccurs="0"&gt;
                         *             &lt;complexType&gt;
                         *               &lt;complexContent&gt;
                         *                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                         *                   &lt;sequence&gt;
                         *                     &lt;element name="PostcdBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcdBuitenland" minOccurs="0"/&gt;
                         *                     &lt;element name="WoonplaatsnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
                         *                     &lt;element name="RegionaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar24" minOccurs="0"/&gt;
                         *                     &lt;element name="LandcodeGba" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeGba" minOccurs="0"/&gt;
                         *                     &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
                         *                     &lt;element name="Landsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandsnaam" minOccurs="0"/&gt;
                         *                     &lt;element name="StraatnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdStraatnaam" minOccurs="0"/&gt;
                         *                     &lt;element name="HuisnrBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisnrBuitenland" minOccurs="0"/&gt;
                         *                     &lt;element name="LocatieomsBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar128" minOccurs="0"/&gt;
                         *                   &lt;/sequence&gt;
                         *                 &lt;/restriction&gt;
                         *               &lt;/complexContent&gt;
                         *             &lt;/complexType&gt;
                         *           &lt;/element&gt;
                         *           &lt;element name="PostbusadresBuitenlandUhr" minOccurs="0"&gt;
                         *             &lt;complexType&gt;
                         *               &lt;complexContent&gt;
                         *                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                         *                   &lt;sequence&gt;
                         *                     &lt;element name="PostcdBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcdBuitenland" minOccurs="0"/&gt;
                         *                     &lt;element name="WoonplaatsnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
                         *                     &lt;element name="RegionaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar24" minOccurs="0"/&gt;
                         *                     &lt;element name="LandcodeGba" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeGba" minOccurs="0"/&gt;
                         *                     &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
                         *                     &lt;element name="Landsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandsnaam" minOccurs="0"/&gt;
                         *                     &lt;element name="PostbusnrBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdReferentienrAnVar8" minOccurs="0"/&gt;
                         *                   &lt;/sequence&gt;
                         *                 &lt;/restriction&gt;
                         *               &lt;/complexContent&gt;
                         *             &lt;/complexType&gt;
                         *           &lt;/element&gt;
                         *         &lt;/choice&gt;
                         *       &lt;/sequence&gt;
                         *     &lt;/restriction&gt;
                         *   &lt;/complexContent&gt;
                         * &lt;/complexType&gt;
                         * </pre>
                         * 
                         * 
                         */
                        @XmlAccessorType(XmlAccessType.FIELD)
                        @XmlType(name = "", propOrder = {
                            "cdAdresrol",
                            "datBAdreshouding",
                            "cdFictieveDatB",
                            "datEAdreshouding",
                            "cdFictieveDatE",
                            "cdAfgeschermdAdres",
                            "straatadresBuitenlandUhr",
                            "postbusadresBuitenlandUhr"
                        })
                        public static class AdresBuitenlandUhr {

                            @XmlElement(name = "CdAdresrol")
                            @Size(min = 1, max = 1)
                            @Pattern(regexp = "\\D*")
                            protected String cdAdresrol;
                            @XmlElement(name = "DatBAdreshouding")
                            @Size(max = 8)
                            protected String datBAdreshouding;
                            @XmlElement(name = "CdFictieveDatB")
                            @Size(min = 1, max = 1)
                            @Pattern(regexp = "\\d*")
                            protected String cdFictieveDatB;
                            @XmlElement(name = "DatEAdreshouding")
                            @Size(max = 8)
                            protected String datEAdreshouding;
                            @XmlElement(name = "CdFictieveDatE")
                            @Size(min = 1, max = 1)
                            @Pattern(regexp = "\\d*")
                            protected String cdFictieveDatE;
                            @XmlElement(name = "CdAfgeschermdAdres")
                            @Size(min = 1, max = 1)
                            @Pattern(regexp = "\\d*")
                            protected String cdAfgeschermdAdres;
                            @XmlElement(name = "StraatadresBuitenlandUhr")
                            @Valid
                            protected CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresBuitenlandUhr.StraatadresBuitenlandUhr straatadresBuitenlandUhr;
                            @XmlElement(name = "PostbusadresBuitenlandUhr")
                            @Valid
                            protected CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresBuitenlandUhr.PostbusadresBuitenlandUhr postbusadresBuitenlandUhr;

                            /**
                             * Gets the value of the cdAdresrol property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getCdAdresrol() {
                                return cdAdresrol;
                            }

                            /**
                             * Sets the value of the cdAdresrol property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setCdAdresrol(String value) {
                                this.cdAdresrol = value;
                            }

                            /**
                             * Gets the value of the datBAdreshouding property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getDatBAdreshouding() {
                                return datBAdreshouding;
                            }

                            /**
                             * Sets the value of the datBAdreshouding property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setDatBAdreshouding(String value) {
                                this.datBAdreshouding = value;
                            }

                            /**
                             * Gets the value of the cdFictieveDatB property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getCdFictieveDatB() {
                                return cdFictieveDatB;
                            }

                            /**
                             * Sets the value of the cdFictieveDatB property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setCdFictieveDatB(String value) {
                                this.cdFictieveDatB = value;
                            }

                            /**
                             * Gets the value of the datEAdreshouding property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getDatEAdreshouding() {
                                return datEAdreshouding;
                            }

                            /**
                             * Sets the value of the datEAdreshouding property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setDatEAdreshouding(String value) {
                                this.datEAdreshouding = value;
                            }

                            /**
                             * Gets the value of the cdFictieveDatE property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getCdFictieveDatE() {
                                return cdFictieveDatE;
                            }

                            /**
                             * Sets the value of the cdFictieveDatE property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setCdFictieveDatE(String value) {
                                this.cdFictieveDatE = value;
                            }

                            /**
                             * Gets the value of the cdAfgeschermdAdres property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getCdAfgeschermdAdres() {
                                return cdAfgeschermdAdres;
                            }

                            /**
                             * Sets the value of the cdAfgeschermdAdres property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setCdAfgeschermdAdres(String value) {
                                this.cdAfgeschermdAdres = value;
                            }

                            /**
                             * Gets the value of the straatadresBuitenlandUhr property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresBuitenlandUhr.StraatadresBuitenlandUhr }
                             *     
                             */
                            public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresBuitenlandUhr.StraatadresBuitenlandUhr getStraatadresBuitenlandUhr() {
                                return straatadresBuitenlandUhr;
                            }

                            /**
                             * Sets the value of the straatadresBuitenlandUhr property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresBuitenlandUhr.StraatadresBuitenlandUhr }
                             *     
                             */
                            public void setStraatadresBuitenlandUhr(CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresBuitenlandUhr.StraatadresBuitenlandUhr value) {
                                this.straatadresBuitenlandUhr = value;
                            }

                            /**
                             * Gets the value of the postbusadresBuitenlandUhr property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresBuitenlandUhr.PostbusadresBuitenlandUhr }
                             *     
                             */
                            public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresBuitenlandUhr.PostbusadresBuitenlandUhr getPostbusadresBuitenlandUhr() {
                                return postbusadresBuitenlandUhr;
                            }

                            /**
                             * Sets the value of the postbusadresBuitenlandUhr property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresBuitenlandUhr.PostbusadresBuitenlandUhr }
                             *     
                             */
                            public void setPostbusadresBuitenlandUhr(CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresBuitenlandUhr.PostbusadresBuitenlandUhr value) {
                                this.postbusadresBuitenlandUhr = value;
                            }


                            /**
                             * <p>Java class for anonymous complex type.
                             * 
                             * <p>The following schema fragment specifies the expected content contained within this class.
                             * 
                             * <pre>
                             * &lt;complexType&gt;
                             *   &lt;complexContent&gt;
                             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                             *       &lt;sequence&gt;
                             *         &lt;element name="PostcdBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcdBuitenland" minOccurs="0"/&gt;
                             *         &lt;element name="WoonplaatsnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
                             *         &lt;element name="RegionaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar24" minOccurs="0"/&gt;
                             *         &lt;element name="LandcodeGba" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeGba" minOccurs="0"/&gt;
                             *         &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
                             *         &lt;element name="Landsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandsnaam" minOccurs="0"/&gt;
                             *         &lt;element name="PostbusnrBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdReferentienrAnVar8" minOccurs="0"/&gt;
                             *       &lt;/sequence&gt;
                             *     &lt;/restriction&gt;
                             *   &lt;/complexContent&gt;
                             * &lt;/complexType&gt;
                             * </pre>
                             * 
                             * 
                             */
                            @XmlAccessorType(XmlAccessType.FIELD)
                            @XmlType(name = "", propOrder = {
                                "postcdBuitenland",
                                "woonplaatsnaamBuitenland",
                                "regionaamBuitenland",
                                "landcodeGba",
                                "landcodeIso",
                                "landsnaam",
                                "postbusnrBuitenland"
                            })
                            public static class PostbusadresBuitenlandUhr {

                                @XmlElement(name = "PostcdBuitenland")
                                @Size(max = 9)
                                protected String postcdBuitenland;
                                @XmlElement(name = "WoonplaatsnaamBuitenland")
                                @Size(max = 80)
                                protected String woonplaatsnaamBuitenland;
                                @XmlElement(name = "RegionaamBuitenland")
                                @Size(max = 24)
                                protected String regionaamBuitenland;
                                @XmlElement(name = "LandcodeGba")
                                @Size(min = 4, max = 4)
                                @Pattern(regexp = "[0-9]*")
                                protected String landcodeGba;
                                @XmlElement(name = "LandcodeIso")
                                @Size(min = 2, max = 2)
                                @Pattern(regexp = "[A-Z]*")
                                protected String landcodeIso;
                                @XmlElement(name = "Landsnaam")
                                @Size(max = 40)
                                protected String landsnaam;
                                @XmlElement(name = "PostbusnrBuitenland")
                                @Size(max = 8)
                                protected String postbusnrBuitenland;

                                /**
                                 * Gets the value of the postcdBuitenland property.
                                 * 
                                 * @return
                                 *     possible object is
                                 *     {@link String }
                                 *     
                                 */
                                public String getPostcdBuitenland() {
                                    return postcdBuitenland;
                                }

                                /**
                                 * Sets the value of the postcdBuitenland property.
                                 * 
                                 * @param value
                                 *     allowed object is
                                 *     {@link String }
                                 *     
                                 */
                                public void setPostcdBuitenland(String value) {
                                    this.postcdBuitenland = value;
                                }

                                /**
                                 * Gets the value of the woonplaatsnaamBuitenland property.
                                 * 
                                 * @return
                                 *     possible object is
                                 *     {@link String }
                                 *     
                                 */
                                public String getWoonplaatsnaamBuitenland() {
                                    return woonplaatsnaamBuitenland;
                                }

                                /**
                                 * Sets the value of the woonplaatsnaamBuitenland property.
                                 * 
                                 * @param value
                                 *     allowed object is
                                 *     {@link String }
                                 *     
                                 */
                                public void setWoonplaatsnaamBuitenland(String value) {
                                    this.woonplaatsnaamBuitenland = value;
                                }

                                /**
                                 * Gets the value of the regionaamBuitenland property.
                                 * 
                                 * @return
                                 *     possible object is
                                 *     {@link String }
                                 *     
                                 */
                                public String getRegionaamBuitenland() {
                                    return regionaamBuitenland;
                                }

                                /**
                                 * Sets the value of the regionaamBuitenland property.
                                 * 
                                 * @param value
                                 *     allowed object is
                                 *     {@link String }
                                 *     
                                 */
                                public void setRegionaamBuitenland(String value) {
                                    this.regionaamBuitenland = value;
                                }

                                /**
                                 * Gets the value of the landcodeGba property.
                                 * 
                                 * @return
                                 *     possible object is
                                 *     {@link String }
                                 *     
                                 */
                                public String getLandcodeGba() {
                                    return landcodeGba;
                                }

                                /**
                                 * Sets the value of the landcodeGba property.
                                 * 
                                 * @param value
                                 *     allowed object is
                                 *     {@link String }
                                 *     
                                 */
                                public void setLandcodeGba(String value) {
                                    this.landcodeGba = value;
                                }

                                /**
                                 * Gets the value of the landcodeIso property.
                                 * 
                                 * @return
                                 *     possible object is
                                 *     {@link String }
                                 *     
                                 */
                                public String getLandcodeIso() {
                                    return landcodeIso;
                                }

                                /**
                                 * Sets the value of the landcodeIso property.
                                 * 
                                 * @param value
                                 *     allowed object is
                                 *     {@link String }
                                 *     
                                 */
                                public void setLandcodeIso(String value) {
                                    this.landcodeIso = value;
                                }

                                /**
                                 * Gets the value of the landsnaam property.
                                 * 
                                 * @return
                                 *     possible object is
                                 *     {@link String }
                                 *     
                                 */
                                public String getLandsnaam() {
                                    return landsnaam;
                                }

                                /**
                                 * Sets the value of the landsnaam property.
                                 * 
                                 * @param value
                                 *     allowed object is
                                 *     {@link String }
                                 *     
                                 */
                                public void setLandsnaam(String value) {
                                    this.landsnaam = value;
                                }

                                /**
                                 * Gets the value of the postbusnrBuitenland property.
                                 * 
                                 * @return
                                 *     possible object is
                                 *     {@link String }
                                 *     
                                 */
                                public String getPostbusnrBuitenland() {
                                    return postbusnrBuitenland;
                                }

                                /**
                                 * Sets the value of the postbusnrBuitenland property.
                                 * 
                                 * @param value
                                 *     allowed object is
                                 *     {@link String }
                                 *     
                                 */
                                public void setPostbusnrBuitenland(String value) {
                                    this.postbusnrBuitenland = value;
                                }

                            }


                            /**
                             * <p>Java class for anonymous complex type.
                             * 
                             * <p>The following schema fragment specifies the expected content contained within this class.
                             * 
                             * <pre>
                             * &lt;complexType&gt;
                             *   &lt;complexContent&gt;
                             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                             *       &lt;sequence&gt;
                             *         &lt;element name="PostcdBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcdBuitenland" minOccurs="0"/&gt;
                             *         &lt;element name="WoonplaatsnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
                             *         &lt;element name="RegionaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar24" minOccurs="0"/&gt;
                             *         &lt;element name="LandcodeGba" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeGba" minOccurs="0"/&gt;
                             *         &lt;element name="LandcodeIso" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandcodeIso" minOccurs="0"/&gt;
                             *         &lt;element name="Landsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLandsnaam" minOccurs="0"/&gt;
                             *         &lt;element name="StraatnaamBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdStraatnaam" minOccurs="0"/&gt;
                             *         &lt;element name="HuisnrBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisnrBuitenland" minOccurs="0"/&gt;
                             *         &lt;element name="LocatieomsBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar128" minOccurs="0"/&gt;
                             *       &lt;/sequence&gt;
                             *     &lt;/restriction&gt;
                             *   &lt;/complexContent&gt;
                             * &lt;/complexType&gt;
                             * </pre>
                             * 
                             * 
                             */
                            @XmlAccessorType(XmlAccessType.FIELD)
                            @XmlType(name = "", propOrder = {
                                "postcdBuitenland",
                                "woonplaatsnaamBuitenland",
                                "regionaamBuitenland",
                                "landcodeGba",
                                "landcodeIso",
                                "landsnaam",
                                "straatnaamBuitenland",
                                "huisnrBuitenland",
                                "locatieomsBuitenland"
                            })
                            public static class StraatadresBuitenlandUhr {

                                @XmlElement(name = "PostcdBuitenland")
                                @Size(max = 9)
                                protected String postcdBuitenland;
                                @XmlElement(name = "WoonplaatsnaamBuitenland")
                                @Size(max = 80)
                                protected String woonplaatsnaamBuitenland;
                                @XmlElement(name = "RegionaamBuitenland")
                                @Size(max = 24)
                                protected String regionaamBuitenland;
                                @XmlElement(name = "LandcodeGba")
                                @Size(min = 4, max = 4)
                                @Pattern(regexp = "[0-9]*")
                                protected String landcodeGba;
                                @XmlElement(name = "LandcodeIso")
                                @Size(min = 2, max = 2)
                                @Pattern(regexp = "[A-Z]*")
                                protected String landcodeIso;
                                @XmlElement(name = "Landsnaam")
                                @Size(max = 40)
                                protected String landsnaam;
                                @XmlElement(name = "StraatnaamBuitenland")
                                @Size(max = 24)
                                protected String straatnaamBuitenland;
                                @XmlElement(name = "HuisnrBuitenland")
                                @Size(max = 9)
                                protected String huisnrBuitenland;
                                @XmlElement(name = "LocatieomsBuitenland")
                                @Size(max = 128)
                                protected String locatieomsBuitenland;

                                /**
                                 * Gets the value of the postcdBuitenland property.
                                 * 
                                 * @return
                                 *     possible object is
                                 *     {@link String }
                                 *     
                                 */
                                public String getPostcdBuitenland() {
                                    return postcdBuitenland;
                                }

                                /**
                                 * Sets the value of the postcdBuitenland property.
                                 * 
                                 * @param value
                                 *     allowed object is
                                 *     {@link String }
                                 *     
                                 */
                                public void setPostcdBuitenland(String value) {
                                    this.postcdBuitenland = value;
                                }

                                /**
                                 * Gets the value of the woonplaatsnaamBuitenland property.
                                 * 
                                 * @return
                                 *     possible object is
                                 *     {@link String }
                                 *     
                                 */
                                public String getWoonplaatsnaamBuitenland() {
                                    return woonplaatsnaamBuitenland;
                                }

                                /**
                                 * Sets the value of the woonplaatsnaamBuitenland property.
                                 * 
                                 * @param value
                                 *     allowed object is
                                 *     {@link String }
                                 *     
                                 */
                                public void setWoonplaatsnaamBuitenland(String value) {
                                    this.woonplaatsnaamBuitenland = value;
                                }

                                /**
                                 * Gets the value of the regionaamBuitenland property.
                                 * 
                                 * @return
                                 *     possible object is
                                 *     {@link String }
                                 *     
                                 */
                                public String getRegionaamBuitenland() {
                                    return regionaamBuitenland;
                                }

                                /**
                                 * Sets the value of the regionaamBuitenland property.
                                 * 
                                 * @param value
                                 *     allowed object is
                                 *     {@link String }
                                 *     
                                 */
                                public void setRegionaamBuitenland(String value) {
                                    this.regionaamBuitenland = value;
                                }

                                /**
                                 * Gets the value of the landcodeGba property.
                                 * 
                                 * @return
                                 *     possible object is
                                 *     {@link String }
                                 *     
                                 */
                                public String getLandcodeGba() {
                                    return landcodeGba;
                                }

                                /**
                                 * Sets the value of the landcodeGba property.
                                 * 
                                 * @param value
                                 *     allowed object is
                                 *     {@link String }
                                 *     
                                 */
                                public void setLandcodeGba(String value) {
                                    this.landcodeGba = value;
                                }

                                /**
                                 * Gets the value of the landcodeIso property.
                                 * 
                                 * @return
                                 *     possible object is
                                 *     {@link String }
                                 *     
                                 */
                                public String getLandcodeIso() {
                                    return landcodeIso;
                                }

                                /**
                                 * Sets the value of the landcodeIso property.
                                 * 
                                 * @param value
                                 *     allowed object is
                                 *     {@link String }
                                 *     
                                 */
                                public void setLandcodeIso(String value) {
                                    this.landcodeIso = value;
                                }

                                /**
                                 * Gets the value of the landsnaam property.
                                 * 
                                 * @return
                                 *     possible object is
                                 *     {@link String }
                                 *     
                                 */
                                public String getLandsnaam() {
                                    return landsnaam;
                                }

                                /**
                                 * Sets the value of the landsnaam property.
                                 * 
                                 * @param value
                                 *     allowed object is
                                 *     {@link String }
                                 *     
                                 */
                                public void setLandsnaam(String value) {
                                    this.landsnaam = value;
                                }

                                /**
                                 * Gets the value of the straatnaamBuitenland property.
                                 * 
                                 * @return
                                 *     possible object is
                                 *     {@link String }
                                 *     
                                 */
                                public String getStraatnaamBuitenland() {
                                    return straatnaamBuitenland;
                                }

                                /**
                                 * Sets the value of the straatnaamBuitenland property.
                                 * 
                                 * @param value
                                 *     allowed object is
                                 *     {@link String }
                                 *     
                                 */
                                public void setStraatnaamBuitenland(String value) {
                                    this.straatnaamBuitenland = value;
                                }

                                /**
                                 * Gets the value of the huisnrBuitenland property.
                                 * 
                                 * @return
                                 *     possible object is
                                 *     {@link String }
                                 *     
                                 */
                                public String getHuisnrBuitenland() {
                                    return huisnrBuitenland;
                                }

                                /**
                                 * Sets the value of the huisnrBuitenland property.
                                 * 
                                 * @param value
                                 *     allowed object is
                                 *     {@link String }
                                 *     
                                 */
                                public void setHuisnrBuitenland(String value) {
                                    this.huisnrBuitenland = value;
                                }

                                /**
                                 * Gets the value of the locatieomsBuitenland property.
                                 * 
                                 * @return
                                 *     possible object is
                                 *     {@link String }
                                 *     
                                 */
                                public String getLocatieomsBuitenland() {
                                    return locatieomsBuitenland;
                                }

                                /**
                                 * Sets the value of the locatieomsBuitenland property.
                                 * 
                                 * @param value
                                 *     allowed object is
                                 *     {@link String }
                                 *     
                                 */
                                public void setLocatieomsBuitenland(String value) {
                                    this.locatieomsBuitenland = value;
                                }

                            }

                        }


                        /**
                         * <p>Java class for anonymous complex type.
                         * 
                         * <p>The following schema fragment specifies the expected content contained within this class.
                         * 
                         * <pre>
                         * &lt;complexType&gt;
                         *   &lt;complexContent&gt;
                         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                         *       &lt;sequence&gt;
                         *         &lt;element name="CdAdresrol" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAdresrol_nocodes" minOccurs="0"/&gt;
                         *         &lt;element name="DatBAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                         *         &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                         *         &lt;element name="DatEAdreshouding" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                         *         &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                         *         &lt;element name="CdAfgeschermdAdres" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdOJNNvt_nocodes" minOccurs="0"/&gt;
                         *         &lt;choice minOccurs="0"&gt;
                         *           &lt;element name="StraatadresUhr" minOccurs="0"&gt;
                         *             &lt;complexType&gt;
                         *               &lt;complexContent&gt;
                         *                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                         *                   &lt;sequence&gt;
                         *                     &lt;element name="Postcd" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcd" minOccurs="0"/&gt;
                         *                     &lt;element name="Woonplaatsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
                         *                     &lt;element name="Straatnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdStraatnaam" minOccurs="0"/&gt;
                         *                     &lt;element name="Huisnr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisnr" minOccurs="0"/&gt;
                         *                     &lt;element name="Huisletter" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisletter" minOccurs="0"/&gt;
                         *                     &lt;element name="Huisnrtoevoeging" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar4" minOccurs="0"/&gt;
                         *                     &lt;element name="CdAanduidingBijHuisnr" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAanduidingBijHuisnr_nocodes" minOccurs="0"/&gt;
                         *                     &lt;element name="NaamOpenbareRuimte" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar80" minOccurs="0"/&gt;
                         *                   &lt;/sequence&gt;
                         *                 &lt;/restriction&gt;
                         *               &lt;/complexContent&gt;
                         *             &lt;/complexType&gt;
                         *           &lt;/element&gt;
                         *           &lt;element name="PostbusadresUhr" minOccurs="0"&gt;
                         *             &lt;complexType&gt;
                         *               &lt;complexContent&gt;
                         *                 &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                         *                   &lt;sequence&gt;
                         *                     &lt;element name="Postcd" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcd" minOccurs="0"/&gt;
                         *                     &lt;element name="Woonplaatsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
                         *                     &lt;element name="Postbusnr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostbusnr" minOccurs="0"/&gt;
                         *                   &lt;/sequence&gt;
                         *                 &lt;/restriction&gt;
                         *               &lt;/complexContent&gt;
                         *             &lt;/complexType&gt;
                         *           &lt;/element&gt;
                         *         &lt;/choice&gt;
                         *       &lt;/sequence&gt;
                         *     &lt;/restriction&gt;
                         *   &lt;/complexContent&gt;
                         * &lt;/complexType&gt;
                         * </pre>
                         * 
                         * 
                         */
                        @XmlAccessorType(XmlAccessType.FIELD)
                        @XmlType(name = "", propOrder = {
                            "cdAdresrol",
                            "datBAdreshouding",
                            "cdFictieveDatB",
                            "datEAdreshouding",
                            "cdFictieveDatE",
                            "cdAfgeschermdAdres",
                            "straatadresUhr",
                            "postbusadresUhr"
                        })
                        public static class AdresNederlandUhr {

                            @XmlElement(name = "CdAdresrol")
                            @Size(min = 1, max = 1)
                            @Pattern(regexp = "\\D*")
                            protected String cdAdresrol;
                            @XmlElement(name = "DatBAdreshouding")
                            @Size(max = 8)
                            protected String datBAdreshouding;
                            @XmlElement(name = "CdFictieveDatB")
                            @Size(min = 1, max = 1)
                            @Pattern(regexp = "\\d*")
                            protected String cdFictieveDatB;
                            @XmlElement(name = "DatEAdreshouding")
                            @Size(max = 8)
                            protected String datEAdreshouding;
                            @XmlElement(name = "CdFictieveDatE")
                            @Size(min = 1, max = 1)
                            @Pattern(regexp = "\\d*")
                            protected String cdFictieveDatE;
                            @XmlElement(name = "CdAfgeschermdAdres")
                            @Size(min = 1, max = 1)
                            @Pattern(regexp = "\\d*")
                            protected String cdAfgeschermdAdres;
                            @XmlElement(name = "StraatadresUhr")
                            @Valid
                            protected CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresNederlandUhr.StraatadresUhr straatadresUhr;
                            @XmlElement(name = "PostbusadresUhr")
                            @Valid
                            protected CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresNederlandUhr.PostbusadresUhr postbusadresUhr;

                            /**
                             * Gets the value of the cdAdresrol property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getCdAdresrol() {
                                return cdAdresrol;
                            }

                            /**
                             * Sets the value of the cdAdresrol property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setCdAdresrol(String value) {
                                this.cdAdresrol = value;
                            }

                            /**
                             * Gets the value of the datBAdreshouding property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getDatBAdreshouding() {
                                return datBAdreshouding;
                            }

                            /**
                             * Sets the value of the datBAdreshouding property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setDatBAdreshouding(String value) {
                                this.datBAdreshouding = value;
                            }

                            /**
                             * Gets the value of the cdFictieveDatB property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getCdFictieveDatB() {
                                return cdFictieveDatB;
                            }

                            /**
                             * Sets the value of the cdFictieveDatB property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setCdFictieveDatB(String value) {
                                this.cdFictieveDatB = value;
                            }

                            /**
                             * Gets the value of the datEAdreshouding property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getDatEAdreshouding() {
                                return datEAdreshouding;
                            }

                            /**
                             * Sets the value of the datEAdreshouding property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setDatEAdreshouding(String value) {
                                this.datEAdreshouding = value;
                            }

                            /**
                             * Gets the value of the cdFictieveDatE property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getCdFictieveDatE() {
                                return cdFictieveDatE;
                            }

                            /**
                             * Sets the value of the cdFictieveDatE property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setCdFictieveDatE(String value) {
                                this.cdFictieveDatE = value;
                            }

                            /**
                             * Gets the value of the cdAfgeschermdAdres property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getCdAfgeschermdAdres() {
                                return cdAfgeschermdAdres;
                            }

                            /**
                             * Sets the value of the cdAfgeschermdAdres property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setCdAfgeschermdAdres(String value) {
                                this.cdAfgeschermdAdres = value;
                            }

                            /**
                             * Gets the value of the straatadresUhr property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresNederlandUhr.StraatadresUhr }
                             *     
                             */
                            public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresNederlandUhr.StraatadresUhr getStraatadresUhr() {
                                return straatadresUhr;
                            }

                            /**
                             * Sets the value of the straatadresUhr property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresNederlandUhr.StraatadresUhr }
                             *     
                             */
                            public void setStraatadresUhr(CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresNederlandUhr.StraatadresUhr value) {
                                this.straatadresUhr = value;
                            }

                            /**
                             * Gets the value of the postbusadresUhr property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresNederlandUhr.PostbusadresUhr }
                             *     
                             */
                            public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresNederlandUhr.PostbusadresUhr getPostbusadresUhr() {
                                return postbusadresUhr;
                            }

                            /**
                             * Sets the value of the postbusadresUhr property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresNederlandUhr.PostbusadresUhr }
                             *     
                             */
                            public void setPostbusadresUhr(CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresNederlandUhr.PostbusadresUhr value) {
                                this.postbusadresUhr = value;
                            }


                            /**
                             * <p>Java class for anonymous complex type.
                             * 
                             * <p>The following schema fragment specifies the expected content contained within this class.
                             * 
                             * <pre>
                             * &lt;complexType&gt;
                             *   &lt;complexContent&gt;
                             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                             *       &lt;sequence&gt;
                             *         &lt;element name="Postcd" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcd" minOccurs="0"/&gt;
                             *         &lt;element name="Woonplaatsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
                             *         &lt;element name="Postbusnr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostbusnr" minOccurs="0"/&gt;
                             *       &lt;/sequence&gt;
                             *     &lt;/restriction&gt;
                             *   &lt;/complexContent&gt;
                             * &lt;/complexType&gt;
                             * </pre>
                             * 
                             * 
                             */
                            @XmlAccessorType(XmlAccessType.FIELD)
                            @XmlType(name = "", propOrder = {
                                "postcd",
                                "woonplaatsnaam",
                                "postbusnr"
                            })
                            public static class PostbusadresUhr {

                                @XmlElement(name = "Postcd")
                                @Size(min = 6, max = 6)
                                @Pattern(regexp = "[1-9][0-9]{3}[A-Z]{2}")
                                protected String postcd;
                                @XmlElement(name = "Woonplaatsnaam")
                                @Size(max = 80)
                                protected String woonplaatsnaam;
                                @XmlElement(name = "Postbusnr")
                                @XmlSchemaType(name = "nonNegativeInteger")
                                @DecimalMin("1")
                                @Digits(integer = 5, fraction = 0)
                                protected BigInteger postbusnr;

                                /**
                                 * Gets the value of the postcd property.
                                 * 
                                 * @return
                                 *     possible object is
                                 *     {@link String }
                                 *     
                                 */
                                public String getPostcd() {
                                    return postcd;
                                }

                                /**
                                 * Sets the value of the postcd property.
                                 * 
                                 * @param value
                                 *     allowed object is
                                 *     {@link String }
                                 *     
                                 */
                                public void setPostcd(String value) {
                                    this.postcd = value;
                                }

                                /**
                                 * Gets the value of the woonplaatsnaam property.
                                 * 
                                 * @return
                                 *     possible object is
                                 *     {@link String }
                                 *     
                                 */
                                public String getWoonplaatsnaam() {
                                    return woonplaatsnaam;
                                }

                                /**
                                 * Sets the value of the woonplaatsnaam property.
                                 * 
                                 * @param value
                                 *     allowed object is
                                 *     {@link String }
                                 *     
                                 */
                                public void setWoonplaatsnaam(String value) {
                                    this.woonplaatsnaam = value;
                                }

                                /**
                                 * Gets the value of the postbusnr property.
                                 * 
                                 * @return
                                 *     possible object is
                                 *     {@link BigInteger }
                                 *     
                                 */
                                public BigInteger getPostbusnr() {
                                    return postbusnr;
                                }

                                /**
                                 * Sets the value of the postbusnr property.
                                 * 
                                 * @param value
                                 *     allowed object is
                                 *     {@link BigInteger }
                                 *     
                                 */
                                public void setPostbusnr(BigInteger value) {
                                    this.postbusnr = value;
                                }

                            }


                            /**
                             * <p>Java class for anonymous complex type.
                             * 
                             * <p>The following schema fragment specifies the expected content contained within this class.
                             * 
                             * <pre>
                             * &lt;complexType&gt;
                             *   &lt;complexContent&gt;
                             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                             *       &lt;sequence&gt;
                             *         &lt;element name="Postcd" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdPostcd" minOccurs="0"/&gt;
                             *         &lt;element name="Woonplaatsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdWoonplaatsnaam" minOccurs="0"/&gt;
                             *         &lt;element name="Straatnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdStraatnaam" minOccurs="0"/&gt;
                             *         &lt;element name="Huisnr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisnr" minOccurs="0"/&gt;
                             *         &lt;element name="Huisletter" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdHuisletter" minOccurs="0"/&gt;
                             *         &lt;element name="Huisnrtoevoeging" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar4" minOccurs="0"/&gt;
                             *         &lt;element name="CdAanduidingBijHuisnr" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAanduidingBijHuisnr_nocodes" minOccurs="0"/&gt;
                             *         &lt;element name="NaamOpenbareRuimte" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar80" minOccurs="0"/&gt;
                             *       &lt;/sequence&gt;
                             *     &lt;/restriction&gt;
                             *   &lt;/complexContent&gt;
                             * &lt;/complexType&gt;
                             * </pre>
                             * 
                             * 
                             */
                            @XmlAccessorType(XmlAccessType.FIELD)
                            @XmlType(name = "", propOrder = {
                                "postcd",
                                "woonplaatsnaam",
                                "straatnaam",
                                "huisnr",
                                "huisletter",
                                "huisnrtoevoeging",
                                "cdAanduidingBijHuisnr",
                                "naamOpenbareRuimte"
                            })
                            public static class StraatadresUhr {

                                @XmlElement(name = "Postcd")
                                @Size(min = 6, max = 6)
                                @Pattern(regexp = "[1-9][0-9]{3}[A-Z]{2}")
                                protected String postcd;
                                @XmlElement(name = "Woonplaatsnaam")
                                @Size(max = 80)
                                protected String woonplaatsnaam;
                                @XmlElement(name = "Straatnaam")
                                @Size(max = 24)
                                protected String straatnaam;
                                @XmlElement(name = "Huisnr")
                                @XmlSchemaType(name = "nonNegativeInteger")
                                @DecimalMin("1")
                                @Digits(integer = 5, fraction = 0)
                                protected BigInteger huisnr;
                                @XmlElement(name = "Huisletter")
                                @Size(min = 1, max = 1)
                                @Pattern(regexp = "[a-zA-Z]")
                                protected String huisletter;
                                @XmlElement(name = "Huisnrtoevoeging")
                                @Size(max = 4)
                                protected String huisnrtoevoeging;
                                @XmlElement(name = "CdAanduidingBijHuisnr")
                                @Size(min = 2, max = 2)
                                @Pattern(regexp = "\\D*")
                                protected String cdAanduidingBijHuisnr;
                                @XmlElement(name = "NaamOpenbareRuimte")
                                @Size(max = 80)
                                protected String naamOpenbareRuimte;

                                /**
                                 * Gets the value of the postcd property.
                                 * 
                                 * @return
                                 *     possible object is
                                 *     {@link String }
                                 *     
                                 */
                                public String getPostcd() {
                                    return postcd;
                                }

                                /**
                                 * Sets the value of the postcd property.
                                 * 
                                 * @param value
                                 *     allowed object is
                                 *     {@link String }
                                 *     
                                 */
                                public void setPostcd(String value) {
                                    this.postcd = value;
                                }

                                /**
                                 * Gets the value of the woonplaatsnaam property.
                                 * 
                                 * @return
                                 *     possible object is
                                 *     {@link String }
                                 *     
                                 */
                                public String getWoonplaatsnaam() {
                                    return woonplaatsnaam;
                                }

                                /**
                                 * Sets the value of the woonplaatsnaam property.
                                 * 
                                 * @param value
                                 *     allowed object is
                                 *     {@link String }
                                 *     
                                 */
                                public void setWoonplaatsnaam(String value) {
                                    this.woonplaatsnaam = value;
                                }

                                /**
                                 * Gets the value of the straatnaam property.
                                 * 
                                 * @return
                                 *     possible object is
                                 *     {@link String }
                                 *     
                                 */
                                public String getStraatnaam() {
                                    return straatnaam;
                                }

                                /**
                                 * Sets the value of the straatnaam property.
                                 * 
                                 * @param value
                                 *     allowed object is
                                 *     {@link String }
                                 *     
                                 */
                                public void setStraatnaam(String value) {
                                    this.straatnaam = value;
                                }

                                /**
                                 * Gets the value of the huisnr property.
                                 * 
                                 * @return
                                 *     possible object is
                                 *     {@link BigInteger }
                                 *     
                                 */
                                public BigInteger getHuisnr() {
                                    return huisnr;
                                }

                                /**
                                 * Sets the value of the huisnr property.
                                 * 
                                 * @param value
                                 *     allowed object is
                                 *     {@link BigInteger }
                                 *     
                                 */
                                public void setHuisnr(BigInteger value) {
                                    this.huisnr = value;
                                }

                                /**
                                 * Gets the value of the huisletter property.
                                 * 
                                 * @return
                                 *     possible object is
                                 *     {@link String }
                                 *     
                                 */
                                public String getHuisletter() {
                                    return huisletter;
                                }

                                /**
                                 * Sets the value of the huisletter property.
                                 * 
                                 * @param value
                                 *     allowed object is
                                 *     {@link String }
                                 *     
                                 */
                                public void setHuisletter(String value) {
                                    this.huisletter = value;
                                }

                                /**
                                 * Gets the value of the huisnrtoevoeging property.
                                 * 
                                 * @return
                                 *     possible object is
                                 *     {@link String }
                                 *     
                                 */
                                public String getHuisnrtoevoeging() {
                                    return huisnrtoevoeging;
                                }

                                /**
                                 * Sets the value of the huisnrtoevoeging property.
                                 * 
                                 * @param value
                                 *     allowed object is
                                 *     {@link String }
                                 *     
                                 */
                                public void setHuisnrtoevoeging(String value) {
                                    this.huisnrtoevoeging = value;
                                }

                                /**
                                 * Gets the value of the cdAanduidingBijHuisnr property.
                                 * 
                                 * @return
                                 *     possible object is
                                 *     {@link String }
                                 *     
                                 */
                                public String getCdAanduidingBijHuisnr() {
                                    return cdAanduidingBijHuisnr;
                                }

                                /**
                                 * Sets the value of the cdAanduidingBijHuisnr property.
                                 * 
                                 * @param value
                                 *     allowed object is
                                 *     {@link String }
                                 *     
                                 */
                                public void setCdAanduidingBijHuisnr(String value) {
                                    this.cdAanduidingBijHuisnr = value;
                                }

                                /**
                                 * Gets the value of the naamOpenbareRuimte property.
                                 * 
                                 * @return
                                 *     possible object is
                                 *     {@link String }
                                 *     
                                 */
                                public String getNaamOpenbareRuimte() {
                                    return naamOpenbareRuimte;
                                }

                                /**
                                 * Sets the value of the naamOpenbareRuimte property.
                                 * 
                                 * @param value
                                 *     allowed object is
                                 *     {@link String }
                                 *     
                                 */
                                public void setNaamOpenbareRuimte(String value) {
                                    this.naamOpenbareRuimte = value;
                                }

                            }

                        }

                    }


                    /**
                     * <p>Java class for anonymous complex type.
                     * 
                     * <p>The following schema fragment specifies the expected content contained within this class.
                     * 
                     * <pre>
                     * &lt;complexType&gt;
                     *   &lt;complexContent&gt;
                     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                     *       &lt;sequence&gt;
                     *         &lt;element name="Handelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar625" minOccurs="0"/&gt;
                     *         &lt;element name="VolgordeHandelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdAantNietNegatiefVar4" minOccurs="0"/&gt;
                     *         &lt;element name="DatBHandelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                     *         &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                     *         &lt;element name="DatEHandelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                     *         &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                     *       &lt;/sequence&gt;
                     *     &lt;/restriction&gt;
                     *   &lt;/complexContent&gt;
                     * &lt;/complexType&gt;
                     * </pre>
                     * 
                     * 
                     */
                    @XmlAccessorType(XmlAccessType.FIELD)
                    @XmlType(name = "", propOrder = {
                        "handelsnaam",
                        "volgordeHandelsnaam",
                        "datBHandelsnaam",
                        "cdFictieveDatB",
                        "datEHandelsnaam",
                        "cdFictieveDatE"
                    })
                    public static class Handelsnaam {

                        @XmlElement(name = "Handelsnaam")
                        @Size(max = 625)
                        protected String handelsnaam;
                        @XmlElement(name = "VolgordeHandelsnaam")
                        @XmlSchemaType(name = "nonNegativeInteger")
                        @DecimalMin("0")
                        @Digits(integer = 4, fraction = 0)
                        protected BigInteger volgordeHandelsnaam;
                        @XmlElement(name = "DatBHandelsnaam")
                        @Size(max = 8)
                        protected String datBHandelsnaam;
                        @XmlElement(name = "CdFictieveDatB")
                        @Size(min = 1, max = 1)
                        @Pattern(regexp = "\\d*")
                        protected String cdFictieveDatB;
                        @XmlElement(name = "DatEHandelsnaam")
                        @Size(max = 8)
                        protected String datEHandelsnaam;
                        @XmlElement(name = "CdFictieveDatE")
                        @Size(min = 1, max = 1)
                        @Pattern(regexp = "\\d*")
                        protected String cdFictieveDatE;

                        /**
                         * Gets the value of the handelsnaam property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getHandelsnaam() {
                            return handelsnaam;
                        }

                        /**
                         * Sets the value of the handelsnaam property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setHandelsnaam(String value) {
                            this.handelsnaam = value;
                        }

                        /**
                         * Gets the value of the volgordeHandelsnaam property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link BigInteger }
                         *     
                         */
                        public BigInteger getVolgordeHandelsnaam() {
                            return volgordeHandelsnaam;
                        }

                        /**
                         * Sets the value of the volgordeHandelsnaam property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link BigInteger }
                         *     
                         */
                        public void setVolgordeHandelsnaam(BigInteger value) {
                            this.volgordeHandelsnaam = value;
                        }

                        /**
                         * Gets the value of the datBHandelsnaam property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getDatBHandelsnaam() {
                            return datBHandelsnaam;
                        }

                        /**
                         * Sets the value of the datBHandelsnaam property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setDatBHandelsnaam(String value) {
                            this.datBHandelsnaam = value;
                        }

                        /**
                         * Gets the value of the cdFictieveDatB property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getCdFictieveDatB() {
                            return cdFictieveDatB;
                        }

                        /**
                         * Sets the value of the cdFictieveDatB property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setCdFictieveDatB(String value) {
                            this.cdFictieveDatB = value;
                        }

                        /**
                         * Gets the value of the datEHandelsnaam property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getDatEHandelsnaam() {
                            return datEHandelsnaam;
                        }

                        /**
                         * Sets the value of the datEHandelsnaam property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setDatEHandelsnaam(String value) {
                            this.datEHandelsnaam = value;
                        }

                        /**
                         * Gets the value of the cdFictieveDatE property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getCdFictieveDatE() {
                            return cdFictieveDatE;
                        }

                        /**
                         * Sets the value of the cdFictieveDatE property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setCdFictieveDatE(String value) {
                            this.cdFictieveDatE = value;
                        }

                    }


                    /**
                     * <p>Java class for anonymous complex type.
                     * 
                     * <p>The following schema fragment specifies the expected content contained within this class.
                     * 
                     * <pre>
                     * &lt;complexType&gt;
                     *   &lt;complexContent&gt;
                     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                     *       &lt;sequence&gt;
                     *         &lt;element name="KvkNr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdKvkNr" minOccurs="0"/&gt;
                     *         &lt;element name="DatBOnderneming" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                     *         &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                     *         &lt;element name="DatEOnderneming" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                     *         &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                     *         &lt;element name="Sbiklasse" maxOccurs="unbounded" minOccurs="0"&gt;
                     *           &lt;complexType&gt;
                     *             &lt;complexContent&gt;
                     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                     *                 &lt;sequence&gt;
                     *                   &lt;element name="CdSbi" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdSbi" minOccurs="0"/&gt;
                     *                   &lt;element name="OmsSbi" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar300" minOccurs="0"/&gt;
                     *                   &lt;element name="IndSbiHoofdactiviteit" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdIndJN_nocodes" minOccurs="0"/&gt;
                     *                   &lt;element name="DatBSbiactiviteit" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                     *                   &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                     *                   &lt;element name="DatESbiactiviteit" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                     *                   &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                     *                 &lt;/sequence&gt;
                     *               &lt;/restriction&gt;
                     *             &lt;/complexContent&gt;
                     *           &lt;/complexType&gt;
                     *         &lt;/element&gt;
                     *         &lt;element name="Handelsnaam" maxOccurs="unbounded" minOccurs="0"&gt;
                     *           &lt;complexType&gt;
                     *             &lt;complexContent&gt;
                     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                     *                 &lt;sequence&gt;
                     *                   &lt;element name="Handelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar625" minOccurs="0"/&gt;
                     *                   &lt;element name="VolgordeHandelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdAantNietNegatiefVar4" minOccurs="0"/&gt;
                     *                   &lt;element name="DatBHandelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                     *                   &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                     *                   &lt;element name="DatEHandelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                     *                   &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                     *                 &lt;/sequence&gt;
                     *               &lt;/restriction&gt;
                     *             &lt;/complexContent&gt;
                     *           &lt;/complexType&gt;
                     *         &lt;/element&gt;
                     *       &lt;/sequence&gt;
                     *     &lt;/restriction&gt;
                     *   &lt;/complexContent&gt;
                     * &lt;/complexType&gt;
                     * </pre>
                     * 
                     * 
                     */
                    @XmlAccessorType(XmlAccessType.FIELD)
                    @XmlType(name = "", propOrder = {
                        "kvkNr",
                        "datBOnderneming",
                        "cdFictieveDatB",
                        "datEOnderneming",
                        "cdFictieveDatE",
                        "sbiklasse",
                        "handelsnaam"
                    })
                    public static class Onderneming {

                        @XmlElement(name = "KvkNr")
                        @Size(min = 8, max = 8)
                        @Pattern(regexp = "\\d*")
                        protected String kvkNr;
                        @XmlElement(name = "DatBOnderneming")
                        @Size(max = 8)
                        protected String datBOnderneming;
                        @XmlElement(name = "CdFictieveDatB")
                        @Size(min = 1, max = 1)
                        @Pattern(regexp = "\\d*")
                        protected String cdFictieveDatB;
                        @XmlElement(name = "DatEOnderneming")
                        @Size(max = 8)
                        protected String datEOnderneming;
                        @XmlElement(name = "CdFictieveDatE")
                        @Size(min = 1, max = 1)
                        @Pattern(regexp = "\\d*")
                        protected String cdFictieveDatE;
                        @XmlElement(name = "Sbiklasse")
                        @Valid
                        protected List<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Onderneming.Sbiklasse> sbiklasse;
                        @XmlElement(name = "Handelsnaam")
                        @Valid
                        protected List<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Onderneming.Handelsnaam> handelsnaam;

                        /**
                         * Gets the value of the kvkNr property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getKvkNr() {
                            return kvkNr;
                        }

                        /**
                         * Sets the value of the kvkNr property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setKvkNr(String value) {
                            this.kvkNr = value;
                        }

                        /**
                         * Gets the value of the datBOnderneming property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getDatBOnderneming() {
                            return datBOnderneming;
                        }

                        /**
                         * Sets the value of the datBOnderneming property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setDatBOnderneming(String value) {
                            this.datBOnderneming = value;
                        }

                        /**
                         * Gets the value of the cdFictieveDatB property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getCdFictieveDatB() {
                            return cdFictieveDatB;
                        }

                        /**
                         * Sets the value of the cdFictieveDatB property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setCdFictieveDatB(String value) {
                            this.cdFictieveDatB = value;
                        }

                        /**
                         * Gets the value of the datEOnderneming property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getDatEOnderneming() {
                            return datEOnderneming;
                        }

                        /**
                         * Sets the value of the datEOnderneming property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setDatEOnderneming(String value) {
                            this.datEOnderneming = value;
                        }

                        /**
                         * Gets the value of the cdFictieveDatE property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getCdFictieveDatE() {
                            return cdFictieveDatE;
                        }

                        /**
                         * Sets the value of the cdFictieveDatE property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setCdFictieveDatE(String value) {
                            this.cdFictieveDatE = value;
                        }

                        /**
                         * Gets the value of the sbiklasse property.
                         * 
                         * <p>
                         * This accessor method returns a reference to the live list,
                         * not a snapshot. Therefore any modification you make to the
                         * returned list will be present inside the JAXB object.
                         * This is why there is not a <CODE>set</CODE> method for the sbiklasse property.
                         * 
                         * <p>
                         * For example, to add a new item, do as follows:
                         * <pre>
                         *    getSbiklasse().add(newItem);
                         * </pre>
                         * 
                         * 
                         * <p>
                         * Objects of the following type(s) are allowed in the list
                         * {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Onderneming.Sbiklasse }
                         * 
                         * 
                         */
                        public List<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Onderneming.Sbiklasse> getSbiklasse() {
                            if (sbiklasse == null) {
                                sbiklasse = new ArrayList<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Onderneming.Sbiklasse>();
                            }
                            return this.sbiklasse;
                        }

                        /**
                         * Gets the value of the handelsnaam property.
                         * 
                         * <p>
                         * This accessor method returns a reference to the live list,
                         * not a snapshot. Therefore any modification you make to the
                         * returned list will be present inside the JAXB object.
                         * This is why there is not a <CODE>set</CODE> method for the handelsnaam property.
                         * 
                         * <p>
                         * For example, to add a new item, do as follows:
                         * <pre>
                         *    getHandelsnaam().add(newItem);
                         * </pre>
                         * 
                         * 
                         * <p>
                         * Objects of the following type(s) are allowed in the list
                         * {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Onderneming.Handelsnaam }
                         * 
                         * 
                         */
                        public List<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Onderneming.Handelsnaam> getHandelsnaam() {
                            if (handelsnaam == null) {
                                handelsnaam = new ArrayList<CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Onderneming.Handelsnaam>();
                            }
                            return this.handelsnaam;
                        }


                        /**
                         * <p>Java class for anonymous complex type.
                         * 
                         * <p>The following schema fragment specifies the expected content contained within this class.
                         * 
                         * <pre>
                         * &lt;complexType&gt;
                         *   &lt;complexContent&gt;
                         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                         *       &lt;sequence&gt;
                         *         &lt;element name="Handelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar625" minOccurs="0"/&gt;
                         *         &lt;element name="VolgordeHandelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdAantNietNegatiefVar4" minOccurs="0"/&gt;
                         *         &lt;element name="DatBHandelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                         *         &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                         *         &lt;element name="DatEHandelsnaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                         *         &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                         *       &lt;/sequence&gt;
                         *     &lt;/restriction&gt;
                         *   &lt;/complexContent&gt;
                         * &lt;/complexType&gt;
                         * </pre>
                         * 
                         * 
                         */
                        @XmlAccessorType(XmlAccessType.FIELD)
                        @XmlType(name = "", propOrder = {
                            "handelsnaam",
                            "volgordeHandelsnaam",
                            "datBHandelsnaam",
                            "cdFictieveDatB",
                            "datEHandelsnaam",
                            "cdFictieveDatE"
                        })
                        public static class Handelsnaam {

                            @XmlElement(name = "Handelsnaam")
                            @Size(max = 625)
                            protected String handelsnaam;
                            @XmlElement(name = "VolgordeHandelsnaam")
                            @XmlSchemaType(name = "nonNegativeInteger")
                            @DecimalMin("0")
                            @Digits(integer = 4, fraction = 0)
                            protected BigInteger volgordeHandelsnaam;
                            @XmlElement(name = "DatBHandelsnaam")
                            @Size(max = 8)
                            protected String datBHandelsnaam;
                            @XmlElement(name = "CdFictieveDatB")
                            @Size(min = 1, max = 1)
                            @Pattern(regexp = "\\d*")
                            protected String cdFictieveDatB;
                            @XmlElement(name = "DatEHandelsnaam")
                            @Size(max = 8)
                            protected String datEHandelsnaam;
                            @XmlElement(name = "CdFictieveDatE")
                            @Size(min = 1, max = 1)
                            @Pattern(regexp = "\\d*")
                            protected String cdFictieveDatE;

                            /**
                             * Gets the value of the handelsnaam property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getHandelsnaam() {
                                return handelsnaam;
                            }

                            /**
                             * Sets the value of the handelsnaam property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setHandelsnaam(String value) {
                                this.handelsnaam = value;
                            }

                            /**
                             * Gets the value of the volgordeHandelsnaam property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link BigInteger }
                             *     
                             */
                            public BigInteger getVolgordeHandelsnaam() {
                                return volgordeHandelsnaam;
                            }

                            /**
                             * Sets the value of the volgordeHandelsnaam property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link BigInteger }
                             *     
                             */
                            public void setVolgordeHandelsnaam(BigInteger value) {
                                this.volgordeHandelsnaam = value;
                            }

                            /**
                             * Gets the value of the datBHandelsnaam property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getDatBHandelsnaam() {
                                return datBHandelsnaam;
                            }

                            /**
                             * Sets the value of the datBHandelsnaam property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setDatBHandelsnaam(String value) {
                                this.datBHandelsnaam = value;
                            }

                            /**
                             * Gets the value of the cdFictieveDatB property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getCdFictieveDatB() {
                                return cdFictieveDatB;
                            }

                            /**
                             * Sets the value of the cdFictieveDatB property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setCdFictieveDatB(String value) {
                                this.cdFictieveDatB = value;
                            }

                            /**
                             * Gets the value of the datEHandelsnaam property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getDatEHandelsnaam() {
                                return datEHandelsnaam;
                            }

                            /**
                             * Sets the value of the datEHandelsnaam property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setDatEHandelsnaam(String value) {
                                this.datEHandelsnaam = value;
                            }

                            /**
                             * Gets the value of the cdFictieveDatE property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getCdFictieveDatE() {
                                return cdFictieveDatE;
                            }

                            /**
                             * Sets the value of the cdFictieveDatE property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setCdFictieveDatE(String value) {
                                this.cdFictieveDatE = value;
                            }

                        }


                        /**
                         * <p>Java class for anonymous complex type.
                         * 
                         * <p>The following schema fragment specifies the expected content contained within this class.
                         * 
                         * <pre>
                         * &lt;complexType&gt;
                         *   &lt;complexContent&gt;
                         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                         *       &lt;sequence&gt;
                         *         &lt;element name="CdSbi" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdSbi" minOccurs="0"/&gt;
                         *         &lt;element name="OmsSbi" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar300" minOccurs="0"/&gt;
                         *         &lt;element name="IndSbiHoofdactiviteit" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdIndJN_nocodes" minOccurs="0"/&gt;
                         *         &lt;element name="DatBSbiactiviteit" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                         *         &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                         *         &lt;element name="DatESbiactiviteit" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                         *         &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                         *       &lt;/sequence&gt;
                         *     &lt;/restriction&gt;
                         *   &lt;/complexContent&gt;
                         * &lt;/complexType&gt;
                         * </pre>
                         * 
                         * 
                         */
                        @XmlAccessorType(XmlAccessType.FIELD)
                        @XmlType(name = "", propOrder = {
                            "cdSbi",
                            "omsSbi",
                            "indSbiHoofdactiviteit",
                            "datBSbiactiviteit",
                            "cdFictieveDatB",
                            "datESbiactiviteit",
                            "cdFictieveDatE"
                        })
                        public static class Sbiklasse {

                            @XmlElement(name = "CdSbi")
                            @Size(max = 5)
                            @Pattern(regexp = "[0-9]*")
                            protected String cdSbi;
                            @XmlElement(name = "OmsSbi")
                            @Size(max = 300)
                            protected String omsSbi;
                            @XmlElement(name = "IndSbiHoofdactiviteit")
                            @Size(min = 1, max = 1)
                            @Pattern(regexp = "[0-9]*")
                            protected String indSbiHoofdactiviteit;
                            @XmlElement(name = "DatBSbiactiviteit")
                            @Size(max = 8)
                            protected String datBSbiactiviteit;
                            @XmlElement(name = "CdFictieveDatB")
                            @Size(min = 1, max = 1)
                            @Pattern(regexp = "\\d*")
                            protected String cdFictieveDatB;
                            @XmlElement(name = "DatESbiactiviteit")
                            @Size(max = 8)
                            protected String datESbiactiviteit;
                            @XmlElement(name = "CdFictieveDatE")
                            @Size(min = 1, max = 1)
                            @Pattern(regexp = "\\d*")
                            protected String cdFictieveDatE;

                            /**
                             * Gets the value of the cdSbi property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getCdSbi() {
                                return cdSbi;
                            }

                            /**
                             * Sets the value of the cdSbi property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setCdSbi(String value) {
                                this.cdSbi = value;
                            }

                            /**
                             * Gets the value of the omsSbi property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getOmsSbi() {
                                return omsSbi;
                            }

                            /**
                             * Sets the value of the omsSbi property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setOmsSbi(String value) {
                                this.omsSbi = value;
                            }

                            /**
                             * Gets the value of the indSbiHoofdactiviteit property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getIndSbiHoofdactiviteit() {
                                return indSbiHoofdactiviteit;
                            }

                            /**
                             * Sets the value of the indSbiHoofdactiviteit property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setIndSbiHoofdactiviteit(String value) {
                                this.indSbiHoofdactiviteit = value;
                            }

                            /**
                             * Gets the value of the datBSbiactiviteit property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getDatBSbiactiviteit() {
                                return datBSbiactiviteit;
                            }

                            /**
                             * Sets the value of the datBSbiactiviteit property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setDatBSbiactiviteit(String value) {
                                this.datBSbiactiviteit = value;
                            }

                            /**
                             * Gets the value of the cdFictieveDatB property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getCdFictieveDatB() {
                                return cdFictieveDatB;
                            }

                            /**
                             * Sets the value of the cdFictieveDatB property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setCdFictieveDatB(String value) {
                                this.cdFictieveDatB = value;
                            }

                            /**
                             * Gets the value of the datESbiactiviteit property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getDatESbiactiviteit() {
                                return datESbiactiviteit;
                            }

                            /**
                             * Sets the value of the datESbiactiviteit property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setDatESbiactiviteit(String value) {
                                this.datESbiactiviteit = value;
                            }

                            /**
                             * Gets the value of the cdFictieveDatE property.
                             * 
                             * @return
                             *     possible object is
                             *     {@link String }
                             *     
                             */
                            public String getCdFictieveDatE() {
                                return cdFictieveDatE;
                            }

                            /**
                             * Sets the value of the cdFictieveDatE property.
                             * 
                             * @param value
                             *     allowed object is
                             *     {@link String }
                             *     
                             */
                            public void setCdFictieveDatE(String value) {
                                this.cdFictieveDatE = value;
                            }

                        }

                    }

                }

            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType&gt;
             *   &lt;complexContent&gt;
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *       &lt;sequence&gt;
             *         &lt;element name="Burgerservicenr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdBurgerservicenr" minOccurs="0"/&gt;
             *         &lt;element name="Voorletters" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdVoorletters" minOccurs="0"/&gt;
             *         &lt;element name="Voornamen" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdVoornamen" minOccurs="0"/&gt;
             *         &lt;element name="Voorvoegsel" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdVoorvoegsel" minOccurs="0"/&gt;
             *         &lt;element name="SignificantDeelVanDeAchternaam" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdSignificantDeelAchtern" minOccurs="0"/&gt;
             *         &lt;element name="CdAanduidingNaamgebruik" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdAanduidingNaamgebruik_nocodes" minOccurs="0"/&gt;
             *         &lt;element name="Geboortedat" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *         &lt;element name="CdFictieveGeboortedat" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
             *         &lt;element name="Geslacht" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdGeslacht_nocodes" minOccurs="0"/&gt;
             *         &lt;element name="HuwelijkGeregistreerdPartner" minOccurs="0"&gt;
             *           &lt;complexType&gt;
             *             &lt;complexContent&gt;
             *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                 &lt;sequence&gt;
             *                   &lt;element name="VoorvoegselEchtgenoot" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdVoorvoegsel" minOccurs="0"/&gt;
             *                   &lt;element name="SignificantDeelAchternaamEchtg" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdSignificantDeelAchtern" minOccurs="0"/&gt;
             *                 &lt;/sequence&gt;
             *               &lt;/restriction&gt;
             *             &lt;/complexContent&gt;
             *           &lt;/complexType&gt;
             *         &lt;/element&gt;
             *       &lt;/sequence&gt;
             *     &lt;/restriction&gt;
             *   &lt;/complexContent&gt;
             * &lt;/complexType&gt;
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "burgerservicenr",
                "voorletters",
                "voornamen",
                "voorvoegsel",
                "significantDeelVanDeAchternaam",
                "cdAanduidingNaamgebruik",
                "geboortedat",
                "cdFictieveGeboortedat",
                "geslacht",
                "huwelijkGeregistreerdPartner"
            })
            public static class NatuurlijkPersoon {

                @XmlElement(name = "Burgerservicenr")
                @Size(min = 9, max = 9)
                @Pattern(regexp = "[0-9]*")
                protected String burgerservicenr;
                @XmlElement(name = "Voorletters")
                @Size(max = 6)
                @Pattern(regexp = "\\D*")
                protected String voorletters;
                @XmlElement(name = "Voornamen")
                @Size(max = 200)
                @Pattern(regexp = "\\D*")
                protected String voornamen;
                @XmlElement(name = "Voorvoegsel")
                @Size(max = 10)
                @Pattern(regexp = "\\D*")
                protected String voorvoegsel;
                @XmlElement(name = "SignificantDeelVanDeAchternaam")
                @Size(max = 200)
                @Pattern(regexp = "\\D*")
                protected String significantDeelVanDeAchternaam;
                @XmlElement(name = "CdAanduidingNaamgebruik")
                @Size(min = 1, max = 1)
                @Pattern(regexp = "[0-9]*")
                protected String cdAanduidingNaamgebruik;
                @XmlElement(name = "Geboortedat")
                @Size(max = 8)
                protected String geboortedat;
                @XmlElement(name = "CdFictieveGeboortedat")
                @Size(min = 1, max = 1)
                @Pattern(regexp = "\\d*")
                protected String cdFictieveGeboortedat;
                @XmlElement(name = "Geslacht")
                @Size(min = 1, max = 1)
                @Pattern(regexp = "[0-9]*")
                protected String geslacht;
                @XmlElement(name = "HuwelijkGeregistreerdPartner")
                @Valid
                protected CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NatuurlijkPersoon.HuwelijkGeregistreerdPartner huwelijkGeregistreerdPartner;

                /**
                 * Gets the value of the burgerservicenr property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getBurgerservicenr() {
                    return burgerservicenr;
                }

                /**
                 * Sets the value of the burgerservicenr property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setBurgerservicenr(String value) {
                    this.burgerservicenr = value;
                }

                /**
                 * Gets the value of the voorletters property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getVoorletters() {
                    return voorletters;
                }

                /**
                 * Sets the value of the voorletters property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setVoorletters(String value) {
                    this.voorletters = value;
                }

                /**
                 * Gets the value of the voornamen property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getVoornamen() {
                    return voornamen;
                }

                /**
                 * Sets the value of the voornamen property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setVoornamen(String value) {
                    this.voornamen = value;
                }

                /**
                 * Gets the value of the voorvoegsel property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getVoorvoegsel() {
                    return voorvoegsel;
                }

                /**
                 * Sets the value of the voorvoegsel property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setVoorvoegsel(String value) {
                    this.voorvoegsel = value;
                }

                /**
                 * Gets the value of the significantDeelVanDeAchternaam property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getSignificantDeelVanDeAchternaam() {
                    return significantDeelVanDeAchternaam;
                }

                /**
                 * Sets the value of the significantDeelVanDeAchternaam property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setSignificantDeelVanDeAchternaam(String value) {
                    this.significantDeelVanDeAchternaam = value;
                }

                /**
                 * Gets the value of the cdAanduidingNaamgebruik property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getCdAanduidingNaamgebruik() {
                    return cdAanduidingNaamgebruik;
                }

                /**
                 * Sets the value of the cdAanduidingNaamgebruik property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setCdAanduidingNaamgebruik(String value) {
                    this.cdAanduidingNaamgebruik = value;
                }

                /**
                 * Gets the value of the geboortedat property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getGeboortedat() {
                    return geboortedat;
                }

                /**
                 * Sets the value of the geboortedat property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setGeboortedat(String value) {
                    this.geboortedat = value;
                }

                /**
                 * Gets the value of the cdFictieveGeboortedat property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getCdFictieveGeboortedat() {
                    return cdFictieveGeboortedat;
                }

                /**
                 * Sets the value of the cdFictieveGeboortedat property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setCdFictieveGeboortedat(String value) {
                    this.cdFictieveGeboortedat = value;
                }

                /**
                 * Gets the value of the geslacht property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getGeslacht() {
                    return geslacht;
                }

                /**
                 * Sets the value of the geslacht property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setGeslacht(String value) {
                    this.geslacht = value;
                }

                /**
                 * Gets the value of the huwelijkGeregistreerdPartner property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NatuurlijkPersoon.HuwelijkGeregistreerdPartner }
                 *     
                 */
                public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NatuurlijkPersoon.HuwelijkGeregistreerdPartner getHuwelijkGeregistreerdPartner() {
                    return huwelijkGeregistreerdPartner;
                }

                /**
                 * Sets the value of the huwelijkGeregistreerdPartner property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NatuurlijkPersoon.HuwelijkGeregistreerdPartner }
                 *     
                 */
                public void setHuwelijkGeregistreerdPartner(CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NatuurlijkPersoon.HuwelijkGeregistreerdPartner value) {
                    this.huwelijkGeregistreerdPartner = value;
                }


                /**
                 * <p>Java class for anonymous complex type.
                 * 
                 * <p>The following schema fragment specifies the expected content contained within this class.
                 * 
                 * <pre>
                 * &lt;complexType&gt;
                 *   &lt;complexContent&gt;
                 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                 *       &lt;sequence&gt;
                 *         &lt;element name="VoorvoegselEchtgenoot" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdVoorvoegsel" minOccurs="0"/&gt;
                 *         &lt;element name="SignificantDeelAchternaamEchtg" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdSignificantDeelAchtern" minOccurs="0"/&gt;
                 *       &lt;/sequence&gt;
                 *     &lt;/restriction&gt;
                 *   &lt;/complexContent&gt;
                 * &lt;/complexType&gt;
                 * </pre>
                 * 
                 * 
                 */
                @XmlAccessorType(XmlAccessType.FIELD)
                @XmlType(name = "", propOrder = {
                    "voorvoegselEchtgenoot",
                    "significantDeelAchternaamEchtg"
                })
                public static class HuwelijkGeregistreerdPartner {

                    @XmlElement(name = "VoorvoegselEchtgenoot")
                    @Size(max = 10)
                    @Pattern(regexp = "\\D*")
                    protected String voorvoegselEchtgenoot;
                    @XmlElement(name = "SignificantDeelAchternaamEchtg")
                    @Size(max = 200)
                    @Pattern(regexp = "\\D*")
                    protected String significantDeelAchternaamEchtg;

                    /**
                     * Gets the value of the voorvoegselEchtgenoot property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getVoorvoegselEchtgenoot() {
                        return voorvoegselEchtgenoot;
                    }

                    /**
                     * Sets the value of the voorvoegselEchtgenoot property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setVoorvoegselEchtgenoot(String value) {
                        this.voorvoegselEchtgenoot = value;
                    }

                    /**
                     * Gets the value of the significantDeelAchternaamEchtg property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getSignificantDeelAchternaamEchtg() {
                        return significantDeelAchternaamEchtg;
                    }

                    /**
                     * Sets the value of the significantDeelAchternaamEchtg property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setSignificantDeelAchternaamEchtg(String value) {
                        this.significantDeelAchternaamEchtg = value;
                    }

                }

            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType&gt;
             *   &lt;complexContent&gt;
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *       &lt;sequence&gt;
             *         &lt;element name="DatOntbindingRechtspSamenwerking" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *         &lt;element name="DatOprichtingRechtspSamenwerking" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *         &lt;element name="Rsin" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdRsin" minOccurs="0"/&gt;
             *         &lt;element name="DatBNietNatuurlijkPersoon" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *         &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
             *         &lt;element name="DatENietNatuurlijkPersoon" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *         &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
             *         &lt;element name="VolledigeNmNietNatuurlijkPersoon" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar500" minOccurs="0"/&gt;
             *         &lt;element name="Rechtspersoon" minOccurs="0"&gt;
             *           &lt;complexType&gt;
             *             &lt;complexContent&gt;
             *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                 &lt;sequence&gt;
             *                   &lt;element name="StatutaireZetel" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar60" minOccurs="0"/&gt;
             *                   &lt;element name="DatBStatutaireZetel" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *                   &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
             *                   &lt;element name="ActiviteitHandelsregister" minOccurs="0"&gt;
             *                     &lt;complexType&gt;
             *                       &lt;complexContent&gt;
             *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                           &lt;sequence&gt;
             *                             &lt;element name="OmsActiviteitHandelsregister" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdTekstAnVar2000" minOccurs="0"/&gt;
             *                           &lt;/sequence&gt;
             *                         &lt;/restriction&gt;
             *                       &lt;/complexContent&gt;
             *                     &lt;/complexType&gt;
             *                   &lt;/element&gt;
             *                 &lt;/sequence&gt;
             *               &lt;/restriction&gt;
             *             &lt;/complexContent&gt;
             *           &lt;/complexType&gt;
             *         &lt;/element&gt;
             *         &lt;element name="VennootschapBuitenland" minOccurs="0"&gt;
             *           &lt;complexType&gt;
             *             &lt;complexContent&gt;
             *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *                 &lt;sequence&gt;
             *                   &lt;element name="DatBVennootschapBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *                   &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
             *                   &lt;element name="DatEVennootschapBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *                   &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
             *                 &lt;/sequence&gt;
             *               &lt;/restriction&gt;
             *             &lt;/complexContent&gt;
             *           &lt;/complexType&gt;
             *         &lt;/element&gt;
             *       &lt;/sequence&gt;
             *     &lt;/restriction&gt;
             *   &lt;/complexContent&gt;
             * &lt;/complexType&gt;
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "datOntbindingRechtspSamenwerking",
                "datOprichtingRechtspSamenwerking",
                "rsin",
                "datBNietNatuurlijkPersoon",
                "cdFictieveDatB",
                "datENietNatuurlijkPersoon",
                "cdFictieveDatE",
                "volledigeNmNietNatuurlijkPersoon",
                "rechtspersoon",
                "vennootschapBuitenland"
            })
            public static class NietNatuurlijkPersoon {

                @XmlElement(name = "DatOntbindingRechtspSamenwerking")
                @Size(max = 8)
                protected String datOntbindingRechtspSamenwerking;
                @XmlElement(name = "DatOprichtingRechtspSamenwerking")
                @Size(max = 8)
                protected String datOprichtingRechtspSamenwerking;
                @XmlElement(name = "Rsin")
                @Size(min = 9, max = 9)
                @Pattern(regexp = "[0-9]*")
                protected String rsin;
                @XmlElement(name = "DatBNietNatuurlijkPersoon")
                @Size(max = 8)
                protected String datBNietNatuurlijkPersoon;
                @XmlElement(name = "CdFictieveDatB")
                @Size(min = 1, max = 1)
                @Pattern(regexp = "\\d*")
                protected String cdFictieveDatB;
                @XmlElement(name = "DatENietNatuurlijkPersoon")
                @Size(max = 8)
                protected String datENietNatuurlijkPersoon;
                @XmlElement(name = "CdFictieveDatE")
                @Size(min = 1, max = 1)
                @Pattern(regexp = "\\d*")
                protected String cdFictieveDatE;
                @XmlElement(name = "VolledigeNmNietNatuurlijkPersoon")
                @Size(max = 500)
                protected String volledigeNmNietNatuurlijkPersoon;
                @XmlElement(name = "Rechtspersoon")
                @Valid
                protected CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NietNatuurlijkPersoon.Rechtspersoon rechtspersoon;
                @XmlElement(name = "VennootschapBuitenland")
                @Valid
                protected CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NietNatuurlijkPersoon.VennootschapBuitenland vennootschapBuitenland;

                /**
                 * Gets the value of the datOntbindingRechtspSamenwerking property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getDatOntbindingRechtspSamenwerking() {
                    return datOntbindingRechtspSamenwerking;
                }

                /**
                 * Sets the value of the datOntbindingRechtspSamenwerking property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setDatOntbindingRechtspSamenwerking(String value) {
                    this.datOntbindingRechtspSamenwerking = value;
                }

                /**
                 * Gets the value of the datOprichtingRechtspSamenwerking property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getDatOprichtingRechtspSamenwerking() {
                    return datOprichtingRechtspSamenwerking;
                }

                /**
                 * Sets the value of the datOprichtingRechtspSamenwerking property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setDatOprichtingRechtspSamenwerking(String value) {
                    this.datOprichtingRechtspSamenwerking = value;
                }

                /**
                 * Gets the value of the rsin property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getRsin() {
                    return rsin;
                }

                /**
                 * Sets the value of the rsin property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setRsin(String value) {
                    this.rsin = value;
                }

                /**
                 * Gets the value of the datBNietNatuurlijkPersoon property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getDatBNietNatuurlijkPersoon() {
                    return datBNietNatuurlijkPersoon;
                }

                /**
                 * Sets the value of the datBNietNatuurlijkPersoon property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setDatBNietNatuurlijkPersoon(String value) {
                    this.datBNietNatuurlijkPersoon = value;
                }

                /**
                 * Gets the value of the cdFictieveDatB property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getCdFictieveDatB() {
                    return cdFictieveDatB;
                }

                /**
                 * Sets the value of the cdFictieveDatB property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setCdFictieveDatB(String value) {
                    this.cdFictieveDatB = value;
                }

                /**
                 * Gets the value of the datENietNatuurlijkPersoon property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getDatENietNatuurlijkPersoon() {
                    return datENietNatuurlijkPersoon;
                }

                /**
                 * Sets the value of the datENietNatuurlijkPersoon property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setDatENietNatuurlijkPersoon(String value) {
                    this.datENietNatuurlijkPersoon = value;
                }

                /**
                 * Gets the value of the cdFictieveDatE property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getCdFictieveDatE() {
                    return cdFictieveDatE;
                }

                /**
                 * Sets the value of the cdFictieveDatE property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setCdFictieveDatE(String value) {
                    this.cdFictieveDatE = value;
                }

                /**
                 * Gets the value of the volledigeNmNietNatuurlijkPersoon property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getVolledigeNmNietNatuurlijkPersoon() {
                    return volledigeNmNietNatuurlijkPersoon;
                }

                /**
                 * Sets the value of the volledigeNmNietNatuurlijkPersoon property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setVolledigeNmNietNatuurlijkPersoon(String value) {
                    this.volledigeNmNietNatuurlijkPersoon = value;
                }

                /**
                 * Gets the value of the rechtspersoon property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NietNatuurlijkPersoon.Rechtspersoon }
                 *     
                 */
                public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NietNatuurlijkPersoon.Rechtspersoon getRechtspersoon() {
                    return rechtspersoon;
                }

                /**
                 * Sets the value of the rechtspersoon property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NietNatuurlijkPersoon.Rechtspersoon }
                 *     
                 */
                public void setRechtspersoon(CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NietNatuurlijkPersoon.Rechtspersoon value) {
                    this.rechtspersoon = value;
                }

                /**
                 * Gets the value of the vennootschapBuitenland property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NietNatuurlijkPersoon.VennootschapBuitenland }
                 *     
                 */
                public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NietNatuurlijkPersoon.VennootschapBuitenland getVennootschapBuitenland() {
                    return vennootschapBuitenland;
                }

                /**
                 * Sets the value of the vennootschapBuitenland property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NietNatuurlijkPersoon.VennootschapBuitenland }
                 *     
                 */
                public void setVennootschapBuitenland(CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NietNatuurlijkPersoon.VennootschapBuitenland value) {
                    this.vennootschapBuitenland = value;
                }


                /**
                 * <p>Java class for anonymous complex type.
                 * 
                 * <p>The following schema fragment specifies the expected content contained within this class.
                 * 
                 * <pre>
                 * &lt;complexType&gt;
                 *   &lt;complexContent&gt;
                 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                 *       &lt;sequence&gt;
                 *         &lt;element name="StatutaireZetel" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar60" minOccurs="0"/&gt;
                 *         &lt;element name="DatBStatutaireZetel" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                 *         &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                 *         &lt;element name="ActiviteitHandelsregister" minOccurs="0"&gt;
                 *           &lt;complexType&gt;
                 *             &lt;complexContent&gt;
                 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                 *                 &lt;sequence&gt;
                 *                   &lt;element name="OmsActiviteitHandelsregister" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdTekstAnVar2000" minOccurs="0"/&gt;
                 *                 &lt;/sequence&gt;
                 *               &lt;/restriction&gt;
                 *             &lt;/complexContent&gt;
                 *           &lt;/complexType&gt;
                 *         &lt;/element&gt;
                 *       &lt;/sequence&gt;
                 *     &lt;/restriction&gt;
                 *   &lt;/complexContent&gt;
                 * &lt;/complexType&gt;
                 * </pre>
                 * 
                 * 
                 */
                @XmlAccessorType(XmlAccessType.FIELD)
                @XmlType(name = "", propOrder = {
                    "statutaireZetel",
                    "datBStatutaireZetel",
                    "cdFictieveDatB",
                    "activiteitHandelsregister"
                })
                public static class Rechtspersoon {

                    @XmlElement(name = "StatutaireZetel")
                    @Size(max = 60)
                    protected String statutaireZetel;
                    @XmlElement(name = "DatBStatutaireZetel")
                    @Size(max = 8)
                    protected String datBStatutaireZetel;
                    @XmlElement(name = "CdFictieveDatB")
                    @Size(min = 1, max = 1)
                    @Pattern(regexp = "\\d*")
                    protected String cdFictieveDatB;
                    @XmlElement(name = "ActiviteitHandelsregister")
                    @Valid
                    protected CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NietNatuurlijkPersoon.Rechtspersoon.ActiviteitHandelsregister activiteitHandelsregister;

                    /**
                     * Gets the value of the statutaireZetel property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getStatutaireZetel() {
                        return statutaireZetel;
                    }

                    /**
                     * Sets the value of the statutaireZetel property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setStatutaireZetel(String value) {
                        this.statutaireZetel = value;
                    }

                    /**
                     * Gets the value of the datBStatutaireZetel property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getDatBStatutaireZetel() {
                        return datBStatutaireZetel;
                    }

                    /**
                     * Sets the value of the datBStatutaireZetel property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setDatBStatutaireZetel(String value) {
                        this.datBStatutaireZetel = value;
                    }

                    /**
                     * Gets the value of the cdFictieveDatB property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getCdFictieveDatB() {
                        return cdFictieveDatB;
                    }

                    /**
                     * Sets the value of the cdFictieveDatB property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setCdFictieveDatB(String value) {
                        this.cdFictieveDatB = value;
                    }

                    /**
                     * Gets the value of the activiteitHandelsregister property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NietNatuurlijkPersoon.Rechtspersoon.ActiviteitHandelsregister }
                     *     
                     */
                    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NietNatuurlijkPersoon.Rechtspersoon.ActiviteitHandelsregister getActiviteitHandelsregister() {
                        return activiteitHandelsregister;
                    }

                    /**
                     * Sets the value of the activiteitHandelsregister property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NietNatuurlijkPersoon.Rechtspersoon.ActiviteitHandelsregister }
                     *     
                     */
                    public void setActiviteitHandelsregister(CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NietNatuurlijkPersoon.Rechtspersoon.ActiviteitHandelsregister value) {
                        this.activiteitHandelsregister = value;
                    }


                    /**
                     * <p>Java class for anonymous complex type.
                     * 
                     * <p>The following schema fragment specifies the expected content contained within this class.
                     * 
                     * <pre>
                     * &lt;complexType&gt;
                     *   &lt;complexContent&gt;
                     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                     *       &lt;sequence&gt;
                     *         &lt;element name="OmsActiviteitHandelsregister" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdTekstAnVar2000" minOccurs="0"/&gt;
                     *       &lt;/sequence&gt;
                     *     &lt;/restriction&gt;
                     *   &lt;/complexContent&gt;
                     * &lt;/complexType&gt;
                     * </pre>
                     * 
                     * 
                     */
                    @XmlAccessorType(XmlAccessType.FIELD)
                    @XmlType(name = "", propOrder = {
                        "omsActiviteitHandelsregister"
                    })
                    public static class ActiviteitHandelsregister {

                        @XmlElement(name = "OmsActiviteitHandelsregister")
                        @Size(max = 2000)
                        protected String omsActiviteitHandelsregister;

                        /**
                         * Gets the value of the omsActiviteitHandelsregister property.
                         * 
                         * @return
                         *     possible object is
                         *     {@link String }
                         *     
                         */
                        public String getOmsActiviteitHandelsregister() {
                            return omsActiviteitHandelsregister;
                        }

                        /**
                         * Sets the value of the omsActiviteitHandelsregister property.
                         * 
                         * @param value
                         *     allowed object is
                         *     {@link String }
                         *     
                         */
                        public void setOmsActiviteitHandelsregister(String value) {
                            this.omsActiviteitHandelsregister = value;
                        }

                    }

                }


                /**
                 * <p>Java class for anonymous complex type.
                 * 
                 * <p>The following schema fragment specifies the expected content contained within this class.
                 * 
                 * <pre>
                 * &lt;complexType&gt;
                 *   &lt;complexContent&gt;
                 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
                 *       &lt;sequence&gt;
                 *         &lt;element name="DatBVennootschapBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                 *         &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                 *         &lt;element name="DatEVennootschapBuitenland" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
                 *         &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
                 *       &lt;/sequence&gt;
                 *     &lt;/restriction&gt;
                 *   &lt;/complexContent&gt;
                 * &lt;/complexType&gt;
                 * </pre>
                 * 
                 * 
                 */
                @XmlAccessorType(XmlAccessType.FIELD)
                @XmlType(name = "", propOrder = {
                    "datBVennootschapBuitenland",
                    "cdFictieveDatB",
                    "datEVennootschapBuitenland",
                    "cdFictieveDatE"
                })
                public static class VennootschapBuitenland {

                    @XmlElement(name = "DatBVennootschapBuitenland")
                    @Size(max = 8)
                    protected String datBVennootschapBuitenland;
                    @XmlElement(name = "CdFictieveDatB")
                    @Size(min = 1, max = 1)
                    @Pattern(regexp = "\\d*")
                    protected String cdFictieveDatB;
                    @XmlElement(name = "DatEVennootschapBuitenland")
                    @Size(max = 8)
                    protected String datEVennootschapBuitenland;
                    @XmlElement(name = "CdFictieveDatE")
                    @Size(min = 1, max = 1)
                    @Pattern(regexp = "\\d*")
                    protected String cdFictieveDatE;

                    /**
                     * Gets the value of the datBVennootschapBuitenland property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getDatBVennootschapBuitenland() {
                        return datBVennootschapBuitenland;
                    }

                    /**
                     * Sets the value of the datBVennootschapBuitenland property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setDatBVennootschapBuitenland(String value) {
                        this.datBVennootschapBuitenland = value;
                    }

                    /**
                     * Gets the value of the cdFictieveDatB property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getCdFictieveDatB() {
                        return cdFictieveDatB;
                    }

                    /**
                     * Sets the value of the cdFictieveDatB property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setCdFictieveDatB(String value) {
                        this.cdFictieveDatB = value;
                    }

                    /**
                     * Gets the value of the datEVennootschapBuitenland property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getDatEVennootschapBuitenland() {
                        return datEVennootschapBuitenland;
                    }

                    /**
                     * Sets the value of the datEVennootschapBuitenland property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setDatEVennootschapBuitenland(String value) {
                        this.datEVennootschapBuitenland = value;
                    }

                    /**
                     * Gets the value of the cdFictieveDatE property.
                     * 
                     * @return
                     *     possible object is
                     *     {@link String }
                     *     
                     */
                    public String getCdFictieveDatE() {
                        return cdFictieveDatE;
                    }

                    /**
                     * Sets the value of the cdFictieveDatE property.
                     * 
                     * @param value
                     *     allowed object is
                     *     {@link String }
                     *     
                     */
                    public void setCdFictieveDatE(String value) {
                        this.cdFictieveDatE = value;
                    }

                }

            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType&gt;
             *   &lt;complexContent&gt;
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *       &lt;sequence&gt;
             *         &lt;element name="DatBPersoonHandelsregister" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *         &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
             *         &lt;element name="DatEPersoonHandelsregister" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *         &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
             *         &lt;element name="NaamPersoonHandelsregister" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar300" minOccurs="0"/&gt;
             *         &lt;element name="VolledigeNmPersHandelsregister" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdTekstAnVar500" minOccurs="0"/&gt;
             *       &lt;/sequence&gt;
             *     &lt;/restriction&gt;
             *   &lt;/complexContent&gt;
             * &lt;/complexType&gt;
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "datBPersoonHandelsregister",
                "cdFictieveDatB",
                "datEPersoonHandelsregister",
                "cdFictieveDatE",
                "naamPersoonHandelsregister",
                "volledigeNmPersHandelsregister"
            })
            public static class PersoonHandelsregister {

                @XmlElement(name = "DatBPersoonHandelsregister")
                @Size(max = 8)
                protected String datBPersoonHandelsregister;
                @XmlElement(name = "CdFictieveDatB")
                @Size(min = 1, max = 1)
                @Pattern(regexp = "\\d*")
                protected String cdFictieveDatB;
                @XmlElement(name = "DatEPersoonHandelsregister")
                @Size(max = 8)
                protected String datEPersoonHandelsregister;
                @XmlElement(name = "CdFictieveDatE")
                @Size(min = 1, max = 1)
                @Pattern(regexp = "\\d*")
                protected String cdFictieveDatE;
                @XmlElement(name = "NaamPersoonHandelsregister")
                @Size(max = 300)
                protected String naamPersoonHandelsregister;
                @XmlElement(name = "VolledigeNmPersHandelsregister")
                @Size(max = 500)
                protected String volledigeNmPersHandelsregister;

                /**
                 * Gets the value of the datBPersoonHandelsregister property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getDatBPersoonHandelsregister() {
                    return datBPersoonHandelsregister;
                }

                /**
                 * Sets the value of the datBPersoonHandelsregister property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setDatBPersoonHandelsregister(String value) {
                    this.datBPersoonHandelsregister = value;
                }

                /**
                 * Gets the value of the cdFictieveDatB property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getCdFictieveDatB() {
                    return cdFictieveDatB;
                }

                /**
                 * Sets the value of the cdFictieveDatB property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setCdFictieveDatB(String value) {
                    this.cdFictieveDatB = value;
                }

                /**
                 * Gets the value of the datEPersoonHandelsregister property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getDatEPersoonHandelsregister() {
                    return datEPersoonHandelsregister;
                }

                /**
                 * Sets the value of the datEPersoonHandelsregister property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setDatEPersoonHandelsregister(String value) {
                    this.datEPersoonHandelsregister = value;
                }

                /**
                 * Gets the value of the cdFictieveDatE property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getCdFictieveDatE() {
                    return cdFictieveDatE;
                }

                /**
                 * Sets the value of the cdFictieveDatE property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setCdFictieveDatE(String value) {
                    this.cdFictieveDatE = value;
                }

                /**
                 * Gets the value of the naamPersoonHandelsregister property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getNaamPersoonHandelsregister() {
                    return naamPersoonHandelsregister;
                }

                /**
                 * Sets the value of the naamPersoonHandelsregister property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setNaamPersoonHandelsregister(String value) {
                    this.naamPersoonHandelsregister = value;
                }

                /**
                 * Gets the value of the volledigeNmPersHandelsregister property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getVolledigeNmPersHandelsregister() {
                    return volledigeNmPersHandelsregister;
                }

                /**
                 * Sets the value of the volledigeNmPersHandelsregister property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setVolledigeNmPersHandelsregister(String value) {
                    this.volledigeNmPersHandelsregister = value;
                }

            }


            /**
             * <p>Java class for anonymous complex type.
             * 
             * <p>The following schema fragment specifies the expected content contained within this class.
             * 
             * <pre>
             * &lt;complexType&gt;
             *   &lt;complexContent&gt;
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
             *       &lt;sequence&gt;
             *         &lt;element name="CdRechtsvorm" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdCdRechtsvorm" minOccurs="0"/&gt;
             *         &lt;element name="DatBRechtsvorm" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *         &lt;element name="CdFictieveDatB" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
             *         &lt;element name="DatERechtsvorm" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso" minOccurs="0"/&gt;
             *         &lt;element name="CdFictieveDatE" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0007}StdCdFictieveDat_nocodes" minOccurs="0"/&gt;
             *       &lt;/sequence&gt;
             *     &lt;/restriction&gt;
             *   &lt;/complexContent&gt;
             * &lt;/complexType&gt;
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "cdRechtsvorm",
                "datBRechtsvorm",
                "cdFictieveDatB",
                "datERechtsvorm",
                "cdFictieveDatE"
            })
            public static class Rechtsvorm {

                @XmlElement(name = "CdRechtsvorm")
                @Size(min = 3, max = 3)
                @Pattern(regexp = "[0-9]*")
                protected String cdRechtsvorm;
                @XmlElement(name = "DatBRechtsvorm")
                @Size(max = 8)
                protected String datBRechtsvorm;
                @XmlElement(name = "CdFictieveDatB")
                @Size(min = 1, max = 1)
                @Pattern(regexp = "\\d*")
                protected String cdFictieveDatB;
                @XmlElement(name = "DatERechtsvorm")
                @Size(max = 8)
                protected String datERechtsvorm;
                @XmlElement(name = "CdFictieveDatE")
                @Size(min = 1, max = 1)
                @Pattern(regexp = "\\d*")
                protected String cdFictieveDatE;

                /**
                 * Gets the value of the cdRechtsvorm property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getCdRechtsvorm() {
                    return cdRechtsvorm;
                }

                /**
                 * Sets the value of the cdRechtsvorm property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setCdRechtsvorm(String value) {
                    this.cdRechtsvorm = value;
                }

                /**
                 * Gets the value of the datBRechtsvorm property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getDatBRechtsvorm() {
                    return datBRechtsvorm;
                }

                /**
                 * Sets the value of the datBRechtsvorm property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setDatBRechtsvorm(String value) {
                    this.datBRechtsvorm = value;
                }

                /**
                 * Gets the value of the cdFictieveDatB property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getCdFictieveDatB() {
                    return cdFictieveDatB;
                }

                /**
                 * Sets the value of the cdFictieveDatB property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setCdFictieveDatB(String value) {
                    this.cdFictieveDatB = value;
                }

                /**
                 * Gets the value of the datERechtsvorm property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getDatERechtsvorm() {
                    return datERechtsvorm;
                }

                /**
                 * Sets the value of the datERechtsvorm property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setDatERechtsvorm(String value) {
                    this.datERechtsvorm = value;
                }

                /**
                 * Gets the value of the cdFictieveDatE property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getCdFictieveDatE() {
                    return cdFictieveDatE;
                }

                /**
                 * Sets the value of the cdFictieveDatE property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setCdFictieveDatE(String value) {
                    this.cdFictieveDatE = value;
                }

            }

        }

    }

}
