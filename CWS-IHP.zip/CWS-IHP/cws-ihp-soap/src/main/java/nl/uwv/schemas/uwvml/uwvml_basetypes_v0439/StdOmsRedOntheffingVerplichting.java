
package nl.uwv.schemas.uwvml.uwvml_basetypes_v0439;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for StdOmsRedOntheffingVerplichting.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <pre>
 * &lt;simpleType name="StdOmsRedOntheffingVerplichting"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;maxLength value="30"/&gt;
 *     &lt;enumeration value="BrugWW"/&gt;
 *     &lt;enumeration value="Calamiteit"/&gt;
 *     &lt;enumeration value="Mantelzorg"/&gt;
 *     &lt;enumeration value="Noodzakeli"/&gt;
 *     &lt;enumeration value="Onderzoekp"/&gt;
 *     &lt;enumeration value="Proefplaat"/&gt;
 *     &lt;enumeration value="Startperio"/&gt;
 *     &lt;enumeration value="Vakantie"/&gt;
 *     &lt;enumeration value="Ziekte"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "StdOmsRedOntheffingVerplichting", namespace = "http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439")
@XmlEnum
public enum StdOmsRedOntheffingVerplichting {


    /**
     * Brug-WW
     * 
     */
    @XmlEnumValue("BrugWW")
    BRUG_WW("BrugWW"),

    /**
     * Calamiteit
     * 
     */
    @XmlEnumValue("Calamiteit")
    CALAMITEIT("Calamiteit"),

    /**
     * Mantelzorg
     * 
     */
    @XmlEnumValue("Mantelzorg")
    MANTELZORG("Mantelzorg"),

    /**
     * Noodzakelijke scholing
     * 
     */
    @XmlEnumValue("Noodzakeli")
    NOODZAKELI("Noodzakeli"),

    /**
     * Onderzoekperiode zzp-er
     * 
     */
    @XmlEnumValue("Onderzoekp")
    ONDERZOEKP("Onderzoekp"),

    /**
     * Proefplaatsing
     * 
     */
    @XmlEnumValue("Proefplaat")
    PROEFPLAAT("Proefplaat"),

    /**
     * Startperiode zzp-er
     * 
     */
    @XmlEnumValue("Startperio")
    STARTPERIO("Startperio"),

    /**
     * Vakantie
     * 
     */
    @XmlEnumValue("Vakantie")
    VAKANTIE("Vakantie"),

    /**
     * Ziekte
     * 
     */
    @XmlEnumValue("Ziekte")
    ZIEKTE("Ziekte");
    private final String value;

    StdOmsRedOntheffingVerplichting(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static StdOmsRedOntheffingVerplichting fromValue(String v) {
        for (StdOmsRedOntheffingVerplichting c: StdOmsRedOntheffingVerplichting.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
