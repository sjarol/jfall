
package nl.uwv.schemas.uwvml.uwvml_basetypes_v0439;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for StdCdSrtWtl.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <pre>
 * &lt;simpleType name="StdCdSrtWtl"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;maxLength value="5"/&gt;
 *     &lt;enumeration value="LIV_1"/&gt;
 *     &lt;enumeration value="LIV_2"/&gt;
 *     &lt;enumeration value="LKV_1"/&gt;
 *     &lt;enumeration value="LKV_2"/&gt;
 *     &lt;enumeration value="LKV_3"/&gt;
 *     &lt;enumeration value="LKV_4"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "StdCdSrtWtl", namespace = "http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439")
@XmlEnum
public enum StdCdSrtWtl {


    /**
     * LIV laag
     * 
     */
    LIV_1,

    /**
     * Jeugd LIV
     * 
     */
    LIV_2,

    /**
     * Oudere werknemer in dienst nemen
     * 
     */
    LKV_1,

    /**
     * Arbeidsgehandicapte werknemer in dienst nemen
     * 
     */
    LKV_2,

    /**
     * Doelgroep Banenafspraak
     * 
     */
    LKV_3,

    /**
     * Herplaatsen arbeidsgehandicapte werknemer
     * 
     */
    LKV_4;

    public String value() {
        return name();
    }

    public static StdCdSrtWtl fromValue(String v) {
        return valueOf(v);
    }

}
