
package nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0007;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0007 package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0007
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse }
     * 
     */
    public CwsInhoudingsplichtigeResponse createCwsInhoudingsplichtigeResponse() {
        return new CwsInhoudingsplichtigeResponse();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering createCwsInhoudingsplichtigeResponseGegevenslevering() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige createCwsInhoudingsplichtigeResponseGegevensleveringPersoonInhoudingsplichtige() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid createCwsInhoudingsplichtigeResponseGegevensleveringPersoonInhoudingsplichtigeAdministratieveEenheid() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding createCwsInhoudingsplichtigeResponseGegevensleveringPersoonInhoudingsplichtigeAdministratieveEenheidAdreshouding() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresBuitenlandWga }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresBuitenlandWga createCwsInhoudingsplichtigeResponseGegevensleveringPersoonInhoudingsplichtigeAdministratieveEenheidAdreshoudingAdresBuitenlandWga() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresBuitenlandWga();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresNederlandWga }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresNederlandWga createCwsInhoudingsplichtigeResponseGegevensleveringPersoonInhoudingsplichtigeAdministratieveEenheidAdreshoudingAdresNederlandWga() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresNederlandWga();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit createCwsInhoudingsplichtigeResponseGegevensleveringPersoonInhoudingsplichtigeMaatschappelijkeActiviteit() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister createCwsInhoudingsplichtigeResponseGegevensleveringPersoonInhoudingsplichtigeMaatschappelijkeActiviteitVestigingHandelsregister() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Onderneming }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Onderneming createCwsInhoudingsplichtigeResponseGegevensleveringPersoonInhoudingsplichtigeMaatschappelijkeActiviteitVestigingHandelsregisterOnderneming() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Onderneming();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.ActiviteitHandelsregister }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.ActiviteitHandelsregister createCwsInhoudingsplichtigeResponseGegevensleveringPersoonInhoudingsplichtigeMaatschappelijkeActiviteitVestigingHandelsregisterActiviteitHandelsregister() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.ActiviteitHandelsregister();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding createCwsInhoudingsplichtigeResponseGegevensleveringPersoonInhoudingsplichtigeMaatschappelijkeActiviteitVestigingHandelsregisterAdreshouding() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresBuitenlandUhr }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresBuitenlandUhr createCwsInhoudingsplichtigeResponseGegevensleveringPersoonInhoudingsplichtigeMaatschappelijkeActiviteitVestigingHandelsregisterAdreshoudingAdresBuitenlandUhr() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresBuitenlandUhr();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresNederlandUhr }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresNederlandUhr createCwsInhoudingsplichtigeResponseGegevensleveringPersoonInhoudingsplichtigeMaatschappelijkeActiviteitVestigingHandelsregisterAdreshoudingAdresNederlandUhr() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresNederlandUhr();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding createCwsInhoudingsplichtigeResponseGegevensleveringPersoonInhoudingsplichtigeAdreshouding() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresBuitenlandUhr }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresBuitenlandUhr createCwsInhoudingsplichtigeResponseGegevensleveringPersoonInhoudingsplichtigeAdreshoudingAdresBuitenlandUhr() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresBuitenlandUhr();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresNederlandUhr }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresNederlandUhr createCwsInhoudingsplichtigeResponseGegevensleveringPersoonInhoudingsplichtigeAdreshoudingAdresNederlandUhr() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresNederlandUhr();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NatuurlijkPersoon }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NatuurlijkPersoon createCwsInhoudingsplichtigeResponseGegevensleveringPersoonInhoudingsplichtigeNatuurlijkPersoon() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NatuurlijkPersoon();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NietNatuurlijkPersoon }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NietNatuurlijkPersoon createCwsInhoudingsplichtigeResponseGegevensleveringPersoonInhoudingsplichtigeNietNatuurlijkPersoon() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NietNatuurlijkPersoon();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NietNatuurlijkPersoon.Rechtspersoon }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NietNatuurlijkPersoon.Rechtspersoon createCwsInhoudingsplichtigeResponseGegevensleveringPersoonInhoudingsplichtigeNietNatuurlijkPersoonRechtspersoon() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NietNatuurlijkPersoon.Rechtspersoon();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Applicatiemelding }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Applicatiemelding createCwsInhoudingsplichtigeResponseApplicatiemelding() {
        return new CwsInhoudingsplichtigeResponse.Applicatiemelding();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.PersoonHandelsregister }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.PersoonHandelsregister createCwsInhoudingsplichtigeResponseGegevensleveringPersoonInhoudingsplichtigePersoonHandelsregister() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.PersoonHandelsregister();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Rechtsvorm }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Rechtsvorm createCwsInhoudingsplichtigeResponseGegevensleveringPersoonInhoudingsplichtigeRechtsvorm() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Rechtsvorm();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.FaillSurs }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.FaillSurs createCwsInhoudingsplichtigeResponseGegevensleveringPersoonInhoudingsplichtigeFaillSurs() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.FaillSurs();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Gemoedsbezwaardheid }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Gemoedsbezwaardheid createCwsInhoudingsplichtigeResponseGegevensleveringPersoonInhoudingsplichtigeGemoedsbezwaardheid() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Gemoedsbezwaardheid();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.SectorRisicogroep }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.SectorRisicogroep createCwsInhoudingsplichtigeResponseGegevensleveringPersoonInhoudingsplichtigeAdministratieveEenheidSectorRisicogroep() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.SectorRisicogroep();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.PremiepercIndividueel }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.PremiepercIndividueel createCwsInhoudingsplichtigeResponseGegevensleveringPersoonInhoudingsplichtigeAdministratieveEenheidPremiepercIndividueel() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.PremiepercIndividueel();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.EigenRisicoDrager }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.EigenRisicoDrager createCwsInhoudingsplichtigeResponseGegevensleveringPersoonInhoudingsplichtigeAdministratieveEenheidEigenRisicoDrager() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.EigenRisicoDrager();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.VoortzettingsrelatieOpvolger }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.VoortzettingsrelatieOpvolger createCwsInhoudingsplichtigeResponseGegevensleveringPersoonInhoudingsplichtigeAdministratieveEenheidVoortzettingsrelatieOpvolger() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.VoortzettingsrelatieOpvolger();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.VoortzettingsrelatieVoorganger }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.VoortzettingsrelatieVoorganger createCwsInhoudingsplichtigeResponseGegevensleveringPersoonInhoudingsplichtigeAdministratieveEenheidVoortzettingsrelatieVoorganger() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.VoortzettingsrelatieVoorganger();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.AangifteFrequentieAdminEenheid }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.AangifteFrequentieAdminEenheid createCwsInhoudingsplichtigeResponseGegevensleveringPersoonInhoudingsplichtigeAdministratieveEenheidAangifteFrequentieAdminEenheid() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.AangifteFrequentieAdminEenheid();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.AansluitingsnrBv }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.AansluitingsnrBv createCwsInhoudingsplichtigeResponseGegevensleveringPersoonInhoudingsplichtigeAdministratieveEenheidAansluitingsnrBv() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.AansluitingsnrBv();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresBuitenlandOngestructureerdWga }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresBuitenlandOngestructureerdWga createCwsInhoudingsplichtigeResponseGegevensleveringPersoonInhoudingsplichtigeAdministratieveEenheidAdreshoudingAdresBuitenlandOngestructureerdWga() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresBuitenlandOngestructureerdWga();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresBuitenlandWga.StraatadresBuitenlandWga }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresBuitenlandWga.StraatadresBuitenlandWga createCwsInhoudingsplichtigeResponseGegevensleveringPersoonInhoudingsplichtigeAdministratieveEenheidAdreshoudingAdresBuitenlandWgaStraatadresBuitenlandWga() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresBuitenlandWga.StraatadresBuitenlandWga();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresBuitenlandWga.PostbusadresBuitenlandWga }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresBuitenlandWga.PostbusadresBuitenlandWga createCwsInhoudingsplichtigeResponseGegevensleveringPersoonInhoudingsplichtigeAdministratieveEenheidAdreshoudingAdresBuitenlandWgaPostbusadresBuitenlandWga() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresBuitenlandWga.PostbusadresBuitenlandWga();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresNederlandWga.StraatadresWga }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresNederlandWga.StraatadresWga createCwsInhoudingsplichtigeResponseGegevensleveringPersoonInhoudingsplichtigeAdministratieveEenheidAdreshoudingAdresNederlandWgaStraatadresWga() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresNederlandWga.StraatadresWga();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresNederlandWga.PostbusadresWga }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresNederlandWga.PostbusadresWga createCwsInhoudingsplichtigeResponseGegevensleveringPersoonInhoudingsplichtigeAdministratieveEenheidAdreshoudingAdresNederlandWgaPostbusadresWga() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.AdministratieveEenheid.Adreshouding.AdresNederlandWga.PostbusadresWga();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.Sbiklasse }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.Sbiklasse createCwsInhoudingsplichtigeResponseGegevensleveringPersoonInhoudingsplichtigeMaatschappelijkeActiviteitSbiklasse() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.Sbiklasse();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Handelsnaam }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Handelsnaam createCwsInhoudingsplichtigeResponseGegevensleveringPersoonInhoudingsplichtigeMaatschappelijkeActiviteitVestigingHandelsregisterHandelsnaam() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Handelsnaam();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Onderneming.Sbiklasse }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Onderneming.Sbiklasse createCwsInhoudingsplichtigeResponseGegevensleveringPersoonInhoudingsplichtigeMaatschappelijkeActiviteitVestigingHandelsregisterOndernemingSbiklasse() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Onderneming.Sbiklasse();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Onderneming.Handelsnaam }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Onderneming.Handelsnaam createCwsInhoudingsplichtigeResponseGegevensleveringPersoonInhoudingsplichtigeMaatschappelijkeActiviteitVestigingHandelsregisterOndernemingHandelsnaam() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Onderneming.Handelsnaam();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.ActiviteitHandelsregister.Sbiklasse }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.ActiviteitHandelsregister.Sbiklasse createCwsInhoudingsplichtigeResponseGegevensleveringPersoonInhoudingsplichtigeMaatschappelijkeActiviteitVestigingHandelsregisterActiviteitHandelsregisterSbiklasse() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.ActiviteitHandelsregister.Sbiklasse();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresBuitenlandOngestructureerdUhr }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresBuitenlandOngestructureerdUhr createCwsInhoudingsplichtigeResponseGegevensleveringPersoonInhoudingsplichtigeMaatschappelijkeActiviteitVestigingHandelsregisterAdreshoudingAdresBuitenlandOngestructureerdUhr() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresBuitenlandOngestructureerdUhr();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresBuitenlandUhr.StraatadresBuitenlandUhr }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresBuitenlandUhr.StraatadresBuitenlandUhr createCwsInhoudingsplichtigeResponseGegevensleveringPersoonInhoudingsplichtigeMaatschappelijkeActiviteitVestigingHandelsregisterAdreshoudingAdresBuitenlandUhrStraatadresBuitenlandUhr() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresBuitenlandUhr.StraatadresBuitenlandUhr();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresBuitenlandUhr.PostbusadresBuitenlandUhr }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresBuitenlandUhr.PostbusadresBuitenlandUhr createCwsInhoudingsplichtigeResponseGegevensleveringPersoonInhoudingsplichtigeMaatschappelijkeActiviteitVestigingHandelsregisterAdreshoudingAdresBuitenlandUhrPostbusadresBuitenlandUhr() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresBuitenlandUhr.PostbusadresBuitenlandUhr();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresNederlandUhr.StraatadresUhr }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresNederlandUhr.StraatadresUhr createCwsInhoudingsplichtigeResponseGegevensleveringPersoonInhoudingsplichtigeMaatschappelijkeActiviteitVestigingHandelsregisterAdreshoudingAdresNederlandUhrStraatadresUhr() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresNederlandUhr.StraatadresUhr();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresNederlandUhr.PostbusadresUhr }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresNederlandUhr.PostbusadresUhr createCwsInhoudingsplichtigeResponseGegevensleveringPersoonInhoudingsplichtigeMaatschappelijkeActiviteitVestigingHandelsregisterAdreshoudingAdresNederlandUhrPostbusadresUhr() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.MaatschappelijkeActiviteit.VestigingHandelsregister.Adreshouding.AdresNederlandUhr.PostbusadresUhr();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresBuitenlandOngestructureerdUhr }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresBuitenlandOngestructureerdUhr createCwsInhoudingsplichtigeResponseGegevensleveringPersoonInhoudingsplichtigeAdreshoudingAdresBuitenlandOngestructureerdUhr() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresBuitenlandOngestructureerdUhr();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresBuitenlandUhr.StraatadresBuitenlandUhr }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresBuitenlandUhr.StraatadresBuitenlandUhr createCwsInhoudingsplichtigeResponseGegevensleveringPersoonInhoudingsplichtigeAdreshoudingAdresBuitenlandUhrStraatadresBuitenlandUhr() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresBuitenlandUhr.StraatadresBuitenlandUhr();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresBuitenlandUhr.PostbusadresBuitenlandUhr }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresBuitenlandUhr.PostbusadresBuitenlandUhr createCwsInhoudingsplichtigeResponseGegevensleveringPersoonInhoudingsplichtigeAdreshoudingAdresBuitenlandUhrPostbusadresBuitenlandUhr() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresBuitenlandUhr.PostbusadresBuitenlandUhr();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresNederlandUhr.StraatadresUhr }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresNederlandUhr.StraatadresUhr createCwsInhoudingsplichtigeResponseGegevensleveringPersoonInhoudingsplichtigeAdreshoudingAdresNederlandUhrStraatadresUhr() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresNederlandUhr.StraatadresUhr();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresNederlandUhr.PostbusadresUhr }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresNederlandUhr.PostbusadresUhr createCwsInhoudingsplichtigeResponseGegevensleveringPersoonInhoudingsplichtigeAdreshoudingAdresNederlandUhrPostbusadresUhr() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.Adreshouding.AdresNederlandUhr.PostbusadresUhr();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NatuurlijkPersoon.HuwelijkGeregistreerdPartner }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NatuurlijkPersoon.HuwelijkGeregistreerdPartner createCwsInhoudingsplichtigeResponseGegevensleveringPersoonInhoudingsplichtigeNatuurlijkPersoonHuwelijkGeregistreerdPartner() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NatuurlijkPersoon.HuwelijkGeregistreerdPartner();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NietNatuurlijkPersoon.VennootschapBuitenland }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NietNatuurlijkPersoon.VennootschapBuitenland createCwsInhoudingsplichtigeResponseGegevensleveringPersoonInhoudingsplichtigeNietNatuurlijkPersoonVennootschapBuitenland() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NietNatuurlijkPersoon.VennootschapBuitenland();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NietNatuurlijkPersoon.Rechtspersoon.ActiviteitHandelsregister }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NietNatuurlijkPersoon.Rechtspersoon.ActiviteitHandelsregister createCwsInhoudingsplichtigeResponseGegevensleveringPersoonInhoudingsplichtigeNietNatuurlijkPersoonRechtspersoonActiviteitHandelsregister() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.PersoonInhoudingsplichtige.NietNatuurlijkPersoon.Rechtspersoon.ActiviteitHandelsregister();
    }

}
