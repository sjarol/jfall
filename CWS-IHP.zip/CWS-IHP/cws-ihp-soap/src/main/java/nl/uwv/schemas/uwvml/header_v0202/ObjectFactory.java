
package nl.uwv.schemas.uwvml.header_v0202;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the nl.uwv.schemas.uwvml.header_v0202 package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _UwvMLHeader_QNAME = new QName("http://schemas.uwv.nl/UwvML/Header-v0202", "UwvMLHeader");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: nl.uwv.schemas.uwvml.header_v0202
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link BerichtIdentificatie }
     * 
     */
    public BerichtIdentificatie createBerichtIdentificatie() {
        return new BerichtIdentificatie();
    }

    /**
     * Create an instance of {@link nl.uwv.schemas.uwvml.header_v0202.RouteInformatie }
     * 
     */
    public nl.uwv.schemas.uwvml.header_v0202.RouteInformatie createRouteInformatie() {
        return new nl.uwv.schemas.uwvml.header_v0202.RouteInformatie();
    }

    /**
     * Create an instance of {@link UwvMLHeader }
     * 
     */
    public UwvMLHeader createUwvMLHeader() {
        return new UwvMLHeader();
    }

    /**
     * Create an instance of {@link Partij }
     * 
     */
    public Partij createPartij() {
        return new Partij();
    }

    /**
     * Create an instance of {@link Transactie }
     * 
     */
    public Transactie createTransactie() {
        return new Transactie();
    }

    /**
     * Create an instance of {@link TussenstationType }
     * 
     */
    public TussenstationType createTussenstationType() {
        return new TussenstationType();
    }

    /**
     * Create an instance of {@link Authenticatie }
     * 
     */
    public Authenticatie createAuthenticatie() {
        return new Authenticatie();
    }

    /**
     * Create an instance of {@link TransportServiceWensen }
     * 
     */
    public TransportServiceWensen createTransportServiceWensen() {
        return new TransportServiceWensen();
    }

    /**
     * Create an instance of {@link BerichtIdentificatie.BerichtType }
     * 
     */
    public BerichtIdentificatie.BerichtType createBerichtIdentificatieBerichtType() {
        return new BerichtIdentificatie.BerichtType();
    }

    /**
     * Create an instance of {@link nl.uwv.schemas.uwvml.header_v0202.RouteInformatie.Bron }
     * 
     */
    public nl.uwv.schemas.uwvml.header_v0202.RouteInformatie.Bron createRouteInformatieBron() {
        return new nl.uwv.schemas.uwvml.header_v0202.RouteInformatie.Bron();
    }

    /**
     * Create an instance of {@link UwvMLHeader.RouteInformatie }
     * 
     */
    public UwvMLHeader.RouteInformatie createUwvMLHeaderRouteInformatie() {
        return new UwvMLHeader.RouteInformatie();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UwvMLHeader }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link UwvMLHeader }{@code >}
     */
    @XmlElementDecl(namespace = "http://schemas.uwv.nl/UwvML/Header-v0202", name = "UwvMLHeader")
    public JAXBElement<UwvMLHeader> createUwvMLHeader(UwvMLHeader value) {
        return new JAXBElement<UwvMLHeader>(_UwvMLHeader_QNAME, UwvMLHeader.class, null, value);
    }

}
