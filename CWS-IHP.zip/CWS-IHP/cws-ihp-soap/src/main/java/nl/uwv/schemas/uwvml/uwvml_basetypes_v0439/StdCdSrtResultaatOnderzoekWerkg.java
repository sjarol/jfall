
package nl.uwv.schemas.uwvml.uwvml_basetypes_v0439;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for StdCdSrtResultaatOnderzoekWerkg.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <pre>
 * &lt;simpleType name="StdCdSrtResultaatOnderzoekWerkg"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;maxLength value="3"/&gt;
 *     &lt;enumeration value="SBW"/&gt;
 *     &lt;enumeration value="TVG"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "StdCdSrtResultaatOnderzoekWerkg", namespace = "http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439")
@XmlEnum
public enum StdCdSrtResultaatOnderzoekWerkg {


    /**
     * Schadebesparing
     * 
     */
    SBW,

    /**
     * Terugvordering
     * 
     */
    TVG;

    public String value() {
        return name();
    }

    public static StdCdSrtResultaatOnderzoekWerkg fromValue(String v) {
        return valueOf(v);
    }

}
