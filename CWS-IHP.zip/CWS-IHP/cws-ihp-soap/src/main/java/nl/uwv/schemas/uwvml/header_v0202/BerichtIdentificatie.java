
package nl.uwv.schemas.uwvml.header_v0202;

import javax.validation.Valid;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * Berichteigenschappen ter indicatie van het doel van het bericht.
 * 
 * <p>Java class for BerichtIdentificatie complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BerichtIdentificatie"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="BerichtReferentienr" type="{http://www.w3.org/2001/XMLSchema}anyURI"/&gt;
 *         &lt;element name="HerhalingsPogingnr" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}unsignedInt"&gt;
 *               &lt;minInclusive value="1"/&gt;
 *               &lt;maxInclusive value="999"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="BerichtType"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="BerichtNaam"&gt;
 *                     &lt;simpleType&gt;
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *                         &lt;maxLength value="100"/&gt;
 *                       &lt;/restriction&gt;
 *                     &lt;/simpleType&gt;
 *                   &lt;/element&gt;
 *                   &lt;element name="VersieMajor"&gt;
 *                     &lt;simpleType&gt;
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *                         &lt;length value="2"/&gt;
 *                         &lt;pattern value="\d*"/&gt;
 *                       &lt;/restriction&gt;
 *                     &lt;/simpleType&gt;
 *                   &lt;/element&gt;
 *                   &lt;element name="VersieMinor"&gt;
 *                     &lt;simpleType&gt;
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *                         &lt;length value="2"/&gt;
 *                         &lt;pattern value="\d*"/&gt;
 *                       &lt;/restriction&gt;
 *                     &lt;/simpleType&gt;
 *                   &lt;/element&gt;
 *                   &lt;element name="Buildnr"&gt;
 *                     &lt;simpleType&gt;
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *                         &lt;length value="2"/&gt;
 *                         &lt;pattern value="\d*"/&gt;
 *                       &lt;/restriction&gt;
 *                     &lt;/simpleType&gt;
 *                   &lt;/element&gt;
 *                   &lt;element name="CommunicatieType"&gt;
 *                     &lt;simpleType&gt;
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *                         &lt;enumeration value="Inkijk"/&gt;
 *                         &lt;enumeration value="Melding"/&gt;
 *                       &lt;/restriction&gt;
 *                     &lt;/simpleType&gt;
 *                   &lt;/element&gt;
 *                   &lt;element name="CommunicatieElement"&gt;
 *                     &lt;simpleType&gt;
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *                         &lt;enumeration value="Request"/&gt;
 *                         &lt;enumeration value="Response"/&gt;
 *                         &lt;enumeration value="Melding"/&gt;
 *                         &lt;enumeration value="Bevestiging"/&gt;
 *                         &lt;enumeration value="Redirect"/&gt;
 *                         &lt;enumeration value="Fout"/&gt;
 *                         &lt;enumeration value="Acknowledgement"/&gt;
 *                       &lt;/restriction&gt;
 *                     &lt;/simpleType&gt;
 *                   &lt;/element&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DatTijdAanmaakBericht" type="{http://www.w3.org/2001/XMLSchema}dateTime"/&gt;
 *         &lt;element name="DatTijdVersturenBericht" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/&gt;
 *         &lt;element name="RequestBerichtReferentienr" type="{http://www.w3.org/2001/XMLSchema}anyURI" minOccurs="0"/&gt;
 *         &lt;element name="DatTijdOntvangstBericht" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/&gt;
 *         &lt;element name="IndTestbericht"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}unsignedInt"&gt;
 *               &lt;enumeration value="1"/&gt;
 *               &lt;enumeration value="2"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ApplicatieInformatie" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="256"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BerichtIdentificatie", propOrder = {
    "berichtReferentienr",
    "herhalingsPogingnr",
    "berichtType",
    "datTijdAanmaakBericht",
    "datTijdVersturenBericht",
    "requestBerichtReferentienr",
    "datTijdOntvangstBericht",
    "indTestbericht",
    "applicatieInformatie"
})
public class BerichtIdentificatie {

    @XmlElement(name = "BerichtReferentienr", required = true)
    @XmlSchemaType(name = "anyURI")
    @NotNull
    protected String berichtReferentienr;
    @XmlElement(name = "HerhalingsPogingnr")
    @DecimalMax("999")
    @DecimalMin("1")
    protected Long herhalingsPogingnr;
    @XmlElement(name = "BerichtType", required = true)
    @NotNull
    @Valid
    protected BerichtIdentificatie.BerichtType berichtType;
    @XmlElement(name = "DatTijdAanmaakBericht", required = true)
    @XmlSchemaType(name = "dateTime")
    @NotNull
    protected XMLGregorianCalendar datTijdAanmaakBericht;
    @XmlElement(name = "DatTijdVersturenBericht")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar datTijdVersturenBericht;
    @XmlElement(name = "RequestBerichtReferentienr")
    @XmlSchemaType(name = "anyURI")
    protected String requestBerichtReferentienr;
    @XmlElement(name = "DatTijdOntvangstBericht")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar datTijdOntvangstBericht;
    @XmlElement(name = "IndTestbericht")
    @NotNull
    @DecimalMax("4294967295")
    @DecimalMin("0")
    protected long indTestbericht;
    @XmlElement(name = "ApplicatieInformatie")
    @Size(max = 256)
    protected String applicatieInformatie;

    /**
     * Gets the value of the berichtReferentienr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBerichtReferentienr() {
        return berichtReferentienr;
    }

    /**
     * Sets the value of the berichtReferentienr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBerichtReferentienr(String value) {
        this.berichtReferentienr = value;
    }

    /**
     * Gets the value of the herhalingsPogingnr property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getHerhalingsPogingnr() {
        return herhalingsPogingnr;
    }

    /**
     * Sets the value of the herhalingsPogingnr property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setHerhalingsPogingnr(Long value) {
        this.herhalingsPogingnr = value;
    }

    /**
     * Gets the value of the berichtType property.
     * 
     * @return
     *     possible object is
     *     {@link BerichtIdentificatie.BerichtType }
     *     
     */
    public BerichtIdentificatie.BerichtType getBerichtType() {
        return berichtType;
    }

    /**
     * Sets the value of the berichtType property.
     * 
     * @param value
     *     allowed object is
     *     {@link BerichtIdentificatie.BerichtType }
     *     
     */
    public void setBerichtType(BerichtIdentificatie.BerichtType value) {
        this.berichtType = value;
    }

    /**
     * Gets the value of the datTijdAanmaakBericht property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDatTijdAanmaakBericht() {
        return datTijdAanmaakBericht;
    }

    /**
     * Sets the value of the datTijdAanmaakBericht property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDatTijdAanmaakBericht(XMLGregorianCalendar value) {
        this.datTijdAanmaakBericht = value;
    }

    /**
     * Gets the value of the datTijdVersturenBericht property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDatTijdVersturenBericht() {
        return datTijdVersturenBericht;
    }

    /**
     * Sets the value of the datTijdVersturenBericht property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDatTijdVersturenBericht(XMLGregorianCalendar value) {
        this.datTijdVersturenBericht = value;
    }

    /**
     * Gets the value of the requestBerichtReferentienr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestBerichtReferentienr() {
        return requestBerichtReferentienr;
    }

    /**
     * Sets the value of the requestBerichtReferentienr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestBerichtReferentienr(String value) {
        this.requestBerichtReferentienr = value;
    }

    /**
     * Gets the value of the datTijdOntvangstBericht property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDatTijdOntvangstBericht() {
        return datTijdOntvangstBericht;
    }

    /**
     * Sets the value of the datTijdOntvangstBericht property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDatTijdOntvangstBericht(XMLGregorianCalendar value) {
        this.datTijdOntvangstBericht = value;
    }

    /**
     * Gets the value of the indTestbericht property.
     * 
     */
    public long getIndTestbericht() {
        return indTestbericht;
    }

    /**
     * Sets the value of the indTestbericht property.
     * 
     */
    public void setIndTestbericht(long value) {
        this.indTestbericht = value;
    }

    /**
     * Gets the value of the applicatieInformatie property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicatieInformatie() {
        return applicatieInformatie;
    }

    /**
     * Sets the value of the applicatieInformatie property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicatieInformatie(String value) {
        this.applicatieInformatie = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="BerichtNaam"&gt;
     *           &lt;simpleType&gt;
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
     *               &lt;maxLength value="100"/&gt;
     *             &lt;/restriction&gt;
     *           &lt;/simpleType&gt;
     *         &lt;/element&gt;
     *         &lt;element name="VersieMajor"&gt;
     *           &lt;simpleType&gt;
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
     *               &lt;length value="2"/&gt;
     *               &lt;pattern value="\d*"/&gt;
     *             &lt;/restriction&gt;
     *           &lt;/simpleType&gt;
     *         &lt;/element&gt;
     *         &lt;element name="VersieMinor"&gt;
     *           &lt;simpleType&gt;
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
     *               &lt;length value="2"/&gt;
     *               &lt;pattern value="\d*"/&gt;
     *             &lt;/restriction&gt;
     *           &lt;/simpleType&gt;
     *         &lt;/element&gt;
     *         &lt;element name="Buildnr"&gt;
     *           &lt;simpleType&gt;
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
     *               &lt;length value="2"/&gt;
     *               &lt;pattern value="\d*"/&gt;
     *             &lt;/restriction&gt;
     *           &lt;/simpleType&gt;
     *         &lt;/element&gt;
     *         &lt;element name="CommunicatieType"&gt;
     *           &lt;simpleType&gt;
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
     *               &lt;enumeration value="Inkijk"/&gt;
     *               &lt;enumeration value="Melding"/&gt;
     *             &lt;/restriction&gt;
     *           &lt;/simpleType&gt;
     *         &lt;/element&gt;
     *         &lt;element name="CommunicatieElement"&gt;
     *           &lt;simpleType&gt;
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
     *               &lt;enumeration value="Request"/&gt;
     *               &lt;enumeration value="Response"/&gt;
     *               &lt;enumeration value="Melding"/&gt;
     *               &lt;enumeration value="Bevestiging"/&gt;
     *               &lt;enumeration value="Redirect"/&gt;
     *               &lt;enumeration value="Fout"/&gt;
     *               &lt;enumeration value="Acknowledgement"/&gt;
     *             &lt;/restriction&gt;
     *           &lt;/simpleType&gt;
     *         &lt;/element&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "berichtNaam",
        "versieMajor",
        "versieMinor",
        "buildnr",
        "communicatieType",
        "communicatieElement"
    })
    public static class BerichtType {

        @XmlElement(name = "BerichtNaam", required = true)
        @NotNull
        @Size(max = 100)
        protected String berichtNaam;
        @XmlElement(name = "VersieMajor", required = true)
        @NotNull
        @Size(min = 2, max = 2)
        @Pattern(regexp = "\\d*")
        protected String versieMajor;
        @XmlElement(name = "VersieMinor", required = true)
        @NotNull
        @Size(min = 2, max = 2)
        @Pattern(regexp = "\\d*")
        protected String versieMinor;
        @XmlElement(name = "Buildnr", required = true)
        @NotNull
        @Size(min = 2, max = 2)
        @Pattern(regexp = "\\d*")
        protected String buildnr;
        @XmlElement(name = "CommunicatieType", required = true)
        @NotNull
        @Pattern(regexp = "(Inkijk)|(Melding)")
        protected String communicatieType;
        @XmlElement(name = "CommunicatieElement", required = true)
        @NotNull
        @Pattern(regexp = "(Request)|(Response)|(Melding)|(Bevestiging)|(Redirect)|(Fout)|(Acknowledgement)")
        protected String communicatieElement;

        /**
         * Gets the value of the berichtNaam property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getBerichtNaam() {
            return berichtNaam;
        }

        /**
         * Sets the value of the berichtNaam property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setBerichtNaam(String value) {
            this.berichtNaam = value;
        }

        /**
         * Gets the value of the versieMajor property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getVersieMajor() {
            return versieMajor;
        }

        /**
         * Sets the value of the versieMajor property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setVersieMajor(String value) {
            this.versieMajor = value;
        }

        /**
         * Gets the value of the versieMinor property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getVersieMinor() {
            return versieMinor;
        }

        /**
         * Sets the value of the versieMinor property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setVersieMinor(String value) {
            this.versieMinor = value;
        }

        /**
         * Gets the value of the buildnr property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getBuildnr() {
            return buildnr;
        }

        /**
         * Sets the value of the buildnr property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setBuildnr(String value) {
            this.buildnr = value;
        }

        /**
         * Gets the value of the communicatieType property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCommunicatieType() {
            return communicatieType;
        }

        /**
         * Sets the value of the communicatieType property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCommunicatieType(String value) {
            this.communicatieType = value;
        }

        /**
         * Gets the value of the communicatieElement property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCommunicatieElement() {
            return communicatieElement;
        }

        /**
         * Sets the value of the communicatieElement property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCommunicatieElement(String value) {
            this.communicatieElement = value;
        }

    }

}
