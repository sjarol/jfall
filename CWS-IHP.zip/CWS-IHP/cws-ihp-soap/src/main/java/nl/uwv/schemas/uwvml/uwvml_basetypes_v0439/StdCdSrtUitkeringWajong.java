
package nl.uwv.schemas.uwvml.uwvml_basetypes_v0439;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for StdCdSrtUitkeringWajong.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <pre>
 * &lt;simpleType name="StdCdSrtUitkeringWajong"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;length value="2"/&gt;
 *     &lt;enumeration value="B-"/&gt;
 *     &lt;enumeration value="D-"/&gt;
 *     &lt;enumeration value="K-"/&gt;
 *     &lt;enumeration value="S-"/&gt;
 *     &lt;enumeration value="V-"/&gt;
 *     &lt;enumeration value="W-"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "StdCdSrtUitkeringWajong", namespace = "http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439")
@XmlEnum
public enum StdCdSrtUitkeringWajong {


    /**
     * Voorgezette werkregeling Breman
     * 
     */
    @XmlEnumValue("B-")
    B("B-"),

    /**
     * Duurzaam arbeidsongeschikten
     * 
     */
    @XmlEnumValue("D-")
    D("D-"),

    /**
     * Geringe kans op herstel
     * 
     */
    @XmlEnumValue("K-")
    K("K-"),

    /**
     * Studie en scholing
     * 
     */
    @XmlEnumValue("S-")
    S("S-"),

    /**
     * Voortgezette werkregeling
     * 
     */
    @XmlEnumValue("V-")
    V("V-"),

    /**
     * Gewone werkregeling
     * 
     */
    @XmlEnumValue("W-")
    W("W-");
    private final String value;

    StdCdSrtUitkeringWajong(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static StdCdSrtUitkeringWajong fromValue(String v) {
        for (StdCdSrtUitkeringWajong c: StdCdSrtUitkeringWajong.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
