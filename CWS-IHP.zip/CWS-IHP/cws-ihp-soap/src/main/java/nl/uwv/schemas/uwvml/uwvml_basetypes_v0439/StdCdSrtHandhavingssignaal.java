
package nl.uwv.schemas.uwvml.uwvml_basetypes_v0439;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for StdCdSrtHandhavingssignaal.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <pre>
 * &lt;simpleType name="StdCdSrtHandhavingssignaal"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;maxLength value="6"/&gt;
 *     &lt;enumeration value="ANDERS"/&gt;
 *     &lt;enumeration value="BAS"/&gt;
 *     &lt;enumeration value="BIT"/&gt;
 *     &lt;enumeration value="Betuwe"/&gt;
 *     &lt;enumeration value="Deblok"/&gt;
 *     &lt;enumeration value="EXTERN"/&gt;
 *     &lt;enumeration value="FIBASE"/&gt;
 *     &lt;enumeration value="HSL"/&gt;
 *     &lt;enumeration value="INTERN"/&gt;
 *     &lt;enumeration value="RASini"/&gt;
 *     &lt;enumeration value="RASsel"/&gt;
 *     &lt;enumeration value="RASstk"/&gt;
 *     &lt;enumeration value="RIFdha"/&gt;
 *     &lt;enumeration value="RIFnoo"/&gt;
 *     &lt;enumeration value="RIFrot"/&gt;
 *     &lt;enumeration value="RIFutr"/&gt;
 *     &lt;enumeration value="RIFzui"/&gt;
 *     &lt;enumeration value="RISICO"/&gt;
 *     &lt;enumeration value="TZW"/&gt;
 *     &lt;enumeration value="VUA"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "StdCdSrtHandhavingssignaal", namespace = "http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439")
@XmlEnum
public enum StdCdSrtHandhavingssignaal {


    /**
     * Ander signaal
     * 
     */
    ANDERS("ANDERS"),

    /**
     * BAS- selectie
     * 
     */
    BAS("BAS"),

    /**
     * Bouw Interventie Team
     * 
     */
    BIT("BIT"),

    /**
     * Project Betuwelijn
     * 
     */
    @XmlEnumValue("Betuwe")
    BETUWE("Betuwe"),

    /**
     * Deblokkering
     * 
     */
    @XmlEnumValue("Deblok")
    DEBLOK("Deblok"),

    /**
     * Extern signaal
     * 
     */
    EXTERN("EXTERN"),

    /**
     * Signaal vergelijking via Fibase
     * 
     */
    FIBASE("FIBASE"),

    /**
     * Project HSL
     * 
     */
    HSL("HSL"),

    /**
     * Intern signaal
     * 
     */
    INTERN("INTERN"),

    /**
     * RAS-initiatief ai
     * 
     */
    @XmlEnumValue("RASini")
    RA_SINI("RASini"),

    /**
     * RAS-selectie
     * 
     */
    @XmlEnumValue("RASsel")
    RA_SSEL("RASsel"),

    /**
     * RAS-steekproef
     * 
     */
    @XmlEnumValue("RASstk")
    RA_SSTK("RASstk"),

    /**
     * RIF-Den Haag
     * 
     */
    @XmlEnumValue("RIFdha")
    RI_FDHA("RIFdha"),

    /**
     * RIF-Noord
     * 
     */
    @XmlEnumValue("RIFnoo")
    RI_FNOO("RIFnoo"),

    /**
     * RIF-Rotterdam
     * 
     */
    @XmlEnumValue("RIFrot")
    RI_FROT("RIFrot"),

    /**
     * RIF-Utrecht
     * 
     */
    @XmlEnumValue("RIFutr")
    RI_FUTR("RIFutr"),

    /**
     * RIF-Zuid
     * 
     */
    @XmlEnumValue("RIFzui")
    RI_FZUI("RIFzui"),

    /**
     * Risico signaal
     * 
     */
    RISICO("RISICO"),

    /**
     * Project TZW
     * 
     */
    TZW("TZW"),

    /**
     * Vua signaal
     * 
     */
    VUA("VUA");
    private final String value;

    StdCdSrtHandhavingssignaal(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static StdCdSrtHandhavingssignaal fromValue(String v) {
        for (StdCdSrtHandhavingssignaal c: StdCdSrtHandhavingssignaal.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
