
package nl.uwv.schemas.uwvml.uwvml_basetypes_v0439;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for StdCdSrtRechtOpUitkeringWia.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <pre>
 * &lt;simpleType name="StdCdSrtRechtOpUitkeringWia"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;length value="1"/&gt;
 *     &lt;enumeration value="G"/&gt;
 *     &lt;enumeration value="I"/&gt;
 *     &lt;enumeration value="V"/&gt;
 *     &lt;enumeration value="W"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "StdCdSrtRechtOpUitkeringWia", namespace = "http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439")
@XmlEnum
public enum StdCdSrtRechtOpUitkeringWia {


    /**
     * Geringe kans op herstel
     * 
     */
    G,

    /**
     * IVA
     * 
     */
    I,

    /**
     * Vrijwillige Verzekerd WGA
     * 
     */
    V,

    /**
     * WGA
     * 
     */
    W;

    public String value() {
        return name();
    }

    public static StdCdSrtRechtOpUitkeringWia fromValue(String v) {
        return valueOf(v);
    }

}
