
package nl.uwv.schemas.uwvml.header_v0202;

import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * Stuurgegevens voor transactiemanagement gericht op het traceren van het bericht binnen de transactie en het garanderen van een juiste verwerkingsvolgorde.
 * 
 * <p>Java class for Transactie complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Transactie"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="TransactieReferentienr" type="{http://www.w3.org/2001/XMLSchema}anyURI"/&gt;
 *         &lt;element name="Volgordenr"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}unsignedInt"&gt;
 *               &lt;minInclusive value="1"/&gt;
 *               &lt;maxInclusive value="999"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="IndLaatsteBericht"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}unsignedInt"&gt;
 *               &lt;enumeration value="1"/&gt;
 *               &lt;enumeration value="2"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Transactie", propOrder = {
    "transactieReferentienr",
    "volgordenr",
    "indLaatsteBericht"
})
public class Transactie {

    @XmlElement(name = "TransactieReferentienr", required = true)
    @XmlSchemaType(name = "anyURI")
    @NotNull
    protected String transactieReferentienr;
    @XmlElement(name = "Volgordenr")
    @NotNull
    @DecimalMax("999")
    @DecimalMin("1")
    protected long volgordenr;
    @XmlElement(name = "IndLaatsteBericht")
    @NotNull
    @DecimalMax("4294967295")
    @DecimalMin("0")
    protected long indLaatsteBericht;

    /**
     * Gets the value of the transactieReferentienr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransactieReferentienr() {
        return transactieReferentienr;
    }

    /**
     * Sets the value of the transactieReferentienr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransactieReferentienr(String value) {
        this.transactieReferentienr = value;
    }

    /**
     * Gets the value of the volgordenr property.
     * 
     */
    public long getVolgordenr() {
        return volgordenr;
    }

    /**
     * Sets the value of the volgordenr property.
     * 
     */
    public void setVolgordenr(long value) {
        this.volgordenr = value;
    }

    /**
     * Gets the value of the indLaatsteBericht property.
     * 
     */
    public long getIndLaatsteBericht() {
        return indLaatsteBericht;
    }

    /**
     * Sets the value of the indLaatsteBericht property.
     * 
     */
    public void setIndLaatsteBericht(long value) {
        this.indLaatsteBericht = value;
    }

}
