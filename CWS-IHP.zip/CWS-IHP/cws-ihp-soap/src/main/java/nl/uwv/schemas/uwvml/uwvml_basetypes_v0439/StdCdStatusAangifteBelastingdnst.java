
package nl.uwv.schemas.uwvml.uwvml_basetypes_v0439;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for StdCdStatusAangifteBelastingdnst.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <pre>
 * &lt;simpleType name="StdCdStatusAangifteBelastingdnst"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;maxLength value="50"/&gt;
 *     &lt;enumeration value="AH"/&gt;
 *     &lt;enumeration value="DA"/&gt;
 *     &lt;enumeration value="GA"/&gt;
 *     &lt;enumeration value="VA"/&gt;
 *     &lt;enumeration value="VN"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "StdCdStatusAangifteBelastingdnst", namespace = "http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439")
@XmlEnum
public enum StdCdStatusAangifteBelastingdnst {


    /**
     * Ambtshalve aanslag
     * 
     */
    AH,

    /**
     * Definitieve aanslag
     * 
     */
    DA,

    /**
     * Nog geen aanslag
     * 
     */
    GA,

    /**
     * Voorlopige aanslag
     * 
     */
    VA,

    /**
     * Vermindering/Navordering
     * 
     */
    VN;

    public String value() {
        return name();
    }

    public static StdCdStatusAangifteBelastingdnst fromValue(String v) {
        return valueOf(v);
    }

}
