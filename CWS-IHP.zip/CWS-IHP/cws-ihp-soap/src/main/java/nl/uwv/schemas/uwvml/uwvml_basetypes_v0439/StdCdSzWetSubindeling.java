
package nl.uwv.schemas.uwvml.uwvml_basetypes_v0439;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for StdCdSzWetSubindeling.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <pre>
 * &lt;simpleType name="StdCdSzWetSubindeling"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;maxLength value="24"/&gt;
 *     &lt;enumeration value="BNO"/&gt;
 *     &lt;enumeration value="DWBZ"/&gt;
 *     &lt;enumeration value="Faillissementsuitkering"/&gt;
 *     &lt;enumeration value="IVA"/&gt;
 *     &lt;enumeration value="OOW"/&gt;
 *     &lt;enumeration value="Verkort werken"/&gt;
 *     &lt;enumeration value="WAZO-ZEZ"/&gt;
 *     &lt;enumeration value="WGA"/&gt;
 *     &lt;enumeration value="WGA-LAU"/&gt;
 *     &lt;enumeration value="WWO"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "StdCdSzWetSubindeling", namespace = "http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439")
@XmlEnum
public enum StdCdSzWetSubindeling {


    /**
     * Buitengewoon natuurlijke omstandigheden
     * 
     */
    BNO("BNO"),

    /**
     * Doorbetaling WW bij ziekte
     * 
     */
    DWBZ("DWBZ"),

    /**
     * Faillissementsuitkering
     * 
     */
    @XmlEnumValue("Faillissementsuitkering")
    FAILLISSEMENTSUITKERING("Faillissementsuitkering"),

    /**
     * Inkomensvoorziening volledig arbeidsongeschikten
     * 
     */
    IVA("IVA"),

    /**
     * Overheidswerknemers onder WW
     * 
     */
    OOW("OOW"),

    /**
     * Verkort werken
     * 
     */
    @XmlEnumValue("Verkort werken")
    VERKORT_WERKEN("Verkort werken"),

    /**
     * Wet Arbeid en Zorg Zelfstandige en Zwanger
     * 
     */
    @XmlEnumValue("WAZO-ZEZ")
    WAZO_ZEZ("WAZO-ZEZ"),

    /**
     * Wet gedeeltelijk arbeidsgeschikten
     * 
     */
    WGA("WGA"),

    /**
     * Wet gedeeltelijk arbeidsgeschikten met loonaanvullingsu
     * 
     */
    @XmlEnumValue("WGA-LAU")
    WGA_LAU("WGA-LAU"),

    /**
     * Ontslagwerkloosheid
     * 
     */
    WWO("WWO");
    private final String value;

    StdCdSzWetSubindeling(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static StdCdSzWetSubindeling fromValue(String v) {
        for (StdCdSzWetSubindeling c: StdCdSzWetSubindeling.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
