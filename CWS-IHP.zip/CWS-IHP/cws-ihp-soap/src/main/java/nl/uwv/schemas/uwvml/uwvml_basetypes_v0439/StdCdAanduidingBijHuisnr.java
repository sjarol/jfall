
package nl.uwv.schemas.uwvml.uwvml_basetypes_v0439;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for StdCdAanduidingBijHuisnr.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <pre>
 * &lt;simpleType name="StdCdAanduidingBijHuisnr"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;length value="2"/&gt;
 *     &lt;pattern value="\D*"/&gt;
 *     &lt;enumeration value="by"/&gt;
 *     &lt;enumeration value="to"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "StdCdAanduidingBijHuisnr", namespace = "http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439")
@XmlEnum
public enum StdCdAanduidingBijHuisnr {


    /**
     * Bij
     * 
     */
    @XmlEnumValue("by")
    BY("by"),

    /**
     * Tegenover
     * 
     */
    @XmlEnumValue("to")
    TO("to");
    private final String value;

    StdCdAanduidingBijHuisnr(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static StdCdAanduidingBijHuisnr fromValue(String v) {
        for (StdCdAanduidingBijHuisnr c: StdCdAanduidingBijHuisnr.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
