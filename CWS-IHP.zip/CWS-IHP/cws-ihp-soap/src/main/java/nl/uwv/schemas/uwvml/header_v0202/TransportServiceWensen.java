
package nl.uwv.schemas.uwvml.header_v0202;

import javax.validation.constraints.Pattern;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for TransportServiceWensen complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="TransportServiceWensen"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="IndControleerbaarheidGewenst" type="{http://schemas.uwv.nl/UwvML/Header-v0202}IndControleerbaarheidGewenst" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TransportServiceWensen", propOrder = {
    "indControleerbaarheidGewenst"
})
public class TransportServiceWensen {

    @XmlElement(name = "IndControleerbaarheidGewenst")
    @Pattern(regexp = "(1)|(2)")
    protected String indControleerbaarheidGewenst;

    /**
     * Gets the value of the indControleerbaarheidGewenst property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIndControleerbaarheidGewenst() {
        return indControleerbaarheidGewenst;
    }

    /**
     * Sets the value of the indControleerbaarheidGewenst property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIndControleerbaarheidGewenst(String value) {
        this.indControleerbaarheidGewenst = value;
    }

}
