
package nl.uwv.schemas.uwvml.uwvml_basetypes_v0439;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for StdCdSrtRijbewijs.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <pre>
 * &lt;simpleType name="StdCdSrtRijbewijs"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;maxLength value="3"/&gt;
 *     &lt;enumeration value="A"/&gt;
 *     &lt;enumeration value="AM"/&gt;
 *     &lt;enumeration value="B"/&gt;
 *     &lt;enumeration value="BE"/&gt;
 *     &lt;enumeration value="C"/&gt;
 *     &lt;enumeration value="C1"/&gt;
 *     &lt;enumeration value="C1E"/&gt;
 *     &lt;enumeration value="CE"/&gt;
 *     &lt;enumeration value="D"/&gt;
 *     &lt;enumeration value="D1"/&gt;
 *     &lt;enumeration value="D1E"/&gt;
 *     &lt;enumeration value="DE"/&gt;
 *     &lt;enumeration value="T"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "StdCdSrtRijbewijs", namespace = "http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439")
@XmlEnum
public enum StdCdSrtRijbewijs {


    /**
     * Motor
     * 
     */
    A("A"),

    /**
     * Bromfiets en snorfiets
     * 
     */
    AM("AM"),

    /**
     * Auto
     * 
     */
    B("B"),

    /**
     * Auto, eventueel met aanhangwagen van meer dan 750kg
     * 
     */
    BE("BE"),

    /**
     * Vrachtwagen meer dan 3500 kg, evt. aanhanger tot 750 kg
     * 
     */
    C("C"),

    /**
     * Lichte vrachtwagen max. 7500 kg, evt aanh. tot 750 kg
     * 
     */
    @XmlEnumValue("C1")
    C_1("C1"),

    /**
     * Lichte vrachtwagen max. 7500 kg, evt. aanh. > 750 kg
     * 
     */
    @XmlEnumValue("C1E")
    C_1_E("C1E"),

    /**
     * Vrachtwagen met een gewicht >3500kg, evt. aanh. >750kg
     * 
     */
    CE("CE"),

    /**
     * Bus voor meer dan 8 personen, evt aanh. tot 750 kg.
     * 
     */
    D("D"),

    /**
     * Bus voor max. 16 pers. excl. best., evt aanh. tot 750kg
     * 
     */
    @XmlEnumValue("D1")
    D_1("D1"),

    /**
     * Bus voor max. 16 personen met aanhangwagen vanaf 750 kg
     * 
     */
    @XmlEnumValue("D1E")
    D_1_E("D1E"),

    /**
     * Bus voor meer dan 8 personen, evt. met aanh. > 750 kg
     * 
     */
    DE("DE"),

    /**
     * Trekkerrijbewijs
     * 
     */
    T("T");
    private final String value;

    StdCdSrtRijbewijs(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static StdCdSrtRijbewijs fromValue(String v) {
        for (StdCdSrtRijbewijs c: StdCdSrtRijbewijs.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
