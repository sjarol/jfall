
package nl.uwv.schemas.uwvml.uwvml_basetypes_v0439;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for StdCdBijzonderNederlanderschap.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <pre>
 * &lt;simpleType name="StdCdBijzonderNederlanderschap"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;length value="1"/&gt;
 *     &lt;pattern value="[A-Z]*"/&gt;
 *     &lt;enumeration value="B"/&gt;
 *     &lt;enumeration value="V"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "StdCdBijzonderNederlanderschap", namespace = "http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439")
@XmlEnum
public enum StdCdBijzonderNederlanderschap {


    /**
     * Behandeld als Nederlander
     * 
     */
    B,

    /**
     * Vastgesteld niet-Nederlander
     * 
     */
    V;

    public String value() {
        return name();
    }

    public static StdCdBijzonderNederlanderschap fromValue(String v) {
        return valueOf(v);
    }

}
