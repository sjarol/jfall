
package nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigerequest_v0001;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * &lt;p&gt;Java class for anonymous complex type.
 * 
 * &lt;p&gt;The following schema fragment specifies the expected content contained within this class.
 * 
 * &lt;pre&gt;
 * &amp;lt;complexType&amp;gt;
 *   &amp;lt;complexContent&amp;gt;
 *     &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&amp;gt;
 *       &amp;lt;sequence&amp;gt;
 *         &amp;lt;element name="Gegevensvraag"&amp;gt;
 *           &amp;lt;complexType&amp;gt;
 *             &amp;lt;complexContent&amp;gt;
 *               &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&amp;gt;
 *                 &amp;lt;sequence&amp;gt;
 *                   &amp;lt;element name="TijdBeschouwing" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatTijd20" minOccurs="0"/&amp;gt;
 *                   &amp;lt;element name="ContractGegevenslevering"&amp;gt;
 *                     &amp;lt;complexType&amp;gt;
 *                       &amp;lt;complexContent&amp;gt;
 *                         &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&amp;gt;
 *                           &amp;lt;sequence&amp;gt;
 *                             &amp;lt;element name="ContractnrGegevenslevering" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeRequest-v0001}StdContractnrGegevenslevering"/&amp;gt;
 *                             &amp;lt;element name="DatBContractGegevenslevering" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso"/&amp;gt;
 *                             &amp;lt;element name="GegevensafnemerConfiguratie"&amp;gt;
 *                               &amp;lt;complexType&amp;gt;
 *                                 &amp;lt;complexContent&amp;gt;
 *                                   &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&amp;gt;
 *                                     &amp;lt;sequence&amp;gt;
 *                                       &amp;lt;element name="VersienrGegevensafnemerConf" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeRequest-v0001}StdVersienrGegevensafnemerConf"/&amp;gt;
 *                                     &amp;lt;/sequence&amp;gt;
 *                                   &amp;lt;/restriction&amp;gt;
 *                                 &amp;lt;/complexContent&amp;gt;
 *                               &amp;lt;/complexType&amp;gt;
 *                             &amp;lt;/element&amp;gt;
 *                           &amp;lt;/sequence&amp;gt;
 *                         &amp;lt;/restriction&amp;gt;
 *                       &amp;lt;/complexContent&amp;gt;
 *                     &amp;lt;/complexType&amp;gt;
 *                   &amp;lt;/element&amp;gt;
 *                   &amp;lt;choice&amp;gt;
 *                     &amp;lt;element name="PersoonInhoudingsplichtige"&amp;gt;
 *                       &amp;lt;complexType&amp;gt;
 *                         &amp;lt;complexContent&amp;gt;
 *                           &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&amp;gt;
 *                             &amp;lt;sequence&amp;gt;
 *                               &amp;lt;element name="NrInhoudingsplichtige" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdNrInhoudingsplichtige"/&amp;gt;
 *                             &amp;lt;/sequence&amp;gt;
 *                           &amp;lt;/restriction&amp;gt;
 *                         &amp;lt;/complexContent&amp;gt;
 *                       &amp;lt;/complexType&amp;gt;
 *                     &amp;lt;/element&amp;gt;
 *                     &amp;lt;element name="AdministratieveEenheid"&amp;gt;
 *                       &amp;lt;complexType&amp;gt;
 *                         &amp;lt;complexContent&amp;gt;
 *                           &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&amp;gt;
 *                             &amp;lt;sequence&amp;gt;
 *                               &amp;lt;element name="Loonheffingennr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLoonheffingennr" minOccurs="0"/&amp;gt;
 *                               &amp;lt;element name="AansluitingsnrBv" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdAansluitingsnrBV" minOccurs="0"/&amp;gt;
 *                             &amp;lt;/sequence&amp;gt;
 *                           &amp;lt;/restriction&amp;gt;
 *                         &amp;lt;/complexContent&amp;gt;
 *                       &amp;lt;/complexType&amp;gt;
 *                     &amp;lt;/element&amp;gt;
 *                     &amp;lt;element name="WerkgeverKvk"&amp;gt;
 *                       &amp;lt;complexType&amp;gt;
 *                         &amp;lt;complexContent&amp;gt;
 *                           &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&amp;gt;
 *                             &amp;lt;sequence&amp;gt;
 *                               &amp;lt;element name="KvkNr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdKvkNr"/&amp;gt;
 *                             &amp;lt;/sequence&amp;gt;
 *                           &amp;lt;/restriction&amp;gt;
 *                         &amp;lt;/complexContent&amp;gt;
 *                       &amp;lt;/complexType&amp;gt;
 *                     &amp;lt;/element&amp;gt;
 *                   &amp;lt;/choice&amp;gt;
 *                 &amp;lt;/sequence&amp;gt;
 *               &amp;lt;/restriction&amp;gt;
 *             &amp;lt;/complexContent&amp;gt;
 *           &amp;lt;/complexType&amp;gt;
 *         &amp;lt;/element&amp;gt;
 *       &amp;lt;/sequence&amp;gt;
 *     &amp;lt;/restriction&amp;gt;
 *   &amp;lt;/complexContent&amp;gt;
 * &amp;lt;/complexType&amp;gt;
 * &lt;/pre&gt;
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "gegevensvraag"
})
@XmlRootElement(name = "CwsInhoudingsplichtigeRequest")
public class CwsInhoudingsplichtigeRequest {

    @XmlElement(name = "Gegevensvraag", required = true)
    @NotNull
    @Valid
    protected CwsInhoudingsplichtigeRequest.Gegevensvraag gegevensvraag;

    /**
     * Gets the value of the gegevensvraag property.
     * 
     * @return
     *     possible object is
     *     {@link CwsInhoudingsplichtigeRequest.Gegevensvraag }
     *     
     */
    public CwsInhoudingsplichtigeRequest.Gegevensvraag getGegevensvraag() {
        return gegevensvraag;
    }

    /**
     * Sets the value of the gegevensvraag property.
     * 
     * @param value
     *     allowed object is
     *     {@link CwsInhoudingsplichtigeRequest.Gegevensvraag }
     *     
     */
    public void setGegevensvraag(CwsInhoudingsplichtigeRequest.Gegevensvraag value) {
        this.gegevensvraag = value;
    }


    /**
     * &lt;p&gt;Java class for anonymous complex type.
     * 
     * &lt;p&gt;The following schema fragment specifies the expected content contained within this class.
     * 
     * &lt;pre&gt;
     * &amp;lt;complexType&amp;gt;
     *   &amp;lt;complexContent&amp;gt;
     *     &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&amp;gt;
     *       &amp;lt;sequence&amp;gt;
     *         &amp;lt;element name="TijdBeschouwing" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatTijd20" minOccurs="0"/&amp;gt;
     *         &amp;lt;element name="ContractGegevenslevering"&amp;gt;
     *           &amp;lt;complexType&amp;gt;
     *             &amp;lt;complexContent&amp;gt;
     *               &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&amp;gt;
     *                 &amp;lt;sequence&amp;gt;
     *                   &amp;lt;element name="ContractnrGegevenslevering" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeRequest-v0001}StdContractnrGegevenslevering"/&amp;gt;
     *                   &amp;lt;element name="DatBContractGegevenslevering" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso"/&amp;gt;
     *                   &amp;lt;element name="GegevensafnemerConfiguratie"&amp;gt;
     *                     &amp;lt;complexType&amp;gt;
     *                       &amp;lt;complexContent&amp;gt;
     *                         &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&amp;gt;
     *                           &amp;lt;sequence&amp;gt;
     *                             &amp;lt;element name="VersienrGegevensafnemerConf" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeRequest-v0001}StdVersienrGegevensafnemerConf"/&amp;gt;
     *                           &amp;lt;/sequence&amp;gt;
     *                         &amp;lt;/restriction&amp;gt;
     *                       &amp;lt;/complexContent&amp;gt;
     *                     &amp;lt;/complexType&amp;gt;
     *                   &amp;lt;/element&amp;gt;
     *                 &amp;lt;/sequence&amp;gt;
     *               &amp;lt;/restriction&amp;gt;
     *             &amp;lt;/complexContent&amp;gt;
     *           &amp;lt;/complexType&amp;gt;
     *         &amp;lt;/element&amp;gt;
     *         &amp;lt;choice&amp;gt;
     *           &amp;lt;element name="PersoonInhoudingsplichtige"&amp;gt;
     *             &amp;lt;complexType&amp;gt;
     *               &amp;lt;complexContent&amp;gt;
     *                 &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&amp;gt;
     *                   &amp;lt;sequence&amp;gt;
     *                     &amp;lt;element name="NrInhoudingsplichtige" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdNrInhoudingsplichtige"/&amp;gt;
     *                   &amp;lt;/sequence&amp;gt;
     *                 &amp;lt;/restriction&amp;gt;
     *               &amp;lt;/complexContent&amp;gt;
     *             &amp;lt;/complexType&amp;gt;
     *           &amp;lt;/element&amp;gt;
     *           &amp;lt;element name="AdministratieveEenheid"&amp;gt;
     *             &amp;lt;complexType&amp;gt;
     *               &amp;lt;complexContent&amp;gt;
     *                 &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&amp;gt;
     *                   &amp;lt;sequence&amp;gt;
     *                     &amp;lt;element name="Loonheffingennr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLoonheffingennr" minOccurs="0"/&amp;gt;
     *                     &amp;lt;element name="AansluitingsnrBv" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdAansluitingsnrBV" minOccurs="0"/&amp;gt;
     *                   &amp;lt;/sequence&amp;gt;
     *                 &amp;lt;/restriction&amp;gt;
     *               &amp;lt;/complexContent&amp;gt;
     *             &amp;lt;/complexType&amp;gt;
     *           &amp;lt;/element&amp;gt;
     *           &amp;lt;element name="WerkgeverKvk"&amp;gt;
     *             &amp;lt;complexType&amp;gt;
     *               &amp;lt;complexContent&amp;gt;
     *                 &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&amp;gt;
     *                   &amp;lt;sequence&amp;gt;
     *                     &amp;lt;element name="KvkNr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdKvkNr"/&amp;gt;
     *                   &amp;lt;/sequence&amp;gt;
     *                 &amp;lt;/restriction&amp;gt;
     *               &amp;lt;/complexContent&amp;gt;
     *             &amp;lt;/complexType&amp;gt;
     *           &amp;lt;/element&amp;gt;
     *         &amp;lt;/choice&amp;gt;
     *       &amp;lt;/sequence&amp;gt;
     *     &amp;lt;/restriction&amp;gt;
     *   &amp;lt;/complexContent&amp;gt;
     * &amp;lt;/complexType&amp;gt;
     * &lt;/pre&gt;
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "tijdBeschouwing",
        "contractGegevenslevering",
        "persoonInhoudingsplichtige",
        "administratieveEenheid",
        "werkgeverKvk"
    })
    public static class Gegevensvraag {

        @XmlElement(name = "TijdBeschouwing")
        @Size(max = 20)
        protected String tijdBeschouwing;
        @XmlElement(name = "ContractGegevenslevering", required = true)
        @NotNull
        @Valid
        protected CwsInhoudingsplichtigeRequest.Gegevensvraag.ContractGegevenslevering contractGegevenslevering;
        @XmlElement(name = "PersoonInhoudingsplichtige")
        @Valid
        protected CwsInhoudingsplichtigeRequest.Gegevensvraag.PersoonInhoudingsplichtige persoonInhoudingsplichtige;
        @XmlElement(name = "AdministratieveEenheid")
        @Valid
        protected CwsInhoudingsplichtigeRequest.Gegevensvraag.AdministratieveEenheid administratieveEenheid;
        @XmlElement(name = "WerkgeverKvk")
        @Valid
        protected CwsInhoudingsplichtigeRequest.Gegevensvraag.WerkgeverKvk werkgeverKvk;

        /**
         * Gets the value of the tijdBeschouwing property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getTijdBeschouwing() {
            return tijdBeschouwing;
        }

        /**
         * Sets the value of the tijdBeschouwing property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setTijdBeschouwing(String value) {
            this.tijdBeschouwing = value;
        }

        /**
         * Gets the value of the contractGegevenslevering property.
         * 
         * @return
         *     possible object is
         *     {@link CwsInhoudingsplichtigeRequest.Gegevensvraag.ContractGegevenslevering }
         *     
         */
        public CwsInhoudingsplichtigeRequest.Gegevensvraag.ContractGegevenslevering getContractGegevenslevering() {
            return contractGegevenslevering;
        }

        /**
         * Sets the value of the contractGegevenslevering property.
         * 
         * @param value
         *     allowed object is
         *     {@link CwsInhoudingsplichtigeRequest.Gegevensvraag.ContractGegevenslevering }
         *     
         */
        public void setContractGegevenslevering(CwsInhoudingsplichtigeRequest.Gegevensvraag.ContractGegevenslevering value) {
            this.contractGegevenslevering = value;
        }

        /**
         * Gets the value of the persoonInhoudingsplichtige property.
         * 
         * @return
         *     possible object is
         *     {@link CwsInhoudingsplichtigeRequest.Gegevensvraag.PersoonInhoudingsplichtige }
         *     
         */
        public CwsInhoudingsplichtigeRequest.Gegevensvraag.PersoonInhoudingsplichtige getPersoonInhoudingsplichtige() {
            return persoonInhoudingsplichtige;
        }

        /**
         * Sets the value of the persoonInhoudingsplichtige property.
         * 
         * @param value
         *     allowed object is
         *     {@link CwsInhoudingsplichtigeRequest.Gegevensvraag.PersoonInhoudingsplichtige }
         *     
         */
        public void setPersoonInhoudingsplichtige(CwsInhoudingsplichtigeRequest.Gegevensvraag.PersoonInhoudingsplichtige value) {
            this.persoonInhoudingsplichtige = value;
        }

        /**
         * Gets the value of the administratieveEenheid property.
         * 
         * @return
         *     possible object is
         *     {@link CwsInhoudingsplichtigeRequest.Gegevensvraag.AdministratieveEenheid }
         *     
         */
        public CwsInhoudingsplichtigeRequest.Gegevensvraag.AdministratieveEenheid getAdministratieveEenheid() {
            return administratieveEenheid;
        }

        /**
         * Sets the value of the administratieveEenheid property.
         * 
         * @param value
         *     allowed object is
         *     {@link CwsInhoudingsplichtigeRequest.Gegevensvraag.AdministratieveEenheid }
         *     
         */
        public void setAdministratieveEenheid(CwsInhoudingsplichtigeRequest.Gegevensvraag.AdministratieveEenheid value) {
            this.administratieveEenheid = value;
        }

        /**
         * Gets the value of the werkgeverKvk property.
         * 
         * @return
         *     possible object is
         *     {@link CwsInhoudingsplichtigeRequest.Gegevensvraag.WerkgeverKvk }
         *     
         */
        public CwsInhoudingsplichtigeRequest.Gegevensvraag.WerkgeverKvk getWerkgeverKvk() {
            return werkgeverKvk;
        }

        /**
         * Sets the value of the werkgeverKvk property.
         * 
         * @param value
         *     allowed object is
         *     {@link CwsInhoudingsplichtigeRequest.Gegevensvraag.WerkgeverKvk }
         *     
         */
        public void setWerkgeverKvk(CwsInhoudingsplichtigeRequest.Gegevensvraag.WerkgeverKvk value) {
            this.werkgeverKvk = value;
        }


        /**
         * &lt;p&gt;Java class for anonymous complex type.
         * 
         * &lt;p&gt;The following schema fragment specifies the expected content contained within this class.
         * 
         * &lt;pre&gt;
         * &amp;lt;complexType&amp;gt;
         *   &amp;lt;complexContent&amp;gt;
         *     &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&amp;gt;
         *       &amp;lt;sequence&amp;gt;
         *         &amp;lt;element name="Loonheffingennr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdLoonheffingennr" minOccurs="0"/&amp;gt;
         *         &amp;lt;element name="AansluitingsnrBv" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdAansluitingsnrBV" minOccurs="0"/&amp;gt;
         *       &amp;lt;/sequence&amp;gt;
         *     &amp;lt;/restriction&amp;gt;
         *   &amp;lt;/complexContent&amp;gt;
         * &amp;lt;/complexType&amp;gt;
         * &lt;/pre&gt;
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "loonheffingennr",
            "aansluitingsnrBv"
        })
        public static class AdministratieveEenheid {

            @XmlElement(name = "Loonheffingennr")
            @Size(min = 12, max = 12)
            protected String loonheffingennr;
            @XmlElement(name = "AansluitingsnrBv")
            @Size(min = 15, max = 15)
            @Pattern(regexp = "0[0-9]{14}")
            protected String aansluitingsnrBv;

            /**
             * Gets the value of the loonheffingennr property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getLoonheffingennr() {
                return loonheffingennr;
            }

            /**
             * Sets the value of the loonheffingennr property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setLoonheffingennr(String value) {
                this.loonheffingennr = value;
            }

            /**
             * Gets the value of the aansluitingsnrBv property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getAansluitingsnrBv() {
                return aansluitingsnrBv;
            }

            /**
             * Sets the value of the aansluitingsnrBv property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setAansluitingsnrBv(String value) {
                this.aansluitingsnrBv = value;
            }

        }


        /**
         * &lt;p&gt;Java class for anonymous complex type.
         * 
         * &lt;p&gt;The following schema fragment specifies the expected content contained within this class.
         * 
         * &lt;pre&gt;
         * &amp;lt;complexType&amp;gt;
         *   &amp;lt;complexContent&amp;gt;
         *     &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&amp;gt;
         *       &amp;lt;sequence&amp;gt;
         *         &amp;lt;element name="ContractnrGegevenslevering" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeRequest-v0001}StdContractnrGegevenslevering"/&amp;gt;
         *         &amp;lt;element name="DatBContractGegevenslevering" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdDatIso"/&amp;gt;
         *         &amp;lt;element name="GegevensafnemerConfiguratie"&amp;gt;
         *           &amp;lt;complexType&amp;gt;
         *             &amp;lt;complexContent&amp;gt;
         *               &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&amp;gt;
         *                 &amp;lt;sequence&amp;gt;
         *                   &amp;lt;element name="VersienrGegevensafnemerConf" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeRequest-v0001}StdVersienrGegevensafnemerConf"/&amp;gt;
         *                 &amp;lt;/sequence&amp;gt;
         *               &amp;lt;/restriction&amp;gt;
         *             &amp;lt;/complexContent&amp;gt;
         *           &amp;lt;/complexType&amp;gt;
         *         &amp;lt;/element&amp;gt;
         *       &amp;lt;/sequence&amp;gt;
         *     &amp;lt;/restriction&amp;gt;
         *   &amp;lt;/complexContent&amp;gt;
         * &amp;lt;/complexType&amp;gt;
         * &lt;/pre&gt;
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "contractnrGegevenslevering",
            "datBContractGegevenslevering",
            "gegevensafnemerConfiguratie"
        })
        public static class ContractGegevenslevering {

            @XmlElement(name = "ContractnrGegevenslevering", required = true)
            @NotNull
            @Size(max = 10)
            @Pattern(regexp = "[0-9]*")
            protected String contractnrGegevenslevering;
            @XmlElement(name = "DatBContractGegevenslevering", required = true)
            @NotNull
            @Size(max = 8)
            protected String datBContractGegevenslevering;
            @XmlElement(name = "GegevensafnemerConfiguratie", required = true)
            @NotNull
            @Valid
            protected CwsInhoudingsplichtigeRequest.Gegevensvraag.ContractGegevenslevering.GegevensafnemerConfiguratie gegevensafnemerConfiguratie;

            /**
             * Gets the value of the contractnrGegevenslevering property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getContractnrGegevenslevering() {
                return contractnrGegevenslevering;
            }

            /**
             * Sets the value of the contractnrGegevenslevering property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setContractnrGegevenslevering(String value) {
                this.contractnrGegevenslevering = value;
            }

            /**
             * Gets the value of the datBContractGegevenslevering property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getDatBContractGegevenslevering() {
                return datBContractGegevenslevering;
            }

            /**
             * Sets the value of the datBContractGegevenslevering property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setDatBContractGegevenslevering(String value) {
                this.datBContractGegevenslevering = value;
            }

            /**
             * Gets the value of the gegevensafnemerConfiguratie property.
             * 
             * @return
             *     possible object is
             *     {@link CwsInhoudingsplichtigeRequest.Gegevensvraag.ContractGegevenslevering.GegevensafnemerConfiguratie }
             *     
             */
            public CwsInhoudingsplichtigeRequest.Gegevensvraag.ContractGegevenslevering.GegevensafnemerConfiguratie getGegevensafnemerConfiguratie() {
                return gegevensafnemerConfiguratie;
            }

            /**
             * Sets the value of the gegevensafnemerConfiguratie property.
             * 
             * @param value
             *     allowed object is
             *     {@link CwsInhoudingsplichtigeRequest.Gegevensvraag.ContractGegevenslevering.GegevensafnemerConfiguratie }
             *     
             */
            public void setGegevensafnemerConfiguratie(CwsInhoudingsplichtigeRequest.Gegevensvraag.ContractGegevenslevering.GegevensafnemerConfiguratie value) {
                this.gegevensafnemerConfiguratie = value;
            }


            /**
             * &lt;p&gt;Java class for anonymous complex type.
             * 
             * &lt;p&gt;The following schema fragment specifies the expected content contained within this class.
             * 
             * &lt;pre&gt;
             * &amp;lt;complexType&amp;gt;
             *   &amp;lt;complexContent&amp;gt;
             *     &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&amp;gt;
             *       &amp;lt;sequence&amp;gt;
             *         &amp;lt;element name="VersienrGegevensafnemerConf" type="{http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeRequest-v0001}StdVersienrGegevensafnemerConf"/&amp;gt;
             *       &amp;lt;/sequence&amp;gt;
             *     &amp;lt;/restriction&amp;gt;
             *   &amp;lt;/complexContent&amp;gt;
             * &amp;lt;/complexType&amp;gt;
             * &lt;/pre&gt;
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "versienrGegevensafnemerConf"
            })
            public static class GegevensafnemerConfiguratie {

                @XmlElement(name = "VersienrGegevensafnemerConf", required = true)
                @NotNull
                @Size(max = 4)
                @Pattern(regexp = "[0-9]*")
                protected String versienrGegevensafnemerConf;

                /**
                 * Gets the value of the versienrGegevensafnemerConf property.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getVersienrGegevensafnemerConf() {
                    return versienrGegevensafnemerConf;
                }

                /**
                 * Sets the value of the versienrGegevensafnemerConf property.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setVersienrGegevensafnemerConf(String value) {
                    this.versienrGegevensafnemerConf = value;
                }

            }

        }


        /**
         * &lt;p&gt;Java class for anonymous complex type.
         * 
         * &lt;p&gt;The following schema fragment specifies the expected content contained within this class.
         * 
         * &lt;pre&gt;
         * &amp;lt;complexType&amp;gt;
         *   &amp;lt;complexContent&amp;gt;
         *     &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&amp;gt;
         *       &amp;lt;sequence&amp;gt;
         *         &amp;lt;element name="NrInhoudingsplichtige" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdNrInhoudingsplichtige"/&amp;gt;
         *       &amp;lt;/sequence&amp;gt;
         *     &amp;lt;/restriction&amp;gt;
         *   &amp;lt;/complexContent&amp;gt;
         * &amp;lt;/complexType&amp;gt;
         * &lt;/pre&gt;
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "nrInhoudingsplichtige"
        })
        public static class PersoonInhoudingsplichtige {

            @XmlElement(name = "NrInhoudingsplichtige", required = true)
            @NotNull
            @Size(min = 9, max = 9)
            @Pattern(regexp = "\\d*")
            protected String nrInhoudingsplichtige;

            /**
             * Gets the value of the nrInhoudingsplichtige property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getNrInhoudingsplichtige() {
                return nrInhoudingsplichtige;
            }

            /**
             * Sets the value of the nrInhoudingsplichtige property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setNrInhoudingsplichtige(String value) {
                this.nrInhoudingsplichtige = value;
            }

        }


        /**
         * &lt;p&gt;Java class for anonymous complex type.
         * 
         * &lt;p&gt;The following schema fragment specifies the expected content contained within this class.
         * 
         * &lt;pre&gt;
         * &amp;lt;complexType&amp;gt;
         *   &amp;lt;complexContent&amp;gt;
         *     &amp;lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&amp;gt;
         *       &amp;lt;sequence&amp;gt;
         *         &amp;lt;element name="KvkNr" type="{http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439}StdKvkNr"/&amp;gt;
         *       &amp;lt;/sequence&amp;gt;
         *     &amp;lt;/restriction&amp;gt;
         *   &amp;lt;/complexContent&amp;gt;
         * &amp;lt;/complexType&amp;gt;
         * &lt;/pre&gt;
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "kvkNr"
        })
        public static class WerkgeverKvk {

            @XmlElement(name = "KvkNr", required = true)
            @NotNull
            @Size(min = 8, max = 8)
            @Pattern(regexp = "\\d*")
            protected String kvkNr;

            /**
             * Gets the value of the kvkNr property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getKvkNr() {
                return kvkNr;
            }

            /**
             * Sets the value of the kvkNr property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setKvkNr(String value) {
                this.kvkNr = value;
            }

        }

    }

}
