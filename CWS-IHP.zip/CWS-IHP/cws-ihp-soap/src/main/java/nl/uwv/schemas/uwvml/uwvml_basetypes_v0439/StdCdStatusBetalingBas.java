
package nl.uwv.schemas.uwvml.uwvml_basetypes_v0439;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for StdCdStatusBetalingBas.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <pre>
 * &lt;simpleType name="StdCdStatusBetalingBas"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;length value="1"/&gt;
 *     &lt;pattern value="[A-Z]*"/&gt;
 *     &lt;enumeration value="A"/&gt;
 *     &lt;enumeration value="B"/&gt;
 *     &lt;enumeration value="D"/&gt;
 *     &lt;enumeration value="G"/&gt;
 *     &lt;enumeration value="H"/&gt;
 *     &lt;enumeration value="O"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "StdCdStatusBetalingBas", namespace = "http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439")
@XmlEnum
public enum StdCdStatusBetalingBas {


    /**
     * Wordt niet uitbetaald; automatisch geannuleerd
     * 
     */
    A,

    /**
     * Nog niet uitbetaald; niet geannuleerd
     * 
     */
    B,

    /**
     * Uitbetaald; ge-deannuleerd
     * 
     */
    D,

    /**
     * Uitbetaald; niet geannuleerd
     * 
     */
    G,

    /**
     * Wordt niet uitbetaald; handmatig geannuleerd
     * 
     */
    H,

    /**
     * Nog niet uitbetaald; ge-deannuleerd
     * 
     */
    O;

    public String value() {
        return name();
    }

    public static StdCdStatusBetalingBas fromValue(String v) {
        return valueOf(v);
    }

}
