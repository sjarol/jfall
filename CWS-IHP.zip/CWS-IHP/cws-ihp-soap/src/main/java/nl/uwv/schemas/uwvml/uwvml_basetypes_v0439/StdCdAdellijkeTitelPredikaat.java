
package nl.uwv.schemas.uwvml.uwvml_basetypes_v0439;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for StdCdAdellijkeTitelPredikaat.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <pre>
 * &lt;simpleType name="StdCdAdellijkeTitelPredikaat"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;maxLength value="2"/&gt;
 *     &lt;pattern value="[A-Z]*"/&gt;
 *     &lt;enumeration value="B"/&gt;
 *     &lt;enumeration value="BS"/&gt;
 *     &lt;enumeration value="G"/&gt;
 *     &lt;enumeration value="GI"/&gt;
 *     &lt;enumeration value="H"/&gt;
 *     &lt;enumeration value="HI"/&gt;
 *     &lt;enumeration value="JH"/&gt;
 *     &lt;enumeration value="JV"/&gt;
 *     &lt;enumeration value="M"/&gt;
 *     &lt;enumeration value="MI"/&gt;
 *     &lt;enumeration value="P"/&gt;
 *     &lt;enumeration value="PS"/&gt;
 *     &lt;enumeration value="R"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "StdCdAdellijkeTitelPredikaat", namespace = "http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439")
@XmlEnum
public enum StdCdAdellijkeTitelPredikaat {


    /**
     * Baron
     * 
     */
    B,

    /**
     * Barones
     * 
     */
    BS,

    /**
     * Graaf
     * 
     */
    G,

    /**
     * Gravin
     * 
     */
    GI,

    /**
     * Hertog
     * 
     */
    H,

    /**
     * Hertogin
     * 
     */
    HI,

    /**
     * Jonkheer
     * 
     */
    JH,

    /**
     * Jonkvrouw
     * 
     */
    JV,

    /**
     * Markies
     * 
     */
    M,

    /**
     * Markiezin
     * 
     */
    MI,

    /**
     * Prins
     * 
     */
    P,

    /**
     * Prinses
     * 
     */
    PS,

    /**
     * Ridder
     * 
     */
    R;

    public String value() {
        return name();
    }

    public static StdCdAdellijkeTitelPredikaat fromValue(String v) {
        return valueOf(v);
    }

}
