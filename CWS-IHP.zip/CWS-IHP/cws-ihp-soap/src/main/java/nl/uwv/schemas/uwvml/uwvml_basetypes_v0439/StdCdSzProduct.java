
package nl.uwv.schemas.uwvml.uwvml_basetypes_v0439;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for StdCdSzProduct.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <pre>
 * &lt;simpleType name="StdCdSzProduct"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;maxLength value="5"/&gt;
 *     &lt;pattern value="[A-Z]*"/&gt;
 *     &lt;enumeration value="AAW"/&gt;
 *     &lt;enumeration value="AB"/&gt;
 *     &lt;enumeration value="ABW"/&gt;
 *     &lt;enumeration value="AKW"/&gt;
 *     &lt;enumeration value="ANW"/&gt;
 *     &lt;enumeration value="AOW"/&gt;
 *     &lt;enumeration value="AWBZ"/&gt;
 *     &lt;enumeration value="AWW"/&gt;
 *     &lt;enumeration value="BB"/&gt;
 *     &lt;enumeration value="BBZ"/&gt;
 *     &lt;enumeration value="CSV"/&gt;
 *     &lt;enumeration value="INTW"/&gt;
 *     &lt;enumeration value="IOAW"/&gt;
 *     &lt;enumeration value="IOAZ"/&gt;
 *     &lt;enumeration value="IOW"/&gt;
 *     &lt;enumeration value="IVA"/&gt;
 *     &lt;enumeration value="KB"/&gt;
 *     &lt;enumeration value="KOP"/&gt;
 *     &lt;enumeration value="NWJ"/&gt;
 *     &lt;enumeration value="OSV"/&gt;
 *     &lt;enumeration value="PVW"/&gt;
 *     &lt;enumeration value="PWJ"/&gt;
 *     &lt;enumeration value="REA"/&gt;
 *     &lt;enumeration value="RWW"/&gt;
 *     &lt;enumeration value="TRI"/&gt;
 *     &lt;enumeration value="TW"/&gt;
 *     &lt;enumeration value="VUT"/&gt;
 *     &lt;enumeration value="WAJ"/&gt;
 *     &lt;enumeration value="WAMIL"/&gt;
 *     &lt;enumeration value="WAO"/&gt;
 *     &lt;enumeration value="WAZ"/&gt;
 *     &lt;enumeration value="WAZO"/&gt;
 *     &lt;enumeration value="WBIA"/&gt;
 *     &lt;enumeration value="WGA"/&gt;
 *     &lt;enumeration value="WHK"/&gt;
 *     &lt;enumeration value="WIA"/&gt;
 *     &lt;enumeration value="WIJ"/&gt;
 *     &lt;enumeration value="WLZ"/&gt;
 *     &lt;enumeration value="WVG"/&gt;
 *     &lt;enumeration value="WW"/&gt;
 *     &lt;enumeration value="WWB"/&gt;
 *     &lt;enumeration value="WWF"/&gt;
 *     &lt;enumeration value="WWIK"/&gt;
 *     &lt;enumeration value="ZFW"/&gt;
 *     &lt;enumeration value="ZVW"/&gt;
 *     &lt;enumeration value="ZW"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "StdCdSzProduct", namespace = "http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439")
@XmlEnum
public enum StdCdSzProduct {


    /**
     * (voormalige) Algemene Arbeidsongeschiktheidswet
     * 
     */
    AAW,

    /**
     * Algemene Bijstand
     * 
     */
    AB,

    /**
     * (nieuwe) Algemene Bijstandswet
     * 
     */
    ABW,

    /**
     * Algemene Kinderbijslagwet
     * 
     */
    AKW,

    /**
     * Algemene Nabestaandenwet
     * 
     */
    ANW,

    /**
     * Algemene Ouderdomswet
     * 
     */
    AOW,

    /**
     * Algemene Wet Bijzondere Ziektekosten
     * 
     */
    AWBZ,

    /**
     * (voormalige) Algemene Weduwen en Wezenwet
     * 
     */
    AWW,

    /**
     * Bijzonder Bijstand
     * 
     */
    BB,

    /**
     * Besluit Bijstandverlening Zelfstandigen
     * 
     */
    BBZ,

    /**
     * Coördinatiewet Sociale Verzekering
     * 
     */
    CSV,

    /**
     * Internationale wetten
     * 
     */
    INTW,

    /**
     * Wet Ink. voorz. Oudere + ged. Arbeidsongeschikte WW'ers
     * 
     */
    IOAW,

    /**
     * Wet Ink.vz. Oudere en ged. Arbeidsongeschikte gew. Zn'n
     * 
     */
    IOAZ,

    /**
     * Inkomensvoorziening Oudere Werklozen
     * 
     */
    IOW,

    /**
     * Inkomensvoorziening Volledig Arbeidsongeschikten
     * 
     */
    IVA,

    /**
     * koninklijk besluit en aanverwante regelingen
     * 
     */
    KB,

    /**
     * Kopjesregeling
     * 
     */
    KOP,

    /**
     * Wet werk en arbeidsondersteuning jonggehandicapten
     * 
     */
    NWJ,

    /**
     * (nieuwe) Organisatiewet Sociale Verzekering
     * 
     */
    OSV,

    /**
     * pensioenwetten
     * 
     */
    PVW,

    /**
     * Participatiewet Wajong
     * 
     */
    PWJ,

    /**
     * Wet op de (RE)integratie Arbeidsgehandicapten
     * 
     */
    REA,

    /**
     * (voormalige) Rijksgroepregeling Werkloze Werknemers
     * 
     */
    RWW,

    /**
     * Tijd. Reg. Ink.gevolgen herbeoordeelde arb.ongeschikten
     * 
     */
    TRI,

    /**
     * Toeslagenwet
     * 
     */
    TW,

    /**
     * VUT-regeling
     * 
     */
    VUT,

    /**
     * Wet Arbeidsongeschiktheidsvoorziening Jonggehandicapten
     * 
     */
    WAJ,

    /**
     * Wet Arbeidsongeschiktheidsvoorziening Militairen
     * 
     */
    WAMIL,

    /**
     * Wet op de Arbeidsongeschiktheidsverzekering
     * 
     */
    WAO,

    /**
     * Wet Arbeidsongeschiktheidsverzekering Zelfstandigen
     * 
     */
    WAZ,

    /**
     * Wet Arbeid en Zorg
     * 
     */
    WAZO,

    /**
     * Wet Beperking Inkomensgevolgen AO-criteria
     * 
     */
    WBIA,

    /**
     * Regeling Werkhervatting gedeeltelijk Arbeidsgeschikten
     * 
     */
    WGA,

    /**
     * Werkhervattingskas
     * 
     */
    WHK,

    /**
     * Wet Werk en Inkomen naar Arbeidsvermogen
     * 
     */
    WIA,

    /**
     * Wet Investeren in Jongeren
     * 
     */
    WIJ,

    /**
     * Wet langdurige zorg
     * 
     */
    WLZ,

    /**
     * Wet Voorzieningen Gehandicapten
     * 
     */
    WVG,

    /**
     * (nieuwe) Werkloosheidswet
     * 
     */
    WW,

    /**
     * Wet Werk en Bijstand
     * 
     */
    WWB,

    /**
     * Werkloosheidswet Faillissementen
     * 
     */
    WWF,

    /**
     * Wet Werk en inkomen Kunstenaars
     * 
     */
    WWIK,

    /**
     * Ziekenfondswet
     * 
     */
    ZFW,

    /**
     * Zorgverzekeringswet
     * 
     */
    ZVW,

    /**
     * Ziektewet
     * 
     */
    ZW;

    public String value() {
        return name();
    }

    public static StdCdSzProduct fromValue(String v) {
        return valueOf(v);
    }

}
