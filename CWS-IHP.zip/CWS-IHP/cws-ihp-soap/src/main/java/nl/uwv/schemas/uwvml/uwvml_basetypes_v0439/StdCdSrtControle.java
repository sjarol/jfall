
package nl.uwv.schemas.uwvml.uwvml_basetypes_v0439;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for StdCdSrtControle.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <pre>
 * &lt;simpleType name="StdCdSrtControle"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;maxLength value="10"/&gt;
 *     &lt;enumeration value="AUTOCOR"/&gt;
 *     &lt;enumeration value="DOMLEN"/&gt;
 *     &lt;enumeration value="DOMRANGE"/&gt;
 *     &lt;enumeration value="DOMROUT"/&gt;
 *     &lt;enumeration value="HANDMATIG"/&gt;
 *     &lt;enumeration value="IKPSTAMHTR"/&gt;
 *     &lt;enumeration value="ISDATE"/&gt;
 *     &lt;enumeration value="ISDATETIME"/&gt;
 *     &lt;enumeration value="ISNOTNULL"/&gt;
 *     &lt;enumeration value="ISNUMBER"/&gt;
 *     &lt;enumeration value="STAM"/&gt;
 *     &lt;enumeration value="STAMHIS"/&gt;
 *     &lt;enumeration value="STAMHTR"/&gt;
 *     &lt;enumeration value="STAMH_PROT"/&gt;
 *     &lt;enumeration value="STAMTR"/&gt;
 *     &lt;enumeration value="STAM_PROT"/&gt;
 *     &lt;enumeration value="UDC"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "StdCdSrtControle", namespace = "http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439")
@XmlEnum
public enum StdCdSrtControle {


    /**
     * Automatisch gecorrigeerde waarde
     * 
     */
    AUTOCOR,

    /**
     * Het gegeven is van de juiste lengte vlgs de domeinspec
     * 
     */
    DOMLEN,

    /**
     * Het gegeven bevat één van de waarde uit domein
     * 
     */
    DOMRANGE,

    /**
     * Domain routine check
     * 
     */
    DOMROUT,

    /**
     * Handmatig aangebrachte signalering
     * 
     */
    HANDMATIG,

    /**
     * Code in stamtabel op datum aanvang per transactie
     * 
     */
    IKPSTAMHTR,

    /**
     * Geldige datum in het het formaat YYYYMMDD
     * 
     */
    ISDATE,

    /**
     * Het gegeven is volgens het formaat YYYYMMDD HH:MI:SS.FF
     * 
     */
    ISDATETIME,

    /**
     * Is not null check
     * 
     */
    ISNOTNULL,

    /**
     * Het gegeven is een geldig getal
     * 
     */
    ISNUMBER,

    /**
     * Code in stamtabel
     * 
     */
    STAM,

    /**
     * Code in stamtabel op datum aanvang
     * 
     */
    STAMHIS,

    /**
     * Cd in stamtabel per transa met geldigheidshistorie
     * 
     */
    STAMHTR,

    /**
     * Zie STAMHIS, werkt alleen op de Protopolis tabellen
     * 
     */
    STAMH_PROT,

    /**
     * Cd in stamtabel per transa zonder datum controle
     * 
     */
    STAMTR,

    /**
     * Zie STAM, werkt alleen op de Protopolis tabellen
     * 
     */
    STAM_PROT,

    /**
     * User Defined Constraint
     * 
     */
    UDC;

    public String value() {
        return name();
    }

    public static StdCdSrtControle fromValue(String v) {
        return valueOf(v);
    }

}
