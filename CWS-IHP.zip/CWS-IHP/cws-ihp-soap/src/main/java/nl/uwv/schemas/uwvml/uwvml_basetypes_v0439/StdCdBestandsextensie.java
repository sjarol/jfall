
package nl.uwv.schemas.uwvml.uwvml_basetypes_v0439;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for StdCdBestandsextensie.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <pre>
 * &lt;simpleType name="StdCdBestandsextensie"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;maxLength value="5"/&gt;
 *     &lt;enumeration value="BMP"/&gt;
 *     &lt;enumeration value="DOC"/&gt;
 *     &lt;enumeration value="DOCX"/&gt;
 *     &lt;enumeration value="HTML"/&gt;
 *     &lt;enumeration value="JPEG"/&gt;
 *     &lt;enumeration value="JPG"/&gt;
 *     &lt;enumeration value="PDF"/&gt;
 *     &lt;enumeration value="PPT"/&gt;
 *     &lt;enumeration value="PPTX"/&gt;
 *     &lt;enumeration value="RTF"/&gt;
 *     &lt;enumeration value="TIFF"/&gt;
 *     &lt;enumeration value="TXT"/&gt;
 *     &lt;enumeration value="XFDF"/&gt;
 *     &lt;enumeration value="XLS"/&gt;
 *     &lt;enumeration value="XLSX"/&gt;
 *     &lt;enumeration value="XML"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "StdCdBestandsextensie", namespace = "http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439")
@XmlEnum
public enum StdCdBestandsextensie {


    /**
     * Niet-gecomprimeerd grafisch bestand
     * 
     */
    BMP,

    /**
     * Tekstdocument van Microsoft Word
     * 
     */
    DOC,

    /**
     * Tekstdocument van Microsoft Word vanaf versie 2007
     * 
     */
    DOCX,

    /**
     * HyperText Markup Language
     * 
     */
    HTML,

    /**
     * Gecomprimeerd grafisch bestand
     * 
     */
    JPEG,

    /**
     * Gecomprimeerd grafisch bestand
     * 
     */
    JPG,

    /**
     * Portable Document Format van Adobe
     * 
     */
    PDF,

    /**
     * Presentatiedocument voor Microsoft Powerpoint
     * 
     */
    PPT,

    /**
     * Presentatiedocument voor MS Powerpoint vanaf v.2007
     * 
     */
    PPTX,

    /**
     * Rich Text Format, documentopmaak in ASCII
     * 
     */
    RTF,

    /**
     * Tagged Image File
     * 
     */
    TIFF,

    /**
     * Tekstbestand, meestal ASCII
     * 
     */
    TXT,

    /**
     * XML Forms Data Format
     * 
     */
    XFDF,

    /**
     * Spreadsheetdocument voor Microsoft Excel
     * 
     */
    XLS,

    /**
     * Spreadsheetdocument voor MS Excel vanaf v.2007
     * 
     */
    XLSX,

    /**
     * Extensible Markup Language
     * 
     */
    XML;

    public String value() {
        return name();
    }

    public static StdCdBestandsextensie fromValue(String v) {
        return valueOf(v);
    }

}
