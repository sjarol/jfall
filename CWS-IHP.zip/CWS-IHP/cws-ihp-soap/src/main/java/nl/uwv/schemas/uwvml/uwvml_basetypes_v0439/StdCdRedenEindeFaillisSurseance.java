
package nl.uwv.schemas.uwvml.uwvml_basetypes_v0439;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for StdCdRedenEindeFaillisSurseance.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <pre>
 * &lt;simpleType name="StdCdRedenEindeFaillisSurseance"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;length value="2"/&gt;
 *     &lt;pattern value="[A-Z]*"/&gt;
 *     &lt;enumeration value="FA"/&gt;
 *     &lt;enumeration value="FG"/&gt;
 *     &lt;enumeration value="FH"/&gt;
 *     &lt;enumeration value="FO"/&gt;
 *     &lt;enumeration value="FS"/&gt;
 *     &lt;enumeration value="FU"/&gt;
 *     &lt;enumeration value="FV"/&gt;
 *     &lt;enumeration value="SA"/&gt;
 *     &lt;enumeration value="SF"/&gt;
 *     &lt;enumeration value="SH"/&gt;
 *     &lt;enumeration value="SI"/&gt;
 *     &lt;enumeration value="SV"/&gt;
 *     &lt;enumeration value="WF"/&gt;
 *     &lt;enumeration value="WH"/&gt;
 *     &lt;enumeration value="WR"/&gt;
 *     &lt;enumeration value="WU"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "StdCdRedenEindeFaillisSurseance", namespace = "http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439")
@XmlEnum
public enum StdCdRedenEindeFaillisSurseance {


    /**
     * Aanvang schuldsanering tijdens faillissement
     * 
     */
    FA,

    /**
     * Vernietiging faillissement na gedaan verzet
     * 
     */
    FG,

    /**
     * Homologatie van het akkoord tijdens faillissement
     * 
     */
    FH,

    /**
     * Opheffing faill. wegens de toestand van de boedel
     * 
     */
    FO,

    /**
     * Volledige voldoening van schuldeisers tijdens faill.
     * 
     */
    FS,

    /**
     * Verbindende (slot-)uitdelingslijst tijdens faill.
     * 
     */
    FU,

    /**
     * Vernietiging faillissement na hoger beroep
     * 
     */
    FV,

    /**
     * Aanvang schuldsanering tijdens surseance
     * 
     */
    SA,

    /**
     * Aanvang faillissement tijdens surseance
     * 
     */
    SF,

    /**
     * Homologatie van het akkoord tijdens surseance
     * 
     */
    SH,

    /**
     * Intrekking surseance bij rechterlijk vonnis
     * 
     */
    SI,

    /**
     * Verloop van surseance na betaling termijn
     * 
     */
    SV,

    /**
     * Aanvang faillissement tijdens schuldsanering
     * 
     */
    WF,

    /**
     * Homologatie van het akkoord tijdens schuldsanering
     * 
     */
    WH,

    /**
     * Rechterlijke uitspraak tijdens schuldsanering
     * 
     */
    WR,

    /**
     * Verbindende slot uitdelingslijst tijdens schuldsanering
     * 
     */
    WU;

    public String value() {
        return name();
    }

    public static StdCdRedenEindeFaillisSurseance fromValue(String v) {
        return valueOf(v);
    }

}
