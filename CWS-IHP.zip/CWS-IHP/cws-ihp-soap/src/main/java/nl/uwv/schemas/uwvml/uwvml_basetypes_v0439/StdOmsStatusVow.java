
package nl.uwv.schemas.uwvml.uwvml_basetypes_v0439;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for StdOmsStatusVow.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <pre>
 * &lt;simpleType name="StdOmsStatusVow"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;maxLength value="20"/&gt;
 *     &lt;pattern value="\D*"/&gt;
 *     &lt;enumeration value="J"/&gt;
 *     &lt;enumeration value="N"/&gt;
 *     &lt;enumeration value="O"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "StdOmsStatusVow", namespace = "http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439")
@XmlEnum
public enum StdOmsStatusVow {


    /**
     * Ja
     * 
     */
    J,

    /**
     * Nee
     * 
     */
    N,

    /**
     * Ja en in Onderzoek
     * 
     */
    O;

    public String value() {
        return name();
    }

    public static StdOmsStatusVow fromValue(String v) {
        return valueOf(v);
    }

}
