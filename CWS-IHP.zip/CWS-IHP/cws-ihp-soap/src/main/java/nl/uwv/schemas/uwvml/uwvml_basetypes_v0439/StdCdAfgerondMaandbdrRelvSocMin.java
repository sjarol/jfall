
package nl.uwv.schemas.uwvml.uwvml_basetypes_v0439;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for StdCdAfgerondMaandbdrRelvSocMin.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <pre>
 * &lt;simpleType name="StdCdAfgerondMaandbdrRelvSocMin"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;maxLength value="30"/&gt;
 *     &lt;enumeration value="Alleenstaand 18 jaar"/&gt;
 *     &lt;enumeration value="Alleenstaand 19 jaar"/&gt;
 *     &lt;enumeration value="Alleenstaand 20 jaar"/&gt;
 *     &lt;enumeration value="Alleenstaand 21 jaar"/&gt;
 *     &lt;enumeration value="Alleenstaand 22 jaar"/&gt;
 *     &lt;enumeration value="Alleenstaand 23 jaar en ouder"/&gt;
 *     &lt;enumeration value="Gehuwd of daarmee gelijkgesteld"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "StdCdAfgerondMaandbdrRelvSocMin", namespace = "http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439")
@XmlEnum
public enum StdCdAfgerondMaandbdrRelvSocMin {


    /**
     *  800,00
     * 
     */
    @XmlEnumValue("Alleenstaand 18 jaar")
    ALLEENSTAAND_18_JAAR("Alleenstaand 18 jaar"),

    /**
     *  950,00
     * 
     */
    @XmlEnumValue("Alleenstaand 19 jaar")
    ALLEENSTAAND_19_JAAR("Alleenstaand 19 jaar"),

    /**
     *  1.225,00
     * 
     */
    @XmlEnumValue("Alleenstaand 20 jaar")
    ALLEENSTAAND_20_JAAR("Alleenstaand 20 jaar"),

    /**
     *  1.500,00
     * 
     */
    @XmlEnumValue("Alleenstaand 21 jaar")
    ALLEENSTAAND_21_JAAR("Alleenstaand 21 jaar"),

    /**
     *  1.900,00
     * 
     */
    @XmlEnumValue("Alleenstaand 22 jaar")
    ALLEENSTAAND_22_JAAR("Alleenstaand 22 jaar"),

    /**
     *  1.900,00
     * 
     */
    @XmlEnumValue("Alleenstaand 23 jaar en ouder")
    ALLEENSTAAND_23_JAAR_EN_OUDER("Alleenstaand 23 jaar en ouder"),

    /**
     *  2.550,00
     * 
     */
    @XmlEnumValue("Gehuwd of daarmee gelijkgesteld")
    GEHUWD_OF_DAARMEE_GELIJKGESTELD("Gehuwd of daarmee gelijkgesteld");
    private final String value;

    StdCdAfgerondMaandbdrRelvSocMin(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static StdCdAfgerondMaandbdrRelvSocMin fromValue(String v) {
        for (StdCdAfgerondMaandbdrRelvSocMin c: StdCdAfgerondMaandbdrRelvSocMin.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
