
package nl.uwv.schemas.uwvml.applicatiefout_v0200;

import java.util.ArrayList;
import java.util.List;
import javax.validation.Valid;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ApplicatieFout complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ApplicatieFout"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="FoutCode" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="FoutTekst" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="FoutBron"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="CdKolomSuwi" type="{http://www.w3.org/2001/XMLSchema}unsignedInt" minOccurs="0"/&gt;
 *                   &lt;element name="CdPartijSuwi" type="{http://www.w3.org/2001/XMLSchema}unsignedInt" minOccurs="0"/&gt;
 *                   &lt;element name="CdVestigingSuwi" type="{http://www.w3.org/2001/XMLSchema}unsignedInt" minOccurs="0"/&gt;
 *                   &lt;element name="ApplicatieNaam" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="InnerApplicatieFout" type="{http://schemas.uwv.nl/UwvML/ApplicatieFout-v0200}ApplicatieFout" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ApplicatieFout", propOrder = {
    "foutCode",
    "foutTekst",
    "foutBron",
    "innerApplicatieFout"
})
public class ApplicatieFout {

    @XmlElement(name = "FoutCode", required = true)
    @NotNull
    protected String foutCode;
    @XmlElement(name = "FoutTekst", required = true)
    @NotNull
    protected String foutTekst;
    @XmlElement(name = "FoutBron", required = true)
    @NotNull
    @Valid
    protected ApplicatieFout.FoutBron foutBron;
    @XmlElement(name = "InnerApplicatieFout")
    @Valid
    protected List<ApplicatieFout> innerApplicatieFout;

    /**
     * Gets the value of the foutCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFoutCode() {
        return foutCode;
    }

    /**
     * Sets the value of the foutCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFoutCode(String value) {
        this.foutCode = value;
    }

    /**
     * Gets the value of the foutTekst property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFoutTekst() {
        return foutTekst;
    }

    /**
     * Sets the value of the foutTekst property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFoutTekst(String value) {
        this.foutTekst = value;
    }

    /**
     * Gets the value of the foutBron property.
     * 
     * @return
     *     possible object is
     *     {@link ApplicatieFout.FoutBron }
     *     
     */
    public ApplicatieFout.FoutBron getFoutBron() {
        return foutBron;
    }

    /**
     * Sets the value of the foutBron property.
     * 
     * @param value
     *     allowed object is
     *     {@link ApplicatieFout.FoutBron }
     *     
     */
    public void setFoutBron(ApplicatieFout.FoutBron value) {
        this.foutBron = value;
    }

    /**
     * Gets the value of the innerApplicatieFout property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the innerApplicatieFout property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getInnerApplicatieFout().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ApplicatieFout }
     * 
     * 
     */
    public List<ApplicatieFout> getInnerApplicatieFout() {
        if (innerApplicatieFout == null) {
            innerApplicatieFout = new ArrayList<ApplicatieFout>();
        }
        return this.innerApplicatieFout;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="CdKolomSuwi" type="{http://www.w3.org/2001/XMLSchema}unsignedInt" minOccurs="0"/&gt;
     *         &lt;element name="CdPartijSuwi" type="{http://www.w3.org/2001/XMLSchema}unsignedInt" minOccurs="0"/&gt;
     *         &lt;element name="CdVestigingSuwi" type="{http://www.w3.org/2001/XMLSchema}unsignedInt" minOccurs="0"/&gt;
     *         &lt;element name="ApplicatieNaam" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "cdKolomSuwi",
        "cdPartijSuwi",
        "cdVestigingSuwi",
        "applicatieNaam"
    })
    public static class FoutBron {

        @XmlElement(name = "CdKolomSuwi")
        @XmlSchemaType(name = "unsignedInt")
        @DecimalMax("4294967295")
        @DecimalMin("0")
        protected Long cdKolomSuwi;
        @XmlElement(name = "CdPartijSuwi")
        @XmlSchemaType(name = "unsignedInt")
        @DecimalMax("4294967295")
        @DecimalMin("0")
        protected Long cdPartijSuwi;
        @XmlElement(name = "CdVestigingSuwi")
        @XmlSchemaType(name = "unsignedInt")
        @DecimalMax("4294967295")
        @DecimalMin("0")
        protected Long cdVestigingSuwi;
        @XmlElement(name = "ApplicatieNaam", required = true)
        @NotNull
        protected String applicatieNaam;

        /**
         * Gets the value of the cdKolomSuwi property.
         * 
         * @return
         *     possible object is
         *     {@link Long }
         *     
         */
        public Long getCdKolomSuwi() {
            return cdKolomSuwi;
        }

        /**
         * Sets the value of the cdKolomSuwi property.
         * 
         * @param value
         *     allowed object is
         *     {@link Long }
         *     
         */
        public void setCdKolomSuwi(Long value) {
            this.cdKolomSuwi = value;
        }

        /**
         * Gets the value of the cdPartijSuwi property.
         * 
         * @return
         *     possible object is
         *     {@link Long }
         *     
         */
        public Long getCdPartijSuwi() {
            return cdPartijSuwi;
        }

        /**
         * Sets the value of the cdPartijSuwi property.
         * 
         * @param value
         *     allowed object is
         *     {@link Long }
         *     
         */
        public void setCdPartijSuwi(Long value) {
            this.cdPartijSuwi = value;
        }

        /**
         * Gets the value of the cdVestigingSuwi property.
         * 
         * @return
         *     possible object is
         *     {@link Long }
         *     
         */
        public Long getCdVestigingSuwi() {
            return cdVestigingSuwi;
        }

        /**
         * Sets the value of the cdVestigingSuwi property.
         * 
         * @param value
         *     allowed object is
         *     {@link Long }
         *     
         */
        public void setCdVestigingSuwi(Long value) {
            this.cdVestigingSuwi = value;
        }

        /**
         * Gets the value of the applicatieNaam property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getApplicatieNaam() {
            return applicatieNaam;
        }

        /**
         * Sets the value of the applicatieNaam property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setApplicatieNaam(String value) {
            this.applicatieNaam = value;
        }

    }

}
