
package nl.uwv.schemas.uwvml.uwvml_basetypes_v0439;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for StdCdSrtRniactualisering.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <pre>
 * &lt;simpleType name="StdCdSrtRniactualisering"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;length value="6"/&gt;
 *     &lt;enumeration value="AC0101"/&gt;
 *     &lt;enumeration value="AC0102"/&gt;
 *     &lt;enumeration value="AC0103"/&gt;
 *     &lt;enumeration value="AC0401"/&gt;
 *     &lt;enumeration value="AC0402"/&gt;
 *     &lt;enumeration value="AC0403"/&gt;
 *     &lt;enumeration value="AC0404"/&gt;
 *     &lt;enumeration value="AC0405"/&gt;
 *     &lt;enumeration value="AC0406"/&gt;
 *     &lt;enumeration value="AC0407"/&gt;
 *     &lt;enumeration value="AC0408"/&gt;
 *     &lt;enumeration value="AC0409"/&gt;
 *     &lt;enumeration value="AC0410"/&gt;
 *     &lt;enumeration value="AC0411"/&gt;
 *     &lt;enumeration value="AC0601"/&gt;
 *     &lt;enumeration value="AC0602"/&gt;
 *     &lt;enumeration value="AC0603"/&gt;
 *     &lt;enumeration value="AC0604"/&gt;
 *     &lt;enumeration value="AC0605"/&gt;
 *     &lt;enumeration value="AC0801"/&gt;
 *     &lt;enumeration value="AC0802"/&gt;
 *     &lt;enumeration value="AC0803"/&gt;
 *     &lt;enumeration value="AC8301"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "StdCdSrtRniactualisering", namespace = "http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439")
@XmlEnum
public enum StdCdSrtRniactualisering {


    /**
     * Wijziging in de naam
     * 
     */
    @XmlEnumValue("AC0101")
    AC_0101("AC0101"),

    /**
     * Wijziging in de geboorte
     * 
     */
    @XmlEnumValue("AC0102")
    AC_0102("AC0102"),

    /**
     * Wijziging in het geslacht
     * 
     */
    @XmlEnumValue("AC0103")
    AC_0103("AC0103"),

    /**
     * Verkrijging Nederlandse nationaliteit
     * 
     */
    @XmlEnumValue("AC0401")
    AC_0401("AC0401"),

    /**
     * Verlies Nederlandse nationaliteit
     * 
     */
    @XmlEnumValue("AC0402")
    AC_0402("AC0402"),

    /**
     * Verkrijging buitenlandse nationaliteit
     * 
     */
    @XmlEnumValue("AC0403")
    AC_0403("AC0403"),

    /**
     * Verlies buitenlandse nationaliteit
     * 
     */
    @XmlEnumValue("AC0404")
    AC_0404("AC0404"),

    /**
     * Beëindiging staatloosheid
     * 
     */
    @XmlEnumValue("AC0405")
    AC_0405("AC0405"),

    /**
     * Wijziging in de reden verkrijging
     * 
     */
    @XmlEnumValue("AC0406")
    AC_0406("AC0406"),

    /**
     * Wijziging in de reden verlies
     * 
     */
    @XmlEnumValue("AC0407")
    AC_0407("AC0407"),

    /**
     * Verwijderen van nationaliteitsgegevens
     * 
     */
    @XmlEnumValue("AC0408")
    AC_0408("AC0408"),

    /**
     * Correctie van ten onrechte opgenomen gegevens
     * 
     */
    @XmlEnumValue("AC0409")
    AC_0409("AC0409"),

    /**
     * Actualiseren akte en document
     * 
     */
    @XmlEnumValue("AC0410")
    AC_0410("AC0410"),

    /**
     * Actualiseren van de ingangsdatum geldigheid
     * 
     */
    @XmlEnumValue("AC0411")
    AC_0411("AC0411"),

    /**
     * Opnemen overlijdensgegevens
     * 
     */
    @XmlEnumValue("AC0601")
    AC_0601("AC0601"),

    /**
     * Wijziging in overlijden
     * 
     */
    @XmlEnumValue("AC0602")
    AC_0602("AC0602"),

    /**
     * Correctie van ten onrechte opgenomen gegevens
     * 
     */
    @XmlEnumValue("AC0603")
    AC_0603("AC0603"),

    /**
     * Actualiseren akte en document
     * 
     */
    @XmlEnumValue("AC0604")
    AC_0604("AC0604"),

    /**
     * Actualiseren van de ingangsdatum geldigheid
     * 
     */
    @XmlEnumValue("AC0605")
    AC_0605("AC0605"),

    /**
     * Wijziging buitenlands adres
     * 
     */
    @XmlEnumValue("AC0801")
    AC_0801("AC0801"),

    /**
     * Wijziging in de omschrijving v/d aangifte adreshouding
     * 
     */
    @XmlEnumValue("AC0802")
    AC_0802("AC0802"),

    /**
     * Actualiseren van de ingangsdatum geldigheid
     * 
     */
    @XmlEnumValue("AC0803")
    AC_0803("AC0803"),

    /**
     * Wijzigen onderzoeksgegevens
     * 
     */
    @XmlEnumValue("AC8301")
    AC_8301("AC8301");
    private final String value;

    StdCdSrtRniactualisering(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static StdCdSrtRniactualisering fromValue(String v) {
        for (StdCdSrtRniactualisering c: StdCdSrtRniactualisering.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
