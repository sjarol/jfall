
package nl.uwv.schemas.uwvml.uwvml_basetypes_v0439;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for StdCdStatusBetalingBank.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <pre>
 * &lt;simpleType name="StdCdStatusBetalingBank"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;length value="1"/&gt;
 *     &lt;pattern value="\D*"/&gt;
 *     &lt;enumeration value="B"/&gt;
 *     &lt;enumeration value="N"/&gt;
 *     &lt;enumeration value="O"/&gt;
 *     &lt;enumeration value="P"/&gt;
 *     &lt;enumeration value="R"/&gt;
 *     &lt;enumeration value="S"/&gt;
 *     &lt;enumeration value="U"/&gt;
 *     &lt;enumeration value="V"/&gt;
 *     &lt;enumeration value="X"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "StdCdStatusBetalingBank", namespace = "http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439")
@XmlEnum
public enum StdCdStatusBetalingBank {


    /**
     * Post(en) nog niet uitbetaald aan bank
     * 
     */
    B,

    /**
     * Post geweigerd door de bank
     * 
     */
    N,

    /**
     * Status onbekend
     * 
     */
    O,

    /**
     * Post retour, handmatig gekoppeld, bedrag wijkt af
     * 
     */
    P,

    /**
     * Post retour, automatisch gekoppeld
     * 
     */
    R,

    /**
     * Post retour, handmatig gekoppeld
     * 
     */
    S,

    /**
     * Post uitgevoerd door bank
     * 
     */
    U,

    /**
     * Post hoort bij een 'niet gefiatteerd' verzamelbestand
     * 
     */
    V,

    /**
     * Geannuleerde post
     * 
     */
    X;

    public String value() {
        return name();
    }

    public static StdCdStatusBetalingBank fromValue(String v) {
        return valueOf(v);
    }

}
