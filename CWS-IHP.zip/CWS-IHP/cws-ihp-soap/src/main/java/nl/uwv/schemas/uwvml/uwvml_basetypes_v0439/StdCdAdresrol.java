
package nl.uwv.schemas.uwvml.uwvml_basetypes_v0439;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for StdCdAdresrol.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <pre>
 * &lt;simpleType name="StdCdAdresrol"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;length value="1"/&gt;
 *     &lt;pattern value="\D*"/&gt;
 *     &lt;enumeration value="A"/&gt;
 *     &lt;enumeration value="B"/&gt;
 *     &lt;enumeration value="C"/&gt;
 *     &lt;enumeration value="D"/&gt;
 *     &lt;enumeration value="E"/&gt;
 *     &lt;enumeration value="F"/&gt;
 *     &lt;enumeration value="G"/&gt;
 *     &lt;enumeration value="J"/&gt;
 *     &lt;enumeration value="L"/&gt;
 *     &lt;enumeration value="M"/&gt;
 *     &lt;enumeration value="P"/&gt;
 *     &lt;enumeration value="R"/&gt;
 *     &lt;enumeration value="V"/&gt;
 *     &lt;enumeration value="W"/&gt;
 *     &lt;enumeration value="Z"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "StdCdAdresrol", namespace = "http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439")
@XmlEnum
public enum StdCdAdresrol {


    /**
     * Verblijfadres bij afwijkend woonland
     * 
     */
    A,

    /**
     * Briefadres
     * 
     */
    B,

    /**
     * Correspondentieadres
     * 
     */
    C,

    /**
     * Domicilieadres (Vervallen)
     * 
     */
    D,

    /**
     * Bezoekadres
     * 
     */
    E,

    /**
     * Feitelijk adres
     * 
     */
    F,

    /**
     * Correspondentieadres gemachtigde
     * 
     */
    G,

    /**
     * Correspondentieadres wettelijk vertegenwoordiger
     * 
     */
    J,

    /**
     * Loonaangifteadres (uitsluitend voor testdoeleinden)
     * 
     */
    L,

    /**
     * RNI adres gemuteerd door UWV
     * 
     */
    M,

    /**
     * Postadres
     * 
     */
    P,

    /**
     * RNI adres
     * 
     */
    R,

    /**
     * Verblijfadres bij ziekte
     * 
     */
    V,

    /**
     * Woonadres
     * 
     */
    W,

    /**
     * Verpleegadres (Vervallen)
     * 
     */
    Z;

    public String value() {
        return name();
    }

    public static StdCdAdresrol fromValue(String v) {
        return valueOf(v);
    }

}
