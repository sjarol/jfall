
package nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0001;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0001 package. 
 * &lt;p&gt;An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0001
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse }
     * 
     */
    public CwsInhoudingsplichtigeResponse createCwsInhoudingsplichtigeResponse() {
        return new CwsInhoudingsplichtigeResponse();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering createCwsInhoudingsplichtigeResponseGegevenslevering() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon createCwsInhoudingsplichtigeResponseGegevensleveringPersoon() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.AdministratieveEenheid }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.AdministratieveEenheid createCwsInhoudingsplichtigeResponseGegevensleveringPersoonAdministratieveEenheid() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.AdministratieveEenheid();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.AdministratieveEenheid.Adres }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.AdministratieveEenheid.Adres createCwsInhoudingsplichtigeResponseGegevensleveringPersoonAdministratieveEenheidAdres() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.AdministratieveEenheid.Adres();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.AdministratieveEenheid.Adres.AdresBuitenland }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.AdministratieveEenheid.Adres.AdresBuitenland createCwsInhoudingsplichtigeResponseGegevensleveringPersoonAdministratieveEenheidAdresAdresBuitenland() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.AdministratieveEenheid.Adres.AdresBuitenland();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.AdministratieveEenheid.Adres.AdresNederland }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.AdministratieveEenheid.Adres.AdresNederland createCwsInhoudingsplichtigeResponseGegevensleveringPersoonAdministratieveEenheidAdresAdresNederland() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.AdministratieveEenheid.Adres.AdresNederland();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.MaatschappelijkeActiviteit }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.MaatschappelijkeActiviteit createCwsInhoudingsplichtigeResponseGegevensleveringPersoonMaatschappelijkeActiviteit() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.MaatschappelijkeActiviteit();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.MaatschappelijkeActiviteit.VestigingHandelsregister }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.MaatschappelijkeActiviteit.VestigingHandelsregister createCwsInhoudingsplichtigeResponseGegevensleveringPersoonMaatschappelijkeActiviteitVestigingHandelsregister() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.MaatschappelijkeActiviteit.VestigingHandelsregister();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.MaatschappelijkeActiviteit.VestigingHandelsregister.Onderneming }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.MaatschappelijkeActiviteit.VestigingHandelsregister.Onderneming createCwsInhoudingsplichtigeResponseGegevensleveringPersoonMaatschappelijkeActiviteitVestigingHandelsregisterOnderneming() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.MaatschappelijkeActiviteit.VestigingHandelsregister.Onderneming();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.MaatschappelijkeActiviteit.VestigingHandelsregister.ActiviteitHandelsregister }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.MaatschappelijkeActiviteit.VestigingHandelsregister.ActiviteitHandelsregister createCwsInhoudingsplichtigeResponseGegevensleveringPersoonMaatschappelijkeActiviteitVestigingHandelsregisterActiviteitHandelsregister() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.MaatschappelijkeActiviteit.VestigingHandelsregister.ActiviteitHandelsregister();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.MaatschappelijkeActiviteit.VestigingHandelsregister.Adres }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.MaatschappelijkeActiviteit.VestigingHandelsregister.Adres createCwsInhoudingsplichtigeResponseGegevensleveringPersoonMaatschappelijkeActiviteitVestigingHandelsregisterAdres() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.MaatschappelijkeActiviteit.VestigingHandelsregister.Adres();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.MaatschappelijkeActiviteit.VestigingHandelsregister.Adres.AdresBuitenland }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.MaatschappelijkeActiviteit.VestigingHandelsregister.Adres.AdresBuitenland createCwsInhoudingsplichtigeResponseGegevensleveringPersoonMaatschappelijkeActiviteitVestigingHandelsregisterAdresAdresBuitenland() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.MaatschappelijkeActiviteit.VestigingHandelsregister.Adres.AdresBuitenland();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.MaatschappelijkeActiviteit.VestigingHandelsregister.Adres.AdresNederland }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.MaatschappelijkeActiviteit.VestigingHandelsregister.Adres.AdresNederland createCwsInhoudingsplichtigeResponseGegevensleveringPersoonMaatschappelijkeActiviteitVestigingHandelsregisterAdresAdresNederland() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.MaatschappelijkeActiviteit.VestigingHandelsregister.Adres.AdresNederland();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.Adres }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.Adres createCwsInhoudingsplichtigeResponseGegevensleveringPersoonAdres() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.Adres();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.Adres.AdresBuitenland }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.Adres.AdresBuitenland createCwsInhoudingsplichtigeResponseGegevensleveringPersoonAdresAdresBuitenland() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.Adres.AdresBuitenland();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.Adres.AdresNederland }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.Adres.AdresNederland createCwsInhoudingsplichtigeResponseGegevensleveringPersoonAdresAdresNederland() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.Adres.AdresNederland();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.NatuurlijkPersoon }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.NatuurlijkPersoon createCwsInhoudingsplichtigeResponseGegevensleveringPersoonNatuurlijkPersoon() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.NatuurlijkPersoon();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.NietNatuurlijkPersoon }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.NietNatuurlijkPersoon createCwsInhoudingsplichtigeResponseGegevensleveringPersoonNietNatuurlijkPersoon() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.NietNatuurlijkPersoon();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.NietNatuurlijkPersoon.Rechtspersoon }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.NietNatuurlijkPersoon.Rechtspersoon createCwsInhoudingsplichtigeResponseGegevensleveringPersoonNietNatuurlijkPersoonRechtspersoon() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.NietNatuurlijkPersoon.Rechtspersoon();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Applicatiemelding }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Applicatiemelding createCwsInhoudingsplichtigeResponseApplicatiemelding() {
        return new CwsInhoudingsplichtigeResponse.Applicatiemelding();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.Rechtsvorm }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.Rechtsvorm createCwsInhoudingsplichtigeResponseGegevensleveringPersoonRechtsvorm() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.Rechtsvorm();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.FaillSurs }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.FaillSurs createCwsInhoudingsplichtigeResponseGegevensleveringPersoonFaillSurs() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.FaillSurs();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.Gemoedsbezwaardheid }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.Gemoedsbezwaardheid createCwsInhoudingsplichtigeResponseGegevensleveringPersoonGemoedsbezwaardheid() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.Gemoedsbezwaardheid();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.PersoonHandelsregister }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.PersoonHandelsregister createCwsInhoudingsplichtigeResponseGegevensleveringPersoonPersoonHandelsregister() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.PersoonHandelsregister();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.AdministratieveEenheid.SectorRisicogroep }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.AdministratieveEenheid.SectorRisicogroep createCwsInhoudingsplichtigeResponseGegevensleveringPersoonAdministratieveEenheidSectorRisicogroep() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.AdministratieveEenheid.SectorRisicogroep();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.AdministratieveEenheid.PremiepercIndividueel }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.AdministratieveEenheid.PremiepercIndividueel createCwsInhoudingsplichtigeResponseGegevensleveringPersoonAdministratieveEenheidPremiepercIndividueel() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.AdministratieveEenheid.PremiepercIndividueel();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.AdministratieveEenheid.EigenRisicoDrager }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.AdministratieveEenheid.EigenRisicoDrager createCwsInhoudingsplichtigeResponseGegevensleveringPersoonAdministratieveEenheidEigenRisicoDrager() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.AdministratieveEenheid.EigenRisicoDrager();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.AdministratieveEenheid.VoortzettingsrelatieOpvolger }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.AdministratieveEenheid.VoortzettingsrelatieOpvolger createCwsInhoudingsplichtigeResponseGegevensleveringPersoonAdministratieveEenheidVoortzettingsrelatieOpvolger() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.AdministratieveEenheid.VoortzettingsrelatieOpvolger();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.AdministratieveEenheid.VoortzettingsrelatieVoorganger }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.AdministratieveEenheid.VoortzettingsrelatieVoorganger createCwsInhoudingsplichtigeResponseGegevensleveringPersoonAdministratieveEenheidVoortzettingsrelatieVoorganger() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.AdministratieveEenheid.VoortzettingsrelatieVoorganger();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.AdministratieveEenheid.AangifteFrequentieAdminEenheid }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.AdministratieveEenheid.AangifteFrequentieAdminEenheid createCwsInhoudingsplichtigeResponseGegevensleveringPersoonAdministratieveEenheidAangifteFrequentieAdminEenheid() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.AdministratieveEenheid.AangifteFrequentieAdminEenheid();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.AdministratieveEenheid.AansluitingsnrBv }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.AdministratieveEenheid.AansluitingsnrBv createCwsInhoudingsplichtigeResponseGegevensleveringPersoonAdministratieveEenheidAansluitingsnrBv() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.AdministratieveEenheid.AansluitingsnrBv();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.AdministratieveEenheid.Adres.AdresBuitenlandOngestructureerd }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.AdministratieveEenheid.Adres.AdresBuitenlandOngestructureerd createCwsInhoudingsplichtigeResponseGegevensleveringPersoonAdministratieveEenheidAdresAdresBuitenlandOngestructureerd() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.AdministratieveEenheid.Adres.AdresBuitenlandOngestructureerd();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.AdministratieveEenheid.Adres.AdresBuitenland.StraatadresBuitenland }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.AdministratieveEenheid.Adres.AdresBuitenland.StraatadresBuitenland createCwsInhoudingsplichtigeResponseGegevensleveringPersoonAdministratieveEenheidAdresAdresBuitenlandStraatadresBuitenland() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.AdministratieveEenheid.Adres.AdresBuitenland.StraatadresBuitenland();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.AdministratieveEenheid.Adres.AdresBuitenland.PostbusadresBuitenland }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.AdministratieveEenheid.Adres.AdresBuitenland.PostbusadresBuitenland createCwsInhoudingsplichtigeResponseGegevensleveringPersoonAdministratieveEenheidAdresAdresBuitenlandPostbusadresBuitenland() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.AdministratieveEenheid.Adres.AdresBuitenland.PostbusadresBuitenland();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.AdministratieveEenheid.Adres.AdresNederland.Straatadres }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.AdministratieveEenheid.Adres.AdresNederland.Straatadres createCwsInhoudingsplichtigeResponseGegevensleveringPersoonAdministratieveEenheidAdresAdresNederlandStraatadres() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.AdministratieveEenheid.Adres.AdresNederland.Straatadres();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.AdministratieveEenheid.Adres.AdresNederland.Postbusadres }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.AdministratieveEenheid.Adres.AdresNederland.Postbusadres createCwsInhoudingsplichtigeResponseGegevensleveringPersoonAdministratieveEenheidAdresAdresNederlandPostbusadres() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.AdministratieveEenheid.Adres.AdresNederland.Postbusadres();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.MaatschappelijkeActiviteit.Sbiactiviteit }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.MaatschappelijkeActiviteit.Sbiactiviteit createCwsInhoudingsplichtigeResponseGegevensleveringPersoonMaatschappelijkeActiviteitSbiactiviteit() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.MaatschappelijkeActiviteit.Sbiactiviteit();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.MaatschappelijkeActiviteit.VestigingHandelsregister.Handelsnaam }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.MaatschappelijkeActiviteit.VestigingHandelsregister.Handelsnaam createCwsInhoudingsplichtigeResponseGegevensleveringPersoonMaatschappelijkeActiviteitVestigingHandelsregisterHandelsnaam() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.MaatschappelijkeActiviteit.VestigingHandelsregister.Handelsnaam();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.MaatschappelijkeActiviteit.VestigingHandelsregister.Onderneming.Sbiactiviteit }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.MaatschappelijkeActiviteit.VestigingHandelsregister.Onderneming.Sbiactiviteit createCwsInhoudingsplichtigeResponseGegevensleveringPersoonMaatschappelijkeActiviteitVestigingHandelsregisterOndernemingSbiactiviteit() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.MaatschappelijkeActiviteit.VestigingHandelsregister.Onderneming.Sbiactiviteit();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.MaatschappelijkeActiviteit.VestigingHandelsregister.Onderneming.Handelsnaam }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.MaatschappelijkeActiviteit.VestigingHandelsregister.Onderneming.Handelsnaam createCwsInhoudingsplichtigeResponseGegevensleveringPersoonMaatschappelijkeActiviteitVestigingHandelsregisterOndernemingHandelsnaam() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.MaatschappelijkeActiviteit.VestigingHandelsregister.Onderneming.Handelsnaam();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.MaatschappelijkeActiviteit.VestigingHandelsregister.ActiviteitHandelsregister.Sbiactiviteit }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.MaatschappelijkeActiviteit.VestigingHandelsregister.ActiviteitHandelsregister.Sbiactiviteit createCwsInhoudingsplichtigeResponseGegevensleveringPersoonMaatschappelijkeActiviteitVestigingHandelsregisterActiviteitHandelsregisterSbiactiviteit() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.MaatschappelijkeActiviteit.VestigingHandelsregister.ActiviteitHandelsregister.Sbiactiviteit();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.MaatschappelijkeActiviteit.VestigingHandelsregister.Adres.AdresBuitenlandOngestructureerd }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.MaatschappelijkeActiviteit.VestigingHandelsregister.Adres.AdresBuitenlandOngestructureerd createCwsInhoudingsplichtigeResponseGegevensleveringPersoonMaatschappelijkeActiviteitVestigingHandelsregisterAdresAdresBuitenlandOngestructureerd() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.MaatschappelijkeActiviteit.VestigingHandelsregister.Adres.AdresBuitenlandOngestructureerd();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.MaatschappelijkeActiviteit.VestigingHandelsregister.Adres.AdresBuitenland.StraatadresBuitenland }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.MaatschappelijkeActiviteit.VestigingHandelsregister.Adres.AdresBuitenland.StraatadresBuitenland createCwsInhoudingsplichtigeResponseGegevensleveringPersoonMaatschappelijkeActiviteitVestigingHandelsregisterAdresAdresBuitenlandStraatadresBuitenland() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.MaatschappelijkeActiviteit.VestigingHandelsregister.Adres.AdresBuitenland.StraatadresBuitenland();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.MaatschappelijkeActiviteit.VestigingHandelsregister.Adres.AdresBuitenland.PostbusadresBuitenland }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.MaatschappelijkeActiviteit.VestigingHandelsregister.Adres.AdresBuitenland.PostbusadresBuitenland createCwsInhoudingsplichtigeResponseGegevensleveringPersoonMaatschappelijkeActiviteitVestigingHandelsregisterAdresAdresBuitenlandPostbusadresBuitenland() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.MaatschappelijkeActiviteit.VestigingHandelsregister.Adres.AdresBuitenland.PostbusadresBuitenland();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.MaatschappelijkeActiviteit.VestigingHandelsregister.Adres.AdresNederland.Straatadres }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.MaatschappelijkeActiviteit.VestigingHandelsregister.Adres.AdresNederland.Straatadres createCwsInhoudingsplichtigeResponseGegevensleveringPersoonMaatschappelijkeActiviteitVestigingHandelsregisterAdresAdresNederlandStraatadres() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.MaatschappelijkeActiviteit.VestigingHandelsregister.Adres.AdresNederland.Straatadres();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.MaatschappelijkeActiviteit.VestigingHandelsregister.Adres.AdresNederland.Postbusadres }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.MaatschappelijkeActiviteit.VestigingHandelsregister.Adres.AdresNederland.Postbusadres createCwsInhoudingsplichtigeResponseGegevensleveringPersoonMaatschappelijkeActiviteitVestigingHandelsregisterAdresAdresNederlandPostbusadres() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.MaatschappelijkeActiviteit.VestigingHandelsregister.Adres.AdresNederland.Postbusadres();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.Adres.AdresBuitenlandOngestructureerd }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.Adres.AdresBuitenlandOngestructureerd createCwsInhoudingsplichtigeResponseGegevensleveringPersoonAdresAdresBuitenlandOngestructureerd() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.Adres.AdresBuitenlandOngestructureerd();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.Adres.AdresBuitenland.StraatadresBuitenland }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.Adres.AdresBuitenland.StraatadresBuitenland createCwsInhoudingsplichtigeResponseGegevensleveringPersoonAdresAdresBuitenlandStraatadresBuitenland() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.Adres.AdresBuitenland.StraatadresBuitenland();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.Adres.AdresBuitenland.PostbusadresBuitenland }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.Adres.AdresBuitenland.PostbusadresBuitenland createCwsInhoudingsplichtigeResponseGegevensleveringPersoonAdresAdresBuitenlandPostbusadresBuitenland() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.Adres.AdresBuitenland.PostbusadresBuitenland();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.Adres.AdresNederland.Straatadres }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.Adres.AdresNederland.Straatadres createCwsInhoudingsplichtigeResponseGegevensleveringPersoonAdresAdresNederlandStraatadres() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.Adres.AdresNederland.Straatadres();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.Adres.AdresNederland.Postbusadres }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.Adres.AdresNederland.Postbusadres createCwsInhoudingsplichtigeResponseGegevensleveringPersoonAdresAdresNederlandPostbusadres() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.Adres.AdresNederland.Postbusadres();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.NatuurlijkPersoon.HuwelijkGeregistreerdPartner }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.NatuurlijkPersoon.HuwelijkGeregistreerdPartner createCwsInhoudingsplichtigeResponseGegevensleveringPersoonNatuurlijkPersoonHuwelijkGeregistreerdPartner() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.NatuurlijkPersoon.HuwelijkGeregistreerdPartner();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.NatuurlijkPersoon.Nationaliteit }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.NatuurlijkPersoon.Nationaliteit createCwsInhoudingsplichtigeResponseGegevensleveringPersoonNatuurlijkPersoonNationaliteit() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.NatuurlijkPersoon.Nationaliteit();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.NietNatuurlijkPersoon.VennootschapBuitenland }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.NietNatuurlijkPersoon.VennootschapBuitenland createCwsInhoudingsplichtigeResponseGegevensleveringPersoonNietNatuurlijkPersoonVennootschapBuitenland() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.NietNatuurlijkPersoon.VennootschapBuitenland();
    }

    /**
     * Create an instance of {@link CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.NietNatuurlijkPersoon.Rechtspersoon.ActiviteitHandelsregister }
     * 
     */
    public CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.NietNatuurlijkPersoon.Rechtspersoon.ActiviteitHandelsregister createCwsInhoudingsplichtigeResponseGegevensleveringPersoonNietNatuurlijkPersoonRechtspersoonActiviteitHandelsregister() {
        return new CwsInhoudingsplichtigeResponse.Gegevenslevering.Persoon.NietNatuurlijkPersoon.Rechtspersoon.ActiviteitHandelsregister();
    }

}
