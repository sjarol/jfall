
package nl.uwv.schemas.uwvml.uwvml_basetypes_v0439;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for StdCdContractduur.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <pre>
 * &lt;simpleType name="StdCdContractduur"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;length value="1"/&gt;
 *     &lt;pattern value="[A-Z]*"/&gt;
 *     &lt;enumeration value="B"/&gt;
 *     &lt;enumeration value="O"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "StdCdContractduur", namespace = "http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439")
@XmlEnum
public enum StdCdContractduur {


    /**
     * bepaalde tijd
     * 
     */
    B,

    /**
     * onbepaalde tijd
     * 
     */
    O;

    public String value() {
        return name();
    }

    public static StdCdContractduur fromValue(String v) {
        return valueOf(v);
    }

}
