
package nl.uwv.schemas.uwvml.uwvml_basetypes_v0439;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for StdCdKantoorHandhaven.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <pre>
 * &lt;simpleType name="StdCdKantoorHandhaven"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;maxLength value="3"/&gt;
 *     &lt;enumeration value="B01"/&gt;
 *     &lt;enumeration value="B03"/&gt;
 *     &lt;enumeration value="B09"/&gt;
 *     &lt;enumeration value="B10"/&gt;
 *     &lt;enumeration value="B15"/&gt;
 *     &lt;enumeration value="B34"/&gt;
 *     &lt;enumeration value="B40"/&gt;
 *     &lt;enumeration value="B50"/&gt;
 *     &lt;enumeration value="B51"/&gt;
 *     &lt;enumeration value="B52"/&gt;
 *     &lt;enumeration value="B53"/&gt;
 *     &lt;enumeration value="B54"/&gt;
 *     &lt;enumeration value="IR"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "StdCdKantoorHandhaven", namespace = "http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439")
@XmlEnum
public enum StdCdKantoorHandhaven {


    /**
     * Groningen
     * 
     */
    @XmlEnumValue("B01")
    B_01("B01"),

    /**
     * Zwolle
     * 
     */
    @XmlEnumValue("B03")
    B_03("B03"),

    /**
     * Amsterdam
     * 
     */
    @XmlEnumValue("B09")
    B_09("B09"),

    /**
     * Den Haag
     * 
     */
    @XmlEnumValue("B10")
    B_10("B10"),

    /**
     * Eindhoven
     * 
     */
    @XmlEnumValue("B15")
    B_15("B15"),

    /**
     * Amsterdam internationaal
     * 
     */
    @XmlEnumValue("B34")
    B_34("B34"),

    /**
     * Dienstenportfolio
     * 
     */
    @XmlEnumValue("B40")
    B_40("B40"),

    /**
     * Themaonderzoek Amsterdam
     * 
     */
    @XmlEnumValue("B50")
    B_50("B50"),

    /**
     * Themaonderzoek Eindhoven
     * 
     */
    @XmlEnumValue("B51")
    B_51("B51"),

    /**
     * Themaonderzoek Rotterdam
     * 
     */
    @XmlEnumValue("B52")
    B_52("B52"),

    /**
     * Themaonderzoek Zwolle
     * 
     */
    @XmlEnumValue("B53")
    B_53("B53"),

    /**
     * Themaonderzoek Utrecht
     * 
     */
    @XmlEnumValue("B54")
    B_54("B54"),

    /**
     * Intake en registratie
     * 
     */
    IR("IR");
    private final String value;

    StdCdKantoorHandhaven(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static StdCdKantoorHandhaven fromValue(String v) {
        for (StdCdKantoorHandhaven c: StdCdKantoorHandhaven.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
