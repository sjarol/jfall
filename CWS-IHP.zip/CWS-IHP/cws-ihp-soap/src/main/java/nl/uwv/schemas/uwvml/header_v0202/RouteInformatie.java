
package nl.uwv.schemas.uwvml.header_v0202;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * Identificaties voor het routeren en traceren van het bericht.
 * 
 * <p>Java class for RouteInformatie complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="RouteInformatie"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Bron"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;extension base="{http://schemas.uwv.nl/UwvML/Header-v0202}Partij"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="DatTijdVersturenBericht" type="{http://www.w3.org/2001/XMLSchema}dateTime"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/extension&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Bestemming" type="{http://schemas.uwv.nl/UwvML/Header-v0202}Partij"/&gt;
 *         &lt;element name="Tussenstation" type="{http://schemas.uwv.nl/UwvML/Header-v0202}TussenstationType" minOccurs="0"/&gt;
 *         &lt;element name="GegevensUitwisselingsnr" type="{http://www.w3.org/2001/XMLSchema}anyURI"/&gt;
 *         &lt;element name="RefnrGegevensUitwisselingsExtern" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="256"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RouteInformatie", propOrder = {
    "bron",
    "bestemming",
    "tussenstation",
    "gegevensUitwisselingsnr",
    "refnrGegevensUitwisselingsExtern"
})
@XmlSeeAlso({
    nl.uwv.schemas.uwvml.header_v0202.UwvMLHeader.RouteInformatie.class
})
public class RouteInformatie {

    @XmlElement(name = "Bron", required = true)
    @NotNull
    @Valid
    protected RouteInformatie.Bron bron;
    @XmlElement(name = "Bestemming", required = true)
    @NotNull
    @Valid
    protected Partij bestemming;
    @XmlElement(name = "Tussenstation")
    @Valid
    protected TussenstationType tussenstation;
    @XmlElement(name = "GegevensUitwisselingsnr", required = true)
    @XmlSchemaType(name = "anyURI")
    @NotNull
    protected String gegevensUitwisselingsnr;
    @XmlElement(name = "RefnrGegevensUitwisselingsExtern")
    @Size(max = 256)
    protected String refnrGegevensUitwisselingsExtern;

    /**
     * Gets the value of the bron property.
     * 
     * @return
     *     possible object is
     *     {@link RouteInformatie.Bron }
     *     
     */
    public RouteInformatie.Bron getBron() {
        return bron;
    }

    /**
     * Sets the value of the bron property.
     * 
     * @param value
     *     allowed object is
     *     {@link RouteInformatie.Bron }
     *     
     */
    public void setBron(RouteInformatie.Bron value) {
        this.bron = value;
    }

    /**
     * Gets the value of the bestemming property.
     * 
     * @return
     *     possible object is
     *     {@link Partij }
     *     
     */
    public Partij getBestemming() {
        return bestemming;
    }

    /**
     * Sets the value of the bestemming property.
     * 
     * @param value
     *     allowed object is
     *     {@link Partij }
     *     
     */
    public void setBestemming(Partij value) {
        this.bestemming = value;
    }

    /**
     * Gets the value of the tussenstation property.
     * 
     * @return
     *     possible object is
     *     {@link TussenstationType }
     *     
     */
    public TussenstationType getTussenstation() {
        return tussenstation;
    }

    /**
     * Sets the value of the tussenstation property.
     * 
     * @param value
     *     allowed object is
     *     {@link TussenstationType }
     *     
     */
    public void setTussenstation(TussenstationType value) {
        this.tussenstation = value;
    }

    /**
     * Gets the value of the gegevensUitwisselingsnr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGegevensUitwisselingsnr() {
        return gegevensUitwisselingsnr;
    }

    /**
     * Sets the value of the gegevensUitwisselingsnr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGegevensUitwisselingsnr(String value) {
        this.gegevensUitwisselingsnr = value;
    }

    /**
     * Gets the value of the refnrGegevensUitwisselingsExtern property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRefnrGegevensUitwisselingsExtern() {
        return refnrGegevensUitwisselingsExtern;
    }

    /**
     * Sets the value of the refnrGegevensUitwisselingsExtern property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRefnrGegevensUitwisselingsExtern(String value) {
        this.refnrGegevensUitwisselingsExtern = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;extension base="{http://schemas.uwv.nl/UwvML/Header-v0202}Partij"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="DatTijdVersturenBericht" type="{http://www.w3.org/2001/XMLSchema}dateTime"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/extension&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "datTijdVersturenBericht"
    })
    public static class Bron
        extends Partij
    {

        @XmlElement(name = "DatTijdVersturenBericht", required = true)
        @XmlSchemaType(name = "dateTime")
        @NotNull
        protected XMLGregorianCalendar datTijdVersturenBericht;

        /**
         * Gets the value of the datTijdVersturenBericht property.
         * 
         * @return
         *     possible object is
         *     {@link XMLGregorianCalendar }
         *     
         */
        public XMLGregorianCalendar getDatTijdVersturenBericht() {
            return datTijdVersturenBericht;
        }

        /**
         * Sets the value of the datTijdVersturenBericht property.
         * 
         * @param value
         *     allowed object is
         *     {@link XMLGregorianCalendar }
         *     
         */
        public void setDatTijdVersturenBericht(XMLGregorianCalendar value) {
            this.datTijdVersturenBericht = value;
        }

    }

}
