@javax.xml.bind.annotation.XmlSchema(namespace = "http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeResponse-v0001", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigeresponse_v0001;
