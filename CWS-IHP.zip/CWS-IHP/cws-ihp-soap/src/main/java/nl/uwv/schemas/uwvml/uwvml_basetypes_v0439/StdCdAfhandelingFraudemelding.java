
package nl.uwv.schemas.uwvml.uwvml_basetypes_v0439;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for StdCdAfhandelingFraudemelding.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <pre>
 * &lt;simpleType name="StdCdAfhandelingFraudemelding"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;length value="3"/&gt;
 *     &lt;enumeration value="A01"/&gt;
 *     &lt;enumeration value="A02"/&gt;
 *     &lt;enumeration value="A03"/&gt;
 *     &lt;enumeration value="A04"/&gt;
 *     &lt;enumeration value="A05"/&gt;
 *     &lt;enumeration value="A06"/&gt;
 *     &lt;enumeration value="A08"/&gt;
 *     &lt;enumeration value="A09"/&gt;
 *     &lt;enumeration value="A10"/&gt;
 *     &lt;enumeration value="A11"/&gt;
 *     &lt;enumeration value="A12"/&gt;
 *     &lt;enumeration value="A13"/&gt;
 *     &lt;enumeration value="A14"/&gt;
 *     &lt;enumeration value="A15"/&gt;
 *     &lt;enumeration value="A16"/&gt;
 *     &lt;enumeration value="A17"/&gt;
 *     &lt;enumeration value="A18"/&gt;
 *     &lt;enumeration value="A19"/&gt;
 *     &lt;enumeration value="A20"/&gt;
 *     &lt;enumeration value="A21"/&gt;
 *     &lt;enumeration value="A22"/&gt;
 *     &lt;enumeration value="A23"/&gt;
 *     &lt;enumeration value="A24"/&gt;
 *     &lt;enumeration value="A25"/&gt;
 *     &lt;enumeration value="A26"/&gt;
 *     &lt;enumeration value="A27"/&gt;
 *     &lt;enumeration value="A28"/&gt;
 *     &lt;enumeration value="A29"/&gt;
 *     &lt;enumeration value="A30"/&gt;
 *     &lt;enumeration value="A33"/&gt;
 *     &lt;enumeration value="A35"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "StdCdAfhandelingFraudemelding", namespace = "http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439")
@XmlEnum
public enum StdCdAfhandelingFraudemelding {


    /**
     * Melding gereed, zaak gestart
     * 
     */
    @XmlEnumValue("A01")
    A_01("A01"),

    /**
     * Geen BSN gevonden
     * 
     */
    @XmlEnumValue("A02")
    A_02("A02"),

    /**
     * Zaak IBF
     * 
     */
    @XmlEnumValue("A03")
    A_03("A03"),

    /**
     * Geen uitkering ontvangen
     * 
     */
    @XmlEnumValue("A04")
    A_04("A04"),

    /**
     * Mogelijk thema
     * 
     */
    @XmlEnumValue("A05")
    A_05("A05"),

    /**
     * Criminele activiteiten
     * 
     */
    @XmlEnumValue("A06")
    A_06("A06"),

    /**
     * Na 3 maanden niets gevonden
     * 
     */
    @XmlEnumValue("A08")
    A_08("A08"),

    /**
     * Interventieteam buiten UWV
     * 
     */
    @XmlEnumValue("A09")
    A_09("A09"),

    /**
     * Valse persoonsgegevens / dienstverbanden
     * 
     */
    @XmlEnumValue("A10")
    A_10("A10"),

    /**
     * Geen geldige verblijfsstatus
     * 
     */
    @XmlEnumValue("A11")
    A_11("A11"),

    /**
     * Hennep
     * 
     */
    @XmlEnumValue("A12")
    A_12("A12"),

    /**
     * CMF BSN gevonden, melding voor IBF
     * 
     */
    @XmlEnumValue("A13")
    A_13("A13"),

    /**
     * CMF BSN gevonden, geen uitkering ontvangen
     * 
     */
    @XmlEnumValue("A14")
    A_14("A14"),

    /**
     * CMF BSN gevonden, melding T.O.
     * 
     */
    @XmlEnumValue("A15")
    A_15("A15"),

    /**
     * CMF BSN gevonden, criminele activiteiten
     * 
     */
    @XmlEnumValue("A16")
    A_16("A16"),

    /**
     * CMF BSN gevonden, melding iRN
     * 
     */
    @XmlEnumValue("A17")
    A_17("A17"),

    /**
     * CMF BSN gevonden, zaak aanmaken
     * 
     */
    @XmlEnumValue("A18")
    A_18("A18"),

    /**
     * CMF uitkering gevonden, melding voor IBF
     * 
     */
    @XmlEnumValue("A19")
    A_19("A19"),

    /**
     * CMF uitkering gevonden, melding voor T.O
     * 
     */
    @XmlEnumValue("A20")
    A_20("A20"),

    /**
     * CMF uitkering gevonden, criminele activiteiten
     * 
     */
    @XmlEnumValue("A21")
    A_21("A21"),

    /**
     * CMF uitkering gevonden, melding iRN
     * 
     */
    @XmlEnumValue("A22")
    A_22("A22"),

    /**
     * CMF uitkering gevonden, zaak aanmaken
     * 
     */
    @XmlEnumValue("A23")
    A_23("A23"),

    /**
     * Beoordeling CMF, A05 naar IO
     * 
     */
    @XmlEnumValue("A24")
    A_24("A24"),

    /**
     * Beoordeling CMF, A06 naar IO
     * 
     */
    @XmlEnumValue("A25")
    A_25("A25"),

    /**
     * Beoordeling CMF, A10 naar IO
     * 
     */
    @XmlEnumValue("A26")
    A_26("A26"),

    /**
     * Beoordeling CMF, A11 naar IO
     * 
     */
    @XmlEnumValue("A27")
    A_27("A27"),

    /**
     * Beoordeling CMF, A12 naar IO
     * 
     */
    @XmlEnumValue("A28")
    A_28("A28"),

    /**
     * Uitkering niet UWV
     * 
     */
    @XmlEnumValue("A29")
    A_29("A29"),

    /**
     * Bekeken zonder resultaat
     * 
     */
    @XmlEnumValue("A30")
    A_30("A30"),

    /**
     * Verkeerde BSN match, juiste BSN niet gevonden
     * 
     */
    @XmlEnumValue("A33")
    A_33("A33"),

    /**
     * Beoordeling CMF, A03 naar IO
     * 
     */
    @XmlEnumValue("A35")
    A_35("A35");
    private final String value;

    StdCdAfhandelingFraudemelding(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static StdCdAfhandelingFraudemelding fromValue(String v) {
        for (StdCdAfhandelingFraudemelding c: StdCdAfhandelingFraudemelding.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
