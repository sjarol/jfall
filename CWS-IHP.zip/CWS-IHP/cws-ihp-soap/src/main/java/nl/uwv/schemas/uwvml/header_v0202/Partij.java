
package nl.uwv.schemas.uwvml.header_v0202;

import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Partij complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Partij"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CdKolomSuwi" type="{http://schemas.uwv.nl/UwvML/Header-v0202}CdKolomSuwi" minOccurs="0"/&gt;
 *         &lt;element name="CdPartijSuwi" type="{http://schemas.uwv.nl/UwvML/Header-v0202}CdPartijSuwi" minOccurs="0"/&gt;
 *         &lt;element name="CdVestigingSuwi" type="{http://schemas.uwv.nl/UwvML/Header-v0202}CdVestigingSuwi" minOccurs="0"/&gt;
 *         &lt;element name="NaamContactpersoonAfd" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="100"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ApplicatieNaam"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="100"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Machine" minOccurs="0"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;minLength value="0"/&gt;
 *               &lt;maxLength value="256"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Partij", propOrder = {
    "cdKolomSuwi",
    "cdPartijSuwi",
    "cdVestigingSuwi",
    "naamContactpersoonAfd",
    "applicatieNaam",
    "machine"
})
@XmlSeeAlso({
    nl.uwv.schemas.uwvml.header_v0202.RouteInformatie.Bron.class,
    TussenstationType.class
})
public class Partij {

    @XmlElement(name = "CdKolomSuwi")
    @XmlSchemaType(name = "unsignedInt")
    @DecimalMax("4294967295")
    @DecimalMin("0")
    protected Long cdKolomSuwi;
    @XmlElement(name = "CdPartijSuwi")
    @XmlSchemaType(name = "unsignedInt")
    @DecimalMax("4294967295")
    @DecimalMin("0")
    protected Long cdPartijSuwi;
    @XmlElement(name = "CdVestigingSuwi")
    @XmlSchemaType(name = "unsignedInt")
    @DecimalMax("4294967295")
    @DecimalMin("0")
    protected Long cdVestigingSuwi;
    @XmlElement(name = "NaamContactpersoonAfd")
    @Size(max = 100)
    protected String naamContactpersoonAfd;
    @XmlElement(name = "ApplicatieNaam", required = true)
    @NotNull
    @Size(max = 100)
    protected String applicatieNaam;
    @XmlElement(name = "Machine")
    @Size(min = 0, max = 256)
    protected String machine;

    /**
     * Gets the value of the cdKolomSuwi property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getCdKolomSuwi() {
        return cdKolomSuwi;
    }

    /**
     * Sets the value of the cdKolomSuwi property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setCdKolomSuwi(Long value) {
        this.cdKolomSuwi = value;
    }

    /**
     * Gets the value of the cdPartijSuwi property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getCdPartijSuwi() {
        return cdPartijSuwi;
    }

    /**
     * Sets the value of the cdPartijSuwi property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setCdPartijSuwi(Long value) {
        this.cdPartijSuwi = value;
    }

    /**
     * Gets the value of the cdVestigingSuwi property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getCdVestigingSuwi() {
        return cdVestigingSuwi;
    }

    /**
     * Sets the value of the cdVestigingSuwi property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setCdVestigingSuwi(Long value) {
        this.cdVestigingSuwi = value;
    }

    /**
     * Gets the value of the naamContactpersoonAfd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNaamContactpersoonAfd() {
        return naamContactpersoonAfd;
    }

    /**
     * Sets the value of the naamContactpersoonAfd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNaamContactpersoonAfd(String value) {
        this.naamContactpersoonAfd = value;
    }

    /**
     * Gets the value of the applicatieNaam property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicatieNaam() {
        return applicatieNaam;
    }

    /**
     * Sets the value of the applicatieNaam property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicatieNaam(String value) {
        this.applicatieNaam = value;
    }

    /**
     * Gets the value of the machine property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMachine() {
        return machine;
    }

    /**
     * Sets the value of the machine property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMachine(String value) {
        this.machine = value;
    }

}
