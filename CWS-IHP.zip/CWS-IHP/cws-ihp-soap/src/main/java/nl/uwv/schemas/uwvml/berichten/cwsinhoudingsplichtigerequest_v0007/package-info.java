@javax.xml.bind.annotation.XmlSchema(namespace = "http://schemas.uwv.nl/UwvML/Berichten/CwsInhoudingsplichtigeRequest-v0007", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package nl.uwv.schemas.uwvml.berichten.cwsinhoudingsplichtigerequest_v0007;
