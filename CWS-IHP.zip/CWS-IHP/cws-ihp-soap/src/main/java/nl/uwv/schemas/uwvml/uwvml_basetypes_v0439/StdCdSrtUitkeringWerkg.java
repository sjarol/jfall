
package nl.uwv.schemas.uwvml.uwvml_basetypes_v0439;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for StdCdSrtUitkeringWerkg.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <pre>
 * &lt;simpleType name="StdCdSrtUitkeringWerkg"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;maxLength value="5"/&gt;
 *     &lt;enumeration value="OSW"/&gt;
 *     &lt;enumeration value="WW 61"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "StdCdSrtUitkeringWerkg", namespace = "http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439")
@XmlEnum
public enum StdCdSrtUitkeringWerkg {


    /**
     * OSW
     * 
     */
    OSW("OSW"),

    /**
     * WW 61
     * 
     */
    @XmlEnumValue("WW 61")
    WW_61("WW 61");
    private final String value;

    StdCdSrtUitkeringWerkg(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static StdCdSrtUitkeringWerkg fromValue(String v) {
        for (StdCdSrtUitkeringWerkg c: StdCdSrtUitkeringWerkg.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
