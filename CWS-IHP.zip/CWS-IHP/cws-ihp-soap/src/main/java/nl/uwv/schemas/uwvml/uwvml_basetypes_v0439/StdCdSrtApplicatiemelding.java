
package nl.uwv.schemas.uwvml.uwvml_basetypes_v0439;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for StdCdSrtApplicatiemelding.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <pre>
 * &lt;simpleType name="StdCdSrtApplicatiemelding"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;length value="1"/&gt;
 *     &lt;pattern value="[A-Z]*"/&gt;
 *     &lt;enumeration value="F"/&gt;
 *     &lt;enumeration value="M"/&gt;
 *     &lt;enumeration value="R"/&gt;
 *     &lt;enumeration value="W"/&gt;
 *     &lt;enumeration value="X"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "StdCdSrtApplicatiemelding", namespace = "http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439")
@XmlEnum
public enum StdCdSrtApplicatiemelding {


    /**
     * Fout
     * 
     */
    F,

    /**
     * Melding
     * 
     */
    M,

    /**
     * Resultaat
     * 
     */
    R,

    /**
     * Waarschuwing
     * 
     */
    W,

    /**
     * Fatale fout
     * 
     */
    X;

    public String value() {
        return name();
    }

    public static StdCdSrtApplicatiemelding fromValue(String v) {
        return valueOf(v);
    }

}
