
package nl.uwv.schemas.uwvml.uwvml_basetypes_v0439;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for StdCdSrtUitkeringsverhouding.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <pre>
 * &lt;simpleType name="StdCdSrtUitkeringsverhouding"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;maxLength value="7"/&gt;
 *     &lt;enumeration value="AAW"/&gt;
 *     &lt;enumeration value="AAW/WAO"/&gt;
 *     &lt;enumeration value="IVA"/&gt;
 *     &lt;enumeration value="NWJ"/&gt;
 *     &lt;enumeration value="REA"/&gt;
 *     &lt;enumeration value="WAJ"/&gt;
 *     &lt;enumeration value="WAO"/&gt;
 *     &lt;enumeration value="WAZ"/&gt;
 *     &lt;enumeration value="WGA"/&gt;
 *     &lt;enumeration value="WW"/&gt;
 *     &lt;enumeration value="ZW"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "StdCdSrtUitkeringsverhouding", namespace = "http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439")
@XmlEnum
public enum StdCdSrtUitkeringsverhouding {

    AAW("AAW"),
    @XmlEnumValue("AAW/WAO")
    AAW_WAO("AAW/WAO"),
    IVA("IVA"),
    NWJ("NWJ"),
    REA("REA"),
    WAJ("WAJ"),
    WAO("WAO"),
    WAZ("WAZ"),
    WGA("WGA"),
    WW("WW"),
    ZW("ZW");
    private final String value;

    StdCdSrtUitkeringsverhouding(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static StdCdSrtUitkeringsverhouding fromValue(String v) {
        for (StdCdSrtUitkeringsverhouding c: StdCdSrtUitkeringsverhouding.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
