
package nl.uwv.schemas.uwvml.uwvml_basetypes_v0439;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for StdHerkomstDoelgroepverklLkv.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <pre>
 * &lt;simpleType name="StdHerkomstDoelgroepverklLkv"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;maxLength value="24"/&gt;
 *     &lt;enumeration value="Gemeente"/&gt;
 *     &lt;enumeration value="Overgangsrecht"/&gt;
 *     &lt;enumeration value="UWV"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "StdHerkomstDoelgroepverklLkv", namespace = "http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439")
@XmlEnum
public enum StdHerkomstDoelgroepverklLkv {


    /**
     * Gemeente
     * 
     */
    @XmlEnumValue("Gemeente")
    GEMEENTE("Gemeente"),

    /**
     * Overgangsrecht
     * 
     */
    @XmlEnumValue("Overgangsrecht")
    OVERGANGSRECHT("Overgangsrecht"),

    /**
     * UWV
     * 
     */
    UWV("UWV");
    private final String value;

    StdHerkomstDoelgroepverklLkv(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static StdHerkomstDoelgroepverklLkv fromValue(String v) {
        for (StdHerkomstDoelgroepverklLkv c: StdHerkomstDoelgroepverklLkv.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
