
package nl.uwv.schemas.uwvml.uwvml_basetypes_v0439;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for StdCdVerzekeringssituatieZvw.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <pre>
 * &lt;simpleType name="StdCdVerzekeringssituatieZvw"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;length value="1"/&gt;
 *     &lt;pattern value="[A-Z]*"/&gt;
 *     &lt;enumeration value="A"/&gt;
 *     &lt;enumeration value="B"/&gt;
 *     &lt;enumeration value="C"/&gt;
 *     &lt;enumeration value="D"/&gt;
 *     &lt;enumeration value="E"/&gt;
 *     &lt;enumeration value="F"/&gt;
 *     &lt;enumeration value="G"/&gt;
 *     &lt;enumeration value="H"/&gt;
 *     &lt;enumeration value="I"/&gt;
 *     &lt;enumeration value="J"/&gt;
 *     &lt;enumeration value="K"/&gt;
 *     &lt;enumeration value="L"/&gt;
 *     &lt;enumeration value="M"/&gt;
 *     &lt;enumeration value="N"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "StdCdVerzekeringssituatieZvw", namespace = "http://schemas.uwv.nl/UwvML/UwvML-BaseTypes-v0439")
@XmlEnum
public enum StdCdVerzekeringssituatieZvw {


    /**
     * Niet verzekeringsplichtig, niet verzekerd voor Wlz
     * 
     */
    A,

    /**
     * Niet verzekeringsplichtig militair ambtenaar
     * 
     */
    B,

    /**
     * Wel verzekeringsplichtig, normaal tarief
     * 
     */
    C,

    /**
     * Wel verzekeringsplichtig, afwijkend tarief zeelieden
     * 
     */
    D,

    /**
     * Wel verzekeringsplichtig, verlaagd tarief
     * 
     */
    E,

    /**
     * Wel verzekeringsplichtig, meer tarieven toegepast
     * 
     */
    F,

    /**
     * Niet verzekeringsplichtig, buitenl. artiest/sporter
     * 
     */
    G,

    /**
     * Wel verzekeringsplichtig, geen tarief toegepast
     * 
     */
    H,

    /**
     * Niet verzekeringsplichtig, geen Wlz wel pseudobijdrage
     * 
     */
    I,

    /**
     * Wel verzekeringsplichtig, 0%-tarief kleinebanenregeling
     * 
     */
    J,

    /**
     * Verzekeringsplichtig, normaal tarief werkgeversheffing
     * 
     */
    K,

    /**
     * Verzekeringsplichtig 0%tarief werkgeversheffing(zeelui)
     * 
     */
    L,

    /**
     * Wel verzekeringsplichtig ingehouden bijdrage
     * 
     */
    M,

    /**
     * Verzekeringsplichtig meer tarieven wgrsheffing (K en L)
     * 
     */
    N;

    public String value() {
        return name();
    }

    public static StdCdVerzekeringssituatieZvw fromValue(String v) {
        return valueOf(v);
    }

}
