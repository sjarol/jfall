# PWS-COMMON

VAADIN 14 Common library voor Polis+ Webschermen
Sonar: [![Quality Gate Status](http://10.140.178.164:19000/api/project_badges/measure?project=nl.uwv.pws%3Apws-common&metric=alert_status)](http://10.140.178.58:19000/dashboard?id=nl.uwv.pws%3Apws-common)

Generieke bibliotheek met VAADIN 14 Componenten en herbruikbare oplossingen voor UWV Polis+ Webschermen
De bibliotheek is bedoeld voor het opzetten van Webapplicaties voor het Polis+ domein met een gemeenschappelijke look and feel.


## Getting Started

These instructions will get you a copy of the project up and running on your local machine for development and testing purposes. See deployment for notes on how to deploy the project on a live system.

### Prerequisites

What things you need to install the software and how to install them

```
Give examples
```

### Installing

A step by step series of examples that tell you how to get a development env running

Say what the step will be

```
Give the example
```

And repeat

```
until finished
```

End with an example of getting some data out of the system or using it for a little demo

## Running the tests

Explain how to run the automated tests for this system

### Break down into end to end tests

Explain what these tests test and why

```
Give an example
```

### And coding style tests

Explain what these tests test and why

```
Give an example
```

## Deployment

Add additional notes about how to deploy this on a live system

## Built With

* [Vaadin 14](https://vaadin.com/releases) - The web framework used
* [Maven](https://maven.apache.org/) - Dependency Management

## Versioning
* **1.2.1**
  * Vaadin versie opgehoogd van 14.6.2 naar 14.6.5
  * FIX: Het component AuthorizedButton is default niet geautoriseerd. Bij de functie enableCsvExport werd er een check
    gedaan of de button geautoriseerd is. Als dat niet het geval is, wordt de button niet aan de layout toegevoegd.
    Als het grid wordt gedefinieerd in de onAttachView, dan is de button altijd niet geautoriseerd en werkt de export
    functie niet ook al wordt de autorisatie daarna wel aangezet. De check op autorisatie is verplaatst naar de functie
    getGridExport(). Tevens is als extra feature opgenomen dat de download pas enabled wordt als het grid
    ook data bevat.

* **1.2.0**
  * Aanpassingen in PWS-COMMON
    * Vaadin versie opgehoogd van 14.4.9 naar 14.6.2
      LET OP: Als je Karibu testing gebruikt, moet je upgraden naar versie 1.3.0
    * Breaking change: LabelGrid aangepast.
      * De functie ``enableCsvExport()`` gebruikt nu een AuthorizedButton om af te dwingen dat de export alleen wordt
        enabled als er een autorisatie is gezet.
      * De functies ``setExportButtonEnabled()`` en ``setExportButtonVisible()`` zijn vervallen. Enable en visible
        kunnen dan direct op de export button.
      * Nieuwe static methode ``LabelGrid.createExportButton()`` om eenvoudig een AuthorizedButton aan te maken voor
        gebruik met ``enableCsvExort()`` functie (de autorisatie regelen via annotatie ``@AuthorizedComponent``).
    * Breaking change: UIUtils.showDialog(...) method weggehaald. Was verouderde en niet werkende code die niet mee had
      moeten komen met eerdere releases. Omdat deze niet correct werkte is de verwachting dat dit geen bestaande
      applicaties raakt.
    * Dialog component met meerdere tabbladen toegevoegd: MultiTabDialog
    * AuthorizedButton, implementeert HasAuthorization (de button click is disabled wanneer er geen autorisatie gezet is).
    * Fix initialisatie van de LomoLogService; initialiseer met de applicatie properties van de applicatie module zodat
      LOMO akties vanuit de PWS_COMMON (zoals login/logout) gelogd kunnen worden met LomoLogger van deze module.
    * Knoppen op BasicDialog en ConfirmationDialog stonden in andere volgorde hoe het Windows werkt en hoe het
      in de Vaadin 7 applicaties werkte. Dat willen we rechttrekken. Als we dat echter in-place zouden doen, dan breekt
      dat eventuele custom knoppen die zijn toegevoegd in de verschillende applicaties. Daarom zijn de betreffende
      dialogen nu deprecated gemaakt. Het wordt aanbevolen over te schakelen naar StyledDialog en ConfirmDialog waarop
      de knoppen in de juiste volgorde staan.
    * StyledNotification toegevoegd en extra functionaliteit opgenomen in UIUtil voor het openen van
      notificaties, inclusief permanente notificaties die pas verdwijnen als ze worden aangeklikt door de gebruiker.
    * SqlFilter is nu Serializable gemaakt.
    * Fix parsen flex attribuut: De waarde van het flex attribuut in .desc files werd alleen overgenomen als het
      attribuut als laatste attribuut in de veldomschrijving werd gedefinieerd.
    * De HasPrepareBinding interface heeft nu default method omdat veel custom componenten exact dezelfde
      minimalistische implementatie gebruikte. Nu hoeven alleen wat complexere componenten die bijvoorbeeld validators
      of converters gebruiken nog een eigen implementatie op te geven.


* **1.1.0**
  * Update dependencies
    * Vaadin versie opgehoogd van 14.4.7 naar 14.4.9
    * Commons-ws versie opgehoogd van 2.0.3 naar 2.0.5 om dubbele include van Oracle driver eruit te halen
    * Release-parent 2.0.4 voor JUnit 5 ondersteuning en om Jacoco test-coverage in Sonar te krijgen

  * Aanpassingen in PWS-COMMON
    * Breaking change: ViewFrame aangepast. Als je voorheen in je view een override had op de method
      ```protected void onAttach(AttachEvent attachEvent)```, dan moet je die code nu opnemen in de methode
      ```protected void onAttachView(AttachEvent attachEvent)```. De eerste methode is nu final gemaakt om te
      voorkomen dat je in je code per ongeluk vergeet de parent implementatie aan te roepen en daarmee effectief
      de authorisatie uit zet. Op de pagina's waarop je expliciet de autorisatie uit moet zetten, zoals
      de login-pagina bijvoorbeeld, kun je expliciet de methode ```protected void authorize()``` overriden met
      een lege implementatie.
    * @Generated annotatie toegevoegd voor code die je wilt uitsluiten van de Jacoco coverage scan
    * BasicDialoog uitgebreid met PdfHelp om context-afhankelijke help documenten toe te kunnen voegen
    * PdfHelp mag nu ook verwijzen naar een URL in plaats van uitsluitend lokale resource.
    * Dashboard toont nu 'tiles' voor alle menu items
    * Stamgegevens worden nu rechtstreeks uit de database opgehaald in plaast van via het PWSGUI package
    * AuthorizationType.TBL toegevoegd
    * Session Id van gebruiker wordt nu met SHA-512 gehasht in plaats van MD5
    * AbstractSqlFilter toegevoegd voor filters waarbij in de constructor de SQL en de parameters al bekend zijn
    * ComponentTraversal toegevoegd; util-class om eenvoudig door de boom van child-components te lopen of om een
      bepaald child-component op te zoeken
    * ColumnListDataProvider uitgebreid met add/removeCountRowsListener en add/removeFetchRowListener om zonder extra
      database-query te kunnen reageren op het tellen van het aantal rijen en het ophalen van (een subset van) de rijen
      die in een Grid worden weergegeven
    * QueryLogger toegevoegd die aanroepen naar de UwvQueryLogger uitvoert via een achtergrond thread zodat je tijdens
      het renderen alle regels kunt loggen zonder dat dat teveel impact heeft op de render performance
    * LocaleConstants toegevoegd, met Nederlandse Locale, DateFormSymbols en DatePickerI18n
    * NoResultsLabel toegevoegd, eenvoudig label dat getoond kan worden op een pagina als een zoek-aktie geen
      resultaten oplevert
    * ValidationLabel toegevoegd, eenvoudig label dat maximaal één van de globale foutmeldingen van een
      Vaadin Binder toont
    * FullVerticalLayout, eenvoudige VerticalLayout zonder margin en padding om eenvoudig elementen te groeperen zonder
      extra inspringing op het scherm
    * AtLeastOneValueValidator, validator die controleert of ten minste één van de aangeboden suppliers een non-null,
      non-empty waarde teruggeeft. Handig als je wilt dat de gebruiker minimaal 1 veld in een zoekbalk invult.
    * BsnNumber toegevoegd, waarin een tussentijds BSN nummer kan worden opgeslagen terwijl de gebruiker deze nog aan
      het intypen is (dus hoeft nog niet aan de 11-proef te voldoen)
    * BsnConverter toegevoegd die kan converteren tussen een String op het scherm en een BsnNumber
    * BsnValidator toegevoegd die een BsnNumber valideert, ook op 11-proef en de juiste fout-melding genereert indien
    * BsnSearchField toegevoegd waarin gebruiker een Bsn nummer kan opgeven waarop gezocht moet worden, voegt
      voorloopnullen toe waar nodig
    * PeildatumPicker waarmee een peildatum gekozen kon worden
    * Tooltip custom component dat een tekst-ballon tooltip toont wanneer je over een component hovert met de muis
    * InfoIcon info-icoon met een Tooltip

  * Code kwaliteit
    * .editorconfig file toegevoegd zodat iedereen die IntelliJ gebruikt automatisch dezelfde code style hanteert
    * Code geherformatteerd zodat deze consistent is door de hele module
    * Sonar violations opgelost
    * Diverse services beter testbaar gemaakt door minder statische referenties te gebruiken, setters toe te voegen voor
      internals zodat ze een mock waarde geïnjecteerd kunnen krijgen en code wat te herstructureren
    * Veel extra unit-tests geschreven om test-coverage te verhogen
    * JUnit test herschreven om gebruik te maken van een CSV resultset mock in plaats van een H2 database

  * Bugfixes:
    * Nette foutafhandeling als PdfHelp resource niet bestaat
    * Onbedoelde appbar reset na attach even
    * getPageTitle mag geen null als verstekwaarde geven
    * Gebruik SplitLayout voor content en details
    * Query voor component autorisatie aangepast zodat deze XMLAGG gebruikt in plaats van LISTAGG, zodat we niet langer
      SQL excepties krijgen op componenten met veel autorisaties


* **1.0.1**
  * Vaadin versie opgehoogd van 14.4.2 naar 14.4.7
  * Dependency com.vaadin:vaadin aangepast naar com.vaadin:vaadin-core zodat commerciële componenten uitgesloten zijn

## Authors

Team Webservice / Smurfen
