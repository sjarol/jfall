package nl.uwv.pws.backend.service;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.vaadin.flow.data.provider.Query;
import com.vaadin.flow.data.provider.QuerySortOrder;

import nl.uwv.pws.backend.dao.SqlFilter;
import nl.uwv.pws.backend.types.ColumnList;

class ColumnListDataProviderTest {

   private Long rows = -1L;

   @Test
   @DisplayName("Call to size() should invoke set DataSizeConsumer")
   void testSetDataSizeConsumer() {
      String[] columnNames = {"Column name"};
      Object[] columnValues = {"Value"};

      Query<ColumnList, SqlFilter> testQuery = new Query<>();
      TestColumnListService testColumnListService = new TestColumnListService();
      ColumnListDataProvider testProvider = new ColumnListDataProvider(testColumnListService);
      testProvider.addCountRowsListener(this::setRows);

      testProvider.size(testQuery);
      assertThat(rows).isEqualTo(0L);

      testColumnListService.addValue(columnNames, columnValues);
      testProvider.size(testQuery);
      assertThat(rows).isEqualTo(1L);

      testColumnListService.addValue(columnNames, columnValues);
      testProvider.size(testQuery);
      assertThat(rows).isEqualTo(2L);
   }

   private void setRows(final Long rows) {
      this.rows  = rows;
   }

   @SuppressWarnings("serial")
   static class TestColumnListService implements ColumnListService {
      List<ColumnList> values = new ArrayList<>();

      protected void clear() {
         values.clear();
      }

      protected void addValue(String[] columnNames, Object[] columnValues) {
         ColumnList columnList = new ColumnList(values.size() + 1, columnNames, columnValues);
         values.add(columnList);
      }

      @Override
      public List<ColumnList> fetchRows(SqlFilter sqlFilter, int limit, int offset, List<QuerySortOrder> sortOrders) {
         return values;
      }

      @Override
      public long countRows(SqlFilter sqlFilter) {
         return values.size();
      }
   }

}
