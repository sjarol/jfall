package nl.uwv.pws.ui.util.css;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;

import static org.assertj.core.api.Assertions.assertThat;

class OverflowTest {
   @DisplayName("Iedere Overflow heeft een value")
   @ParameterizedTest(name = "[{index}] Overflow: {0}")
   @EnumSource(Overflow.class)
   void test(final Overflow overflow) {
      assertThat(overflow.getValue()).isNotEmpty();
   }
}
