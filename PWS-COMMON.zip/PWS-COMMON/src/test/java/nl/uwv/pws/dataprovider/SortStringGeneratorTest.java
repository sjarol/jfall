package nl.uwv.pws.dataprovider;

import com.vaadin.flow.data.provider.QuerySortOrder;
import com.vaadin.flow.data.provider.SortDirection;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;

import static org.assertj.core.api.Assertions.assertThat;

class SortStringGeneratorTest {
   @Test
   @DisplayName("generate genereert de juiste ORDER BY SQL")
   void generate() {
      SortStringGenerator sortStringGenerator = new SortStringGenerator();

      assertThat(sortStringGenerator.generate(null)).isEqualTo("");
      assertThat(sortStringGenerator.generate(Collections.emptyList())).isEqualTo("");

      String result = sortStringGenerator.generate(Arrays.asList(
            new QuerySortOrder("NAAM", SortDirection.ASCENDING),
            new QuerySortOrder("AGE", SortDirection.DESCENDING)
      ));
      assertThat(result).isEqualTo(" order by NAAM asc, AGE desc");
   }

   @Test
   @DisplayName("generate().witNullsFirst() genereert de juiste ORDER BY SQL")
   void generateNullsFirst() {
      SortStringGenerator sortStringGenerator = new SortStringGenerator().withNullsFirst();

      assertThat(sortStringGenerator.generate(null)).isEqualTo("");
      assertThat(sortStringGenerator.generate(Collections.emptyList())).isEqualTo("");

      String result = sortStringGenerator.generate(Arrays.asList(
            new QuerySortOrder("NAAM", SortDirection.ASCENDING),
            new QuerySortOrder("AGE", SortDirection.DESCENDING)
      ));
      assertThat(result).isEqualTo(" order by NAAM asc nulls first, AGE desc nulls first");
   }

   @Test
   @DisplayName("generate().witNullsLast() genereert de juiste ORDER BY SQL")
   void generateNullsLast() {
      SortStringGenerator sortStringGenerator = new SortStringGenerator().withNullsLast();

      assertThat(sortStringGenerator.generate(null)).isEqualTo("");
      assertThat(sortStringGenerator.generate(Collections.emptyList())).isEqualTo("");

      String result = sortStringGenerator.generate(Arrays.asList(
            new QuerySortOrder("NAAM", SortDirection.ASCENDING),
            new QuerySortOrder("AGE", SortDirection.DESCENDING)
      ));
      assertThat(result).isEqualTo(" order by NAAM asc nulls last, AGE desc nulls last");
   }

   @Test
   @DisplayName("generate().withNullsReversed() genereert de juiste ORDER BY SQL")
   void generateNullsReversed() {
      SortStringGenerator sortStringGenerator = new SortStringGenerator().withNullsReversed();

      assertThat(sortStringGenerator.generate(null)).isEqualTo("");
      assertThat(sortStringGenerator.generate(Collections.emptyList())).isEqualTo("");

      String result = sortStringGenerator.generate(Arrays.asList(
            new QuerySortOrder("NAAM", SortDirection.ASCENDING),
            new QuerySortOrder("AGE", SortDirection.DESCENDING)
      ));
      assertThat(result).isEqualTo(" order by NAAM asc nulls first, AGE desc nulls last");
   }
}
