package nl.uwv.pws.ui.layout;

import com.vaadin.flow.component.html.Label;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class FullVerticalLayoutTest {
   @Test
   @DisplayName("No-args constructor zet padding en margin uit")
   void testDefaultConstructor() {
      FullVerticalLayout fixture = new FullVerticalLayout();
      assertThat(fixture.isPadding()).isFalse();
      assertThat(fixture.isMargin()).isFalse();
   }

   @Test
   @DisplayName("Var-args constructor zet padding en margin uit")
   void testArgumentConstructor() {
      FullVerticalLayout fixture = new FullVerticalLayout(new Label("Hello World"));
      assertThat(fixture.isPadding()).isFalse();
      assertThat(fixture.isMargin()).isFalse();
   }
}
