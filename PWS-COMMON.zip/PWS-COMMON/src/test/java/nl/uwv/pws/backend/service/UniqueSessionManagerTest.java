package nl.uwv.pws.backend.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.codec.binary.StringUtils;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;

import com.vaadin.flow.server.VaadinService;
import com.vaadin.flow.server.VaadinServletRequest;
import com.vaadin.flow.server.WrappedSession;

class UniqueSessionManagerTest {

   private static final String SESSION_ID = "flZnbygKP3YOSzFeq-3_-bjFTppKuB4rKgTo76ZX65N0qr5z89Mn";
   private static final String SESSION_ID53 = "flZnbygKP3YOSzFeq-3_-bjFTppKuB4rKgTo76ZX65N0qr5z89MnP";
   private static final String SESSION_ID55 = "flZnbygKP3YOSzFeq-3_-bjFTppKuB4rKgTo76ZX65N0qr5z89MnP22";
   private static final String SESSION_ID_HASH = UniqueSessionManager.hashSessionId(SESSION_ID);
   private static final String DUMMY = "Dummy";
   private static final String USER = "TST007";

   private static TestSessionService testSessionService = null;
   private static WrappedSession mockSession;
   private static VaadinServletRequest mockRequest;
   private UniqueSessionManager testManager = UniqueSessionManager.get();
   private static MockedStatic<SessionService> mockSessionService;
   private static MockedStatic<VaadinService> theMockService;
   
   @Test
   @DisplayName("get should return the same instance of UniqueSessionManager")
   void testGet() {
      assertThat(testManager).isNotNull().isExactlyInstanceOf(UniqueSessionManager.class)
            .isSameAs(UniqueSessionManager.get());
   }

   @Test
   @DisplayName("insertCurrentUserSession should add sessionId to SessionService")
   void testInsertCurrentUserSession() {
      assertThat(testSessionService.getSessionId()).isNull();
      
      testManager.insertCurrentUserSession(USER);
      assertThat(testSessionService.getUsername()).isEqualTo(USER);
      assertThat(testSessionService.getSessionId()).isEqualTo(SESSION_ID_HASH).hasSizeLessThan(97);
   }

   @Test
   @DisplayName("insertUserLoginSession should add sessionId to login map")
   void testInsertUserLoginSession() {
      testManager.removeUserLoginSession(USER);
      testManager.removeUserLoginSession(DUMMY);
      assertThat(testManager.isLoginSession(USER)).isFalse();

      testManager.insertUserLoginSession(USER);
      assertThat(testManager.isLoginSession(USER)).isTrue();
      assertThat(testManager.isLoginSession(DUMMY)).isFalse();
   }

   @Test
   @DisplayName("removeUserSession should remove user from SessionService")
   void testRemoveUserSession() {
      assertThat(testSessionService.getRemovedUsername()).isNull();

      testManager.removeUserSession(USER);
      assertThat(testSessionService.getRemovedUsername()).isEqualTo(USER);
      assertThat(testSessionService.getRemovedSessionId()).isNull();
   }

   @Test
   @DisplayName("removeCurrentUserSession should remove sessionId from login map")
   void testRemoveCurrentUserSession() {
      assertThat(testSessionService.getRemovedUsername()).isNull();

      testManager.removeCurrentUserSession(USER);
      assertThat(testSessionService.getRemovedUsername()).isEqualTo(USER);
      assertThat(testSessionService.getRemovedSessionId()).isEqualTo(SESSION_ID_HASH);
   }

   @Test
   @DisplayName("removeUserLoginSession should remove sessionId from SessionService")
   void testRemoveUserLoginSession() {
      testManager.insertUserLoginSession(USER);
      testManager.insertUserLoginSession(DUMMY);
      assertThat(testManager.isLoginSession(USER)).isTrue();
      assertThat(testManager.isLoginSession(DUMMY)).isTrue();

      testManager.removeUserLoginSession(USER);
      assertThat(testManager.isLoginSession(USER)).isFalse();
      assertThat(testManager.isLoginSession(DUMMY)).isTrue();
   }

   @Test
   @DisplayName("isActiveSession should return only true if sessionId is inserted")
   void testIsActiveSession() {
      testManager.removeCurrentUserSession(USER);
      testManager.removeCurrentUserSession(DUMMY);
      assertThat(testManager.isActiveSession(USER)).isFalse();
      assertThat(testManager.isActiveSession(DUMMY)).isFalse();
      
      testManager.insertCurrentUserSession(USER);
      assertThat(testManager.isActiveSession(USER)).isTrue();
      assertThat(testManager.isActiveSession(DUMMY)).isFalse();

      testManager.insertCurrentUserSession(DUMMY);
      assertThat(testManager.isActiveSession(USER)).isTrue();
      assertThat(testManager.isActiveSession(DUMMY)).isTrue();
   }

   @Test
   @DisplayName("hasActiveSession should return only true if a sessionId was inserted")
   void testHasActiveSession() {
      testManager.removeCurrentUserSession(USER);
      testManager.removeCurrentUserSession(DUMMY);
      assertThat(testManager.hasActiveSession(USER)).isFalse();
      assertThat(testManager.hasActiveSession(DUMMY)).isFalse();
      
      testManager.insertCurrentUserSession(USER);
      assertThat(testManager.hasActiveSession(USER)).isTrue();
      assertThat(testManager.hasActiveSession(DUMMY)).isFalse();

      testManager.insertCurrentUserSession(DUMMY);
      assertThat(testManager.hasActiveSession(USER)).isTrue();
      assertThat(testManager.hasActiveSession(DUMMY)).isTrue();
      
      testManager.removeCurrentUserSession(USER);
      testSessionService.insertUserSession(USER, SESSION_ID_HASH);
      assertThat(testManager.hasActiveSession(USER)).isTrue();
   }

   @Test
   @DisplayName("getCurrentSessionId should only consider first 52 char (weblogic default)")
   void testGetCurrentSessionId() {
      mockSession = mock(WrappedSession.class);
      when(mockRequest.getWrappedSession()).thenReturn(mockSession);
      when(mockSession.getId()).thenReturn(SESSION_ID).thenReturn(SESSION_ID53).thenReturn(SESSION_ID55);
      
      assertThat(UniqueSessionManager.getCurrentSessionId()).isEqualTo(SESSION_ID_HASH);
      assertThat(UniqueSessionManager.getCurrentSessionId()).isEqualTo(SESSION_ID_HASH);
      assertThat(UniqueSessionManager.getCurrentSessionId()).isEqualTo(SESSION_ID_HASH);
   }
   
   @BeforeEach
   protected void initMocks() {
      if (testSessionService == null) {
         testSessionService = new TestSessionService();
         mockSessionService.when(SessionService::get).thenReturn(testSessionService);
      } else {
         testSessionService.clear();
      }
   }

   private static VaadinServletRequest getMockRequest() {
      mockRequest = mock(VaadinServletRequest.class);
      mockSession = mock(WrappedSession.class);
      when(mockRequest.getServerName()).thenReturn("nl.uwv.test");
      when(mockRequest.getScheme()).thenReturn("https");
      when(mockRequest.getServerPort()).thenReturn(8080);
      when(mockRequest.getWrappedSession()).thenReturn(mockSession);
      when(mockSession.getId()).thenReturn(SESSION_ID);

      return mockRequest;
   }
   
   @BeforeAll
   static void initStaticMocks() {
      mockSessionService = mockStatic(SessionService.class);
      mockSessionService.when(SessionService::getDSName).thenReturn("dummy");

      VaadinServletRequest mockReqest = getMockRequest();
      theMockService = mockStatic(VaadinService.class);
      theMockService.when(VaadinService::getCurrentRequest).thenReturn(mockReqest);
   }

   @AfterAll
   static void clearStaticMocks() {
      if (mockSessionService != null) {
         mockSessionService.closeOnDemand();
      }
      if (theMockService != null) {
         theMockService.closeOnDemand();
      }
   }


   @SuppressWarnings("serial")
   class TestSessionService extends SessionService {
      private String username;
      private String sessionId;
      private String removedUsername;
      private String removedSessionId;
      private Map<String, String> sessionMap = new HashMap<String, String>();
      
      TestSessionService() {
         // Empty constructor
      }
      
      public void clear() {
         username = null;
         sessionId = null;
         removedUsername = null;
         removedSessionId = null;
         sessionMap.clear();
      }
      
      @Override
      public boolean insertUserSession(String username, String sessionId) {
         setUsername(username);
         setSessionId(sessionId);
         sessionMap.put(username, sessionId);
         
         return true;
      }
      
      @Override
      public void removeUserSession(final String username) {
         setRemovedUsername(username);
         sessionMap.remove(username);
      }

      @Override
      public void removeUserSession(final String username, final String sessionId) {
         setRemovedUsername(username);
         setRemovedSessionId(sessionId);
         if (StringUtils.equals(sessionMap.get(username), sessionId)) {
            sessionMap.remove(username);
         }
      }

      public String getUserSession(final String userId) {
         return sessionMap.get(userId);
      }
      
      public String getUsername() {
         return username;
      }

      public void setUsername(String username) {
         this.username = username;
      }

      public String getSessionId() {
         return sessionId;
      }

      public void setSessionId(String sessionId) {
         this.sessionId = sessionId;
      }

      public String getRemovedUsername() {
         return removedUsername;
      }

      public void setRemovedUsername(String removedUsername) {
         this.removedUsername = removedUsername;
      }

      public String getRemovedSessionId() {
         return removedSessionId;
      }

      public void setRemovedSessionId(String removedSessionId) {
         this.removedSessionId = removedSessionId;
      }
   }
}
