package nl.uwv.pws.ui.components;

import com.vaadin.flow.data.binder.Binder;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

class ValidationLabelTest {
   @Test
   @DisplayName("Als een ValidationLabel wordt aangemaakt, heeft deze een id, een text en is initieel onzichtbaar")
   @SuppressWarnings("unchecked")
   void testConstruction() {
      Binder<String> binder = mock(Binder.class);
      ValidationLabel fixture = new ValidationLabel(binder);
      assertThat(fixture.getText()).isEqualTo("");
      assertThat(fixture.getId()).hasValue("validation-message");
      assertThat(fixture.isVisible()).isFalse();

      verify(binder).setStatusLabel(fixture);
   }

   @Test
   @DisplayName("Zetten van validatie melding maakt label zichtbaar en schonen van melding maakt label onzichtbaar")
   @SuppressWarnings("unchecked")
   void whenSetTextIsCalledVisibilityGetsUpdated() {
      Binder<String> binder = mock(Binder.class);
      ValidationLabel fixture = new ValidationLabel(binder);
      assertThat(fixture.isVisible()).isFalse();

      fixture.setText("A validation error occurred");
      assertThat(fixture.isVisible()).isTrue();

      fixture.setText("");
      assertThat(fixture.isVisible()).isFalse();

      fixture.setText("A validation error occurred");
      assertThat(fixture.isVisible()).isTrue();

      fixture.setText(null);
      assertThat(fixture.isVisible()).isFalse();
   }
}
