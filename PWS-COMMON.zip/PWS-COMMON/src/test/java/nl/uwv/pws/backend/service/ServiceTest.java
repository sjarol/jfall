package nl.uwv.pws.backend.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatExceptionOfType;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class ServiceTest {

   private static final String DSNAME = "nl.uwv.testDS";
   private static final String PREFIX = "java:/comp/env/";

   @Test
   @DisplayName("Calling getDataSource should return datasource from Context")
   void testGetDataSource() throws NamingException {
      TestService service = new TestService(DSNAME);
      DataSource testDS = mock(DataSource.class);
      when(service.getInitialContext().lookup(DSNAME)).thenReturn(testDS);
      
      assertThat(service.getDataSource()).isSameAs(testDS);
   }

   @Test
   @DisplayName("Calling getDataSource should return datasource from Context using the prefix " + PREFIX)
   void testGetDataSourceUsingPrefix() throws NamingException {
      TestService service = new TestService(DSNAME);
      DataSource testDS = mock(DataSource.class);
      when(service.getInitialContext().lookup(DSNAME )).thenThrow(new NamingException("Not found."));
      when(service.getInitialContext().lookup(PREFIX + DSNAME)).thenReturn(testDS);
      
      assertThat(service.getDataSource()).isSameAs(testDS);
   }

   @Test
   @DisplayName("Calling getDataSource should throw an NamingException when no datasource or an null value is found")
   void testGetDataSourceThrowsException() throws NamingException {
      TestService service = new TestService(DSNAME);
      
      assertThatExceptionOfType(NamingException.class).isThrownBy(service::getDataSource).withMessageStartingWith("Datasource not found :");      
      String errMsg = "Not found.";
      when(service.getInitialContext().lookup(DSNAME )).thenThrow(new NamingException(errMsg));
      when(service.getInitialContext().lookup(PREFIX + DSNAME)).thenThrow(new NamingException("Not found2."));
      
      assertThatExceptionOfType(NamingException.class).isThrownBy(service::getDataSource).withMessageStartingWith(errMsg);      
   }
   
   @SuppressWarnings("serial")
   class TestService extends AbstractService {
      InitialContext mockContext = mock(InitialContext.class);

      public TestService(String dsName) {
         super(dsName);
      }

      @Override
      protected Context getInitialContext() throws NamingException {
         return mockContext;
      }

   }
}
