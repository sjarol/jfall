package nl.uwv.pws.backend.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.NamingException;
import javax.sql.DataSource;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import nl.uwv.pws.common.testutils.CsvMockResultSetFactory;

class StamgegevensServiceTest extends AbstractServiceTest<StamgegevensService> {
   private static final IllegalStateException ILLEGAL_STATE_EXCEPTION = new IllegalStateException("Waarde zou uit de cache moeten komen?");
   private static final String EXPECTED_CAT_QUERY =
         "SELECT cat.NAAM, cat.DATUMAANVANG, cat.DATUMEINDE FROM REF_STAMGEGEVENS_CAT cat WHERE cat.CAT_CD = ?";
   private static final String EXPECTED_REF_QUERY =
         "SELECT ref.OMSCHRIJVING, ref.DATUMAANVANG, ref.DATUMEINDE FROM REF_STAMGEGEVENS ref WHERE ref.CAT_CD = ? AND ref.CODE = ? ORDER BY ref.DATUMAANVANG";

   @Test
   @DisplayName("Calling getDescription with 'RGB' returns cat name as description")
   void testGetCatDescription() throws SQLException {
      setupCatTabelMocks();
      
      assertThat(getFixture().getDescription("RGD")).isEqualTo("Gebruik personen of bestelauto");
   }

   @Test
   @DisplayName("Calling getDescription with 'RGB' returns cat name as description from cache")
   void testGetCatDescriptionFromCache() throws SQLException {
      setupCatTabelMocks();

      // Lees waarde uit database in cache
      getFixture().getDescription("RGD");
      when(getConnectionMock().prepareStatement(EXPECTED_CAT_QUERY)).thenThrow(ILLEGAL_STATE_EXCEPTION);
      
      assertThat(getFixture().getDescription("RGD")).isEqualTo("Gebruik personen of bestelauto");
   }

   @Test
   @DisplayName("Calling getDescription with 'AAP' returns description unknown")
   void testGetUnknownCatDescription() throws SQLException {
      setupCatTabelEmptyMocks();

      assertThat(getFixture().getDescription("AAP")).isEqualTo("Onbekende naam voor cat 'AAP'");
   }

   @Test
   @DisplayName("Calling getDescription with 'RGB', '1' returns code description")
   void testgetDescription() throws SQLException {
      setupRefTabelMocks();
      
      assertThat(getFixture().getDescription("RGD", "1")).isEqualTo("Geen auto ter beschikking gesteld* Beëindigd per 20140101\n"
            + "Afspraak via werkgever met Belastingdienst");
   }

   @Test
   @DisplayName("Calling getDescription with 'RGB', '1' returns code description from cache")
   void testgetDescriptionFromCache() throws SQLException {
      setupRefTabelMocks();
      
      // Lees waarde in cache
      getFixture().getDescription("RGD", "1");
      when(getConnectionMock().prepareStatement(EXPECTED_REF_QUERY)).thenThrow(ILLEGAL_STATE_EXCEPTION);
      
      assertThat(getFixture().getDescription("RGD", "1")).isEqualTo("Geen auto ter beschikking gesteld* Beëindigd per 20140101\n"
            + "Afspraak via werkgever met Belastingdienst");
   }

   @Test
   @DisplayName("Calling getDescription with 'RGB', '2' returns unknown description")
   void testgetDescriptionUnknown() throws SQLException {
      setupRefTabelEmptyMocks();
      
      assertThat(getFixture().getDescription("RGD", "2")).isEqualTo("Onbekende omschrijving voor cat RGD, code 2");
   }


   private void setupCatTabelMocks() throws SQLException {
      setupCatTabelMocks(false);
   }

   private void setupCatTabelEmptyMocks() throws SQLException {
      setupCatTabelMocks(true);
   }

   private void setupCatTabelMocks(boolean returnEmpty) throws SQLException {
      // Setup mocks
      CsvMockResultSetFactory rsFactory = super.createMockResultSetFactory("/data/cat_rgbDataSet.csv");
      ResultSet mockResultSet = rsFactory.getMockResultSet();
      when(getDataSourceMock().getConnection()).thenReturn(getConnectionMock());
      when(getConnectionMock().prepareStatement(EXPECTED_CAT_QUERY)).thenReturn(getPrepStatementMock());
      when(getPrepStatementMock().executeQuery()).thenReturn(mockResultSet);
      
      if (returnEmpty) {
         when(mockResultSet.next()).thenReturn(false);
      }
   }
   
   
   private void setupRefTabelMocks() throws SQLException {
      setupRefTabelMocks(false);
   }

   private void setupRefTabelEmptyMocks() throws SQLException {
      setupRefTabelMocks(true);
   }

   private void setupRefTabelMocks(boolean returnEmpty) throws SQLException {
      // Setup mocks
      CsvMockResultSetFactory rsFactory = super.createMockResultSetFactory("/data/ref_rgb_1DataSet.csv");
      ResultSet mockResultSet = rsFactory.getMockResultSet();
      when(getDataSourceMock().getConnection()).thenReturn(getConnectionMock());
      when(getConnectionMock().prepareStatement(EXPECTED_REF_QUERY)).thenReturn(getPrepStatementMock());
      when(getPrepStatementMock().executeQuery()).thenReturn(mockResultSet);

      if (returnEmpty) {
         when(mockResultSet.next()).thenReturn(false);
      }
   }

   @SuppressWarnings("serial")
   @Override
   protected StamgegevensService createService(DataSource dataSourceMock) {
      return new StamgegevensService("DS_NAME"){
         @Override
         protected DataSource getDataSource() throws NamingException {
            return dataSourceMock;
         }
      };
   }
}
