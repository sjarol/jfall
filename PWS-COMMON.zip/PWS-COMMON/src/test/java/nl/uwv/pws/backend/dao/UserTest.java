package nl.uwv.pws.backend.dao;

import com.openpojo.reflection.PojoClass;
import com.openpojo.reflection.impl.PojoClassFactory;
import com.openpojo.validation.ValidatorBuilder;
import com.openpojo.validation.test.impl.GetterTester;
import com.openpojo.validation.test.impl.SetterTester;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.server.VaadinRequest;
import com.vaadin.flow.server.VaadinResponse;
import com.vaadin.flow.server.VaadinService;
import com.vaadin.flow.server.VaadinSession;
import com.vaadin.flow.server.WrappedSession;

import nl.uwv.pws.backend.lomo.LomoLogMessage;
import nl.uwv.pws.backend.lomo.LomoLogMessage.LomoResult;
import nl.uwv.pws.backend.lomo.LomoLogger;
import nl.uwv.pws.backend.service.LomoLogService;
import nl.uwv.pws.backend.service.LomoLogServiceIfc;
import nl.uwv.pws.backend.service.UniqueSessionManager;
import nl.uwv.pws.backend.service.UserService;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatNoException;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponseWrapper;
import javax.sql.DataSource;

class UserTest {

   @Test
   @DisplayName("Als setters worden aangeroepen leveren getters de juiste waarden terug")
   void gettersAndSetters() {
      // Test getters and setters
      PojoClass pojoclass = PojoClassFactory.getPojoClass(User.class);
      ValidatorBuilder.create()
            .with(new GetterTester())
            .with(new SetterTester())
            .build()
            .validate(pojoclass);
   }

   @Test
   @DisplayName("When createUser method is called, the username and roles get set properly")
   void testCreate() {
      User user = User.createUser("Test User", "ADMIN", "EDITOR");
      assertThat(user).isNotNull();
      assertThat(user.getUsername()).isEqualTo("Test User");
      assertThat(user.getRoles()).containsExactly("ADMIN", "EDITOR");
      assertThat(user.toString()).isEqualTo("User [username=Test User, roles=[ADMIN, EDITOR]]");
   }

   @Test
   @DisplayName("When logout is called should be logged out")
   void testLogout() {
      TestLomoLogService testLomoService = new TestLomoLogService();
      User user = User.createUser("Test User", "ADMIN", "EDITOR");
      UserService mockUserService = mock(UserService.class);
      UniqueSessionManager mockSessionManager = mock(UniqueSessionManager.class);
      VaadinSession mockVaadinSession = mock(VaadinSession.class);
      VaadinRequest mockVaadinRequest = mock(VaadinRequest.class);
      Cookie[] cookies = { new Cookie("Test", "TestValue") };
      TestResponse mockResponse = mock(TestResponse.class);
      WrappedSession wrappedSession = mock(WrappedSession.class);
      try ( MockedStatic<UserService> mockStaticUserService = mockStatic(UserService.class);
            MockedStatic<LomoLogService> mockLomoLogService = mockStatic(LomoLogService.class);
            MockedStatic<UniqueSessionManager> mockStaticSessionManager = mockStatic(UniqueSessionManager.class);
            MockedStatic<VaadinService> mockVaadinService = mockStatic(VaadinService.class);
            MockedStatic<VaadinSession> mockStaticVaadinSession = mockStatic(VaadinSession.class);
            MockedStatic<VaadinResponse> mockVaadinResponse = mockStatic(VaadinResponse.class);
            ) {
         mockLomoLogService.when(LomoLogService::getInstance).thenReturn(testLomoService);
         mockStaticUserService.when(UserService::getCurrentUser).thenReturn(user);
         mockStaticSessionManager.when(UniqueSessionManager::get).thenReturn(mockSessionManager);
         mockVaadinService.when(VaadinService::getCurrentRequest).thenReturn(mockVaadinRequest);
         when(mockVaadinRequest.getCookies()).thenReturn(cookies);
         mockVaadinResponse.when(VaadinResponse::getCurrent).thenReturn(mockResponse);         
         
         assertThatNoException().isThrownBy(() -> User.logout());

         verify(mockSessionManager, Mockito.times(1)).removeUserSession(user.getUsername());
         assertThat(cookies[0]).isNotNull();
         assertThat(cookies[0].getName()).isEqualTo("Test");
         assertThat(cookies[0].getMaxAge()).isEqualTo(0);
         assertThat(cookies[0].getValue()).isEqualTo("-");
         assertThat(cookies[0].getPath()).isEqualTo("/");
         verify(mockResponse, Mockito.times(1)).addCookie(cookies[0]);
         // No UserService.get() check message for NullPointerException
         assertThat(testLomoService.getApplicatieFunctie()).isEqualTo("Logout Polis+");
         assertThat(testLomoService.getMessage()).isNotNull();
         assertThat(testLomoService.getMessage().getResult()).isEqualTo(LomoResult.ERROR);
         assertThat(testLomoService.getMessage().getMessage()).isEqualTo("Foutmelding java.lang.NullPointerException: null");

         mockStaticUserService.when(UserService::get).thenReturn(mockUserService);
         mockStaticVaadinSession.when(VaadinSession::getCurrent).thenReturn(mockVaadinSession);
         when(mockVaadinRequest.getWrappedSession()).thenReturn(wrappedSession);
         assertThatNoException().isThrownBy(() -> User.logout());
         
         // check message for Succes
         assertThat(testLomoService.getApplicatieFunctie()).isEqualTo("Logout Polis+");
         assertThat(testLomoService.getMessage()).isNotNull();
         assertThat(testLomoService.getMessage().getResult()).isEqualTo(LomoResult.OK);
         assertThat(testLomoService.getMessage().getMessage()).isEqualTo("User is uitgelogd");
         verify(mockUserService, Mockito.times(1)).logout(user.getUsername());
         verify(mockSessionManager, Mockito.times(1)).removeCurrentUserSession(user.getUsername());
         verify(wrappedSession, Mockito.times(1)).invalidate();
      }
   }

   @Test
   @DisplayName("When logout is called with keepCurrentSession, the user should be logged out but session should remain active")
   void testLogoutWithKeepCurrentSession() {
      TestLomoLogService testLomoService = new TestLomoLogService();
      User user = User.createUser("Test User", "ADMIN", "EDITOR");
      UserService mockUserService = mock(UserService.class);
      UniqueSessionManager mockSessionManager = mock(UniqueSessionManager.class);
      VaadinRequest mockVaadinRequest = mock(VaadinRequest.class);
      Cookie[] cookies = { new Cookie("Test", "TestValue") };
      TestResponse mockResponse = mock(TestResponse.class);
      cookies[0].setPath("/test.uwv.nl");
      try ( MockedStatic<UserService> mockStaticUserService = mockStatic(UserService.class);
            MockedStatic<LomoLogService> mockLomoLogService = mockStatic(LomoLogService.class);
            MockedStatic<UniqueSessionManager> mockStaticSessionManager = mockStatic(UniqueSessionManager.class);
            MockedStatic<VaadinService> mockVaadinService = mockStatic(VaadinService.class);
            MockedStatic<VaadinResponse> mockVaadinResponse = mockStatic(VaadinResponse.class);
            ) {
         mockLomoLogService.when(LomoLogService::getInstance).thenReturn(testLomoService);
         mockStaticUserService.when(UserService::getCurrentUser).thenReturn(user);
         mockStaticSessionManager.when(UniqueSessionManager::get).thenReturn(mockSessionManager);
         mockVaadinService.when(VaadinService::getCurrentRequest).thenReturn(mockVaadinRequest);
         when(mockVaadinRequest.getCookies()).thenReturn(cookies);
         mockVaadinResponse.when(VaadinResponse::getCurrent).thenReturn(mockResponse);         
         mockStaticUserService.when(UserService::get).thenReturn(mockUserService);

         assertThatNoException().isThrownBy(() -> User.logout(user.getUsername(), true));
         assertThat(cookies[0]).isNotNull();
         assertThat(cookies[0].getName()).isEqualTo("Test");
         assertThat(cookies[0].getMaxAge()).isEqualTo(-1);
         assertThat(cookies[0].getValue()).isEqualTo("TestValue");
         assertThat(cookies[0].getPath()).isEqualTo("/test.uwv.nl");
         verify(mockResponse, Mockito.times(0)).addCookie(cookies[0]);
         
         // check message for Succes
         assertThat(testLomoService.getApplicatieFunctie()).isEqualTo("Logout Polis+");
         assertThat(testLomoService.getMessage()).isNotNull();
         assertThat(testLomoService.getMessage().getResult()).isEqualTo(LomoResult.OK);
         assertThat(testLomoService.getMessage().getMessage()).isEqualTo("User is uitgelogd");
         verify(mockUserService, Mockito.times(1)).logout(user.getUsername());
         verify(mockSessionManager, Mockito.times(1)).removeUserSession(user.getUsername());
         
         assertThatNoException().isThrownBy(() -> User.logout(null, true));
      }
   }

   @Test
   @DisplayName("When logout method is called and user is not logged in, it should not fail")
   void testLogoutWithNoLogin() {
      try (MockedStatic<UserService> mockAuthorizationService = mockStatic(UserService.class)) {
         mockAuthorizationService.when(UserService::getCurrentUser).thenReturn(null);
         assertThatNoException().isThrownBy(() -> User.logout());
      }
   }
   
   @Test
   @DisplayName("When closeVaadinUI is called the UIs should be closed")
   void testCloseVaadinUI() {
      UI mockCurrentUI = mock(UI.class);
      UI mockOtherUI = mock(UI.class);
      VaadinSession mockCurrentSession = mock (VaadinSession.class);
      List<UI> myUIs = new ArrayList<>();
      myUIs.add(mockOtherUI);
      myUIs.add(mockCurrentUI);
      
      try (MockedStatic<UI> mockStaticUI = mockStatic(UI.class)) {
         mockStaticUI.when(UI::getCurrent).thenReturn(mockCurrentUI);

         assertThatNoException().isThrownBy(() -> User.closeVaadinUI(true));
         verify(mockCurrentUI, Mockito.times(0)).close();
         verify(mockOtherUI, Mockito.times(0)).close();

         when(mockCurrentUI.getSession()).thenReturn(mockCurrentSession);
         when(mockCurrentSession.getUIs()).thenReturn(myUIs);
         
         assertThatNoException().isThrownBy(() -> User.closeVaadinUI(true));
         verify(mockCurrentUI, Mockito.times(0)).close();
         verify(mockOtherUI, Mockito.times(1)).close();
         
         assertThatNoException().isThrownBy(() -> User.closeVaadinUI(false));
         verify(mockCurrentUI, Mockito.times(1)).close();
         verify(mockOtherUI, Mockito.times(2)).close();
      }
   }
   
   class TestLomoLogService implements LomoLogServiceIfc {
      private String programmaId;
      private String applicatieFunctie;
      private LomoLogMessage message;

      public String getProgrammaId() {
         return programmaId;
      }

      public String getApplicatieFunctie() {
         return applicatieFunctie;
      }

      public LomoLogMessage getMessage() {
         return message;
      }

      @Override
      public DataSource getLomoDataSource() {
         return null;
      }

      @Override
      public void addLomoLogger(String programId, LomoLogger lomoLogger) {
         // Empty
      }

      @Override
      public void addLomoLog(String programmaId, String applicatieFunctie, LomoLogMessage message) {
         this.programmaId = programmaId;
         this.applicatieFunctie = applicatieFunctie;
         this.message = message;
      }
   }
   
   class TestResponse extends HttpServletResponseWrapper implements HttpServletResponse, VaadinResponse {

      public TestResponse(HttpServletResponse response) {
         super(response);
      }

      @Override
      public void setCacheTime(long milliseconds) {
         // empty
      }

      @Override
      public VaadinService getService() {
         return null;
      }
      
   }
}
