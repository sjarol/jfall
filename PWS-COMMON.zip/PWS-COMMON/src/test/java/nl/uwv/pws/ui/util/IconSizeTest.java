package nl.uwv.pws.ui.util;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;

import static org.assertj.core.api.Assertions.assertThat;

class IconSizeTest {
   @DisplayName("Iedere IconSize heeft een className")
   @ParameterizedTest(name = "[{index}] IconSize: {0}")
   @EnumSource(IconSize.class)
   void test(final IconSize iconSize) {
      assertThat(iconSize.getClassName()).isNotEmpty();
   }
}
