package nl.uwv.pws.ui.views;

import com.vaadin.flow.component.AttachEvent;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;
import nl.uwv.pws.backend.dao.MenuPage;
import nl.uwv.pws.ui.MainLayout;
import nl.uwv.pws.ui.components.navigation.bar.AppBar;
import nl.uwv.pws.ui.util.ComponentAuthorizationHelper;
import nl.uwv.pws.ui.util.ViewAuthorizationHelper;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;

import java.lang.reflect.Field;
import java.util.concurrent.atomic.AtomicBoolean;

import static nl.uwv.pws.ui.util.ComponentTraversal.firstDirectChildWithClassName;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatIllegalStateException;
import static org.mockito.Mockito.*;
import static org.springframework.util.ReflectionUtils.*;

class ViewFrameTest {
   private static final String CLASS_HEADER = "view-frame__header";
   private static final String CLASS_CONTENT = "view-frame__content";
   private static final String CLASS_FOOTER = "view-frame__footer";

   @Test
   @DisplayName("De no-args constructor initialiseert het ViewFrame voor een standaard view")
   void constructViewFrame() {
      testConstruction(new ViewFrame(), false, null);
   }

   @Test
   @DisplayName("De no-args constructor initialiseert het ViewFrame voor een dialoog view")
   void constructViewFrameForDialog() {
      ViewFrame parentFrame = new ViewFrame();
      testConstruction(new ViewFrame(parentFrame), true, parentFrame);
   }

   @Test
   @DisplayName("setViewHeader overschrijft eerdere header content")
   void setViewHeader() {
      // Set up fixture
      ViewFrame fixture = new ViewFrame();

      // Set header content
      fixture.setViewHeader(new Label("label 1"), new Label("label 2"));

      // Make sure the labels were added
      Div header = getHeader(fixture);
      assertThat(header.getChildren()).hasSize(2);
      assertThat(header.getChildren().filter(child -> child instanceof Label).map(child -> ((Label) child).getText()))
            .containsExactly("label 1", "label 2");

      // Make sure the labels are properly replaced
      fixture.setViewHeader(new Label("label 3"));
      assertThat(header.getChildren()).hasSize(1);
      assertThat(header.getChildren().filter(child -> child instanceof Label).map(child -> ((Label) child).getText()))
            .containsExactly("label 3");
   }

   @Test
   @DisplayName("setViewContent overschrijft eerdere main content")
   void setViewContent() {
      // Set up fixture
      ViewFrame fixture = new ViewFrame();

      // Set header content
      fixture.setViewContent(new Label("label 1"), new Label("label 2"));

      // Make sure the labels were added
      Div content = getContent(fixture);
      assertThat(content.getChildren()).hasSize(2);
      assertThat(content.getChildren().filter(child -> child instanceof Label).map(child -> ((Label) child).getText()))
            .containsExactly("label 1", "label 2");

      // Make sure the labels are properly replaced
      fixture.setViewContent(new Label("label 3"));
      assertThat(content.getChildren()).hasSize(1);
      assertThat(content.getChildren().filter(child -> child instanceof Label).map(child -> ((Label) child).getText()))
            .containsExactly("label 3");
   }

   @Test
   @DisplayName("setViewFooter overschrijft eerdere footer content")
   void setViewFooter() {
      // Set up fixture
      ViewFrame fixture = new ViewFrame();

      // Set header content
      fixture.setViewFooter(new Label("label 1"), new Label("label 2"));

      // Make sure the labels were added
      Div footer = getFooter(fixture);
      assertThat(footer.getChildren()).hasSize(2);
      assertThat(footer.getChildren().filter(child -> child instanceof Label).map(child -> ((Label) child).getText()))
            .containsExactly("label 1", "label 2");

      // Make sure the labels are properly replaced
      fixture.setViewFooter(new Label("label 3"));
      assertThat(footer.getChildren()).hasSize(1);
      assertThat(footer.getChildren().filter(child -> child instanceof Label).map(child -> ((Label) child).getText()))
            .containsExactly("label 3");
   }

   @Test
   @DisplayName("onAttach method calls the onAttachView(AttachEvent) and authorize() methods")
   void onAttachCallsonAttachViewAndAuthorizeMethods() {
      AtomicBoolean onAttachViewCalled = new AtomicBoolean(false);
      AtomicBoolean authorizeCalled = new AtomicBoolean(false);
      ViewFrame fixture = new ViewFrame() {
         @Override
         protected void onAttachView(final AttachEvent attachEvent) {
            onAttachViewCalled.set(true);
         }

         @Override
         protected void authorize() {
            authorizeCalled.set(true);
         }
      };

      fixture.onAttach(mock(AttachEvent.class));
      assertThat(onAttachViewCalled).isTrue();
      assertThat(authorizeCalled).isTrue();

      // The default onAttachView implementation should not throw any exceptions either
      new ViewFrame() {
         @Override
         protected void authorize() {
            // No authorization required for this test
         }
      }.onAttach(mock(AttachEvent.class));
   }

   @Test
   @DisplayName("Calling onAttach method from onAttachView triggers exception so you don't end up in Stack Overflow")
   void callingonAttachFromOnAttachViewMethodThrowsException() {
      AtomicBoolean onAttachViewCalled = new AtomicBoolean(false);
      AtomicBoolean authorizeCalled = new AtomicBoolean(false);
      ViewFrame fixture = new ViewFrame() {
         @Override
         protected void onAttachView(final AttachEvent attachEvent) {
            onAttachViewCalled.set(true);

            // This is not allowed and could lead to infinite loop where methods keep calling each other,
            // So we throw an exception from the onAttach method if this is detected
            onAttach(attachEvent);
         }

         @Override
         protected void authorize() {
            authorizeCalled.set(true);
         }
      };

      assertThatIllegalStateException().isThrownBy(() -> fixture.onAttach(mock(AttachEvent.class)));
      assertThat(onAttachViewCalled).isTrue();
      assertThat(authorizeCalled).isFalse();
   }

   @Test
   @DisplayName("De authorize() method voor een dialoog roept de checkAutorizedComponents aan voor parent ViewFrame")
   void authorizeOnDialogCallsCheckAutorizedComponentsForParentViewFrame() {
      ViewFrame parent = new ViewFrame();
      ViewFrame fixture = new ViewFrame(parent);

      try (MockedStatic<ComponentAuthorizationHelper> ahMock = mockStatic(ComponentAuthorizationHelper.class)) {
         fixture.authorize();
         ahMock.verify(() -> ComponentAuthorizationHelper.checkAutorizedComponents(parent));
      }
   }

   @Test
   @DisplayName("De authorize() method doet view authorization, component authorization en zet menu page")
   void authorizeMethodPerformsViewAuthorizationComponentAuthorizationAndSetsMenuPage() {
      ViewFrame fixture = new ViewFrame();

      try (MockedStatic<ViewAuthorizationHelper> vaMock = mockStatic(ViewAuthorizationHelper.class);
           MockedStatic<ComponentAuthorizationHelper> ahMock = mockStatic(ComponentAuthorizationHelper.class);
           MockedStatic<MainLayout> mlMock = mockStatic(MainLayout.class)) {

         MainLayout mainLayoutMock = mock(MainLayout.class);
         mlMock.when(MainLayout::get).thenReturn(mainLayoutMock);

         AppBar appBarMock = mock(AppBar.class);
         when(mainLayoutMock.getAppBar()).thenReturn(appBarMock);

         MenuPage menuPageMock = mock(MenuPage.class);
         vaMock.when(() -> ViewAuthorizationHelper.getMenuPage(fixture)).thenReturn(menuPageMock);

         fixture.authorize();
         vaMock.verify(() -> ViewAuthorizationHelper.checkAuthorized(fixture));
         ahMock.verify(() -> ComponentAuthorizationHelper.checkAutorizedComponents(fixture));
         verify(appBarMock).setMenuPage(menuPageMock);
      }
   }

   @Test
   @DisplayName("De authorize() method zonder MainLayout doet view authorization en component authorization")
   void authorizeMethodWithoutMainLayoutPerformsViewAuthorizationAndComponentAuthorization() {
      ViewFrame fixture = new ViewFrame();

      try (MockedStatic<ViewAuthorizationHelper> vaMock = mockStatic(ViewAuthorizationHelper.class);
           MockedStatic<ComponentAuthorizationHelper> ahMock = mockStatic(ComponentAuthorizationHelper.class);
           MockedStatic<MainLayout> mlMock = mockStatic(MainLayout.class)) {

         mlMock.when(MainLayout::get).thenReturn(null);

         fixture.authorize();
         vaMock.verify(() -> ViewAuthorizationHelper.checkAuthorized(fixture));
         ahMock.verify(() -> ComponentAuthorizationHelper.checkAutorizedComponents(fixture));
         vaMock.verify(never(), () -> ViewAuthorizationHelper.getMenuPage(fixture));
      }
   }

   @Test
   @DisplayName("De authorize() method zonder MenuPage doet view authorization en component authorization")
   void authorizeMethodWithoutMenuPagePerformsViewAuthorizationAndComponentAuthorization() {
      ViewFrame fixture = new ViewFrame();

      try (MockedStatic<ViewAuthorizationHelper> vaMock = mockStatic(ViewAuthorizationHelper.class);
           MockedStatic<ComponentAuthorizationHelper> ahMock = mockStatic(ComponentAuthorizationHelper.class);
           MockedStatic<MainLayout> mlMock = mockStatic(MainLayout.class)) {

         MainLayout mainLayoutMock = mock(MainLayout.class);
         mlMock.when(MainLayout::get).thenReturn(mainLayoutMock);

         AppBar appBarMock = mock(AppBar.class);
         when(mainLayoutMock.getAppBar()).thenReturn(appBarMock);

         MenuPage menuPageMock = mock(MenuPage.class);
         vaMock.when(() -> ViewAuthorizationHelper.getMenuPage(fixture)).thenReturn(null);

         fixture.authorize();
         vaMock.verify(() -> ViewAuthorizationHelper.checkAuthorized(fixture));
         ahMock.verify(() -> ComponentAuthorizationHelper.checkAutorizedComponents(fixture));
         verify(appBarMock, never()).setMenuPage(menuPageMock);
      }
   }

   @Test
   @DisplayName("getPageTitle method returns the pageTitle from the AppBar if available")
   void getPageTitleReturnsPageTitleFromAppBar() {
      try (MockedStatic<MainLayout> mainLayoutMockedStatic = mockStatic(MainLayout.class)) {
         MainLayout mainLayoutMock = mock(MainLayout.class);
         mainLayoutMockedStatic.when(MainLayout::get).thenReturn(mainLayoutMock);

         AppBar appBarMock = mock(AppBar.class);
         when(appBarMock.getPageTitle()).thenReturn("Page Title from Mock AppBar");
         when(mainLayoutMock.getAppBar()).thenReturn(appBarMock);

         assertThat(new ViewFrame().getPageTitle()).isEqualTo("Page Title from Mock AppBar");
      }
   }

   @Test
   @DisplayName("getPageTitle method returns empty String when no MainLayout was found")
   void getPageTitleReturnsEmptyStringWhenNoMainLayoutWasFound() {
      try (MockedStatic<MainLayout> mainLayoutMockedStatic = mockStatic(MainLayout.class)) {
         mainLayoutMockedStatic.when(MainLayout::get).thenReturn(null);
         assertThat(new ViewFrame().getPageTitle()).isEqualTo("");
      }
   }

   private Div getHeader(final ViewFrame fixture) {
      Div header = (Div) firstDirectChildWithClassName(fixture.getContent(), Div.class, CLASS_HEADER).orElse(null);
      assertThat(header).isNotNull();
      return header;
   }

   private Div getContent(final ViewFrame fixture) {
      Div header = (Div) firstDirectChildWithClassName(fixture.getContent(), Div.class, CLASS_CONTENT).orElse(null);
      assertThat(header).isNotNull();
      return header;
   }

   private Div getFooter(final ViewFrame fixture) {
      Div header = (Div) firstDirectChildWithClassName(fixture.getContent(), Div.class, CLASS_FOOTER).orElse(null);
      assertThat(header).isNotNull();
      return header;
   }

   private void testConstruction(
         final ViewFrame fixture,
         final boolean expectedDialogModel,
         final ViewFrame expectedParentFrame) {
      assertThat(fixture.getClassName()).isEqualTo("view-frame");
      Component content = fixture.getContent();
      assertThat(content).isInstanceOf(Div.class);

      // We expect 3 direct children of content area; header, content and footer
      assertThat(content.getChildren()).hasSize(3);

      // We have a header, content and footer area, but no components will have been added to them yet
      assertThat(getHeader(fixture).getChildren()).hasSize(0);
      assertThat(getContent(fixture).getChildren()).hasSize(0);
      assertThat(getFooter(fixture).getChildren()).hasSize(0);

      // Use reflection to check internal dialogMode
      Field field = findField(ViewFrame.class, "dialogMode");
      makeAccessible(field);
      assertThat((Boolean) getField(field, fixture)).isEqualTo(expectedDialogModel);

      // Use reflection to check internal parent
      field = findField(ViewFrame.class, "parent");
      makeAccessible(field);
      assertThat(getField(field, fixture)).isEqualTo(expectedParentFrame);
   }
}
