package nl.uwv.pws.ui.util;

import com.vaadin.flow.internal.CurrentInstance;
import com.vaadin.flow.server.VaadinRequest;
import nl.uwv.commons.ws.UwvQueryLogger;
import org.awaitility.Awaitility;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.parallel.Execution;
import org.junit.jupiter.api.parallel.ExecutionMode;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import javax.naming.Context;
import javax.naming.spi.NamingManager;
import javax.sql.DataSource;
import java.lang.reflect.Field;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.TimeUnit;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

@DisplayName("QueryLogger Test")
@Execution(ExecutionMode.SAME_THREAD)
class QueryLoggerTest {
   // The Thread Sleep Time in milliseconds to use for the QueryLogger
   private static final int THREAD_SLEEP_MILLIS = 100;

   // Awaitility has polling time of 100ms, so we need to allow a bit more room in max wait time
   private static final int MAX_WAIT = 3 * THREAD_SLEEP_MILLIS;

   // Mock the DataSource to log into a Map instead of to the database
   private static final DataSource MOCK_DATA_SOURCE = mock(DataSource.class);
   private static final Map<QueryLogger.LogType, List<String>> LOGS = new TreeMap<>();

   @Test
   @DisplayName("Herhaaldelijke aanroep van getInstance() geeft steeds dezelfde instantie terug")
   void getInstanceReturnsSameInstanceRepeatedly() throws Exception {
      try (MockedStatic<NamingManager> namingManagerStaticMock = Mockito.mockStatic(NamingManager.class)) {
         initializeDataSource(namingManagerStaticMock);

         // Actual unit-test
         QueryLogger instance = QueryLogger.getInstance();
         assertThat(instance).isNotNull();
         assertThat(QueryLogger.getInstance()).isSameAs(instance);
      }
   }

   @Test
   @DisplayName("Aanroepen van de QueryLogger met Java objecten worden verwerkt")
   void callQueryLogWithObject() throws Exception {
      try (MockedStatic<NamingManager> namingManagerStaticMock = Mockito.mockStatic(NamingManager.class)) {
         initializeDataSource(namingManagerStaticMock);

         // Configure the current VaadinRequest
         VaadinRequest mockRequest = mock(VaadinRequest.class);
         when(mockRequest.getRemoteUser()).thenReturn("Test User");
         when(mockRequest.getRemoteAddr()).thenReturn("Test Address");
         CurrentInstance.set(VaadinRequest.class, mockRequest);

         // Get the QueryLogger instance and log one BSN number twice and the other once
         // We expect the logger to only log each different value once for as long as the cache still holds the values
         QueryLogger instance = QueryLogger.getInstance();
         instance.callQueryLog(QueryLogger.LogType.LA_BSN, 123456789);
         instance.callQueryLog(QueryLogger.LogType.LA_BSN, 123456789);
         instance.callQueryLog(QueryLogger.LogType.LA_BSN, 234567890);

         // Use Awaitility to wait until the Log was processed by the background Thread running inside the QueryLogger
         Awaitility.await()
               .atMost(MAX_WAIT, TimeUnit.MILLISECONDS)
               .until(() -> LOGS.get(QueryLogger.LogType.LA_BSN) != null
                     && LOGS.get(QueryLogger.LogType.LA_BSN).size() == 2
               );

         // Check if the log were received as expected
         List<String> logsForType = LOGS.get(QueryLogger.LogType.LA_BSN);
         assertThat(logsForType).containsExactlyInAnyOrder("123456789", "234567890");
      }
   }

   @Test
   @DisplayName("Aanroepen van de QueryLogger met Strings worden verwerkt")
   void callQueryLogWithStrings() throws Exception {
      try (MockedStatic<NamingManager> namingManagerStaticMock = Mockito.mockStatic(NamingManager.class)) {
         initializeDataSource(namingManagerStaticMock);

         // Configure the current VaadinRequest
         VaadinRequest mockRequest = mock(VaadinRequest.class);
         when(mockRequest.getRemoteUser()).thenReturn("Test User");
         when(mockRequest.getRemoteAddr()).thenReturn("Test Address");
         CurrentInstance.set(VaadinRequest.class, mockRequest);

         // Get the QueryLogger instance and log some lines
         QueryLogger instance = QueryLogger.getInstance();
         instance.callQueryLog(QueryLogger.LogType.LA_LHNR, "115102802L01");
         instance.callQueryLog(QueryLogger.LogType.WGA_SOFINR, "201500097");
         instance.callQueryLog(QueryLogger.LogType.WGA_SOFINR, "201500098");

         // Use Awaitility to wait until the Log were processed by the background Thread running inside the QueryLogger
         Awaitility.await()
               .atMost(MAX_WAIT, TimeUnit.MILLISECONDS)
               .until(() -> LOGS.get(QueryLogger.LogType.LA_LHNR) != null);
         Awaitility.await()
               .atMost(MAX_WAIT, TimeUnit.MILLISECONDS)
               .until(() -> LOGS.get(QueryLogger.LogType.WGA_SOFINR) != null
                     && LOGS.get(QueryLogger.LogType.WGA_SOFINR).size() == 2
               );

         // Check if the logs were received as expected
         List<String> logsForType = LOGS.get(QueryLogger.LogType.LA_LHNR);
         assertThat(logsForType).containsExactly("115102802L01");
         logsForType = LOGS.get(QueryLogger.LogType.WGA_SOFINR);
         assertThat(logsForType).containsExactlyInAnyOrder("201500097", "201500098");
      }
   }

   @Test
   @DisplayName("Aanroep van de QueryLogger met null wordt verwerkt")
   void callQueryLogWithNullValue() throws Exception {
      try (MockedStatic<NamingManager> namingManagerStaticMock = Mockito.mockStatic(NamingManager.class)) {
         initializeDataSource(namingManagerStaticMock);

         // Configure the current VaadinRequest
         VaadinRequest mockRequest = mock(VaadinRequest.class);
         when(mockRequest.getRemoteUser()).thenReturn("Test User");
         when(mockRequest.getRemoteAddr()).thenReturn("Test Address");
         CurrentInstance.set(VaadinRequest.class, mockRequest);

         // Get the QueryLogger instance and log a null value
         QueryLogger instance = QueryLogger.getInstance();
         instance.callQueryLog(QueryLogger.LogType.LA_LHNR, (Object) null);

         // Use Awaitility to wait for the thread to process the logs
         Awaitility.await().during(MAX_WAIT, TimeUnit.MILLISECONDS);

         // Check that no logs were processed
         assertThat(LOGS.get(QueryLogger.LogType.LA_LHNR)).isNull();
      }
   }

   /**
    * It's a bit tricky to mock the data source, since internally it is being looked up from an enclosed private
    * method. But by statically mocking the NamingManager used for looking up the context we can still do it.
    *
    * @param namingManagerStaticMock The statically mocked NamingManager.
    * @throws Exception Any of the low-level exception that can occur, such as NamingExceptions etc.
    */
   @SuppressWarnings("unchecked")
   static void initializeDataSource(final MockedStatic<NamingManager> namingManagerStaticMock) throws Exception {
      // Use a shorted ThreadSleep time to speed up unit-tests a bit, otherwise it can take up to 5 seconds to close
      // the QueryLogger when we're done
      QueryLogger.setThreadSleep(THREAD_SLEEP_MILLIS);

      // Make sure the UwvQueryLoggers that are created beneath the surface are mocks
      QueryLogger.setUwvQueryLoggerCreator(QueryLoggerTest::mockLogger);

      // Setup the InitialContextFactoryBuilder so the DataSource lookup will return our MOCK_DATA_SOURCE
      Context initialContextMock = mock(Context.class);
      when(initialContextMock.lookup("nl/uwv/ppls/datasource/scalametads")).thenReturn(MOCK_DATA_SOURCE);
      namingManagerStaticMock.when(() -> NamingManager.getInitialContext(any())).thenReturn(initialContextMock);

      // Make sure we have an initialized QueryLogger
      QueryLogger queryLogger = QueryLogger.getInstance();

      // Extract the worker thread
      Field workerField = QueryLogger.class.getDeclaredField("worker");
      workerField.setAccessible(true);
      Thread worker = (Thread) workerField.get(queryLogger);

      // Use reflection to fetch a map of UwvQueryLoggers and make sure they are all properly mocked (sanity check)
      Field queryLoggersField = worker.getClass().getDeclaredField("queryLoggers");
      queryLoggersField.setAccessible(true);
      Map<QueryLogger.LogType, UwvQueryLogger> queryLoggers =
            (Map<QueryLogger.LogType, UwvQueryLogger>) queryLoggersField.get(worker);
      assertThat(queryLoggers).hasSize(QueryLogger.LogType.values().length);
      queryLoggers.values().forEach(
            uwvQueryLogger -> assertThat(Mockito.mockingDetails(uwvQueryLogger).isMock()).isTrue()
      );
   }

   @AfterEach
   void clearMockDataSource() {
      // After each test was run, we need to clean up the MOCK_DATA_SOURCE and clear the logs again
      Mockito.reset(MOCK_DATA_SOURCE);
      LOGS.clear();
   }

   @AfterAll
   static void closeQueryLogger() throws NoSuchFieldException, IllegalAccessException {
      // Close the QueryLogger and wait for it to finish
      QueryLogger.getInstance().close();

      // Check that the instance was now reset to null
      Field instanceField = QueryLogger.class.getDeclaredField("instance");
      instanceField.setAccessible(true);
      Object instance = instanceField.get(null);
      assertThat(instance).isNull();
   }

   // Creates a mock UwvLogger that logs to the logs to MAPS instead of to the database
   private static UwvQueryLogger mockLogger(final QueryLogger.LogType logType) {
      UwvQueryLogger mock = mock(UwvQueryLogger.class);
      doAnswer(invocationOnMock -> {
         List<String> logsForType = LOGS.computeIfAbsent(logType, k -> new ArrayList<>());
         String log = invocationOnMock.getArgument(0, String.class);
         logsForType.add(log);
         return null;
      }).when(mock).log(anyString(), any(Timestamp.class), anyString(), anyString());
      return mock;
   }
}
