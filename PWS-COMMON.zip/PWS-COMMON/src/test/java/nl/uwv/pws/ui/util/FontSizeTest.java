package nl.uwv.pws.ui.util;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;

import static org.assertj.core.api.Assertions.assertThat;

class FontSizeTest {
   @DisplayName("Iedere FontSize heeft een value")
   @ParameterizedTest(name = "[{index}] FontSize: {0}")
   @EnumSource(FontSize.class)
   void test(final FontSize fontSize) {
      assertThat(fontSize.getValue()).isNotEmpty();
   }
}
