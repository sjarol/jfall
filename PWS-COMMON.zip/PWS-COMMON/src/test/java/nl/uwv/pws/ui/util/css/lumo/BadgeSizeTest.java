package nl.uwv.pws.ui.util.css.lumo;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;

import static org.assertj.core.api.Assertions.assertThat;

class BadgeSizeTest {
   @DisplayName("Iedere BadgeSize heeft een themeName")
   @ParameterizedTest(name = "[{index}] BadgeSize: {0}")
   @EnumSource(BadgeSize.class)
   void test(final BadgeSize badgeSize) {
      assertThat(badgeSize.getThemeName()).isNotEmpty();
   }
}
