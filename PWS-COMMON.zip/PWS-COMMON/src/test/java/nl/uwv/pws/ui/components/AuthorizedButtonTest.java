package nl.uwv.pws.ui.components;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class AuthorizedButtonTest {

   private boolean clicked;
   
   @Test
   @DisplayName("Als een AuthorizedButton wordt aangemaakt, is deze default not authorized en reageert niet op een muisklik")
   void testConstruction() {
      AuthorizedButton fixture = new AuthorizedButton();
      assertThat(fixture.isAuthorized()).isFalse();
      
      clicked = false;
      fixture.addClickListener(ev -> clicked = true);
      fixture.click();
      
      assertThat(clicked).isFalse();
   }

   @Test
   @DisplayName("Als een AuthorizedButton is authorized dan reageert deze op een muisklik")
   void testAuthorized() {
      AuthorizedButton fixture = new AuthorizedButton();
      fixture.setAuthorized(true);
      clicked = false;
      fixture.addClickListener(ev -> clicked = true);
      fixture.click();
      
      assertThat(clicked).isTrue();
   }

}
