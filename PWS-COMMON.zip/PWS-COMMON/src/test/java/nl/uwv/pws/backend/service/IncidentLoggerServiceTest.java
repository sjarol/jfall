package nl.uwv.pws.backend.service;

import static org.assertj.core.api.Assertions.assertThat;

import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.startsWith;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.sql.SQLException;
import java.sql.Timestamp;

import javax.sql.DataSource;

import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import com.vaadin.flow.data.provider.SortDirection;

import nl.uwv.pws.backend.desc.SampleResourceFieldDescriptor;

class IncidentLoggerServiceTest extends AbstractListServiceTest<IncidentLoggerService> {
   public IncidentLoggerServiceTest() {
      super("PWS_INCIDENT_LOGS", SampleResourceFieldDescriptor.INCIDENTLOG, "LOGGED_ON", SortDirection.ASCENDING);
   }
   
   @Test
   void testInsert() throws SQLException {
      when(getDataSourceMock().getConnection()).thenReturn(getConnectionMock());
      when(getConnectionMock().prepareStatement(startsWith("INSERT INTO PWS_INCIDENT_LOGS"))).thenReturn(getStatementMock());
      when(getConnectionMock().getAutoCommit()).thenReturn(true).thenReturn(false);
      
      ArgumentCaptor<String> vcIncidentNo = ArgumentCaptor.forClass(String.class);
      ArgumentCaptor<String> vcLoggedBy = ArgumentCaptor.forClass(String.class);
      ArgumentCaptor<Timestamp> vcTimestamp = ArgumentCaptor.forClass(Timestamp.class);
      ArgumentCaptor<String> vcStacktrace = ArgumentCaptor.forClass(String.class);
      ArgumentCaptor<String> vcThreadDump = ArgumentCaptor.forClass(String.class);
      
      doNothing().when(getStatementMock()).setString(eq(1), vcIncidentNo.capture());
      doNothing().when(getStatementMock()).setString(eq(2), vcLoggedBy.capture());
      doNothing().when(getStatementMock()).setTimestamp(eq(3), vcTimestamp.capture());
      doNothing().when(getStatementMock()).setString(eq(4), vcStacktrace.capture());
      doNothing().when(getStatementMock()).setString(eq(5), vcThreadDump.capture());
      
      getFixture().insert("tst101", "Deze string verkorten tot maximaal 20 posities", "Some stacktrace", "Some threaddump");

      assertThat(vcIncidentNo.getValue()).isNotNull().isNotEmpty().matches("[a-z0-9]+");
      assertThat(vcLoggedBy.getValue()).isNotNull().isEqualTo("Deze stri.. posities");
      assertThat(vcTimestamp.getValue()).isNotNull();
      assertThat(vcStacktrace.getValue()).isNotNull().isEqualTo("Some stacktrace");
      assertThat(vcThreadDump.getValue()).isNotNull().isEqualTo("Some threaddump");
      verify(getConnectionMock(), never()).commit();
      
      getFixture().insert("tst101", "Logged door", "Some stacktrace2", "Some threaddump2");

      assertThat(vcIncidentNo.getValue()).isNotNull().isNotEmpty().matches("[a-z0-9]+");
      assertThat(vcLoggedBy.getValue()).isNotNull().isEqualTo("Logged door");
      assertThat(vcTimestamp.getValue()).isNotNull();
      assertThat(vcStacktrace.getValue()).isNotNull().isEqualTo("Some stacktrace2");
      assertThat(vcThreadDump.getValue()).isNotNull().isEqualTo("Some threaddump2");
      verify(getConnectionMock(), times(1)).commit();
      
   }

   @SuppressWarnings("serial")
   @Override
   protected IncidentLoggerService createService(final DataSource dataSourceMock) {
      return new IncidentLoggerService("DS_NAME") {
         @Override
         protected DataSource getDataSource() {
            // Make sure we return the mocked datasource
            return dataSourceMock;
         }
      };
   }
}
