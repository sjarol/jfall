package nl.uwv.pws.ui.util.css;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;

import static org.assertj.core.api.Assertions.assertThat;

class BorderRadiusTest {
   @DisplayName("Iedere BorderRadius heeft een value")
   @ParameterizedTest(name = "[{index}] BorderRadius: {0}")
   @EnumSource(BorderRadius.class)
   void test(final BorderRadius borderRadius) {
      assertThat(borderRadius.getValue()).isNotEmpty();
   }
}
