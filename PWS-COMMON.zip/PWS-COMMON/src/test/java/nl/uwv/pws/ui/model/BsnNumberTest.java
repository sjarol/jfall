package nl.uwv.pws.ui.model;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.NullAndEmptySource;

import static org.assertj.core.api.Assertions.assertThat;

class BsnNumberTest {
   @DisplayName("BsnNumber voegt voorloopnullen toe")
   @ParameterizedTest(name = "[{index}] - new BsnNumber(\"{0}\") geeft bsn \"{1}\" terug")
   @CsvSource({"123,000000123", "123456789,123456789", "654321,000654321"})
   void constructBsn(final String bsn, final String expectedBsn) {
      BsnNumber bsnNumber = new BsnNumber(bsn);
      assertThat(bsnNumber.getBsn()).isEqualTo(expectedBsn);
      assertThat(bsnNumber.toString()).isEqualTo(expectedBsn);
      assertThat(bsnNumber.intValue()).isEqualTo(Integer.parseInt(bsn));
   }

   @DisplayName("Leeg BsnNumber voegt geen voorloopnullen toe")
   @ParameterizedTest(name = "[{index}] - new BsnNumber({0}) geeft leeg bsn terug")
   @NullAndEmptySource
   void constructEmptyBsn(final String bsn) {
      BsnNumber bsnNumber = new BsnNumber(bsn);
      assertThat(bsnNumber.getBsn()).isEqualTo("");
      assertThat(bsnNumber.toString()).isEqualTo("");
      assertThat(bsnNumber.intValue()).isZero();
   }

   @DisplayName("Non-numerieke input-waarden leveren geen fout op, maar int-waarde is 0")
   @ParameterizedTest(name = "[{index}] - new BsnNumber(\"{0}\") geeft int-waarde 0 terug")
   @CsvSource({"123abc,000123abc", "Ab!0,00000Ab!0", "xëW,000000xëW"})
   void constructFoutiefBsn(final String bsn, final String expectedBsn) {
      BsnNumber bsnNumber = new BsnNumber(bsn);
      assertThat(bsnNumber.getBsn()).isEqualTo(expectedBsn);
      assertThat(bsnNumber.toString()).isEqualTo(expectedBsn);
      assertThat(bsnNumber.intValue()).isZero();
   }
}
