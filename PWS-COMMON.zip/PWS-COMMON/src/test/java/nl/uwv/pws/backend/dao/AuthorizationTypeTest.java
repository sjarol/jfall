package nl.uwv.pws.backend.dao;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class AuthorizationTypeTest {
   @Test
   @DisplayName("De letters van de naam van de enum komen allemaal voor in de omschrijving die tostring genereert")
   void testAuthorizationType() {
      // Quick test; make sure the letters of the name of each enum value are all present in their descriptions
      for (AuthorizationType authorizationType : AuthorizationType.values()) {
         assertThat(authorizationType.toString().toLowerCase().toCharArray())
               .contains(authorizationType.name().toLowerCase().toCharArray());
      }
   }
}
