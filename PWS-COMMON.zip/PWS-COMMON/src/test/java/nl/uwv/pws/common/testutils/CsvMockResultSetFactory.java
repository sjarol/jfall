package nl.uwv.pws.common.testutils;

import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;

import org.apache.commons.codec.binary.StringUtils;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import java.util.Map.Entry;

import static java.util.stream.Collectors.toList;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Factory that creates a mock {@link ResultSet} that returns data from a CSV file to make writing unit-tests
 * a bit easier for services that normally try to read data from the database.
 *
 * @author Onno Scheffers
 */
public class CsvMockResultSetFactory {
   private final List<String> headers;
   private final List<List<String>> rows;
   private final ResultSet mockResultSet = mock(ResultSet.class);
   private final Map<Integer,String> filters;
   private int rowIndex = -1;

   /**
    * Constructs a new CsvMockResultSetFactory that will setup a mock {@link ResultSet} for you with data from a
    * CSV file.
    *
    * @param relativeTo  The test-class relative to which package the CSV file is on the classpath.
    * @param csvFileName The name of the CSV file to load.
    * @throws IOException            If something goes wrong while accessing the CSV file.
    * @throws CsvValidationException If the CsvFile is invalid.
    * @throws SQLException           If setting up the mock ResultSet fails.
    */
   public CsvMockResultSetFactory(final Class<?> relativeTo, final String csvFileName)
         throws IOException, CsvValidationException, SQLException {

      String[] csvHeaders = null;
      List<List<String>> csvRows = new ArrayList<>();

      // Read the CSV file
      try (InputStream is = relativeTo.getResourceAsStream(csvFileName);
           CSVReader csvReader = new CSVReader(new InputStreamReader(Objects.requireNonNull(
                 is, "Unable to locate CSV file \"" + csvFileName + "\" on classpath")))) {
         String[] rowData;
         int rowNumber = 0;
         while ((rowData = csvReader.readNext()) != null) {
            if (csvHeaders == null) {
               // Read the headers
               csvHeaders = rowData;
            } else {
               // Read a line of data
               assertThat(rowData.length)
                     .withFailMessage(String.format(
                           "Row %d in %s contains %d columns of data while %d header columns are defined",
                           rowNumber, csvFileName, rowData.length, csvHeaders.length
                     ))
                     .isEqualTo(csvHeaders.length);
               csvRows.add(Arrays.stream(rowData).map(this::trimToNull).collect(toList()));
            }
         }
      }
      if (csvHeaders == null) {
         throw new CsvValidationException("No column headers were found in CSV File \"" + csvFileName + "\"");
      }

      this.headers = Arrays.stream(csvHeaders).map(this::trim).collect(toList());
      this.rows = Collections.unmodifiableList(csvRows);
      this.filters = new HashMap<>();

      // Make sure the ResultSet mock is properly initialized to return the data from the CSV file
      initializeMockResultSet();
   }

   public void clearFilter() {
      filters.clear();
      rowIndex = -1;
   }

   public void addFilter(String header, String value) {
      for (int index = 0; index < headers.size(); index++) {
         if (StringUtils.equals(headers.get(index), header)) {
            filters.put(index, value);
         }
      }
   }

   /**
    * Get the mocked ResultSet you can use in your unit-test.
    *
    * @return The mocked ResultSet you can use in your unit-test.
    */
   public ResultSet getMockResultSet() {
      return mockResultSet;
   }

   private String trimToNull(final String str) {
      String trimmed = trim(str);
      return trimmed == null || trimmed.isEmpty() ? null : trimmed;
   }

   private String trim(final String str) {
      return str == null ? null : str.trim();
   }

   private void initializeMockResultSet() throws SQLException {
      when(mockResultSet.next()).thenAnswer((Answer<Boolean>) invocationOnMock -> nextRow());

      when(mockResultSet.getInt(anyInt())).thenAnswer((Answer<Integer>) this::intByIndex);
      when(mockResultSet.getInt(anyString())).thenAnswer((Answer<Integer>) this::intByName);

      when(mockResultSet.getLong(anyInt())).thenAnswer((Answer<Long>) this::longByIndex);
      when(mockResultSet.getLong(anyString())).thenAnswer((Answer<Long>) this::longByName);

      when(mockResultSet.getString(anyInt())).thenAnswer((Answer<String>) this::strByIndex);
      when(mockResultSet.getString(anyString())).thenAnswer((Answer<String>) this::strByName);

      when(mockResultSet.getObject(anyInt())).thenAnswer(this::strByIndex);
      when(mockResultSet.getObject(anyString())).thenAnswer(this::strByName);
   }

   private boolean nextRow() {
      boolean notFound = filters.size() > 0;
      while (++rowIndex < rows.size() && notFound) {
         boolean found = true;
         for (Entry<Integer, String> entry : filters.entrySet()) {
            found = found
                  && StringUtils.equals(entry.getValue(), rows.get(rowIndex).get(entry.getKey()));
         }
         notFound = !found;
      }
      return rowIndex < rows.size();
   }

   private String strByIndex(final InvocationOnMock invocationOnMock) {
      return rows.get(rowIndex).get(getColumnIndex(invocationOnMock));
   }

   private String strByName(final InvocationOnMock invocationOnMock) {
      return rows.get(rowIndex).get(findColumnIndexByName(invocationOnMock));
   }

   private int intByIndex(final InvocationOnMock invocationOnMock) {
      String str = strByIndex(invocationOnMock);
      return Integer.parseInt(str);
   }

   private int intByName(final InvocationOnMock invocationOnMock) {
      String str = strByName(invocationOnMock);
      return Integer.parseInt(str);
   }

   private long longByIndex(final InvocationOnMock invocationOnMock) {
      String str = strByIndex(invocationOnMock);
      return Long.parseLong(str);
   }

   private long longByName(final InvocationOnMock invocationOnMock) {
      String str = strByName(invocationOnMock);
      return Long.parseLong(str);
   }

   private int getColumnIndex(final InvocationOnMock invocationOnMock) {
      return invocationOnMock.getArgument(0, Integer.class) - 1;
   }

   private int findColumnIndexByName(final InvocationOnMock invocationOnMock) {
      String name = invocationOnMock.getArgument(0, String.class);
      for (int i = 0; i < headers.size(); i++) {
         if (name.equalsIgnoreCase(headers.get(i))) {
            return i;
         }
      }
      throw new IllegalArgumentException("Column \"" + name + "\" was not found in CSV file");
   }
}
