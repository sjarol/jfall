package nl.uwv.pws.ui.components;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class NoResultsLabelTest {
   @Test
   @DisplayName("Als een NoResultsLabel wordt aangemaakt, heeft deze een id, een text en is initieel onzichtbaar")
   void testConstruction() {
      NoResultsLabel fixture = new NoResultsLabel();
      assertThat(fixture.getText()).isEqualTo("Geen resultaten gevonden");
      assertThat(fixture.getId()).hasValue("no_results_label");
      assertThat(fixture.isVisible()).isFalse();
   }
}
