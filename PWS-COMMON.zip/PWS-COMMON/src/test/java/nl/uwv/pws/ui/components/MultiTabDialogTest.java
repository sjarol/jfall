package nl.uwv.pws.ui.components;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatNoException;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockStatic;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;

import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;

import nl.uwv.pws.backend.service.LomoLogService;
import nl.uwv.pws.ui.views.ViewFrame;

class MultiTabDialogTest {

   private static final String TEST_1 = "Test 1";
   private static final String TEST_2 = "Test 2";
   private static final String TEST_3 = "Test 3";
   private TestDialogTab dialogTab1 = new TestDialogTab(TEST_1, new Div(new Label(TEST_1)));
   private TestDialogTab dialogTab2 = new TestDialogTab(TEST_2, new Div(new Label(TEST_2)));
   private TestDialogTab dialogTab3 = new TestDialogTab(TEST_3, new Div(new Label(TEST_3)));

   @Test
   @DisplayName("Navigatie test prev button")
   void testPreviousTab() {
      MultiTabDialog fixture = getMultiTabDialog();
      UI mockUI = mock(UI.class);
      try (MockedStatic<UI> mockStaticUI = mockStatic(UI.class)){
         mockStaticUI.when(UI::getCurrent).thenReturn(mockUI);
         assertThatNoException().isThrownBy(() -> fixture.open());
         
         assertThatNoException().isThrownBy(() -> fixture.prevTab());
         assertThat(fixture.getSelectedTabIndex()).isEqualTo(0);
         dialogTab1.setValid(true);
         fixture.setSelectedTabIndex(2);
         assertThat(fixture.getSelectedTabIndex()).isEqualTo(2);
         // Tab is nog niet valid dus geen navigatie
         dialogTab3.setValid(false);
         assertThatNoException().isThrownBy(() -> fixture.prevTab());
         assertThat(fixture.getSelectedTabIndex()).isEqualTo(2);
         dialogTab3.setValid(true);
         assertThatNoException().isThrownBy(() -> fixture.prevTab());
         assertThat(fixture.getSelectedTabIndex()).isEqualTo(1);
         dialogTab2.setValid(true);
         assertThatNoException().isThrownBy(() -> fixture.prevTab());
         assertThat(fixture.getSelectedTabIndex()).isEqualTo(0);
      } finally {
         assertThatNoException().isThrownBy(() -> fixture.close());
      }
   }

   @Test
   @DisplayName("Navigatie test next button")
   void testNextTab() {
      MultiTabDialog fixture = getMultiTabDialog();
      UI mockUI = mock(UI.class);
      try (MockedStatic<UI> mockStaticUI = mockStatic(UI.class)){
         mockStaticUI.when(UI::getCurrent).thenReturn(mockUI);
         assertThatNoException().isThrownBy(() -> fixture.open());
         
         assertThatNoException().isThrownBy(() -> fixture.nextTab());
         // Tab is nog niet valid dus geen navigatie
         assertThat(fixture.getSelectedTabIndex()).isEqualTo(0);
         dialogTab1.setValid(true);
         assertThatNoException().isThrownBy(() -> fixture.nextTab());
         assertThat(fixture.getSelectedTabIndex()).isEqualTo(1);
         dialogTab2.setValid(true);
         assertThatNoException().isThrownBy(() -> fixture.nextTab());
         assertThat(fixture.getSelectedTabIndex()).isEqualTo(2);
         dialogTab3.setValid(true);
         assertThatNoException().isThrownBy(() -> fixture.nextTab());
         assertThat(fixture.getSelectedTabIndex()).isEqualTo(2);
      } finally {
         assertThatNoException().isThrownBy(() -> fixture.close());
      }
   }

   @Test
   @DisplayName("Remove tabs verwijderd bestaande dialog tabs")
   void testRemoveTabs() {
      MultiTabDialog fixture = getMultiTabDialog();
      UI mockUI = mock(UI.class);
      try (MockedStatic<UI> mockStaticUI = mockStatic(UI.class)){
         mockStaticUI.when(UI::getCurrent).thenReturn(mockUI);
         assertThatNoException().isThrownBy(() -> fixture.open());

         assertThatNoException().isThrownBy(() -> fixture.removeTabs());
         // Geen tabs
         assertThat(fixture.getTabSize()).isEqualTo(0);
         // Geen tab geselecteerd
         assertThat(fixture.getSelectedTabIndex()).isEqualTo(-1);
         // Navigatie mag geen fout geven
         assertThatNoException().isThrownBy(() -> fixture.prevTab());
         assertThatNoException().isThrownBy(() -> fixture.nextTab());
      } finally {
         assertThatNoException().isThrownBy(() -> fixture.close());
      }
   }

   private MultiTabDialog getMultiTabDialog() {
      ViewFrame parent = new ViewFrame();
      String title = "Test dialog";
      String width = "1024px";
      String height = "768px";
      String testId = "tst-id";

      MultiTabDialog dialog = new MultiTabDialog(parent, title, width, height);
      dialog.setId(testId);
      
      assertThat(dialog.getHeight()).isEqualTo(height);
      assertThat(dialog.getId().isPresent()).isTrue();
      assertThat(dialog.getId().orElse("?")).isEqualTo(testId);
      assertThat(dialog.getWidth()).isEqualTo(width);
      // Niet geautoriseerd tab wordt niet toegevoegd.
      dialogTab1.setAuthorized(false);
      assertThatNoException().isThrownBy(() -> dialog.addTab(dialogTab1));
      assertThat(dialog.getTabSize()).isEqualTo(0);

      // Geautoriseerd tabs worden toegevoegd.
      dialogTab1.setAuthorized(true);
      dialogTab2.setAuthorized(true);
      dialogTab3.setAuthorized(true);
      assertThatNoException().isThrownBy(() -> dialog.addTab(dialogTab1));
      assertThatNoException().isThrownBy(() -> dialog.addTab(dialogTab2));
      assertThatNoException().isThrownBy(() -> dialog.addTab(dialogTab3));
      assertThat(dialog.getTabSize()).isEqualTo(3);

      // Default zou de eerste tab geselecteerd moeten zijn (base=0)
      assertThat(dialog.getSelectedTabIndex()).isEqualTo(0);
      
      // De get content zou aangeroepen moeten zijn
      assertThat(dialogTab1.getContentCalled()).isEqualTo(1);
      assertThat(dialogTab2.getContentCalled()).isEqualTo(1);
      assertThat(dialogTab3.getContentCalled()).isEqualTo(1);

      return dialog;
   }

   class TestDialogTab implements DialogTab {
      private boolean authorized = false;
      private String name;
      private boolean valid;
      private Div content;
      private int contentCalled = 0;
      
      TestDialogTab(String name, Div content) {
         this.name = name;
         this.content = content;
      }

      @Override
      public boolean isAuthorized() {
         return authorized;
      }

      @Override
      public void setAuthorized(boolean authorized) {
         this.authorized = authorized;
      }

      @Override
      public String getName() {
         return name;
      }

      @Override
      public Div getContent() {
         contentCalled++;
         return content;
      }
      
      public int getContentCalled() {
         return contentCalled;
      }

      @Override
      public boolean isValid() {
         return valid;
      }

      public void setValid(boolean valid) {
         this.valid = valid;
      }

   }
}
