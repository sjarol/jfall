package nl.uwv.pws.backend.service;

import com.opencsv.exceptions.CsvValidationException;
import nl.uwv.pws.common.testutils.CsvMockResultSetFactory;
import org.opentest4j.AssertionFailedError;

import javax.sql.DataSource;
import java.io.IOException;
import java.lang.reflect.Method;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import static org.mockito.Mockito.mock;

/**
 * Can be extended by unit-tests that test a Service that extend the AbstractService and holds some tests and
 * functionality that is often shared between those tests.
 *
 * @param <T> The type of service to test.
 */
abstract class AbstractServiceTest<T extends AbstractService> {
   private final DataSource dataSourceMock = mock(DataSource.class);
   private final Connection connectionMock = mock(Connection.class);
   private final CallableStatement callStatementMock = mock(CallableStatement.class);
   private final PreparedStatement prepStatementMock = mock(PreparedStatement.class);
   private final T fixture = createService(dataSourceMock);

   /**
    * Constructs this AbstractServiceTest.
    *
    */
   public AbstractServiceTest() {
      // Empty constructor
   }

   /**
    * Must be implemented by the actual service test classes to return a service implementation that does not lookup
    * the dataSource, but uses the mocked one passed in as a parameter. This way we can mock the entire JDBC stack
    * without requiring an actual database connection.
    *
    * @param dataSourceMock The mock dataSource that should be used instead of a real dataSource.
    * @return The newly created Service to test, but that now uses the mocked dataSource.
    */
   protected abstract T createService(final DataSource dataSourceMock);

   /**
    * The dataSource mock that was set up for this test. You still need to prepare this mock for your specific
    * test case.
    *
    * @return The dataSource mock that was set up for this test.
    */
   public DataSource getDataSourceMock() {
      return dataSourceMock;
   }

   /**
    * The connection mock that was set up for this test. You still need to prepare this mock for your specific
    * test case.
    *
    * @return The connection mock that was set up for this test.
    */
   public Connection getConnectionMock() {
      return connectionMock;
   }

   /**
    * The statement mock that was set up for this test. You still need to prepare this mock for your specific test case.
    *
    * @return The statement mock that was set up for this test.
    */
   public CallableStatement getCallStatementMock() {
      return callStatementMock;
   }

   /**
    * The statement mock that was set up for this test. You still need to prepare this mock for your specific test case.
    *
    * @return The statement mock that was set up for this test.
    */
   public PreparedStatement getPrepStatementMock() {
      return prepStatementMock;
   }


   /**
    * Returns the fixture (service under test) that was set up for this test using the {@link #createService} method.
    *
    * @return The fixture that was set up for this test.
    */
   public T getFixture() {
      return fixture;
   }

   /**
    * Create a CsvMockResultSetFactory that reads data from the given CSV file and offers that data through a mock
    * ResultSet factory that can be used to test if the JDBC calls are written properly without actually hitting a
    * database.
    *
    * @param csvFileName The name of the CSV file to read data from, must be on the classpath, relative to getClass().
    * @return The newly create CsvMockResultSetFactory.
    * @throws IllegalArgumentException If the given file cannot be found or read from.
    */
   public CsvMockResultSetFactory createMockResultSetFactory(final String csvFileName) {
      try {
         return new CsvMockResultSetFactory(getClass(), csvFileName);
      } catch (IOException | SQLException | CsvValidationException e) {
         throw new IllegalArgumentException("Unable to read data from CSV file: " + csvFileName);
      }
   }

   /**
    * Uses reflection to locate a specific method on the fixture.
    *
    * @param methodName The name of the method to find.
    * @return The method with the given name on the fixture class we'll be testing.
    * @throws AssertionFailedError If the method cannot be found.
    */
   protected Method findMethod(final String methodName) {
      Class<?> c = getFixture().getClass();
      while(c != null) {
         try {
            Method method = c.getDeclaredMethod(methodName);
            method.setAccessible(true);
            return method;
         } catch (NoSuchMethodException e) {
            // Ignore
         }
         c = c.getSuperclass();
      }
      throw new AssertionFailedError("Unable to find method: " + methodName);
   }
}
