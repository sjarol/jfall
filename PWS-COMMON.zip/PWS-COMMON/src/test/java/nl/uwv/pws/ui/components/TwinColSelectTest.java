package nl.uwv.pws.ui.components;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;

public class TwinColSelectTest {

   private static final String ERRMSG_VALUE_NE = "Value ongelijk aan verwachting";
   private static final String ERRMSG_NULL = "Value is null?";
   private static final String ERRMSG_DEFAULT_NOTNULL = "Value default niet null?";
   private static final String ERRMSG_AANTAL_NE = "Aantal selectie ongelijk aan verwachting";
   private static final String ERRMSG_ITEM_NE = "Selectie ongelijk aan verwachting";
   TwinColSelect<String> twinTest;

   @Before
   public void initTest() {
      String[] testSet = new String[]{"Test 1", "Test 2", "Test 3", "Test 4", "Test 5", "Test 6", "Test 7", "Test 8"};
      Set<String> items = new HashSet<>(Arrays.asList(testSet));

      twinTest = new TwinColSelect<>();
      twinTest.setItems(items);
   }

   @Test
   public void testSelection() {
      assertNotNull("Selectie default null?", twinTest.getSelectedItems());
      assertEquals("Selectie default niet leeg?", 0, twinTest.getSelectedItems().size());

      twinTest.select("Test 4");
      assertEquals(ERRMSG_AANTAL_NE, 1, twinTest.getSelectedItems().size());
      for (String item : twinTest.getSelectedItems()) {
         assertEquals(ERRMSG_ITEM_NE, "Test 4", item);
      }

      twinTest.deselectAll();
      assertEquals("Selectie na deselect niet leeg?", 0, twinTest.getSelectedItems().size());

      twinTest.select("Test 6");
      assertEquals(ERRMSG_AANTAL_NE, 1, twinTest.getSelectedItems().size());
      for (String item : twinTest.getSelectedItems()) {
         assertEquals(ERRMSG_ITEM_NE, "Test 6", item);
      }

      twinTest.select("Test 3", "Test 1");
      assertEquals(ERRMSG_AANTAL_NE, 3, twinTest.getSelectedItems().size());
      String[] items = twinTest.getSelectedItems().toArray(new String[3]);
      assertEquals(ERRMSG_ITEM_NE, "Test 6", items[0]);
      assertEquals(ERRMSG_ITEM_NE, "Test 3", items[1]);
      assertEquals(ERRMSG_ITEM_NE, "Test 1", items[2]);
   }

   @Test
   public void testValue() {
      HashSet<String> testSet = new HashSet<>();
      assertNull(ERRMSG_DEFAULT_NOTNULL, twinTest.getValue());

      testSet.add("Test 4");
      twinTest.setValue(testSet);
      assertNotNull(ERRMSG_NULL, twinTest.getValue());
      assertEquals("Aantal value ongelijk aan verwachting", 1, twinTest.getValue().size());
      for (String item : twinTest.getValue()) {
         assertEquals(ERRMSG_VALUE_NE, "Test 4", item);
      }

      twinTest.clear();
      assertNotNull("Value na clear null?", twinTest.getValue());
      assertEquals("Value na clear niet leeg?", 0, twinTest.getValue().size());
      testSet.clear();
      testSet.add("Test 6");

      twinTest.setValue(testSet);
      assertNotNull(ERRMSG_NULL, twinTest.getValue());
      assertEquals("Aantal value ongelijk aan verwachting", 1, twinTest.getValue().size());
      for (String item : twinTest.getValue()) {
         assertEquals(ERRMSG_VALUE_NE, "Test 6", item);
      }

      testSet.add("Test 3");
      testSet.add("Test 1");
      twinTest.setValue(testSet);
      assertNotNull(ERRMSG_NULL, twinTest.getValue());
      assertEquals("Aantal value ongelijk aan verwachting", 3, twinTest.getValue().size());
      String[] items = twinTest.getValue().toArray(new String[3]);
      assertEquals(ERRMSG_VALUE_NE, "Test 6", items[0]);
      assertEquals(ERRMSG_VALUE_NE, "Test 3", items[1]);
      assertEquals(ERRMSG_VALUE_NE, "Test 1", items[2]);
   }

   @Test
   public void testSelectionMatchesValue() {
      assertNotNull("Selectie default null?", twinTest.getSelectedItems());
      assertEquals("Selectie default niet leeg?", 0, twinTest.getSelectedItems().size());

      twinTest.select("Test 4");
      assertNotNull("Value null?", twinTest.getValue());
      assertEquals("Aantal ongelijk aan verwachting", 1, twinTest.getValue().size());
      for (String item : twinTest.getValue()) {
         assertEquals(ERRMSG_VALUE_NE, "Test 4", item);
      }

      twinTest.deselectAll();
      assertEquals("Value na deselect niet leeg?", 0, twinTest.getValue().size());

      twinTest.select("Test 6");
      assertEquals("Aantal ongelijk aan verwachting", 1, twinTest.getValue().size());
      for (String item : twinTest.getValue()) {
         assertEquals(ERRMSG_VALUE_NE, "Test 6", item);
      }

      twinTest.select("Test 3", "Test 1");
      assertEquals("Aantal ongelijk aan verwachting", 3, twinTest.getValue().size());
      String[] items = twinTest.getValue().toArray(new String[3]);
      assertEquals(ERRMSG_VALUE_NE, "Test 6", items[0]);
      assertEquals(ERRMSG_VALUE_NE, "Test 3", items[1]);
      assertEquals(ERRMSG_VALUE_NE, "Test 1", items[2]);
   }

   @Test
   public void testValueMatchesSelection() {
      HashSet<String> testSet = new HashSet<>();
      assertNull(ERRMSG_DEFAULT_NOTNULL, twinTest.getValue());

      testSet.add("Test 4");
      twinTest.setValue(testSet);
      assertNotNull("Selectie is null?", twinTest.getSelectedItems());
      assertEquals(ERRMSG_AANTAL_NE, 1, twinTest.getSelectedItems().size());
      for (String item : twinTest.getSelectedItems()) {
         assertEquals(ERRMSG_ITEM_NE, "Test 4", item);
      }

      twinTest.clear();
      assertNotNull("Selectie na clear null?", twinTest.getSelectedItems());
      assertEquals("Selectie na clear niet leeg?", 0, twinTest.getSelectedItems().size());
      testSet.clear();
      testSet.add("Test 6");

      twinTest.setValue(testSet);
      assertNotNull("Selectie is null?", twinTest.getSelectedItems());
      assertEquals(ERRMSG_AANTAL_NE, 1, twinTest.getSelectedItems().size());
      for (String item : twinTest.getSelectedItems()) {
         assertEquals(ERRMSG_ITEM_NE, "Test 6", item);
      }

      testSet.add("Test 3");
      testSet.add("Test 1");
      twinTest.setValue(testSet);
      assertNotNull("Selectie is null?", twinTest.getSelectedItems());
      assertEquals(ERRMSG_AANTAL_NE, 3, twinTest.getSelectedItems().size());
      String[] items = twinTest.getSelectedItems().toArray(new String[3]);
      assertEquals(ERRMSG_ITEM_NE, "Test 6", items[0]);
      assertEquals(ERRMSG_ITEM_NE, "Test 3", items[1]);
      assertEquals(ERRMSG_ITEM_NE, "Test 1", items[2]);
   }
}
