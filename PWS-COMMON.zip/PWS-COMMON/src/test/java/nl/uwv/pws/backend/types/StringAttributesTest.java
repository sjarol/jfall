package nl.uwv.pws.backend.types;

import static org.junit.Assert.*;

import org.junit.Test;

import nl.uwv.pws.ui.util.UIUtils;

/**
 * @author rbo138
 *
 */
public class StringAttributesTest {

   private static final String MSG = " is ongelijk aan verwachting";

   private StringAttributes test;


   /**
    * Test method for {@link nl.uwv.pws.backend.types.StringAttributes#getWidth()}.
    */
   @Test
   public void testGetWidth() {
      final String errMsg = "Width" + MSG;

      test = new StringAttributes("width:XS");
      assertEquals(errMsg, UIUtils.COLUMN_WIDTH_XS, test.getWidth());

      test = new StringAttributes("width:S");
      assertEquals(errMsg, UIUtils.COLUMN_WIDTH_S, test.getWidth());

      test = new StringAttributes("width:M");
      assertEquals(errMsg, UIUtils.COLUMN_WIDTH_M, test.getWidth());

      test = new StringAttributes("width:L");
      assertEquals(errMsg, UIUtils.COLUMN_WIDTH_L, test.getWidth());

      test = new StringAttributes("width:XL");
      assertEquals(errMsg, UIUtils.COLUMN_WIDTH_XL, test.getWidth());

      test = new StringAttributes("width:12px");
      assertEquals(errMsg, "12px", test.getWidth());

      test = new StringAttributes("width:15%");
      assertEquals(errMsg, UIUtils.COLUMN_WIDTH_S, test.getWidth());
   }

   /**
    * Test method for {@link nl.uwv.pws.backend.types.StringAttributes#getFlexGrow()}.
    */
   @Test
   public void testGetFlexGrow() {
      final String errMsg = "FlexGrow" + MSG;

      test = new StringAttributes("width:XS");
      assertEquals(errMsg, 1, test.getFlexGrow());

      test = new StringAttributes("width:L");
      assertEquals(errMsg, 2, test.getFlexGrow());

      test = new StringAttributes("flex:1");
      assertEquals(errMsg, 1, test.getFlexGrow());

      test = new StringAttributes("flex:15");
      assertEquals(errMsg, 15, test.getFlexGrow());
      
      test = new StringAttributes("flex:10,property:leverCode,sort");
      assertEquals(errMsg, 10, test.getFlexGrow());
      
      test = new StringAttributes("sort,flex:10:property:leverCode");
      assertEquals(errMsg, 10, test.getFlexGrow());
   }

   /**
    * Test method for {@link nl.uwv.pws.backend.types.StringAttributes#isSortable()}.
    */
   @Test
   public void testIsSortable() {
      final String errMsg = "IsSortable" + MSG;

      test = new StringAttributes("sort");
      assertTrue(errMsg, test.isSortable());

      test = new StringAttributes("width:XL");
      assertFalse(errMsg, test.isSortable());
   }

   /**
    * Test method for {@link nl.uwv.pws.backend.types.StringAttributes#getProperty()}.
    */
   @Test
   public void testGetProperty() {
      final String errMsg = "GetProperty" + MSG;

      test = new StringAttributes("width:L,sort,property:tslog");
      assertEquals(errMsg, "tslog", test.getProperty());

      test = new StringAttributes("property:descr,sort");
      assertEquals(errMsg, "descr", test.getProperty());

      test = new StringAttributes("sort");
      assertEquals(errMsg, "", test.getProperty());
   }

   /**
    * Test method for {@link nl.uwv.pws.backend.types.StringAttributes#isPrefix()}.
    */
   @Test
   public void testIsPrefix() {
      final String errMsg = "IsPrefix" + MSG;

      test = new StringAttributes("prefix");
      assertTrue(errMsg, test.isPrefix());

      test = new StringAttributes("width:XL");
      assertFalse(errMsg, test.isPrefix());
   }

   /**
    * Test method for {@link nl.uwv.pws.backend.types.StringAttributes#getType()}.
    */
   @Test
   public void testGetType() {
      final String errMsg = "GetType" + MSG;

      test = new StringAttributes("width:L,sort,type:date");
      assertEquals(errMsg, "date", test.getType());

      test = new StringAttributes("type:timestamp,sort");
      assertEquals(errMsg, "timestamp", test.getType());

      test = new StringAttributes("sort");
      assertNull(test.getType());
   }

   /**
    * Test method for {@link nl.uwv.pws.backend.types.StringAttributes#isHidden()}.
    */
   @Test
   public void testIsHidden() {
      final String errMsg = "IsHidden" + MSG;

      test = new StringAttributes("hidden");
      assertTrue(errMsg, test.isHidden());

      test = new StringAttributes("width:XL");
      assertFalse(errMsg, test.isHidden());
   }

   /**
    * Test method for {@link nl.uwv.pws.backend.types.StringAttributes#usePlain()}.
    */
   @Test
   public void testUsePlain() {
      final String errMsg = "UsePlain" + MSG;

      test = new StringAttributes("plain");
      assertTrue(errMsg, test.usePlain());

      test = new StringAttributes("width:XL");
      assertFalse(errMsg, test.usePlain());
   }

   /**
    * Test method for {@link nl.uwv.pws.backend.types.StringAttributes#getFieldDescription()}.
    */
   @Test
   public void testGetFieldDescription() {
      final String errMsg = "GetFieldDescription" + MSG;

      test = new StringAttributes("width:L,sort,descr:REF-ACS");
      assertEquals(errMsg, "ref", test.getFieldDescription().getProviderId());
      assertEquals(errMsg, "acs", test.getFieldDescription().getCategorie());

      test = new StringAttributes("descr:dom-tst,sort");
      assertEquals(errMsg, "dom", test.getFieldDescription().getProviderId());
      assertEquals(errMsg, "tst", test.getFieldDescription().getCategorie());

      test = new StringAttributes("sort");
      assertNull(test.getFieldDescription());
   }

   /**
    * Test method for {@link nl.uwv.pws.backend.types.StringAttributes#toString()}.
    */
   @Test
   public void testToString() {
      final String errMsg = "ToString" + MSG;
      final String value = "sort,width:XL";

      test = new StringAttributes(value);
      assertEquals(errMsg, "Attributes{" + value.toLowerCase() + "}", test.toString());
   }
}
