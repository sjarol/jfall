package nl.uwv.pws.backend.service;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.vaadin.flow.data.provider.Query;
import com.vaadin.flow.data.provider.QuerySortOrder;

class ListBoxProviderTest {

   private static final String TEST_VALUE = "testValue";
   private static final String TEST_VALUE1 = TEST_VALUE + "01";
   private static final String TEST_VALUE2 = TEST_VALUE + "02";
   private static final String TEST_VALUE3 = TEST_VALUE + "03";

   @Test
   @DisplayName("New ListBoxProvider should create a ListBoxService of type ListBoxServiceImpl")
   void testNew() {
      ListBoxProvider testProvider = new ListBoxProvider("datasource", "view", "column");
      assertThat(testProvider.getListBoxService()).isInstanceOf(ListBoxServiceImpl.class);
   }

   @Test
   @DisplayName("FetchFromBackEnd should return values")
   void testFetchFromBackEnd() {
      TestListBoxService testService = new TestListBoxService();
      ListBoxProvider testProvider = new ListBoxProvider("datasource", "view", "column");
      Query<String, String> testQuery = new Query<>();

      testService.setValues(getTestValues());
      testProvider.setListBoxService(testService);

      assertThat(testProvider.fetch(testQuery)).containsExactly(TEST_VALUE1, TEST_VALUE2, TEST_VALUE3);
      assertThat(testProvider.size(testQuery)).isEqualTo(3);
   }

   private List<String> getTestValues() {
      List<String> values = new ArrayList<>();

      values.add(TEST_VALUE1);
      values.add(TEST_VALUE2);
      values.add(TEST_VALUE3);

      return values;
   }

   @SuppressWarnings("serial")
   static class TestListBoxService implements ListBoxService {
     List<String> values = new ArrayList<>();

     protected void setValues(List<String> values) {
        this.values.clear();
        this.values.addAll(values);
     }

      @Override
      public List<String> fetchRows(String filter, int limit, int offset, List<QuerySortOrder> sortOrders) {
         return values;
      }

      @Override
      public long countRows(String filter) {
         return values.size();
      }
   }
}
