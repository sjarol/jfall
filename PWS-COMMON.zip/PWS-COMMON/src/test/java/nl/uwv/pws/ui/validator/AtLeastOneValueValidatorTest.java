package nl.uwv.pws.ui.validator;

import com.vaadin.flow.data.binder.ErrorLevel;
import com.vaadin.flow.data.binder.ValidationResult;
import com.vaadin.flow.data.binder.ValueContext;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatIllegalStateException;
import static org.mockito.Mockito.mock;

class AtLeastOneValueValidatorTest {
   @Test
   @DisplayName("When 3 suppliers supply null values, a validation error is triggered")
   void testThreeNullProviders() {
      AtLeastOneValueValidator<String> fixture = new AtLeastOneValueValidator<String>(
            "Min 1 item required",
            () -> null, () -> null, () -> null
      );
      ValidationResult validationResult =  fixture.apply("bean", mock(ValueContext.class));
      assertThat(validationResult.isError()).isTrue();
      assertThat(validationResult.getErrorLevel()).hasValue(ErrorLevel.ERROR);
      assertThat(validationResult.getErrorMessage()).isEqualTo("Min 1 item required");
   }

   @Test
   @DisplayName("When 3 suppliers supply empty values, a validation error is triggered")
   void testThreeEmptyStringProviders() {
      AtLeastOneValueValidator<String> fixture = new AtLeastOneValueValidator<String>(
            "Min 1 item required",
            () -> "", () -> "", () -> ""
      );
      ValidationResult validationResult =  fixture.apply("bean", mock(ValueContext.class));
      assertThat(validationResult.isError()).isTrue();
      assertThat(validationResult.getErrorLevel()).hasValue(ErrorLevel.ERROR);
      assertThat(validationResult.getErrorMessage()).isEqualTo("Min 1 item required");
   }

   @Test
   @DisplayName("When at least on of the suppliers supplies a valid value, no validation error is triggered")
   void testOneNonNullStringProviders() {
      AtLeastOneValueValidator<String> fixture = new AtLeastOneValueValidator<String>(
            "Min 1 item required",
            () -> null, () -> "Valid Item", () -> null
      );
      ValidationResult validationResult =  fixture.apply("bean", mock(ValueContext.class));
      assertThat(validationResult.isError()).isFalse();
      assertThatIllegalStateException().isThrownBy(validationResult::getErrorMessage)
            .withMessage("The result is not an error. It cannot contain error message");
   }
}
