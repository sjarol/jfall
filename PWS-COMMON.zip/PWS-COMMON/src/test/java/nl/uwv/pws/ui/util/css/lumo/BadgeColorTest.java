package nl.uwv.pws.ui.util.css.lumo;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;

import static org.assertj.core.api.Assertions.assertThat;

class BadgeColorTest {
   @DisplayName("Iedere BadgeColor heeft een themeName")
   @ParameterizedTest(name = "[{index}] BadgeColor: {0}")
   @EnumSource(BadgeColor.class)
   void test(final BadgeColor badgeColor) {
      assertThat(badgeColor.getThemeName()).isNotEmpty();
   }
}
