package nl.uwv.pws.ui.converters;

import com.vaadin.flow.data.binder.Result;
import com.vaadin.flow.data.binder.ValueContext;
import nl.uwv.pws.ui.model.BsnNumber;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.assertj.core.api.Assertions.assertThat;

class BsnConverterTest {
   private final BsnConverter fixture = new BsnConverter();

   @DisplayName("ConvertToModel genereert de juiste resultaten")
   @ParameterizedTest(name = "[{index}] - convertToModel {0} zou {1} terug moeten geven")
   @CsvSource({"123,000000123", "123456789,123456789", "654321,000654321"})
   void testConvertToModel(final String bsn, final String expectedOutput) {
      Result<BsnNumber> result = fixture.convertToModel(bsn, new ValueContext());
      assertThat(result).isNotNull();
      assertThat(result.isError()).isFalse();
      assertThat(result.toString()).isEqualTo("ok(" + expectedOutput + ")");
   }

   @DisplayName("ConvertToPresentation genereert de juiste resultaten")
   @ParameterizedTest(name = "[{index}] - convertToPresentation {0} zou {1} terug moeten geven")
   @CsvSource({"123,000000123", "123456789,123456789", "654321,000654321"})
   void testConvertToPresentation(final String bsn, final String expectedOutput) {
      String result = fixture.convertToPresentation(new BsnNumber(bsn), new ValueContext());
      assertThat(result).isEqualTo(expectedOutput);
   }
}
