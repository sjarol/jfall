package nl.uwv.pws.backend.dao;

import com.openpojo.reflection.PojoClass;
import com.openpojo.reflection.impl.PojoClassFactory;
import com.openpojo.validation.ValidatorBuilder;
import com.openpojo.validation.test.impl.GetterTester;
import com.openpojo.validation.test.impl.SetterTester;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class MenuPageTest {
   @Test
   @DisplayName("Getters en Setters werken volgens verwachting")
   void gettersAndSetters() {
      // Test getters and setters
      PojoClass pojoclass = PojoClassFactory.getPojoClass(MenuPage.class);
      ValidatorBuilder.create()
            .with(new GetterTester())
            .with(new SetterTester())
            .build()
            .validate(pojoclass);
   }

   @Test
   @DisplayName("toString() levert een duidelijke weergave van de waarden")
   void toStringWorks() {
      MenuPage menuPage = new MenuPage();
      menuPage.setMenuCode("MENU_CODE");
      menuPage.setDescription("Menu Description");
      menuPage.setName("Menu Name");
      menuPage.setIconName("Menu Icon");
      menuPage.setUrl("Menu URL");
      assertThat(menuPage.toString()).isEqualTo(
            "Page [menuCode=MENU_CODE, name=Menu Name, url=Menu URL, iconName=Menu Icon, omschrijving=Menu Description]"
      );
   }
}
