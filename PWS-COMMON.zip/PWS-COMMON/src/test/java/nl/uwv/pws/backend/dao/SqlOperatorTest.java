package nl.uwv.pws.backend.dao;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class SqlOperatorTest {
   @Test
   @DisplayName("Enum name are the same as the trimmed codes")
   void codesEqualNames() {
      for (SqlOperator sqlOperator : SqlOperator.values()) {
         assertThat(sqlOperator.name()).isEqualTo(sqlOperator.getCode().trim());
      }
   }
}
