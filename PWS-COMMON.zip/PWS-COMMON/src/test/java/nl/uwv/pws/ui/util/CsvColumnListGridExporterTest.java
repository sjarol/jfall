package nl.uwv.pws.ui.util;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.io.Serializable;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.junit.Test;

import com.opencsv.exceptions.CsvValidationException;
import com.vaadin.flow.data.provider.ConfigurableFilterDataProvider;
import com.vaadin.flow.data.provider.QuerySortOrder;
import com.vaadin.flow.data.provider.SortDirection;

import nl.uwv.pws.backend.dao.SqlFilter;
import nl.uwv.pws.backend.desc.FieldDescParser;
import nl.uwv.pws.backend.desc.FieldDescriptor;
import nl.uwv.pws.backend.service.AbstractListService;
import nl.uwv.pws.backend.service.ColumnListDataProvider;
import nl.uwv.pws.backend.types.ColumnList;
import nl.uwv.pws.common.testutils.CsvMockResultSetFactory;
import nl.uwv.pws.ui.components.LabelGrid;

public class CsvColumnListGridExporterTest {
   private static final Logger LOG = LogManager.getLogger(CsvBeanGridExporterTest.class);

   private final ResourceFieldDescriptor PERSONEN = new ResourceFieldDescriptor("desc/personen.desc");
   private LabelGrid<ColumnList> grid;

   @Test
   public void test() throws SQLException, IOException {
      LOG.info("Test CsvBeanGridExporter");
      initGrid();

      GridExporter<ColumnList> exporter = new CsvColumnListGridExporter<>(PERSONEN);

      assertEquals("CSV ongelijk aan verwachting", "Id;Voornaam;Achternaam;Email;Geslacht\r\n" +
            "34;Alan;Gordon;agordonx@prnewswire.com;Male\r\n" +
            "219;Alan;Kelly;akelly62@360.cn;Male\r\n" +
            "445;Alan;Moreno;amorenocc@miitbeian.gov.cn;Male\r\n" +
            "532;Alan;Perkins;aperkinser@sitemeter.com;Male\r\n" +
            "594;Alan;Smith;asmithgh@theglobeandmail.com;Male\r\n" +
            "", new String(exporter.exportGrid(grid.getGrid()), StandardCharsets.UTF_8));
   }

   private void initGrid() throws SQLException {
      PeopleListMockService peopleservice = new PeopleListMockService("dummy");
      peopleservice.setDescriptor(PERSONEN);
      peopleservice.setupMocks();

      ConfigurableFilterDataProvider<ColumnList, Void, SqlFilter> dataProvider =
            new ColumnListDataProvider(peopleservice).withConfigurableFilter();
      dataProvider.setFilter(new SqlFilter() {

         @Override
         public String getFilterSql() {
            return "FIRST_NAME = 'Alan'";
         }

         @Override
         public int getParametersSize() {
            return 0;
         }

         @Override
         public String getParameter(int index) {
            return null;
         }

      });
      grid = UIUtils.createLabelGrid("Personen", "gridPersonen", PERSONEN);
      grid.getGrid().setDataProvider(dataProvider);
   }

   public class ResourceFieldDescriptor extends FieldDescriptor {

      public ResourceFieldDescriptor(String resource) {
         super(new FieldDescParser().parse(resource));
      }
   }
   
   @SuppressWarnings("serial")
   class PeopleListMockService extends AbstractListService implements Serializable {
      private static final String EXPECTED_COUNT_QUERY =
            "SELECT COUNT(*) FROM people WHERE FIRST_NAME = 'Alan'";
      private static final String EXPECTED_FETCH_QUERY =
            "SELECT * FROM people WHERE FIRST_NAME = 'Alan' order by ID asc OFFSET ? ROWS FETCH NEXT ? ROWS ONLY";

      private final DataSource dataSourceMock = mock(DataSource.class);
      private final Connection connectionMock = mock(Connection.class);
      private final PreparedStatement countStatementMock = mock(PreparedStatement.class);
      private final PreparedStatement selectStatementMock = mock(PreparedStatement.class);

      public PeopleListMockService(String dataSourceName) {
         super(dataSourceName);
      }
      
      public void setupMocks() throws SQLException {
         // Setup mocks
         ResultSet mockCountResultSet = mock(ResultSet.class);
         when(dataSourceMock.getConnection()).thenReturn(connectionMock);
         when(connectionMock.prepareStatement(EXPECTED_COUNT_QUERY)).thenReturn(countStatementMock);
         when(countStatementMock.executeQuery()).thenReturn(mockCountResultSet);
         when(mockCountResultSet.next()).thenReturn(true, false);
         when(mockCountResultSet.getLong(1)).thenReturn(5L);

         ResultSet mockSelectResultSet = createMockResultSetFactory("/data/peopleDataSet.csv").getMockResultSet();
         when(connectionMock.prepareStatement(EXPECTED_FETCH_QUERY)).thenReturn(selectStatementMock);
         when(selectStatementMock.executeQuery()).thenReturn(mockSelectResultSet);
      }

      private CsvMockResultSetFactory createMockResultSetFactory(final String csvFileName) {
         try {
            return new CsvMockResultSetFactory(getClass(), csvFileName);
         } catch (CsvValidationException | IOException | SQLException e) {
            throw new IllegalArgumentException("Unable to read data from CSV file: " + csvFileName);
         }
      }

      private static final String VIEW_NAME = "people";
      private static final String SORT_ID = "ID";

      private FieldDescriptor descriptor;

      @Override
      protected String getViewName() {
         return VIEW_NAME;
      }

      @Override
      protected QuerySortOrder getDefaultSortOrder() {
         return new QuerySortOrder(SORT_ID, SortDirection.ASCENDING);
      }

      @Override
      public final FieldDescriptor getDescriptor() {
         return descriptor;
      }

      public void setDescriptor(FieldDescriptor descriptor) {
         this.descriptor = descriptor;
      }

      protected DataSource getDataSource() {
         return dataSourceMock;
      }

   }

}
