package nl.uwv.pws.backend.service;

import com.opencsv.exceptions.CsvValidationException;
import com.vaadin.flow.data.provider.QuerySortOrder;
import com.vaadin.flow.data.provider.SortDirection;

import nl.uwv.pws.backend.desc.SampleResourceFieldDescriptor;
import nl.uwv.pws.common.testutils.CsvMockResultSetFactory;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.opentest4j.AssertionFailedError;

import javax.sql.DataSource;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

/**
 * Can be extended by unit-tests that test a Service that extend the AbstractListService and holds some tests and
 * functionality that is often shared between those tests.
 *
 * @param <T> The type of service to test.
 */
abstract class AbstractListServiceTest<T extends AbstractListService> {
   private final String viewName;
   private final SampleResourceFieldDescriptor descriptor;
   private final String defaultSortColumnName;
   private final SortDirection defaultSortDirection;

   private final DataSource dataSourceMock = mock(DataSource.class);
   private final Connection connectionMock = mock(Connection.class);
   private final CallableStatement statementMock = mock(CallableStatement.class);
   private final T fixture = createService(dataSourceMock);

   /**
    * Constructs this AbstractListServiceTest.
    *
    * @param viewName The name of the view this service lists records from (will be unit-tested).
    * @param descriptor The ResourceFieldDescriptor for this service (will be unit-tested).
    * @param defaultSortColumnName The expected default sort column name to use (will be unit-tested).
    * @param defaultSortDirection The expected default sort direction (will be unit-tested).
    */
   public AbstractListServiceTest(
         final String viewName, final SampleResourceFieldDescriptor descriptor,
         final String defaultSortColumnName, final SortDirection defaultSortDirection) {
      this.viewName = viewName;
      this.descriptor = descriptor;
      this.defaultSortColumnName = defaultSortColumnName;
      this.defaultSortDirection = defaultSortDirection;
   }

   /**
    * Must be implemented by the actual service test classes to return a service implementation that does not lookup
    * the dataSource, but uses the mocked one passed in as a parameter. This way we can mock the entire JDBC stack
    * without requiring an actual database connection.
    *
    * @param dataSourceMock The mock dataSource that should be used instead of a real dataSource.
    * @return The newly created Service to test, but that now uses the mocked dataSource.
    */
   protected abstract T createService(final DataSource dataSourceMock);

   @Test
   @DisplayName("Make sure the view name is properly initialized")
   void testViewName() throws InvocationTargetException, IllegalAccessException {
      String extractedViewName = (String) findMethod("getViewName").invoke(fixture);
      assertThat(extractedViewName).isEqualTo(viewName);
   }

   @Test
   @DisplayName("Make sure the descriptor is properly initialized")
   void testDescriptor() {
      assertThat(getFixture().getDescriptor()).isEqualTo(descriptor);
   }

   @Test
   @DisplayName("Make sure the default sortOrder is properly initialized")
   void testDefaultSortOrder() throws InvocationTargetException, IllegalAccessException {
      QuerySortOrder defaultSortOrder = (QuerySortOrder) findMethod("getDefaultSortOrder").invoke(getFixture());
      assertThat(defaultSortOrder).isNotNull();
      assertThat(defaultSortOrder.getSorted()).isEqualTo(defaultSortColumnName);
      assertThat(defaultSortOrder.getDirection()).isSameAs(defaultSortDirection);
   }

   @Test
   @DisplayName("Calling countRows with null SqlFilter returns 0")
   void testCountRowsWithNullSqlFilterReturnsZero() {
      assertThat(getFixture().countRows(null)).isZero();
   }

   /**
    * The dataSource mock that was set up for this test. You still need to prepare this mock for your specific
    * test case.
    *
    * @return The dataSource mock that was set up for this test.
    */
   public DataSource getDataSourceMock() {
      return dataSourceMock;
   }

   /**
    * The connection mock that was set up for this test. You still need to prepare this mock for your specific
    * test case.
    *
    * @return The connection mock that was set up for this test.
    */
   public Connection getConnectionMock() {
      return connectionMock;
   }

   /**
    * The statement mock that was set up for this test. You still need to prepare this mock for your specific test case.
    *
    * @return The statement mock that was set up for this test.
    */
   public CallableStatement getStatementMock() {
      return statementMock;
   }

   /**
    * Returns the fixture (service under test) that was set up for this test using the {@link #createService} method.
    *
    * @return The fixture that was set up for this test.
    */
   public T getFixture() {
      return fixture;
   }

   /**
    * Create a CsvMockResultSetFactory that reads data from the given CSV file and offers that data through a mock
    * ResultSet factory that can be used to test if the JDBC calls are written properly without actually hitting a
    * database.
    *
    * @param csvFileName The name of the CSV file to read data from, must be on the classpath, relative to getClass().
    * @return The newly create CsvMockResultSetFactory.
    * @throws IllegalArgumentException If the given file cannot be found or read from.
    */
   public CsvMockResultSetFactory createMockResultSetFactory(final String csvFileName) {
      try {
         return new CsvMockResultSetFactory(getClass(), csvFileName);
      } catch (IOException | SQLException | CsvValidationException e) {
         throw new IllegalArgumentException("Unable to read data from CSV file: " + csvFileName);
      }
   }

   /**
    * Uses reflection to locate a specific method on the fixture.
    *
    * @param methodName The name of the method to find.
    * @return The method with the given name on the fixture class we'll be testing.
    * @throws AssertionFailedError If the method cannot be found.
    */
   private Method findMethod(final String methodName) {
      Class<?> c = getFixture().getClass();
      while(c != null) {
         try {
            Method method = c.getDeclaredMethod(methodName);
            method.setAccessible(true);
            return method;
         } catch (NoSuchMethodException e) {
            // Ignore
         }
         c = c.getSuperclass();
      }
      throw new AssertionFailedError("Unable to find method: " + methodName);
   }
}
