package nl.uwv.pws.ui.util.css.lumo;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;

import static org.assertj.core.api.Assertions.assertThat;

class BadgeShapeTest {
   @DisplayName("Iedere BadgeShape heeft een themeName")
   @ParameterizedTest(name = "[{index}] BadgeShape: {0}")
   @EnumSource(BadgeShape.class)
   void test(final BadgeShape badgeShape) {
      assertThat(badgeShape.getThemeName()).isNotEmpty();
   }
}
