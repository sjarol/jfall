package nl.uwv.pws.backend.types;

import org.apache.commons.lang.time.DateUtils;
import org.junit.jupiter.api.Test;

import java.sql.Timestamp;
import java.text.ParseException;
import java.util.Date;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * @author rbo138
 *
 */
class FieldTest {
   private Field test;

   /**
    * Test method for {@link nl.uwv.pws.backend.types.Field#getFormattedValue(java.lang.Object)}.
    */
   @Test
   void testGetFormattedValueInt() {
      test = new Field("name", null);
      Integer testInt = 314;
      assertThat(test.getFormattedValue(testInt)).isEqualTo("314");
   }

   @Test
   void testGetFormattedValueDate() throws ParseException {
      test = new Field("name", "date");

      Date date = DateUtils.parseDate("30-08-2019 12:04:45.123", new String[]{"dd-MM-yyyy HH:mm:ss.SSS"});
      Timestamp tsTest = new Timestamp(date.getTime());

      assertThat(test.getFormattedValue(tsTest)).isEqualTo("30-08-2019");
   }

   @Test
   void testGetFormattedValueDateTime() throws ParseException {
      test = new Field("name", "datetime");

      Date date = DateUtils.parseDate("30-08-2019 12:04:45.123", new String[]{"dd-MM-yyyy HH:mm:ss.SSS"});
      Timestamp tsTest = new Timestamp(date.getTime());

      assertThat(test.getFormattedValue(tsTest)).isEqualTo("30-08-2019 12:04:45");
   }

   /**
    * Test method for {@link nl.uwv.pws.backend.types.Field#getName()}.
    */
   @Test
   void testGetName() {
      test = new Field("name2", "");
      assertThat(test.getName()).isEqualTo("name2");
   }

   /**
    * Test method for {@link nl.uwv.pws.backend.types.Field#getType()}.
    */
   @Test
   void testGetType() {
      test = new Field("name2", "date");
      assertThat(test.getType()).isEqualTo("date");
   }

   /**
    * Test method for {@link nl.uwv.pws.backend.types.Field#getLabel()}.
    */
   @Test
   void testGetLabel() {
      test = new Field("name2", "My Label", "");
      assertThat(test.getLabel()).isEqualTo("My Label");
   }

   /**
    * Test method for {@link nl.uwv.pws.backend.types.Field#getWidth()}.
    */
   @Test
   void testGetWidth() {
      test = new Field("name2", "My Label", "width:12px");
      assertThat(test.getWidth()).isEqualTo("12px");
   }

   /**
    * Test method for {@link nl.uwv.pws.backend.types.Field#getFlexGrow()}.
    */
   @Test
   void testGetFlexGrow() {
      test = new Field("name2", "My Label", "flex:3");
      assertThat(test.getFlexGrow()).isEqualTo(3);
   }

   /**
    * Test method for {@link nl.uwv.pws.backend.types.Field#isSortable()}.
    */
   @Test
   void testIsSortable() {
      test = new Field("name2", "My Label", "sort");
      assertThat(test.isSortable()).isTrue();

      test = new Field("name2", "My Label", "");
      assertThat(test.isSortable()).isFalse();
   }

   /**
    * Test method for {@link nl.uwv.pws.backend.types.Field#getProperty()}.
    */
   @Test
   void testGetProperty() {
      test = new Field("name2", "My Label", "property:propName");
      assertThat(test.getProperty()).isEqualTo("propname");
   }

   /**
    * Test method for {@link nl.uwv.pws.backend.types.Field#getPropertyWithDefault(java.lang.String)}.
    */
   @Test
   void testGetPropertyWithDefault() {
      test = new Field("name2", "My Label", "property:myname");
      assertThat(test.getPropertyWithDefault("noname")).isEqualTo("myname");

      test = new Field("name2", "My Label", "");
      assertThat(test.getPropertyWithDefault("noname")).isEqualTo("noname");
   }

   /**
    * Test method for {@link nl.uwv.pws.backend.types.Field#isHidden()}.
    */
   @Test
   void testIsHidden() {
      test = new Field("name2", "My Label", "hidden");
      assertThat(test.isHidden()).isTrue();

      test = new Field("name2", "My Label", "");
      assertThat(test.isHidden()).isFalse();
   }

   /**
    * Test method for {@link nl.uwv.pws.backend.types.Field#usePlain()}.
    */
   @Test
   void testUsePlain() {
      test = new Field("name2", "My Label", "plain");
      assertThat(test.usePlain()).isTrue();

      test = new Field("name2", "My Label", "");
      assertThat(test.usePlain()).isFalse();
   }

   /**
    * Test method for {@link nl.uwv.pws.backend.types.Field#toString()}.
    */
   @Test
   void testToString() {
      test = new Field("name2", "date", "My Label", "width:XL,flex:0,sort,plain,property:btn");
      assertThat(test.toString())
            .isEqualTo("Field{name2|date|My Label|btn|240px|Attributes{width:xl,flex:0,sort,plain,property:btn}}");
   }
}
