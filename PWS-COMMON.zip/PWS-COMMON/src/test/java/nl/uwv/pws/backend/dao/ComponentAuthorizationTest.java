package nl.uwv.pws.backend.dao;

import com.openpojo.reflection.PojoClass;
import com.openpojo.reflection.impl.PojoClassFactory;
import com.openpojo.validation.ValidatorBuilder;
import com.openpojo.validation.test.impl.GetterTester;
import com.openpojo.validation.test.impl.SetterTester;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class ComponentAuthorizationTest {
   @Test
   @DisplayName("Getters en Setters werken volgens verwachting")
   void gettersAndSetters() {
      // Test getters and setters
      PojoClass pojoclass = PojoClassFactory.getPojoClass(ComponentAuthorization.class);
      ValidatorBuilder.create()
            .with(new GetterTester())
            .with(new SetterTester())
            .build()
            .validate(pojoclass);
   }

   @Test
   @DisplayName("create() method maakt correct een ComponentAuthorization aan")
   void create() {
      ComponentAuthorization componentAuthorization = ComponentAuthorization.create(
            "Test Title", AuthorizationType.MNU, "TestPage", "ADMIN", "EDITOR"
      );
      assertThat(componentAuthorization).isNotNull();
      assertThat(componentAuthorization.getTitle()).isEqualTo("Test Title");
      assertThat(componentAuthorization.getType()).isSameAs(AuthorizationType.MNU);
      assertThat(componentAuthorization.getPage()).isEqualTo("TestPage");
      assertThat(componentAuthorization.getRoles()).containsExactly("ADMIN", "EDITOR");
   }
}
