package nl.uwv.pws.ui.util;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;

import static org.assertj.core.api.Assertions.assertThat;

class FontWeightTest {
   @DisplayName("Iedere FontWeight heeft een value")
   @ParameterizedTest(name = "[{index}] FontWeight: {0}")
   @EnumSource(FontWeight.class)
   void test(final FontWeight fontWeight) {
      assertThat(fontWeight.getValue()).isNotEmpty();
   }
}
