package nl.uwv.pws.ui.util.css;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;

import static org.assertj.core.api.Assertions.assertThat;

class PositionTest {
   @DisplayName("Iedere Position heeft een value")
   @ParameterizedTest(name = "[{index}] Position: {0}")
   @EnumSource(Position.class)
   void test(final Position position) {
      assertThat(position.getValue()).isNotEmpty();
   }
}
