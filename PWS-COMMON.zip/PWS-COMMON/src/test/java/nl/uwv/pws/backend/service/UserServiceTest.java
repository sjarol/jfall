package nl.uwv.pws.backend.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;

import com.vaadin.flow.server.VaadinRequest;
import com.vaadin.flow.server.VaadinServletRequest;

import nl.uwv.pws.backend.dao.User;

class UserServiceTest {
   private static final String USER = "test007";
   private static final String ROLE1 = "UWV SP G-UG-UWV-A-PWS-01";
   private static final String ROLE2 = "UWV SP G-UG-UWV-A-PWS-02";
   private static VaadinServletRequest mockRequest;
   private static MockedStatic<AuthorizationService> mockAuthorizationService;
   private static MockedStatic<VaadinServletRequest> staticMockServletRequest;
   private static MockedStatic<VaadinRequest> staticMockRequest;

   private UserService userService = UserService.get();

   @Test
   @DisplayName("get should return the same instance of UserService")
   void testGet() {
      assertThat(userService).isNotNull().isExactlyInstanceOf(UserService.class)
            .isEqualTo(UserService.get());
   }

   @Test
   void testGetCurrentUser() {
      String remoteUser = USER;
      when(mockRequest.getRemoteUser()).thenReturn(null).thenReturn(remoteUser);

      assertThat(UserService.getCurrentUser()).isNull();
      
      User user = UserService.getCurrentUser();
      assertThat(user).isNotNull().isInstanceOf(User.class);
      assertThat(user.getUsername()).isEqualTo(remoteUser);
      assertThat(user.getRoles()).hasSize(2).containsExactlyInAnyOrder(ROLE1, ROLE2);
      // next call should be user with cached roles
      user = UserService.getCurrentUser();
      assertThat(user).isNotNull().isInstanceOf(User.class);
      assertThat(user.getUsername()).isEqualTo(remoteUser);
      assertThat(user.getRoles()).hasSize(2).containsExactlyInAnyOrder(ROLE1, ROLE2);
   }

   @Test
   void testLogin() {
      Optional<User> user = userService.login(USER);
      assertThat(user.isPresent()).isTrue();
      assertThat(user.get().getUsername()).isEqualTo(USER);
      assertThat(user.get().getRoles()).hasSize(2).containsExactlyInAnyOrder(ROLE1, ROLE2);

      // next call should be cached user
      user = userService.login(USER);
      assertThat(user.isPresent()).isTrue();
      assertThat(user.get().getUsername()).isEqualTo(USER);
      assertThat(user.get().getRoles()).hasSize(2).containsExactlyInAnyOrder(ROLE1, ROLE2);

      // Next login should fail (no roles);
      userService.logout(USER);
      user = userService.login(USER);
      assertThat(user.isPresent()).isFalse();
   }

   @BeforeAll
   static void initStaticMocks() {
      List<String> myRoles = new ArrayList<>();
      myRoles.add(ROLE1);
      myRoles.add(ROLE2);

      mockAuthorizationService = mockStatic(AuthorizationService.class);
      AuthorizationService testAuthorizationService = mock(AuthorizationService.class);
      mockAuthorizationService.when(AuthorizationService::get).thenReturn(testAuthorizationService);
      when(testAuthorizationService.getADGroups()).thenReturn(myRoles).thenReturn(new ArrayList<String>());

      mockRequest = mock(VaadinServletRequest.class);
      when(mockRequest.isUserInRole(ROLE1)).thenReturn(Boolean.TRUE);
      when(mockRequest.isUserInRole(ROLE2)).thenReturn(Boolean.TRUE);

      staticMockServletRequest = mockStatic(VaadinServletRequest.class);
      staticMockServletRequest.when(VaadinServletRequest::getCurrent).thenReturn(mockRequest);

      staticMockRequest = mockStatic(VaadinRequest.class);
      staticMockRequest.when(VaadinRequest::getCurrent).thenReturn(mockRequest);
   }
   
   @AfterAll
   static void clearStaticMocks() {
      if (mockAuthorizationService != null) {
         mockAuthorizationService.closeOnDemand();
      }
      if (staticMockServletRequest != null) {
         staticMockServletRequest.closeOnDemand();
      }
      if (staticMockRequest != null) {
         staticMockRequest.closeOnDemand();
      }
   }

}
