package nl.uwv.pws.backend.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.when;

import java.io.StringWriter;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.sql.DataSource;

import org.apache.log4j.Appender;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;
import org.apache.log4j.WriterAppender;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.springframework.mock.jndi.SimpleNamingContextBuilder;

import com.vaadin.flow.server.VaadinServletRequest;

import nl.uwv.pws.backend.lomo.LomoLogMessage;
import nl.uwv.pws.backend.lomo.LomoLogMessage.LomoResult;
import nl.uwv.pws.backend.lomo.LomoLogMessage.LomoTransaction;
import nl.uwv.pws.backend.lomo.LomoLogger;
import nl.uwv.pws.backend.lomo.LomoLoggerLog4j;

class LomoLogServiceTest extends AbstractServiceTest<LomoLogService> {
   private static final String ENV_LOMO_LOGGER = "lomoLogger";
   private static final String ENV_LOMO_DATASOURCE = "lomoDataSource";
   private static final String DS_NAME_LOMO = "DSLOMO";
   private static final int APPI_ID = 10013;
   private static final String PROGRAM_ID = LomoLogService.PWS_PROGRAMID;
   private static MockedStatic<AuthorizationService> theStaticAuthService;
   private Context initialContext;
   private Context contextMock;

   @Test
   @DisplayName("getJndiName should return datasourcename from environment or empty string when lookup failed")
   void testGetJndiName() {
      LomoLogService.setDsFailed(true);
      assertThat(LomoLogService.getJndiName()).isEqualTo("");

      LomoLogService.setDsFailed(false);
      assertThat(LomoLogService.getJndiName()).isEqualTo("DSLOMO");
   }

   @Test
   @DisplayName("Test getter/setter for dsFailed")
   void testDsFailed() {
      LomoLogService.setDsFailed(false);
      assertThat(LomoLogService.isDsFailed()).isEqualTo(false);

      LomoLogService.setDsFailed(true);
      assertThat(LomoLogService.isDsFailed()).isEqualTo(true);
   }

   @Test
   @DisplayName("Test getLomoDataSource should return datasource or null when failed")
   void testGetLomoDataSource() throws NamingException {
      assertThat(getFixture().getLomoDataSource()).isEqualTo(getDataSourceMock());

      LomoLogService.setDsFailed(true);
      assertThat(getFixture().getLomoDataSource()).isNull();

      initialContext.unbind(DS_NAME_LOMO);
      LomoLogService.setDsFailed(false);
      getFixture().setDataSource(null);

      assertThat(getFixture().getLomoDataSource()).isNull();

   }

   @Test
   @DisplayName("Get instance should return the service")
   void testGetInstance() {
      assertThat(LomoLogService.getInstance()).isNotNull().isEqualTo(getFixture());
   }

   @Test
   @DisplayName("When no custom logger is set in env a default logger should be used.")
   void testDefaultLogger() throws NamingException {
      when(contextMock.lookup(ENV_LOMO_LOGGER)).thenReturn("");
      LomoLogService.getInstance();
      assertThat(LomoLogService.getInstance()).isNotNull();

      // Check if logging goes to log4j implementation
      LomoLogMessage message = new LomoLogMessage("Test default", LomoTransaction.OTHER, LomoResult.OK, "log naar log4j?");
      VaadinServletRequest theMockRequest = getMockRequest();

      Logger lomoLogger = LogManager.getLogger(nl.uwv.pws.backend.lomo.LomoLoggerLog4j.class);
      StringWriter writer = new StringWriter();
      Appender appender = new WriterAppender(new PatternLayout("%p, %m%n"),writer);
      lomoLogger.addAppender(appender);
      // saving additivity and turning it off:
      boolean additivity = lomoLogger.getAdditivity();
      lomoLogger.setAdditivity(false);

      try (MockedStatic<VaadinServletRequest> theMockServletRequest = mockStatic(VaadinServletRequest.class)) {
         VaadinServletRequest mockServletRequest = mock(VaadinServletRequest.class);
         theMockServletRequest.when(VaadinServletRequest::getCurrent).thenReturn(mockServletRequest);
         when(mockServletRequest.getHttpServletRequest()).thenReturn(theMockRequest);

         // Use program id from application.properties
         LomoLogService.getInstance().addLomoLog("testDefaultLogger", message);
      } finally {
         lomoLogger.removeAppender(appender);
         lomoLogger.setAdditivity(additivity);
      }
      assertThat(writer.toString().replace("\n", "").replace("\r", "").replaceAll("appiId=[0-9]+", "")).isEqualTo(
            "INFO, LOG4j Lomologger initialized for programId=2170, INFO, User:null, functie: testDefaultLogger, msg: LomoLogMessage [action=Test default, transaction=OTHER, result=OK, message=log naar log4j?, details=[]]");
   }

   @Test
   @DisplayName("Adding a logger should initialize it")
   void testAddLomoLogger() {
      LomoLogService.setDsFailed(false);
      TestLomoLogger logger = new TestLomoLogger();
      getFixture().addLomoLogger(PROGRAM_ID, logger );

      assertThat(logger.getProgramId()).isEqualTo(PROGRAM_ID);
      assertThat(logger.getLomoDataSource()).isEqualTo(getDataSourceMock());
   }

   @Test
   @DisplayName("A logmessage should be forwared to the Log implementation")
   void testAddLomoLog() {
      VaadinServletRequest theMockRequest = getMockRequest();
      LomoLogService.setDsFailed(false);
      TestLomoLogger logger = new TestLomoLogger();
      getFixture().addLomoLogger(PROGRAM_ID, logger);

      LomoLogMessage message1 = new LomoLogMessage("Test logservice1", LomoTransaction.OTHER, LomoResult.OK, "log bericht1");
      LomoLogMessage message2 = new LomoLogMessage("Test logservice2", LomoTransaction.OTHER, LomoResult.ERROR, "log bericht2");

      try (MockedStatic<VaadinServletRequest> theMockServletRequest = mockStatic(VaadinServletRequest.class)) {
         VaadinServletRequest mockServletRequest = mock(VaadinServletRequest.class);
         theMockServletRequest.when(VaadinServletRequest::getCurrent).thenReturn(mockServletRequest);
         when(mockServletRequest.getHttpServletRequest()).thenReturn(theMockRequest);

         getFixture().addLomoLog(PROGRAM_ID, "testAddLomoLog1", message1);
         assertThat(logger.getProgramId()).isEqualTo(PROGRAM_ID);
         assertThat(logger.getApplicatieFunctie()).isEqualTo("testAddLomoLog1");
         assertThat(logger.getHttpServletRequest().getServerName()).isEqualTo("nl.uwv.test");
         assertThat(logger.getMessage()).isEqualTo(message1);

         getFixture().addLomoLog(PROGRAM_ID, "testAddLomoLog2", message2);
         assertThat(logger.getProgramId()).isEqualTo(PROGRAM_ID);
         assertThat(logger.getApplicatieFunctie()).isEqualTo("testAddLomoLog2");
         assertThat(logger.getHttpServletRequest().getServerName()).isEqualTo("nl.uwv.test");
         assertThat(logger.getMessage()).isEqualTo(message2);

      }
   }

   @Test
   @DisplayName("Check application.properties should log a warning when a property setting is missing")
   void testArePropertiesValid() {
      Logger lomoserviceLogger = LogManager.getLogger(LomoLogService.class);
      StringWriter writer = new StringWriter();
      Appender appender = new WriterAppender(new PatternLayout("%p, %m%n"),writer);
      lomoserviceLogger.addAppender(appender);
      // saving additivity and turning it off:
      boolean additivity = lomoserviceLogger.getAdditivity();
      lomoserviceLogger.setAdditivity(false);

      try {
         Properties properties = new Properties();
         assertThat(LomoLogService.arePropertiesValid(properties)).isFalse();
         // No message when properties are empty
         assertThat(writer.getBuffer().length()).isZero();

         properties.setProperty(LomoLogService.PROGRAM_ENV, "PPLS");
         assertThat(LomoLogService.arePropertiesValid(properties)).isFalse();
         assertThat(getMessageAndClearBuffer(writer)).isEqualTo("WARN, Ontbrekende property voor " +  LomoLogService.PROGRAM_ID);

         properties.setProperty(LomoLogService.PROGRAM_ID, "1600");
         properties.setProperty(LomoLogService.PROGRAM_ENV, "");
         assertThat(LomoLogService.arePropertiesValid(properties)).isFalse();
         assertThat(getMessageAndClearBuffer(writer)).isEqualTo("WARN, Ontbrekende property voor " +  LomoLogService.PROGRAM_ENV);

         properties.setProperty(LomoLogService.PROGRAM_ENV, "PPLS");
         assertThat(LomoLogService.arePropertiesValid(properties)).isFalse();
         assertThat(getMessageAndClearBuffer(writer)).isEqualTo("WARN, Ontbrekende property voor " +  LomoLogService.PROGRAM_INSTANCE);

         properties.setProperty(LomoLogService.PROGRAM_INSTANCE, "PWS");
         assertThat(LomoLogService.arePropertiesValid(properties)).isFalse();
         assertThat(getMessageAndClearBuffer(writer)).isEqualTo("WARN, Ontbrekende property voor " +  LomoLogService.PROGRAM_RELEASE);

         properties.setProperty(LomoLogService.PROGRAM_RELEASE, "1.0.1");
         assertThat(LomoLogService.arePropertiesValid(properties)).isTrue();
         // No message when properties are valid
         assertThat(writer.getBuffer().length()).isZero();

      } finally {
         lomoserviceLogger.removeAppender(appender);
         lomoserviceLogger.setAdditivity(additivity);
      }
   }
   
   private String getMessageAndClearBuffer(StringWriter writer) {
      String message = writer.toString().replace("\n", "").replace("\r", "");
      writer.getBuffer().delete(0, writer.getBuffer().length());
      
      return message;
   }

   @Override
   protected LomoLogService createService(DataSource dataSourceMock) {
      try {
         SimpleNamingContextBuilder.emptyActivatedContextBuilder();
         contextMock = mock(Context.class);
         when(contextMock.lookup(ENV_LOMO_DATASOURCE)).thenReturn(DS_NAME_LOMO);
         when(contextMock.lookup(ENV_LOMO_LOGGER)).thenReturn(LomoLoggerLog4j.class.getCanonicalName());

         initialContext = new InitialContext();
         initialContext.bind("java:comp/env", contextMock);
         initialContext.bind(DS_NAME_LOMO, dataSourceMock);

      } catch (NamingException e) {
         throw new RuntimeException("Context setup failed", e);
      }

      LomoLogService service = (LomoLogService)LomoLogService.getInstance();
      service.setDataSource(dataSourceMock);

      return service;
   }

   private VaadinServletRequest getMockRequest() {
      VaadinServletRequest request = mock(VaadinServletRequest.class);
      when(request.getServerName()).thenReturn("nl.uwv.test");
      when(request.getScheme()).thenReturn("https");
      when(request.getServerPort()).thenReturn(8080);

      return request;
   }

   @BeforeAll
   static void initStaticMocks() {
      // Mock autorisatie service voor appiId
      theStaticAuthService = mockStatic(AuthorizationService.class);
      AuthorizationService mockAuthService = mock(AuthorizationService.class);
      theStaticAuthService.when(AuthorizationService::get).thenReturn(mockAuthService);
      when(mockAuthService.getAppiId(anyString(), anyString(), anyString(), anyString())).thenReturn(APPI_ID);
   }

   @AfterAll
   static void clearStaticMocks() {
      if (theStaticAuthService != null) {
         theStaticAuthService.closeOnDemand();
      }
   }
   
   @SuppressWarnings("serial")
   static class TestLomoLogger implements LomoLogger {
      private DataSource lomoDataSource;
      private String programId;
      private int appiId;
      private HttpServletRequest httpServletRequest;
      private String applicatieFunctie;
      private LomoLogMessage message;

      @Override
      public void init(DataSource lomoDataSource, String programId, int appiId) {
         this.lomoDataSource = lomoDataSource;
         this.programId = programId;
         this.appiId = appiId;
      }

      @Override
      public void addLomoLog(HttpServletRequest httpServletRequest, String applicatieFunctie, LomoLogMessage message) {
         this.httpServletRequest = httpServletRequest;
         this.applicatieFunctie = applicatieFunctie;
         this.message = message;
      }

      public DataSource getLomoDataSource() {
         return lomoDataSource;
      }

      public void setLomoDataSource(DataSource lomoDataSource) {
         this.lomoDataSource = lomoDataSource;
      }

      public String getProgramId() {
         return programId;
      }

      public void setProgramId(String programId) {
         this.programId = programId;
      }

      public int getAppiId() {
         return appiId;
      }

      public void setAppiId(int appiId) {
         this.appiId = appiId;
      }

      public HttpServletRequest getHttpServletRequest() {
         return httpServletRequest;
      }

      public void setHttpServletRequest(HttpServletRequest httpServletRequest) {
         this.httpServletRequest = httpServletRequest;
      }

      public String getApplicatieFunctie() {
         return applicatieFunctie;
      }

      public void setApplicatieFunctie(String applicatieFunctie) {
         this.applicatieFunctie = applicatieFunctie;
      }

      public LomoLogMessage getMessage() {
         return message;
      }

      public void setMessage(LomoLogMessage message) {
         this.message = message;
      }
   }
}
