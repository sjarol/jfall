package nl.uwv.pws.backend.lomo;

import com.openpojo.reflection.PojoClass;
import com.openpojo.reflection.impl.PojoClassFactory;
import com.openpojo.validation.ValidatorBuilder;
import com.openpojo.validation.test.impl.GetterTester;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.sql.Date;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;

class LomoLogMessageTest {
   @Test
   @DisplayName("Getters en Setters werken volgens verwachting")
   void gettersAndSettersWorkAsExpected() {
      // Test getters and setters
      PojoClass pojoclass = PojoClassFactory.getPojoClass(LomoLogMessage.class);
      ValidatorBuilder.create().with(new GetterTester()).build().validate(pojoclass);

      pojoclass = PojoClassFactory.getPojoClass(LomoLogMessage.KeyValue.class);
      ValidatorBuilder.create().with(new GetterTester()).build().validate(pojoclass);
   }

   @Test
   @DisplayName("toString() werkt volgens verwachting")
   void toStringWorksAsExpected() {
      LomoLogMessage lomoLogMessage = new LomoLogMessage(
            "Create User",
            LomoLogMessage.LomoTransaction.CREATE,
            LomoLogMessage.LomoResult.ERROR,
            "Error occurred while creating new user"
      );
      lomoLogMessage.addDetail("username", "Test User");
      assertThat(lomoLogMessage.toString()).isEqualTo("LomoLogMessage [action=Create User, transaction=CREATE, " +
            "result=ERROR, message=Error occurred while creating new user, " +
            "details=[KeyValue [key=username, value=Test User]]]"
      );

      LomoLogMessage.KeyValue keyValue = new LomoLogMessage.KeyValue("Test Key", "Test Value");
      assertThat(keyValue.toString()).isEqualTo("KeyValue [key=Test Key, value=Test Value]");
   }

   @Test
   @DisplayName("Bij het toevoegen van een detail blijven de waarden behouden")
   void addDetail() {
      LomoLogMessage lomoLogMessage = new LomoLogMessage(
            "Delete group",
            LomoLogMessage.LomoTransaction.DELETE,
            LomoLogMessage.LomoResult.ERROR,
            "Delete Group Failed"
      );
      lomoLogMessage.addDetail("GROUP_NAME", "GROUP TO DELETE")
            .addDetail("REASON", "There are still users in the group")
            .addDetail("date", LocalDate.of(2021, 1, 15))
            .addDetail("next-attempt", LocalDateTime.of(2021, 2, 1, 11, 30));

      assertThat(lomoLogMessage.getDetailKeys()).containsExactly("GROUP_NAME", "REASON", "date", "next-attempt");
      assertThat(lomoLogMessage.getDetailValue("GROUP_NAME")).isEqualTo("GROUP TO DELETE");
      assertThat(lomoLogMessage.getDetailValue("REASON")).isEqualTo("There are still users in the group");
      assertThat(lomoLogMessage.getDetailValue("date")).isInstanceOf(Date.class);
      assertThat(lomoLogMessage.getDetailValue("date")).isEqualTo(Date.valueOf(LocalDate.of(2021, 1, 15)));
      assertThat(lomoLogMessage.getDetailValue("next-attempt")).isInstanceOf(Timestamp.class);
      assertThat(lomoLogMessage.getDetailValue("next-attempt"))
            .isEqualTo(Timestamp.valueOf(LocalDateTime.of(2021, 2, 1, 11, 30)));
      assertThat(lomoLogMessage.getDetailValue("UNKNOWN")).isNull();
   }

   @Test
   @DisplayName("Bij het toevoegen van meerdere details tegelijkertijd blijven de waarden behouden")
   void addDetails() {
      LomoLogMessage lomoLogMessage = new LomoLogMessage(
            "Delete group",
            LomoLogMessage.LomoTransaction.DELETE,
            LomoLogMessage.LomoResult.ERROR,
            "Delete Group Failed"
      );
      lomoLogMessage.addDetail("GROUP_NAME", "GROUP TO DELETE");
      Set<Object> reasons = new HashSet<>();
      reasons.add("There are still users in the group");
      reasons.add("The group is locked against deletion");
      reasons.add("User has insufficient right to delete group");
      lomoLogMessage.addDetails("REASONS", reasons);

      assertThat(lomoLogMessage.getDetailKeys()).containsExactly("GROUP_NAME", "REASONS", "REASONS", "REASONS");
      assertThat(lomoLogMessage.getDetailValue("REASONS")).isEqualTo("There are still users in the group");
      assertThat(lomoLogMessage.getDetails().stream()
            .filter(keyValue -> keyValue.getKey().equals("REASONS"))
            .map(keyValue -> (String) keyValue.getValue())
      ).containsExactlyInAnyOrder(
            "There are still users in the group",
            "The group is locked against deletion",
            "User has insufficient right to delete group"
      );
   }
}
