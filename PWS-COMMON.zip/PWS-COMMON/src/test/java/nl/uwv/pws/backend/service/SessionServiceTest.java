package nl.uwv.pws.backend.service;

import nl.uwv.pws.backend.dao.BackendException;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.mock.jndi.SimpleNamingContextBuilder;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.contains;
import static org.mockito.ArgumentMatchers.startsWith;
import static org.mockito.Mockito.*;

class SessionServiceTest extends AbstractServiceTest<SessionService> {
   private static final String DATABASE_ERROR_REMOVE_SESSION = "Database error remove session";
   private static final String DATABASE_ERROR_SELECT = "Database error select";
   private static final String DATABASE_ERROR_UPDATE = "Database error update";
   private static final String INTERNE_FOUT_SESSION_SERVICE = "Interne fout SessionService";
   private static final String AUTH_DATASOURCE = "AUTHDS";

   @Test
   @DisplayName("Get instance should return the service")
   void testGet() {
      SessionService service = SessionService.get();
      assertThat(service).isNotNull();
      assertThat(SessionService.get()).isEqualTo(service);
   }

   @Test
   @DisplayName("Get user session id should return an sessionId or null")
   void testGetUserSession() throws SQLException {
      final String sessionId = "1-TST-001";
      final String user = "TST001";

      assertThatExceptionOfType(BackendException.class).isThrownBy(() -> getFixture().getUserSession(user))
            .withMessageStartingWith(INTERNE_FOUT_SESSION_SERVICE).havingCause().withMessage(DATABASE_ERROR_SELECT);
      verify(getConnectionMock()).close();

      ResultSet mockResultSet = mock(ResultSet.class);
      when(getPrepStatementMock().executeQuery()).thenReturn(mockResultSet);
      when(mockResultSet.getString("SESSION_ID")).thenReturn(sessionId);
      when(mockResultSet.next()).thenReturn(false).thenReturn(true).thenReturn(false);

      assertThat(getFixture().getUserSession(user)).isNull();
      verify(mockResultSet).close();
      verify(getPrepStatementMock()).close();

      assertThat(getFixture().getUserSession(user)).isEqualTo(sessionId);
      assertThat(getFixture().getUserSession(user)).isNull();
   }

   @Test
   @DisplayName("Insert user session should invoke call to database function PWS_GUI.UPDATE_USR_SESSION")
   void testInsertUserSession() throws SQLException {
      final String sessionId = "1-TST-001";
      final String user = "TST001";

      assertThatExceptionOfType(BackendException.class).isThrownBy(() -> getFixture().insertUserSession(user, sessionId))
            .withMessageStartingWith(INTERNE_FOUT_SESSION_SERVICE).havingCause().withMessage(DATABASE_ERROR_UPDATE);

      assertThatNoException().isThrownBy(() -> getFixture().insertUserSession(user, sessionId));

      verify(getCallStatementMock()).setString(2, user);
      verify(getCallStatementMock()).setString(3, sessionId);
      verify(getCallStatementMock()).close();
      verify(getConnectionMock(), never()).commit();
      
      when(getCallStatementMock().getInt(1)).thenReturn(1);
      assertThat(getFixture().insertUserSession(user, sessionId)).isTrue();
      verify(getConnectionMock(), times(1)).commit();
   }

   @Test
   @DisplayName("Remove user session should invoke call to database function PWS_GUI.REMOVE_USR_SESSION")
   void testRemoveUserSession() throws SQLException {
      final String sessionId = "1-TST-001";
      final String user = "TST001";

      assertThatExceptionOfType(BackendException.class).isThrownBy(() -> getFixture().removeUserSession(user, sessionId))
            .withMessageStartingWith(INTERNE_FOUT_SESSION_SERVICE).havingCause().withMessage(DATABASE_ERROR_REMOVE_SESSION);

      assertThatNoException().isThrownBy(() -> getFixture().removeUserSession(user, sessionId));

      verify(getCallStatementMock()).setString(2, user);
      verify(getCallStatementMock()).setString(3, sessionId);
      verify(getCallStatementMock()).close();
   }

   @Test
   @DisplayName("Remove user session should invoke call to database function PWS_GUI.REMOVE_USR_SESSION")
   void testRemoveUserSessions() throws SQLException {
      final String user = "TST001";

      assertThatExceptionOfType(BackendException.class).isThrownBy(() -> getFixture().removeUserSession(user))
            .withMessageStartingWith(INTERNE_FOUT_SESSION_SERVICE).havingCause().withMessage(DATABASE_ERROR_REMOVE_SESSION);

      assertThatNoException().isThrownBy(() -> getFixture().removeUserSession(user));

      verify(getCallStatementMock()).setString(2, user);
      verify(getCallStatementMock()).setString(3, null);
      verify(getCallStatementMock()).close();
   }

   @SuppressWarnings("serial")
   @Override
   protected SessionService createService(DataSource dataSourceMock) {
      try {
         SimpleNamingContextBuilder.emptyActivatedContextBuilder();
         Context contextMock = mock(Context.class);
         when(contextMock.lookup(AuthorizationService.ENV_AUTH_DATASOURCE)).thenReturn(AUTH_DATASOURCE);

         InitialContext initialContext = new InitialContext();
         initialContext.bind("java:comp/env", contextMock);
         initialContext.bind(AUTH_DATASOURCE, dataSourceMock);
      } catch (NamingException e) {
         throw new RuntimeException("Context setup failed", e);
      }
      try {
         when(dataSourceMock.getConnection()).thenReturn(getConnectionMock());
         when(getConnectionMock().getAutoCommit()).thenReturn(true).thenReturn(false);

         when(getConnectionMock().prepareCall(contains("REMOVE_USR_SESSION")))
         .thenThrow(new SQLException(DATABASE_ERROR_REMOVE_SESSION)).thenReturn(getCallStatementMock())
         .thenThrow(new SQLException(DATABASE_ERROR_REMOVE_SESSION)).thenReturn(getCallStatementMock());

         when(getConnectionMock().prepareCall(contains("UPDATE_USR_SESSION")))
         .thenThrow(new SQLException(DATABASE_ERROR_UPDATE)).thenReturn(getCallStatementMock());

         when(getConnectionMock().prepareStatement(startsWith("SELECT PUIK_ID, SESSION_ID FROM USER_SESSION")))
         .thenThrow(new SQLException(DATABASE_ERROR_SELECT)).thenReturn(getPrepStatementMock());

      } catch (SQLException e) {
         throw new RuntimeException("JDBC mock setup failed", e);
      }

      return new SessionService() {
         @Override
         protected DataSource getDataSource() {
            return getDataSourceMock();
         }
      };
   }
}
