package nl.uwv.pws.backend.validator;

import nl.uwv.pws.ui.util.UIUtils;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.time.temporal.TemporalField;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.AssertionsForInterfaceTypes.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class DateValidatorUsingDateTimeFormatterTest {

   /**
    * It is safer to use "u" instead of "y" because DateTimeFormatter will otherwise insist on having an era in
    * combination with "y" (= year-of-era). So using "u" would avoid some possible unexpected exceptions
    * in strict formatting/parsing.
    */

   private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("dd-MM-uuuu")
         .withResolverStyle(ResolverStyle.STRICT);

   private static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("dd-MM-uuuu HH:mm:ss")
         .withResolverStyle(ResolverStyle.STRICT);

   private static final DateTimeFormatter DATE_TIME_ISO_FORMATTER = DateTimeFormatter.ISO_DATE_TIME
         .withResolverStyle(ResolverStyle.STRICT);

   private final DateValidator dateValidator = new DateValidatorUsingDateTimeFormatter(DATE_FORMATTER);
   private final DateValidator dateTimeValidator = new DateValidatorUsingDateTimeFormatter(DATE_TIME_FORMATTER);
   private final DateValidator dateTimeIsoValidator = new DateValidatorUsingDateTimeFormatter(DATE_TIME_ISO_FORMATTER);

   @Test
   @DisplayName("ISO datum/tijd String wordt als valide gezien")
   public void testDutchLocaleISODateTimeStrings() {
      assertThat(dateTimeIsoValidator.isValid("2019-09-23T13:30:32.725")).isTrue();
   }

   @Test
   @DisplayName("Formatteren van LocalDateTime levert correcte Nederlandse datum/tijd op")
   public void testValidDutchLocaleDateTimes() {
      LocalDateTime now = LocalDateTime.now();
      LocalDateTime yesterday = LocalDateTime.now().minusHours(24);

      assertThat(dateTimeValidator.isValid(UIUtils.formatDateTime(now))).isTrue();
      assertThat(dateTimeValidator.isValid(UIUtils.formatDateTime(yesterday))).isTrue();
   }

   @Test
   @DisplayName("Nederlandse datum String wordt als valide gezien")
   public void testValidDutchLocaleDatesString() {
      assertThat(dateValidator.isValid("07-09-1994")).isTrue();
      assertThat(dateValidator.isValid("28-02-1994")).isTrue();
   }

   @Test
   @DisplayName("Foutieve datum Strings worden als invalide gezien")
   public void testInvalidDutchLocaleDatesString() {
      assertThat(dateValidator.isValid("31-02-2000")).isFalse();
      assertThat(dateValidator.isValid("7-9-1994")).isFalse();
      assertThat(dateValidator.isValid("20190230")).isFalse();
   }

   @Test
   @DisplayName("Een LocalDateTime object wordt als valide gezien")
   void locaDateTimeIsValid() {
      assertThat(dateTimeValidator.isValid(LocalDateTime.now())).isTrue();
   }

   @Test
   @DisplayName("Indien een LocalDateTime object een DateTimeParseException gooit wordt het als invalide gezien")
   void localDateTimeThatThrowDateTimeParseExceptionIsInvalid() {
      LocalDateTime mockDateTime = mock(LocalDateTime.class);
      when(mockDateTime.getLong(any(TemporalField.class)))
            .thenThrow(new DateTimeParseException("Test Exception", "test-data", 0));
      assertThat(dateTimeValidator.isValid(mockDateTime)).isFalse();
   }

   @Test
   @DisplayName("Een null LocalDateTime object wordt als invalide gezien")
   void nullLocalDateTimeIsInvalid() {
      assertThat(dateTimeValidator.isValid((LocalDateTime) null)).isFalse();
   }

   @Test
   @DisplayName("Een LocalDate object wordt als valide gezien")
   void locaDateIsValid() {
      assertThat(dateValidator.isValid(LocalDate.now())).isTrue();
   }

   @Test
   @DisplayName("Indien een LocalDate object een DateTimeParseException gooit wordt het als invalide gezien")
   void localDateThatThrowDateTimeParseExceptionIsInvalid() {
      LocalDate mockDate = mock(LocalDate.class);
      when(mockDate.getLong(any(TemporalField.class)))
            .thenThrow(new DateTimeParseException("Test Exception", "test-data", 0));
      assertThat(dateTimeValidator.isValid(mockDate)).isFalse();
   }

   @Test
   @DisplayName("Een null LocalDate object wordt als invalide gezien")
   void nullLocalTimeIsInvalid() {
      assertThat(dateValidator.isValid((LocalDate) null)).isFalse();
   }
}
