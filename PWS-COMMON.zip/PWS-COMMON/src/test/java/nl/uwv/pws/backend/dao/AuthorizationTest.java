package nl.uwv.pws.backend.dao;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class AuthorizationTest {
   private static final String[] CHECK_ROLES = {
         "ADMIN", "EDITOR", "DEVELOPER", null
   };

   @Test
   @DisplayName("isAuthorized geeft true als minimaal 1 van de genoemde rollen voorkomt in lijstje uit getRoles()")
   void isAuthorized() {
      Authorization authorization = () -> CHECK_ROLES;
      assertThat(authorization.isAuthorized()).isFalse();
      assertThat(authorization.isAuthorized("PO")).isFalse();
      assertThat(authorization.isAuthorized("po")).isFalse();
      assertThat(authorization.isAuthorized((String) null)).isFalse();
      assertThat(authorization.isAuthorized("")).isFalse();

      assertThat(authorization.isAuthorized("PO", "ADMIN", "EDITOR", "DEVELOPER")).isTrue();
      assertThat(authorization.isAuthorized("ADMIN", "EDITOR", "DEVELOPER", "PO")).isTrue();
      assertThat(authorization.isAuthorized("ADMIN", "EDITOR", "PO")).isTrue();
      assertThat(authorization.isAuthorized("Admin")).isTrue();
   }
}
