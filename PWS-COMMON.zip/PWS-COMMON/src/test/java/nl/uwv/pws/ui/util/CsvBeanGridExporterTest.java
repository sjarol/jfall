package nl.uwv.pws.ui.util;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import com.vaadin.flow.component.grid.Grid;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class CsvBeanGridExporterTest {
   private Grid<Person> grid;

   @Test
   @DisplayName("Test CsvBeanGridExporter")
   public void test() throws IOException {
      initGrid();

      GridExporter<Person> exporter = new CsvBeanGridExporter<>(grid.getPropertySet());
      assertThat(new String(exporter.exportGrid(grid), StandardCharsets.UTF_8))
            .withFailMessage("CSV ongelijk aan verwachting")
            .isEqualTo("First Name;Last Name;Age\r\n"
                  + "Lucas;Kane;68\r\n"
                  + "Peter;Buchanan;38\r\n"
                  + "Samuel;Lee;53\r\n"
                  + "Anton;Ross;37\r\n"
                  + "Aaron;Atkinson;18\r\n"
                  + "Jack;Woodward;28\r\n"
            );
   }

   public void initGrid() {
      List<Person> personList = new ArrayList<>();

      personList.add(new Person(100, "Lucas", "Kane", 68));
      personList.add(new Person(101, "Peter", "Buchanan", 38));
      personList.add(new Person(102, "Samuel", "Lee", 53));
      personList.add(new Person(103, "Anton", "Ross", 37));
      personList.add(new Person(104, "Aaron", "Atkinson", 18));
      personList.add(new Person(105, "Jack", "Woodward", 28));

      grid = new Grid<>(Person.class);
      grid.setItems(personList);

      grid.removeColumnByKey("id");

      // The Grid<>(Person.class) sorts the properties and in order to
      // reorder the properties we use the 'setColumns' method.
      grid.setColumns("firstName", "lastName", "age");
   }

   public static class Person {
      private final int id;
      private final String firstName;
      private final String lastName;
      private final int age;

      public Person(final int id, final String firstName, final String lastName, final int age) {
         this.id = id;
         this.firstName = firstName;
         this.lastName = lastName;
         this.age = age;
      }

      public int getId() {
         return id;
      }

      public String getFirstName() {
         return firstName;
      }

      public String getLastName() {
         return lastName;
      }

      public int getAge() {
         return age;
      }
   }
}
