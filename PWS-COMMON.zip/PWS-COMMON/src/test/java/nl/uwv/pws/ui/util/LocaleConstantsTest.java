package nl.uwv.pws.ui.util;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class LocaleConstantsTest {
   @DisplayName("DUTCH_DATE_PICKER_I18N geeft de correcte Nederlandstalige maandnamen terug")
   @Test
   void testDutchMonthNames() {
      assertThat(LocaleConstants.DUTCH_DATE_PICKER_I18N.getMonthNames()).containsExactly(
            "januari", "februari", "maart", "april", "mei", "juni",
            "juli", "augustus", "september", "oktober", "november", "december"
      );
   }

   @DisplayName("DUTCH_DATE_PICKER_I18N geeft de correcte Nederlandstalige weeknamen terug")
   @Test
   void testDutchWeekNames() {
      assertThat(LocaleConstants.DUTCH_DATE_PICKER_I18N.getWeekdays()).containsExactly(
            "zondag", "maandag", "dinsdag", "woensdag", "donderdag", "vrijdag", "zaterdag"
      );
   }

   @DisplayName("DUTCH_DATE_PICKER_I18N geeft de correcte Nederlandstalige verkorte weeknamen terug")
   @Test
   void testDutchShortWeekNames() {
      assertThat(LocaleConstants.DUTCH_DATE_PICKER_I18N.getWeekdaysShort()).containsExactly(
            "zo", "ma", "di", "wo", "do", "vr", "za"
      );
   }
}
