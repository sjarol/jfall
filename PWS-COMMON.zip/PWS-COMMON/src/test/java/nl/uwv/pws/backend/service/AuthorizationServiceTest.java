package nl.uwv.pws.backend.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.startsWith;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.mock.jndi.SimpleNamingContextBuilder;

import com.vaadin.flow.server.VaadinServletRequest;

import nl.uwv.pws.backend.dao.AuthorizationType;
import nl.uwv.pws.backend.dao.ComponentAuthorization;
import nl.uwv.pws.backend.dao.PageAuthorization;
import nl.uwv.pws.backend.dao.User;
import nl.uwv.pws.common.testutils.CsvMockResultSetFactory;

class AuthorizationServiceTest extends AbstractServiceTest<AuthorizationService> {

   private static final String TEST_LOGIN_URL = "https://nl.uwv.test:8080/webapps/test/login";

   @Test
   @DisplayName("Calling getAuthorizedPages with null should return the Login page authorization")
   void testGetAuthorizedPagesWithNull() {
      setupMockRequest();

      List<PageAuthorization> pages = getFixture().getAuthorizedPages(null);
      assertThat(pages).isNotNull().isNotEmpty().hasSize(1);
      assertThat(pages.get(0)).isNotNull();
      assertThat(pages.get(0).getPage()).isNotNull()
         .hasFieldOrPropertyWithValue("description", "Login")
         .hasFieldOrPropertyWithValue("url", TEST_LOGIN_URL);
   }

   @Test
   @DisplayName("Calling getAuthorizedPages with unauthorized user should return no authorizations")
   void testGetAuthorizedPagesWithUnauthorizedUser() throws SQLException {
      String[] roles = {"UnknownGroup"};
      setupMockRequest();
      setupTabelMocks();

      User usr = createUser(roles);

      List<PageAuthorization> pages = getFixture().getAuthorizedPages(usr);
      assertThat(pages).isNotNull().isEmpty();
   }

   @Test
   @DisplayName("Calling getAuthorizedPages with authorized user should return authorizations")
   void testGetAuthorizedPagesWithAuthorizedUser() throws SQLException {
      String[] roles = {"PolisPlusGroup"};
      setupMockRequest();
      setupTabelMocks();

      User usr = createUser(roles);

      List<PageAuthorization> pages = getFixture().getAuthorizedPages(usr);
      assertThat(pages).isNotNull().isNotEmpty().hasSize(6);
      for (PageAuthorization page : pages) {
         assertThat(page).isNotNull();
         assertThat(page.getName()).isIn("Menus", "Autorisaties", "RGD Batch Log", "RGD Workflow", "RGD Upload",
               "RGD Job kalender", "RGD Jobs");
      }
   }

   @Test
   @DisplayName("Calling getPageUrlByName with dummy name should return Optional with no value")
   void testGetPageUrlByNameWithDummyName() throws SQLException {
      setupMockRequest();
      setupTabelMocks();

      Optional<String> test = getFixture().getPageUrlByName("dummy");

      assertThat(test).isNotNull();
      assertThat(test.isPresent()).isFalse();
   }

   @Test
   @DisplayName("Calling getPageUrlByName with Autorisaties pagename should return Optional with url value")
   void testGetPageUrlByNameWithLoginName() throws SQLException {
      setupMockRequest();
      setupTabelMocks();

      Optional<String> test = getFixture().getPageUrlByName("Autorisaties");

      assertThat(test).isNotNull();
      assertThat(test.isPresent()).isTrue();
      assertThat(test.get()).isEqualTo("https://nl.uwv.test:8080/webapps/test/admin/ui/autorisaties");
   }

   @Test
   @DisplayName("Calling getLoginUrl should return the URL to the LoginPage")
   void testLoginURL() throws NamingException {
      setupMockRequest();

      assertThat(getFixture().getLoginUrl()).isEqualTo(TEST_LOGIN_URL);
   }

   @Test
   @DisplayName("Calling getAuthorizedComponents with unauthorized user should return no authorizations")
   void testGetAuthorizedComponentsWithUnauthorizedUser() throws SQLException {
      String[] roles = {"UnknownGroup"};
      setupMockRequest();
      setupAuthCompTabelMocks();

      User usr = createUser(roles);

      List<ComponentAuthorization> components = getFixture().getAuthorizedComponents("Autorisaties", usr);
      assertThat(components).isNotNull().isEmpty();
   }

   @Test
   @DisplayName("Calling getAuthorizedComponents with authorized user should return compont authorizations")
   void testGetAuthorizedComponentsWithAuthorizedUser() throws SQLException {
      String[] roles = {"PolisPlusGroep"};
      setupMockRequest();
      setupAuthCompTabelMocks();

      User usr = createUser(roles);

      List<ComponentAuthorization> components = getFixture().getAuthorizedComponents("Autorisaties", usr);
      assertThat(components).isNotNull().isNotEmpty().hasSize(3);
      for (ComponentAuthorization component : components) {
         assertThat(component).isNotNull();
         assertThat(component.getTitle()).isIn("Onderhoud Autorisaties", "AD Groepen", "Autorisatie Report");
      }
   }

   @Test
   @DisplayName("Calling isUserAuthorizedFor with unauthorized user should return false")
   void testIsUserAuthorizedForWithUnauthorizedUser() throws SQLException {
      String[] roles = {"UnknownGroup"};
      setupMockRequest();
      setupTabelMocks();
      setupAuthCompTabelMocks();

      User usr = createUser(roles);

      assertThat(getFixture().isUserAuthorizedFor(usr, AuthorizationType.TAB, "AD Groepen", "Autorisaties")).isFalse();
   }

   @Test
   @DisplayName("Calling isUserAuthorizedFor with authorized user should return true")
   void testIsUserAuthorizedForWithAuthorizedUser() throws SQLException {
      String[] roles = {"PolisPlusGroup"};
      setupMockRequest();
      setupTabelMocks();
      setupAuthCompTabelMocks();

      User usr = createUser(roles);

      assertThat(getFixture().isUserAuthorizedFor(usr, AuthorizationType.TAB, "AD Groepen", "Autorisaties")).isTrue();
   }

   @Test
   @DisplayName("Calling getADGroups should return data")
   void testGetADGroups() throws SQLException {
      // Setup mocks
      CsvMockResultSetFactory rsAdGroupFactory = super.createMockResultSetFactory("/data/adGroupDataSet.csv");
      ResultSet mockResultSetAdGroup = rsAdGroupFactory.getMockResultSet();

      when(getDataSourceMock().getConnection()).thenReturn(getConnectionMock());
      when(getConnectionMock().prepareStatement(startsWith("SELECT ADG.GROUP_NAME FROM PWS_AD_GROUPS"))).thenReturn(getPrepStatementMock());
      when(getPrepStatementMock().executeQuery()).thenReturn(mockResultSetAdGroup);

      List<String> components = getFixture().getADGroups();
      assertThat(components).isNotNull().isNotEmpty().hasSize(6)
         .contains("G-UG-PWS-GD-Contractbeheer",
            "G-UG-UWV-A-PLM-Configuratiebeheer", "G-UG-UWV-A-PLM-Functioneelbeheer", "PolisPlusGroup",
            "UWV SP G-UG-UWV-A-PLM-Configuratiebeheer", "UWV SP G-UG-UWV-A-PLM-Functioneelbeheer");
   }

   @Test
   @DisplayName("Calling getAppiId should return an Id")
   void testGetAppiId() throws SQLException {
      when(getDataSourceMock().getConnection()).thenReturn(getConnectionMock());
      when(getConnectionMock().prepareCall("{ ? = call PPLS_PWS00.GET_APPI_ID(?, ?, ?, ?) }")).thenReturn(getCallStatementMock());
      when(getCallStatementMock().getInt(1)).thenReturn(101101);

      assertThat(getFixture().getAppiId("prgId", "envName", "instanceName", "release")).isEqualTo(101101);
   }

   private User createUser(String[] roles) {
      User usr = new User();
      usr.setRoles(roles);
      usr.setUsername("tst");
      return usr;
   }

   private void setupMockRequest() {
      VaadinServletRequest request = mock(VaadinServletRequest.class);
      when(request.getServerName()).thenReturn("nl.uwv.test");
      when(request.getScheme()).thenReturn("https");
      when(request.getServerPort()).thenReturn(8080);
      AuthorizationService.setMockRequest(request );
   }

   private void setupTabelMocks() throws SQLException {
      // Setup mocks
      CsvMockResultSetFactory rsMenuFactory = super.createMockResultSetFactory("/data/menuDataSet.csv");
      CsvMockResultSetFactory rsAuthFactory = super.createMockResultSetFactory("/data/authDataSet.csv");
      ResultSet mockResultSetMenu = rsMenuFactory.getMockResultSet();
      ResultSet mockResultSetAuth = rsAuthFactory.getMockResultSet();

      when(getDataSourceMock().getConnection()).thenReturn(getConnectionMock());
      when(getConnectionMock().prepareStatement(startsWith("SELECT * FROM PWS_MENU"))).thenReturn(getPrepStatementMock());
      when(getPrepStatementMock().executeQuery()).thenReturn(mockResultSetMenu);

      when(getConnectionMock().prepareCall("{ ? = call PPLS_PWS00.GET_OBJECT_GROUPS(?,?,?) }")).thenReturn(getCallStatementMock());
      when(getCallStatementMock().getObject(1)).thenReturn(mockResultSetAuth);

      doAnswer((Answer<Void>) i -> setMockFilterAuth(rsAuthFactory, i))
         .when(getCallStatementMock()).setString(anyInt(), anyString());
   }

   private Void setMockFilterAuth(final CsvMockResultSetFactory rsFactory, final InvocationOnMock invocationOnMock) {
      final String[] headers = {"TYPE", "NAAM", "PARENT" };
      int index = invocationOnMock.getArgument(0);
      if (index == 2) {
         rsFactory.clearFilter();
      }
      rsFactory.addFilter(headers[index-2], invocationOnMock.getArgument(1));
      return null;
   }

   private void setupAuthCompTabelMocks() throws SQLException {
      // Setup mocks
      CsvMockResultSetFactory rsAuthCompFactory = super.createMockResultSetFactory("/data/authCompDataSet.csv");
      ResultSet mockResultSetAuthComp = rsAuthCompFactory.getMockResultSet();
      PreparedStatement mockStatementAuthComp = mock(PreparedStatement.class);

      when(getDataSourceMock().getConnection()).thenReturn(getConnectionMock());
      when(getConnectionMock()
            .prepareStatement(startsWith("SELECT aobj.ID, aobj.TYPE, aobj.NAAM, RTRIM(XMLAGG(XMLELEMENT")))
            .thenReturn(mockStatementAuthComp);
      when(mockStatementAuthComp.executeQuery()).thenReturn(mockResultSetAuthComp);

      doAnswer((Answer<Void>) i -> setMockFilterAuthComp(rsAuthCompFactory, i))
         .when(getCallStatementMock()).setString(anyInt(), anyString());

   }

   private Void setMockFilterAuthComp(final CsvMockResultSetFactory rsFactory, final InvocationOnMock invocationOnMock) {
      int index = invocationOnMock.getArgument(0);
      if (index == 1) {
         rsFactory.clearFilter();
         rsFactory.addFilter("PAGE", invocationOnMock.getArgument(1));
      }
      return null;
   }

   @Override
   protected AuthorizationService createService(DataSource dataSourceMock) {
      try {
         SimpleNamingContextBuilder.emptyActivatedContextBuilder();
         Context contextMock = mock(Context.class);
         when(contextMock.lookup("authorisationDataSource")).thenReturn("DSNAME");
         when(contextMock.lookup("menuContextRoot")).thenReturn("/webapps/test");
         Context context = new InitialContext();
         context.bind("java:comp/env", contextMock);
      } catch (NamingException e) {
         throw new RuntimeException("Context setup failed", e);
      }
      AuthorizationService service = AuthorizationService.get();
      service.setDataSource(dataSourceMock);

      return service;
   }
}
