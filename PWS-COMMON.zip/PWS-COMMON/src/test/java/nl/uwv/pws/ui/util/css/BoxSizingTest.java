package nl.uwv.pws.ui.util.css;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;

import static org.assertj.core.api.Assertions.assertThat;

class BoxSizingTest {
   @DisplayName("Iedere BoxSizing heeft een value")
   @ParameterizedTest(name = "[{index}] BoxSizing: {0}")
   @EnumSource(BoxSizing.class)
   void test(final BoxSizing boxSizing) {
      assertThat(boxSizing.getValue()).isNotEmpty();
   }
}
