package nl.uwv.pws.ui.validator;

import com.vaadin.flow.data.binder.ValidationResult;
import com.vaadin.flow.data.binder.ValueContext;
import nl.uwv.pws.ui.model.BsnNumber;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static com.vaadin.flow.data.binder.ErrorLevel.ERROR;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatIllegalStateException;

class BsnValidatorTest {
   private final BsnValidator bsnValidator = new BsnValidator();

   @Test
   @DisplayName("Valide BSN nummer komt door de validator")
   void validBsnValidatesWithoutError() {
      ValidationResult result = bsnValidator.apply(new BsnNumber("201500097"), new ValueContext());
      assertThat(result).isNotNull();
      assertThat(result.isError()).isFalse();
      assertThat(result.getErrorLevel()).isEmpty();
      assertThatIllegalStateException().isThrownBy(result::getErrorMessage);
   }

   @Test
   @DisplayName("Validatie faalt op nummer dat niet door de elf-proef komt")
   void elfProefFailsValidation() {
      ValidationResult result = bsnValidator.apply(new BsnNumber("201500096"), new ValueContext());
      assertThat(result).isNotNull();
      assertThat(result.isError()).isTrue();
      assertThat(result.getErrorLevel()).hasValue(ERROR);
      assertThat(result.getErrorMessage()).isEqualTo("Fout : PWS-0001, Ingevoerd nummer voldoet niet aan elf-proef");
   }

   @Test
   @DisplayName("Validatie faalt op lege waarde")
   void emptyBsnFailsValidation() {
      ValidationResult result = bsnValidator.apply(new BsnNumber(""), new ValueContext());
      assertThat(result).isNotNull();
      assertThat(result.isError()).isTrue();
      assertThat(result.getErrorLevel()).hasValue(ERROR);
      assertThat(result.getErrorMessage()).isEqualTo("Fout : PWS-0015, Veld is verplicht");
   }

   @Test
   @DisplayName("Validatie faalt op niet-numerieke waarde")
   void nonNumericFailsValidation() {
      ValidationResult result = bsnValidator.apply(new BsnNumber("abcdefghi"), new ValueContext());
      assertThat(result).isNotNull();
      assertThat(result.isError()).isTrue();
      assertThat(result.getErrorLevel()).hasValue(ERROR);
      assertThat(result.getErrorMessage()).isEqualTo("Fout : PWS-0002, Ingevoerd nummer is niet numeriek");
   }
}
