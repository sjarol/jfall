package nl.uwv.pws.ui;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class AppRuntimeExceptionTest {
   @Test
   @DisplayName("Constructieparameters blijven bewaard")
   void testConstruction() {
      AppRuntimeException appRuntimeException = new AppRuntimeException("Test Message");
      assertThat(appRuntimeException.getMessage()).isEqualTo("Test Message");

      Throwable t = new Throwable("Test Throwable");
      appRuntimeException = new AppRuntimeException(t);
      assertThat(appRuntimeException.getCause()).isSameAs(t);

      appRuntimeException = new AppRuntimeException("Another Test Message", t);
      assertThat(appRuntimeException.getMessage()).isEqualTo("Another Test Message");
      assertThat(appRuntimeException.getCause()).isSameAs(t);

      appRuntimeException = new AppRuntimeException("Yet Another Test Message", t, true, true);
      assertThat(appRuntimeException.getMessage()).isEqualTo("Yet Another Test Message");
      assertThat(appRuntimeException.getCause()).isSameAs(t);
   }
}
