package nl.uwv.pws.backend.dao;

import com.openpojo.reflection.PojoClass;
import com.openpojo.reflection.impl.PojoClassFactory;
import com.openpojo.validation.ValidatorBuilder;
import com.openpojo.validation.test.impl.GetterTester;
import com.openpojo.validation.test.impl.SetterTester;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class PageAuthorizationTest {
   @Test
   @DisplayName("Getters en Setters werken volgens verwachting")
   void gettersAndSetters() {
      // Test getters
      PojoClass pojoclass = PojoClassFactory.getPojoClass(PageAuthorization.class);
      ValidatorBuilder.create()
            .with(new GetterTester())
            .with(new SetterTester())
            .build()
            .validate(pojoclass);
   }

   @Test
   @DisplayName("Page-getters leveren de waarden uit onderliggende page terug")
   void testPageGetters() {
      MenuPage menuPage = new MenuPage();
      menuPage.setName("Page Name");
      menuPage.setIconName("Icon Name");
      menuPage.setUrl("Page URL");
      PageAuthorization pageAuthorization = new PageAuthorization(menuPage, "ADMIN", "EDITOR");
      assertThat(pageAuthorization.getName()).isEqualTo("Page Name");
      assertThat(pageAuthorization.getIconName()).isEqualTo("Icon Name");
      assertThat(pageAuthorization.getUrl()).isEqualTo("Page URL");
      assertThat(pageAuthorization.getRoles()).containsExactly("ADMIN", "EDITOR");
   }
}
