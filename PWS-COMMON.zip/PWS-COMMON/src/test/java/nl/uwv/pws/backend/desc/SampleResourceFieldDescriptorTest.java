package nl.uwv.pws.backend.desc;

import nl.uwv.pws.backend.types.Field;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Objects;

import static org.assertj.core.api.Assertions.assertThat;

class SampleResourceFieldDescriptorTest {
   @Test
   void construct() {
      SampleResourceFieldDescriptor incidentLog = SampleResourceFieldDescriptor.INCIDENTLOG;
      assertThat(incidentLog.getNrOfColumns()).isEqualTo(5);
      assertThat(incidentLog.getColumnNames()).containsExactly(
            "INCIDENT_NO", "LOGGED_BY", "LOGGED_ON", "STACKTRACE", "THREAD_DUMP"
      );
      Arrays.stream(incidentLog.getColumnDataTypes()).forEach(dt -> assertThat(dt).isEqualTo("String"));
      assertThat(incidentLog.toString()).isEqualTo(
            "FieldDescriptor{|[Field{INCIDENT_NO|String|Incident id#|id|200px|Attributes{width:l,sort,property:id}}, "
                  + "Field{LOGGED_BY|String|Gebruiker|by|200px|Attributes{width:l,sort,property:by}}, "
                  + "Field{LOGGED_ON|String|Datumtijd gelogd|on|200px|Attributes{width:l,sort,property:on}}, "
                  + "Field{STACKTRACE|String|STACKTRACE||120px|Attributes{hidden}}, "
                  + "Field{THREAD_DUMP|String|THREAD_DUMP||120px|Attributes{hidden}}]}"
      );

      assertThat(Objects.requireNonNull(incidentLog.getField(2)).getLabel()).isEqualTo("Datumtijd gelogd");
      assertThat(Objects.requireNonNull(incidentLog.getField(3)).getLabel()).isEqualTo("STACKTRACE");
      assertThat(Objects.requireNonNull(incidentLog.getField(4)).getLabel()).isEqualTo("THREAD_DUMP");

      Field field = incidentLog.getField(0);
      assertThat(field).isNotNull();
      assertThat(field.getName()).isEqualTo("INCIDENT_NO");
      assertThat(field.getLabel()).isEqualTo("Incident id#");
      assertThat(field.getFlexGrow()).isEqualTo(2);
      assertThat(field.getProperty()).isEqualTo("id");
      assertThat(field.isSortable()).isTrue();
      assertThat(field.isHidden()).isFalse();
      assertThat(field.usePlain()).isFalse();
      assertThat(field.getWidth()).isEqualTo("200px");
      assertThat(field.getType()).isEqualTo("String");
      assertThat(field.toString())
            .isEqualTo("Field{INCIDENT_NO|String|Incident id#|id|200px|Attributes{width:l,sort,property:id}}");
      assertThat(field.getFieldDescription()).isNull();

      field = incidentLog.getField(1);
      assertThat(field).isNotNull();
      assertThat(field.getName()).isEqualTo("LOGGED_BY");
      assertThat(field.getLabel()).isEqualTo("Gebruiker");
      assertThat(field.getFlexGrow()).isEqualTo(2);
      assertThat(field.getProperty()).isEqualTo("by");
      assertThat(field.isSortable()).isTrue();
      assertThat(field.isHidden()).isFalse();
      assertThat(field.usePlain()).isFalse();
      assertThat(field.getWidth()).isEqualTo("200px");
      assertThat(field.getType()).isEqualTo("String");
      assertThat(field.toString())
            .isEqualTo("Field{LOGGED_BY|String|Gebruiker|by|200px|Attributes{width:l,sort,property:by}}");
      assertThat(field.getFieldDescription()).isNull();

      field = incidentLog.getField(2);
      assertThat(field).isNotNull();
      assertThat(field.getName()).isEqualTo("LOGGED_ON");
      assertThat(field.getLabel()).isEqualTo("Datumtijd gelogd");
      assertThat(field.getFlexGrow()).isEqualTo(2);
      assertThat(field.getProperty()).isEqualTo("on");
      assertThat(field.isSortable()).isTrue();
      assertThat(field.isHidden()).isFalse();
      assertThat(field.usePlain()).isFalse();
      assertThat(field.getWidth()).isEqualTo("200px");
      assertThat(field.getType()).isEqualTo("String");
      assertThat(field.toString())
            .isEqualTo("Field{LOGGED_ON|String|Datumtijd gelogd|on|200px|Attributes{width:l,sort,property:on}}");
      assertThat(field.getFieldDescription()).isNull();

      field = incidentLog.getField(3);
      assertThat(field).isNotNull();
      assertThat(field.getName()).isEqualTo("STACKTRACE");
      assertThat(field.getLabel()).isEqualTo("STACKTRACE");
      assertThat(field.getFlexGrow()).isEqualTo(1);
      assertThat(field.getProperty()).isEqualTo("");
      assertThat(field.isSortable()).isFalse();
      assertThat(field.isHidden()).isTrue();
      assertThat(field.usePlain()).isFalse();
      assertThat(field.getWidth()).isEqualTo("120px");
      assertThat(field.getType()).isEqualTo("String");
      assertThat(field.toString())
            .isEqualTo("Field{STACKTRACE|String|STACKTRACE||120px|Attributes{hidden}}");
      assertThat(field.getFieldDescription()).isNull();

      field = incidentLog.getField(4);
      assertThat(field).isNotNull();
      assertThat(field.getName()).isEqualTo("THREAD_DUMP");
      assertThat(field.getLabel()).isEqualTo("THREAD_DUMP");
      assertThat(field.getFlexGrow()).isEqualTo(1);
      assertThat(field.getProperty()).isEqualTo("");
      assertThat(field.isSortable()).isFalse();
      assertThat(field.isHidden()).isTrue();
      assertThat(field.usePlain()).isFalse();
      assertThat(field.getWidth()).isEqualTo("120px");
      assertThat(field.getType()).isEqualTo("String");
      assertThat(field.toString())
            .isEqualTo("Field{THREAD_DUMP|String|THREAD_DUMP||120px|Attributes{hidden}}");
      assertThat(field.getFieldDescription()).isNull();

      assertThat(incidentLog.getField(5)).isNull();


      /*
Field( "INCIDENT_NO", "Incident id#", "width:L,sort,property:id" )
Field( "LOGGED_BY", "Gebruiker", "width:L,sort,property:by" )
Field( "LOGGED_ON", "Datumtijd gelogd", "width:L,sort,property:on" )
Field( "STACKTRACE", "" , "hidden" )
Field( "THREAD_DUMP", "" , "hidden" )

       */
   }

}
