package nl.uwv.pws.backend.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.startsWith;
import static org.mockito.Mockito.*;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.opencsv.exceptions.CsvValidationException;
import com.vaadin.flow.data.provider.QuerySortOrder;
import com.vaadin.flow.data.provider.SortDirection;

import nl.uwv.pws.common.testutils.CsvMockResultSetFactory;
import nl.uwv.pws.dataprovider.SortStringGenerator;

class ListBoxServiceTest {
   private static final String DSNAME = "nl.uwv.testDS";
   private static final String VIEWNAME = "TEST_VW";
   private static final String COLUMNNAME = "TEST_COL";

   @Test
   @DisplayName("Calling getDataSource should return datasource from Context")
   void testGetDataSource() throws NamingException {
      TestListBoxService service = new TestListBoxService(DSNAME, VIEWNAME, COLUMNNAME);
      DataSource testDS = mock(DataSource.class);
      when(service.getInitialContext().lookup(DSNAME)).thenReturn(testDS);

      assertThat(service.getDataSource()).isSameAs(testDS);
   }

   @Test
   @DisplayName("Calling fetchRows returns expected rows")
   void testFetchRows() throws SQLException, CsvValidationException, IOException, NamingException {
      // Use CSV file as source for the ResultSet
      CsvMockResultSetFactory factory = new CsvMockResultSetFactory(getClass(), "/data/peopleListBoxDataSet.csv");
      ResultSet mockResultSet = factory.getMockResultSet();

      String column = "LAST_NAME";
      TestListBoxService service = new TestListBoxService(DSNAME, VIEWNAME, column);

      // Setup mocks
      when(service.getInitialContext().lookup(DSNAME)).thenReturn(service.getDataSourceMock());
      when(service.getDataSourceMock().getConnection()).thenReturn(service.getConnectionMock());
      when(service.getConnectionMock().prepareStatement(startsWith("SELECT DISTINCT"))).thenReturn(service.getStatementMock());
      when(service.getStatementMock().executeQuery()).thenReturn(mockResultSet);

      List<String> elements = service.fetchRows("", 50, 0, null);

      assertThat(elements).isNotNull().containsExactly("Gordon", "Kelly", "Moreno", "Perkins", "Smith");
   }

   @Test
   @DisplayName("Calling countRows returns expected number of rows")
   void testCountRows() throws SQLException, NamingException {
      ResultSet mockResultSet = mock(ResultSet.class);
      long rowCount = 5;
      TestListBoxService service = new TestListBoxService(DSNAME, VIEWNAME, "LAST_NAME");

      // Setup mocks
      when(service.getInitialContext().lookup(DSNAME)).thenReturn(service.getDataSourceMock());
      when(service.getDataSourceMock().getConnection()).thenReturn(service.getConnectionMock());
      when(service.getConnectionMock().prepareStatement(startsWith("SELECT COUNT"))).thenReturn(service.getStatementMock());
      when(service.getStatementMock().executeQuery()).thenReturn(mockResultSet);
      when(mockResultSet.next()).thenReturn(true).thenReturn(false);
      when(mockResultSet.getLong(1)).thenReturn(rowCount);

      long size = service.countRows("dummy");
      assertThat(size).isEqualTo(rowCount);

   }

   @Test
   @DisplayName("Calling countRows returns zero when resultset next returns false")
   void testCountEmptyRows() throws SQLException, NamingException {
      ResultSet mockResultSet = mock(ResultSet.class);
      long rowCount = 0;
      TestListBoxService service = new TestListBoxService(DSNAME, VIEWNAME, "LAST_NAME");

      // Setup mocks
      when(service.getInitialContext().lookup(DSNAME)).thenReturn(service.getDataSourceMock());
      when(service.getDataSourceMock().getConnection()).thenReturn(service.getConnectionMock());
      when(service.getConnectionMock().prepareStatement(startsWith("SELECT COUNT"))).thenReturn(service.getStatementMock());
      when(service.getStatementMock().executeQuery()).thenReturn(mockResultSet);
      when(mockResultSet.next()).thenReturn(false).thenReturn(false);
      when(mockResultSet.getLong(1)).thenReturn(rowCount);

      long size = service.countRows("%");
      assertThat(size).isEqualTo(rowCount);

      verify(mockResultSet).next();              // Make sure next() has been called once
      verify(mockResultSet, never()).getLong(1); // Make sure getLong(1) was never called
   }

   @Test
   @DisplayName("Calling createSelectStatement with custom SortStringGenerator to order null values first")
   void testSetSortStringGenerator() {
      String expectedSelect = "SELECT DISTINCT " + COLUMNNAME
            + " FROM " + VIEWNAME
            + " WHERE " + COLUMNNAME + " like ?"
            + "  order by " + COLUMNNAME + " asc nulls first"
            + " OFFSET ? ROWS FETCH NEXT ? ROWS ONLY";
      TestListBoxService service = new TestListBoxService(DSNAME, VIEWNAME, COLUMNNAME);
      SortStringGenerator sort = new SortStringGenerator();
      service.setSortStringGenerator(sort.withNullsFirst());

      assertThat(service.createSelectStatement(service.createSortOrderList(null)))
         .isEqualTo(expectedSelect );
   }

   @Test
   @DisplayName("Calling createSelectStatement with custom sort order")
   void testCreateSelectStatementWithSort() {
      String sortColumn = "COL1";
      String expectedSelect = "SELECT DISTINCT " + COLUMNNAME
            + " FROM " + VIEWNAME
            + " WHERE " + COLUMNNAME + " like ?"
            + "  order by " + sortColumn + " desc"
            + " OFFSET ? ROWS FETCH NEXT ? ROWS ONLY";
      TestListBoxService service = new TestListBoxService(DSNAME, VIEWNAME, COLUMNNAME);

      List<QuerySortOrder> sortList = new ArrayList<>();
      sortList.add(new QuerySortOrder(sortColumn, SortDirection.DESCENDING));

      assertThat(service.createSelectStatement(sortList))
         .isEqualTo(expectedSelect );
   }

   @Test
   @DisplayName("Calling createCountStatement")
   void testCreateCountStatement() {
      String expectedSelect = "SELECT COUNT(DISTINCT " + COLUMNNAME + ")"
            + " FROM " + VIEWNAME
            + " WHERE " + COLUMNNAME + " like ? ";
      TestListBoxService service = new TestListBoxService(DSNAME, VIEWNAME, COLUMNNAME);

      assertThat(service.createCountStatement())
         .isEqualTo(expectedSelect );
   }


   @SuppressWarnings("serial")
   static class TestListBoxService extends ListBoxServiceImpl {
      private final InitialContext mockContext = mock(InitialContext.class);
      private final DataSource dataSourceMock = mock(DataSource.class);
      private final Connection connectionMock = mock(Connection.class);
      private final PreparedStatement statementMock = mock(PreparedStatement.class);

      public TestListBoxService(String dataSourceName, String viewName, String columnName) {
         super(dataSourceName, viewName, columnName);
      }

      @Override
      protected Context getInitialContext() {
         return mockContext;
      }

      public DataSource getDataSourceMock() {
         return dataSourceMock;
      }

      public Connection getConnectionMock() {
         return connectionMock;
      }

      public PreparedStatement getStatementMock() {
         return statementMock;
      }

   }

}
