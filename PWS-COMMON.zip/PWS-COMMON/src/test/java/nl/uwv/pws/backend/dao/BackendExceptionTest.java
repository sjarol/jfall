package nl.uwv.pws.backend.dao;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class BackendExceptionTest {
   @Test
   @DisplayName("Constructieparameters blijven bewaard")
   void testConstruction() {
      BackendException backendException = new BackendException("Test Message");
      assertThat(backendException.getMessage()).isEqualTo("Test Message");

      Throwable t = new Throwable("Test Throwable");
      backendException = new BackendException(t);
      assertThat(backendException.getCause()).isSameAs(t);

      backendException = new BackendException("Another Test Message", t);
      assertThat(backendException.getMessage()).isEqualTo("Another Test Message");
      assertThat(backendException.getCause()).isSameAs(t);

      backendException = new BackendException("Yet Another Test Message", t, true, true);
      assertThat(backendException.getMessage()).isEqualTo("Yet Another Test Message");
      assertThat(backendException.getCause()).isSameAs(t);
   }
}
