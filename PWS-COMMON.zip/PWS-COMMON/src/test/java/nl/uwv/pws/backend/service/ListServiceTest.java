package nl.uwv.pws.backend.service;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.vaadin.flow.data.provider.QuerySortOrder;
import com.vaadin.flow.data.provider.SortDirection;

import nl.uwv.pws.backend.dao.SqlFilter;
import nl.uwv.pws.backend.desc.FieldDescriptor;
import nl.uwv.pws.backend.desc.SampleResourceFieldDescriptor;
import nl.uwv.pws.dataprovider.SortStringGenerator;

class ListServiceTest {

   @Test
   @DisplayName("Calling createSelectStatement with custom SortStringGenerator to order null values first")
   void testSetSortStringGenerator() {
      String expectedSelect = "SELECT * FROM INCIDENT"
            + " WHERE '1' = ?"
            + " order by ID desc nulls first"
            + " OFFSET ? ROWS FETCH NEXT ? ROWS ONLY";
      TestListService service = new TestListService("dummy");
      SortStringGenerator sort = new SortStringGenerator();
      service.setSortStringGenerator(sort.withNullsFirst());

      assertThat(service.createSelectStatement(new TestFilter(), service.createSortOrderList(null)))
         .isEqualTo(expectedSelect );
   }

   @Test
   @DisplayName("Calling createSelectStatement with custom sort order")
   void testCreateSelectStatementWithSort() {
      String expectedSelect = "SELECT * FROM INCIDENT"
            + " WHERE '1' = ?"
            + " order by COL1 asc"
            + " OFFSET ? ROWS FETCH NEXT ? ROWS ONLY";
      TestListService service = new TestListService("dummy");
      
      List<QuerySortOrder> sortList = service.getSortOrders();
      sortList.add(new QuerySortOrder("COL1", SortDirection.ASCENDING));

      assertThat(service.createSelectStatement(new TestFilter(), sortList))
         .isEqualTo(expectedSelect );
   }

   @Test
   @DisplayName("Calling createSelectStatement with Group By expression set")
   void testCreateSelectStatementWithGroupBy() {
      String expectedSelect = "SELECT COL2, MIN(COL1) FROM INCIDENT"
            + " WHERE '1' = ?"
            + " GROUP BY COL2"
            + " order by ID desc"
            + " OFFSET ? ROWS FETCH NEXT ? ROWS ONLY";
      TestListService service = new TestListService("dummy");
      service.setGroupBy("COL2, MIN(COL1)", "COL2");

      assertThat(service.createSelectStatement(new TestFilter(), service.createSortOrderList(null)))
         .isEqualTo(expectedSelect );
   }

   @Test
   @DisplayName("Calling createCountStatement")
   void testCreateCountStatement() {
      String expectedSelect = "SELECT COUNT(*) FROM INCIDENT"
            + " WHERE '1' = ?";
      TestListService service = new TestListService("dummy");

      assertThat(service.createCountStatement(new TestFilter()))
         .isEqualTo(expectedSelect );
   }

   @Test
   @DisplayName("Calling createCountStatement with Group By expression set")
   void testCreateCountStatementWithGroupBy() {
      String expectedSelect = "SELECT COUNT(*) FROM "
            + "( SELECT COL2 FROM INCIDENT"
            + " WHERE '1' = ?"
            + " GROUP BY COL2)";
      TestListService service = new TestListService("dummy");
      service.setGroupBy("COL2, MIN(COL1)", "COL2");

      assertThat(service.createCountStatement(new TestFilter()))
         .isEqualTo(expectedSelect );
   }


   @SuppressWarnings("serial")
   class TestListService extends AbstractListService {

      protected TestListService(String dataSourceName) {
         super(dataSourceName);
      }

      @Override
      protected String getViewName() {
         return "INCIDENT";
      }

      @Override
      public FieldDescriptor getDescriptor() {
         return SampleResourceFieldDescriptor.INCIDENTLOG;
      }

      @Override
      protected QuerySortOrder getDefaultSortOrder() {
         return new QuerySortOrder("ID", SortDirection.DESCENDING);
      }
      
   }
   
   class TestFilter implements SqlFilter {

      @Override
      public String getFilterSql() {
         return "'1' = ?";
      }

      @Override
      public int getParametersSize() {
         return 1;
      }

      @Override
      public String getParameter(int index) {
         return "1";
      }
      
   }
}
