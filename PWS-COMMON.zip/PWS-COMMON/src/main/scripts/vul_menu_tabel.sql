PROMPT Aanvullen tabel PPLS_PLMAPPMUT.PWS_MENU
BEGIN
   INSERT INTO PPLS_PLMAPPMUT.PWS_MENU(MNU_CD,NAAM,ICON,URL,OMSCHRIJVING) VALUES
      ('PWS90', 'Autorisaties', 'KEY', '/autorisaties', 'PWS: beheer autorisaties/AD-groepen');
   COMMIT;
END;
/
