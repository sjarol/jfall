package nl.uwv.pws.ui.util;

import nl.uwv.pws.backend.validator.DateValidator;
import nl.uwv.pws.backend.validator.DateValidatorUsingDateTimeFormatter;
import org.apache.commons.lang3.time.FastDateFormat;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.ResolverStyle;
import java.util.Date;

public final class DateUtils {
   public static final String ORA_DATEFORMAT = "yyyy-MM-dd";

   private static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ISO_DATE_TIME
         .withResolverStyle(ResolverStyle.STRICT);
   private static final DateValidator VALIDATOR = new DateValidatorUsingDateTimeFormatter(DATE_TIME_FORMATTER);

   private DateUtils() {
      // Do not construct
   }

   public static String localDateToOraDateConstant(final LocalDate date) {
      if (date == null) {
         return null;
      }
      final FastDateFormat df = FastDateFormat.getInstance(ORA_DATEFORMAT);
      return " DATE '" + df.format(Date.from(date.atStartOfDay(ZoneId.systemDefault()).toInstant())) + "'";
   }

   public static boolean isValid(final LocalDateTime localDateTime) {
      return VALIDATOR.isValid(localDateTime);
   }
}
