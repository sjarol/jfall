package nl.uwv.pws.backend.types;

import java.io.Serializable;

public class FieldDescription implements Serializable {

   private String providerId;
   private String categorie;

   public FieldDescription(final String providerId, final String categorie) {
      this.providerId = providerId;
      this.categorie = categorie;
   }

   /**
    * @return the providerId
    */
   public String getProviderId() {
      return providerId;
   }

   /**
    * @return the categorie
    */
   public String getCategorie() {
      return categorie;
   }

   @Override
   public String toString() {
      return "FieldDescription [providerId=" + providerId + ", categorie=" + categorie + "]";
   }
}
