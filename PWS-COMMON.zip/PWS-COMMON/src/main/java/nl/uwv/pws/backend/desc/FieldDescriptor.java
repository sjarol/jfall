package nl.uwv.pws.backend.desc;

import java.util.ArrayList;
import java.util.Arrays;

import nl.uwv.pws.backend.types.Field;

public class FieldDescriptor {
   private final Field[] fields;

   public final Field[] getFields() {
      return fields;
   }

   protected FieldDescriptor() {
      this.fields = new Field[0];
   }

   protected FieldDescriptor(final Field[] fields) {
      this.fields = fields;
   }

   public final int getNrOfColumns() {
      return getFields().length;
   }

   public String[] getColumnNames() {
      ArrayList<String> columns = new ArrayList<>();
      for (Field f : getFields()) {
         columns.add(f.getName());
      }
      return columns.toArray(new String[0]);
   }

   public String[] getColumnDataTypes() {
      ArrayList<String> dataTypes = new ArrayList<>();
      for (Field f : getFields()) {
         dataTypes.add(f.getType());
      }
      return dataTypes.toArray(new String[0]);
   }

   public final Field getField(final int i) {
      if (i < fields.length) {
         return fields[i];
      }
      return null;
   }

   @Override
   public String toString() {
      final StringBuilder sb = new StringBuilder("FieldDescriptor{");
      sb.append("|").append(fields == null ? "null" : Arrays.asList(fields).toString());
      sb.append('}');
      return sb.toString();
   }
}
