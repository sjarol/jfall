package nl.uwv.pws.ui.views;

import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.dependency.HtmlImport;
import com.vaadin.flow.component.html.H1;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.login.AbstractLogin.LoginEvent;
import com.vaadin.flow.component.login.LoginI18n;
import com.vaadin.flow.component.login.LoginOverlay;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.notification.Notification.Position;
import com.vaadin.flow.component.notification.NotificationVariant;
import com.vaadin.flow.component.page.Viewport;
import com.vaadin.flow.router.BeforeEnterEvent;
import com.vaadin.flow.router.BeforeEnterObserver;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.server.VaadinServletRequest;

import nl.uwv.pws.backend.dao.BackendException;
import nl.uwv.pws.backend.dao.User;
import nl.uwv.pws.backend.lomo.LomoLogMessage;
import nl.uwv.pws.backend.lomo.LomoLogMessage.LomoResult;
import nl.uwv.pws.backend.lomo.LomoLogMessage.LomoTransaction;
import nl.uwv.pws.backend.service.LomoLogService;
import nl.uwv.pws.backend.service.UniqueSessionManager;
import nl.uwv.pws.backend.service.UserService;
import nl.uwv.pws.ui.util.UIUtils;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import java.util.Collections;
import java.util.Optional;
import java.util.regex.Pattern;

/*
 * Onderstaande tag zou gebruikt kunnen worden icm spring-security
 * Tag("sa-login-view")
 */
@Route(value = LoginView.ROUTE)
@PageTitle(LoginView.TITLE)
@HtmlImport("frontend://bower_components/vaadin-lumo-styles/presets/compact.html")
@Viewport("width=device-width, minimum-scale=1.0, initial-scale=1.0, user-scalable=yes")
public class LoginView extends ViewFrame implements BeforeEnterObserver {
   private static final Logger LOG = LogManager.getLogger(LoginView.class);

   private static final int NOTIFICATION_DURATION = 10000;
   private static final Pattern USERNAME_PATTERN = Pattern.compile("^[a-z]{3}[0-9]{3}");

   private static final String USR_LABEL = "USER";

   private static final String LOGIN_AKTIE = "Gebruiker login";

   protected static final String ROUTE = "login";
   protected static final String TITLE = "Login Polis+";

   private final LoginOverlay login = new LoginOverlay();

   public LoginView() {
      H1 title = new H1();
      Label titleLabel = UIUtils.createH1Label("PWS");
      Image logo = new Image(UIUtils.IMG_PATH + "uwvLogo1RGB.svg", "");
      logo.setAlt("UWV logo");
      logo.getStyle().set("flex-shrink", "0");
      logo.getStyle().set("height", "96px");
      logo.getStyle().set("margin-left", "var(--lumo-space-m)");
      logo.getStyle().set("width", "96px");

      title.getStyle().set("color", "var(--lumo-base-color)");
      title.getStyle().set("display", "flex");
      title.getStyle().set("flex-direction", "row");
      title.getStyle().set("align-items", "center");
      title.getStyle().set("justify-content", "center");

      titleLabel.setWidthFull();
      title.add(titleLabel, logo);

      login.setTitle(title);
      login.setI18n(createNlI18n());
      login.setForgotPasswordButtonVisible(false);

      login.addLoginListener(this::login);

      login.setOpened(true);
   }

   private void login(final LoginEvent event) {
      boolean duplicateLogin = false;
      HttpServletRequest request = VaadinServletRequest.getCurrent();
      String userName = event.getUsername();
      String remoteUser = request.getRemoteUser();

      try {
         if (StringUtils.equalsIgnoreCase(remoteUser, userName)) {
            LOG.warn("Gebruiker was al ingelogd.");
         } else if (remoteUser != null) {
            duplicateLogin = true;
         } else {
            request.login(userName, event.getPassword());
            duplicateLogin = (UniqueSessionManager.get().hasActiveSession(userName)
                  && !UniqueSessionManager.get().isActiveSession(userName));
         }
         if (duplicateLogin) {
            handleDuplicateLogin(userName);
         } else {
            Optional<User> optionalUser = UserService.get().login(userName);
            if (optionalUser.isPresent()) {
               User user = optionalUser.get();
               handleLogin(user);
            } else {
               handleNoRoles(event);
            }
         }
      } catch (BackendException e) {
         UIUtils.handleError(e);
      } catch (ServletException e) {
         LOG.warn("Login faalt voor user: " + userName);
         if (!StringUtils.contains(e.getMessage(), "Authentication")) {
            UIUtils.handleError(e);
         }
         handleLoginFailure(e, userName);
      } finally {
         if (!login.isError()) {
            login.close();
         }
      }
   }

   private void handleLogin(final User user) {
      LomoLogService.getInstance().addLomoLog(TITLE,
            new LomoLogMessage(LOGIN_AKTIE, LomoTransaction.LOGIN, LomoResult.OK, "").addDetail(USR_LABEL,
                  user.getUsername()));

      UniqueSessionManager.get().insertCurrentUserSession(user.getUsername());
      UI.getCurrent().navigate(Dashboard.class);
   }

   private void handleLoginFailure(final ServletException e, final String userName) {
      if (StringUtils.isAlphanumeric(userName) && USERNAME_PATTERN.matcher(userName.toLowerCase()).matches()) {
         LomoLogService.getInstance().addLomoLog(TITLE,
               new LomoLogMessage(LOGIN_AKTIE, LomoTransaction.LOGIN, LomoResult.ERROR, e.getMessage())
                     .addDetail(USR_LABEL, userName));
      }
      login.setError(true);
   }

   private void handleNoRoles(final LoginEvent event) {
      String userHasNoRoles = "Gebruiker (" + event.getUsername() + ") heeft geen (PWS) rollen";

      LomoLogService.getInstance().addLomoLog(TITLE,
            new LomoLogMessage(LOGIN_AKTIE, LomoTransaction.LOGIN, LomoResult.ERROR, userHasNoRoles)
                  .addDetail(USR_LABEL, event.getUsername()));
      showMessage(userHasNoRoles);
      login.setError(true);
   }

   private void handleDuplicateLogin(final String userName) {
      String duplicateSession = "Dubbele aanmelding, uw sessie is verlopen omdat meerdere " +
            "aanmeldingen zijn gedetecteerd";

      LomoLogService.getInstance().addLomoLog(TITLE,
            new LomoLogMessage(LOGIN_AKTIE, LomoTransaction.LOGIN, LomoResult.ERROR, duplicateSession)
                  .addDetail(USR_LABEL, userName));

      UniqueSessionManager.get().insertUserLoginSession(userName);
      UI.getCurrent().navigate(DuplicateLoginView.class, userName);
   }

   private void showMessage(final String message) {
      LOG.warn(message);

      Notification.show(message, NOTIFICATION_DURATION, Position.BOTTOM_START)
            .addThemeVariants(NotificationVariant.LUMO_PRIMARY);
   }

   private LoginI18n createNlI18n() {
      final LoginI18n i18n = LoginI18n.createDefault();

      i18n.setHeader(new LoginI18n.Header());
      i18n.getHeader().setTitle("Login");
      i18n.getHeader().setDescription("Polis+ Webschermen");
      i18n.getForm().setUsername("Gebruikersnaam");
      i18n.getForm().setTitle("Log in");
      i18n.getForm().setSubmit("Log in");
      i18n.getForm().setPassword("Wachtwoord");
      i18n.getForm().setForgotPassword(null);
      i18n.getErrorMessage().setTitle("Ongeldig Gebruikersnaam/wachtwoord");
      i18n.getErrorMessage().setMessage(
            "Gebruikersnaam en/of wachtwoord is onjuist, dubbele aanmelding of u heeft geen toegang " +
                  "tot de applicatie PWS."
      );
      i18n.setAdditionalInformation(
            "Toegang tot de applicatie PWS verloopt via ABS. Neem hiervoor contact op met uw manager."
      );
      return i18n;
   }

   @Override
   public void beforeEnter(final BeforeEnterEvent event) {
      // inform the user about an authentication error
      // (yes, the API for resolving query parameters is annoying...)
      if (!event.getLocation().getQueryParameters().getParameters()
            .getOrDefault("error", Collections.emptyList()).isEmpty()) {
         login.setError(true);
      }
   }

   @Override
   protected void authorize() {
      // Negeer autorisatie afhandeling in ViewFrame.
   }
}
