package nl.uwv.pws.ui.views;

import com.vaadin.flow.component.AttachEvent;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.Composite;
import com.vaadin.flow.component.HasStyle;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.splitlayout.SplitLayout;
import com.vaadin.flow.component.splitlayout.SplitLayout.Orientation;

import nl.uwv.pws.ui.MainLayout;
import nl.uwv.pws.ui.util.ComponentAuthorizationHelper;
import nl.uwv.pws.ui.util.ViewAuthorizationHelper;

/**
 * A view frame that establishes app design guidelines. It consists of four
 * parts:
 * <ul>
 * <li>Topmost {@link #setViewHeader(Component...) header}</li>
 * <li>Center {@link #setViewContent(Component...) content}</li>
 * <li>Center {@link #setViewDetails(Component...) details}</li>
 * <li>Bottom {@link #setViewFooter(Component...) footer}</li>
 * </ul>
 * <p>
 *   Bij gebruik van de PageMenuCode annotatie moet de pagina ook de interface HasDynamicTitle gebruiken.
 *   De annotatie PageTitle mag dan niet meer gebruikt worden.
 * </P>
 */
@CssImport("./styles/components/view-frame.css")
public class SplitViewFrame extends Composite<Div> implements HasStyle {

   private static final String CLASS_NAME = "view-frame";

   private final Div header = new Div();
   private final SplitLayout wrapper = new SplitLayout();
   private final Div content = new Div();
   private final Div details = new Div();
   private final Div footer = new Div();

   public enum Position {
      RIGHT, BOTTOM
   }

   @SuppressWarnings("java:S1699") // Call to overridable method setClassName from constructor
   public SplitViewFrame() {
      setClassName(CLASS_NAME);

      header.setClassName(CLASS_NAME + "__header");
      wrapper.setClassName(CLASS_NAME + "__wrapper");
      content.setClassName(CLASS_NAME + "__content");
      details.setClassName(CLASS_NAME + "__details");
      footer.setClassName(CLASS_NAME + "__footer");

      wrapper.addToPrimary(content);
      wrapper.addToSecondary(details);

      super.getContent().add(header, wrapper, footer);
   }

   /**
    * Sets the header slot's components.
    */
   public void setViewHeader(final Component... components) {
      header.removeAll();
      header.add(components);
   }

   /**
    * Sets the content slot's components.
    */
   public void setViewContent(final Component... components) {
      content.removeAll();
      content.add(components);
   }

   /**
    * Sets the detail slot's components.
    */
   public void setViewDetails(final Component... components) {
      details.removeAll();
      details.add(components);
   }

   public void setViewDetailsPosition(final Position position) {
      if (position == Position.RIGHT) {
         wrapper.setOrientation(Orientation.HORIZONTAL);
      } else if (position == Position.BOTTOM) {
         wrapper.setOrientation(Orientation.VERTICAL);
      }
   }

   /**
    * Sets the relative position of the splitter in percentages.
    * The given value is used to set how much space is given to
    * the content relative to the details view. In horizontal mode
    * this is the width of the component and in vertical mode this
    * is the height. The given value will automatically be clamped
    * to the range [0, 100].
    *
    * @param position the relative position of the splitter, in percentages
    */
   public void setDetailsSplitterPosition(final double position) {
      wrapper.setSplitterPosition(position);
   }

   /**
    * Sets the footer slot's components.
    */
   public void setViewFooter(final Component... components) {
      footer.removeAll();
      footer.add(components);
   }

   @Override
   protected void onAttach(final AttachEvent attachEvent) {
      super.onAttach(attachEvent);
      ViewAuthorizationHelper.checkAuthorized(this);
      ComponentAuthorizationHelper.checkAutorizedComponents(this);
      if (MainLayout.get() != null) {
         MainLayout.get().getAppBar().reset(ViewAuthorizationHelper.getMenuPage(this));
      }
   }

   public String getPageTitle() {
      if (MainLayout.get() != null) {
         return MainLayout.get().getAppBar().getPageTitle();
      }
      return null;
   }
}
