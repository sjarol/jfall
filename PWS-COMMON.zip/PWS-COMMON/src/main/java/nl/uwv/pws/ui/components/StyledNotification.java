package nl.uwv.pws.ui.components;

import com.vaadin.flow.component.ClientCallable;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.Text;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.notification.Notification;

/**
 * Notification that takes some additional styling and behavior.
 */
@CssImport(value = "./styles/components/styled-notification-card.css", themeFor = "vaadin-notification-card")
public class StyledNotification extends Notification {
   public static final int DEFAULT_DURATION = 10000;
   public static final Position DEFAULT_POSITION = Position.BOTTOM_START;

   private static final String THEME_CLICKABLE = "clickable";

   private boolean clickToClose = false;

   /**
    * Default constructor. Create an empty notification with component support
    * and non-auto-closing
    * <p>
    * Note: To mix text and child components in notification that also supports
    * child components, use the {@link Text} component for the textual parts.
    */
   public StyledNotification() {
      super();
      super.setPosition(DEFAULT_POSITION);
      super.setDuration(0);
      config();
   }

   /**
    * Creates a Notification with the given String rendered as its HTML text,
    * that does not close automatically.
    *
    * @param text the text of the Notification
    */
   public StyledNotification(final String text) {
      super(text, 0, DEFAULT_POSITION);
      config();
   }

   /**
    * Creates a Notification with given String rendered as its HTML text and
    * given Integer rendered as its duration.
    * <p>
    * Set to {@code 0} or a negative number to disable the notification
    * auto-closing.
    *
    * @param text     the text of the Notification
    * @param duration the duration in milliseconds to show the notification
    */
   public StyledNotification(final String text, final int duration) {
      super(text, duration, DEFAULT_POSITION);
      config();
   }

   /**
    * Creates a Notification with given text String, duration and position
    * <p>
    * Set to {@code 0} or a negative number to disable the notification
    * auto-closing.
    *
    * @param text     the text of the notification
    * @param duration the duration in milliseconds to show the notification
    * @param position the position of the notification. Valid enumerate values are
    *                 TOP_STRETCH, TOP_START, TOP_CENTER, TOP_END, MIDDLE,
    *                 BOTTOM_START, BOTTOM_CENTER, BOTTOM_END, BOTTOM_STRETCH
    */
   public StyledNotification(final String text, final int duration, final Position position) {
      super(text, duration, position);
      config();
   }

   /**
    * Creates a notification with given components inside.
    * <p>
    * Note: To mix text and child components in a component that also supports
    * child components, use the {@link Text} component for the textual parts.
    *
    * @param components the components inside the notification
    * @see #add(Component...)
    */
   public StyledNotification(final Component... components) {
      super(components);
      config();
   }

   /**
    * Makes sure a click on the notification in the client is passed on to the server by calling the
    * {@link #closeNotificationPopup()} method.
    */
   private void config() {
      getElement().executeJs("window.addEventListener(" +
            "'click', function(){$0.$server.closeNotificationPopup();}, { passive: true , once: true}); "
      );
   }

   /**
    * Enables or disabled the clickToClose behavior flag.
    */
   public final void clickToClose(final boolean clickToClose) {
      this.clickToClose = clickToClose;
      if (clickToClose) {
         if (!hasThemeName(THEME_CLICKABLE)) {
            addThemeName(THEME_CLICKABLE);
         }
      } else {
         if (hasThemeName(THEME_CLICKABLE)) {
            removeThemeName(THEME_CLICKABLE);
         }
      }
   }

   /**
    * Called from the client to close the notification if the user clicks on it and clickToClose was enabled.
    * activated.
    */
   @ClientCallable
   public final void closeNotificationPopup() {
      if (clickToClose) {
         close();
      }
   }
}
