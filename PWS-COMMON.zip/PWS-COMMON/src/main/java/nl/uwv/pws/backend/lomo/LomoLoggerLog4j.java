package nl.uwv.pws.backend.lomo;

import javax.servlet.http.HttpServletRequest;
import javax.sql.DataSource;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

public class LomoLoggerLog4j implements LomoLogger {
   private static final Logger LOG = LogManager.getLogger(LomoLoggerLog4j.class);

   @Override
   public void init(final DataSource lomoDataSource, final String programId, final int appiId) {
      LOG.info("LOG4j Lomologger initialized for programId=" + programId + ", appiId=" + appiId);
   }

   @Override
   public void addLomoLog(
         final HttpServletRequest httpServletRequest,
         final String applicatieFunctie,
         final LomoLogMessage message) {
      LOG.info("User:" + httpServletRequest.getRemoteUser() + ", functie: " + applicatieFunctie + ", msg: " + message);
   }
}
