package nl.uwv.pws.ui.validator;

import com.vaadin.flow.data.binder.ValidationResult;
import com.vaadin.flow.data.binder.Validator;
import com.vaadin.flow.data.binder.ValueContext;
import nl.uwv.commons.validation.IsElfProefMatcher;
import nl.uwv.pws.ui.model.BsnNumber;
import org.apache.commons.lang.StringUtils;

/**
 * Validates a {@link BsnNumber} input. This validation makes sure the input is not empty, is numeric and passes the
 * so-called 'elf-proef' that validates whether the input number may be considered to be a valid Bsn.
 */
public class BsnValidator implements Validator<BsnNumber> {
   private final transient IsElfProefMatcher isElfProefMatcher = new IsElfProefMatcher();

   /**
    * {@inheritDoc}
    */
   @Override
   public ValidationResult apply(final BsnNumber value, final ValueContext context) {
      if (isElfProefMatcher.matches(value.getBsn())) {
         return ValidationResult.ok();
      }
      if (StringUtils.isEmpty(value.getBsn())) {
         return ValidationResult.error("Fout : PWS-0015, Veld is verplicht");
      }
      if (!StringUtils.isNumeric(value.getBsn())) {
         return ValidationResult.error("Fout : PWS-0002, Ingevoerd nummer is niet numeriek");
      }
      return ValidationResult.error("Fout : PWS-0001, Ingevoerd nummer voldoet niet aan elf-proef");
   }
}
