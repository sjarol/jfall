package nl.uwv.pws.ui.util;

public final class BoxShadowBorders {
   public static final String BOTTOM = "bsb-b";
   public static final String LEFT = "bsb-l";
   public static final String RIGHT = "bsb-r";
   public static final String TOP = "bsb-t";

   private BoxShadowBorders() {
      // Empty private constructor, utility class
   }
}
