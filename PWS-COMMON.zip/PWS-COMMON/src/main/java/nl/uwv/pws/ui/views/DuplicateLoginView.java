package nl.uwv.pws.ui.views;

import com.vaadin.flow.component.AttachEvent;
import com.vaadin.flow.component.Text;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.dependency.HtmlImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.H1;
import com.vaadin.flow.component.html.H2;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.notification.Notification.Position;
import com.vaadin.flow.component.notification.NotificationVariant;
import com.vaadin.flow.component.page.Viewport;
import com.vaadin.flow.router.BeforeEnterEvent;
import com.vaadin.flow.router.BeforeEnterObserver;
import com.vaadin.flow.router.BeforeEvent;
import com.vaadin.flow.router.HasUrlParameter;
import com.vaadin.flow.router.OptionalParameter;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.server.VaadinServletRequest;

import nl.uwv.pws.backend.dao.User;
import nl.uwv.pws.backend.service.UniqueSessionManager;
import nl.uwv.pws.ui.components.BasicDialog;
import nl.uwv.pws.ui.components.ListItem;
import nl.uwv.pws.ui.util.UIUtils;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import javax.servlet.http.HttpServletRequest;

/*
 * Onderstaande tag zou gebruikt kunnen worden icm spring-security
 * Tag("sa-login-view")
 */
@Route(value = DuplicateLoginView.ROUTE)
@PageTitle(DuplicateLoginView.TITLE)
@HtmlImport("frontend://bower_components/vaadin-lumo-styles/presets/compact.html")
@Viewport("width=device-width, minimum-scale=1.0, initial-scale=1.0, user-scalable=yes")
public class DuplicateLoginView extends ViewFrame implements BeforeEnterObserver, HasUrlParameter<String> {
   private static final Logger LOG = LogManager.getLogger(DuplicateLoginView.class);

   private static final int NOTIFICATION_DURATION = 10000;

   protected static final String ROUTE = "duplogin";
   protected static final String TITLE = "Dubbele login Polis+";

   private Div content;

   private String userName;

   @Override
   protected void onAttachView(final AttachEvent attachEvent) {
      setViewHeader(createContent());
      showAlreadyAuthenticated(VaadinServletRequest.getCurrent().getRemoteUser());
   }

   @Override
   protected void authorize() {
      // Negeer autorisatie afhandeling in ViewFrame.
   }

   public Div createContent() {
      if (content == null) {
         H1 title = new H1();
         Label titleLabel = UIUtils.createH1Label(" PWS - Duplicaat login");
         Image logo = new Image(UIUtils.IMG_PATH + "uwvLogo1RGB.svg", "UWV logo");
         logo.getStyle().set("flex-shrink", "0");
         logo.getStyle().set("height", "96px");
         logo.getStyle().set("margin-left", "var(--lumo-space-m)");
         logo.getStyle().set("width", "96px");

         title.getStyle().set("color", "var(--lumo-base-color)");
         title.getStyle().set("background-color", "var(--theme-color-primary, #FFFFF)");
         title.getStyle().set("display", "flex");
         title.getStyle().set("flex-direction", "row");
         title.getStyle().set("align-items", "center");
         title.getStyle().set("justify-content", "center");

         titleLabel.setWidthFull();
         title.setWidthFull();
         title.add(titleLabel, logo);

         H2 melding = new H2();
         Label meldingLabel = UIUtils.createH2Label("U bent nog ingelogd via een andere browser/tab/user.");
         meldingLabel.setWidthFull();
         melding.add(meldingLabel);

         content = new Div(title, melding);
         content.setSizeFull();
      }
      return content;
   }


   private void showAlreadyAuthenticated(final String remoteUser) {
      BasicDialog dialog = new BasicDialog(this, "Aktieve sessie gebruiker", "20vw", "25vh");
      dialog.setContent(new ListItem(VaadinIcon.USER.create(), remoteUser), new Text("Deze gebruiker uitloggen?"));
      Button logout = UIUtils.createPrimaryButton("Uitloggen");
      logout.addClickListener(e -> {
         try {
            User.logout(remoteUser, true);
            showMessage("Gebruiker succesvol uitgelogd");
            UniqueSessionManager.get().removeUserLoginSession(remoteUser);

            if (StringUtils.equalsIgnoreCase(userName, remoteUser)) {
               UniqueSessionManager.get().insertCurrentUserSession(remoteUser);
               UI.getCurrent().navigate(Dashboard.class);
            } else {
               UI.getCurrent().close();
               UI.getCurrent().navigate(LoginView.class);
            }
         } catch (Exception e1) {
            UIUtils.handleError(e1, "Fout tijdens uitloggen gebruiker");
            UI.getCurrent().navigate(LoginView.class);
         } finally {
            dialog.close();
         }
      });
      dialog.addCustomButtonRight(logout);
      Button cancel = UIUtils.createTertiaryButton("Annuleren");
      cancel.addClickListener(e -> {
         dialog.close();
         UI.getCurrent().close();
         UI.getCurrent().navigate(LoginView.class);
      });
      dialog.hideCancelButton();
      dialog.addCustomButtonLeft(cancel);
      dialog.open();
   }

   private void showMessage(final String message) {
      LOG.warn(message);

      Notification.show(message, NOTIFICATION_DURATION, Position.BOTTOM_START)
            .addThemeVariants(NotificationVariant.LUMO_PRIMARY);
   }

   @Override
   public void beforeEnter(final BeforeEnterEvent event) {
      HttpServletRequest request = VaadinServletRequest.getCurrent();
      String user = request.getRemoteUser();
      if (user == null) {
         LOG.debug("Geen remote user, redirect naar login pagina");
         event.rerouteTo(LoginView.class);
      }
   }

   @Override
   public void setParameter(final BeforeEvent event, final @OptionalParameter String parameter) {
      userName = parameter;
   }
}
