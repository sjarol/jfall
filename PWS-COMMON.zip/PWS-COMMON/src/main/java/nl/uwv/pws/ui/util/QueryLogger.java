package nl.uwv.pws.ui.util;

import com.vaadin.flow.server.VaadinRequest;
import com.vaadin.flow.server.VaadinService;
import nl.uwv.commons.ws.UwvQueryLogger;
import nl.uwv.commons.ws.VerwerkingException;
import nl.uwv.pws.backend.types.Column;
import nl.uwv.pws.backend.types.ColumnList;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;

/**
 * The QueryLogger is a wrapper around the usual UwvQueryLoggers that caches the log calls so they can be processed by
 * a background Thread. This allows you to actively log while rendering the front-end without the user being forced
 * to wait a long time for the screens being built.
 */
public final class QueryLogger {
   private static final Logger LOGGER = LogManager.getLogger(QueryLogger.class);

   private static final int THREAD_SLEEP = 5000;
   private static final int CACHE_TIMEOUT = 3600;

   private static final String LOG_TABLE_IKV = "LA_INKOMSTENVERHOUDING";
   private static final String LOG_TABLE_PRS = "WGA_PERSOON";
   private static final String LOG_TABLE_AEH = "WGA_AEH";
   private static final String LOG_TABLE_PUO = "PUO_AO_CLAIMS";
   private static final String LOG_TABLE_AFNIND = "AFN_AFNEMERINDICATIE";
   private static final String LOG_TABLE_AFN = "AFN_AFNEMER";
   private static final String LOG_TABLE_PROTO = "STAP2_VOORRAAD";

   private static final String LOG_COLUMN_BSN = "SOFINR";
   private static final String LOG_COLUMN_FINR = "FINR";
   private static final String REGEX_BSN = "^[0-9]+$";
   private static final String LOG_COLUMN_LHNR = "LHNR";
   private static final String REGEX_LHNR = "^[0-9]+L[0-9][0-9]$";
   private static final String LOG_COLUMN_AFNCD = "AFN_CD";
   private static final String REGEX_AFNCD = "^[\\S.]{1,8}$";

   private static final String PROGRAMID = "1600";
   private static final String JNDINAME = "nl/uwv/ppls/datasource/scalametads";

   private static int threadSleep = THREAD_SLEEP;

   private static DataSource dataSource;
   private static Function<LogType, UwvQueryLogger> uwvQueryLoggerCreator = logType -> new UwvQueryLogger();
   private static QueryLogger instance = null;

   private final Map<LogItemData, String> eventsToLog = new ConcurrentHashMap<>();
   private final Set<LogItemData> eventsLogged = new TreeSet<>();

   private final QueryLoggerWorkerThread worker;

   private QueryLogger() {
      // Setup the background WorkerThread
      this.worker = new QueryLoggerWorkerThread();
      worker.start();
      LOGGER.info("QueryLogger started");
   }

   /**
    * Closes the QueryLogger worker thread and waits for it to finish.
    */
   public synchronized void close() {
      if (worker != null) {
         worker.terminate();
         try {
            LOGGER.info("Wait for QueryLogger to finish");
            worker.join();
         } catch (InterruptedException e) {
            worker.interrupt();
            LOGGER.warn("Querylogger Interrupted");
         }
         instance = null;
         LOGGER.info("QueryLogger finished");
      }
   }

   /**
    * The first time this method is called, a new QueryLogger instance is created and after that the same instance will
    * be returned every time until the QueryLogger was closed.
    *
    * @return de QueryLogger instance
    */
   public static QueryLogger getInstance() {
      QueryLogger queryLogger = instance;
      if (queryLogger == null) {
         queryLogger = createInstance();
      }
      return queryLogger;
   }

   /**
    * Creates a new QueryLogger instance if one doesn't exist yet.
    */
   private static synchronized QueryLogger createInstance() {
      // Note: This null-check needs to be here even though getInstance() also does the null-check, but this time
      //       we do it inside a synchronized context
      QueryLogger queryLogger = instance;
      if (queryLogger == null) {
         queryLogger = new QueryLogger();
         instance = queryLogger;
      }
      return queryLogger;
   }

   /**
    * Prepares a QueryLog to be written to the database by the background process.
    *
    * @param logType   The type of QueryLog to write to the database.
    * @param itemValue The value to log.
    */
   public void callQueryLog(final LogType logType, final Object itemValue) {
      if (itemValue != null) {
         callQueryLog(logType, itemValue.toString());
      }
   }

   /**
    * Prepares a QueryLog to be written to the database by the background process.
    *
    * @param logType The type of QueryLog to write to the database.
    * @param value   The value to log.
    */
   public void callQueryLog(final LogType logType, final String value) {
      if (value != null) {
         VaadinRequest v = VaadinService.getCurrentRequest();
         LogItemData logItem = new LogItemData(logType, v.getRemoteUser(), value, v.getRemoteAddr());

         if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("QueryLogger add: " + logItem.toString());
         }
         eventsToLog.put(logItem, "");
      }
   }

   public void callQueryLog(final LogType logType, final ColumnList item, final Column column) {
      String value = getValueFromItem(item, column);
      if (value != null) {
         callQueryLog(logType, value);
      }
   }

   private static String getValueFromItem(final ColumnList row, final Column column) {
      Object object = row == null ? null : row.getValue(column.name());
      return object == null ? null : object.toString();
   }

   /**
    * Container for a single logItem.
    */
   private static class LogItemData implements Comparable<LogItemData> {
      private static final String SEP = ", ";
      private final LogType logType;
      private final String user;
      private final String value;
      private final String address;
      private final LocalDateTime tsLog;

      public LogItemData(final LogType logType, final String user, final String value, final String address) {
         super();
         this.logType = logType;
         this.user = user;
         this.address = address;
         this.value = value;
         this.tsLog = LocalDateTime.now();
      }

      public LogType getLogType() {
         return logType;
      }

      public String getUser() {
         return user;
      }

      public String getValue() {
         return value;
      }

      public String getAddress() {
         return address;
      }

      public LocalDateTime getTsLog() {
         return tsLog;
      }

      public String toString() {
         return new StringBuilder()
               .append(tsLog).append(SEP)
               .append(user).append(SEP)
               .append(address).append(SEP)
               .append(logType).append(SEP)
               .append(value)
               .toString();
      }

      @Override
      public int hashCode() {
         final int prime = 31;
         int result = 1;
         result = prime * result + ((logType == null) ? 0 : logType.hashCode());
         result = prime * result + ((user == null) ? 0 : user.hashCode());
         result = prime * result + ((value == null) ? 0 : value.hashCode());
         return result;
      }

      @Override
      public boolean equals(final Object obj) {
         if (this == obj) {
            return true;
         }
         if (obj == null) {
            return false;
         }
         if (!(obj instanceof LogItemData)) {
            return false;
         }
         return equalsLogItemData((LogItemData) obj);
      }

      private boolean equalsLogItemData(final LogItemData other) {
         return logType == other.logType && user.equals(other.user) && value.equals(other.value);
      }

      @Override
      public int compareTo(final LogItemData o) {
         int result = this.logType.compareTo(o.getLogType());
         if (result == 0) {
            result = this.user.compareTo(o.getUser());
         }
         if (result == 0) {
            result = this.value.compareTo(o.getValue());
         }
         return result;
      }
   }

   /**
    * The actual Background Thread that will process the batches of logs once every while and writes them to the
    * database.
    */
   private final class QueryLoggerWorkerThread extends Thread {
      private final Map<LogType, UwvQueryLogger> queryLoggers = new EnumMap<>(LogType.class);

      private volatile boolean waitForData = true;

      private QueryLoggerWorkerThread() {
         // Map each LogType to an UwvQueryLogger instance
         Arrays.stream(LogType.values()).forEach(logType -> queryLoggers.put(logType, createQueryLogger(logType)));
      }

      @Override
      public void run() {
         while (waitForData) {
            try {
               Thread.sleep(threadSleep);
               cleanLoggedItems();
               logItemData();
            } catch (InterruptedException e) {
               LOGGER.warn("Worker thread interrupted: ", e);
               waitForData = false;
               interrupt();
            } catch (Exception e) {
               LOGGER.error("Worker thread has an error: ", e);
            }
         }
      }

      public void terminate() {
         waitForData = false;
      }

      private void cleanLoggedItems() {
         LocalDateTime cleanDateTime = LocalDateTime.now().minus(CACHE_TIMEOUT, ChronoUnit.SECONDS);
         eventsLogged.removeIf(logData -> logData.getTsLog().isBefore(cleanDateTime));
      }

      private void logItemData() {
         Set<LogItemData> loggedDataItems = new HashSet<>();
         eventsToLog.keySet().stream()
               .filter(itemData -> !eventsLogged.contains(itemData))
               .forEach(itemData -> writeToQueryLog(itemData, loggedDataItems));
         eventsLogged.addAll(loggedDataItems);
         for (LogItemData itemData : loggedDataItems) {
            eventsToLog.remove(itemData);
         }
         loggedDataItems.clear();
      }

      private void writeToQueryLog(final LogItemData itemData, final Set<LogItemData> loggedDataItems) {
         try {
            queryLoggers.get(itemData.getLogType()).log(
                  itemData.getValue(), Timestamp.valueOf(itemData.getTsLog()),
                  itemData.getUser(), itemData.getAddress()
            );

            if (LOGGER.isDebugEnabled()) {
               LOGGER.debug("QueryLogger written: " + itemData.toString());
            }
         } catch (Exception e) {
            LOGGER.warn(String.format("Geen log entry voor %s, %s, %s, %s", itemData.getAddress(),
                  itemData.getUser(), itemData.getLogType(), itemData.getValue()), e);
         } finally {
            loggedDataItems.add(itemData);
         }
      }

      /**
       * Creates and populates the QueryLogger for a specific LogType.
       *
       * @param logType The LogType to create and prepare the QueryLogger for.
       * @return The UwvQueryLogger that was created for the given LogType.
       */
      private UwvQueryLogger createQueryLogger(final LogType logType) {
         UwvQueryLogger queryLogger = uwvQueryLoggerCreator.apply(logType);
         queryLogger.setDataSource(getDataSource());
         queryLogger.setProgramId(PROGRAMID);
         queryLogger.setLogTableName(logType.table);
         queryLogger.setLogTableColumn(logType.column);
         queryLogger.setColumnValuePattern(logType.pattern);
         queryLogger.init();
         return queryLogger;
      }

      /**
       * Will look up the DataSource to use the first time this method is called and will cache and return the
       * cached value on consecutive calls.
       *
       * @return The Datasource to use for writing out the QueryLogs.
       */
      private synchronized DataSource getDataSource() {
         if (dataSource == null) {
            try {
               Context initContext = new InitialContext();
               dataSource = (DataSource) initContext.lookup(JNDINAME);
            } catch (NamingException e) {
               throw new VerwerkingException("Fout bij ophalen datasource", e);
            }
         }
         return dataSource;
      }
   }

   /**
    * The type of QueryLog. Different types of QueryLogs will be logged to different tables/columns in the database.
    */
   public enum LogType {
      LA_BSN(LOG_TABLE_IKV, LOG_COLUMN_BSN, REGEX_BSN),
      LA_LHNR(LOG_TABLE_IKV, LOG_COLUMN_LHNR, REGEX_LHNR),
      WGA_FINR(LOG_TABLE_PRS, LOG_COLUMN_FINR, REGEX_BSN),
      WGA_SOFINR(LOG_TABLE_PRS, LOG_COLUMN_BSN, REGEX_BSN),
      WGA_LHNR(LOG_TABLE_AEH, LOG_COLUMN_LHNR, REGEX_LHNR),
      PUO_BSN(LOG_TABLE_PUO, LOG_COLUMN_BSN, REGEX_BSN),
      AFNIND_BSN(LOG_TABLE_AFNIND, LOG_COLUMN_BSN, REGEX_BSN),
      AFN_LHNR(LOG_TABLE_AFN, LOG_COLUMN_LHNR, REGEX_LHNR),
      AFN_AFNCD(LOG_TABLE_AFN, LOG_COLUMN_AFNCD, REGEX_AFNCD),
      PROTO_LHNR(LOG_TABLE_PROTO, LOG_COLUMN_LHNR, REGEX_LHNR);

      private final String table;
      private final String column;
      private final String pattern;

      LogType(final String table, final String column, final String pattern) {
         this.table = table;
         this.column = column;
         this.pattern = pattern;
      }
   }

   // Allows for the UwvQueryLoggerCreator to be overridden for unit-testing purpose
   static void setUwvQueryLoggerCreator(final Function<LogType, UwvQueryLogger> uwvQueryLoggerCreator) {
      QueryLogger.uwvQueryLoggerCreator = uwvQueryLoggerCreator;
   }

   // Allows for different threadSleep time during unit-testing
   static void setThreadSleep(final int threadSleepMillis) {
      threadSleep = threadSleepMillis;
   }
}
