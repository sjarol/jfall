package nl.uwv.pws.backend.service;

import com.vaadin.flow.data.provider.QuerySortOrder;
import com.vaadin.flow.data.provider.SortDirection;
import nl.uwv.pws.backend.desc.FieldDescriptor;
import nl.uwv.pws.backend.desc.SampleResourceFieldDescriptor;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import javax.naming.NamingException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;

@SuppressWarnings("serial")
public class IncidentLoggerService extends AbstractListService {
   private static final Logger LOG = LogManager.getLogger(IncidentLoggerService.class);
   private static final String VIEW_NAME = "PWS_INCIDENT_LOGS";
   private static final String SORT_TIJDSTIP = "LOGGED_ON";
   private static final FieldDescriptor descriptor = SampleResourceFieldDescriptor.INCIDENTLOG;
   private static final int MAX_NAME_LENGTH = 20;

   public IncidentLoggerService(final String dataSourceName) {
      super(dataSourceName);
   }

   @Override
   protected String getViewName() {
      return VIEW_NAME;
   }

   @Override
   public FieldDescriptor getDescriptor() {
      return descriptor;
   }

   @Override
   protected QuerySortOrder getDefaultSortOrder() {
      return new QuerySortOrder(SORT_TIJDSTIP, SortDirection.ASCENDING);
   }

   public void insert(
         final String incidentNo,
         final String loggedBy,
         final String stacktrace,
         final String threadDump) {
      String sql = "INSERT INTO PWS_INCIDENT_LOGS(INCIDENT_NO, LOGGED_BY, LOGGED_ON, STACKTRACE, THREAD_DUMP) " +
            "VALUES (?, ?, ?, ?, ?)";
      try (Connection conn = getDataSource().getConnection();
            PreparedStatement callStmt = conn.prepareStatement(sql)) {
         callStmt.setString(1, incidentNo);
         callStmt.setString(2, StringUtils.abbreviateMiddle(loggedBy, "..", MAX_NAME_LENGTH));
         callStmt.setTimestamp(3, new Timestamp(System.currentTimeMillis()));
         callStmt.setString(4, stacktrace);
         callStmt.setString(5, threadDump);
         callStmt.execute();
         if (!conn.getAutoCommit()) {
            conn.commit();
         }
      } catch (SQLException | NamingException error) {
         LOG.error("Interne fout: " + error.getClass().getName() + " " + error.getMessage(), error);
         LOG.error("loggedBy='" + StringUtils.abbreviateMiddle(loggedBy, "..", MAX_NAME_LENGTH) + "'");
      }
   }
}
