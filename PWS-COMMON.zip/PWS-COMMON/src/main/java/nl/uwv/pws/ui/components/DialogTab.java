package nl.uwv.pws.ui.components;

import com.vaadin.flow.component.Component;
import nl.uwv.pws.ui.util.HasAuthorization;

import java.io.Serializable;

public interface DialogTab extends HasAuthorization, Serializable {

   String getName();

   Component getContent();

   boolean isValid();

}
