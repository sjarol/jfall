package nl.uwv.pws.ui.components;

import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.HasStyle;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.Scroller;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import nl.uwv.pws.ui.util.ComponentAuthorizationHelper;
import nl.uwv.pws.ui.util.LumoStyles;
import nl.uwv.pws.ui.util.PdfHelp;
import nl.uwv.pws.ui.util.UIUtils;
import nl.uwv.pws.ui.views.ViewFrame;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import java.net.URL;

/**
 * Base dialog that holds the code that is shared between the StyledDialog and the BasicDialog.
 */
@CssImport(value = "./styles/components/dialog.css", themeFor = "vaadin-*-overlay")
@CssImport(value = "./styles/components/basic-dialog.css")
abstract class AbstractDialog extends Dialog implements HasStyle {
   private static final Logger LOG = LogManager.getLogger(AbstractDialog.class);

   private static final String COMPONENT_ID = "basic-dialog";
   private static final String COMPONENT_FOOTER_CLASS = "footer";
   private static final String COMPONENT_FOOTER_LEFT_CLASS = "footer-left";
   private static final String COMPONENT_FOOTER_RIGHT_CLASS = "footer-right";
   private static final String COMPONENT_CONTENT_CLASS = "content";
   private Button cancelButton;
   private VerticalLayout content;
   private HorizontalLayout header;
   private HorizontalLayout footerLeft;
   private HorizontalLayout footerRight;
   private Span dialogTitle;
   private PdfHelp help;

   /**
    * @param parent to check for authorisation
    * @param title  of the dialog
    */
   public AbstractDialog(final ViewFrame parent, final String title) {
      this(parent, title, "100%", "100%", COMPONENT_ID);
   }

   /**
    * @param parent to check for authorisation
    * @param title  of the dialog
    * @param width  of the dialog
    * @param height of the dialog
    */
   public AbstractDialog(final ViewFrame parent, final String title, final String width, final String height) {
      this(parent, title, width, height, COMPONENT_ID);
   }

   /**
    * @param parent               to check for authorisation
    * @param title                of the dialog
    * @param width                of the dialog
    * @param height               of the dialog
    * @param inheritedComponentId CSS ID to give to the component
    */
   public AbstractDialog(
         final ViewFrame parent,
         final String title,
         final String width,
         final String height,
         final String inheritedComponentId) {
      LOG.debug("Basic Dialog aangeroepen vanuit: " + inheritedComponentId);

      super.setCloseOnEsc(true);
      super.setCloseOnOutsideClick(false);

      if (parent != null) {
         ComponentAuthorizationHelper.checkAutorizedComponents(parent);
      }

      super.setHeight(height);
      super.setWidth(width);

      VerticalLayout dialogStructure = new VerticalLayout(initHeader(title), initContent(), initFooter());

      dialogStructure.setClassName(COMPONENT_ID, true);
      dialogStructure.setId(inheritedComponentId);
      dialogStructure.setSizeFull();
      super.add(dialogStructure);
   }

   /**
    * @param title for the dialog
    * @return header
    */
   private HorizontalLayout initHeader(final String title) {
      header = new HorizontalLayout();
      initHeader(header);
      header.setWidthFull();

      dialogTitle = new Span(title);
      dialogTitle.addClassName(LumoStyles.Heading.H2);
      dialogTitle.getElement().getStyle().set("user-select", "none");
      dialogTitle.addClassName("draggable");

      Button btnCloseDialog = UIUtils.createButton(VaadinIcon.CLOSE, ButtonVariant.LUMO_SMALL,
            ButtonVariant.LUMO_TERTIARY);
      btnCloseDialog.addClickListener(event -> cancel());

      header.add(dialogTitle, btnCloseDialog);
      header.setAlignItems(FlexComponent.Alignment.CENTER);
      header.setFlexGrow(1, dialogTitle);

      return header;
   }

   abstract void initHeader(final HorizontalLayout headerToInitialize);

   /**
    * @return content
    */
   private Scroller initContent() {
      content = new VerticalLayout();
      content.setSizeFull();

      Scroller scroller = new Scroller(content);
      scroller.setClassName(COMPONENT_CONTENT_CLASS);
      scroller.setSizeFull();

      return scroller;
   }

   /**
    * @return footer
    */
   private HorizontalLayout initFooter() {
      HorizontalLayout footer = new HorizontalLayout();
      footer.setClassName(COMPONENT_FOOTER_CLASS);
      footer.setWidthFull();
      add(footer);

      // LEFT side of the footer
      footerLeft = new HorizontalLayout();
      footerLeft.setClassName(COMPONENT_FOOTER_LEFT_CLASS);
      footerLeft.setJustifyContentMode(FlexComponent.JustifyContentMode.START);
      footerLeft.setWidth("50%");
      footer.add(footerLeft);

      // RIGHT side of the footer
      footerRight = new HorizontalLayout();
      footerRight.setClassName(COMPONENT_FOOTER_RIGHT_CLASS);
      footerRight.setJustifyContentMode(FlexComponent.JustifyContentMode.END);
      footerRight.setWidth("50%");
      footer.add(footerRight);

      // Annuleren knop
      cancelButton = createAndPlaceCancelButton(footerLeft, footerRight);
      cancelButton.addClickListener(e -> close());

      return footer;
   }

   /**
    * Create and place the cancel button to use. You do not need to attach any listener to the button, since that will
    * be done automatically on the returned Button instance.
    *
    * @param footerLeft The left footer where the button may be placed.
    * @param footerRight The right footer where the button may be placed.
    * @return The newly created footer which will have been added to either the left or the right footer as well.
    */
   abstract Button createAndPlaceCancelButton(final HorizontalLayout footerLeft, final HorizontalLayout footerRight);

   private void cancel() {
      if (cancelButton != null) {
         cancelButton.click();
      } else {
         close();
      }
   }

   public void setContent(final Component... components) {
      content.removeAll();
      content.add(components);
   }

   public void setTitle(final String title) {
      dialogTitle.setText(title);
   }

   public void hideCancelButton() {
      removeButton(cancelButton);
   }

   public void showCancelButton() {
      addCancelButtonAsFirstOnFooter(cancelButton, footerLeft, footerRight);
   }

   abstract void addCancelButtonAsFirstOnFooter(
         final Button cancelButton,
         final HorizontalLayout footerLeft,
         final HorizontalLayout footerRight
   );

   public void addCustomButtonLeft(final Component customButtons) {
      footerLeft.add(customButtons);
   }

   public void addCustomButtonRight(final Component customButtons) {
      footerRight.add(customButtons);
   }

   public void removeButton(final Component oldButton) {
      if (footerLeft.getChildren().anyMatch(e -> e == oldButton)) {
         footerLeft.remove(oldButton);
      } else if (footerRight.getChildren().anyMatch(e -> e == oldButton)) {
         footerRight.remove(oldButton);
      }
   }

   public void addCloseListener(final ComponentEventListener<OpenedChangeEvent<Dialog>> listener) {
      if (listener != null) {
         this.addOpenedChangeListener(listener);
      }
   }

   public void setHelp(final String pdfFilename, final String helpDescription) {
      setPdfHelp(new PdfHelp(pdfFilename, helpDescription));
   }

   public void setHelp(final URL pdfUrl, final String helpDescription) {
      setPdfHelp(new PdfHelp(pdfUrl, helpDescription));
   }

   private void setPdfHelp(final PdfHelp pdfHelp) {
      if (help != null) {
         header.remove(help.getButton());
      }
      help = pdfHelp;
      header.addComponentAtIndex(1, help.getButton());
   }
}
