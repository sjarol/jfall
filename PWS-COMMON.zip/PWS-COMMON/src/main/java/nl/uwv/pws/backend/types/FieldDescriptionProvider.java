package nl.uwv.pws.backend.types;

public interface FieldDescriptionProvider {

   /**
    * Bepaal de omschrijving voor de categorie (code altijd lowercase)
    *
    * @param catCode
    * @return
    */
   String getDescription(final String catCode);

   /**
    * Bepaal de omschrijving voor de code in categorie (catCode altijd lowercase)
    *
    * @param catCode
    * @param code
    * @return
    */
   String getDescription(final String catCode, final String code);

}
