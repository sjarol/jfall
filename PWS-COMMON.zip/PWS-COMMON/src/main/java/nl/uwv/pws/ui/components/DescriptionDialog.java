package nl.uwv.pws.ui.components;

import java.util.HashMap;
import java.util.Map;

import com.vaadin.flow.component.orderedlayout.VerticalLayout;

import nl.uwv.pws.backend.types.FieldDescriptionProvider;
import nl.uwv.pws.ui.util.FontSize;
import nl.uwv.pws.ui.util.TextColor;
import nl.uwv.pws.ui.util.UIUtils;

public final class DescriptionDialog {
   private static final Map<String, FieldDescriptionProvider> PROVIDERS = new HashMap<>();

   private DescriptionDialog() {
      // Do not construct
   }

   public static void addFieldDescriptionProvider(final String id, final FieldDescriptionProvider provider) {
      PROVIDERS.put(id, provider);
   }

   public static void show(final String id, final String cat, final String code) {
      if (PROVIDERS.containsKey(id)) {
         openDialog(createContent(id, cat, code));
      } else {
         UIUtils.showErrorNotification("Geen provider gedefinieerd voor " + id);
      }
   }

   private static void openDialog(final VerticalLayout details) {
      BasicDialog dialog = new BasicDialog(null, "Extra toelichting", "25vw", "25vh");
      dialog.setContent(details);
      dialog.hideCancelButton();
      dialog.setDraggable(true);
      dialog.setResizable(true);
      dialog.open();
   }

   private static VerticalLayout createContent(final String id, final String cat, final String code) {
      FieldDescriptionProvider provider = PROVIDERS.get(id);
      VerticalLayout details = new VerticalLayout();
      String catDescr = provider.getDescription(cat);

      if (catDescr != null) {
         details.add(UIUtils.createH3Label("Categorie:"));
         details.add(UIUtils.createLabel(FontSize.M, TextColor.PRIMARY, catDescr));
      }
      details.add(UIUtils.createH3Label("Code:"));
      details.add(UIUtils.createLabel(FontSize.M, TextColor.SECONDARY, provider.getDescription(cat, code)));
      return details;
   }
}
