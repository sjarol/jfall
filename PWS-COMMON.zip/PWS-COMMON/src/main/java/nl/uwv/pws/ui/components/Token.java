package nl.uwv.pws.ui.components;

import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.FlexComponent;

import nl.uwv.pws.ui.layout.size.Left;
import nl.uwv.pws.ui.layout.size.Right;
import nl.uwv.pws.ui.util.FontSize;
import nl.uwv.pws.ui.util.LumoStyles;
import nl.uwv.pws.ui.util.TextColor;
import nl.uwv.pws.ui.util.UIUtils;
import nl.uwv.pws.ui.util.css.BorderRadius;
import nl.uwv.pws.ui.util.css.Display;

public class Token extends FlexBoxLayout {

   private static final String CLASS_NAME = "token";

   public Token(final String text) {
      super.setAlignItems(FlexComponent.Alignment.CENTER);
      super.setBackgroundColor(LumoStyles.Color.Primary.PCT_10);
      super.setBorderRadius(BorderRadius.M);
      super.setClassName(CLASS_NAME);
      super.setDisplay(Display.INLINE_FLEX);
      super.setPadding(Left.S, Right.XS);
      super.setSpacing(Right.XS);

      Label label = UIUtils.createLabel(FontSize.S, TextColor.BODY, text);
      Button button = UIUtils.createButton(
            VaadinIcon.CLOSE_SMALL, ButtonVariant.LUMO_SMALL, ButtonVariant.LUMO_TERTIARY_INLINE
      );
      super.add(label, button);
   }
}
