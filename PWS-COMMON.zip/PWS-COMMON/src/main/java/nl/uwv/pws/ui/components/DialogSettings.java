package nl.uwv.pws.ui.components;

public class DialogSettings {
   private final String title;
   private final String message;
   private final String additionalMessage;
   private final String actionName;
   private final boolean isDisruptive;

   public DialogSettings(
         final String title,
         final String message,
         final String additionalMessage,
         final String actionName,
         final boolean isDisruptive) {
      this.title = title;
      this.message = message;
      this.additionalMessage = additionalMessage;
      this.actionName = actionName;
      this.isDisruptive = isDisruptive;
   }

   /**
    * @return the title
    */
   public String getTitle() {
      return title;
   }

   /**
    * @return the message
    */
   public String getMessage() {
      return message;
   }

   /**
    * @return the additionalMessage
    */
   public String getAdditionalMessage() {
      return additionalMessage;
   }

   /**
    * @return the actionName
    */
   public String getActionName() {
      return actionName;
   }

   /**
    * @return the isDisruptive
    */
   public boolean isDisruptive() {
      return isDisruptive;
   }
}
