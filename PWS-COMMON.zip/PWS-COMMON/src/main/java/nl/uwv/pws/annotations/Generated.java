package nl.uwv.pws.annotations;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.CLASS;

/**
 * Annotation can be used to exclude classes or methods from the Jacoco coverage scan. Since Jacoco version v.0.8.2
 * a feature has been implemented that accepts any annotation whose retention policy is RUNTIME or CLASS and whose
 * simple name is 'Generated' to exclude that class or method from the coverage report.
 * <p>
 * https://github.com/jacoco/jacoco/releases/tag/v0.8.2
 * https://github.com/jacoco/jacoco/pull/731
 */
@Documented
@Retention(CLASS)
@Target({TYPE, METHOD})
public @interface Generated {
}
