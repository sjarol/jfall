package nl.uwv.pws.ui.components;

import com.vaadin.flow.component.datepicker.DatePicker;
import com.vaadin.flow.data.binder.Binder;

import java.time.LocalDate;

import static nl.uwv.pws.ui.util.LocaleConstants.DUTCH_DATE_PICKER_I18N;
import static nl.uwv.pws.ui.util.LocaleConstants.DUTCH_LOCALE;

/**
 * This field can be used on a SearchBar to ask a user to enter a valid 'PeilDatum'.
 */
@SuppressWarnings("java:S110") // Too many parents
public class PeildatumPicker extends DatePicker implements HasPrepareBinding<LocalDate> {
   public static final LocalDate START_PPLS_DATE = LocalDate.of(2006, 1, 1);

   public PeildatumPicker() {
      super.setLocale(DUTCH_LOCALE);
      super.setI18n(DUTCH_DATE_PICKER_I18N);
      super.setRequired(true);
      super.setRequiredIndicatorVisible(true);
      super.setClearButtonVisible(true);
      super.setMin(START_PPLS_DATE);
      super.setMax(LocalDate.now());
      super.setWeekNumbersVisible(true);
   }

   public PeildatumPicker(final String componentId) {
      this();
      super.setId(componentId);
   }

   @Override
   public <B> Binder.BindingBuilder<B, LocalDate> prepareBinding(final Binder<B> binder) {
      return binder.forField(this)
            .asRequired("Datum is niet correct")
            .withValidator(
                  date -> date == null || !date.isBefore(START_PPLS_DATE),
                  "De Peildatum mag niet voor 01-01-2006 liggen"
            );
   }
}
