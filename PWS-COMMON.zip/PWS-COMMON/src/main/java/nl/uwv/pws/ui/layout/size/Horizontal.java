package nl.uwv.pws.ui.layout.size;

public enum Horizontal implements Size {

   AUTO("auto", null),
   XS("var(--lumo-space-xs)", "spacing-h-xs"),
   S("var(--lumo-space-s)", "spacing-h-s"),
   M("var(--lumo-space-m)", "spacing-h-m"),
   L("var(--lumo-space-l)", "spacing-h-l"),
   XL("var(--lumo-space-xl)", "spacing-h-xl"),
   RESPONSIVE_M("var(--lumo-space-r-m)", null),
   RESPONSIVE_L("var(--lumo-space-r-l)", null),
   RESPONSIVE_X("var(--lumo-space-r-x)", null);

   LayoutSize horizontalSize;

   Horizontal(final String variable, final String spacingClassName) {
      horizontalSize = new LayoutSize(variable, spacingClassName);
   }

   @Override
   public String[] getMarginAttributes() {
      return horizontalSize.getMarginsWithSuffix(LayoutSize.SUFFIX_LEFT, LayoutSize.SUFFIX_RIGHT);
   }

   @Override
   public String[] getPaddingAttributes() {
      return horizontalSize.getPaddingsWithSuffix(LayoutSize.SUFFIX_LEFT, LayoutSize.SUFFIX_RIGHT);
   }

   @Override
   public String getSpacingClassName() {
      return horizontalSize.getSpacingClassName();
   }

   @Override
   public String getVariable() {
      return horizontalSize.getVariable();
   }
}
