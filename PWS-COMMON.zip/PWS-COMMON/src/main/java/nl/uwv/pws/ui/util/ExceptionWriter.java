package nl.uwv.pws.ui.util;

import java.io.File;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import com.vaadin.flow.server.VaadinSession;

import nl.uwv.pws.ui.AppRuntimeException;

public class ExceptionWriter {

   private static final String EXCEPTION_WRITER = "ExceptionWriter";
   private static final String ENV_INCIDENT_PATH = "incidentFilePath";
   private String filePath;
   private String exceptionID;

   public static ExceptionWriter getCurrentInstance() {
      ExceptionWriter writer;
      if (VaadinSession.getCurrent() != null && VaadinSession.getCurrent().getSession() != null) {
         writer = (ExceptionWriter) VaadinSession.getCurrent().getSession().getAttribute(EXCEPTION_WRITER);
         if (writer == null) {
            writer = new ExceptionWriter();
            VaadinSession.getCurrent().getSession().setAttribute(EXCEPTION_WRITER, writer);
         }
      } else {
         writer = new ExceptionWriter();
      }
      return writer;
   }

   public static String getDefaultPath() {
      return getDirFromEnv(ENV_INCIDENT_PATH, "/tmp/incident");
   }

   private static String getDirFromEnv(final String envName, final String defaultDir) {
      try {
         Context env = (Context) new InitialContext().lookup("java:comp/env");
         if (env != null) {
            String directoryName = (String) env.lookup(envName);
            File theDir = new File(directoryName);
            if (theDir.exists() && theDir.isDirectory()) {
               return directoryName;
            }
         }
      } catch (NamingException e) {
         throw new AppRuntimeException("Directory is niet gevonden: " + e.getMessage(), e);
      }
      return defaultDir;
   }

   public String getFilePath() {
      if (filePath == null) {
         filePath = getDefaultPath();
      }
      return filePath;
   }

   public void setFilePath(final String filePath) {
      this.filePath = filePath;
   }

   public void setExceptionID(final String exceptionID) {
      this.exceptionID = exceptionID;
   }

   public String getExceptionID() {
      return exceptionID;
   }
}
