package nl.uwv.pws.ui.components;

import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import nl.uwv.pws.ui.layout.size.Right;
import nl.uwv.pws.ui.layout.size.Wide;
import nl.uwv.pws.ui.util.FontSize;
import nl.uwv.pws.ui.util.TextColor;
import nl.uwv.pws.ui.util.UIUtils;
import nl.uwv.pws.ui.util.css.WhiteSpace;

@CssImport("./styles/components/list-item.css")
public class ListItem extends FlexBoxLayout {

   private static final String CLASS_NAME = "list-item";

   private Div prefix;
   private Div suffix;

   private final FlexBoxLayout content;

   private final Label primary;
   private final Label secondary;

   public ListItem(final String primary, final String secondary) {
      super.addClassName(CLASS_NAME);

      super.setAlignItems(FlexComponent.Alignment.CENTER);
      super.setPadding(Wide.RESPONSIVE_L);
      super.setSpacing(Right.L);

      this.primary = new Label(primary);
      this.secondary = UIUtils.createLabel(FontSize.S, TextColor.SECONDARY,
            secondary);

      content = new FlexBoxLayout(this.primary, this.secondary);
      content.setClassName(CLASS_NAME + "__content");
      content.setFlexDirection(FlexDirection.COLUMN);
      super.add(content);
   }

   public ListItem(final String primary) {
      this(primary, "");
   }

   /* === PREFIX === */

   public ListItem(final Component prefix, final String primary, final String secondary) {
      this(primary, secondary);
      setPrefix(prefix);
   }

   public ListItem(final Component prefix, final String primary) {
      this(prefix, primary, "");
   }

   /* === SUFFIX === */

   public ListItem(final String primary, final String secondary, final Component suffix) {
      this(primary, secondary);
      setSuffix(suffix);
   }

   public ListItem(final String primary, final Component suffix) {
      this(primary, null, suffix);
   }

   /* === PREFIX & SUFFIX === */

   public ListItem(final Component prefix, final String primary, final String secondary, final Component suffix) {
      this(primary, secondary);
      setPrefix(prefix);
      setSuffix(suffix);
   }

   public ListItem(final Component prefix, final String primary, final Component suffix) {
      this(prefix, primary, "", suffix);
   }

   /* === MISC === */

   public FlexBoxLayout getContent() {
      return content;
   }

   public void setWhiteSpace(final WhiteSpace whiteSpace) {
      UIUtils.setWhiteSpace(whiteSpace, this);
   }

   public void setReverse(final boolean reverse) {
      if (reverse) {
         content.setFlexDirection(FlexDirection.COLUMN_REVERSE);
      } else {
         content.setFlexDirection(FlexDirection.COLUMN);
      }
   }

   public void setHorizontalPadding(final boolean horizontalPadding) {
      if (horizontalPadding) {
         getStyle().remove("padding-left");
         getStyle().remove("padding-right");
      } else {
         getStyle().set("padding-left", "0");
         getStyle().set("padding-right", "0");
      }
   }

   public void setPrimaryText(final String text) {
      primary.setText(text);
   }

   public Label getPrimary() {
      return primary;
   }

   public void setSecondaryText(final String text) {
      secondary.setText(text);
   }

   public final void setPrefix(final Component... components) {
      if (prefix == null) {
         prefix = new Div();
         prefix.setClassName(CLASS_NAME + "__prefix");
         getElement().insertChild(0, prefix.getElement());
         getElement().setAttribute("with-prefix", true);
      }
      prefix.removeAll();
      prefix.add(components);
   }

   public final void setSuffix(final Component... components) {
      if (suffix == null) {
         suffix = new Div();
         suffix.setClassName(CLASS_NAME + "__suffix");
         getElement().insertChild(getElement().getChildCount(),
               suffix.getElement());
         getElement().setAttribute("with-suffix", true);
      }
      suffix.removeAll();
      suffix.add(components);
   }

   public void setDividerVisible(final boolean visible) {
      if (visible) {
         getElement().setAttribute("with-divider", true);
      } else {
         getElement().removeAttribute("with-divider");
      }
   }
}
