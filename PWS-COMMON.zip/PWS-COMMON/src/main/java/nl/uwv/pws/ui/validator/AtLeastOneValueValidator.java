package nl.uwv.pws.ui.validator;

import com.vaadin.flow.data.binder.ValidationResult;
import com.vaadin.flow.data.binder.Validator;
import com.vaadin.flow.data.binder.ValueContext;
import com.vaadin.flow.function.SerializableSupplier;
import nl.uwv.pws.ui.components.ValidationLabel;
import org.apache.commons.lang3.StringUtils;

import java.io.Serializable;

/**
 * Validator that simply checks if at least one of the suppliers you pass in has a non-null, non-empty value. This is
 * typically used at the binding-level for generic error messages, for example:
 *
 * <pre>
 *       binder = new Binder<SearchBean>().withValidator(new AtLeastOneValueValidator<>(
 *             "Een ingevuld zoekveld is verplicht",
 *             searchBean::getAfnemerCode, searchBean::getAfnemerNaam, searchBean::getUgcId
 *       ));
 * </pre>
 *
 * In this example the validation messages will be logged at the binding-level and will not be component-specific,
 * therefore you will need to set a statusLabel to use for rendering the message, maybe the {@link ValidationLabel}
 * can help you with that.
 *
 * @param <T> The bean type of the binder this validator is bound to.
 */
public class AtLeastOneValueValidator<T> implements Validator<T> {
   private final String message;
   private final SerializableSupplier<Serializable>[] suppliers;

   @SafeVarargs
   public AtLeastOneValueValidator(final String message, final SerializableSupplier<Serializable>... suppliers) {
      this.message = message;
      this.suppliers = suppliers;
   }

   @Override
   public ValidationResult apply(final T bean, final ValueContext context) {
      for (SerializableSupplier<Serializable> supplier : suppliers) {
         Object value = supplier.get();
         if (value != null && !StringUtils.isEmpty(value.toString())) {
            // This is a non-null, non-empty value.. that's what we need, so all ok!
            return ValidationResult.ok();
         }
      }

      // We went through all ofo the supplied values and non of the returned a non-null, non-empty value
      return ValidationResult.error(message);
   }
}
