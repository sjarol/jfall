package nl.uwv.pws.ui.views;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vaadin.flow.component.html.H2;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.BeforeEnterEvent;
import com.vaadin.flow.router.ErrorParameter;
import com.vaadin.flow.router.InternalServerError;
import com.vaadin.flow.router.ParentLayout;

import nl.uwv.pws.ui.MainLayout;
import nl.uwv.pws.ui.NotAuthorizedException;
import nl.uwv.pws.ui.util.ExceptionHandler;
import nl.uwv.pws.ui.util.ExceptionWriter;
import nl.uwv.pws.ui.util.UIUtils;

@ParentLayout(MainLayout.class)
public class ErrorView extends InternalServerError {
   private static final Logger LOG = LoggerFactory.getLogger(ErrorView.class);

   @Override
   public int setErrorParameter(final BeforeEnterEvent event, final ErrorParameter<Exception> parameter) {
      Exception caughtException = parameter.getCaughtException();

      if (caughtException instanceof NotAuthorizedException) {
         handleNotAuthorized(event, caughtException);
      } else {
         handleInternalError(caughtException);
      }

      return HttpServletResponse.SC_INTERNAL_SERVER_ERROR;
   }

   private void handleNotAuthorized(final BeforeEnterEvent event, final Exception caughtException) {
      LOG.warn("NotAuthorizedException: {}", caughtException.getMessage());
      UIUtils.showErrorNotification(caughtException.getMessage());
      event.rerouteTo(NotAuthorizedView.class);
   }

   private void handleInternalError(final Exception caughtException) {
      LOG.error("Interne fout:", caughtException);
      ExceptionHandler.getInstance().writeException(caughtException);
      ExceptionWriter exceptionWriter = ExceptionWriter.getCurrentInstance();

      H2 title = new H2("Er is een interne fout opgetreden: " + exceptionWriter.getExceptionID());
      Span detail = new Span("Er is een interne fout opgetreden. Neem contact op met uw administrator");
      VerticalLayout errorLayout = new VerticalLayout(title, detail);
      getElement().appendChild(errorLayout.getElement());
   }
}
