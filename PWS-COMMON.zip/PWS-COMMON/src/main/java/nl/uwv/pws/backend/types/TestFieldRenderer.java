package nl.uwv.pws.backend.types;

import com.vaadin.flow.data.provider.DataKeyMapper;
import com.vaadin.flow.data.renderer.Renderer;
import com.vaadin.flow.data.renderer.Rendering;
import com.vaadin.flow.data.renderer.TemplateRenderer;
import com.vaadin.flow.dom.Element;
import com.vaadin.flow.function.ValueProvider;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

public class TestFieldRenderer<T extends RowId> extends Renderer<T> implements FieldRenderer<T> {
   private static final Logger LOG = LogManager.getLogger(TestFieldRenderer.class);

   private Field f;
   private ValueProvider<T, ?> v;

   protected TestFieldRenderer() {
      super();
   }

   public TestFieldRenderer(final Field f, final ValueProvider<T, ?> v) {
      super();
      this.f = f;
      this.v = v;
   }

   @Override
   public Renderer<T> render(final Field field, final ValueProvider<T, ?> value) {
      String propertyName = field.getPropertyWithDefault("p1");
      LOG.debug("FieldRenderer : " + field + ", value=" + value);
      return TemplateRenderer.<T>of("[[item." + propertyName + "]]")
            .withProperty(propertyName, value);
   }

   public String test(final Field field, final ValueProvider<T, ?> value) {
      String propertyName = field.getPropertyWithDefault("p2");
      LOG.debug("FieldRenderer : " + field + ", value=" + value);
      return "[[item." + propertyName + "]] = " + value;
   }

   @Override
   public Rendering<T> render(final Element container, final DataKeyMapper<T> keyMapper) {
      Renderer<T> r = render(f, v);
      return r.render(container, keyMapper);
   }

   @Override
   public Rendering<T> render(
         final Element container, final DataKeyMapper<T> keyMapper, final Element contentTemplate) {

      Renderer<T> r = render(f, v);
      return r.render(container, keyMapper, contentTemplate);
   }
}
