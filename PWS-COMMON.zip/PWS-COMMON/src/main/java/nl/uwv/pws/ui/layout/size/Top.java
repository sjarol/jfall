package nl.uwv.pws.ui.layout.size;

public enum Top implements Size {

   AUTO("auto", null),
   XS("var(--lumo-space-xs)", "spacing-t-xs"),
   S("var(--lumo-space-s)", "spacing-t-s"),
   M("var(--lumo-space-m)", "spacing-t-m"),
   L("var(--lumo-space-l)", "spacing-t-l"),
   XL("var(--lumo-space-xl)", "spacing-t-xl"),
   RESPONSIVE_M("var(--lumo-space-r-m)", null),
   RESPONSIVE_L("var(--lumo-space-r-l)", null),
   RESPONSIVE_X("var(--lumo-space-r-x)", null);

   LayoutSize topSize;

   Top(final String variable, final String spacingClassName) {
      topSize = new LayoutSize(variable, spacingClassName);
   }

   @Override
   public String[] getMarginAttributes() {
      return topSize.getMarginsWithSuffix(LayoutSize.SUFFIX_TOP);
   }

   @Override
   public String[] getPaddingAttributes() {
      return topSize.getPaddingsWithSuffix(LayoutSize.SUFFIX_TOP);
   }

   @Override
   public String getSpacingClassName() {
      return topSize.getSpacingClassName();
   }

   @Override
   public String getVariable() {
      return topSize.getVariable();
   }
}
