package nl.uwv.pws.backend.service;

import com.vaadin.flow.data.provider.QuerySortOrder;

import nl.uwv.pws.backend.dao.SqlFilter;
import nl.uwv.pws.backend.types.ColumnList;

import java.io.Serializable;
import java.util.List;

public interface ColumnListService extends Serializable {
   List<ColumnList> fetchRows(
         final SqlFilter sqlFilter, final int limit, final int offset, final List<QuerySortOrder> sortOrders
   );

   long countRows(final SqlFilter sqlFilter);
}
