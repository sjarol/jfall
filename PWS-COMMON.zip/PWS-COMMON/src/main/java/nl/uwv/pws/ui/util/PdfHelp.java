package nl.uwv.pws.ui.util;

import java.io.InputStream;
import java.io.Serializable;
import java.net.URL;

import org.apache.commons.io.FilenameUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.vaadin.flow.component.Key;
import com.vaadin.flow.component.KeyModifier;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.server.StreamResource;

import nl.uwv.pws.ui.components.BasicDialog;
import nl.uwv.pws.ui.components.EmbeddedPdfDocument;

/**
 * PdfHelp component Het component toont een PDF document als de help key (Shift
 * F1) of de help "(?)" buton gebruikt wordt. Het document wordt in een aparte
 * dialoog getoond die verplaatsbaar is en waarvan de grootte aangepast kan
 * worden.
 */
public class PdfHelp implements Serializable {
   private static final Logger LOG = LogManager.getLogger(PdfHelp.class);

   private final String helpDescription;
   private final String id;
   private Button help;
   private String helpPdfFilename;
   private String helpPdfUrl;

   public PdfHelp(final String helpPdfFilname, final String helpDescription) {
      this("pdf-hlp", helpPdfFilname, helpDescription);
   }

   public PdfHelp(final String id, final String helpPdfFilname, final String helpDescription) {
      this.id = id;
      if (PdfHelp.class.getResource(helpPdfFilname) == null) {
         this.helpPdfFilename = null;
         this.helpDescription = "Resource niet beschikbaar voor " + helpDescription;
         LOG.warn("Resource niet beschikbaar: " + helpPdfFilname);
      } else {
         this.helpPdfFilename = helpPdfFilname;
         this.helpDescription = helpDescription;
      }
   }

   public PdfHelp(final URL helpPdfUrl, final String helpDescription) {
      this("pdf-hlp", helpPdfUrl, helpDescription);
   }

   public PdfHelp(final String id, final URL helpPdfUrl, final String helpDescription) {
      this.id = id;
      this.helpPdfUrl = helpPdfUrl.toString();
      this.helpDescription = helpDescription;
   }

   public Button getButton() {
      if (help == null) {
         help = UIUtils.createContrastButton(VaadinIcon.QUESTION_CIRCLE_O);
         help.setId(id);
         help.addClickListener(e -> showHelp());
         help.addClickShortcut(Key.F1, KeyModifier.SHIFT);
         UIUtils.setTooltip(helpDescription, help);
      }
      return help;
   }

   protected void showHelp() {
      if (helpPdfFilename != null || helpPdfUrl != null) {
         EmbeddedPdfDocument helpPdfDoc;
         if (helpPdfUrl != null) {
            helpPdfDoc = new EmbeddedPdfDocument(helpPdfUrl);
         } else {
            helpPdfDoc = new EmbeddedPdfDocument(
                  new StreamResource(FilenameUtils.getName(helpPdfFilename), () -> getPdfInputStream(helpPdfFilename)));
         }
         BasicDialog dialog = new BasicDialog(null, helpDescription, "95vh", "50vw");
         dialog.setId("help-d");
         dialog.hideCancelButton();
         dialog.setResizable(true);
         dialog.setDraggable(true);

         dialog.setContent(helpPdfDoc);
         dialog.open();
      }
   }

   private InputStream getPdfInputStream(final String helpPdfDoc) {
      InputStream inputStream = null;
      try {
         inputStream = PdfHelp.class.getResourceAsStream(helpPdfDoc);
      } catch (Exception e) {
         UIUtils.handleError(e);
      }

      return inputStream;
   }
}
