package nl.uwv.pws.ui.components.detailsdrawer;

import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.tabs.Tabs;
import nl.uwv.pws.ui.components.FlexBoxLayout;
import nl.uwv.pws.ui.layout.size.Horizontal;
import nl.uwv.pws.ui.layout.size.Right;
import nl.uwv.pws.ui.layout.size.Vertical;
import nl.uwv.pws.ui.util.BoxShadowBorders;
import nl.uwv.pws.ui.util.UIUtils;

public class DetailsDrawerHeader extends FlexBoxLayout {

   private final Button close;
   private final Label title;

   public DetailsDrawerHeader(final String title) {
      super.addClassName(BoxShadowBorders.BOTTOM);
      super.setFlexDirection(FlexDirection.COLUMN);
      super.setWidthFull();

      this.close = UIUtils.createTertiaryInlineButton(VaadinIcon.CLOSE);
      UIUtils.setLineHeight("1", this.close);

      this.title = UIUtils.createH4Label(title);

      FlexBoxLayout wrapper = new FlexBoxLayout(this.close, this.title);
      wrapper.setAlignItems(FlexComponent.Alignment.CENTER);
      wrapper.setPadding(Horizontal.RESPONSIVE_L, Vertical.M);
      wrapper.setSpacing(Right.L);
      super.add(wrapper);
   }

   public DetailsDrawerHeader(final String title, final Tabs tabs) {
      this(title);
      add(tabs);
   }

   public void setTitle(final String title) {
      this.title.setText(title);
   }

   public void addCloseListener(final ComponentEventListener<ClickEvent<Button>> listener) {
      this.close.addClickListener(listener);
   }
}
