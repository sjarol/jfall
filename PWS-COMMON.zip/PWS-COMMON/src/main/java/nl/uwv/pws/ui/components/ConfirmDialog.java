package nl.uwv.pws.ui.components;

import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.HasStyle;
import com.vaadin.flow.component.Key;
import com.vaadin.flow.component.Shortcuts;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import nl.uwv.pws.ui.util.UIUtils;

import java.io.Serializable;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * A generic dialog for confirming or cancelling an action.
 *
 * @param <T> The type of the action's subject
 */
@CssImport(value = "./styles/components/dialog.css")
@CssImport(value = "./styles/components/confirmation-dialog.css", themeFor = "vaadin-*-overlay")
public class ConfirmDialog<T extends Serializable> extends Dialog implements HasStyle {

   private static final String COMPONENT_ID = "confirmation";

   public static final String CLASS_HEADER = "dialog-header";
   public static final String CLASS_CONTENT = "dialog-content";
   public static final String CLASS_FOOTER = "dialog-footer";

   // Footer
   private final Button saveButton = UIUtils.createPrimaryButton("Opslaan");
   private final Button cancelButton = UIUtils.createTertiaryButton("Annuleren");
   // Header
   private final Label titleField = UIUtils.createH2Label("");
   //  Content
   private final Label messageLabel = new Label();
   private final Label extraMessageLabel = new Label();

   // Flag that indicates if the confirm button was clicked before closing the dialog
   private final AtomicBoolean confirmed = new AtomicBoolean(false);

   private final T item;
   private final ConfirmHandler<T> confirmHandler;
   private final CancelHandler cancelHandler;

   /**
    * Constructs the confirmation dialog.
    * <p>
    * The dialog will display the given title and message(s), then call
    * <code>confirmHandler</code> if the Confirm button is clicked, or
    * <code>closeHandler</code> if the dialog is closed without clicking the confirm button.
    *
    * @param dialogSettings The dialog settings used to open this dialog.
    * @param item           The item the action applies to if confirmed.
    * @param confirmHandler The handler that will be invoked after the user clicks the confirm button.
    */
   public ConfirmDialog(
         final DialogSettings dialogSettings,
         final T item,
         final ConfirmHandler<T> confirmHandler) {
      this(dialogSettings, item, confirmHandler, null);
   }

   /**
    * Constructs the confirmation dialog.
    * <p>
    * The dialog will display the given title and message(s), then call
    * <code>confirmHandler</code> if the Confirm button is clicked, or
    * <code>closeHandler</code> if the dialog is closed without clicking the confirm button.
    *
    * @param title                The title for the dialog.
    * @param message              The message for the dialog.
    * @param confirmButtonCaption The caption to put onto the confirm button.
    * @param item                 The item the action applies to if confirmed.
    * @param confirmHandler       The handler that will be invoked after the user clicks the confirm button.
    */
   public ConfirmDialog(
         final String title,
         final String message,
         final String confirmButtonCaption,
         final T item,
         final ConfirmHandler<T> confirmHandler) {
      this(title, message, confirmButtonCaption, false, item, confirmHandler);
   }

   /**
    * Constructs the confirmation dialog.
    * <p>
    * The dialog will display the given title and message(s), then call
    * <code>confirmHandler</code> if the Confirm button is clicked, or
    * <code>closeHandler</code> if the dialog is closed without clicking the confirm button.
    *
    * @param title                The title for the dialog.
    * @param message              The message for the dialog.
    * @param confirmButtonCaption The caption to put onto the confirm button.
    * @param isDisruptive         Indicate whether the action to confirm is disruptive, true makes confirm button red.
    * @param item                 The item the action applies to if confirmed.
    * @param confirmHandler       The handler that will be invoked after the user clicks the confirm button.
    */
   public ConfirmDialog(
         final String title,
         final String message,
         final String confirmButtonCaption,
         final boolean isDisruptive,
         final T item,
         final ConfirmHandler<T> confirmHandler) {
      this(new DialogSettings(title, message, null, confirmButtonCaption, isDisruptive), item, confirmHandler, null);
   }

   /**
    * Constructs the confirmation dialog.
    * <p>
    * The dialog will display the given title and message(s), then call
    * <code>confirmHandler</code> if the Confirm button is clicked, or
    * <code>closeHandler</code> if the dialog is closed without clicking the confirm button.
    *
    * @param title                The title for the dialog.
    * @param message              The message for the dialog.
    * @param confirmButtonCaption The caption to put onto the confirm button.
    * @param isDisruptive         Indicate whether the action to confirm is disruptive, true makes confirm button red.
    * @param item                 The item the action applies to if confirmed.
    * @param confirmHandler       The handler that will be invoked after the user clicks the confirm button.
    * @param cancelHandler        The cancel handler that will be invoked when dialog is closed without confirming.
    */
   public ConfirmDialog(
         final String title,
         final String message,
         final String confirmButtonCaption,
         final boolean isDisruptive,
         final T item,
         final ConfirmHandler<T> confirmHandler,
         final CancelHandler cancelHandler) {
      this(
            new DialogSettings(title, message, null, confirmButtonCaption, isDisruptive),
            item,
            confirmHandler,
            cancelHandler
      );
   }

   /**
    * Constructs the confirmation dialog.
    * <p>
    * The dialog will display the given title and message(s), then call
    * <code>confirmHandler</code> if the Confirm button is clicked, or
    * <code>closeHandler</code> if the dialog is closed without clicking the confirm button.
    *
    * @param dialogSettings The dialog settings used to open this dialog.
    * @param item           The item the action applies to if confirmed.
    * @param confirmHandler The handler that will be invoked after the user clicks the confirm button.
    * @param cancelHandler  The cancel handler that will be invoked when dialog is closed without confirming.
    */
   public ConfirmDialog(
         final DialogSettings dialogSettings,
         final T item,
         final ConfirmHandler<T> confirmHandler,
         final CancelHandler cancelHandler) {

      this.item = item;
      this.confirmHandler = confirmHandler;
      this.cancelHandler = cancelHandler;

      super.setId(COMPONENT_ID);
      super.setCloseOnOutsideClick(false);

      VerticalLayout dialogStructure = new VerticalLayout(
            initHeader(dialogSettings), initFormLayout(dialogSettings), initFooter(dialogSettings)
      );

      super.addOpenedChangeListener(this::dialogOpenedOrClosed);
      super.add(dialogStructure);
   }

   private HorizontalLayout initHeader(final DialogSettings dialogSettings) {
      HorizontalLayout header = new HorizontalLayout(titleField);
      header.setClassName(CLASS_HEADER);
      header.setWidthFull();
      titleField.setText(dialogSettings.getTitle());

      return header;
   }

   private Component initFormLayout(final DialogSettings dialogSettings) {
      VerticalLayout content = new VerticalLayout();
      content.setClassName(CLASS_CONTENT);
      content.setWidthFull();
      content.add(messageLabel, extraMessageLabel);
      messageLabel.setText(dialogSettings.getMessage());
      extraMessageLabel.setText(dialogSettings.getAdditionalMessage());

      return content;
   }

   private HorizontalLayout initFooter(final DialogSettings dialogSettings) {
      HorizontalLayout footer = new HorizontalLayout(saveButton, cancelButton);
      footer.setClassName(CLASS_FOOTER);
      footer.setJustifyContentMode(FlexComponent.JustifyContentMode.END);
      footer.setWidthFull();

      saveButton.setId("operatie-bevestigen");
      saveButton.addClickListener(evt -> confirmButtonClicked());
      saveButton.setText(dialogSettings.getActionName());
      Shortcuts.addShortcutListener(this, this::confirmButtonClicked, Key.ENTER).listenOn(this);
      if (dialogSettings.isDisruptive()) {
         saveButton.addThemeVariants(ButtonVariant.LUMO_ERROR);
      }

      cancelButton.setId("operatie-annuleren");
      cancelButton.addClickListener(evt -> close());

      return footer;
   }

   private void confirmButtonClicked() {
      // Mark confirmed flag and close dialog
      confirmed.set(true);
      close();
   }

   private void dialogOpenedOrClosed(final OpenedChangeEvent<Dialog> evt) {
      if (!evt.isOpened()) {
         if (confirmed.get()) {
            // Confirm button was clicked, we need to run the confirmHandler
            ConfirmHandler<T> handler = confirmHandler;
            if (handler != null) {
               handler.confirmed(item);
            }
         } else {
            // Cancel button was clicked or ESC pressed or clicked outside of dialog or any other thing that cancels
            // We should run the closeHandler if available
            CancelHandler handler = cancelHandler;
            if (handler != null) {
               handler.canceled();
            }
         }
      }
   }
}
