package nl.uwv.pws.ui.components;

import java.io.Serializable;

/**
 * Handler to implement for responding to confirm-actions in a {@link ConfirmDialog}.
 *
 * @param <T> The type of object you want to confirm an action for in the {@link ConfirmDialog}.
 */
@FunctionalInterface
public interface ConfirmHandler<T extends Serializable> extends Serializable {
   /**
    * Triggered if the user confirms an action in the {@link ConfirmDialog}. This implementation allows you to actually
    * perform the action we just requested confirmation for. It is possible when opening the dialog to pass in an object
    * to confirm the action for. If you did, that parameter will be passed into this method for direct use.
    *
    * @param confirmedValue the value that was passed on to the ConfirmDialog on opening, may be null.
    */
   public void confirmed(final T confirmedValue);
}
