package nl.uwv.pws.ui.util;

import java.io.IOException;
import java.io.StringWriter;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.util.Collection;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;

import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.data.provider.DataCommunicator;
import com.vaadin.flow.data.provider.Query;

public abstract class AbstractCsvGridExporter<T> implements GridExporter<T> {
   public static final char CSV_SEP = ';';
   private static final CSVFormat CSVFORMAT = CSVFormat.RFC4180.withDelimiter(CSV_SEP);

   private Grid<T> myGrid;

   @Override
   public byte[] exportGrid(final Grid<T> grid) throws IOException {
      myGrid = grid;
      return getDataAsCsv().getBytes(StandardCharsets.UTF_8);
   }

   private String getDataAsCsv() throws IOException {
      StringWriter writer = new StringWriter();
      try {
         Collection<Grid.Column<T>> columns = myGrid.getColumns().stream()
               .filter(this::isExportable)
               .collect(Collectors.toList());
         if (!columns.isEmpty()) {
            try (CSVPrinter printer = new CSVPrinter(writer, CSVFORMAT)) {
               printHeader(printer, columns);
               printData(printer, columns);
            }
         }
      } catch (Exception e) {
         throw new IOException("Internefout tijden het maken van de csv export", e);
      }
      return writer.toString();
   }

   protected boolean isExportable(final Grid.Column<T> column) {
      return column.isVisible();
   }

   protected abstract void printHeader(
         final CSVPrinter printer,
         final Collection<Grid.Column<T>> columns
   ) throws IOException;

   @SuppressWarnings({"unchecked", "rawtypes"})
   private void printData(final CSVPrinter printer, final Collection<Grid.Column<T>> columns) throws IOException {
      Query streamQuery = new Query(0, myGrid.getDataProvider().size(new Query(getFilter())),
            myGrid.getDataCommunicator().getBackEndSorting(), myGrid.getDataCommunicator().getInMemorySorting(),
            null);
      Stream<T> dataStream = getDataStream(streamQuery);

      dataStream.forEach(row -> {

         try {
            printRow(printer, columns, row);
         } catch (IOException e) {
            UIUtils.handleError(e, "Fout tijdens schrijven csv data");
         }
      });
   }

   private Object getFilter() throws IOException {
      Object filter = null;
      try {
         Method method = DataCommunicator.class.getDeclaredMethod("getFilter");
         try {
            method.setAccessible(true);
            filter = method.invoke(myGrid.getDataCommunicator());
         } finally {
            method.setAccessible(false);
         }
      } catch (Exception e) {
         throw new IOException("Fout bij bepalen filter", e);
      }
      return filter;
   }

   abstract void printRow(
         final CSVPrinter printer,
         final Collection<Grid.Column<T>> columns,
         final T item
   ) throws IOException;

   @SuppressWarnings({"unchecked", "rawtypes"})
   private Stream<T> getDataStream(final Query newQuery) {
      Stream<T> stream = myGrid.getDataProvider().fetch(newQuery);
      if (stream.isParallel()) {
         stream = stream.collect(Collectors.toList()).stream();
         assert !stream.isParallel();
      }
      return stream;
   }
}
