package nl.uwv.pws.backend.service;

import javax.sql.DataSource;

import nl.uwv.pws.backend.lomo.LomoLogMessage;
import nl.uwv.pws.backend.lomo.LomoLogger;

public interface LomoLogServiceIfc {

   /**
    * @return the default Datasource for the lomo logging.
    */
   DataSource getLomoDataSource();

   void addLomoLogger(String programId, LomoLogger lomoLogger);

   /**
    * Logt een bericht in het LOMO log.
    * Het program id wordt opgehaald uit de applicatie.properties van de aanroepende applicatie.
    * @param applicatieFunctie
    * @param message
    */
   default void addLomoLog(String applicatieFunctie, LomoLogMessage message) {
      addLomoLog(null, applicatieFunctie, message);
   }

   /**
    * Logt een bericht in het LOMO log.
    *
    * @param programmaId (null => programId uit applicatie.properties)
    * @param applicatieFunctie
    * @param message
    */
   void addLomoLog(String programmaId, String applicatieFunctie, LomoLogMessage message);

}
