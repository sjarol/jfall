package nl.uwv.pws.backend.types;

public interface FieldProperty {
   String getFormattedValue(final Object value);

   String getName();

   String getType();

   String getLabel();

   String getWidth();

   int getFlexGrow();

   boolean isSortable();

   String getProperty();

   boolean isHidden();

   boolean usePlain();

   FieldDescription getFieldDescription();

}
