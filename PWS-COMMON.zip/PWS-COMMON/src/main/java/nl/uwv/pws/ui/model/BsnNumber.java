package nl.uwv.pws.ui.model;

import org.apache.commons.lang.StringUtils;

import java.util.regex.Pattern;

/**
 * Holds a single BSN number as well as some constants and convenience methods that can be used to validate and convert
 * BSN numbers properly.
 */
public class BsnNumber {
   /**
    * Number of characters expected in a BSN number.
    */
   public static final int AANTAL_TEKENS = 9;
   /**
    * Pattern that can be used to validate during input.
    */
   public static final String VALIDATIE_PATTERN = "\\d{0," + AANTAL_TEKENS + "}";
   /**
    * Compiled pattern that can be used to check validity of a BSN number.
    */
   public static final Pattern REGEX_PATTERN = Pattern.compile(VALIDATIE_PATTERN);

   /**
    * The BSN number that was input by the user.
    */
   private final String bsn;

   /**
    * Constructs a new BSN object.
    *
    * @param bsn The BSN number inputted by the user.
    */
   public BsnNumber(final String bsn) {
      if (bsn == null || bsn.isEmpty()) {
         this.bsn = "";
      } else {
         this.bsn = bsn.length() < AANTAL_TEKENS ? StringUtils.leftPad(bsn, AANTAL_TEKENS, '0') : bsn;
      }
   }

   /**
    * Returns the BSN number entered by the user.
    *
    * @return The BSN number entered by the user.
    */
   public String getBsn() {
      return bsn;
   }

   /**
    * Converts the current BSN number into an integer number, will return 0 if the internal bsn is null or empty.
    *
    * @return The current BSN number as an integer or 0 if the user hasn't entered a bsn number yet.
    */
   public int intValue() {
      if (bsn.isEmpty() || !REGEX_PATTERN.matcher(bsn).matches()) {
         return 0;
      }
      return Integer.parseInt(bsn);
   }

   /**
    * {@inheritDoc}
    */
   @Override
   public String toString() {
      return bsn;
   }
}
