package nl.uwv.pws.ui.components.navigation.bar;

import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.tabs.Tab;
import com.vaadin.flow.component.tabs.Tabs;

import nl.uwv.pws.ui.components.navigation.tab.NaviTabs;
import nl.uwv.pws.ui.util.LumoStyles;
import nl.uwv.pws.ui.util.UIUtils;
import nl.uwv.pws.ui.views.Dashboard;

@CssImport("./styles/components/tab-bar.css")
@SuppressWarnings("java:S110") // Class has too many parent
public class TabBar extends AbstractBar {
   private static final String CLASS_NAME = "tab-bar";

   public TabBar() {
      super();

      initTab();
      initTabs();

      add(menuIcon, tabs, addTab, avatar);
   }

   private void initTab() {
      addTab = UIUtils.createSmallButton(VaadinIcon.PLUS);
      addTab.addClickListener(e -> tabs
            .setSelectedTab(addClosableTab("New Tab", Dashboard.class)));
      addTab.setClassName(CLASS_NAME + "__add-tab");
   }

   private void initTabs() {
      tabs = new NaviTabs();
      tabs.setClassName(CLASS_NAME + "__tabs");
   }

   /* === TABS === */

   public void centerTabs() {
      tabs.addClassName(LumoStyles.Margin.Horizontal.AUTO);
   }

   private void configureTab(final Tab tab) {
      tab.addClassName(CLASS_NAME + "__tab");
   }

   public Tab addTab(final String text) {
      Tab tab = tabs.addTab(text);
      configureTab(tab);
      return tab;
   }

   public Tab addTab(final String text, final Class<? extends Component> navigationTarget) {
      Tab tab = tabs.addTab(text, navigationTarget);
      configureTab(tab);
      return tab;
   }

   public Tab addClosableTab(final String text, final Class<? extends Component> navigationTarget) {
      Tab tab = tabs.addClosableTab(text, navigationTarget);
      configureTab(tab);
      return tab;
   }

   public Tab getSelectedTab() {
      return tabs.getSelectedTab();
   }

   public void setSelectedTab(final Tab selectedTab) {
      tabs.setSelectedTab(selectedTab);
   }

   public void updateSelectedTab(final String text, final Class<? extends Component> navigationTarget) {
      tabs.updateSelectedTab(text, navigationTarget);
   }

   public void addTabSelectionListener(final ComponentEventListener<Tabs.SelectedChangeEvent> listener) {
      tabs.addSelectedChangeListener(listener);
   }

   public int getTabCount() {
      return tabs.getTabCount();
   }

   public void removeAllTabs() {
      tabs.removeAll();
   }

   /* === ADD TAB BUTTON === */

   public void setAddTabVisible(final boolean visible) {
      addTab.setVisible(visible);
   }

   @Override
   protected String getBarClassName() {
      return CLASS_NAME;
   }
}
