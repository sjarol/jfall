package nl.uwv.pws.ui.components;

import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;

/**
 * Simple Info-icon that gets a Tooltip attached for providing additional information to the end-user on hover.
 */
public class InfoIcon extends Div {
   public InfoIcon(final String tooltipText) {
      super.getStyle().set("width", "12px").set("height", "12px");

      Icon icon = new Icon(VaadinIcon.INFO_CIRCLE);
      icon.setSize("12px");
      icon.setColor("#0078d2");
      super.add(icon);

      super.add(Tooltip.builder().forComponent(icon).withBody(tooltipText).build());
   }
}
