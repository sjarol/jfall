package nl.uwv.pws.ui.util;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Defines the menu page for use with the MainLayou
 * <p>
 * The annotation PageTitle can't be used, instead the page should include
 * the use of the HasDynamicTitle interface.
 * </p>
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface PageMenuCode {
   /**
    * Gets the MenuPage that should be used to define page code, page name and page description to show in the
    * MainLayout application bar.
    * <p>
    * The value should match the menu code used in the menu table.
    * <p>
    *
    * @return the Authorization view name
    */
   String value();
}
