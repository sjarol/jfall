package nl.uwv.pws.backend.desc;

public class SampleResourceFieldDescriptor extends FieldDescriptor {

   private static final FieldDescParser parser = new FieldDescParser();

   public static final SampleResourceFieldDescriptor INCIDENTLOG;

   static {
      INCIDENTLOG = new SampleResourceFieldDescriptor("incidentlog.desc");
   }

   public SampleResourceFieldDescriptor(final String resource) {
      super(parser.parse(resource));
   }
}
