package nl.uwv.pws.ui.util;

import java.io.IOException;
import java.io.Serializable;

import com.vaadin.flow.component.grid.Grid;

public interface GridExporter<T> extends Serializable {
   public byte[] exportGrid(final Grid<T> grid) throws IOException;
}
