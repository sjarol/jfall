package nl.uwv.pws.backend.dao;

public enum SqlOperator {
   OR(" OR "),
   AND(" AND ");

   private final String code;

   SqlOperator(final String code) {
      this.code = code;
   }

   public String getCode() {
      return code;
   }
}
