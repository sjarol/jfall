package nl.uwv.pws.ui.layout;

import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;

/**
 * VerticalLayout without any padding or margin so you have the full area available for your components and it is safe
 * to use for grouping components vertically without them being indented.
 */
public class FullVerticalLayout extends VerticalLayout {
   public FullVerticalLayout() {
      init();
   }

   public FullVerticalLayout(final Component... children) {
      super(children);
      init();
   }

   private void init() {
      setPadding(false);
      setMargin(false);
   }
}
