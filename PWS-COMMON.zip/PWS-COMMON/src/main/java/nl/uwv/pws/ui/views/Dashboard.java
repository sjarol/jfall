package nl.uwv.pws.ui.views;

import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.vaadin.flow.component.AttachEvent;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.HasComponents;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.dependency.NpmPackage;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.FlexComponent.JustifyContentMode;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.router.HasDynamicTitle;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.router.RouteAlias;
import com.vaadin.shrinkwrap.VaadinCoreShrinkWrap;

import nl.uwv.pws.ApplicationInfo;
import nl.uwv.pws.backend.dao.MenuPage;
import nl.uwv.pws.backend.dao.PageAuthorization;
import nl.uwv.pws.backend.dao.User;
import nl.uwv.pws.backend.service.AuthorizationService;
import nl.uwv.pws.backend.service.UserService;
import nl.uwv.pws.ui.MainLayout;
import nl.uwv.pws.ui.components.FlexBoxLayout;
import nl.uwv.pws.ui.components.navigation.bar.AppBar;
import nl.uwv.pws.ui.components.navigation.drawer.NaviItem;
import nl.uwv.pws.ui.layout.size.Uniform;
import nl.uwv.pws.ui.util.LumoStyles;
import nl.uwv.pws.ui.util.PageMenuCode;
import nl.uwv.pws.ui.util.UIUtils;
import nl.uwv.pws.ui.util.css.BorderRadius;
import nl.uwv.pws.ui.util.css.BoxSizing;
import nl.uwv.pws.ui.util.css.Display;
import nl.uwv.pws.ui.util.css.FlexWrap;
import nl.uwv.pws.ui.util.css.Shadow;

@Route(value = "ui/dashboard", layout = MainLayout.class)
@RouteAlias(value = "", layout = MainLayout.class)
@PageMenuCode(Dashboard.MENU_CODE)
public class Dashboard extends ViewFrame implements HasDynamicTitle {
   static final String MENU_CODE = "APP01";
   private static final String APP_BAR_ID = "app-bar-workflows";

   private String databaseName;

   @Override
   protected void onAttachView(final AttachEvent attachEvent) {
      setId("home");
      initAppBar();
      setViewContent(createContent());
      setViewFooter(createFooter());
   }

   private Component createContent() {
      FlexBoxLayout menuContent = createMenuLayout();
      addMenuTiles(menuContent);
      return menuContent;
   }

   private FlexBoxLayout createMenuLayout() {
      FlexBoxLayout menuContent = new FlexBoxLayout();
      menuContent.setBorderRadius(BorderRadius.M);
      menuContent.setShadow(Shadow.M);
      menuContent.setBoxSizing(BoxSizing.BORDER_BOX);
      menuContent.setDisplay(Display.FLEX);
      menuContent.setCssFlexWrap(FlexWrap.WRAP);
      menuContent.setJustifyContentMode(JustifyContentMode.BETWEEN);
      menuContent.setWidthFull();
      return menuContent;
   }

   private void addMenuTiles(final HasComponents menuContent) {
      User loggedUser = UserService.getCurrentUser();
      if (loggedUser != null) {
         List<PageAuthorization> authorizedPages = AuthorizationService.get().getAuthorizedPages(loggedUser);
         authorizedPages.forEach(page -> addMenuTile(menuContent, page.getPage()));
      }
   }

   private void addMenuTile(final HasComponents menuContent, final MenuPage menuPage) {
      if (!MENU_CODE.equals(menuPage.getMenuCode())) {
         FlexBoxLayout tile = createTileLayout();

         NaviItem item = new NaviItem(
               UIUtils.getVaadinIcon(menuPage.getIconName()),
               menuPage.getMenuCode() + ", " + menuPage.getDescription(),
               menuPage.getUrl()
         );
         item.setSizeFull();
         tile.add(item);
         menuContent.add(tile);
      }
   }

   private FlexBoxLayout createTileLayout() {
      FlexBoxLayout tile = new FlexBoxLayout();
      tile.setBackgroundColor(LumoStyles.Color.Tint.PCT_30);
      tile.setBorderRadius(BorderRadius.S);
      tile.setShadow(Shadow.S);
      tile.setMargin(Uniform.S);
      tile.setFlexGrow(0.0);
      tile.setFlexShrink(1.0);
      tile.setMinWidth("12em");
      tile.setWidth("19%");
      tile.setHeight("4.5em");
      return tile;
   }

   private Component createFooter() {
      HorizontalLayout footer = new HorizontalLayout();
      if (!isProductionOrAccept()) {
         footer.add(getVersionInfo());
      }
      footer.add(getCopyRight());
      if (!isProductionOrAccept()) {
         footer.add(getDatabaseInfo());
      }
      footer.setWidthFull();

      return footer;
   }

   private void initAppBar() {
      AppBar appBar = MainLayout.get().getAppBar();
      appBar.setAppInfo(new ApplicationInfo());
      appBar.setId(APP_BAR_ID);
   }

   private Component getVersionInfo() {
      final String version = "version: " + VaadinCoreShrinkWrap.class.getAnnotation(NpmPackage.class).version();
      Button btnVersion = UIUtils.createButton(version, VaadinIcon.VAADIN_H, ButtonVariant.LUMO_ICON);
      btnVersion.setWidth(version.length() + "em");

      return btnVersion;
   }

   private Component getCopyRight() {
      Button copyright = UIUtils.createButton("2020 UWV", VaadinIcon.COPYRIGHT, ButtonVariant.LUMO_ICON);
      copyright.setWidthFull();

      return copyright;
   }

   private Component getDatabaseInfo() {
      Button btnDatabase = UIUtils.createButton(getDatabaseName(), VaadinIcon.DATABASE, ButtonVariant.LUMO_ICON);
      btnDatabase.setWidth(getDatabaseName().length() + "em");

      return btnDatabase;
   }

   private String getDatabaseName() {
      if (databaseName == null) {
         databaseName = AuthorizationService.get().getDatabaseName();
      }
      return databaseName;
   }

   private boolean isProductionOrAccept() {
      return StringUtils.startsWithAny(StringUtils.toRootUpperCase(getDatabaseName()), "A", "P");
   }
}
