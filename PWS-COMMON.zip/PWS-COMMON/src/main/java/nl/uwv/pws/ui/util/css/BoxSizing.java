package nl.uwv.pws.ui.util.css;

public enum BoxSizing {
   BORDER_BOX("border-box"),
   CONTENT_BOX("content-box");

   private final String value;

   BoxSizing(final String value) {
      this.value = value;
   }

   public String getValue() {
      return value;
   }
}
