package nl.uwv.pws.ui.components;

import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.grid.Grid.SelectionMode;
import com.vaadin.flow.component.grid.GridNoneSelectionModel;
import com.vaadin.flow.component.html.Anchor;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.server.StreamResource;
import com.vaadin.flow.shared.Registration;

import nl.uwv.pws.backend.desc.FieldDescriptor;
import nl.uwv.pws.backend.service.ColumnListDataProvider;
import nl.uwv.pws.ui.util.CsvBeanGridExporter;
import nl.uwv.pws.ui.util.CsvColumnListGridExporter;
import nl.uwv.pws.ui.util.GridExporter;
import nl.uwv.pws.ui.util.UIUtils;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.vaadin.flow.component.Composite;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;

public class LabelGrid<T> extends Composite<VerticalLayout> {
   private static final String FULL = "100%";
   private static final String GRID_FOOTER_CLASS = "footer";
   private static final String GRID_FOOTER_LEFT_CLASS = "footer-left";
   private static final String GRID_FOOTER_RIGHT_CLASS = "footer-right";
   private final Label label;
   private AuthorizedButton exportButton;
   private Anchor download;
   private final Grid<T> myGrid;
   private String labelText;
   private Long rows;
   private HorizontalLayout footerLeft;
   private HorizontalLayout footerRight;
   private GridExporter<T> exporter;
   private final List<Button> gridButtonEnableList = new ArrayList<>();
   private Registration regListener;

   public LabelGrid(final String labelText, final Grid<T> grid) {
      this(labelText, grid, FULL);
   }

   public LabelGrid(final String labelText, final Grid<T> grid, final String height) {
      this(labelText, grid, height, FULL);
   }

   public LabelGrid(final String labelText, final Grid<T> grid, final String height, final String width) {
      label = new Label();
      myGrid = grid;
      myGrid.setHeight(height);
      myGrid.setWidth(width);

      setLabel(labelText);

      super.getContent().setHeight(height);
      super.getContent().setWidth(width);
      super.getContent().setPadding(false);
      super.getContent().setMargin(false);
      super.getContent().add(label, grid, initFooter());
   }
   
   public static AuthorizedButton createExportButton(String label) {
      Icon i = new Icon(VaadinIcon.FILE_O);
      i.getElement().setAttribute("slot", "prefix");
      AuthorizedButton button = new AuthorizedButton(label, i);
      button.addThemeVariants(ButtonVariant.LUMO_TERTIARY);
      
      return button;
   }

   public void addDataSizeConsumerToProvider(final ColumnListDataProvider dataProvider) {
      if (dataProvider != null) {
         dataProvider.addCountRowsListener(this::setRows);
      }
   }

   public final void setLabel(final String text) {
      labelText = text;
      updateLabel();
   }

   public String getLabel() {
      return label.getText();
   }

   public Long getRows() {
      return rows;
   }

   private void setRows(final Long rows) {
      this.rows = rows;
      updateLabel();
      enableDownloadExport(rows);
   }

   private void updateLabel() {
      if (rows != null) {
         label.setText(String.format("%s (%d)", labelText, rows));
      } else {
         label.setText(labelText);
      }
   }

   private void enableDownloadExport(Long rows) {
      if (download != null) {
         download.setEnabled(rows > 0);
         exportButton.setEnabled(rows > 0);
      }
   }


   public Grid<T> getGrid() {
      return myGrid;
   }

   public void enableCsvExport(final AuthorizedButton button, final String fileName) {
      if (exporter == null) {
         exporter = new CsvBeanGridExporter<>(myGrid.getPropertySet());
      }
      if (download != null) {
         download.setHref(new StreamResource(fileName, this::getGridExport));
         download.remove(exportButton);
      } else {
         download = new Anchor(new StreamResource(fileName, this::getGridExport), "");
         download.getElement().setAttribute("download", true);
         footerLeft.add(download);
      }
      exportButton = button;
      download.add(exportButton);
   }

   public void enableCsvExport(final AuthorizedButton button, final String fileName,
         final FieldDescriptor fieldDescriptor) {
      exporter = new CsvColumnListGridExporter<>(fieldDescriptor);
      enableCsvExport(button, fileName);
   }

   /**
    * @param enableOnSelection
    * @param gridButtons
    */
   public void addGridButtonLeft(final boolean enableOnSelection, final Button... gridButtons) {
      footerLeft.add(gridButtons);
      addGridButtons(enableOnSelection, gridButtons);
   }

   /**
    * @param enableOnSelection
    * @param gridButtons
    */
   public void addGridButtonRight(final boolean enableOnSelection, final Button... gridButtons) {
      footerRight.add(gridButtons);
      addGridButtons(enableOnSelection, gridButtons);
   }

   private void addGridButtons(final boolean addToList, final Button... gridButtons) {
      if (gridButtons != null && addToList) {
         gridButtonEnableList.addAll(Arrays.asList(gridButtons));
         initListener();
         setGridButtonsEnabled(!myGrid.getSelectedItems().isEmpty());
      }
   }

   private void initListener() {
      if (regListener == null) {
         if (myGrid.getSelectionModel() instanceof GridNoneSelectionModel) {
            // Default to single row
            myGrid.setSelectionMode(SelectionMode.SINGLE);
         }
         regListener = myGrid.addSelectionListener(e -> setGridButtonsEnabled(e.getFirstSelectedItem().isPresent()));
      }
   }

   public void removeButton(final Button oldButton) {
      if (footerLeft.getChildren().anyMatch(e -> e == oldButton)) {
         footerLeft.remove(oldButton);
      } else if (footerRight.getChildren().anyMatch(e -> e == oldButton)) {
         footerRight.remove(oldButton);
      }
      gridButtonEnableList.remove(oldButton);
   }

   private void setGridButtonsEnabled(final boolean enabled) {
      for (Button button : gridButtonEnableList) {
         button.setEnabled(enabled);
      }
   }

   private InputStream getGridExport() {
      if (exportButton.isAuthorized()) {
         try {
            return new ByteArrayInputStream(exporter.exportGrid(myGrid));
         } catch (IOException e) {
            UIUtils.handleError(e, "Interne fout tijdens CSV export");
         }
      }
      return new ByteArrayInputStream(new byte[0]);
   }

   /**
    * @return footer
    */
   private HorizontalLayout initFooter() {
      HorizontalLayout footer = new HorizontalLayout();
      footer.setClassName(GRID_FOOTER_CLASS);
      footer.setWidthFull();

      //  LEFT side of the footer
      footerLeft = new HorizontalLayout();
      footerLeft.setClassName(GRID_FOOTER_LEFT_CLASS);
      footerLeft.setJustifyContentMode(FlexComponent.JustifyContentMode.START);
      footerLeft.setWidth("50%");
      footer.add(footerLeft);

      //  RIGHT side of the footer
      footerRight = new HorizontalLayout();
      footerRight.setClassName(GRID_FOOTER_RIGHT_CLASS);
      footerRight.setJustifyContentMode(FlexComponent.JustifyContentMode.END);
      footerRight.setWidth("50%");
      footer.add(footerRight);

      return footer;
   }
}
