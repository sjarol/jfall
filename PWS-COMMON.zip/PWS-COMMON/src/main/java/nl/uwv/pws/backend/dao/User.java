package nl.uwv.pws.backend.dao;

import java.util.Arrays;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.vaadin.flow.component.UI;
import com.vaadin.flow.server.VaadinResponse;
import com.vaadin.flow.server.VaadinService;
import com.vaadin.flow.server.VaadinSession;

import nl.uwv.pws.backend.lomo.LomoLogMessage;
import nl.uwv.pws.backend.lomo.LomoLogMessage.LomoResult;
import nl.uwv.pws.backend.lomo.LomoLogMessage.LomoTransaction;
import nl.uwv.pws.backend.service.LomoLogService;
import nl.uwv.pws.backend.service.UniqueSessionManager;
import nl.uwv.pws.backend.service.UserService;

public class User {

   private static final Logger LOG = LogManager.getLogger(User.class);
   private String username;
   private String[] roles;

   public static User createUser(final String username, final String... roles) {
      User user = new User();
      user.setUsername(username);
      user.setRoles(roles);
      return user;
   }

   public String getUsername() {
      return username;
   }

   public void setUsername(final String username) {
      this.username = username;
   }

   public String[] getRoles() {
      return roles;
   }

   public void setRoles(final String[] roles) {
      this.roles = roles;
   }

   public static void logout() {
      User user = UserService.getCurrentUser();
      if (user != null) {
         logout(user.getUsername(), false);
      }
   }

   public static void logout(final String userName, final boolean keepCurrentSession) {
      try {
         doUserLogout(userName);
         closeVaadinUI(keepCurrentSession);
         if (keepCurrentSession) {
            UniqueSessionManager.get().removeUserSession(userName);
         } else {
            if (VaadinSession.getCurrent() != null) {
               UniqueSessionManager.get().removeCurrentUserSession(userName);
               VaadinSession.getCurrent().close();
               VaadinService.getCurrentRequest().getWrappedSession().invalidate();
            } else {
               UniqueSessionManager.get().removeUserSession(userName);
            }
            resetCookies();
         }
      } catch (Exception e) {
         LOG.warn("Fout bij uitloggen: " + e.getClass().getName() + " - " + e.getMessage(), e);
      }
   }

   private static void resetCookies() {
      HttpServletResponse response = (HttpServletResponse) VaadinResponse.getCurrent();
      for (Cookie cookie : VaadinService.getCurrentRequest().getCookies()) {
         LOG.debug("Reset cookie: " + cookie.getName());
         cookie.setMaxAge(0);
         cookie.setValue("-");
         cookie.setPath("/");
         response.addCookie(cookie);
      }
   }

   private static void doUserLogout(final String userName) {
      if (userName != null) {
         String title = "Logout Polis+";
         String aktie = "Gebruiker uitloggen";
         try {
            UserService.get().logout(userName);
            LomoLogService.getInstance().addLomoLog(title,
                  new LomoLogMessage(aktie, LomoTransaction.LOGOUT, LomoResult.OK, "User is uitgelogd")
                        .addDetail("USER", userName));
         } catch (Exception e) {
            LOG.warn("Fout bij doUserLogout", e);
            LomoLogService.getInstance().addLomoLog(title,
                  new LomoLogMessage(aktie, LomoTransaction.LOGOUT, LomoResult.ERROR,
                        "Foutmelding " + e.getClass().getName() + ": " + e.getMessage())
                        .addDetail("USER", userName));
         }
      }
   }

   protected static void closeVaadinUI(final boolean keepCurrent) {
      if (UI.getCurrent() != null && UI.getCurrent().getSession() != null) {
         for (UI ui : UI.getCurrent().getSession().getUIs()) {
            if (!keepCurrent || ui != UI.getCurrent()) {
               ui.close();
            }
         }
      }
   }


   /* (non-Javadoc)
    * @see java.lang.Object#toString()
    */
   @Override
   public String toString() {
      StringBuilder builder = new StringBuilder();
      builder.append("User [username=");
      builder.append(username);
      builder.append(", roles=");
      builder.append(Arrays.toString(roles));
      builder.append("]");
      return builder.toString();
   }
}
