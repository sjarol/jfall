package nl.uwv.pws.ui.util;

import com.vaadin.flow.component.datepicker.DatePicker;

import java.text.DateFormatSymbols;
import java.util.Arrays;
import java.util.Locale;
import java.util.stream.Collectors;

public final class LocaleConstants {
   /**
    * Dutch locale that can be used to render things like numbers and dates in the proper format.
    */
   public static final Locale DUTCH_LOCALE = new Locale("nl", "NL");

   /**
    * Dutch DateFormSymbols that gives access to Dutch month names, weekday names, etc.
    */
   public static final DateFormatSymbols DUTCH_DATE_FORMAT_SYMBOLS = new DateFormatSymbols(DUTCH_LOCALE);

   /**
    * Dutch DatePickerI18N that can be used to show a Dutch version of the Vaadin
    * {@link com.vaadin.flow.component.datepicker.DatePicker} and
    * {@link com.vaadin.flow.component.datetimepicker.DateTimePicker}.
    */
   public static final DatePicker.DatePickerI18n DUTCH_DATE_PICKER_I18N =
         new DutchDatePickerI18n(DUTCH_DATE_FORMAT_SYMBOLS);

   private LocaleConstants() {
      // Do not construct
   }

   /**
    * Dutch implementation of the DatePickerI18n object that utilizes the given {@link DateFormatSymbols} to extract
    * names of months, weeks and short week-notations.
    */
   private static final class DutchDatePickerI18n extends DatePicker.DatePickerI18n {
      private DutchDatePickerI18n(final DateFormatSymbols dutchDateFormatSymbols) {
         String[] months = dutchDateFormatSymbols.getMonths();
         String[] weeks = dutchDateFormatSymbols.getWeekdays();
         String[] shortWeeks = dutchDateFormatSymbols.getShortWeekdays();

         // String arrays from DateFormatSymbols contain empty Strings, filter them out
         setMonthNames(Arrays.stream(months).filter(month -> !month.isEmpty()).collect(Collectors.toList()));
         setWeekdays(Arrays.stream(weeks).filter(week -> !week.isEmpty()).collect(Collectors.toList()));
         setWeekdaysShort(Arrays.stream(shortWeeks).filter(week -> !week.isEmpty()).collect(Collectors.toList()));

         setFirstDayOfWeek(1); // Monday
         setWeek("week");
         setCalendar("kalender");
         setClear("Wis");
         setToday("Vandaag");
         setCancel("Annuleren");
      }
   }
}
