package nl.uwv.pws.ui.util;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Defines the page name used for view authorization.
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface AuthorizedView {
   /**
    * Gets the View name that should be used.
    * <p>
    * The name should match the name used in the menu table
    * <p>
    *
    * @return the Authorization view name
    */
   String value();
}
