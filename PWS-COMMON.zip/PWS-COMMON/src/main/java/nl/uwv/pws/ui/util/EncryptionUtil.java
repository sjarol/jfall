package nl.uwv.pws.ui.util;

import nl.uwv.pws.ui.AppRuntimeException;

import javax.xml.bind.DatatypeConverter;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;

public final class EncryptionUtil {
   public static final String PARAMETER_SEPERATOR = "/";

   private EncryptionUtil() {
      // Empty private constructor, utility class
   }

   private static String encode(final String raw) {
      return Base64.getEncoder().encodeToString(raw.getBytes(StandardCharsets.UTF_8));
   }

   private static String decode(final String encodedString) {
      return new String(Base64.getDecoder().decode(encodedString), StandardCharsets.UTF_8);
   }

   private static String generateHash(final String string) {
      try {
         MessageDigest md = MessageDigest.getInstance("SHA-512");
         md.update(string.getBytes(StandardCharsets.UTF_8));
         byte[] digest = md.digest();
         return DatatypeConverter.printHexBinary(digest).toUpperCase();
      } catch (NoSuchAlgorithmException e) {
         throw new AppRuntimeException("An error has occured", e);
      }
   }

   /**
    * Encodes parameters and generates a hash, and adds the hash as the first
    * parameter
    */
   public static List<String> encodeParameters(final List<String> parameters) {
      String allParameters = String.join(PARAMETER_SEPERATOR, parameters);
      String hash = generateHash(allParameters);
      List<String> encodedParameters = new ArrayList<>();
      encodedParameters.add(hash);
      parameters.forEach(param -> encodedParameters.add(encode(param)));
      return encodedParameters;
   }

   /**
    * Encodes parameters and generates a hash, and adds the hash as the first
    * parameter
    */
   public static List<String> encodeParameters(final String... parameters) {
      List<String> params = Arrays.asList(parameters);
      return encodeParameters(params);
   }

   /**
    * Reads parameters that are joined by '/' chars - where the first one is the
    * hash generated returns decoded parameters if the generated hash matches
    */
   public static List<String> decodeParameters(final String parameter) {
      String[] parameters = parameter.split(PARAMETER_SEPERATOR);
      if (parameters.length < 2) {
         throw new IllegalArgumentException("Could not read parameters");
      }
      String hash = parameters[0];
      List<String> decodedParameters = new ArrayList<>();
      for (int i = 1; i < parameters.length; i++) {
         decodedParameters.add(decode(parameters[i]));
      }
      String generatedHash = generateHash(String.join(PARAMETER_SEPERATOR, decodedParameters));
      if (!hash.equals(generatedHash)) {
         throw new IllegalArgumentException("Could not read parameters");
      }
      return decodedParameters;
   }
}
