package nl.uwv.pws.ui.components;

import com.vaadin.flow.component.AbstractField.ComponentValueChangeEvent;
import com.vaadin.flow.component.*;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.internal.AbstractFieldSupport;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.FlexLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.provider.ListDataProvider;
import com.vaadin.flow.data.selection.MultiSelect;
import com.vaadin.flow.data.selection.MultiSelectionEvent;
import com.vaadin.flow.data.selection.MultiSelectionListener;
import com.vaadin.flow.data.selection.SelectionListener;
import com.vaadin.flow.data.value.ValueChangeMode;
import com.vaadin.flow.function.SerializablePredicate;
import com.vaadin.flow.shared.Registration;
import nl.uwv.pws.ui.util.FontSize;
import nl.uwv.pws.ui.util.TextColor;
import nl.uwv.pws.ui.util.UIUtils;
import org.apache.commons.lang3.StringUtils;

import java.io.Serializable;
import java.util.*;


public class TwinColSelect<T extends Serializable & Comparable<T>>
      extends Composite<FlexLayout> implements HasValidation, MultiSelect<TwinColSelect<T>, T> {

   private final AbstractFieldSupport<TwinColSelect<T>, Set<T>> fieldSupport;
   private final Label error;

   private Grid<T> leftColumnItemsList;
   private Grid<T> rightColumnItemsList;
   private ListDataProvider<T> leftColumnItemsDataProvider;
   private ListDataProvider<T> rightColumnItemsDataProvider;
   private Button selectButton;
   private Button deselectButton;

   private FlexBoxLayout header;
   private String sidetoFilter;
   private TextField itemsFilter;
   private boolean invalid = false;
   private boolean valueIsChanging = false;

   private final Set<T> selectedItems;
   private ItemLabelGenerator<T> itemLabelGenerator = Object::toString;

   public TwinColSelect() {
      this("Beschikbaar", "Geselecteerd");
   }

   private TwinColSelect(final String labelAvailableItems, final String labelSelectedItems) {
      fieldSupport = new AbstractFieldSupport<>(this, null, this::valueEquals, this::selectItems);
      selectedItems = new HashSet<>();
      error = UIUtils.createLabel(FontSize.XS, TextColor.ERROR, "");
      error.setVisible(false);

      initFilter();
      initLeftColumn(labelAvailableItems);
      initRightColumn(labelSelectedItems);
      initButtons();
      initHeader();

      FlexBoxLayout twinColSelect = new FlexBoxLayout(createTwinColSelect());
      twinColSelect.setWidth("100%");
      twinColSelect.setMinHeight("300px");

      VerticalLayout pageContainer = new VerticalLayout(header, twinColSelect, error);
      pageContainer.setSizeFull();

      super.getContent().add(pageContainer);
   }

   private void initHeader() {
      header = new FlexBoxLayout(itemsFilter);
      header.setWidthFull();
   }

   private void initFilter() {
      itemsFilter = new TextField("Zoekfilter");
      itemsFilter.setWidthFull();
      itemsFilter.setClearButtonVisible(true);
      itemsFilter.setValueChangeMode(ValueChangeMode.EAGER);

      if (sidetoFilter != null && StringUtils.equals(sidetoFilter, "LEFT")) {
         itemsFilter.addValueChangeListener(evt -> leftColumnItemsDataProvider.refreshAll());
      } else if (sidetoFilter != null && StringUtils.equals(sidetoFilter, "RIGHT")) {
         itemsFilter.addValueChangeListener(evt -> rightColumnItemsDataProvider.refreshAll());
      } else {
         itemsFilter.addValueChangeListener(evt -> leftColumnItemsDataProvider.refreshAll());
         itemsFilter.addValueChangeListener(evt -> rightColumnItemsDataProvider.refreshAll());
      }
   }

   private void initRightColumn(final String labelSelectedItems) {
      rightColumnItemsDataProvider = new ListDataProvider<>(Collections.emptyList());
      rightColumnItemsDataProvider.setFilter(this::canDisplayInLeftColumnItems);
      rightColumnItemsList = initColumn(
            labelSelectedItems,
            rightColumnItemsDataProvider,
            evt -> deselectButton.setEnabled(!evt.getAllSelectedItems().isEmpty())
      );
   }

   private void initLeftColumn(final String labelAvailableItems) {
      leftColumnItemsDataProvider = new ListDataProvider<>(Collections.emptyList());
      leftColumnItemsDataProvider.setFilter(this::canDisplayInRightColumnItems);
      leftColumnItemsList = initColumn(
            labelAvailableItems,
            leftColumnItemsDataProvider,
            evt -> selectButton.setEnabled(!evt.getAllSelectedItems().isEmpty())
      );
   }

   private Grid<T> initColumn(
         final String label,
         final ListDataProvider<T> dataProvider,
         final SelectionListener<Grid<T>, T> selectionListener) {

      Grid<T> grid = new Grid<>();
      grid.setVerticalScrollingEnabled(true);
      grid.setSelectionMode(Grid.SelectionMode.MULTI);
      grid.setSizeFull();
      grid.addColumn(row -> itemLabelGenerator.apply(row)).setHeader(label);
      grid.setDataProvider(dataProvider);
      grid.addSelectionListener(selectionListener);
      return grid;
   }

   private void initButtons() {
      selectButton = UIUtils.createPrimaryButton(VaadinIcon.ANGLE_RIGHT);
      selectButton.setEnabled(false);

      deselectButton = UIUtils.createPrimaryButton(VaadinIcon.ANGLE_LEFT);
      deselectButton.setEnabled(false);

      selectButton.addClickListener(evt -> selectItems(leftColumnItemsList.getSelectedItems()));
      deselectButton.addClickListener(evt -> deselectItems(rightColumnItemsList.getSelectedItems()));
   }

   @Override
   public void setEnabled(final boolean enabled) {
      selectButton.setEnabled(enabled);
      deselectButton.setEnabled(enabled);
      leftColumnItemsList.setEnabled(enabled);
      rightColumnItemsList.setEnabled(enabled);
      itemsFilter.setEnabled(enabled);
   }

   private FlexBoxLayout createTwinColSelect() {
      FlexBoxLayout content = new FlexBoxLayout();
      content.setAlignItems(FlexComponent.Alignment.CENTER);
      content.setJustifyContentMode(FlexComponent.JustifyContentMode.CENTER);

      FlexBoxLayout buttonsFlexBox = new FlexBoxLayout(selectButton, deselectButton);
      buttonsFlexBox.setJustifyContentMode(FlexComponent.JustifyContentMode.AROUND);
      buttonsFlexBox.getStyle().set("flexDirection", "column");
      buttonsFlexBox.getStyle().set("margin", "0 30px");

      content.add(leftColumnItemsList);
      content.add(buttonsFlexBox);
      content.add(rightColumnItemsList);
      content.setSizeFull();
      return content;
   }

   public void filterOnLeft() {
      sidetoFilter = "LEFT";
      header.setWidth("47%");
      header.getElement().getStyle().set("margin-right", "auto");
   }

   public void filterOnRight() {
      sidetoFilter = "RIGHT";
      header.setWidth("47%");
      header.getElement().getStyle().set("margin-left", "auto");
   }

   private boolean canDisplayInRightColumnItems(final T row) {
      return !selectedItems.contains(row) && applyTextFilter(row, itemsFilter.getValue());
   }

   private boolean canDisplayInLeftColumnItems(final T row) {
      return applyTextFilter(row, itemsFilter.getValue());
   }

   private void selectItems(final Set<T> values) {
      updateSelection(values, new HashSet<>());
      leftColumnItemsList.deselectAll();
   }

   private void deselectItems(final Set<T> values) {
      updateSelection(new HashSet<>(), values);
      rightColumnItemsList.deselectAll();
   }

   public void setItems(final Collection<T> items) {
      setAllItems(items);
   }

   private void setAllItems(final Collection<T> items) {
      SerializablePredicate<T> existingFilter = leftColumnItemsDataProvider.getFilter();
      leftColumnItemsDataProvider = new ListDataProvider<>(items);
      leftColumnItemsDataProvider.setFilter(existingFilter);
      leftColumnItemsList.setDataProvider(leftColumnItemsDataProvider);
   }

   public void setItemCaptionGenerator(final ItemLabelGenerator<T> itemLabelGenerator) {
      this.itemLabelGenerator = itemLabelGenerator;
   }

   private boolean applyTextFilter(final T row, final String filterValue) {
      if (StringUtils.isEmpty(filterValue)) {
         return true;
      }
      String[] filters = filterValue.split(" ");
      boolean shouldDisplay = true;
      for (String filter : filters) {
         shouldDisplay = shouldDisplay && itemLabelGenerator.apply(row).toLowerCase().contains(filter.toLowerCase());
      }
      return shouldDisplay;
   }

   @Override
   public void updateSelection(final Set<T> addedItems, final Set<T> removedItems) {
      selectedItems.removeAll(removedItems);
      selectedItems.addAll(addedItems);
      leftColumnItemsDataProvider.refreshAll();
      setSelectedItems(selectedItems);
      setValue(selectedItems);
   }

   @Override
   public Set<T> getSelectedItems() {
      return selectedItems;
   }

   private void setSelectedItems(final Collection<T> items) {
      SerializablePredicate<T> existingFilter = rightColumnItemsDataProvider.getFilter();
      rightColumnItemsDataProvider.setFilter(existingFilter);
      List<T> itemsList = new ArrayList<>(items);
      Collections.sort(itemsList);
      rightColumnItemsDataProvider = new ListDataProvider<>(itemsList);
      rightColumnItemsList.setDataProvider(rightColumnItemsDataProvider);
   }

   @SuppressWarnings("unchecked")
   @Override
   public Registration addSelectionListener(final MultiSelectionListener<TwinColSelect<T>, T> listener) {
      @SuppressWarnings("rawtypes")
      ComponentEventListener componentListener = event -> listener
            .selectionChange(new MultiSelectionEvent<>(this, this, selectedItems, false));
      return ComponentUtil.addListener(this, MultiSelectionEvent.class, componentListener);
   }

   @Override
   public String getErrorMessage() {
      return error.getText();
   }

   @Override
   public void setErrorMessage(final String errorMessage) {
      setInvalid(StringUtils.isNotBlank(errorMessage));
      error.setVisible(isInvalid());
      error.setText(errorMessage);
   }

   @Override
   public boolean isInvalid() {
      return invalid;
   }

   @Override
   public void setInvalid(final boolean invalid) {
      this.invalid = invalid;
      error.setVisible(invalid);
   }

   private boolean valueEquals(final Set<T> value1, final Set<T> value2) {
      return fieldSupport.valueEquals(value1, value2);
   }

   @Override
   public Set<T> getValue() {
      return fieldSupport.getValue();
   }

   @Override
   public void setValue(final Set<T> values) {
      if (valueIsChanging) {
         return;
      }
      valueIsChanging = true;
      try {
         if (values == null || values.isEmpty()) {
            deselectAll();
         } else {
            select(values);
         }
         if (values == null) {
            fieldSupport.setValue(null);
         } else {
            fieldSupport.setValue(new HashSet<>(values));
         }
      } finally {
         valueIsChanging = false;
      }
   }

   @Override
   public Registration addValueChangeListener(
         final ValueChangeListener<? super ComponentValueChangeEvent<TwinColSelect<T>, Set<T>>> listener) {
      return fieldSupport.addValueChangeListener(listener);
   }


   public void addAdditionalFilter(final Component... additionalFilter) {
      header.setWidth("100%");
      itemsFilter.setWidth("47%");

      if (sidetoFilter != null && StringUtils.equals(sidetoFilter, "LEFT")) {
         itemsFilter.getElement().getStyle().set("margin-right", "97px");
         header.add(additionalFilter);
      } else {
         //  TODO: px must equal to buttonsFlexBox.getWidth()
         itemsFilter.getElement().getStyle().set("margin-left", "97px");
         header.add(additionalFilter);
      }
   }
}
