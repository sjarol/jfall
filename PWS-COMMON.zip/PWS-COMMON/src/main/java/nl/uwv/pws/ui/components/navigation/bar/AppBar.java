package nl.uwv.pws.ui.components.navigation.bar;

import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.tabs.Tab;
import com.vaadin.flow.component.tabs.Tabs;
import com.vaadin.flow.shared.Registration;

import nl.uwv.pws.backend.dao.MenuPage;
import nl.uwv.pws.ui.components.FlexBoxLayout;
import nl.uwv.pws.ui.components.navigation.tab.NaviTab;
import nl.uwv.pws.ui.components.navigation.tab.NaviTabs;
import nl.uwv.pws.ui.util.LumoStyles;
import nl.uwv.pws.ui.util.UIUtils;
import nl.uwv.pws.ui.views.Dashboard;

import java.util.ArrayList;

@CssImport("./styles/components/app-bar.css")
@SuppressWarnings("java:S110") // Class has too many parent
public class AppBar extends AbstractBar {

   private static final String CLASS_NAME = "app-bar";

   private ArrayList<Registration> tabSelectionListeners;

   public AppBar(final NaviTab... tabs) {
      this(new MenuPage(), tabs);
   }

   public AppBar(final MenuPage page, final NaviTab... tabs) {
      super(page);
      init(tabs);
   }

   /**
    * @deprecated Use one of the other constructors instead.
    */
   @Deprecated
   public AppBar(final String title, final NaviTab... tabs) {
      super();
      super.setTitle(title);
      init(tabs);
   }

   private void init(final NaviTab... tabs) {
      initContainer();
      initTabs(tabs);
   }

   private void initContainer() {
      FlexBoxLayout container = new FlexBoxLayout(menuIcon, pageCodeIcon, pageTitle, actionItems, avatar);
      container.addClassName(CLASS_NAME + "__container");
      container.setAlignItems(FlexComponent.Alignment.CENTER);
      add(container);
   }

   private void initTabs(final NaviTab... tabs) {
      addTab = UIUtils.createSmallButton(VaadinIcon.PLUS);
      addTab.addClickListener(e -> this.tabs
            .setSelectedTab(addClosableNaviTab("New Tab", Dashboard.class)));
      addTab.setVisible(false);

      this.tabs = tabs.length > 0 ? new NaviTabs(tabs) : new NaviTabs();
      this.tabs.setClassName(CLASS_NAME + "__tabs");
      this.tabs.setVisible(false);
      for (NaviTab tab : tabs) {
         configureTab(tab);
      }

      this.tabSelectionListeners = new ArrayList<>();

      FlexBoxLayout tabContainer = new FlexBoxLayout(this.tabs, addTab);
      tabContainer.addClassName(CLASS_NAME + "__tab-container");
      tabContainer.setAlignItems(FlexComponent.Alignment.CENTER);
      add(tabContainer);
   }

   /* === TABS === */

   public void centerTabs() {
      tabs.addClassName(LumoStyles.Margin.Horizontal.AUTO);
   }

   private void configureTab(final Tab tab) {
      tab.addClassName(CLASS_NAME + "__tab");
      updateTabsVisibility();
   }

   public Tab addTab(final String text) {
      return addTab(tabs.addTab(text));
   }

   public Tab addTab(final Tab tab) {
      tabs.add(tab);
      configureTab(tab);
      return tab;
   }

   public Tab addTab(final String text, final Class<? extends Component> navigationTarget) {
      Tab tab = tabs.addTab(text, navigationTarget);
      configureTab(tab);
      return tab;
   }

   public Tab addClosableNaviTab(final String text, final Class<? extends Component> navigationTarget) {
      Tab tab = tabs.addClosableTab(text, navigationTarget);
      configureTab(tab);
      return tab;
   }

   public Tab getSelectedTab() {
      return tabs.getSelectedTab();
   }

   public void setSelectedTab(final Tab selectedTab) {
      tabs.setSelectedTab(selectedTab);
   }

   public void updateSelectedTab(final String text, final Class<? extends Component> navigationTarget) {
      tabs.updateSelectedTab(text, navigationTarget);
   }

   public void navigateToSelectedTab() {
      tabs.navigateToSelectedTab();
   }

   public void addTabSelectionListener(final ComponentEventListener<Tabs.SelectedChangeEvent> listener) {
      Registration registration = tabs.addSelectedChangeListener(listener);
      tabSelectionListeners.add(registration);
   }

   public int getTabCount() {
      return tabs.getTabCount();
   }

   public void removeAllTabs() {
      tabSelectionListeners.forEach(Registration::remove);
      tabSelectionListeners.clear();
      tabs.removeAll();
      updateTabsVisibility();
   }

   /* === ADD TAB BUTTON === */

   public void setAddTabVisible(final boolean visible) {
      addTab.setVisible(visible);
   }

   /* === RESET === */

   public void reset() {
      reset(null);
   }

   public void reset(final MenuPage page) {
      if (page != null) {
         setMenuPage(page);
      } else {
         setPageIcon(null);
         setPageCode("");
         setTitle("");
      }
      removeAllActionItems();
      removeAllTabs();
   }

   /* === UPDATE VISIBILITY === */

   private void updateTabsVisibility() {
      tabs.setVisible(tabs.getComponentCount() > 0);
   }

   @Override
   protected String getBarClassName() {
      return CLASS_NAME;
   }
}
