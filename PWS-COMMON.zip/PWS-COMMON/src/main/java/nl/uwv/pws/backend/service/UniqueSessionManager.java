package nl.uwv.pws.backend.service;

import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.collections4.map.PassiveExpiringMap;

import com.helger.commons.base64.Base64;
import com.vaadin.flow.server.VaadinService;

public final class UniqueSessionManager {
   private static final int ENTRY_EXPIRATION_TIME = 5;
   private static final int LOGIN_EXPIRATION_TIME = 15;
   public static final int SESSION_ID_LENGTH = 52;

   private Map<String, String> userSessionMap = new PassiveExpiringMap<>(ENTRY_EXPIRATION_TIME, TimeUnit.MINUTES);
   private Map<String, String> loginSessionMap = new PassiveExpiringMap<>(LOGIN_EXPIRATION_TIME, TimeUnit.MINUTES);
   private static UniqueSessionManager instance = new UniqueSessionManager();

   private UniqueSessionManager() {
      // Utility class
   }

   public static UniqueSessionManager get() {
      return instance;
   }

   public void insertCurrentUserSession(final String username) {
      String sessionId = getCurrentSessionId();
      if (SessionService.get().insertUserSession(username, sessionId)) {
         userSessionMap.put(username, sessionId);
      }
   }

   public void insertUserLoginSession(final String username) {
      loginSessionMap.put(username, getCurrentSessionId());
   }

   public void removeUserSession(final String username) {
      if (userSessionMap.containsKey(username)) {
         userSessionMap.remove(username);
      }
      SessionService.get().removeUserSession(username);
   }

   public void removeCurrentUserSession(final String username) {
      String sessionId = getCurrentSessionId();
      if (userSessionMap.containsKey(username) && sessionId.equals(userSessionMap.get(username))) {
         userSessionMap.remove(username);
      }
      SessionService.get().removeUserSession(username, sessionId);
   }

   public void removeUserLoginSession(final String username) {
      if (loginSessionMap.containsKey(username)) {
         loginSessionMap.remove(username);
      }
   }

   public boolean isActiveSession(final String username) {
      String sessionId = getCurrentSessionId();
      if (hasActiveSession(username)) {
         return sessionId.equals(userSessionMap.get(username));
      }
      return false;
   }

   public boolean isLoginSession(final String username) {
      if (loginSessionMap.containsKey(username)) {
         return getCurrentSessionId().equals(loginSessionMap.get(username));
      }
      return false;
   }

   public boolean hasActiveSession(final String username) {
      if (userSessionMap.containsKey(username)) {
         return true;
      }
      String activeSessionId = SessionService.get().getUserSession(username);
      if (activeSessionId != null) {
         userSessionMap.put(username, activeSessionId);
         return true;
      }
      return false;
   }

   /**
    * Maak een SHA-512 hash in Base64 formaat
    *
    * @param sessionId
    * @return
    */
   public static String hashSessionId(final String sessionId) {
      return Base64.encodeBytes(DigestUtils.sha512(sessionId));
   }

   /**
    * Bepaal het (hashed) session ID van de HTTP sessie
    *
    * @return sessionId
    */
   public static String getCurrentSessionId() {
      String sessionId = VaadinService.getCurrentRequest().getWrappedSession().getId();
      // Knip sessie id op 52 tekens (weblogic default)
      if (sessionId.length() > SESSION_ID_LENGTH) {
         sessionId = sessionId.substring(0, SESSION_ID_LENGTH);
      }
      return hashSessionId(sessionId);
   }
}
