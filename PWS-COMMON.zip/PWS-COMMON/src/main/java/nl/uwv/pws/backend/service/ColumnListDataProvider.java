package nl.uwv.pws.backend.service;

import com.vaadin.flow.data.provider.AbstractBackEndDataProvider;
import com.vaadin.flow.data.provider.Query;
import com.vaadin.flow.function.SerializableConsumer;

import nl.uwv.pws.backend.dao.SqlFilter;
import nl.uwv.pws.backend.types.ColumnList;

import java.util.LinkedList;
import java.util.List;
import java.util.stream.Stream;

public class ColumnListDataProvider extends AbstractBackEndDataProvider<ColumnList, SqlFilter> {
   @SuppressWarnings("java:S1948") // The implementation is LinkedList, which is already Serializable
   private final List<CountRowsListener> countRowsListeners = new LinkedList<>();

   @SuppressWarnings("java:S1948") // The implementation is LinkedList, which is already Serializable
   private final List<FetchRowsListener> fetchRowsListeners = new LinkedList<>();

   private final ColumnListService listService;

   public ColumnListDataProvider(final ColumnListService listService) {
      this.listService = listService;
   }

   /**
    * Sets a DataSizeConsumer that will consume the number of rows as soon as it is fetched from the database.
    *
    * @param dataSizeConsumer The dataSizeConsumer.
    * @deprecated Use the more generic {@link #addCountRowsListener} instead.
    */
   @Deprecated
   public void setDataSizeConsumer(final SerializableConsumer<Long> dataSizeConsumer) {
      addCountRowsListener(dataSizeConsumer::accept);
   }

   @Override
   protected Stream<ColumnList> fetchFromBackEnd(final Query<ColumnList, SqlFilter> query) {
      List<ColumnList> rows = listService.fetchRows(
            query.getFilter().orElse(null),
            query.getLimit(),
            query.getOffset(),
            query.getSortOrders()
      );
      return triggerFetchRowsListeners(rows).stream();
   }

   /**
    * Triggers all registered fetchRowsListeners.
    *
    * @param rows The (subset of) rows that were just fetched.
    * @return The input rows for easy method chaining.
    */
   private List<ColumnList> triggerFetchRowsListeners(final List<ColumnList> rows) {
      fetchRowsListeners.forEach(fetchRowsListener -> fetchRowsListener.rowsFetched(rows));
      return rows;
   }

   @Override
   protected int sizeInBackEnd(final Query<ColumnList, SqlFilter> query) {
      long rows = listService.countRows(query.getFilter().orElse(null));
      return (int) triggerCountRowsListeners(rows);
   }

   /**
    * Triggers all registered countRowsListeners.
    *
    * @param rowCount The total numbers of matching rows in the database.
    * @return The input rowCount for easy method chaining.
    */
   private long triggerCountRowsListeners(final long rowCount) {
      countRowsListeners.forEach(countRowsListener -> countRowsListener.rowsCounted(rowCount));
      return rowCount;
   }

   /**
    * Adds a listener that gets notified after the rows were counted.
    *
    * @param countRowsListener The listener that will get notified when the rows were counted.
    */
   @SuppressWarnings("java:S2250") // calling contains() on limited number of listeners is no performance issue
   public void addCountRowsListener(final CountRowsListener countRowsListener) {
      if (!countRowsListeners.contains(countRowsListener)) {
         countRowsListeners.add(countRowsListener);
      }
   }

   /**
    * Adds a listener that gets notified after a list of rows were fetched.
    *
    * Note: Vaadin often fetches subsets of rows and not all rows at once, therefore you must take into
    * account in your implementation that you may get multiple calls to this method with different subsets
    * of all available rows.
    *
    * @param fetchRowsListener The listener that will get notified when rows were fetched.
    */
   @SuppressWarnings("java:S2250") // calling contains() on limited number of listeners is no performance issue
   public void addFetchRowsListener(final FetchRowsListener fetchRowsListener) {
      if (!fetchRowsListeners.contains(fetchRowsListener)) {
         fetchRowsListeners.add(fetchRowsListener);
      }
   }

   /**
    * Removes a countRowsListener that was attached earlier.
    *
    * @param countRowsListener The countRowsListener to remove.
    */
   public void removeCountRowsListener(final CountRowsListener countRowsListener) {
      countRowsListeners.remove(countRowsListener);
   }

   /**
    * Removes a fetchRowsListener that was attached earlier.
    *
    * @param fetchRowsListener The fetchRowsListener to remove.
    */
   public void removeFetchRowsListener(final FetchRowsListener fetchRowsListener) {
      fetchRowsListeners.remove(fetchRowsListener);
   }
}
