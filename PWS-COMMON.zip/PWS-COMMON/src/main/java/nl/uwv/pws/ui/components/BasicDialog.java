package nl.uwv.pws.ui.components;

import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import nl.uwv.pws.ui.util.UIUtils;
import nl.uwv.pws.ui.views.ViewFrame;

/**
 * Base class for basic dialogs for viewing elaborated information of items.
 * This dialog only consists of a cancel action
 *
 * @deprecated De annuleren knop staat hier nog links, schakel over op de {@link StyledDialog} om deze rechts te zetten.
 */
@Deprecated
public class BasicDialog extends AbstractDialog {
   private static final String COMPONENT_HEADER_CLASS = "header";

   /**
    * @param parent to check for authorisation
    * @param title  of the dialog
    */
   public BasicDialog(final ViewFrame parent, final String title) {
      super(parent, title);
   }

   /**
    * @param parent to check for authorisation
    * @param title  of the dialog
    * @param width  of the dialog
    * @param height of the dialog
    */
   public BasicDialog(final ViewFrame parent, final String title, final String width, final String height) {
      super(parent, title, width, height);
   }

   /**
    * @param parent               to check for authorisation
    * @param title                of the dialog
    * @param width                of the dialog
    * @param height               of the dialog
    * @param inheritedComponentId CSS ID to give to the component
    */
   public BasicDialog(
         final ViewFrame parent,
         final String title,
         final String width,
         final String height,
         final String inheritedComponentId) {
      super(parent, title, width, height, inheritedComponentId);
   }

   @Override
   void initHeader(final HorizontalLayout headerToInitialize) {
      headerToInitialize.setClassName(COMPONENT_HEADER_CLASS);
   }

   @Override
   Button createAndPlaceCancelButton(final HorizontalLayout footerLeft, final HorizontalLayout footerRight) {
      Button cancelButton = UIUtils.createTertiaryButton("Annuleren");
      footerLeft.add(cancelButton);
      return cancelButton;
   }

   @Override
   void addCancelButtonAsFirstOnFooter(
         final Button cancelButton,
         final HorizontalLayout footerLeft,
         final HorizontalLayout footerRight) {
      footerLeft.addComponentAsFirst(cancelButton);
   }
}
