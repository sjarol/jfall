package nl.uwv.pws.dataprovider;

import java.io.Serializable;
import java.util.List;

import com.vaadin.flow.data.provider.QuerySortOrder;
import com.vaadin.flow.data.provider.SortDirection;

/**
 * <p>Generates the SQL syntax to add sort condition to the query.
 * <p>If the null ordering is not specified then the handling of the null values is:
 * <ul>
 * <li>NULLS LAST if the sort is <b>ASC</b>
 * <li>NULLS FIRST if the sort is <b>DESC</b>
 * </ul></p>
 */
public class SortStringGenerator implements Serializable {
   private static final String ASC = "asc";
   private static final String DESC = "desc";
   private static final String NULL_FIRST = " nulls first";
   private static final String NULL_LAST = " nulls last";

   private final String sortAsc;
   private final String sortDesc;

   public SortStringGenerator() {
      this(ASC, DESC);
   }

   private SortStringGenerator(final String asc, final String desc) {
      sortAsc = asc;
      sortDesc = desc;
   }

   public SortStringGenerator withNullsFirst() {
      return new SortStringGenerator(ASC + NULL_FIRST, DESC + NULL_FIRST);
   }

   public SortStringGenerator withNullsLast() {
      return new SortStringGenerator(ASC + NULL_LAST, DESC + NULL_LAST);
   }

   /**
    * <p>Generates the SQL syntax to add sort condition to the query.
    * <p>The handling of the null values is:
    * <ul>
    * <li>NULLS FIRST if the sort is <b>ASC</b>
    * <li>NULLS LAST if the sort is <b>DESC</b>
    * </ul></p>
    */
   public SortStringGenerator withNullsReversed() {
      return new SortStringGenerator(ASC + NULL_FIRST, DESC + NULL_LAST);
   }

   public String generate(final List<QuerySortOrder> sortOrders) {
      StringBuilder sort = new StringBuilder();
      if (sortOrders != null && !sortOrders.isEmpty()) {
         for (QuerySortOrder sortOrder : sortOrders) {
            if (sort.length() == 0) {
               sort.append(" order by ");
            } else {
               sort.append(", ");
            }
            sort.append(sortOrder.getSorted()).append(" ").append(getOrder(sortOrder.getDirection()));
         }
      }
      return sort.toString();
   }

   private String getOrder(final SortDirection sortDirection) {
      if (sortDirection == SortDirection.DESCENDING) {
         return sortDesc;
      }
      return sortAsc;
   }
}
