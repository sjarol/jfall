package nl.uwv.pws.ui.components.navigation.drawer;

import java.util.List;
import java.util.stream.Collectors;

import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.icon.VaadinIcon;

@CssImport("./styles/components/navi-menu.css")
public class NaviMenu extends Div {

   private static final String CLASS_NAME = "navi-menu";

   public NaviMenu() {
      super.setClassName(CLASS_NAME);
   }

   protected void addNaviItem(final NaviItem item) {
      add(item);
   }

   protected void addNaviItem(final NaviItem parent, final NaviItem item) {
      parent.addSubItem(item);
      addNaviItem(item);
   }

   public void filter(final String filter) {
      getNaviItems().forEach(naviItem -> naviItem.setVisible(
            naviItem.getText().toLowerCase().contains(filter.toLowerCase())
      ));
   }

   public NaviItem addNaviItem(final String text, final Class<? extends Component> navigationTarget) {
      NaviItem item = new NaviItem(text, navigationTarget);
      addNaviItem(item);
      return item;
   }

   public NaviItem addNaviItem(final VaadinIcon icon, String text, final Class<? extends Component> navigationTarget) {
      NaviItem item = new NaviItem(icon, text, navigationTarget);
      addNaviItem(item);
      return item;
   }

   public NaviItem addNaviItem(final Image image, String text, final Class<? extends Component> navigationTarget) {
      NaviItem item = new NaviItem(image, text, navigationTarget);
      addNaviItem(item);
      return item;
   }

   public NaviItem addNaviItem(final NaviItem parent, String text, final Class<? extends Component> navigationTarget) {
      NaviItem item = new NaviItem(text, navigationTarget);
      addNaviItem(parent, item);
      return item;
   }

   public NaviItem addNaviItem(final VaadinIcon vaadinIcon, final String name, String url) {
      NaviItem item = new NaviItem(vaadinIcon, name, url);
      addNaviItem(item);
      return item;
   }

   @SuppressWarnings("unchecked")
   public List<NaviItem> getNaviItems() {
      return (List<NaviItem>) (List<?>) getChildren().collect(Collectors.toList());
   }
}
