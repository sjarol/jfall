package nl.uwv.pws.backend.types;

import java.util.HashMap;
import java.util.Map;

public class StringDescriptionProvider implements FieldDescriptionProvider {

   private final Map<String, String> descriptionCache;

   public StringDescriptionProvider() {
      descriptionCache = new HashMap<>();
   }

   public void addOmschrijving(final String catCode, final String omschrijving) {
      descriptionCache.put(catCode.toLowerCase(), omschrijving);
   }

   public void addOmschrijving(final String catCode, final String code, final String omschrijving) {
      descriptionCache.put(getKey(catCode, code), omschrijving);
   }

   @Override
   public String getDescription(final String catCode) {
      return catCode == null ? null : descriptionCache.get(catCode.toLowerCase());
   }

   @Override
   public String getDescription(final String catCode, final String code) {
      return descriptionCache.get(getKey(catCode, code));
   }

   private String getKey(final String catCode, final String code) {
      if (catCode == null) {
         return null;
      }
      return catCode.toLowerCase() + "@" + (code == null ? "" : code.toLowerCase());
   }
}
