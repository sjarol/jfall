package nl.uwv.pws.backend.service;

import java.security.Principal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

import javax.security.auth.Subject;

import org.apache.commons.collections4.map.PassiveExpiringMap;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.vaadin.flow.server.VaadinRequest;
import com.vaadin.flow.server.VaadinServletRequest;

import nl.uwv.pws.backend.dao.User;
import weblogic.security.Security;
import weblogic.security.principal.WLSGroupImpl;

public final class UserService {
   private static final Logger LOG = LogManager.getLogger(UserService.class);
   /**
    * Keep UserContext in cache for nn minutes
    */
   private static final int ENTRY_EXPIRATION_TIME = 5;
   private static final Map<String, User> USER_CONTEXT_CACHE =
         new PassiveExpiringMap<>(ENTRY_EXPIRATION_TIME, TimeUnit.MINUTES);

   private static final UserService INSTANCE = new UserService();

   private UserService() {
      // Empty constructor
   }

   public static UserService get() {
      return INSTANCE;
   }

   public static User getCurrentUser() {
      String remoteUser = VaadinServletRequest.getCurrent().getRemoteUser();
      LOG.debug("getCurrentUser: remoteUser=" + remoteUser);
      User user = null;
      if (StringUtils.isEmpty(remoteUser)) {
         LOG.debug("User is niet ingelogd");
      } else if (USER_CONTEXT_CACHE.containsKey(remoteUser)) {
         user = USER_CONTEXT_CACHE.get(remoteUser);
         LOG.debug("getCurrentUser User roles: " + StringUtils.join(user.getRoles(), ","));
      } else {
         LOG.debug("User expired, refresh");
         user = UserService.get().createUser(remoteUser);
         USER_CONTEXT_CACHE.put(remoteUser, user);
      }
      return user;
   }

   public Optional<User> login(final String username) {
      User user = null;
      LOG.debug("Login user: " + username);
      if (USER_CONTEXT_CACHE.containsKey(username)) {
         user = USER_CONTEXT_CACHE.get(username);
      } else {
         user = createUser(username);
         USER_CONTEXT_CACHE.put(username, user);
         // Geen rollen => login failed
         if (user.getRoles().length == 0) {
            user = null;
         }
      }

      return Optional.ofNullable(user);
   }

   public void logout(final String username) {
      LOG.debug("Logout user: " + username);
      if (USER_CONTEXT_CACHE.containsKey(username)) {
         USER_CONTEXT_CACHE.remove(username);
      }
   }

   private User createUser(final String username) {
      User user = new User();
      String[] roles = getUserRoles();
      user.setUsername(username);
      user.setRoles(roles);

      return user;
   }

   private String[] getUserRoles() {
      List<String> userRoles = new ArrayList<>();
      VaadinRequest request = VaadinRequest.getCurrent();
      for (String role : AuthorizationService.get().getADGroups()) {
         if (request.isUserInRole(role)) {
            userRoles.add(role);
         }
      }
      if (userRoles.isEmpty()) {
         addWeblogicRoles(userRoles);
      }

      return userRoles.toArray(new String[0]);
   }

   private void addWeblogicRoles(final List<String> userRoles) {
      try {
         // first try to see weblogic is available
         Class.forName("weblogic.security.service.PrivilegedActions");
         Subject subject = Security.getCurrentSubject();
         for (Principal p : subject.getPrincipals()) {
            LOG.debug("Principle : " + p.getName() + ", " + p.getClass());
            if (p instanceof WLSGroupImpl) {
               userRoles.add(p.getName());
            }
         }
      } catch (Exception e) {
         LOG.warn("Fout tijdens ophalen weblogic rollen", e);
      }
   }
}
