package nl.uwv.pws.ui;

public class NotAuthorizedException extends RuntimeException {

   public NotAuthorizedException(final String message) {
      super(message);
   }

   public NotAuthorizedException(final Throwable cause) {
      super(cause);
   }

   public NotAuthorizedException(final String message, final Throwable cause) {
      super(message, cause);
   }
}
