package nl.uwv.pws.ui.util;

import com.vaadin.flow.server.VaadinService;
import nl.uwv.pws.backend.dao.User;
import nl.uwv.pws.backend.service.IncidentLoggerService;
import nl.uwv.pws.backend.service.UserService;
import nl.uwv.pws.ui.AppRuntimeException;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import java.io.File;
import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.lang.management.ThreadInfo;
import java.lang.management.ThreadMXBean;
import java.util.Calendar;

import static java.lang.String.format;

public final class ExceptionHandler {
   private static final Logger LOG = LogManager.getLogger(ExceptionHandler.class);
   private static final String ENV_INCIDENT_DATASOURCE = "incidentDataSource";
   private static final String LIJN = StringUtils.repeat('-', 114);

   private static ExceptionHandler instance = null;
   private static IncidentLoggerService logService = null;
   private static String dsName = null;

   protected ThreadLocal<IncidentContext[]> threadContext = ThreadLocal.withInitial(() -> new IncidentContext[1]);

   private ExceptionHandler() {
      // Empty constructor
   }

   public static void setDsName(final String dataSourceName) {
      if (dsName != null && !dsName.equals(dataSourceName)) {
         throw new IllegalStateException("Er is al een datasource gedefinieerd");
      }
      dsName = dataSourceName;
   }

   public static ExceptionHandler getInstance() {
      if (instance == null) {
         if (dsName == null) {
            dsName = getDataSourceFromEnv();
         }
         if (dsName == null) {
            LOG.warn("Geen datasource gedefinieerd");
         }
         logService = new IncidentLoggerService(dsName);
         instance = new ExceptionHandler();
      }
      return instance;
   }

   public void writeException(final Throwable t) {
      String stackTrace = ExceptionUtils.getFullStackTrace(t);
      Calendar calendar = Calendar.getInstance();
      IncidentContext context = threadContext.get()[0];
      String user = "-onbekend-";

      LOG.error(stackTrace);

      if (context == null) {
         context = new IncidentContext("Geen aanvullende context");
      }
      if (VaadinService.getCurrentRequest() != null) {
         try {
            User loggedUser = UserService.getCurrentUser();
            if (loggedUser != null) {
               user = loggedUser.getUsername();
            }
         } catch (Exception e) {
            LOG.warn(e.getClass().getName() + " " + e.getMessage(), e);
         }
      }

      String incidentID = String.format("%s-%2$tY%2$tm%2$td_%2$tH%2$tM%2$tS", context.identification, calendar);
      String incidentFile = String.format("incident-%s.log", incidentID);

      StringBuilder incident = new StringBuilder();
      appendAsLine(incident, LIJN);
      appendAsLine(incident, " Filename    : ", incidentFile);
      appendAsLine(incident, " User		 : ", user);
      appendAsLine(incident, format(" Date        : %1$tB %1$te, %1$tY", calendar));
      appendAsLine(incident, format(" Time        : %1$tl:%1$tM:%1$tS %1$tp", calendar));
      appendAsLine(incident, LIJN);
      appendAsLine(incident, "");
      appendAsLine(incident, " Unexpected error context: ", context.text);
      appendAsLine(incident, "");
      appendAsLine(incident, stackTrace);
      appendAsLine(incident, LIJN);
      appendAsLine(incident, "");
      appendAsLine(incident, " ** THREAD DUMP:");
      appendAsLine(incident, dumpThreads());
      appendAsLine(incident, "");
      appendAsLine(incident, LIJN);
      appendAsLine(incident, "[END]");

      tryTowriteToDatabase(incidentID, user, stackTrace, dumpThreads());
      tryTowriteToFile(incident, incidentID, incidentFile);

      threadContext.remove();
   }

   private void tryTowriteToDatabase(
         final String incidentID,
         final String user,
         final String fullStackTrace,
         final String dumpThreads) {

      try {
         logService.insert(incidentID, user, fullStackTrace, dumpThreads);
      } catch (Exception ex) {
         LOG.warn("Kan incident niet in database registreren.", ex);
      }
   }

   private void tryTowriteToFile(final StringBuilder incident, final String incidentID, final String incidentFile) {
      ExceptionWriter.getCurrentInstance().setExceptionID(incidentID);

      String filePath = ExceptionWriter.getCurrentInstance().getFilePath();
      File f = new File(filePath, incidentFile);
      try {
         FileUtils.write(f, incident.toString(), "UTF-8");
      } catch (IOException e) {
         LOG.error("De oorspronkelijke uitzondering was: " + incident.toString(), e);
      }
   }

   private void appendAsLine(final StringBuilder incidentLog, final String... data) {
      for (String str : data) {
         incidentLog.append(str);
      }
      incidentLog.append("\n");
   }

   private String dumpThreads() {
      ThreadMXBean bean = ManagementFactory.getThreadMXBean();
      ThreadInfo[] infos = bean.dumpAllThreads(true, true);

      StringBuilder stack = new StringBuilder();

      for (ThreadInfo info : infos) {
         stack.append(info.toString());
      }

      return stack.toString();
   }

   private static String getDataSourceFromEnv() {
      String datasourceName = null;
      try {
         Context env = (Context) new InitialContext().lookup("java:comp/env");
         if (env != null) {
            datasourceName = (String) env.lookup(ENV_INCIDENT_DATASOURCE);
         }
      } catch (NamingException e) {
         throw new AppRuntimeException("Environment is niet gevonden: " + e.getMessage(), e);
      }
      return datasourceName;
   }

   private static final class IncidentContext {
      private static long incidentCount = 1L;

      private final String identification;
      private final String text;

      IncidentContext(final String txt) {
         identification = String.format("#%d", incidentCount++);
         text = txt;
      }
   }
}
