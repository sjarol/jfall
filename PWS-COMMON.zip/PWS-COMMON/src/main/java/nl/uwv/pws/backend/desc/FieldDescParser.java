package nl.uwv.pws.backend.desc;

import nl.uwv.pws.backend.types.Field;
import nl.uwv.pws.ui.util.UIUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * <p>
 * This class parses a .desc file that describes the columns of a view/table and how they should be displayed on the
 * screen in a grid.
 * </p>
 *
 * <p>
 * Each row in this file looks something like this:
 * Field("[QUERY_STRING]", "[TYPE]", "[NAME_STRING]", "[ATTRIBUTES]")
 * </p>
 *
 * <p>
 * So for each column in the database you define a Field with a QUERY_STRING, an optional TYPE description,
 * a NAME_STRING and a list of attributes:
 * <ul>
 *    <li>
 *       QUERY_STRING: The Query-String used to fetch data for this column from the view, typically the column-name.
 *    </li>
 *    <li>
 *       TYPE: The data-type for the column.
 *    </li>
 *    <li>
 *       NAME_STRING: The column-name on the screen as displayed to the end-user.
 *    </li>
 *    <li>
 *       ATTRIBUTES: comma-separated list of attributes and their values. Example &quot;width:L,sort,property:by&quot;
 *    </li>
 * </ul>
 * </p>
 *
 * <p>
 * Each ATTRIBUTE has the form [ATTRIBUTE_NAME]:[ATTRIBUTE_VALUE]:
 * <ul>
 *    <li>ATTRIBUTE_NAME is required, if it is a flag, just the name is enough to set the attribute to true.</li>
 *    <li>ATTRIBUTE_VALUE is optional and defines the value to set for the attribute.</li>
 * </ul>
 * </p>
 *
 * <p>
 * Available attributes:<br />
 * Attribute-names and -values are case-insensitive.
 * <ul>
 *    <li>
 *       desc: Defines a fieldDescription for the column that consists of a providerId and a categorie, in a format
 *             [PROVIDER_ID]-[CATEGORY]. These together will be used to lookup the right FieldDescriptionProvider
 *             that provides messages to display on the screen in generic modal dialogs.
 *    </li>
 *    <li>
 *       flex: Sets the flex-grow attribute that defines how additional space is assigned to the column if available.
 *             See <a href="https://css-tricks.com/snippets/css/a-guide-to-flexbox/">this guide to flexbox</a> for
 *             more details. You can enter an integer value or a pixel value. The pixel value will be converted to a
 *             plain integer value by dividing it by 80 (the number of characters per line). Defaults to 0.
 *    </li>
 *    <li>hidden: Flag to indicate the column should be hidden on the screen.</li>
 *    <li>plain: Flag to indicate the values in this column should be rendered as-is without any formatting.</li>
 *    <li>prefix: Flag to indicate the attribute should be rendered with a name:type:-prefix.</li>
 *    <li>property: The property name to assign this column to for sorting.</li>
 *    <li>sort: Flag that indicates if the column is sortable, no value necessary.</li>
 *    <li>
 *       type: The column type to use if no [TYPE] was set for the Field. One of date/datetime/Icon/String, for more
 *             details, see below.
 *    </li>
 *    <li>
 *       width: The width of the column on the screen. You can specify the width manually (e.g. 134px) or use one of
 *              the short-hand notations: XS for 80px, S for 120px, M for 160px, L for 200px and XL for 240px.
 *              Defaults to S.
 *    </li>
 * </ul>
 * </p>
 *
 * <p>
 * Field type:<br />
 * When you define a field, you can specify the [TYPE], but you can also specify the type using an attribute. If you
 * define both, the Field-level [TYPE] takes precedence over the type you specified in the attributes. These types are
 * supported:
 * <ul>
 *    <li>date: If the attribute value is a timestamp, this type formats the timestamp as a date.</li>
 *    <li>datetime: If the attribute value is a timestamp, this type formats the timestamp as a date and time.</li>
 *    <li>Icon: If the attribute value is the name of a VaadinIcon that needs to be displayed.</li>
 *    <li>String: Default field type, simply holds a String.</li>
 * </ul>
 * </p>
 */
public class FieldDescParser implements Parser {

   private static final Logger LOG = LogManager.getLogger(FieldDescParser.class);

   //  Format :
   //  Field("TS_LOG", "Logtijdstip", "width:L,sort.property:tslog")
   private static final String SP = "[ \t]*";
   private static final String FIELD = "Field" + SP + "\\(" + SP;
   private static final String QSTR = "\"([^\"]*)\"";
   private static final String NSTR = SP + "[,]" + SP + QSTR;
   private static final String END = SP + "\\)";

   private static String any(final String s) {
      return ".*" + s + ".*";
   }

   public Field[] parse(final String resource) {
       ArrayList<Field> fields = new ArrayList<>();
      ClassLoader classLoader = FieldDescParser.class.getClassLoader();
      try (InputStream is = classLoader.getResourceAsStream(resource)) {
         if (is != null) {
            fields = parseInputStream(resource, is);
         } else {
            throw new IOException("Resource not found : " + resource);
         }
      } catch (IOException e) {
         UIUtils.handleError(e, "InputStream gefaald: " + resource);
      }
      return fields.toArray(new Field[0]);
   }

   private ArrayList<Field> parseInputStream(final String resource, final InputStream is) {
      ArrayList<Field> fields = new ArrayList<>();
      try (BufferedReader reader = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
         Pattern p1 = Pattern.compile(any(FIELD + QSTR + NSTR + NSTR + END));
         Pattern p2 = Pattern.compile(any(FIELD + QSTR + NSTR + NSTR + NSTR + END));
         String line;
         while ((line = reader.readLine()) != null) {
            parseLine(p1, p2, line, fields);
         }
      } catch (IOException e) {
         UIUtils.handleError(e, "InputStream gefaald: " + resource);

         LOG.error("Parsing gefaald: " + resource, e);
      }
      return fields;
   }

   private void parseLine(final Pattern p1, final Pattern p2, final String line, final ArrayList<Field> fields) {
      Matcher m = p1.matcher(line);
      if (m.matches()) {
         LOG.debug(m.group());
         fields.add(new Field(m.group(1), m.group(2), m.group(3)));
      } else {
         m = p2.matcher(line);
         if (m.matches()) {
            LOG.debug(m.group());
            fields.add(new Field(m.group(1), m.group(2), m.group(3), m.group(4)));
         } else {
            LOG.warn("Beschrijvingsregel genegeerd: " + line);
         }
      }
   }
}
