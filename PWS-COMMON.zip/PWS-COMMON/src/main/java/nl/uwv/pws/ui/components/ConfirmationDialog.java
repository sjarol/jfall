package nl.uwv.pws.ui.components;

import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;

import java.io.Serializable;

/**
 * A generic dialog for confirming or cancelling an action.
 *
 * @param <T> The type of the action's subject
 * @deprecated De annuleren knop staat hier nog links, schakel over op de {@link ConfirmDialog} om deze rechts te zetten.
 */
@Deprecated
public class ConfirmationDialog<T extends Serializable> extends AbstractConfirmationDialog<T> {
   @Override
   HorizontalLayout createFooter(final Button saveButton, final Button cancelButton) {
      return new HorizontalLayout(cancelButton, saveButton);
   }
}
