package nl.uwv.pws.ui.util.css;

public enum Position {
   ABSOLUTE("absolute"),
   FIXED("fixed"),
   RELATIVE("relative");

   private final String value;

   Position(final String value) {
      this.value = value;
   }

   public String getValue() {
      return value;
   }
}
