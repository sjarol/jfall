package nl.uwv.pws.backend.service;

import com.vaadin.flow.data.provider.QuerySortOrder;

import java.io.Serializable;
import java.util.List;

public interface ListBoxService extends Serializable {
   List<String> fetchRows(
         final String filter,
         final int limit,
         final int offset,
         final List<QuerySortOrder> sortOrders
   );

   long countRows(final String filter);
}
