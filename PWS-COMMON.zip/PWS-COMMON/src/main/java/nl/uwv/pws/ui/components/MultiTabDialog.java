package nl.uwv.pws.ui.components;

import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.HasStyle;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.tabs.Tab;
import com.vaadin.flow.component.tabs.Tabs;
import com.vaadin.flow.component.tabs.Tabs.SelectedChangeEvent;

import nl.uwv.pws.ui.util.UIUtils;
import nl.uwv.pws.ui.views.ViewFrame;

import java.util.HashMap;
import java.util.Map;

@SuppressWarnings("serial")
public class MultiTabDialog extends StyledDialog {
   private static final String CLASS_NAME = "app-bar";

   private Div top;
   private FlexBoxLayout tabContent;
   private Div bottom;
   private Tabs tabs;
   private Map<Tab, Component> tabContentMap;
   private Map<Tab, DialogTab> tabDialogMap;

   private Button prevButton = createPrev();
   private Button nextButton = createNext();
   private boolean ignoreSelectedChangeEvent;

   public MultiTabDialog(ViewFrame parent, String title) {
      super(parent, title);
   }

   public MultiTabDialog(ViewFrame parent, String title, String width, String height) {
      super(parent, title, width, height);

      tabs = new Tabs();
      tabs.setId("tabs");
      tabs.setClassName(CLASS_NAME + "__tabs");
      tabs.setOrientation(Tabs.Orientation.VERTICAL);
      tabs.addSelectedChangeListener(this::tabSelectedChanged);
      tabContentMap = new HashMap<>();
      tabDialogMap = new HashMap<>();

      top = new Div();
      top.setWidthFull();
      tabContent = new FlexBoxLayout(tabs);
      tabContent.getStyle().set("overflow-y", "hidden");
      tabContent.setSizeFull();
      bottom = new Div();
      bottom.setWidthFull();
   }
   
   public Div getTop() {
      return top;
   }
   
   public void setTop(Component... components) {
      top.removeAll();
      top.add(components);
   }

   public Div getBottom() {
      return bottom;
   }
   public void setBottom(Component... components) {
      bottom.removeAll();
      bottom.add(components);
   }

   public void addTab(DialogTab dialogTab) {
      if (dialogTab.isAuthorized()) {
         Tab tab = new Tab(dialogTab.getName());
         tab.setId("tab-" + dialogTab.getName().replace(" ", "-"));
         tab.setClassName(CLASS_NAME + "__tab");

         Component content = dialogTab.getContent();
         if (content instanceof HasStyle) {
            ((HasStyle)content).setClassName(CLASS_NAME + "__tab-container");
         }

         tabContentMap.put(tab, content);
         tabDialogMap.put(tab, dialogTab);
         tabs.add(tab);
      }
   }
   
   /**
    * @return the number of defined dialog tabs
    */
   public int getTabSize() {
      return tabDialogMap.size();
   }

   public void removeTabs() {
      tabContent.remove(tabContentMap.get(tabs.getSelectedTab()));
      tabContentMap.clear();
      tabDialogMap.clear();

      // Wanneer een tab verwijderd wordt, dan treed er een tabchanged event op.
      ignoreSelectedChangeEvent = true;
      tabs.removeAll();
   }
   
   /**
    * @return the current selected dialog tab index
    */
   public int getSelectedTabIndex() {
      return tabs.getSelectedIndex();
   }

   /**
    * @param index the index for the dialog tab to be selected
    */
   public void setSelectedTabIndex(int index) {
      tabs.setSelectedIndex(index);
   }

   /**
    * Navigate to previous dialog tab
    */
   public void prevTab() {
      prevButton.click();
   }

   /**
    * Navigate to next dialog tab
    */
   public void nextTab() {
      nextButton.click();
   }

   /**
    * @return true if dialog is valid (all dialogtabs are valid)
    */
   public boolean isValid() {
      for (DialogTab tab : tabDialogMap.values()) {
         if (!tab.isValid()) {
            return false;
         }
      }

      return true;
   }

   /**
    * Try to select the first tab which is not valid.
    */
   public void selectInvalidTab() {
      int index = 0;
      for (DialogTab tab : tabDialogMap.values()) {
         if (!tab.isValid()) {
            tabs.setSelectedIndex(index);
            break;
         }
         index++;
      }
   }
   
   private Button createPrev() {
      prevButton = UIUtils.createTertiaryButton("Vorige");
      prevButton.setId("bt-prev");
      prevButton.addClickListener(event -> selectPrevTab() );
      return prevButton;
   }

   private Button createNext() {
      nextButton = UIUtils.createPrimaryButton("Volgende");
      nextButton.setId("bt-next");
      nextButton.addClickListener(event -> selectNextTab() );

      return nextButton;
   }

   private void tabSelectedChanged(SelectedChangeEvent event) {
      if (ignoreSelectedChangeEvent) {
         ignoreSelectedChangeEvent = false;
         return;
      }
      if (event.getPreviousTab() != null) {
         if (tabDialogMap.get(event.getPreviousTab()).isValid()) {
            tabContent.remove(tabContentMap.get(event.getPreviousTab()));
         } else {
            ignoreSelectedChangeEvent = true;
            event.getSource().setSelectedTab(event.getPreviousTab());
            return;
         }
      }
      if (event.getSelectedTab() != null) {
         Component component = tabContentMap.get(event.getSelectedTab());
         tabContent.add(component);
         tabContent.setFlexGrow(1, component);
      }
      enableDisableNavButtons();
   }

   private void selectPrevTab() {
      int index = tabs.getSelectedIndex();
      if (index > 0) {
         index--;
         tabs.setSelectedIndex(index);
      }
   }

   private void selectNextTab() {
      int index = tabs.getSelectedIndex();
      if (index < tabContentMap.size() - 1) {
         index++;
         tabs.setSelectedIndex(index);
      }
   }

   private void enableDisableNavButtons() {
      int index = tabs.getSelectedIndex();
      prevButton.setEnabled(index > 0);
      nextButton.setEnabled(index < tabContentMap.size() - 1);
      if (index >= 0) {
         if (nextButton.isEnabled()) {
            index++;
         }
         Tab nextTab = (Tab) tabs.getComponentAt(index);
         nextButton.setText("Naar " + nextTab.getLabel().toLowerCase());
      }
   }

   @Override
   public void open() {
      setContent(top, tabContent, bottom);
      addCustomButtonRight(prevButton);
      addCustomButtonRight(nextButton);
      enableDisableNavButtons();
      super.open();
   }
}
