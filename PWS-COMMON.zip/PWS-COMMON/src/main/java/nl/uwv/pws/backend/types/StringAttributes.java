package nl.uwv.pws.backend.types;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import nl.uwv.pws.ui.util.UIUtils;

public class StringAttributes implements FieldAttributes {
   private static final Pattern DESCRIPTION_PATTERN = Pattern.compile(".*descr:([a-zA-Z0-9_]*)-([a-zA-Z0-9_]*).*");
   private static final Pattern FLEX_PATTERN = Pattern.compile(".*flex:([0-9]+).*");
   private static final Pattern PROPERTY_PATTERN = Pattern.compile(".*property:([a-z0-9]*).*");
   private static final Pattern PX_PATTERN = Pattern.compile("([0-9]+)(px)");
   private static final Pattern TYPE_PATTERN = Pattern.compile(".*type:([a-zA-Z0-9_]*).*");
   private static final Pattern WIDTH_PATTERN = Pattern.compile(".*width:([0-9]*(px)).*");

   private static final int NUM_CHARACTERS_PER_LINE = 80;

   private final String attributes;
   private String width;
   private int flexGrow = -1;
   private String property;
   private String type;
   private FieldDescription fieldDescription;

   public StringAttributes(final String attributes) {
      this.attributes = attributes.toLowerCase();
   }

   @Override
   public String getWidth() {
      if (width == null) {
         width = parseWidth();
      }
      return width;
   }

   @Override
   public int getFlexGrow() {
      if (flexGrow == -1) {
         flexGrow = parseFlexGrow();
      }
      return flexGrow;
   }

   @Override
   public boolean isSortable() {
      return attributes.contains("sort");
   }

   @Override
   public String getProperty() {
      if (property == null) {
         property = parseProperty();
      }
      return property;
   }

   @Override
   public boolean isPrefix() {
      return attributes.contains("prefix");
   }

   @Override
   public String getType() {
      if (type == null) {
         type = parseType();
      }
      return type;
   }

   @Override
   public boolean isHidden() {
      return attributes.contains("hidden");
   }

   @Override
   public boolean usePlain() {
      return attributes.contains("plain");
   }

   @Override
   public FieldDescription getFieldDescription() {
      if (fieldDescription == null) {
         fieldDescription = parseFieldDescription();
      }
      return fieldDescription;
   }

   // Attribuut parsers / patterns
   private String parseWidth() {
      if (attributes.contains("width:m")) {
         return UIUtils.COLUMN_WIDTH_M;
      } else if (attributes.contains("width:l")) {
         return UIUtils.COLUMN_WIDTH_L;
      } else if (attributes.contains("width:xl")) {
         return UIUtils.COLUMN_WIDTH_XL;
      } else if (attributes.contains("width:xs")) {
         return UIUtils.COLUMN_WIDTH_XS;
      } else if (attributes.contains("width:s")) {
         return UIUtils.COLUMN_WIDTH_S;
      } else if (attributes.contains("width:")) {
         Matcher m = WIDTH_PATTERN.matcher(attributes);
         if (m.matches()) {
            return m.group(1);
         }
      }
      return UIUtils.COLUMN_WIDTH_S;
   }

   private int parseFlexGrow() {
      if (attributes.contains("flex:")) {
         Matcher m = FLEX_PATTERN.matcher(attributes);
         if (m.matches() && m.groupCount() > 0) {
            return Integer.parseInt((m.group(1)));
         }
      } else {
         Matcher m = PX_PATTERN.matcher(getWidth());
         if (m.matches()) {
            int pixelWidth = Integer.parseInt(m.group(1));
            return pixelWidth / NUM_CHARACTERS_PER_LINE;
         }
      }
      return 0;
   }

   private String parseProperty() {
      if (attributes.contains("property:")) {
         Matcher m = PROPERTY_PATTERN.matcher(attributes);
         if (m.matches()) {
            return m.group(1);
         }
      }
      return "";
   }

   private String parseType() {
      if (attributes.contains("type:")) {
         Matcher m = TYPE_PATTERN.matcher(attributes);
         if (m.matches()) {
            return m.group(1);
         }
      }
      return null;
   }

   private FieldDescription parseFieldDescription() {
      if (attributes.contains("descr:")) {
         Matcher m = DESCRIPTION_PATTERN.matcher(attributes);
         if (m.matches()) {
            return new FieldDescription(m.group(1), m.group(2));
         }
      }
      return null;
   }

   @Override
   public String toString() {
      final StringBuilder sb = new StringBuilder("Attributes{");
      sb.append(attributes);
      sb.append('}');
      return sb.toString();
   }
}
