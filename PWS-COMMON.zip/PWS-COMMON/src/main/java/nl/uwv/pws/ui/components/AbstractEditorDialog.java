package nl.uwv.pws.ui.components;

import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.HasStyle;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.formlayout.FormLayout;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.data.binder.Binder;
import com.vaadin.flow.shared.Registration;
import nl.uwv.pws.ui.util.UIUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import java.io.Serializable;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

/**
 * Abstract base class for dialogs adding, editing or deleting items.
 * <p>
 * Subclasses are expected to
 * <ul>
 * <li>add, during construction, the needed UI components to
 * {@link #getFormLayout()} and bind them using {@link #getBinder()}, as well
 * as</li>
 * <li>override {@link #confirmDelete()} to open the confirmation dialog with
 * the desired message (by calling
 * {@link #openConfirmationDialog(String, String, String)}.</li>
 * </ul>
 *
 * @param <T> the type of the item to be added, edited or deleted
 */
@CssImport(value = "./styles/components/dialog.css", themeFor = "vaadin-*-overlay")
public abstract class AbstractEditorDialog<T extends Serializable> extends Dialog implements HasStyle {
   private static final Logger LOG = LogManager.getLogger(AbstractEditorDialog.class);

   private static final String COMPONENT_ID = "editor-dialog";
   private static final String COMPONENT_FOOTER_CLASS = "footer";
   private static final String COMPONENT_FOOTER_LEFT_CLASS = "footer-left";
   private static final String COMPONENT_FOOTER_RIGHT_CLASS = "footer-right";
   private static final String COMPONENT_HEADER_CLASS = "header";
   private static final String COMPONENT_CONTENT_CLASS = "content";

   private final EditorConfirmationDialog<T> confirmationDialog = new EditorConfirmationDialog<>();
   // Content
   private final FormLayout formLayout = new FormLayout();
   private final transient BiConsumer<T, Operation> itemSaver;
   private final transient Consumer<T> itemDeleter;
   // Header
   private final Label dialogTitle = UIUtils.createH2Label("");
   // Footer
   // TODO: createErrorLabel
   private final Label errorMessage = new Label();
   private HorizontalLayout footerLeft;
   private final Button saveButton = UIUtils.createPrimaryButton("Opslaan");
   private final Button cancelButton = UIUtils.createTertiaryButton("Annuleren");
   private final Button deleteButton = UIUtils.createErrorTertiaryButton("Verwijderen");
   private Registration registrationForSave;
   private Registration registrationForDelete;
   private final Binder<T> binder = new Binder<>();
   private T currentItem;

   /**
    * Constructs a new instance.
    *
    * @param itemSaver   Callback to save the edited item
    * @param itemDeleter Callback to delete the edited item
    */
   protected AbstractEditorDialog(final BiConsumer<T, Operation> itemSaver, final Consumer<T> itemDeleter) {
      this(itemSaver, itemDeleter, COMPONENT_ID);
   }

   /**
    * Constructs a new instance.
    *
    * @param itemSaver            Callback to save the edited item
    * @param itemDeleter          Callback to delete the edited item
    * @param inheritedComponentId CSS ID to give to the component
    */
   protected AbstractEditorDialog(
         final BiConsumer<T, Operation> itemSaver,
         final Consumer<T> itemDeleter,
         final String inheritedComponentId) {
      super.setCloseOnEsc(true);
      super.setCloseOnOutsideClick(false);

      this.itemSaver = itemSaver;
      this.itemDeleter = itemDeleter;

      VerticalLayout dialogStructure = new VerticalLayout(initDialogHeader(), initFormLayout(), initFooter());
      dialogStructure.setId(inheritedComponentId);
      super.add(dialogStructure);
   }

   private HorizontalLayout initDialogHeader() {
      HorizontalLayout header = new HorizontalLayout(dialogTitle);
      header.setClassName(COMPONENT_HEADER_CLASS);
      header.setWidthFull();

      return header;
   }

   private Component initFormLayout() {
      VerticalLayout contentBlock = new VerticalLayout();
      contentBlock.setClassName(COMPONENT_CONTENT_CLASS);
      contentBlock.setWidthFull();
      contentBlock.add(formLayout, errorMessage);
      errorMessage.setClassName("error-label");

      return contentBlock;
   }

   private HorizontalLayout initFooter() {
      HorizontalLayout footer = new HorizontalLayout();
      footer.setClassName(COMPONENT_FOOTER_CLASS);

      cancelButton.addClickListener(e -> close());
      deleteButton.addClickListener(e -> deleteClicked());
      deleteButton.setClassName("delete-btn");

      //  Footer
      footer.setWidthFull();
      add(footer);

      //  LEFT side of the footer
      footerLeft = new HorizontalLayout();
      footerLeft.setClassName(COMPONENT_FOOTER_LEFT_CLASS);
      footerLeft.setJustifyContentMode(FlexComponent.JustifyContentMode.START);
      footerLeft.setWidth("50%");
      footerLeft.add(deleteButton);
      footer.add(footerLeft);

      //  RIGHT side of the footer
      HorizontalLayout footerRight = new HorizontalLayout();
      footerRight.setClassName(COMPONENT_FOOTER_RIGHT_CLASS);
      footerRight.setJustifyContentMode(FlexComponent.JustifyContentMode.END);
      footerRight.setWidth("50%");
      footerRight.add(saveButton, cancelButton);
      footer.add(footerRight);

      return footer;
   }

   protected void addCustomButton(final Button customButtons) {
      footerLeft.add(customButtons);
   }

   protected void addCustomButtonAtIndex(final int index, final Button component) {
      footerLeft.addComponentAtIndex(index, component);
   }

   /**
    * Gets the form layout, where additional components can be added for
    * displaying or editing the item's properties.
    *
    * @return the form layout
    */
   protected final FormLayout getFormLayout() {
      return formLayout;
   }

   /**
    * Gets the binder.
    *
    * @return the binder
    */
   protected final Binder<T> getBinder() {
      return binder;
   }

   /**
    * Gets the item currently being edited.
    *
    * @return the item currently being edited
    */
   protected final T getCurrentItem() {
      return currentItem;
   }

   /**
    * Opens the given item for editing in the dialog.
    *
    * @param item      The item to edit; it may be an existing or a newly created
    *                  instance
    * @param operation The operation being performed on the item
    */
   public final void open(final String title, final T item, final Operation operation) {
      LOG.debug("Opening AbstractEditor Dialog");

      binder.readBean(null);

      currentItem = item;
      dialogTitle.setText(title);
      if (registrationForSave != null) {
         registrationForSave.remove();
      }
      registrationForSave = saveButton
            .addClickListener(e -> saveClicked(operation));

      if (registrationForDelete != null) {
         registrationForDelete.remove();
      }
      registrationForDelete = deleteButton
            .addClickListener(e -> deleteClicked());

      binder.readBean(currentItem);

      deleteButton.setEnabled(operation.isDeleteEnabled());
      saveButton.setEnabled(false);

      open();
   }

   private void saveClicked(final Operation operation) {
      LOG.debug("Saving AbstractEditorDialog Instance");

      if (binder.writeBeanIfValid(currentItem)) {
         itemSaver.accept(currentItem, operation);
         //  Close dialog should be done in inherited screen
         //  See Jobs.java for example
      } else {
         LOG.debug("Saving aborted: binder has invalid status");
      }
   }

   private void deleteClicked() {
      if (confirmationDialog.getElement().getParent() == null) {
         getUI().ifPresent(ui -> ui.add(confirmationDialog));
      }
      confirmDelete();
   }

   protected abstract void confirmDelete();

   /**
    * Opens the confirmation dialog before deleting the current item.
    * <p>
    * The dialog will display the given title and message(s), then call
    * {@link #deleteConfirmed(Serializable)} if the Delete button is clicked.
    *
    * @param width             The dialog width
    * @param height            The dialog height
    * @param title             The title text
    * @param message           Detail message (optional, may be empty)
    * @param additionalMessage Additional message (optional, may be empty)
    */
   protected final void openConfirmationDialog(
         final String width,
         final String height,
         final String title,
         final String message,
         final String additionalMessage) {
      confirmationDialog.setWidth(width);
      confirmationDialog.setHeight(height);
      openConfirmationDialog(title, message, additionalMessage);
   }

   /**
    * Opens the confirmation dialog before deleting the current item.
    * <p>
    * The dialog will display the given title and message(s), then call
    * {@link #deleteConfirmed(Serializable)} if the Delete button is clicked.
    *
    * @param title             The title text
    * @param message           Detail message (optional, may be empty)
    * @param additionalMessage Additional message (optional, may be empty)
    */
   protected final void openConfirmationDialog(
         final String title,
         final String message,
         final String additionalMessage) {
      confirmationDialog.open(
            new DialogSettings(title, message, additionalMessage, "Verwijder", true)
            , getCurrentItem(), this::deleteConfirmed, this::cancelOperation);
   }

   /**
    * Removes the {@code item} from the backend and close the dialog.
    *
    * @param item the item to delete
    */
   private void doDelete(final T item) {
      itemDeleter.accept(item);
      close();
   }

   public void setErrorMessage(final String message) {
      errorMessage.setText(message);
   }

   public Label getErrorMessageLabel() {
      return errorMessage;
   }

   private void deleteConfirmed(final T item) {
      doDelete(item);
   }

   private void cancelOperation() {
      confirmationDialog.close();
   }

   public Button getDeleteButton() {
      return deleteButton;
   }

   public Button getSaveButton() {
      return saveButton;
   }

   public int getButtonCount() {
      return footerLeft.getComponentCount();
   }

   public void removeButton(final Component oldButton) {
      footerLeft.remove(oldButton);
   }

   /**
    * The operations supported by this dialog. Delete is enabled when editing
    * an already existing item.
    */
   public enum Operation {
      ADD("New", "toegevoegd", false),
      EDIT("Edit", "gewijzigd", true);

      private final String nameInTitle;
      private final String nameInText;
      private final boolean deleteEnabled;

      Operation(final String nameInTitle, final String nameInText, final boolean deleteEnabled) {
         this.nameInTitle = nameInTitle;
         this.nameInText = nameInText;
         this.deleteEnabled = deleteEnabled;
      }

      public String getNameInTitle() {
         return nameInTitle;
      }

      public String getNameInText() {
         return nameInText;
      }

      public boolean isDeleteEnabled() {
         return deleteEnabled;
      }
   }
}
