package nl.uwv.pws.backend.types;

import java.io.Serializable;

public interface FieldAttributes extends Serializable {
   String getWidth();

   boolean isSortable();

   String getProperty();

   boolean isPrefix();

   String getType();

   boolean isHidden();

   boolean usePlain();

   int getFlexGrow();

   FieldDescription getFieldDescription();

}
