package nl.uwv.pws.ui.components;

import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.shared.Registration;

import nl.uwv.pws.ui.util.HasAuthorization;

public class AuthorizedButton extends Button implements HasAuthorization {
   boolean buttonAuthorized = false;

   public AuthorizedButton() {
      super();
   }

   public AuthorizedButton(String label) {
      super(label);
   }

   public AuthorizedButton(Icon icon) {
      super(icon);
   }

   public AuthorizedButton(String label, Icon icon) {
      super(label, icon);
   }

   @Override
   public boolean isAuthorized() {
      return buttonAuthorized;
   }

   @Override
   public void setAuthorized(boolean authorized) {
      buttonAuthorized = authorized;
   }

   @Override
   public Registration addClickListener(
         ComponentEventListener<ClickEvent<Button>> listener) {
      if (buttonAuthorized) {
         return super.addClickListener(listener);
      }
      return Registration.once(() -> {});
   }
}
