package nl.uwv.pws.backend.desc;

public interface Parser {
}
