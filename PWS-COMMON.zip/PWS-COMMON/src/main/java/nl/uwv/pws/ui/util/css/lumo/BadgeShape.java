package nl.uwv.pws.ui.util.css.lumo;

public enum BadgeShape {

   NORMAL("normal"), PILL("pill");

   private final String style;

   BadgeShape(final String style) {
      this.style = style;
   }

   public String getThemeName() {
      return style;
   }
}
