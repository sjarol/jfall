package nl.uwv.pws.backend.dao;

import java.io.Serializable;

public interface SqlFilter extends Serializable {

   String getFilterSql();

   int getParametersSize();

   String getParameter(final int index);
}
