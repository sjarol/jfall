package nl.uwv.pws.backend.types;

import com.vaadin.flow.data.renderer.TemplateRenderer;

import nl.uwv.pws.ui.util.UIUtils;

import org.apache.commons.collections4.map.PassiveExpiringMap;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import java.io.Serializable;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

public class ColumnList implements RowId, Serializable {

   private static final Integer ID = 1;
   private static final Logger LOG = LogManager.getLogger(ColumnList.class);

   private static final PassiveExpiringMap<Integer, Boolean> HANDLED_EXCEPTIONS =
         new PassiveExpiringMap<>(5, TimeUnit.MINUTES);
   private final HashMap<Object, Object> map = new HashMap<>();

   public ColumnList(final ResultSet rs, final String[] columns, final String[] types) {
      for (int i = 0; i < columns.length; i++) {
         String name = columns[i];
         String type = types[i];
         try {
            if (StringUtils.equalsIgnoreCase("date", type)) {
               map.put(name, rs.getDate(name));
            } else if (StringUtils.equalsIgnoreCase("datenumber", type)) {
               map.put(name, Date.valueOf(UIUtils.polisDateStringToLocalDate(rs.getString(name))));
            } else if (StringUtils.equalsIgnoreCase("datetime", type)) {
               map.put(name, rs.getTimestamp(name));
            } else {
               map.put(name, rs.getObject(name));
            }
         } catch (SQLException e) {
            handleException(e);
         }
      }
      try {
         map.put(ID, rs.getRow());
      } catch (SQLException e) {
         handleException(e);
      }
   }

   public final void handleException(final SQLException e) {
      if (!HANDLED_EXCEPTIONS.containsKey(e.getErrorCode())) {
         HANDLED_EXCEPTIONS.put(e.getErrorCode(), Boolean.TRUE);
         UIUtils.handleError(e);
      }
   }

   /**
    * Create record without database results.
    *
    * @param row
    * @param columns
    * @param values
    */
   public ColumnList(final int row, final String[] columns, final Object[] values) {
      for (int i = 0; i < columns.length; i++) {
         map.put(columns[i], values[i]);
      }
      map.put(ID, row);
   }

   public String getFormattedValue(final Field field) {
      LOG.debug("Get formatted value " + field);
      if (field == null) {
         return null;
      }
      if (map.containsKey(field.getName())) {
         String value = field.getFormattedValue(map.get(field.getName()));
         LOG.debug(field.getName() + " = " + value);
         return value;
      }
      return null;
   }

   public TemplateRenderer<ColumnList> render(final Field field) {
      if (StringUtils.isEmpty(field.getProperty())) {
         return TemplateRenderer.of(getFormattedValue(field));
      }
      return TemplateRenderer.<ColumnList>of("[[item." + field.getProperty() + "]]")
            .withProperty(field.getProperty(), (ColumnList c) -> getFormattedValue(field));
   }

   public Object getValue(final Field field) {
      LOG.debug("Get value " + field);
      if (field != null) {
         return getValue(field.getName());
      }
      return null;
   }

   public Object getValue(final String fieldName) {
      LOG.debug("Get value " + fieldName);
      if (fieldName != null && map.containsKey(fieldName)) {
         Object value = map.get(fieldName);
         LOG.debug(fieldName + " = " + value);
         return value;
      }
      return null;
   }

   public LocalDate getValueAsLocalDate(final String fieldName) {
      LOG.debug("Get value as local date " + fieldName);
      if (fieldName != null && map.containsKey(fieldName)) {
         Object value = map.get(fieldName);
         if (value instanceof Date) {
            LOG.debug(fieldName + " = " + value);
            return ((Date) value).toLocalDate();
         }
      }
      return null;
   }

   public LocalDateTime getValueAsLocalDateTime(final String fieldName) {
      LOG.debug("Get value as local date/time " + fieldName);
      if (fieldName != null && map.containsKey(fieldName)) {
         Object value = map.get(fieldName);
         if (value instanceof Timestamp) {
            LOG.debug(fieldName + " = " + value);
            return ((Timestamp) value).toLocalDateTime();
         }
      }
      return null;
   }

   @Override
   public Object getId() {
      return map.get(ID);
   }
}
