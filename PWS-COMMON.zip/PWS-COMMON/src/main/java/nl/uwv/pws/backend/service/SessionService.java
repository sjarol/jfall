package nl.uwv.pws.backend.service;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import nl.uwv.pws.backend.dao.BackendException;
import oracle.jdbc.OracleTypes;

@SuppressWarnings("serial")
public class SessionService extends AbstractService {
   public static final String ENV_AUTH_DATASOURCE = "authorisationDataSource";

   private static final Logger LOG = LogManager.getLogger(SessionService.class);

   private static final String MSG_INTERNALERR = "Interne fout SessionService";

   private static SessionService instance = null;

   SessionService() {
      super(getDSName());
   }

   public static SessionService get() {
      // Using Double-checked locking
      SessionService localRef = instance;
      if (localRef == null) {
         synchronized (SessionService.class) {
            // Fetch and check again while guaranteed to have only 1 thread at the same time in this block of code
            localRef = instance;
            if (localRef == null) {
               instance = localRef = new SessionService();
            }
         }
      }
      return localRef;
   }

   public String getUserSession(final String userId) {
      final String sqlCall = "SELECT PUIK_ID, SESSION_ID FROM USER_SESSION" +
            " WHERE TS_LAST_EVENT > (SYSTIMESTAMP - 15/1440)" +
            "  AND PUIK_ID = ?";
      String sessionId = null;
      try (Connection conn = getDataSource().getConnection();
           PreparedStatement callStmt = conn.prepareStatement(sqlCall)) {
         callStmt.setString(1, userId);
         try (ResultSet rs = callStmt.executeQuery()) {
            if (rs.next()) {
               sessionId = rs.getString("SESSION_ID");
            }
         }

      } catch (Exception e) {
         throw new BackendException(MSG_INTERNALERR, e);
      }
      return sessionId;
   }

   public boolean insertUserSession(final String username, final String sessionId) {
      LOG.debug("insertUserSession voor userId " + username + " en sessionId " + sessionId);
      return doUpdateOrRemoveUserSession(
            "{ ? = call PPLS_PWS00.PWS_GUI.UPDATE_USR_SESSION(?,?) }", username, sessionId
      );
   }

   public void removeUserSession(final String username) {
      LOG.debug("removeUserSession voor user " + username);
      doUpdateOrRemoveUserSession("{ ? = call PPLS_PWS00.PWS_GUI.REMOVE_USR_SESSION(?,?) }", username, null);
   }

   public void removeUserSession(final String userId, final String sessionId) {
      LOG.debug("Remove user session voor userId " + userId + " en sessionId " + sessionId);
      doUpdateOrRemoveUserSession("{ ? = call PPLS_PWS00.PWS_GUI.REMOVE_USR_SESSION(?,?) }", userId, sessionId);
   }

   private synchronized boolean doUpdateOrRemoveUserSession(
         final String sqlCall, final String userId, final String sessionId) {

      int result = 0;
      try (Connection conn = getDataSource().getConnection(); CallableStatement callStmt = conn.prepareCall(sqlCall)) {
         callStmt.registerOutParameter(1, OracleTypes.INTEGER);
         callStmt.setString(2, userId);
         callStmt.setString(3, sessionId);
         callStmt.execute();
         result = callStmt.getInt(1);

         if (!conn.getAutoCommit()) {
            conn.commit();
         }

      } catch (Exception e) {
         throw new BackendException(MSG_INTERNALERR, e);
      }
      return result > 0;
   }

   protected static String getDSName() {
      String datasourceName = getStringFromContext(ENV_AUTH_DATASOURCE, null);
      if (datasourceName == null) {
         throw new BackendException("Naam voor datasource is niet gevonden: " + ENV_AUTH_DATASOURCE);
      }
      return datasourceName;
   }
}
