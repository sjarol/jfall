package nl.uwv.pws.backend.dao;

import java.io.Serializable;

public class PageAuthorization implements Authorization, Serializable {
   private MenuPage page;
   private String[] roles;

   public PageAuthorization(final MenuPage page, final String... roles) {
      setPage(page);
      setRoles(roles);
   }

   public MenuPage getPage() {
      return page;
   }

   public final void setPage(final MenuPage page) {
      this.page = page;
   }

   public String getName() {
      return page.getName();
   }

   public String getIconName() {
      return page.getIconName();
   }

   public String getUrl() {
      return page.getUrl();
   }

   @Override
   public String[] getRoles() {
      return roles;
   }

   public final void setRoles(final String... roles) {
      this.roles = roles;
   }
}
