package nl.uwv.pws.ui.util;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.vaadin.flow.component.Composite;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.router.PageTitle;

import nl.uwv.pws.backend.dao.MenuPage;
import nl.uwv.pws.backend.dao.PageAuthorization;
import nl.uwv.pws.backend.service.AuthorizationService;
import nl.uwv.pws.backend.service.UserService;
import nl.uwv.pws.ui.NotAuthorizedException;

public final class ViewAuthorizationHelper {
   private static final Logger LOG = LogManager.getLogger(ViewAuthorizationHelper.class);

   private ViewAuthorizationHelper() {
      // Empty private constructor, utility class
   }

   /**
    * Checks the view with AuthorizedView annotation, and throws NotAuthroizedException if
    * User has no authorization for the view
    *
    * @param page The page that holds the AuthorizedView annotation.
    */
   public static void checkAuthorized(final Composite<Div> page) {
      final String verleendViaABS = ", autorisaties worden verleend via ABS";
      boolean authorized = false;
      List<PageAuthorization> authorizedPages = AuthorizationService.get()
            .getAuthorizedPages(UserService.getCurrentUser());
      if (authorizedPages.isEmpty()) {
         throw new NotAuthorizedException("Gebruiker is voor geen enkel scherm geautoriseerd" + verleendViaABS);
      } else if (page.getClass().isAnnotationPresent(AuthorizedView.class)) {
         String viewName = page.getClass().getAnnotation(AuthorizedView.class).value();
         String pageTitle = getTitleforPage(page);
         LOG.debug("Check autorisatie voor scherm " + viewName + ": " + pageTitle);
         for (PageAuthorization authorizedPage : authorizedPages) {
            authorized = authorized || StringUtils.equalsIgnoreCase(authorizedPage.getPage().getName(), viewName);
         }
         if (!authorized) {
            LOG.warn("Gebruiker is niet geautoriseerd voor " + pageTitle);
            throw new NotAuthorizedException("U bent niet geautoriseerd voor deze pagina" + verleendViaABS);
         } else {
            LOG.debug("Gebruiker is geautoriseerd.");
         }
      } else {
         LOG.debug("Geen autorisatie definitie voor view " + page.getClass().getName());
      }
   }

   private static String getTitleforPage(final Composite<Div> page) {
      String pageTitle = "No title";
      if (page.getClass().isAnnotationPresent(PageTitle.class)) {
         pageTitle = page.getClass().getAnnotation(PageTitle.class).value();
      } else {
         MenuPage menuPage = getMenuPage(page);
         if (menuPage != null) {
            pageTitle = menuPage.getName();
         }
      }
      return pageTitle;
   }

   /**
    * Checks the view with PageMenuCode annotation, and retrieves the MenuPage object
    *
    * @param page The page that holds the PageMenuCode annotation.
    */
   public static MenuPage getMenuPage(final Composite<Div> page) {
      List<PageAuthorization> authorizedPages = AuthorizationService.get()
            .getAuthorizedPages(UserService.getCurrentUser());
      MenuPage menuPage = null;
      if (!authorizedPages.isEmpty() && page.getClass().isAnnotationPresent(PageMenuCode.class)) {
         String code = page.getClass().getAnnotation(PageMenuCode.class).value();
         LOG.debug("Bepaal MenuPage voor scherm " + code);
         for (PageAuthorization authorizedPage : authorizedPages) {
            if (StringUtils.equalsIgnoreCase(code, authorizedPage.getPage().getMenuCode())) {
               menuPage = authorizedPage.getPage();
            }
         }
      }
      if (menuPage == null) {
         LOG.debug("Geen MenuPage definitie voor view " + page.getClass().getName());
      }
      return menuPage;
   }
}
