package nl.uwv.pws.ui.layout.size;

public enum Tall implements Size {

   XS("var(--lumo-space-xs)", "spacing-tall-xs"),
   S("var(--lumo-space-s)", "spacing-tall-s"),
   M("var(--lumo-space-m)", "spacing-tall-m"),
   L("var(--lumo-space-l)", "spacing-tall-l"),
   XL("var(--lumo-space-xl)", "spacing-tall-xl");

   LayoutSize tallSize;

   Tall(final String variable, final String spacingClassName) {
      tallSize = new LayoutSize(variable, spacingClassName);
   }

   @Override
   public String[] getMarginAttributes() {
      return tallSize.getMargins();
   }

   @Override
   public String[] getPaddingAttributes() {
      return tallSize.getPaddings();
   }

   @Override
   public String getSpacingClassName() {
      return tallSize.getSpacingClassName();
   }

   @Override
   public String getVariable() {
      return tallSize.getVariable();
   }
}
