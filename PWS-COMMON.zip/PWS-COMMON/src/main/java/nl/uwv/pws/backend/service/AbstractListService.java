package nl.uwv.pws.backend.service;

import com.vaadin.flow.data.provider.QuerySortOrder;

import nl.uwv.pws.backend.dao.SqlFilter;
import nl.uwv.pws.backend.desc.FieldDescriptor;
import nl.uwv.pws.backend.types.ColumnList;
import nl.uwv.pws.dataprovider.SortStringGenerator;
import nl.uwv.pws.ui.util.UIUtils;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import javax.naming.NamingException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("serial")
public abstract class AbstractListService extends AbstractService implements ColumnListService {
   private static final int INITIAL_SIZE = 512;

   private static final Logger LOG = LogManager.getLogger(AbstractListService.class);

   private boolean hasGroupBy = false;
   private String selectGroupBy = null;
   private String groupBy = null;
   private boolean columnNamesChecked = false;
   private String[] columns;
   private String[] columnTypes;

   private SortStringGenerator sortStringGenerator;

   protected AbstractListService(final String dataSourceName) {
      super(dataSourceName);
      sortStringGenerator = new SortStringGenerator();
   }

   /**
    * @param sortStringGenerator the sortStringGenerator to set
    */
   public void setSortStringGenerator(final SortStringGenerator sortStringGenerator) {
      this.sortStringGenerator = sortStringGenerator;
   }

   @Override
   public List<ColumnList> fetchRows(final SqlFilter sqlFilter, final int limit, final int offset,
         final List<QuerySortOrder> sortOrders) {
      ArrayList<ColumnList> items = new ArrayList<>();
      if (sqlFilter == null) {
         return items;
      }
      LOG.debug("Fetch rows " + getViewName() + " starting at " + offset + " limit to " + limit);
      List<QuerySortOrder> sortOrdersToUse = createSortOrderList(sortOrders);
      String sql = createSelectStatement(sqlFilter, sortOrdersToUse);

      try (Connection conn = getDataSource().getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {

         int index = setFilterParams(stmt, sqlFilter);
         stmt.setInt(index++, offset);
         stmt.setInt(index, limit);
         try (ResultSet rs = stmt.executeQuery()) {
            checkColumns(rs);
            while (rs.next()) {
               items.add(new ColumnList(rs, getColumns(), getDataTypes()));
            }
         }
      } catch (SQLException | NamingException e) {
         UIUtils.handleError(e);
      }
      LOG.debug("Rows fetched " + items.size());
      return items;
   }

   @Override
   public long countRows(final SqlFilter sqlFilter) {
      long count = 0;
      if (sqlFilter == null) {
         return count;
      }
      String sql = createCountStatement(sqlFilter);
      LOG.debug("Start countRows " + getViewName());
      try (Connection conn = getDataSource().getConnection();
           PreparedStatement stmt = conn.prepareStatement(sql)) {

         setFilterParams(stmt, sqlFilter);
         try (ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
               count = rs.getLong(1);
            }
         }
      } catch (SQLException | NamingException e) {
         UIUtils.handleError(e);
      }
      LOG.debug("countRows returns " + count);
      return count;
   }

   protected List<QuerySortOrder> createSortOrderList(final List<QuerySortOrder> sortOrders) {
      List<QuerySortOrder> sortOrdersToUse = sortOrders;
      if (sortOrdersToUse == null || sortOrdersToUse.isEmpty()) {
         sortOrdersToUse = getSortOrders();
         if (sortOrdersToUse.isEmpty()) {
            sortOrdersToUse.add(getDefaultSortOrder());
         }
      }
      return sortOrdersToUse;
   }

   private int setFilterParams(PreparedStatement stmt, final SqlFilter sqlFilter) throws SQLException {
      int index = 0;
      for (index = 1; index <= sqlFilter.getParametersSize(); index++) {
         stmt.setString(index, sqlFilter.getParameter(index-1));
      }
      return index;
   }

   protected String createSelectStatement(final SqlFilter sqlFilter, List<QuerySortOrder> sortOrdersToUse) {
      StringBuilder sqlBuilder = new StringBuilder(INITIAL_SIZE);

      sqlBuilder.append("SELECT ").append(hasGroupBy ? selectGroupBy : "*")
            .append(" FROM ").append(getViewName())
            .append(" WHERE ").append(sqlFilter.getFilterSql());

      if (hasGroupBy) {
         sqlBuilder.append(" GROUP BY ").append(groupBy);
      }
      sqlBuilder.append(sortStringGenerator.generate(sortOrdersToUse))
            .append(" OFFSET ? ROWS FETCH NEXT ? ROWS ONLY");
      
      return sqlBuilder.toString();
   }

   protected String createCountStatement(final SqlFilter sqlFilter) {
      StringBuilder sqlBuilder = new StringBuilder(INITIAL_SIZE);
      
      sqlBuilder.append("SELECT COUNT(*) FROM ");
      
      if (hasGroupBy) {
         sqlBuilder.append("( SELECT ").append(groupBy).append(" FROM ");
      }
      
      sqlBuilder.append(getViewName()).append(" WHERE ").append(sqlFilter.getFilterSql());
      
      if (hasGroupBy) {
         sqlBuilder.append(" GROUP BY ").append(groupBy).append(")");
      }
      return sqlBuilder.toString();
   }

   private void checkColumns(final ResultSet rs) {
      if (!columnNamesChecked) {
         int colNr = 0;
         columnNamesChecked = true;
         getColumns();
         getDataTypes();
         for (int index = 0; index < columns.length; index++) {
            LOG.debug("Controle kolomnaam " + columns[index]);
            try {
               colNr = rs.findColumn(columns[index]);
               LOG.debug(" => kolomnummer=" + colNr);
            } catch (SQLException e) {
               LOG.warn("Definitie bevat onbekende kolomnaam " + columns[index], e);
               try {
                  columns[index] = rs.getMetaData().getColumnLabel(index);
                  columnTypes[index] = "String";
                  LOG.warn(" => aangepast naar " + columns[index]);
               } catch (SQLException ex) {
                  LOG.warn("Fout bij bepalen naam: " + ex);
               }
            }
         }
      }
   }

   protected String[] getColumns() {
      if (columns == null) {
         columns = getDescriptor().getColumnNames();
      }
      return columns;
   }

   protected String[] getDataTypes() {
      if (columnTypes == null) {
         columnTypes = getDescriptor().getColumnDataTypes();
      }
      return columnTypes;
   }

   protected void setGroupBy(final String selectGroupBy, final String groupBy) {
      this.selectGroupBy = selectGroupBy;
      this.groupBy = groupBy;
      this.hasGroupBy = true;
   }

   protected List<QuerySortOrder> getSortOrders() {
      return new ArrayList<>();
   }

   protected abstract String getViewName();

   public abstract FieldDescriptor getDescriptor();

   protected abstract QuerySortOrder getDefaultSortOrder();
}
