package nl.uwv.pws.backend.service;

import com.vaadin.flow.data.provider.QuerySortOrder;
import com.vaadin.flow.data.provider.SortDirection;

import nl.uwv.pws.dataprovider.SortStringGenerator;

import nl.uwv.pws.ui.util.UIUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import javax.naming.NamingException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("serial")
public class ListBoxServiceImpl extends AbstractService implements ListBoxService {
   private static final int INITIAL_SIZE = 512;
   private static final Logger LOG = LogManager.getLogger(ListBoxServiceImpl.class);

   private String viewName = null;
   private String columnName = null;
   private QuerySortOrder defaultSort;

   private SortStringGenerator sortStringGenerator;

   public ListBoxServiceImpl(final String dataSourceName, final String viewName, final String columnName) {
      super(dataSourceName);
      this.viewName = viewName;
      this.columnName = columnName;
      this.sortStringGenerator = new SortStringGenerator();
      this.defaultSort = new QuerySortOrder(columnName, SortDirection.ASCENDING);
   }

   /**
    * @param sortStringGenerator the sortStringGenerator to set
    */
   public void setSortStringGenerator(final SortStringGenerator sortStringGenerator) {
      this.sortStringGenerator = sortStringGenerator;
   }

   @Override
   public List<String> fetchRows(
         final String filter,
         final int limit,
         final int offset,
         final List<QuerySortOrder> sortOrders) {

      ArrayList<String> items = new ArrayList<>();
      LOG.info("Fetch rows starting at " + offset + " limit to " + limit);
      String sql = createSelectStatement(createSortOrderList(sortOrders));
      try (Connection conn = getDataSource().getConnection();
           PreparedStatement stmt = conn.prepareStatement(sql)) {

         int index = 1;
         stmt.setString(index++, createLikeFilter(filter));
         stmt.setInt(index++, offset);
         stmt.setInt(index, limit);
         try (ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
               items.add(rs.getString(1));
            }
         }
      } catch (SQLException | NamingException e) {
         UIUtils.handleError(e);
      }
      LOG.info("Rows fetched " + items.size());
      return items;
   }

   protected String createSelectStatement(List<QuerySortOrder> sortOrdersTouse) {
      StringBuilder sqlBuilder = new StringBuilder(INITIAL_SIZE);

      sqlBuilder.append("SELECT DISTINCT ").append(columnName)
            .append(" FROM ").append(viewName)
            .append(" WHERE ").append(columnName).append(" like ? ")
            .append(sortStringGenerator.generate(sortOrdersTouse))
            .append(" OFFSET ? ROWS FETCH NEXT ? ROWS ONLY");
      
      return sqlBuilder.toString();
   }

   protected List<QuerySortOrder> createSortOrderList(final List<QuerySortOrder> sortOrders) {
      List<QuerySortOrder> sortOrdersTouse = sortOrders;
      if (sortOrdersTouse == null || sortOrdersTouse.isEmpty()) {
         sortOrdersTouse = new ArrayList<>();
         sortOrdersTouse.add(defaultSort);
      }
      return sortOrdersTouse;
   }

   private String createLikeFilter(final String filter) {
      String likeFilter = "%";
      if (StringUtils.isNotEmpty(filter)) {
         if (StringUtils.containsAny(filter, '%', '_')) {
            likeFilter = filter;
         } else {
            likeFilter += filter + "%";
         }
      }
      return likeFilter;
   }

   @Override
   public long countRows(final String filter) {
      long count = 0;
      LOG.info("Start countRows");
      String sql = createCountStatement();
      try (Connection conn = getDataSource().getConnection();
           PreparedStatement stmt = conn.prepareStatement(sql)) {

         stmt.setString(1, createLikeFilter(filter));
         try (ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
               count = rs.getLong(1);
            }
         }
      } catch (SQLException | NamingException e) {
         UIUtils.handleError(e);
      }
      LOG.info("countRows returns " + count);
      return count;
   }

   protected String createCountStatement() {
      StringBuilder sqlBuilder = new StringBuilder(INITIAL_SIZE);

      sqlBuilder.append("SELECT COUNT(DISTINCT ").append(columnName).append(")")
            .append(" FROM ").append(viewName)
            .append(" WHERE ").append(columnName).append(" like ? ");

      return sqlBuilder.toString();
   }
}
