package nl.uwv.pws.ui.components;

import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;

import java.io.Serializable;

/**
 * Currently only used in the {@link AbstractEditorDialog}, should move to {@link ConfirmDialog} in the future, but
 * requires a rewrite of the current logic, since that still used logic to reuse the same dialog instance from
 * everywhere.
 */
class EditorConfirmationDialog<T extends Serializable> extends AbstractConfirmationDialog<T> {
   @Override
   HorizontalLayout createFooter(final Button saveButton, final Button cancelButton) {
      return new HorizontalLayout(saveButton, cancelButton);
   }
}
