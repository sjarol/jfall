package nl.uwv.pws.ui.components;

import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.HasStyle;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.shared.Registration;
import nl.uwv.pws.ui.util.UIUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import java.io.Serializable;
import java.util.function.Consumer;

/**
 * A generic dialog for confirming or cancelling an action.
 *
 * @param <T> The type of the action's subject
 */
@CssImport(value = "./styles/components/dialog.css")
@CssImport(value = "./styles/components/confirmation-dialog.css", themeFor = "vaadin-*-overlay")
abstract class AbstractConfirmationDialog<T extends Serializable> extends Dialog implements HasStyle {

   private static final Logger LOG = LogManager.getLogger(AbstractConfirmationDialog.class);
   private static final String COMPONENT_ID = "confirmation";

   public static final String CLASS_HEADER = "dialog-header";
   public static final String CLASS_CONTENT = "dialog-content";
   public static final String CLASS_FOOTER = "dialog-footer";

   // Footer
   private final Button saveButton = UIUtils.createPrimaryButton("Opslaan");
   private final Button cancelButton = UIUtils.createTertiaryButton("Annuleren");
   // Header
   private final Label titleField = UIUtils.createH2Label("");
   //  Content
   private final Label messageLabel = new Label();
   private final Label extraMessageLabel = new Label();

   private Registration registrationForConfirm;
   private Registration registrationForCancel;

   private static final Runnable NO_OP = () -> { };

   /**
    * Constructor.
    */
   public AbstractConfirmationDialog() {
      super.setId(COMPONENT_ID);
      super.setCloseOnOutsideClick(false);

      VerticalLayout dialogStructure = new VerticalLayout(
            initHeader(),
            initFormLayout(),
            initFooter());

      super.add(dialogStructure);
   }

   private HorizontalLayout initHeader() {
      HorizontalLayout header = new HorizontalLayout(titleField);
      header.setClassName(CLASS_HEADER);
      header.setWidthFull();

      return header;
   }

   private Component initFormLayout() {
      VerticalLayout content = new VerticalLayout();
      content.setClassName(CLASS_CONTENT);
      content.setWidthFull();
      content.add(messageLabel, extraMessageLabel);

      return content;
   }

   private HorizontalLayout initFooter() {
      HorizontalLayout footer = createFooter(saveButton, cancelButton);
      footer.setClassName(CLASS_FOOTER);
      footer.setJustifyContentMode(FlexComponent.JustifyContentMode.END);
      footer.setWidthFull();

      saveButton.addClickListener(e -> close());
      saveButton.setId("operatie-bevestigen");

      cancelButton.addClickListener(e -> close());
      cancelButton.setId("operatie-annuleren");

      return footer;
   }

   abstract HorizontalLayout createFooter(final Button saveButton, final Button cancelButton);

   /**
    * Opens the confirmation dialog.
    * <p>
    * The dialog will display the given title and message(s), then call
    * <code>confirmHandler</code> if the Confirm button is clicked, or
    * <code>cancelHandler</code> if the Cancel button is clicked.
    *
    * @param dialogSettings The dialog settings used to open this dialog
    * @param item           The subject of the action
    * @param confirmHandler The confirmation handler function
    * @param cancelHandler  The cancellation handler function
    */
   public void open(
         final DialogSettings dialogSettings,
         final T item,
         final Consumer<T> confirmHandler,
         final Runnable cancelHandler) {

      LOG.debug("ConfirmationDialog openen");

      titleField.setText(dialogSettings.getTitle());
      messageLabel.setText(dialogSettings.getMessage());
      extraMessageLabel.setText(dialogSettings.getAdditionalMessage());
      saveButton.setText(dialogSettings.getActionName());

      Runnable cancelAction = cancelHandler == null ? NO_OP : cancelHandler;

      if (registrationForConfirm != null) {
         registrationForConfirm.remove();
      }

      registrationForConfirm = saveButton
            .addClickListener(e -> confirmHandler.accept(item));

      if (registrationForCancel != null) {
         registrationForCancel.remove();
      }

      registrationForCancel = cancelButton
            .addClickListener(e -> cancelAction.run());

      this.addOpenedChangeListener(e -> {
         if (!e.isOpened()) {
            cancelAction.run();
         }
      });

      saveButton.removeThemeVariants(ButtonVariant.LUMO_ERROR);
      if (dialogSettings.isDisruptive()) {
         saveButton.addThemeVariants(ButtonVariant.LUMO_ERROR);
      }
      open();
   }
}
