package nl.uwv.pws.ui.layout.size;

public enum Left implements Size {

   AUTO("auto", null),
   XS("var(--lumo-space-xs)", "spacing-l-xs"),
   S("var(--lumo-space-s)", "spacing-l-s"),
   M("var(--lumo-space-m)", "spacing-l-m"),
   L("var(--lumo-space-l)", "spacing-l-l"),
   XL("var(--lumo-space-xl)", "spacing-l-xl"),
   RESPONSIVE_M("var(--lumo-space-r-m)", null),
   RESPONSIVE_L("var(--lumo-space-r-l)", null),
   RESPONSIVE_X("var(--lumo-space-r-x)", null);

   LayoutSize leftSize;

   Left(final String variable, final String spacingClassName) {
      leftSize = new LayoutSize(variable, spacingClassName);
   }

   @Override
   public String[] getMarginAttributes() {
      return leftSize.getMarginsWithSuffix(LayoutSize.SUFFIX_LEFT);
   }

   @Override
   public String[] getPaddingAttributes() {
      return leftSize.getPaddingsWithSuffix(LayoutSize.SUFFIX_LEFT);
   }

   @Override
   public String getSpacingClassName() {
      return leftSize.getSpacingClassName();
   }

   @Override
   public String getVariable() {
      return leftSize.getVariable();
   }
}
