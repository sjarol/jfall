package nl.uwv.pws.backend.filter;

import nl.uwv.pws.backend.dao.SqlFilter;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

/**
 * SqlFilter implementation that takes away some of the repetitive code often used when implementing
 * an SqlFilter. If the filter and the parameters are known on construction time, you can extends this
 * class, pass the values into the super-constructor and the interface methods will be implemented for you.
 */
public abstract class AbstractSqlFilter implements SqlFilter, Serializable {
   private final String sqlFilter;
   private final List<String> parameters;

   /**
    * Constructs a new AbstractSqlFilter.
    *
    * @param sqlFilter The SQL WHERE clause.
    * @param parameters The parameters to set.
    */
   protected AbstractSqlFilter(final String sqlFilter, final String... parameters) {
      this.sqlFilter = sqlFilter;
      this.parameters = Arrays.asList(parameters);
   }

   /**
    * The SQL WHERE clause to use.
    *
    * @return The SQL WHERE clause to use.
    */
   @Override
   public String getFilterSql() {
      return sqlFilter;
   }

   /**
    * Returns the number of parameters to set on the SQL WHERE clause.
    *
    * @return the number of parameters to set on the SQL WHERE clause.
    */
   @Override
   public int getParametersSize() {
      return parameters.size();
   }

   /**
    * Returns the parameter value to set for the given index.
    *
    * @param index the index of the parameter to set.
    * @return The parameter value to set for the given index.
    */
   @Override
   public String getParameter(final int index) {
      return parameters.get(index);
   }
}
