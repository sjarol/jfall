package nl.uwv.pws.ui.components.navigation.bar;

import static nl.uwv.pws.ui.util.UIUtils.IMG_PATH;

import java.net.URL;

import org.apache.commons.lang3.StringUtils;

import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.Text;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.contextmenu.ContextMenu;
import com.vaadin.flow.component.html.H4;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.icon.VaadinIcon;

import nl.uwv.pws.backend.dao.MenuPage;
import nl.uwv.pws.backend.dao.User;
import nl.uwv.pws.backend.service.UserService;
import nl.uwv.pws.ui.AppInfo;
import nl.uwv.pws.ui.MainLayout;
import nl.uwv.pws.ui.components.BasicDialog;
import nl.uwv.pws.ui.components.FlexBoxLayout;
import nl.uwv.pws.ui.components.ListItem;
import nl.uwv.pws.ui.components.navigation.tab.NaviTabs;
import nl.uwv.pws.ui.util.PdfHelp;
import nl.uwv.pws.ui.util.UIUtils;

abstract class AbstractBar extends FlexBoxLayout {
   protected Button menuIcon;
   protected Button pageCodeIcon;
   protected H4 pageTitle;
   protected Image avatar;
   protected FlexBoxLayout actionItems;
   protected Button addTab;
   protected NaviTabs tabs;
   private AppInfo appInfo;
   private PdfHelp help;
   private final MenuPage menuPage = new MenuPage();

   public AbstractBar() {
      this(new MenuPage());
   }

   @SuppressWarnings("java:S1699") // Call to overridable method getBarClassName from constructor
   public AbstractBar(final MenuPage page) {
      super.setClassName(getBarClassName());
      menuPage.setName(page.getName());
      initMenuIcon();
      initPageCode(page.getIconName(), page.getMenuCode());
      initPageTitle(page.getDescription());
      initAvatar();
      initActionItems();
   }

   protected abstract String getBarClassName();

   public void setAppInfo(final AppInfo appInfo) {
      String tooltip = appInfo == null ? ""
            : String.format("Versie %s, %s", appInfo.getImplementationVersion(), appInfo.getBuildDate());
      UIUtils.setTooltip(tooltip, pageCodeIcon);
      this.appInfo = appInfo;
   }

   public void setHelp(String pdfFilename, String helpDescription) {
      setPdfHelp(new PdfHelp(pdfFilename, helpDescription));
   }

   public void setHelp(final URL pdfUrl, final String helpDescription) {
      setPdfHelp(new PdfHelp(pdfUrl, helpDescription));
   }

   public void setPdfHelp(final PdfHelp pdfHelp) {
      clearHelp();
      help = pdfHelp;
      addActionItem(help.getButton());
   }

   public void clearHelp() {
      if (help != null) {
         removeActionItem(help.getButton());
         help = null;
      }
   }

   private void initMenuIcon() {
      menuIcon = UIUtils.createTertiaryInlineButton(VaadinIcon.MENU);
      // menuIcon.removeThemeVariants(ButtonVariant.LUMO_ICON)
      menuIcon.addClassName(getBarClassName() + "__navi-icon");
      menuIcon.addClickListener(e -> MainLayout.get().getNaviDrawer().toggle());
      UIUtils.setAriaLabel("Menu", menuIcon);
      UIUtils.setLineHeight("1", menuIcon);
   }

   private void initPageCode(final String iconName, final String pageCode) {
      VaadinIcon icon = UIUtils.getVaadinIcon(iconName);
      pageCodeIcon = (icon == null ? UIUtils.createTertiaryInlineButton(VaadinIcon.INFO_CIRCLE_O)
            : UIUtils.createTertiaryInlineButton(icon));
      pageCodeIcon.addClassNames(getBarClassName() + "__page-icon");
      pageCodeIcon.addClickListener(e -> showAbout());

      UIUtils.setLineHeight("1", pageCodeIcon);
      setPageCode(pageCode);
   }

   private void initPageTitle(final String description) {
      pageTitle = new H4();
      pageTitle.setClassName(getBarClassName() + "__title");
      pageTitle.setId("page-descr");
      setTitle(description);
   }

   private void initAvatar() {
      User loggedUser = UserService.getCurrentUser();
      avatar = new Image();
      avatar.setId("avatar_button");
      avatar.setClassName(getBarClassName() + "__avatar");
      if (loggedUser == null) {
         avatar.setSrc(IMG_PATH + "avatar.png");
      } else {
         avatar.setSrc("https://mijnsite.sharepoint.uwv.nl:443/User%20Photos/Profielafbeeldingen/"
               + loggedUser.getUsername() + "_MThumb.jpg");
         avatar.setAlt("User menu");
         avatar.getElement().setAttribute("onerror", "this.onerror=null; this.src='" + IMG_PATH + "avatar.png'");

         ContextMenu contextMenu = new ContextMenu(avatar);
         contextMenu.setOpenOnClick(true);
         contextMenu.addItem(loggedUser.getUsername() + "@uwv.nl");
         contextMenu.addItem("Logout", e -> logout());
      }
   }

   protected void showAbout() {
      if (appInfo != null) {
         BasicDialog dialog = new BasicDialog(null, "About", "25vw", "45vh");
         dialog.setContent(new Text("Module specificatie"),
               new ListItem(VaadinIcon.MODAL.create(), "Project: " + appInfo.getImplementationTitle()),
               new ListItem(VaadinIcon.COPY.create(), "Versie: " + appInfo.getImplementationVersion()),
               new ListItem(VaadinIcon.CALENDAR.create(), "Build: " + appInfo.getBuildDate()),
               new ListItem(VaadinIcon.FILE_TEXT.create(), "Specificatie: " + appInfo.getSpecificationTitle()),
               new ListItem(VaadinIcon.COPY.create(), "Versie: " + appInfo.getSpecificationVersion()));
         dialog.open();
      }
   }

   protected void logout() {
      User.logout();
      UI.getCurrent().getPage().reload();
   }

   protected final void initActionItems() {
      actionItems = new FlexBoxLayout();
      actionItems.addClassName(getBarClassName() + "__action-items");
      actionItems.setVisible(false);
   }

   /* === MENU ICON === */

   public Button getMenuIcon() {
      return menuIcon;
   }

   /* === MENU PAGE === */

   public void setMenuPage(final MenuPage page) {
      menuPage.setName(page.getName());
      setPageIcon(page.getIconName());
      setPageCode(page.getMenuCode());
      setTitle(page.getDescription());
   }

   public MenuPage getMenuPage() {
      MenuPage page = new MenuPage();
      page.setIconName(menuPage.getIconName());
      page.setMenuCode(menuPage.getMenuCode());
      page.setName(menuPage.getName());
      page.setDescription(menuPage.getDescription());

      return page;
   }

   public void setPageIcon(final String iconName) {
      if (StringUtils.isNotEmpty(iconName)) {
         pageCodeIcon.setIcon(UIUtils.getVaadinIcon(iconName).create());
      } else {
         pageCodeIcon.setIcon(VaadinIcon.INFO_CIRCLE_O.create());
      }
   }

   public void setPageCode(final String code) {
      menuPage.setMenuCode(code);
      if (StringUtils.isNotEmpty(code)) {
         pageCodeIcon.setText(code);
      } else {
         pageCodeIcon.setText("UWV");
      }
   }

   /**
    * Gebruik PageMenuCode annotatie met menu/page code bv @MenuPage("PWS90") De
    * annotatie PageTitle mag dan ook vervallen.
    *
    * @see nl.uwv.pws.ui.util.PageMenuCode#value()
    */
   public final void setTitle(final String title) {
      menuPage.setDescription(title);
      pageTitle.setText(title);
   }

   public String getPageTitle() {
      String title;
      if (StringUtils.isNotEmpty(menuPage.getName())) {
         title = StringUtils.isEmpty(menuPage.getMenuCode())
               ? menuPage.getName()
               : (menuPage.getMenuCode() + " " + menuPage.getName());
      } else if (StringUtils.isNotEmpty(menuPage.getDescription())) {
         title = StringUtils.isEmpty(menuPage.getMenuCode())
               ? menuPage.getDescription()
               : (menuPage.getMenuCode() + " " + menuPage.getDescription());
      } else {
         title = menuPage.getMenuCode();
      }
      return title;
   }

   /* === ACTION ITEMS === */

   public Component addActionItem(final Component component) {
      actionItems.add(component);
      updateActionItemsVisibility();
      return component;
   }

   public Button addActionItem(final VaadinIcon icon) {
      Button button = UIUtils.createButton(icon, ButtonVariant.LUMO_SMALL, ButtonVariant.LUMO_TERTIARY);
      addActionItem(button);
      return button;
   }

   public void removeActionItem(final Component... components) {
      actionItems.remove(components);
      updateActionItemsVisibility();
   }

   public void removeAllActionItems() {
      clearHelp();
      actionItems.removeAll();
      updateActionItemsVisibility();
   }

   /* === AVATAR == */

   public Image getAvatar() {
      return avatar;
   }

   /* === UPDATE VISIBILITY === */

   protected void updateActionItemsVisibility() {
      actionItems.setVisible(actionItems.getComponentCount() > 0);
   }
}
