package nl.uwv.pws.backend.lomo;

import java.sql.Date;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.StringUtils;

public class LomoLogMessage {

   public enum LomoTransaction {
      CREATE, READ, UPDATE, DELETE, LOGIN, LOGOUT, OTHER
   }

   public enum LomoResult {
      OK, ERROR, WARN
   }

   private final String action;
   private final LomoTransaction transaction;
   private final LomoResult result;
   private final String message;
   private final List<KeyValue> details;

   /**
    * Maak een log bericht voor de LomoLogger
    *
    * @param handeling De handeling die we willen loggen.
    * @param transactieType Het soort transactie dat we willen loggen.
    * @param resultaat Het type resultaat van handeling dat we willen loggen.
    * @param bericht Het bericht dat we willen loggen.
    */
   public LomoLogMessage(
         final String handeling,
         final LomoTransaction transactieType,
         final LomoResult resultaat,
         final String bericht) {
      action = handeling;
      transaction = transactieType;
      result = resultaat;
      message = bericht;
      details = new ArrayList<>();
   }

   /**
    * Voeg een detail regel toe aan log bericht.
    *
    * @param label De key waaronder de detail-waarde wordt opgeslagen.
    * @param value De detail-waarde die we willen toevoegen.
    * @return LomoLogMessage logbericht
    */
   public LomoLogMessage addDetail(final String label, final Object value) {
      Object newValue;

      // Convert local datum naar SQL datum
      if (value instanceof LocalDate) {
         newValue = Date.valueOf((LocalDate) value);
      } else if (value instanceof LocalDateTime) {
         newValue = Timestamp.valueOf((LocalDateTime) value);
      } else {
         newValue = value;
      }

      details.add(new KeyValue(label, newValue));

      return this;
   }

   /**
    * Voeg detail regels toe aan log bericht.
    *
    * @param label De key waaronder de detail-waarden wordt opgeslagen.
    * @param values Set van detail-waarden die moeten worden toegevoegd onder het genoemde label.
    * @return LomoLogMessage logbericht
    */
   public LomoLogMessage addDetails(final String label, final Set<Object> values) {
      values.forEach(value -> addDetail(label, value));

      return this;
   }

   /**
    * @return the action
    */
   public String getAction() {
      return action;
   }

   /**
    * @return the transaction
    */
   public LomoTransaction getTransaction() {
      return transaction;
   }

   /**
    * @return the result
    */
   public LomoResult getResult() {
      return result;
   }

   /**
    * @return the message
    */
   public String getMessage() {
      return message;
   }

   /**
    * @return de lijst met datail sleutels.
    */
   public List<String> getDetailKeys() {
      List<String> detailKeys = new ArrayList<>();
      for (KeyValue keyValue : details) {
         detailKeys.add(keyValue.getKey());
      }

      return detailKeys;
   }

   /**
    * Zoekt een detail-waarde op bij een gegeven key (label).
    *
    * @param key De key (label) waarbij je de detail-waarde wilt ophalen.
    * @return detail waarde voor key, null indien niet gevonden.
    */
   public Object getDetailValue(final String key) {
      Object value = null;
      for (KeyValue keyValue : details) {
         if (StringUtils.equals(key, keyValue.getKey())) {
            value = keyValue.getValue();
         }
      }

      return value;
   }

   protected List<KeyValue> getDetails() {
      return details;
   }

   @Override
   public String toString() {
      return "LomoLogMessage [action=" + action + ", transaction=" + transaction + ", result=" + result + ", message="
            + message + ", details=" + details + "]";
   }

   protected static class KeyValue {
      private final String key;
      private final Object value;

      KeyValue(final String key, final Object value) {
         this.key = key;
         this.value = value;
      }

      String getKey() {
         return key;
      }

      Object getValue() {
         return value;
      }

      @Override
      public String toString() {
         return "KeyValue [key=" + key + ", value=" + value + "]";
      }
   }
}
