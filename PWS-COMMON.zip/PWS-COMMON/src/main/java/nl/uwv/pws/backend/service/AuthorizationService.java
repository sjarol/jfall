package nl.uwv.pws.backend.service;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import org.apache.commons.collections4.map.PassiveExpiringMap;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.server.VaadinServletRequest;

import nl.uwv.pws.backend.dao.AuthorizationType;
import nl.uwv.pws.backend.dao.BackendException;
import nl.uwv.pws.backend.dao.ComponentAuthorization;
import nl.uwv.pws.backend.dao.MenuPage;
import nl.uwv.pws.backend.dao.PageAuthorization;
import nl.uwv.pws.backend.dao.User;
import oracle.jdbc.OracleTypes;

@SuppressWarnings("serial")
public final class AuthorizationService extends AbstractService {
   private static final Logger LOG = LogManager.getLogger(AuthorizationService.class);

   public static final String ENV_AUTH_DATASOURCE = "authorisationDataSource";
   public static final String ENV_MENU_CONTEXTROOT = "menuContextRoot";

   private static final String URL_SEP = "/";
   private static final String LOGIN = URL_SEP + "login";
   private static final int ENTRY_EXPIRATION_TIME = 5;
   private static final String PAGE_KEY = "Page";
   private static final String MENU_CONTEXTROOT = URL_SEP + "webapps";
   private static final String MSG_INTERNALERR = "Interne fout AuthorizationService";

   private static String menuContextRoot;
   private final Map<String, Set<String>> authCache;
   private final Map<String, List<PageAuthorization>> pageCache;
   private final Map<String, List<ComponentAuthorization>> componentCache;

   private static AuthorizationService instance = null;
   private static VaadinServletRequest mockRequest = null;

   private AuthorizationService() {
      super(getDSName());
      authCache = new PassiveExpiringMap<>(ENTRY_EXPIRATION_TIME, TimeUnit.MINUTES);
      pageCache = new PassiveExpiringMap<>(ENTRY_EXPIRATION_TIME, TimeUnit.MINUTES);
      componentCache = new PassiveExpiringMap<>(ENTRY_EXPIRATION_TIME, TimeUnit.MINUTES);
   }

   public static AuthorizationService get() {
      // Using Double-checked locking
      AuthorizationService localRef = instance;
      if (localRef == null) {
         synchronized (AuthorizationService.class) {
            // Fetch and check again while guaranteed to have only 1 thread at the same time in this block of code
            localRef = instance;
            if (localRef == null) {
               instance = localRef = new AuthorizationService();
            }
         }
      }
      return localRef;
   }

   public List<PageAuthorization> getAuthorizedPages(final User user) {
      if (user == null) {
         List<PageAuthorization> pageList = new ArrayList<>();
         MenuPage loginPage = new MenuPage();
         loginPage.setDescription("Login");
         loginPage.setIconName(VaadinIcon.CONNECT_O.toString());
         loginPage.setUrl(getLoginUrl());
         pageList.add(new PageAuthorization(loginPage, ""));
         return pageList;
      }
      return getAuthorizedPages().stream().filter(p -> p.isAuthorized(user.getRoles())).collect(Collectors.toList());
   }

   public Optional<String> getPageUrlByName(final String name) {
      return getAuthorizedPages().stream()
            .filter(p -> name.equals(p.getName())).map(PageAuthorization::getUrl)
            .findFirst();
   }

   public String getLoginUrl() {
      return getUrlPrefix() + LOGIN;
   }

   private List<PageAuthorization> getAuthorizedPages() {
      List<PageAuthorization> pages;

      if (pageCache.containsKey(PAGE_KEY)) {
         pages = pageCache.get(PAGE_KEY);
      } else {
         pages = createPageAuthorizations();
         pageCache.put(PAGE_KEY, pages);
      }

      return pages;
   }

   public List<ComponentAuthorization> getAuthorizedComponents(final String page, final User user) {
      return getAuthorizedComponents(page).stream()
            .filter(c -> c.getPage().equals(page) && c.isAuthorized(user.getRoles()))
            .collect(Collectors.toList());
   }

   private List<ComponentAuthorization> getAuthorizedComponents(final String page) {
      List<ComponentAuthorization> components;

      if (componentCache.containsKey(page)) {
         components = componentCache.get(page);
      } else {
         components = createComponentAuthorizations(page);
         componentCache.put(page, components);
      }

      return components;
   }

   public boolean isUserAuthorizedFor(final AuthorizationType objectType, final String objectName,
         final String menuName) {
      return isUserAuthorizedFor(UserService.getCurrentUser(), objectType, objectName, menuName);
   }

   protected boolean isUserAuthorizedFor(final User loggedUser, final AuthorizationType objectType,
         final String objectName, final String menuName) {
      List<String> userGroups = Arrays.asList(loggedUser.getRoles());
      for (String allowedGroup : getAuthorizationGroups(objectType, objectName, menuName)) {
         if (userGroups.contains(allowedGroup)) {
            return true;
         }
      }
      if (LOG.isDebugEnabled()) {
         LOG.debug("Allowed Groups" + getAuthorizationGroups(objectType, objectName, menuName));
         LOG.debug(String.format("isUserAuthorizedFor: Gebruiker %s niet geauthoriseerd voor: %s.%s.%s",
               loggedUser.getUsername(), menuName, objectType, objectName));
         LOG.debug("AD groepen:" + userGroups);
      }
      return false;
   }

   public void clearCache() {
      LOG.debug("AuthorizationService: cache cleared");
      authCache.clear();
      componentCache.clear();
      pageCache.clear();
   }

   private Set<String> getAuthorizationGroups(
         final AuthorizationType objectType,
         final String objectName,
         final String menuName) {
      String key = menuName + "." + objectType.name() + "." + objectName;
      if (!authCache.containsKey(key)) {
         authCache.put(key, getAuthorizationGroups(objectType.name(), objectName, menuName));
      }
      return authCache.get(key);
   }


   private List<PageAuthorization> createPageAuthorizations() {
      LOG.debug("Bepaal menu autorisaties");
      String sql = "SELECT * FROM PWS_MENU WHERE HIS_TS_END = DATE '9999-12-31' ORDER BY SORTERING,MNU_CD";
      List<PageAuthorization> pageAuthList = new ArrayList<>();

      String urlPrefix = getUrlPrefix();
      try (Connection conn = getDataSource().getConnection();
           PreparedStatement prepStmt = conn.prepareStatement(sql);
           ResultSet rs = prepStmt.executeQuery()) {

         while (rs.next()) {
            MenuPage page = new MenuPage();
            page.setMenuCode(rs.getString("MNU_CD"));
            page.setName(rs.getString("NAAM"));
            page.setIconName(rs.getString("ICON"));
            String url = rs.getString("URL");
            if (url.startsWith(URL_SEP)) {
               url = urlPrefix + url;
            }
            page.setUrl(url);
            page.setDescription(rs.getString("OMSCHRIJVING"));

            String[] roles = getAuthorizationGroups(
                  AuthorizationType.MNU, page.getName(), page.getName()).toArray(new String[1]
            );
            pageAuthList.add(new PageAuthorization(page, roles));

         }
      } catch (Exception e) {
         throw new BackendException(MSG_INTERNALERR, e);
      }
      LOG.debug("Aantal pages is " + pageAuthList.size());
      return pageAuthList;
   }

   private List<ComponentAuthorization> createComponentAuthorizations(final String page) {
      LOG.debug("Bepaal component autorisaties voor " + page);
      String sql = "SELECT aobj.ID, aobj.TYPE, aobj.NAAM," +
                        " RTRIM(XMLAGG(XMLELEMENT(E,adg.GROUP_NAME,',').EXTRACT('//text()')" +
                        " ORDER BY adg.GROUP_NAME).GetClobVal(),',') AS GROUP_NAMES\r\n" +
            "      FROM (SELECT t1.*\r\n" +
            "              FROM PPLS_PWS00.PWS_AUTH_OBJECT t1\r\n" +
            "         LEFT JOIN PPLS_PWS00.PWS_AUTH_OBJECT t2 ON t2.id = t1.parent_id\r\n" +
            "        START WITH t1.id = (SELECT ID\r\n" +
            "                              FROM PPLS_PWS00.PWS_AUTH_OBJECT\r\n" +
            "                             WHERE NAAM = ?\r\n" +
            "                               AND TYPE = 'MNU'\r\n" +
            "                               AND HIS_TS_END = TO_TIMESTAMP('99991231', 'YYYYMMDD')\r\n" +
            "                            )\r\n" +
            "           CONNECT BY PRIOR t1.id = t1.parent_id\r\n" +
            "           ) aobj\r\n" +
            "       INNER JOIN PPLS_PWS00.PWS_AUTH_INFO aut ON aut.AOBJ_ID = aobj.ID    " +
                       "AND aut.HIS_TS_END =  TO_TIMESTAMP('99991231', 'YYYYMMDD')\r\n" +
            "       INNER JOIN PPLS_PWS00.PWS_AD_GROUPS adg ON adg.ID      = aut.ADG_ID " +
                       "AND adg.HIS_TS_END =  TO_TIMESTAMP('99991231', 'YYYYMMDD')\r\n" +
            "       WHERE aobj.TYPE <> 'MNU'\r\n" +
            "       GROUP BY aobj.ID, aobj.TYPE, aobj.NAAM";

      List<ComponentAuthorization> compAuthList = new ArrayList<>();

      try (Connection conn = getDataSource().getConnection();
            PreparedStatement prepStmt = conn.prepareStatement(sql)) {

         prepStmt.setString(1, page);
         try (ResultSet rs = prepStmt.executeQuery()) {
            while (rs.next()) {
               String naam = rs.getString("NAAM");
               AuthorizationType type = AuthorizationType.valueOf(rs.getString("TYPE"));
               String roles = rs.getString("GROUP_NAMES");
               LOG.debug("Add component " + naam + ", type=" + type + ", rollen=" + roles);

               compAuthList.add(ComponentAuthorization.create(naam, type, page, roles.split(",")));
            }
         }
      } catch (Exception e) {
         throw new BackendException(MSG_INTERNALERR, e);
      }
      LOG.debug("Aantal componenten is " + compAuthList.size());
      return compAuthList;
   }


   private String getUrlPrefix() {
      VaadinServletRequest request = getRequest();
      String schema = request.getScheme();
      String serverName = request.getServerName();
      int serverPort = request.getServerPort();
      return schema + "://" + serverName + ":" + serverPort + getMenuContextRoot();
   }

   private Set<String> getAuthorizationGroups(final String objectType, final String objectName, final String menuName) {
      LOG.debug(String.format("Bepaal autorisatie groepen voor type %s, object %s, %s", objectType, objectName,
            menuName));
      Set<String> groups = new HashSet<>();
      String sqlCall = "{ ? = call PPLS_PWS00.GET_OBJECT_GROUPS(?,?,?) }";
      try (Connection conn = getDataSource().getConnection();
           CallableStatement callStmt = conn.prepareCall(sqlCall)) {

         callStmt.registerOutParameter(1, OracleTypes.CURSOR);
         callStmt.setString(2, objectType);
         callStmt.setString(3, objectName);
         callStmt.setString(4, menuName);
         callStmt.execute();

         try (ResultSet rs = (ResultSet) callStmt.getObject(1)) {
            while (rs.next()) {
               groups.add(rs.getString(1));
            }
         }
      } catch (Exception e) {
         throw new BackendException(MSG_INTERNALERR, e);
      }
      LOG.debug("Aantal groepen is " + groups.size());
      return groups;
   }

   public List<String> getADGroups() {
      LOG.debug("Haal AD Groepen op");
      List<String> adGroups = new ArrayList<>();
      String sql = "SELECT ADG.GROUP_NAME FROM PWS_AD_GROUPS adg WHERE ADG.HIS_TS_END = DATE '9999-12-31' ORDER BY 1";
      try (Connection conn = getDataSource().getConnection();
           PreparedStatement adGroupStmt = conn.prepareStatement(sql);
           ResultSet rs = adGroupStmt.executeQuery()) {

         while (rs.next()) {
            adGroups.add(rs.getString(1));
         }
      } catch (Exception e) {
         throw new BackendException(MSG_INTERNALERR, e);
      }
      return adGroups;
   }

   public int getAppiId(String programId, String envName, String instanceName, String prgRelease) {
      int appiId = 0;
      String release = prgRelease == null ? null : prgRelease.replace("-SNAPSHOT", "");
      String melding = String.format(
            "Bepaal appiId voor programId %s, envName %s, instance %s, release %s",
            programId, envName, instanceName, release
      );
      LOG.debug("Bepaal " + melding);
      String sqlCall = "{ ? = call PPLS_PWS00.GET_APPI_ID(?, ?, ?, ?) }";
      try (Connection conn = getDataSource().getConnection(); CallableStatement callStmt = conn.prepareCall(sqlCall)) {
         callStmt.registerOutParameter(1, java.sql.Types.VARCHAR);
         callStmt.setString(2, programId);
         callStmt.setString(3, envName);
         callStmt.setString(4, instanceName);
         callStmt.setString(5, release);
         callStmt.execute();

         appiId = callStmt.getInt(1);
      } catch (Exception e) {
         throw new BackendException(MSG_INTERNALERR, e);
      }
      LOG.debug("AppiId: " + appiId);
      return appiId;
   }

   public String getDatabaseName() {
      String databaseName = "";
      try (Connection conn = getDataSource().getConnection()) {
         databaseName = conn.getMetaData().getURL();
      } catch (Exception e) {
         throw new BackendException(MSG_INTERNALERR, e);
      }
      return databaseName;
   }

   private static final String getDSName() {
      String datasourceName = getStringFromContext(ENV_AUTH_DATASOURCE, null);
      if (datasourceName == null) {
         throw new BackendException("Naam voor datasource is niet gevonden: " + ENV_AUTH_DATASOURCE);
      }
      return datasourceName;
   }

   private static final String getMenuContextRoot() {
      if (menuContextRoot == null) {
         menuContextRoot = getStringFromContext(ENV_MENU_CONTEXTROOT, MENU_CONTEXTROOT);
      }
      return menuContextRoot;
   }

   private VaadinServletRequest getRequest() {
      return mockRequest != null ? mockRequest : VaadinServletRequest.getCurrent();
   }

   /**
    * Test function to mock a servlet request
    * @param request
    */
   protected static void setMockRequest(VaadinServletRequest request) {
      mockRequest = request;
   }

}
