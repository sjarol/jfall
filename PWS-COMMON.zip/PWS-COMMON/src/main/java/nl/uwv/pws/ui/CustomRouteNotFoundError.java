package nl.uwv.pws.ui;

import com.vaadin.flow.router.*;

import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

@ParentLayout(MainLayout.class)
public class CustomRouteNotFoundError extends RouteNotFoundError {
   private static final Logger LOG = LogManager.getLogger(CustomRouteNotFoundError.class);

   public CustomRouteNotFoundError() {
      LOG.warn("Verkeerde route");
   }

   @Override
   public int setErrorParameter(final BeforeEnterEvent event, final ErrorParameter<NotFoundException> parameter) {
      LOG.warn("RouteNotFoundError: " + parameter.getException().getMessage());
      LOG.info("Available routes:");
      for (RouteData route : RouteConfiguration.forApplicationScope().getAvailableRoutes()) {
         LOG.info("- " + route.getUrl());
      }
      event.rerouteTo("");
      return HttpServletResponse.SC_ACCEPTED;
   }
}
