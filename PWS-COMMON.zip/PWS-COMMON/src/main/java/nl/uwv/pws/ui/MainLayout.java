package nl.uwv.pws.ui;

import java.util.List;
import java.util.Optional;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.HasElement;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.dependency.JsModule;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.page.Push;
import com.vaadin.flow.component.page.Viewport;
import com.vaadin.flow.router.AfterNavigationEvent;
import com.vaadin.flow.router.AfterNavigationObserver;
import com.vaadin.flow.router.BeforeEnterEvent;
import com.vaadin.flow.router.BeforeEnterObserver;
import com.vaadin.flow.router.RouterLayout;
import com.vaadin.flow.server.InitialPageSettings;
import com.vaadin.flow.server.PWA;
import com.vaadin.flow.server.PageConfigurator;
import com.vaadin.flow.server.VaadinServletRequest;
import com.vaadin.flow.server.VaadinSession;
import com.vaadin.flow.theme.Theme;
import com.vaadin.flow.theme.lumo.Lumo;

import nl.uwv.pws.backend.dao.PageAuthorization;
import nl.uwv.pws.backend.dao.User;
import nl.uwv.pws.backend.service.AuthorizationService;
import nl.uwv.pws.backend.service.UniqueSessionManager;
import nl.uwv.pws.backend.service.UserService;
import nl.uwv.pws.ui.components.FlexBoxLayout;
import nl.uwv.pws.ui.components.navigation.bar.AppBar;
import nl.uwv.pws.ui.components.navigation.bar.TabBar;
import nl.uwv.pws.ui.components.navigation.drawer.NaviDrawer;
import nl.uwv.pws.ui.components.navigation.drawer.NaviItem;
import nl.uwv.pws.ui.components.navigation.drawer.NaviMenu;
import nl.uwv.pws.ui.util.UIUtils;
import nl.uwv.pws.ui.util.css.Overflow;
import nl.uwv.pws.ui.views.Dashboard;
import nl.uwv.pws.ui.views.DuplicateLoginView;
import nl.uwv.pws.ui.views.LoginView;
import nl.uwv.pws.ui.views.NotAuthorizedView;

@CssImport(value = "./styles/components/floating-action-button.css", themeFor = "vaadin-button")
@CssImport(value = "./styles/components/grid.css", themeFor = "vaadin-grid")
@CssImport("./styles/lumo/border-radius.css")
@CssImport("./styles/lumo/icon-size.css")
@CssImport("./styles/lumo/margin.css")
@CssImport("./styles/lumo/padding.css")
@CssImport("./styles/lumo/shadow.css")
@CssImport("./styles/lumo/spacing.css")
@CssImport("./styles/lumo/typography.css")
@CssImport("./styles/misc/box-shadow-borders.css")
@CssImport(value = "./styles/styles.css", include = "lumo-badge")
@JsModule("@vaadin/vaadin-lumo-styles/badge")
@JsModule("@vaadin/vaadin-lumo-styles/presets/compact.js")
@PWA(name = "pws", shortName = "polis-webschermen", iconPath = "images/logo-uwv-18.png")
@Viewport("width=device-width, minimum-scale=1.0, initial-scale=1.0, user-scalable=yes")
@Theme(Lumo.class)
@Push
public class MainLayout extends FlexBoxLayout
      implements RouterLayout, PageConfigurator, AfterNavigationObserver, BeforeEnterObserver {

   private static final Logger LOG = LogManager.getLogger(MainLayout.class);
   private static final String CLASS_NAME = "root";

   private static final boolean NAVIGATION_TABS = false;

   private NaviDrawer naviDrawer;
   private FlexBoxLayout column;

   private Div appHeaderInner;
   private FlexBoxLayout viewContainer;

   private TabBar tabBar;
   private AppBar appBar;

   public MainLayout() {
      VaadinSession.getCurrent().setErrorHandler(errorEvent -> UIUtils.handleError(errorEvent.getThrowable()));

      super.addClassName(CLASS_NAME);
      super.setFlexDirection(FlexDirection.COLUMN);
      super.setSizeFull();

      // Initialise the UI building blocks
      initStructure();

      // Populate the navigation drawer
      initNaviItems();

      // Configure the headers and footers (optional)
      initHeaders();
   }

   /**
    * Initialise the required components and containers.
    */
   private void initStructure() {
      naviDrawer = new NaviDrawer();

      viewContainer = new FlexBoxLayout();
      viewContainer.addClassName(CLASS_NAME + "__view-container");
      viewContainer.setOverflow(Overflow.HIDDEN);

      column = new FlexBoxLayout(viewContainer);
      column.addClassName(CLASS_NAME + "__column");
      column.setFlexDirection(FlexDirection.COLUMN);
      column.setFlexGrow(1, viewContainer);
      column.setOverflow(Overflow.HIDDEN);

      FlexBoxLayout row = new FlexBoxLayout(naviDrawer, column);
      row.addClassName(CLASS_NAME + "__row");
      row.setFlexGrow(1, column);
      row.setOverflow(Overflow.HIDDEN);
      add(row);
      setFlexGrow(1, row);
   }

   /**
    * Initialise the navigation items.
    */
   private void initNaviItems() {
      NaviMenu menu = naviDrawer.getMenu();

      User loggedUser = UserService.getCurrentUser();
      if (loggedUser != null) {
         List<PageAuthorization> authorizedPages = AuthorizationService.get().getAuthorizedPages(loggedUser);
         authorizedPages.forEach(page -> menu.addNaviItem(
               UIUtils.getVaadinIcon(page.getIconName()),
               page.getName(),
               page.getUrl()
         ));
      }
      naviDrawer.toggle();
   }

   /**
    * Configure the app's inner and outer headers.
    */
   private void initHeaders() {
      // Default inner header setup:
      // - When using tabbed navigation the view title, user avatar and main menu button will appear in the TabBar.
      // - When tabbed navigation is turned off they appear in the AppBar.

      appBar = new AppBar();

      // Tabbed navigation
      if (NAVIGATION_TABS) {
         tabBar = new TabBar();
         UIUtils.setTheme(Lumo.DARK, tabBar);

         // Shift-click to add a new tab
         for (NaviItem item : naviDrawer.getMenu().getNaviItems()) {
            item.addClickListener(e -> {
               if (e.getButton() == 0 && e.isShiftKey()) {
                  tabBar.setSelectedTab(tabBar.addClosableTab(item.getText(), item.getNavigationTarget()));
               }
            });
         }
         appBar.getAvatar().setVisible(false);
         setAppHeaderInner(tabBar, appBar);

         // Default navigation
      } else {
         UIUtils.setTheme(Lumo.DARK, appBar);
         setAppHeaderInner(appBar);
      }
   }

   private void setAppHeaderInner(final Component... components) {
      if (appHeaderInner == null) {
         appHeaderInner = new Div();
         appHeaderInner.addClassName("app-header-inner");
         column.getElement().insertChild(0, appHeaderInner.getElement());
      }
      appHeaderInner.removeAll();
      appHeaderInner.add(components);
   }

   @Override
   public void configurePage(final InitialPageSettings settings) {
      settings.addMetaTag("apple-mobile-web-app-capable", "yes");
      settings.addMetaTag("apple-mobile-web-app-status-bar-style", "black");
   }

   @Override
   public void showRouterLayoutContent(final HasElement content) {
      this.viewContainer.getElement().appendChild(content.getElement());
   }

   public NaviDrawer getNaviDrawer() {
      return naviDrawer;
   }

   public static MainLayout get() {
      return (MainLayout) UI.getCurrent().getChildren().filter(component -> component.getClass() == MainLayout.class)
            .findFirst().orElse(null);
   }

   public AppBar getAppBar() {
      return appBar;
   }

   @Override
   public void beforeEnter(final BeforeEnterEvent event) {
      String remoteUser = VaadinServletRequest.getCurrent().getRemoteUser();

      if (remoteUser == null) {
         LOG.warn("Redirect: Geen remote user");
         rerouteToLogin(event);
      } else if (VaadinSession.getCurrent() == null || VaadinSession.getCurrent().getSession() == null) {
         LOG.warn("Redirect: Geen sessie");
         rerouteToLogin(event);
      } else {
         User loggedUser = UserService.getCurrentUser();
         if (loggedUser == null) {
            Optional<User> user = UserService.get().login(remoteUser);
            if (!user.isPresent()) {
               LOG.warn("Redirect: User heeft geen autorisatie voor de applicatie");
               rerouteToNotAuthorized(event);
               return;
            }
         }
         if (!UniqueSessionManager.get().isActiveSession(remoteUser)) {
            LOG.warn("Redirect: User heeft al een sessie voor de applicatie");
            rerouteToDuplicateLogin(event);
         }
      }
   }

   private void rerouteToLogin(final BeforeEnterEvent event) {
      event.rerouteTo(LoginView.class);
   }

   private void rerouteToDuplicateLogin(final BeforeEnterEvent event) {
      event.rerouteTo(DuplicateLoginView.class);
   }

   private void rerouteToNotAuthorized(final BeforeEnterEvent event) {
      event.rerouteTo(NotAuthorizedView.class);
   }

   @Override
   public void afterNavigation(final AfterNavigationEvent event) {
      if (NAVIGATION_TABS) {
         afterNavigationWithTabs(event);
      }
   }

   private void afterNavigationWithTabs(final AfterNavigationEvent e) {
      NaviItem active = getActiveItem(e);
      if (active == null) {
         if (tabBar.getTabCount() == 0) {
            tabBar.addClosableTab("", Dashboard.class);
         }
      } else {
         if (tabBar.getTabCount() > 0) {
            tabBar.updateSelectedTab(active.getText(),
                  active.getNavigationTarget());
         } else {
            tabBar.addClosableTab(active.getText(),
                  active.getNavigationTarget());
         }
      }
      appBar.getMenuIcon().setVisible(false);
   }

   private NaviItem getActiveItem(final AfterNavigationEvent e) {
      for (NaviItem item : naviDrawer.getMenu().getNaviItems()) {
         if (item.isHighlighted(e)) {
            return item;
         }
      }
      return null;
   }
}
