package nl.uwv.pws.ui.components;

import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.orderedlayout.FlexLayout;
import com.vaadin.flow.theme.lumo.Lumo;

import nl.uwv.pws.ui.util.css.BorderRadius;
import nl.uwv.pws.ui.util.css.BoxSizing;
import nl.uwv.pws.ui.util.css.Display;
import nl.uwv.pws.ui.util.css.Overflow;
import nl.uwv.pws.ui.util.css.Position;
import nl.uwv.pws.ui.util.css.Shadow;
import nl.uwv.pws.ui.layout.size.Size;

import java.util.ArrayList;

public class FlexBoxLayout extends FlexLayout {

   public static final String BACKGROUND_COLOR = "background-color";
   public static final String BORDER_RADIUS = "border-radius";
   public static final String BOX_SHADOW = "box-shadow";
   public static final String BOX_SIZING = "box-sizing";
   public static final String DISPLAY = "display";
   public static final String FLEX_DIRECTION = "flex-direction";
   public static final String FLEX_WRAP = "flex-wrap";
   public static final String MAX_WIDTH = "max-width";
   public static final String OVERFLOW = "overflow";
   public static final String POSITION = "position";

   private final ArrayList<Size> spacings;

   public FlexBoxLayout(final Component... components) {
      super(components);
      spacings = new ArrayList<>();
   }

   public final void setBackgroundColor(final String value) {
      getStyle().set(BACKGROUND_COLOR, value);
   }

   public final void setBackgroundColor(final String value, final String theme) {
      getStyle().set(BACKGROUND_COLOR, value);
      setTheme(theme);
   }

   public final void removeBackgroundColor() {
      getStyle().remove(BACKGROUND_COLOR);
   }

   public final void setBorderRadius(final BorderRadius radius) {
      getStyle().set(BORDER_RADIUS, radius.getValue());
   }

   public final void removeBorderRadius() {
      getStyle().remove(BORDER_RADIUS);
   }

   public final void setBoxSizing(final BoxSizing sizing) {
      getStyle().set(BOX_SIZING, sizing.getValue());
   }

   public final void removeBoxSizing() {
      getStyle().remove(BOX_SIZING);
   }

   public final void setDisplay(final Display display) {
      getStyle().set(DISPLAY, display.getValue());
   }

   public final void removeDisplay() {
      getStyle().remove(DISPLAY);
   }

   public final void setCssFlex(final String value, final Component... components) {
      for (Component component : components) {
         component.getElement().getStyle().set("flex", value);
      }
   }

   public final void setCssFlexBasis(final String value, final Component... components) {
      for (Component component : components) {
         component.getElement().getStyle().set("flex-basis", value);
      }
   }

   public final void setCssFlexDirection(final nl.uwv.pws.ui.util.css.FlexDirection direction) {
      getStyle().set(FLEX_DIRECTION, direction.getValue());
   }

   public final void removeCssFlexDirection() {
      getStyle().remove(FLEX_DIRECTION);
   }

   public final void setCssFlexShrink(final String value, final Component... components) {
      for (Component component : components) {
         component.getElement().getStyle().set("flex-shrink", value);
      }
   }

   public final void setCssFlexWrap(final nl.uwv.pws.ui.util.css.FlexWrap wrap) {
      getStyle().set(FLEX_WRAP, wrap.getValue());
   }

   public final void removeCssFlexWrap() {
      getStyle().remove(FLEX_WRAP);
   }

   public final void setMargin(final Size... sizes) {
      for (Size size : sizes) {
         for (String attribute : size.getMarginAttributes()) {
            getStyle().set(attribute, size.getVariable());
         }
      }
   }

   public final void removeMargin() {
      getStyle().remove("margin");
      getStyle().remove("margin-bottom");
      getStyle().remove("margin-left");
      getStyle().remove("margin-right");
      getStyle().remove("margin-top");
   }

   @Override
   public final void setMaxWidth(final String value) {
      getStyle().set(MAX_WIDTH, value);
   }

   public final void removeMaxWidth() {
      getStyle().remove(MAX_WIDTH);
   }

   public final void setOverflow(final Overflow overflow) {
      getStyle().set(OVERFLOW, overflow.getValue());
   }

   public final void removeOverflow() {
      getStyle().remove(OVERFLOW);
   }

   public final void setPadding(final Size... sizes) {
      removePadding();
      for (Size size : sizes) {
         for (String attribute : size.getPaddingAttributes()) {
            getStyle().set(attribute, size.getVariable());
         }
      }
   }

   public final void removePadding() {
      getStyle().remove("padding");
      getStyle().remove("padding-bottom");
      getStyle().remove("padding-left");
      getStyle().remove("padding-right");
      getStyle().remove("padding-top");
   }

   public final void setPosition(final Position position) {
      getStyle().set(POSITION, position.getValue());
   }

   public final void removePosition() {
      getStyle().remove(POSITION);
   }

   public final void setShadow(final Shadow shadow) {
      getStyle().set(BOX_SHADOW, shadow.getValue());
   }

   public final void removeShadow() {
      getStyle().remove(BOX_SHADOW);
   }

   public final void setSpacing(final Size... sizes) {
      // Remove old styles (if applicable)
      for (Size spacing : spacings) {
         removeClassName(spacing.getSpacingClassName());
      }
      spacings.clear();

      // Add new
      for (Size size : sizes) {
         addClassName(size.getSpacingClassName());
         spacings.add(size);
      }
   }

   public final void setTheme(final String theme) {
      if (Lumo.DARK.equals(theme)) {
         getElement().setAttribute("theme", "dark");
      } else {
         getElement().removeAttribute("theme");
      }
   }
}
