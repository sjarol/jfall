package nl.uwv.pws.backend.types;

import org.apache.commons.lang3.StringUtils;

import nl.uwv.pws.backend.dao.BackendException;
import nl.uwv.pws.ui.util.UIUtils;

import java.io.Serializable;
import java.sql.Clob;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Timestamp;

public class Field implements FieldProperty, Serializable {

   private final String name;
   private final String type;
   private final String label;

   private final FieldAttributes attributes;

   public Field(final String name, final String type) {
      this(name, type, "", "");
   }

   public Field(final String name, final String label, final String attributes) {
      this(name, "", label, attributes);
   }

   public Field(final String name, final String type, final String label, final String attributes) {
      this.name = name;
      this.type = type;
      this.label = label;
      this.attributes = new StringAttributes(attributes);
   }

   @Override
   public String getFormattedValue(final Object value) {
      if (value == null) {
         return null;
      }
      if (value instanceof Date) {
         String formatted = null;
         Date sqlDate = (Date) value;
         formatted = UIUtils.formatDate(sqlDate.toLocalDate());
         return withPrefix(formatted);
      }
      if (value instanceof Timestamp) {
         String formatted = null;
         Timestamp ts = (Timestamp) value;
         if (StringUtils.equals(type, "date")) {
            formatted = UIUtils.formatDate(ts.toLocalDateTime().toLocalDate());
         } else if (StringUtils.equals(type, "datetime")) {
            formatted = UIUtils.formatDateTime(ts.toLocalDateTime());
         } else {
            formatted = UIUtils.formatTimestamp(ts);
         }
         return withPrefix(formatted);
      }
      if (value instanceof Clob) {
         return withPrefix(getClobValue((Clob) value));
      }
      return withPrefix(value.toString());
   }

   private String getClobValue(final Clob clob) {
      if (clob != null) {
         try {
            return clob.getSubString(1, (int) clob.length());
         } catch (SQLException e) {
            throw new BackendException("Fout bij ophalen CLOB kolom.", e);
         }
      }
      return null;
   }

   private String withPrefix(final String s) {
      if (attributes.isPrefix()) {
         return getName() + ":" + getType() + ":" + s;
      }
      return s;
   }

   @Override
   public String getName() {
      return name;
   }

   @Override
   public String getType() {
      if (!StringUtils.isEmpty(type)) {
         return type;
      }
      if (!StringUtils.isEmpty(attributes.getType())) {
         return attributes.getType();
      }
      return "String";
   }

   @Override
   public String getLabel() {
      if (StringUtils.isEmpty(label)) {
         return getName().toUpperCase();
      }
      return label;
   }

   @Override
   public String getWidth() {
      return attributes.getWidth();
   }

   @Override
   public int getFlexGrow() {
      return attributes.getFlexGrow();
   }

   @Override
   public boolean isSortable() {
      return attributes.isSortable();
   }

   @Override
   public String getProperty() {
      return attributes.getProperty();
   }

   String getPropertyWithDefault(final String defaultProperty) {
      if (StringUtils.isEmpty(getProperty())) {
         return defaultProperty;
      }
      return getProperty();
   }

   @Override
   public boolean isHidden() {
      return attributes.isHidden();
   }

   @Override
   public boolean usePlain() {
      return attributes.usePlain();
   }

   @Override
   public FieldDescription getFieldDescription() {
      return attributes.getFieldDescription();
   }

   @Override
   public String toString() {
      return "Field{" + getName() +
            "|" + getType() +
            "|" + getLabel() +
            "|" + getProperty() +
            "|" + getWidth() +
            "|" + attributes +
            '}';
   }
}
