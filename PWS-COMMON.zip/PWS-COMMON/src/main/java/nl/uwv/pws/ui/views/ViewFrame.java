package nl.uwv.pws.ui.views;

import java.util.concurrent.atomic.AtomicBoolean;

import com.vaadin.flow.component.AttachEvent;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.Composite;
import com.vaadin.flow.component.HasStyle;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;

import nl.uwv.pws.backend.dao.MenuPage;
import nl.uwv.pws.ui.MainLayout;
import nl.uwv.pws.ui.util.ComponentAuthorizationHelper;
import nl.uwv.pws.ui.util.ViewAuthorizationHelper;

/**
 * A view frame that establishes app design guidelines. It consists of three
 * parts:
 * <ul>
 * <li>Topmost {@link #setViewHeader(Component...) header}</li>
 * <li>Center {@link #setViewContent(Component...) content}</li>
 * <li>Bottom {@link #setViewFooter(Component...) footer}</li>
 * </ul>
 * <p>
 *   Bij gebruik van de PageMenuCode annotatie moet de pagina ook de interface HasDynamicTitle gebruiken.
 *   De annotatie PageTitle mag dan niet meer gebruikt worden.
 * </P>
 */
@CssImport("./styles/components/view-frame.css")
public class ViewFrame extends Composite<Div> implements HasStyle {
   private static final String CLASS_NAME = "view-frame";

   private final Div header = new Div();
   private final Div content = new Div();
   private final Div footer = new Div();
   private final AtomicBoolean onAttachViewCalled = new AtomicBoolean();

   private boolean dialogMode = false;
   private ViewFrame parent = null;

   @SuppressWarnings("java:S1699") // Call to overridable method setClassName from constructor
   public ViewFrame() {
      setClassName(CLASS_NAME);

      header.setClassName(CLASS_NAME + "__header");
      content.setClassName(CLASS_NAME + "__content");
      footer.setClassName(CLASS_NAME + "__footer");

      super.getContent().add(header, content, footer);
   }

   /**
    * Use ViewFrame in dialog mode:
    * - Do not reset MainLayout
    * - Use parent for component authorization instead of Page annotation
    *
    * @param parent The parent ViewFrame that will be used for authorization of Page annotation.
    */
   public ViewFrame(final ViewFrame parent) {
      this();
      dialogMode = true;
      this.parent = parent;
   }

   /**
    * Sets the header slot's components.
    */
   public void setViewHeader(final Component... components) {
      header.removeAll();
      header.add(components);
   }

   /**
    * Sets the content slot's components.
    */
   public void setViewContent(final Component... components) {
      content.removeAll();
      content.add(components);
   }

   /**
    * Sets the footer slot's components.
    */
   public void setViewFooter(final Component... components) {
      footer.removeAll();
      footer.add(components);
   }

   /**
    * Makes sure the user is authorized to access this View and its components. Note that we have made this method final
    * to make sure you cannot accidentally override this method and forget to call the super implementation thereby
    * removing all authorization checks.
    * <p>
    * If your subclass has something to do when the view is attached, override the method {@link #onAttachView} instead.
    * If your subclass needs to disable authorisation checks (for instance on public pages or from unit-tests), you must
    * explicitly override the {@link #authorize} method.
    *
    * @param attachEvent The AttachEvent we got from the Vaadin framework.
    */
   @Override
   protected final void onAttach(final AttachEvent attachEvent) {
      // Methode final gemaakt om te voorkomen dat subclasses per ongeluk vergeten super.onAttach(...) aan te roepen en
      // daarmee de authorisatie per ongeluk uitschakelen. Subclasses kunnen nu onAttachView(...) aanroepen en als ze
      // expliciet authorisatie willen onderdukken, bijvoorbeeld op publieke pagina's of in unit-tests, dan kunnen ze
      // de authorize() methode overriden
      if (onAttachViewCalled.get()) {
         throw new IllegalStateException("onAttach called from within onAttachView");
      } else {
         onAttachViewCalled.set(true);
         onAttachView(attachEvent);
      }
      onAttachViewCalled.set(false);
      authorize();
   }

   /**
    * Method that will be called by the {@link #onAttach} method to allow subclasses to provide initialization code
    * to execute when the view is attached.
    *
    * @param attachEvent The AttachEvent we got from the Vaadin framework.
    */
   protected void onAttachView(final AttachEvent attachEvent) {
      // Subclasses kunnen hier hun eigen implementatie voor aanbieden
   }

   /**
    * Performs authorization of the View and its components. This will be called from {@link #onAttach} and can be
    * overridden to skip authorization in case you're building a public page or require a different form of
    * authorization.
    */
   protected void authorize() {
      if (dialogMode) {
         ComponentAuthorizationHelper.checkAutorizedComponents(parent);
      } else {
         ViewAuthorizationHelper.checkAuthorized(this);
         ComponentAuthorizationHelper.checkAutorizedComponents(this);
         MainLayout mainLayout = MainLayout.get();
         MenuPage menuPage = mainLayout == null ? null : ViewAuthorizationHelper.getMenuPage(this);
         if (menuPage != null) {
            mainLayout.getAppBar().setMenuPage(menuPage);
         }
      }
   }

   public String getPageTitle() {
      MainLayout mainLayout = MainLayout.get();
      return mainLayout == null ? "" : mainLayout.getAppBar().getPageTitle();
   }
}
