package nl.uwv.pws.ui.components;

import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import nl.uwv.pws.ui.util.UIUtils;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Locale;

public class DateTimePickerZSM extends com.vaadin.flow.component.datetimepicker.DateTimePicker {
   private static final int NOW_BUTTON_MINUTES = 4;

   private final Button btnNow;

   /**
    * @see com.vaadin.flow.component.datetimepicker.DateTimePicker
    * Basis implementatie met Now button.
    */
   public DateTimePickerZSM() {
      super.setLocale(Locale.forLanguageTag("nl"));
      super.setDatePlaceholder("dd-mm-jjjj");
      super.setTimePlaceholder("hh:mm");
      super.setStep(Duration.ofMinutes(1));

      btnNow = UIUtils.createButton("ZSM", ButtonVariant.LUMO_PRIMARY);
      btnNow.addClickListener(event -> setNowDateTimeValue());

      btnNow.getElement().setAttribute("slot", "time-picker");
      super.getElement().appendChild(btnNow.getElement());
   }

   private void setNowDateTimeValue() {
      setValue(LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES).plusMinutes(NOW_BUTTON_MINUTES));
   }

   @Override
   public void setEnabled(final boolean enabled) {
      super.setEnabled(enabled);
      btnNow.setEnabled(enabled);
   }

   /**
    * @param required
    */
   public void setRequired(final Boolean required) {
      super.setRequiredIndicatorVisible(required);
   }

   public void reset() {
      super.clear();
   }
}
