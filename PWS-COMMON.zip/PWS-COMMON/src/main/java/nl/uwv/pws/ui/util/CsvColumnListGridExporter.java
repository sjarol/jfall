package nl.uwv.pws.ui.util;

import java.io.IOException;
import java.util.Collection;

import org.apache.commons.csv.CSVPrinter;

import com.vaadin.flow.component.grid.Grid;

import nl.uwv.pws.backend.desc.FieldDescriptor;
import nl.uwv.pws.backend.types.ColumnList;
import nl.uwv.pws.backend.types.Field;

public class CsvColumnListGridExporter<T> extends AbstractCsvGridExporter<T> {
   private final FieldDescriptor descriptor;

   public CsvColumnListGridExporter(final FieldDescriptor descriptor) {
      if (descriptor == null) {
         throw new IllegalArgumentException("Field descriptor mag niet null zijn!");
      }
      this.descriptor = descriptor;
   }

   protected void printHeader(final CSVPrinter printer, final Collection<Grid.Column<T>> columns) throws IOException {
      for (Field field : descriptor.getFields()) {
         if (!field.isHidden()) {
            printer.print(field.getLabel());
         }
      }
      printer.println();
   }

   protected void printRow(
         final CSVPrinter printer,
         final Collection<Grid.Column<T>> columns,
         final T item) throws IOException {

      for (Field field : descriptor.getFields()) {
         ColumnList data = (ColumnList) item;
         printer.print(field.getFormattedValue(data.getValue(field)));
      }
      printer.println();
   }
}
