package nl.uwv.pws.ui.components.detailsdrawer;

import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.dependency.CssImport;

import nl.uwv.pws.ui.components.FlexBoxLayout;

@CssImport("./styles/components/details-drawer.css")
public class DetailsDrawer extends FlexBoxLayout {
   private static final String CLASS_NAME = "details-drawer";

   private final FlexBoxLayout header;
   private final FlexBoxLayout content;
   private final FlexBoxLayout footer;

   public enum Position {
      BOTTOM, RIGHT
   }

   public DetailsDrawer(final Position position, final Component... components) {
      super.setClassName(CLASS_NAME);
      setDrawerPosition(position);

      header = new FlexBoxLayout();
      header.setClassName(CLASS_NAME + "__header");

      content = new FlexBoxLayout(components);
      content.setClassName(CLASS_NAME + "__content");
      content.setFlexDirection(FlexDirection.COLUMN);

      footer = new FlexBoxLayout();
      footer.setClassName(CLASS_NAME + "__footer");

      super.add(header, content, footer);
   }

   public void setHeader(final Component... components) {
      this.header.removeAll();
      this.header.add(components);
   }

   public FlexBoxLayout getHeader() {
      return this.header;
   }

   public void setContent(final Component... components) {
      this.content.removeAll();
      this.content.add(components);
   }

   public void setFooter(final Component... components) {
      this.footer.removeAll();
      this.footer.add(components);
   }

   public final void setDrawerPosition(final Position position) {
      getElement().setAttribute("position", position.name().toLowerCase());
   }

   public void hide() {
      getElement().setAttribute("open", false);
   }

   public void show() {
      getElement().setAttribute("open", true);
   }
}
