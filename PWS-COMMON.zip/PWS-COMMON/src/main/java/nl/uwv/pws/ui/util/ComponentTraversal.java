package nl.uwv.pws.ui.util;

import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.HasStyle;

import java.util.Optional;
import java.util.stream.Stream;

/**
 * Util class that provides some convenience methods for easily walking through the
 * descendants of a component or for finding specific descendants.
 */
public final class ComponentTraversal {
   private ComponentTraversal() {
      // Do not construct
   }

   /**
    * Searches the direct children of a specific parent component for a child component with the given id.
    * Direct children are children at the first level. This method will not traverse the entire component tree down to
    * the deepest level.
    *
    * @param parent The parent to check the direct child components for.
    * @param id The id of the direct child to find.
    * @param <T> The type of component you expect back.
    * @return An optional that contains the child component with the given id if it could be found.
    */
   @SuppressWarnings("unchecked")
   public static <T extends Component> Optional<T> directChildWithId(final Component parent, final String id) {
      return parent.getChildren()
            .filter(child -> id.equals(child.getId().orElse(null)))
            .map(child -> (T) child)
            .findFirst();
   }

   /**
    * Searches the direct children of a specific parent component for the first direct child component of the given
    * type. Direct children are children at the first level. This method will not traverse the entire component tree
    * down to the deepest level.
    *
    * @param parent The parent to check the direct child components for.
    * @param type The type of the direct child to find.
    * @param <T> The type of component you expect back.
    * @return An optional that contains the first child component of the given type if it could be found.
    */
   @SuppressWarnings("unchecked")
   public static <T extends Component> Optional<T> firstDirectChildOfType(
         final Component parent,
         final Class<? extends Component> type) {
      return parent.getChildren()
            .filter(child -> type.isAssignableFrom(child.getClass()))
            .map(child -> (T) child)
            .findFirst();
   }

   /**
    * Searches the direct children of a specific parent component for the first direct child component of the given
    * type and with the given CSS ClassName. Direct children are children at the first level. This method will not
    * traverse the entire component tree down to the deepest level.
    *
    * @param parent The parent to check the direct child components for.
    * @param type The type of the direct child to find.
    * @param cssClassName The CSS ClassName to search for.
    * @param <T> The type of component you expect back.
    * @return An optional that contains the first child component of the given type if it could be found.
    */
   @SuppressWarnings("unchecked")
   public static <T extends Component> Optional<T> firstDirectChildWithClassName(
         final Component parent,
         final Class<? extends Component> type,
         final String cssClassName) {
      return directChildrenWithClassName(parent, type, cssClassName).map(child -> (T) child).findFirst();
   }

   /**
    * Returns a Stream of a specific parents' direct children of the given component type.
    * Direct children are children at the first level. This method will not traverse the entire component tree
    * down to the deepest level.
    *
    * @param parent The parent to check the direct child components for.
    * @param type The type of the direct children to find.
    * @return A stream of the parents' direct child components of the given type.
    */
   public static Stream<Component> directChildrenOfType(
         final Component parent,
         final Class<? extends Component> type) {
      return parent.getChildren().filter(child -> type.isAssignableFrom(child.getClass()));
   }

   /**
    * Returns a Stream of a specific parents' direct children of the given component type and with
    * the given CSS ClassName. Direct children are children at the first level. This method will not traverse the
    * entire component tree down to the deepest level.
    *
    * @param parent The parent to check the direct child components for.
    * @param type The type of the direct children to find.
    * @param cssClassName The CSS className your looking for.
    * @return A stream of the parents' direct child components of the given type.
    */
   public static Stream<Component> directChildrenWithClassName(
         final Component parent,
         final Class<? extends Component> type,
         final String cssClassName) {
      return directChildrenWithClassName(parent, cssClassName).filter(child -> type.isAssignableFrom(child.getClass()));
   }

   /**
    * Returns a Stream of a specific parents' direct children with the given CSS ClassName.
    * Direct children are children at the first level. This method will not traverse the entire component tree
    * down to the deepest level.
    *
    * @param parent The parent to check the direct child components for.
    * @param cssClassName The CSS className your looking for.
    * @return A stream of the parents' direct child components of the given type.
    */
   public static Stream<Component> directChildrenWithClassName(final Component parent, final String cssClassName) {
      return parent.getChildren()
            .filter(child -> child instanceof HasStyle)
            .filter(child -> ((HasStyle) child).hasClassName(cssClassName));
   }

   /**
    * Returns a Stream of all of the parents' descendants, traversing all the way down the tree.
    *
    * @param parent The parent to find all descendants for.
    * @return A stream of all of the parents' descendants.
    */
   public static Stream<Component> descendants(final Component parent) {
      return parent.getChildren().flatMap(child -> Stream.concat(Stream.of(child), children(child)));
   }

   /**
    * Helper method that returns a stream of a components children and all of their children as well. This is a
    * recursive method that keeps calling itself until all children are included and combined into a single Stream.
    * Searching is performed using pre-order traversal (NLR), see
    * https://www.baeldung.com/cs/depth-first-traversal-methods for more details.
    *
    * @param parent The component to find all descendants for.
    * @return A stream of all of the parents' descendants.
    */
   private static Stream<Component> children(final Component parent) {
      return parent.getChildren().flatMap(child -> Stream.concat(Stream.of(child), children(child)));
   }

   /**
    * Searches through all of the parents' descendants to find a descendant with the given id.
    *
    * @param parent The parent to find the descendant with the specified id for.
    * @return An optional that contains the descendant with the given id if it could be found.
    */
   @SuppressWarnings("unchecked")
   public static <T extends Component> Optional<T> descendantWithId(final Component parent, final String id) {
      return descendants(parent)
            .filter(child -> id.equals(child.getId().orElse(null)))
            .map(child -> (T) child)
            .findFirst();
   }

   /**
    * Searches through all of the parents' descendants to find a descendant with the given id and throws an
    * IllegalStateException if the descendant could not be found.
    *
    * @param parent The parent to find the descendant with the specified id for.
    * @return The descendant with the given id.
    * @throws IllegalStateException If a descendant with the given id could not be found.
    */
   @SuppressWarnings("unchecked")
   public static <T extends Component> T requireDescendantWithId(final Component parent, final String id) {
      return (T) descendantWithId(parent, id).orElseThrow(IllegalStateException::new);
   }

   /**
    * Searches through all of the parents' descendants to find the first descendants of the given type. Searching is
    * performed using pre-order traversal (NLR), see https://www.baeldung.com/cs/depth-first-traversal-methods for more
    * details.
    *
    * @param parent The parent to find the descendants with the specified type for.
    * @return An optional that contains the descendant with the given id if it could be found.
    */
   @SuppressWarnings("unchecked")
   public static <T extends Component> Optional<T> firstDescendantOfType(
         final Component parent,
         final Class<T> type) {
      return descendants(parent)
            .filter(child -> type.isAssignableFrom(child.getClass()))
            .map(child -> (T) child)
            .findFirst();
   }
}
