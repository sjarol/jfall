package nl.uwv.pws.ui.validator;

import com.vaadin.flow.data.binder.ValidationResult;
import com.vaadin.flow.data.binder.ValueContext;
import com.vaadin.flow.data.validator.RegexpValidator;


/**
 * A string validator for excluding keywords. Value is considered valid when none of the keywords is present.
 */
public class ExcludeKeywordValidator extends RegexpValidator {
   private final String errorMessage;

   /**
    * Creates a validator for checking that a string doesn't contain a keyword.
    *
    * @param errorMessage the message to display in case the value does not validate.
    * @param keyWords     The keywords witch are not allowed.
    */
   public ExcludeKeywordValidator(final String errorMessage, final String... keyWords) {
      super(errorMessage, getPattern(keyWords), false);
      this.errorMessage = errorMessage;
   }

   @Override
   public ValidationResult apply(final String value, final ValueContext context) {
      ValidationResult result = super.apply(value == null ? null : value.toUpperCase(), context);

      if (result.isError()) {
         result = ValidationResult.ok();
      } else {
         result = ValidationResult.error(errorMessage);
      }

      return result;
   }

   /**
    * Create the Regular expression to exclude the keywords
    *
    * @param keyWords The keywords to exclude.
    * @return regex pattern
    */
   private static String getPattern(final String... keyWords) {
      if (keyWords == null || keyWords.length == 0) {
         throw new IllegalArgumentException("keyWords are mandatory");
      }
      // ((?!hede).)*
      StringBuilder patternBuilder = new StringBuilder();
      for (String word : keyWords) {
         if (patternBuilder.length() == 0) {
            patternBuilder.append("(");
         } else {
            patternBuilder.append("|");
         }
         patternBuilder.append("\\b").append(word).append("\\b");
      }
      patternBuilder.append(")");

      return patternBuilder.toString();
   }
}
