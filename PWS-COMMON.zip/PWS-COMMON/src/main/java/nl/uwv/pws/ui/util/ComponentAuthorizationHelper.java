package nl.uwv.pws.ui.util;

import java.lang.reflect.Field;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.HasEnabled;
import com.vaadin.flow.router.PageTitle;

import nl.uwv.pws.backend.dao.AuthorizationType;
import nl.uwv.pws.backend.dao.ComponentAuthorization;
import nl.uwv.pws.backend.dao.User;
import nl.uwv.pws.backend.service.AuthorizationService;
import nl.uwv.pws.backend.service.UserService;

public final class ComponentAuthorizationHelper {
   private static final Logger LOG = LogManager.getLogger(ComponentAuthorizationHelper.class);

   private ComponentAuthorizationHelper() {
      // Empty private constructor, utility class
   }

   /**
    * Checks all the fields with AuthorizedComponent annotation, and hides them if User has no authorization. The class
    * should be annotated with AuthorizedView to determine authorization parent object (menu item).
    *
    * @param pageOrDialog or dialog
    */
   public static void checkAutorizedComponents(final Object pageOrDialog) {
      if (pageOrDialog.getClass().isAnnotationPresent(PageTitle.class)) {
         LOG.debug("Check autorisatie voor scherm " + pageOrDialog.getClass().getAnnotation(PageTitle.class).value());
      }
      if (pageOrDialog.getClass().isAnnotationPresent(AuthorizedView.class)) {
         String authPage = pageOrDialog.getClass().getAnnotation(AuthorizedView.class).value();
         LOG.debug("Check autorisatie view/page/menu " + authPage);

         User loggedUser = UserService.getCurrentUser();
         List<ComponentAuthorization> authorizedComponents = AuthorizationService.get()
               .getAuthorizedComponents(authPage, loggedUser);
         LOG.debug("Geautoriseerde componenten:");
         authorizedComponents.forEach(c -> LOG.debug("\t" + c.getTitle()));

         for (Field field : pageOrDialog.getClass().getDeclaredFields()) {
            checkAuthorizedComponent(field, authorizedComponents, pageOrDialog);
         }
      }
   }

   private static void checkAuthorizedComponent(
         final Field field,
         final List<ComponentAuthorization> authorizedComponents,
         final Object pageOrDialog)  {

      if (field.isAnnotationPresent(AuthorizedComponent.class)) {
         String name = field.getAnnotation(AuthorizedComponent.class).value();
         AuthorizationType type = field.getAnnotation(AuthorizedComponent.class).type();

         boolean hasAuthorization = authorizedComponents.stream()
               .anyMatch(c -> name.equals(c.getTitle()) && type == c.getType());
         if (!hasAuthorization) {
            LOG.debug("Geen authorisatie voor " + name);
         }
         setComponentAuthorization(pageOrDialog, field, hasAuthorization);
      }
   }

   @SuppressWarnings({"java:S1941", "java:S1874"}) // Sonar doesn't like reflection
   private static void setComponentAuthorization(
         final Object parent,
         final Field field,
         final boolean hasAuthorization) {
      try {
         boolean isAccessible = field.isAccessible();
         field.setAccessible(true);
         Object component = field.get(parent);
         if (component == null) {
            throw new IllegalStateException(
                  "Field " + field.getName() +
                        " should be initialized with non null value when @AuthorizedComponent is used"
            );
         } else {
            if (!hasAuthorization && component instanceof Component) {
               ((Component) component).setVisible(false);
            }
            if (!hasAuthorization && component instanceof HasEnabled) {
               ((HasEnabled) component).setEnabled(false);
            }
            if (component instanceof HasAuthorization) {
               ((HasAuthorization) component).setAuthorized(hasAuthorization);
            }
         }
         field.setAccessible(isAccessible);
      } catch (IllegalArgumentException | IllegalAccessException e) {
         UIUtils.handleError(e);
      }
   }
}
