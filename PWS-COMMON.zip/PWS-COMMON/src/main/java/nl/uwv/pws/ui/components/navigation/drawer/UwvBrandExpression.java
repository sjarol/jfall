package nl.uwv.pws.ui.components.navigation.drawer;

import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Image;

import nl.uwv.pws.ui.util.UIUtils;

@CssImport("./styles/components/brand-expression.css")
public class UwvBrandExpression extends Div {
   private static final String CLASS_NAME = "brand-expression";
   private static final String UWV_LOGO = "UWV.svg";
   private static final String UWV_ALT_LOGO = "uwvLogo1RGB.svg";
   private static final String SIZE = "48px";

   private Image logo;

   public UwvBrandExpression() {
      super.setClassName(CLASS_NAME);

      logo = new Image(UIUtils.IMG_PATH + UWV_LOGO, "");
      logo.setWidth(SIZE);
      logo.setHeight(SIZE);
      logo.addClassName(CLASS_NAME + "__logo");
      logo.setAlt("UWV logo");

      super.add(logo);
   }

   public void useAlternateLogo() {
      logo = new Image(UIUtils.IMG_PATH + UWV_ALT_LOGO, "");
   }
}
