package nl.uwv.pws.ui.components;

import com.vaadin.flow.component.AttachEvent;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.DetachEvent;
import com.vaadin.flow.component.Html;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.dependency.JavaScript;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Footer;
import com.vaadin.flow.component.html.Header;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static org.apache.commons.lang3.StringUtils.trimToNull;

/**
 * A Tooltip provides additional information about a component when the user hovers over that component. You can either
 * pass a component to work on or make this Tooltip work on its container component.
 * <p>
 * Note: We do not expose a constructor, you'll have to use the Builder instead, which you can create using the
 * {@link #builder} method.
 */
@CssImport("./styles/components/pws-tooltip.css")
@JavaScript("./pws-tooltip.js")
public final class Tooltip extends Div {
   private static final Logger LOG = LoggerFactory.getLogger(Tooltip.class);
   private boolean attached = false;

   private final Component relativeTo;
   private final String header;
   private final String body;
   private final String markup;
   private final String footer;
   private final Anchor anchor;
   private final Position position;

   /**
    * Constructs a new Tooltip component that will be positioned relative to its parent component.
    *
    * @param relativeTo The component that trigger the tooltip on mouse over, null to use parent component of tooltip.
    * @param header     The optional header text to display in the tooltip.
    * @param body       The plain-text body to display in the tooltip (either this or markup must be provided).
    * @param markup     The HTML snippet to display in the tooltip (either this or a plain-text body must be provided).
    * @param footer     The optional footer text to display in the tooltip.
    * @param anchor     The optional anchor on {@link #relativeTo} to point the tip of the tooltip at.
    * @param position   The position of the tooltip relative to the {@link #relativeTo} component.
    */
   private Tooltip(
         final Component relativeTo,
         final String header,
         final String body,
         final String markup,
         final String footer,
         final Anchor anchor,
         final Position position) {
      this.relativeTo = relativeTo;
      this.header = header;
      this.body = body;
      this.markup = markup;
      this.footer = footer;
      this.anchor = anchor;
      this.position = position;

      // Set the primary className for the tooltip
      super.addClassName("pws-tooltip");

      // If the anchor and position are hardcoded, add the right CSS className
      if (anchor != null && position != null) {
         super.addClassName("pws-tooltip-" + position.name().toLowerCase());
      }

      if (header != null) {
         add(createHeaderSection(header));
      }

      if (body != null) {
         add(createBodySection(body));
      }

      if (markup != null) {
         add(createHtmlSection(markup));
      }

      if (footer != null) {
         add(createFooterSection(footer));
      }
   }

   private Header createHeaderSection(final String headerText) {
      Header headerSection = new Header();
      headerSection.setText(headerText);
      return headerSection;
   }

   private Div createBodySection(final String bodyText) {
      Div bodySection = new Div();
      bodySection.setClassName("pws-tooltip-body");
      bodySection.setText(bodyText);
      return bodySection;
   }

   private Html createHtmlSection(final String markup) {
      return new Html("<div class=\"pws-tooltip-markup\">" + markup + "</div>");
   }

   private Footer createFooterSection(final String footerText) {
      Footer footerSection = new Footer();
      footerSection.setText(footerText);
      return footerSection;
   }

   @Override
   protected void onAttach(final AttachEvent attachEvent) {
      LOG.debug("onAttach tooltip...");
      if (attached) {
         return;
      }

      LOG.debug("Attaching tooltip...");
      Component tooltipSource = getComponent();
      if (tooltipSource == null) {
         LOG.warn("Tooltip unable to attach itself to source component: null");
      } else {
         // Initialize the tooltip for the tooltipSource
         getUI().ifPresent(ui -> ui.getPage()
               .executeJs("window.pwsTooltipInit($0,$1,$2,$3)",
                     Tooltip.this.getElement(),
                     anchor == null ? null : anchor.name(),
                     anchor != null && position != null,
                     tooltipSource.getElement()
               )
         );
      }
      attached = true;
   }

   @Override
   protected void onDetach(final DetachEvent detachEvent) {
      LOG.debug("onDetach tooltip...");
   }

   /**
    * Creates a new Tooltip Builder tha can be used to configure and build a Tooltip for a specific component.
    *
    * @return The new Tooltip Builder.
    */
   public static Builder builder() {
      return new Builder();
   }

   /**
    * Returns the source component that triggers this tooltip on mouseover.
    *
    * @return The source component that triggers this tooltip on mouseover.
    */
   public Component getComponent() {
      return relativeTo == null ? getParent().orElse(null) : relativeTo;
   }

   /**
    * Returns the optional header text that will be displayed in the Tooltip or null if no header text is available.
    *
    * @return The optional header text that will be displayed in the Tooltip or null if no header text is available.
    */
   public String getHeader() {
      return header;
   }

   /**
    * Returns the plain-text body that will be displayed in the Tooltip or null if no plain-text body is available.
    *
    * @return The plain-text body that will be displayed in the Tooltip or null if no plain-text body is available.
    */
   public String getBody() {
      return body;
   }

   /**
    * Returns the rich-text markup that will be displayed in the Tooltip or null if no markup is available.
    *
    * @return The rich-text markup that will be displayed in the Tooltip or null if no markup is available.
    */
   public String getMarkup() {
      return markup;
   }

   /**
    * Returns the footer text that will be displayed in the Tooltip or null if no footer text is available.
    *
    * @return The footer text that will be displayed in the Tooltip or null if no footer text is available.
    */
   public String getFooter() {
      return footer;
   }

   /**
    * Returns the optional hard-coded anchor point on the source {@link #getComponent()} that will be used to point the
    * tip of the tooltip towards. Will return null if unspecified (e.g. the anchor point will be dynamically decided in
    * the browser).
    *
    * @return The optional hard-coded anchor point on the {@link #getComponent()} that will be used to point the tip of
    * the tooltip towards or null if unspecified.
    */
   public Anchor getAnchor() {
      return anchor;
   }

   /**
    * Returns the optional hard-coded position of the tooltip relative to the source {@link #getComponent()}. Will
    * return null if unspecified (e.d. the position will be dynamically decided in the browser).
    *
    * @return The optional hard-coded position of the tooltip relative to the source {@link #getComponent()}.
    */
   public Position getPosition() {
      return position;
   }

   /**
    * The possible anchor points on the source component to position the Tooltip.
    * So if you want to show a tooltip for a button, using Anchor.TOP_LEFT will bind the tip of the tooltip to the
    * top-left position of the button.
    */
   public enum Anchor {
      TOP_LEFT, TOP_CENTER, TOP_RIGHT,
      MID_LEFT, MID_RIGHT,
      BOTTOM_LEFT, BOTTOM_CENTER, BOTTOM_RIGHT
   }

   /**
    * The position of the tooltip relative to the source component. If you select RIGHT, the tooltip will be displayed
    * to the right of the component.
    */
   public enum Position {
      TOP, RIGHT, BOTTOM, LEFT
   }

   /**
    * Builder to configure and build the Tooltip for a specific component.
    */
   public static class Builder {
      private Component relativeTo;
      private String header;
      private String footer;
      private String body;
      private String markup;
      private Anchor anchor;
      private Position position;

      /**
       * Sets the component the Tooltip will be shown for when the user hovers over it. If this is not selected, the
       * tooltip will default to its parent component in the markup.
       *
       * @param component The component the tooltip will be shown for.
       * @return The current Builder instance.
       */
      public Builder forComponent(final Component component) {
         this.relativeTo = component;
         return this;
      }

      /**
       * Sets an optional header text to display in the tooltip.
       *
       * @param header The header text to display in the tooltip.
       * @return The current Builder instance.
       */
      public Builder withHeader(final String header) {
         this.header = trimToNull(header);
         return this;
      }

      /**
       * Sets the plain text body for the tooltip. You need to call either this method or {@link #withMarkup} to specify
       * the content for the tooltip.
       *
       * @param body The plain text body for the tooltip.
       * @return The current Builder instance.
       */
      public Builder withBody(final String body) {
         this.body = trimToNull(body);
         return this;
      }

      /**
       * Sets the HTML snippet to display in the tooltip. Use this only if you need rich text, if plain text is enough,
       * use the {@link #withBody} method instead.
       *
       * @param markup The HTML snippet to display in the tooltip.
       * @return The current Builder instance.
       */
      public Builder withMarkup(final String markup) {
         this.markup = trimToNull(markup);
         return this;
      }

      /**
       * Sets an optional footer text to display in the tooltip.
       *
       * @param footer The footer text to display in the tooltip.
       * @return The current Builder instance.
       */
      public Builder withFooter(final String footer) {
         this.footer = trimToNull(footer);
         return this;
      }

      /**
       * Sets the optional anchor to use on the source component to point the tip of the tooltip at. If you set an
       * explicit anchor and position, they will always be used. If you don't set an anchor or position, the tooltip
       * will dynamically position itself based on the space available in the viewport of the users' browser.
       *
       * @param anchor The anchor point on the source component to point the tip of the tooltip at.
       * @return The current Builder instance.
       */
      public Builder withAnchor(final Anchor anchor) {
         this.anchor = anchor;
         return this;
      }

      /**
       * Sets the optional position of the tooltip relative to the source component. If you set an explicit anchor and
       * position, they will always be used. If you don't set an anchor or position, the tooltip will dynamically
       * position itself based on the space available in the viewport of the users' browser.
       *
       * @param position The position of the tooltip relative to the source component.
       * @return The current Builder instance.
       */
      public Builder withPosition(final Position position) {
         this.position = position;
         return this;
      }

      /**
       * Builds the actual tooltip for you to use.
       *
       * @return The newly create Tooltip instance.
       * @throws IllegalArgumentException If you haven't set all required properties yet.
       */
      public Tooltip build() {
         if (body == null && markup == null) {
            throw new IllegalArgumentException("You need to set at least a body or markup for the Tooltip");
         }
         if (body != null && markup != null) {
            throw new IllegalArgumentException(
                  "You need to set either a plain-text body or rich-text markup for the Tooltip, not both"
            );
         }
         return new Tooltip(relativeTo, header, body, markup, footer, anchor, position);
      }
   }
}
