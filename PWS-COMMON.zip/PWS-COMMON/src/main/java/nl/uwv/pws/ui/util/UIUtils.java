package nl.uwv.pws.ui.util;

import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.grid.Grid.SelectionMode;
import com.vaadin.flow.component.grid.GridVariant;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.notification.Notification.Position;
import com.vaadin.flow.component.notification.NotificationVariant;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.component.textfield.TextFieldVariant;
import com.vaadin.flow.data.renderer.Renderer;
import nl.uwv.pws.backend.desc.FieldDescriptor;
import nl.uwv.pws.backend.types.ColumnList;
import nl.uwv.pws.backend.types.Field;
import nl.uwv.pws.backend.types.FieldRenderer;
import nl.uwv.pws.backend.types.PropertyFieldRenderer;
import nl.uwv.pws.ui.components.LabelGrid;
import nl.uwv.pws.ui.components.StyledNotification;
import nl.uwv.pws.ui.util.css.*;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Map;
import java.util.Objects;

@SuppressWarnings("java:S1448") // Too many methods in class
public final class UIUtils {
   private static final Logger LOG = LoggerFactory.getLogger(UIUtils.class);

   private static final String ATTR_LABEL = "aria-label";

   public static final String IMG_PATH = "images/";

   public static final String COLUMN_WIDTH_XS = "80px";
   public static final String COLUMN_WIDTH_S = "120px";
   public static final String COLUMN_WIDTH_M = "160px";
   public static final String COLUMN_WIDTH_L = "200px";
   public static final String COLUMN_WIDTH_XL = "240px";

   /**
    * Thread-unsafe formatters.
    */
   private static final ThreadLocal<DecimalFormat> decimalFormat = ThreadLocal
         .withInitial(() -> new DecimalFormat("###,###,###.00"));
   private static final ThreadLocal<DateTimeFormatter> dateFormat = ThreadLocal
         .withInitial(() -> DateTimeFormatter.ofPattern("dd-MM-uuuu"));
   private static final ThreadLocal<DateTimeFormatter> dateTimeFormat = ThreadLocal
         .withInitial(() -> DateTimeFormatter.ofPattern("dd-MM-uuuu HH:mm:ss"));
   private static final ThreadLocal<DateTimeFormatter> polisDateFormat = ThreadLocal
         .withInitial(() -> DateTimeFormatter.ofPattern("uuuuMMdd"));

   private UIUtils() {
      // Private constructor Utility class
   }

   public static void cleanUp() {
      decimalFormat.remove();
      dateFormat.remove();
      dateTimeFormat.remove();
      polisDateFormat.remove();
   }

   /* ==== GRID === */

   public static <T> Grid<T> createGrid(final String id) {
      Grid<T> grid;
      grid = new Grid<>();
      grid.setId(id);
      grid.setSelectionMode(SelectionMode.NONE);
      grid.setSizeFull();

      // Theme variants
      grid.addThemeVariants(GridVariant.LUMO_COMPACT, GridVariant.LUMO_NO_ROW_BORDERS, GridVariant.LUMO_ROW_STRIPES);
      return grid;
   }

   public static Grid<ColumnList> createGrid(final String id, final FieldDescriptor fieldDesc) {
      Map<String, Renderer<ColumnList>> customRenders = null;
      return createGrid(id, fieldDesc, customRenders);
   }

   public static LabelGrid<ColumnList> createLabelGrid(
         final String label,
         final String id,
         final FieldDescriptor fieldDesc) {
      return new LabelGrid<>(label, createGrid(id, fieldDesc));
   }

   public static LabelGrid<ColumnList> createLabelGrid(
         final String label,
         final String id,
         final FieldDescriptor fieldDesc,
         final Map<String, Renderer<ColumnList>> customRenders) {
      return new LabelGrid<>(label, createGrid(id, fieldDesc, customRenders));
   }

   public static Grid<ColumnList> createGrid(
         final String id,
         final FieldDescriptor fieldDesc,
         final Map<String, Renderer<ColumnList>> customRenders) {
      Grid<ColumnList> grid = createGrid(id);

      FieldRenderer<ColumnList> renderer = new PropertyFieldRenderer<>();
      for (int i = 0; i < fieldDesc.getNrOfColumns(); i++) {
         final Field field = Objects.requireNonNull(fieldDesc.getField(i));
         if (!field.isHidden()) {
            Grid.Column<ColumnList> c;
            if (customRenders != null && customRenders.containsKey(field.getName())) {
               c = grid.addColumn(customRenders.get(field.getName()));
            } else if (field.usePlain()) {
               c = grid.addColumn(renderer.render(field, columnList -> columnList.getValue(field)));
            } else {
               c = grid.addColumn(renderer.render(field, columnList -> columnList.getFormattedValue(field)));
            }
            c.setWidth(field.getWidth())
                  .setHeader(field.getLabel())
                  .setResizable(true)
                  .setFlexGrow(field.getFlexGrow());
            if (i == 0) {
               c.setFrozen(true);
            }
            if (field.isSortable()) {
               c.setSortProperty(field.getName());
            }
         }
      }
      return grid;
   }

   /**
    * Removes current selection and select the first row in Grid
    */
   public static void selectFirstRowInGrid(final Grid<?> grid) {
      grid.deselectAll();
      grid.getElement().getNode().runWhenAttached(ui -> ui.getPage().executeJs(
            "setTimeout(function(){" +
                  "let firstTd = $0.shadowRoot.querySelector('tr:first-child > td:first-child'); firstTd.click(); },0)",
            grid.getElement()
      ));
   }

   /* ==== BUTTONS ==== */

   // Styles

   public static Button createPrimaryButton(final String text) {
      return createButton(text, ButtonVariant.LUMO_PRIMARY);
   }

   public static Button createPrimaryButton(final VaadinIcon icon) {
      return createButton(icon, ButtonVariant.LUMO_PRIMARY);
   }

   public static Button createPrimaryButton(final String text, final VaadinIcon icon) {
      return createButton(text, icon, ButtonVariant.LUMO_PRIMARY);
   }

   public static Button createPrimaryButton(
         final String label,
         final VaadinIcon icon,
         final ComponentEventListener<ClickEvent<Button>> listener) {
      Button button = createPrimaryButton(label, icon);

      if (listener != null) {
         button.addClickListener(listener);
      }
      return button;
   }

   public static Button createTertiaryButton(final String text) {
      return createButton(text, ButtonVariant.LUMO_TERTIARY);
   }

   public static Button createErrorTertiaryButton(final String text) {
      return createButton(text,
            ButtonVariant.LUMO_TERTIARY, ButtonVariant.LUMO_ERROR);
   }

   public static Button createTertiaryButton(final VaadinIcon icon) {
      return createButton(icon, ButtonVariant.LUMO_TERTIARY);
   }

   public static Button createTertiaryButton(final String text, final VaadinIcon icon) {
      return createButton(text, icon, ButtonVariant.LUMO_TERTIARY);
   }

   public static Button createTertiaryInlineButton(final String text) {
      return createButton(text, ButtonVariant.LUMO_TERTIARY_INLINE);
   }

   public static Button createTertiaryInlineButton(final VaadinIcon icon) {
      return createButton(icon, ButtonVariant.LUMO_TERTIARY_INLINE);
   }

   public static Button createTertiaryInlineButton(final String text, final VaadinIcon icon) {
      return createButton(text, icon, ButtonVariant.LUMO_TERTIARY_INLINE);
   }

   public static Button createSuccessButton(final String text) {
      return createButton(text, ButtonVariant.LUMO_SUCCESS);
   }

   public static Button createSuccessButton(final VaadinIcon icon) {
      return createButton(icon, ButtonVariant.LUMO_SUCCESS);
   }

   public static Button createSuccessButton(final String text, final VaadinIcon icon) {
      return createButton(text, icon, ButtonVariant.LUMO_SUCCESS);
   }

   public static Button createSuccessPrimaryButton(final String text) {
      return createButton(text, ButtonVariant.LUMO_SUCCESS, ButtonVariant.LUMO_PRIMARY);
   }

   public static Button createSuccessPrimaryButton(final VaadinIcon icon) {
      return createButton(icon, ButtonVariant.LUMO_SUCCESS, ButtonVariant.LUMO_PRIMARY);
   }

   public static Button createSuccessPrimaryButton(final String text, final VaadinIcon icon) {
      return createButton(text, icon, ButtonVariant.LUMO_SUCCESS, ButtonVariant.LUMO_PRIMARY);
   }

   public static Button createErrorButton(final String text) {
      return createButton(text, ButtonVariant.LUMO_ERROR);
   }

   public static Button createErrorButton(final VaadinIcon icon) {
      return createButton(icon, ButtonVariant.LUMO_ERROR);
   }

   public static Button createErrorButton(final String text, final VaadinIcon icon) {
      return createButton(text, icon, ButtonVariant.LUMO_ERROR);
   }

   public static Button createErrorPrimaryButton(final String text) {
      return createButton(text, ButtonVariant.LUMO_ERROR, ButtonVariant.LUMO_PRIMARY);
   }

   public static Button createErrorPrimaryButton(final VaadinIcon icon) {
      return createButton(icon, ButtonVariant.LUMO_ERROR, ButtonVariant.LUMO_PRIMARY);
   }

   public static Button createErrorPrimaryButton(final String text, final VaadinIcon icon) {
      return createButton(text, icon, ButtonVariant.LUMO_ERROR, ButtonVariant.LUMO_PRIMARY);
   }

   public static Button createContrastButton(final String text) {
      return createButton(text, ButtonVariant.LUMO_CONTRAST);
   }

   public static Button createContrastButton(final VaadinIcon icon) {
      return createButton(icon, ButtonVariant.LUMO_CONTRAST);
   }

   public static Button createContrastButton(final String text, final VaadinIcon icon) {
      return createButton(text, icon, ButtonVariant.LUMO_CONTRAST);
   }

   public static Button createContrastPrimaryButton(final String text) {
      return createButton(text, ButtonVariant.LUMO_CONTRAST, ButtonVariant.LUMO_PRIMARY);
   }

   public static Button createContrastPrimaryButton(final VaadinIcon icon) {
      return createButton(icon, ButtonVariant.LUMO_CONTRAST, ButtonVariant.LUMO_PRIMARY);
   }

   public static Button createContrastPrimaryButton(final String text, final VaadinIcon icon) {
      return createButton(text, icon, ButtonVariant.LUMO_CONTRAST, ButtonVariant.LUMO_PRIMARY);
   }

   // Size
   public static Button createSmallButton(final String text) {
      return createButton(text, ButtonVariant.LUMO_SMALL);
   }

   public static Button createSmallButton(final VaadinIcon icon) {
      return createButton(icon, ButtonVariant.LUMO_SMALL);
   }

   public static Button createSmallButton(final String text, final VaadinIcon icon) {
      return createButton(text, icon, ButtonVariant.LUMO_SMALL);
   }

   public static Button createLargeButton(final String text) {
      return createButton(text, ButtonVariant.LUMO_LARGE);
   }

   public static Button createLargeButton(final VaadinIcon icon) {
      return createButton(icon, ButtonVariant.LUMO_LARGE);
   }

   public static Button createLargeButton(final String text, final VaadinIcon icon) {
      return createButton(text, icon, ButtonVariant.LUMO_LARGE);
   }

   // Text
   public static Button createButton(final String text, final ButtonVariant... variants) {
      Button button = new Button(text);
      button.addThemeVariants(variants);
      button.setClassName("button");
      button.getElement().setAttribute(ATTR_LABEL, text);
      return button;
   }

   public static Button createButton(final String text, final String style, final ButtonVariant... variants) {
      Button button = new Button(text);
      button.addThemeVariants(variants);
      button.setThemeName(style);
      button.getElement().setAttribute(ATTR_LABEL, text);
      return button;
   }

   // Icon
   public static Button createButton(final VaadinIcon icon, final ButtonVariant... variants) {
      Button button = new Button(new Icon(icon));
      button.setClassName("button");
      button.addThemeVariants(variants);
      return button;
   }

   // Text and icon
   public static Button createButton(final String text, final VaadinIcon icon, final ButtonVariant... variants) {
      Icon i = new Icon(icon);
      i.getElement().setAttribute("slot", "prefix");
      Button button = new Button(text, i);
      button.addThemeVariants(variants);
      return button;
   }

   /* ==== TEXTFIELDS ==== */

   public static TextField createSmallTextField() {
      TextField textField = new TextField();
      textField.addThemeVariants(TextFieldVariant.LUMO_SMALL);
      return textField;
   }

   /* ==== LABELS ==== */

   public static Label createLabel(final FontSize size, final TextColor color, final String text) {
      Label label = new Label(text);
      setFontSize(size, label);
      setTextColor(color, label);
      return label;
   }

   public static Label createLabel(final FontSize size, final String text) {
      return createLabel(size, TextColor.BODY, text);
   }

   public static Label createLabel(final TextColor color, final String text) {
      return createLabel(FontSize.M, color, text);
   }

   public static Label createErrorLabel(final String text) {
      Label label = new Label(text);
      setFontSize(FontSize.M, label);
      setTextColor(TextColor.ERROR, label);
      return label;
   }

   public static Label createH1Label(final String text) {
      Label label = new Label(text);
      label.addClassName(LumoStyles.Heading.H1);
      return label;
   }

   public static Label createH2Label(final String text) {
      Label label = new Label(text);
      label.addClassName(LumoStyles.Heading.H2);
      return label;
   }

   public static Label createH3Label(final String text) {
      Label label = new Label(text);
      label.addClassName(LumoStyles.Heading.H3);
      return label;
   }

   public static Label createH4Label(final String text) {
      Label label = new Label(text);
      label.addClassName(LumoStyles.Heading.H4);
      return label;
   }

   public static Label createH5Label(final String text) {
      Label label = new Label(text);
      label.addClassName(LumoStyles.Heading.H5);
      return label;
   }

   public static Label createH6Label(final String text) {
      Label label = new Label(text);
      label.addClassName(LumoStyles.Heading.H6);
      return label;
   }

   /* === MISC === */

   public static HorizontalLayout createHorizontalSeparator() {
      HorizontalLayout separator = new HorizontalLayout();
      separator.setWidthFull();
      separator.getStyle().set("border-bottom", "2px solid #8080802E");
      separator.getStyle().set("margin", "25px 0");

      return separator;
   }

   public static Button createFloatingActionButton(final VaadinIcon icon) {
      Button button = createPrimaryButton(icon);
      button.addThemeName("fab");
      return button;
   }

   /* === NUMBERS === */

   public static String formatAmount(final Double amount) {
      return decimalFormat.get().format(amount);
   }

   public static String formatAmount(final int amount) {
      return decimalFormat.get().format(amount);
   }

   public static Label createAmountLabel(final double amount) {
      Label label = createH5Label(formatAmount(amount));
      label.addClassName(LumoStyles.FontFamily.MONOSPACE);
      return label;
   }

   public static String formatUnits(final int units) {
      return NumberFormat.getIntegerInstance().format(units);
   }

   public static String formatUnits(final long units) {
      return NumberFormat.getIntegerInstance().format(units);
   }

   public static Label createUnitsLabel(final int units) {
      Label label = new Label(formatUnits(units));
      label.addClassName(LumoStyles.FontFamily.MONOSPACE);
      return label;
   }

   /* === ICONS === */
   public static VaadinIcon getVaadinIcon(final String iconName) {
      VaadinIcon icon = null;
      if (StringUtils.isNotEmpty(iconName)) {
         try {
            icon = VaadinIcon.valueOf(iconName);
         } catch (Exception e) {
            handleError(e);

            icon = VaadinIcon.QUESTION_CIRCLE_O;
         }
      }
      return icon;
   }

   public static Icon createPrimaryIcon(final VaadinIcon icon) {
      Icon i = new Icon(icon);
      setTextColor(TextColor.PRIMARY, i);
      return i;
   }

   public static Icon createSecondaryIcon(final VaadinIcon icon) {
      Icon i = new Icon(icon);
      setTextColor(TextColor.SECONDARY, i);
      return i;
   }

   public static Icon createTertiaryIcon(final VaadinIcon icon) {
      Icon i = new Icon(icon);
      setTextColor(TextColor.TERTIARY, i);
      return i;
   }

   public static Icon createDisabledIcon(final VaadinIcon icon) {
      Icon i = new Icon(icon);
      setTextColor(TextColor.DISABLED, i);
      return i;
   }

   public static Icon createSuccessIcon(final VaadinIcon icon) {
      Icon i = new Icon(icon);
      setTextColor(TextColor.SUCCESS, i);
      return i;
   }

   public static Icon createErrorIcon(final VaadinIcon icon) {
      Icon i = new Icon(icon);
      setTextColor(TextColor.ERROR, i);
      return i;
   }

   public static Icon createSmallIcon(final VaadinIcon icon) {
      Icon i = new Icon(icon);
      i.addClassName(IconSize.S.getClassName());
      return i;
   }

   public static Icon createLargeIcon(final VaadinIcon icon) {
      Icon i = new Icon(icon);
      i.addClassName(IconSize.L.getClassName());
      return i;
   }

   // Combinations

   public static Icon createIcon(final IconSize size, final TextColor color, final VaadinIcon icon) {
      Icon i = new Icon(icon);
      i.addClassNames(size.getClassName());
      setTextColor(color, i);
      return i;
   }

   /* === DATES === */

   public static String getCurrentTimeStamp() {
      SimpleDateFormat sdfDate = new SimpleDateFormat("ddMMyyyy-HH:mm");
      Date now = new Date();
      return sdfDate.format(now);
   }

   public static String formatDate(final java.sql.Date date) {
      return date == null ? "" : dateFormat.get().format(date.toLocalDate());
   }

   public static String formatDate(final LocalDate date) {
      return dateFormat.get().format(date);
   }

   public static LocalDate parseDate(final String date) {
      return LocalDate.from(dateFormat.get().parse(date));
   }

   /**
    * yyyy-MM-dd -> yyyyMMdd
    *
    * @param date The date to format.
    * @return polisDate
    */
   public static String localDateToPolisDate(final LocalDate date) {
      return polisDateFormat.get().format(date);
   }

   public static LocalDate polisDateStringToLocalDate(final String date) {
      return LocalDate.from(polisDateFormat.get().parse(date));
   }

   public static String formatDateTime(final LocalDateTime dateTime) {
      return dateTimeFormat.get().format(dateTime);
   }

   public static LocalDateTime parseDatetime(final String dateTime) {
      return LocalDateTime.from(dateTimeFormat.get().parse(dateTime));
   }

   public static String formatTimestamp(final Timestamp timestamp) {
      if (timestamp == null) {
         return "";
      }
      return dateTimeFormat.get().format(timestamp.toLocalDateTime())
            + "." + StringUtils.leftPad("" + timestamp.getNanos(), 9, "0");
   }

   /* === NOTIFICATIONS === */

   /**
    * Shows a normal notification on the screen that will auto-close after 10 seconds.
    *
    * @param message The message to display in the notification.
    * @return The newly opened notification.
    */
   public static StyledNotification showNormalNotification(final String message) {
      return showNotification(message, StyledNotification.DEFAULT_DURATION, null);
   }

   /**
    * Shows a normal notification on the screen that will not auto-close.
    *
    * @param message The message to display in the notification.
    * @return The newly opened notification.
    */
   public static StyledNotification showPermanentNormalNotification(final String message) {
      return showNotification(message, 0, null);
   }

   /**
    * Shows an error notification on the screen that will auto-close after 10 seconds.
    *
    * @param message The message to display in the notification.
    * @return The newly opened notification.
    */
   public static StyledNotification showErrorNotification(final String message) {
      return showNotification(message, StyledNotification.DEFAULT_DURATION, NotificationVariant.LUMO_ERROR);
   }

   /**
    * Shows an error notification on the screen that will not auto-close.
    *
    * @param message The message to display in the notification.
    * @return The newly opened notification.
    */
   public static StyledNotification showPermanentErrorNotification(final String message) {
      return showNotification(message, 0, NotificationVariant.LUMO_ERROR);
   }

   /**
    * Shows a success notification on the screen that will auto-close after 10 seconds.
    *
    * @param message The message to display in the notification.
    * @return The newly opened notification.
    */
   public static StyledNotification showSuccessNotification(final String message) {
      return showNotification(message, StyledNotification.DEFAULT_DURATION, NotificationVariant.LUMO_SUCCESS);
   }

   /**
    * Shows a success notification on the screen that will not auto-close.
    *
    * @param message The message to display in the notification.
    * @return The newly opened notification.
    */
   public static StyledNotification showPermanentSuccessNotification(final String message) {
      return showNotification(message, 0, NotificationVariant.LUMO_SUCCESS);
   }

   /**
    * Shows a notification on the screen with the given message, duration and style variant. Most of the times you will
    * want to use one of the easier short-hand notations such as {@link #showSuccessNotification} or
    * {@link #showErrorNotification} instead for consistency.
    *
    * @param message  The message to display in the notification.
    * @param duration the duration in milliseconds to show the notification, 0 or negative to disable auto-closing.
    * @param variant  The style variant to use for the notification.
    * @return The newly opened notification.
    */
   public static StyledNotification showNotification(
         final String message,
         final int duration,
         final NotificationVariant variant) {
      return showNotification(message, duration, StyledNotification.DEFAULT_POSITION, variant);
   }

   /**
    * Shows a notification on the screen with the given message, duration and style variant. Most of the times you will
    * want to use one of the easier short-hand notations such as {@link #showSuccessNotification} or
    * {@link #showErrorNotification} instead for consistency.
    *
    * @param message  The message to display in the notification.
    * @param duration the duration in milliseconds to show the notification, 0 or negative to disable auto-closing.
    * @param variant  The style variant to use for the notification.
    * @param position The position for the notification.
    * @return The newly opened notification.
    */
   public static StyledNotification showNotification(
         final String message,
         final int duration,
         final Position position,
         final NotificationVariant variant) {
      StyledNotification notification = new StyledNotification(message, duration, position);
      if (variant != null) {
         notification.addThemeVariants(variant);
      }
      if (duration <= 0) {
         notification.clickToClose(true);
      }
      notification.open();
      return notification;
   }

   /* === CSS UTILITIES === */

   public static void setAlignSelf(final AlignSelf alignSelf, final Component... components) {
      for (Component component : components) {
         component.getElement().getStyle().set("align-self", alignSelf.getValue());
      }
   }

   public static void setBackgroundColor(final String backgroundColor, final Component... components) {
      for (Component component : components) {
         component.getElement().getStyle().set("background-color", backgroundColor);
      }
   }

   public static void setBorderRadius(final BorderRadius borderRadius, final Component... components) {
      for (Component component : components) {
         component.getElement().getStyle().set("border-radius", borderRadius.getValue());
      }
   }

   public static void setBoxSizing(final BoxSizing boxSizing, final Component... components) {
      for (Component component : components) {
         component.getElement().getStyle().set("box-sizing", boxSizing.getValue());
      }
   }

   public static void setColSpan(final int span, final Component... components) {
      for (Component component : components) {
         component.getElement().setAttribute("colspan", Integer.toString(span));
      }
   }

   public static void setFontSize(final FontSize fontSize, final Component... components) {
      for (Component component : components) {
         component.getElement().getStyle().set("font-size", fontSize.getValue());
      }
   }

   public static void setFontWeight(final FontWeight fontWeight, final Component... components) {
      for (Component component : components) {
         component.getElement().getStyle().set("font-weight", fontWeight.getValue());
      }
   }

   public static void setLineHeight(final LineHeight lineHeight, final Component... components) {
      for (Component component : components) {
         component.getElement().getStyle().set("line-height", lineHeight.getValue());
      }
   }

   public static void setLineHeight(final String value, final Component... components) {
      for (Component component : components) {
         component.getElement().getStyle().set("line-height", value);
      }
   }

   public static void setMaxWidth(final String value, final Component... components) {
      for (Component component : components) {
         component.getElement().getStyle().set("max-width", value);
      }
   }

   public static void setOverflow(final Overflow overflow, final Component... components) {
      for (Component component : components) {
         component.getElement().getStyle().set("overflow", overflow.getValue());
      }
   }

   public static void setShadow(final Shadow shadow, final Component... components) {
      for (Component component : components) {
         component.getElement().getStyle().set("box-shadow", shadow.getValue());
      }
   }

   public static void setTextAlign(final TextAlign textAlign, final Component... components) {
      for (Component component : components) {
         component.getElement().getStyle().set("text-align", textAlign.getValue());
      }
   }

   public static void setTextColor(final TextColor textColor, final Component... components) {
      for (Component component : components) {
         component.getElement().getStyle().set("color", textColor.getValue());
      }
   }

   public static void setTheme(final String theme, final Component... components) {
      for (Component component : components) {
         component.getElement().setAttribute("theme", theme);
      }
   }

   public static void setTooltip(final String tooltip, final Component... components) {
      for (Component component : components) {
         component.getElement().setProperty("title", tooltip);
      }
   }

   public static void setWhiteSpace(final WhiteSpace whiteSpace, final Component... components) {
      for (Component component : components) {
         component.getElement().setProperty("white-space", whiteSpace.getValue());
      }
   }

   public static void setWidth(final String value, final Component... components) {
      for (Component component : components) {
         component.getElement().getStyle().set("width", value);
      }
   }

   /* === ACCESSIBILITY === */

   public static void setAriaLabel(final String value, final Component... components) {
      for (Component component : components) {
         component.getElement().setAttribute(ATTR_LABEL, value);
      }
   }

   /* === ERROR HANDLING === */

   /**
    * @param error   For logging purposes
    * @param message For user friendly feedback
    */
   public static void handleError(final Throwable error, final String message) {
      LOG.error("Interne fout: {} {}", error.getClass().getName(), error.getMessage());
      ExceptionHandler.getInstance().writeException(error);

      UIUtils.showErrorNotification(message);
   }

   /**
    * @param error For logging purposes
    */
   public static void handleError(final Throwable error) {
      LOG.error("Interne fout: {} {}", error.getClass().getName(), error.getMessage());
      ExceptionHandler.getInstance().writeException(error);

      if (UI.getCurrent() != null) {
         UIUtils.showErrorNotification("Er is een interne fout opgetreden. Neem contact op met uw administrator");
      }
   }
}
