package nl.uwv.pws.ui.components.detailsdrawer;

import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.shared.Registration;
import nl.uwv.pws.ui.components.FlexBoxLayout;
import nl.uwv.pws.ui.layout.size.Horizontal;
import nl.uwv.pws.ui.layout.size.Right;
import nl.uwv.pws.ui.layout.size.Vertical;
import nl.uwv.pws.ui.util.LumoStyles;
import nl.uwv.pws.ui.util.UIUtils;

public class DetailsDrawerFooter extends FlexBoxLayout {

   private final Button save;
   private final Button cancel;

   public DetailsDrawerFooter() {
      super.setBackgroundColor(LumoStyles.Color.Contrast.PCT_5);
      super.setPadding(Horizontal.RESPONSIVE_L, Vertical.S);
      super.setSpacing(Right.S);
      super.setWidthFull();

      save = UIUtils.createPrimaryButton("Save");
      cancel = UIUtils.createTertiaryButton("Cancel");
      super.add(save, cancel);
   }

   public Registration addSaveListener(final ComponentEventListener<ClickEvent<Button>> listener) {
      return save.addClickListener(listener);
   }

   public Registration addCancelListener(final ComponentEventListener<ClickEvent<Button>> listener) {
      return cancel.addClickListener(listener);
   }
}
