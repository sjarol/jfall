package nl.uwv.pws.ui.components;

import com.vaadin.flow.component.html.Span;

import nl.uwv.pws.ui.util.UIUtils;
import nl.uwv.pws.ui.util.css.lumo.BadgeColor;
import nl.uwv.pws.ui.util.css.lumo.BadgeShape;
import nl.uwv.pws.ui.util.css.lumo.BadgeSize;

import static nl.uwv.pws.ui.util.css.lumo.BadgeShape.PILL;

import java.util.StringJoiner;

public class Badge extends Span {

   public Badge(final String text) {
      this(text, BadgeColor.NORMAL);
   }

   public Badge(final String text, final BadgeColor color) {
      super(text);
      UIUtils.setTheme(color.getThemeName(), this);
   }

   public Badge(final String text, final BadgeColor color, final BadgeSize size, final BadgeShape shape) {
      super(text);
      StringJoiner joiner = new StringJoiner(" ");
      joiner.add(color.getThemeName());

      if (shape == PILL) {
         joiner.add(shape.getThemeName());
      }

      if (size == BadgeSize.S) {
         joiner.add(size.getThemeName());
      }
      UIUtils.setTheme(joiner.toString(), this);
   }
}
