package nl.uwv.pws.ui.components;

import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.tabs.Tabs;

import nl.uwv.pws.ui.util.HasAuthorization;

public class AuthorizedTabs extends Tabs implements HasAuthorization {
   boolean tabsAuthorized = true;

   @Override
   public boolean isAuthorized() {
      return tabsAuthorized;
   }

   @Override
   public void setAuthorized(final boolean authorized) {
      tabsAuthorized = authorized;
   }

   @Override
   public void add(final Component... components) {
      for (Component component : components) {
         if (isComponentAuthorized(component)) {
            super.add(component);
         }
      }
   }

   @Override
   public void addComponentAtIndex(final int index, final Component component) {
      if (isComponentAuthorized(component)) {
         super.addComponentAtIndex(index, component);
      }
   }

   @Override
   public void replace(final Component oldComponent, final Component newComponent) {
      if (isComponentAuthorized(newComponent)) {
         super.replace(oldComponent, newComponent);
      } else {
         super.remove(oldComponent);
      }
   }

   private boolean isComponentAuthorized(final Component component) {
      return tabsAuthorized
            && (!(component instanceof HasAuthorization) || ((HasAuthorization) component).isAuthorized());
   }
}
