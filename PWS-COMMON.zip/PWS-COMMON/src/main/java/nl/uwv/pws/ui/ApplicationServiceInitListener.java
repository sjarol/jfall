package nl.uwv.pws.ui;

import com.vaadin.flow.server.VaadinRequest;
import com.vaadin.flow.server.VaadinSession;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.vaadin.flow.server.ServiceInitEvent;
import com.vaadin.flow.server.VaadinServiceInitListener;

import nl.uwv.pws.backend.dao.User;
import nl.uwv.pws.backend.service.UniqueSessionManager;

public class ApplicationServiceInitListener implements VaadinServiceInitListener {
   private static final Logger LOG = LogManager.getLogger(ApplicationServiceInitListener.class);
   private static final int UNIQUE_SESSION_TIMEOUT = 5000;

   @Override
   public void serviceInit(final ServiceInitEvent event) {

      // TODO fix in servlet init of web.xml?
      //ServletContext servletContext = VaadinServlet.getCurrent().getServletContext();
      //servletContext.setInitParameter("org.atmosphere.cpr.AtmosphereConfig.getInitParameter","true");
      //servletContext.setInitParameter("org.atmosphere.websocket.maxIdleTime","45000");

      event.addBootstrapListener(response -> {
         // BoostrapListener to change the bootstrap page
      });

      // DependencyFilter to add/remove/change dependencies sent to the client
      event.addDependencyFilter((dependencies, filterContext) -> dependencies);

      event.addRequestHandler((session, request, response) -> {
         // RequestHandler to change how responses are handled
         try {
            if (request.getRemoteUser() != null) {
               handleRequest(session, request);
            }
         } catch (Exception e) {
            LOG.warn(e);
         }
         return false;
      });
   }

   private void handleRequest(final VaadinSession session, final VaadinRequest request) {
      if (LOG.isTraceEnabled()) {
         LOG.trace("Check sessionId user " + request.getRemoteUser() + ", "
               + UniqueSessionManager.hashSessionId(UniqueSessionManager.getCurrentSessionId()));
         LOG.trace(" getAuthType: " + request.getAuthType());
         LOG.trace(" getContentType: " + request.getContentType());
         LOG.trace(" getContextPath: " + request.getContextPath());
         LOG.trace(" getPathInfo: " + request.getPathInfo());
         LOG.trace(" getUserPrincipal: " + request.getUserPrincipal());
      }
      session.lock();
      String remoteUser = request.getRemoteUser();
      if (!UniqueSessionManager.get().isLoginSession(remoteUser)) {
         if (UniqueSessionManager.get().isActiveSession(remoteUser)) {
            if (System.currentTimeMillis() - session.getLastRequestTimestamp() > UNIQUE_SESSION_TIMEOUT) {
               UniqueSessionManager.get().insertCurrentUserSession(remoteUser);
            }
         } else {
            LOG.debug("Geen geldige sessie, uitloggen");
            User.logout();
            if (session.getSession() != null) {
               session.getSession().invalidate();
            }
            session.close();
         }
      }
      session.unlock();
   }
}
