package nl.uwv.pws.ui.util;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import nl.uwv.pws.backend.dao.AuthorizationType;

@Retention(RUNTIME)
@Target(FIELD)
public @interface AuthorizedComponent {
   String value();

   AuthorizationType type();
}
