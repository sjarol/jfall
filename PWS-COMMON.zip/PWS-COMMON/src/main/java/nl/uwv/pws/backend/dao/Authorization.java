package nl.uwv.pws.backend.dao;

public interface Authorization {

   public String[] getRoles();

   public default boolean isAuthorized(final String... roles) {
      for (String checkRole : getRoles()) {
         for (String role : roles) {
            if (checkRole != null && checkRole.equalsIgnoreCase(role)) {
               return true;
            }
         }
      }
      return false;
   }
}
