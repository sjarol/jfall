package nl.uwv.pws.ui.util.css;

public enum FlexDirection {
   COLUMN("column"),
   COLUMN_REVERSE("column-reverse"),
   ROW("row"),
   ROW_REVERSE("row-reverse");

   private final String value;

   FlexDirection(final String value) {
      this.value = value;
   }

   public String getValue() {
      return value;
   }
}
