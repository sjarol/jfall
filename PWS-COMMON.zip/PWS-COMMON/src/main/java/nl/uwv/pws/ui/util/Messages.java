package nl.uwv.pws.ui.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

public final class Messages {
   private static final Logger LOG = LogManager.getLogger(Messages.class);
   private static Properties messageProperties;

   public static final String RESOURCE = "messages.properties";

   private Messages() {
      // Helper class
   }

   public static String get(final String messageId) {
      init();
      return messageProperties.getProperty(messageId, "Geen melding voor " + messageId);
   }

   public static String get(final String messageId, final String defaultMessage) {
      init();
      return messageProperties.getProperty(messageId, defaultMessage);
   }

   private static void init() {
      if (messageProperties == null) {
         readProperties();
      }
   }

   private static synchronized void readProperties() {
      if (messageProperties == null) {
         messageProperties = new Properties();
         InputStream inputStream = null;
         try {
            ClassLoader classLoader = Messages.class.getClassLoader();
            inputStream = classLoader.getResourceAsStream(RESOURCE);
            if (inputStream != null) {
               messageProperties.load(inputStream);
            } else {
               LOG.warn("Geen resource voor (fout) meldingen : " + RESOURCE);
            }
         } catch (IOException e) {
            UIUtils.handleError(e);
         } finally {
            IOUtils.closeQuietly(inputStream);
         }
      }
   }
}
