package nl.uwv.pws.backend.validator;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class DateValidatorUsingDateTimeFormatter implements DateValidator {

   private final DateTimeFormatter dateFormatter;

   public DateValidatorUsingDateTimeFormatter(final DateTimeFormatter dateFormatter) {
      this.dateFormatter = dateFormatter;
   }

   @Override
   public boolean isValid(final String dateStr) {
      try {
         this.dateFormatter.parse(dateStr);
      } catch (DateTimeParseException e) {
         return false;
      }
      return true;
   }

   @Override
   public boolean isValid(final LocalDateTime localDateTime) {
      if (localDateTime != null) {
         try {
            this.dateFormatter.format(localDateTime);
         } catch (DateTimeParseException e) {
            return false;
         }
         return true;
      }
      return false;
   }

   @Override
   public boolean isValid(final LocalDate localDate) {
      if (localDate != null) {
         try {
            this.dateFormatter.format(localDate);
         } catch (DateTimeParseException e) {
            return false;
         }
         return true;
      }
      return false;
   }
}
