package nl.uwv.pws.ui.layout.size;

public enum Vertical implements Size {

   AUTO("auto", null),
   XS("var(--lumo-space-xs)", "spacing-v-xs"),
   S("var(--lumo-space-s)", "spacing-v-s"),
   M("var(--lumo-space-m)", "spacing-v-m"),
   L("var(--lumo-space-l)", "spacing-v-l"),
   XL("var(--lumo-space-xl)", "spacing-v-xl"),
   RESPONSIVE_M("var(--lumo-space-r-m)", null),
   RESPONSIVE_L("var(--lumo-space-r-l)", null),
   RESPONSIVE_X("var(--lumo-space-r-x)", null);

   LayoutSize verticalSize;

   Vertical(final String variable, final String spacingClassName) {
      verticalSize = new LayoutSize(variable, spacingClassName);
   }

   @Override
   public String[] getMarginAttributes() {
      return verticalSize.getMarginsWithSuffix(LayoutSize.SUFFIX_BOTTOM, LayoutSize.SUFFIX_TOP);
   }

   @Override
   public String[] getPaddingAttributes() {
      return verticalSize.getPaddingsWithSuffix(LayoutSize.SUFFIX_BOTTOM, LayoutSize.SUFFIX_TOP);
   }

   @Override
   public String getSpacingClassName() {
      return verticalSize.getSpacingClassName();
   }

   @Override
   public String getVariable() {
      return verticalSize.getVariable();
   }
}
