package nl.uwv.pws.backend.types;

/**
 * Helps generify Database Column definitions that were set up as enums. By having them implement this
 * interface they have a common way to deliver the column name, simply by using the enums' name() method.
 */
public interface Column {
   /**
    * Returns the name of the column.
    *
    * @return The name of the column.
    */
   public String name();
}
