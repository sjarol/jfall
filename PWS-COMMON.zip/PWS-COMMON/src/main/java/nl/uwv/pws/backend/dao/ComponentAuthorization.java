package nl.uwv.pws.backend.dao;

import java.io.Serializable;

public class ComponentAuthorization implements Authorization, Serializable {

   private String title;
   private AuthorizationType type;
   private String page;
   private String[] roles;

   public static ComponentAuthorization create(
         final String title,
         final AuthorizationType type,
         final String page,
         final String... roles) {

      ComponentAuthorization ca = new ComponentAuthorization();
      ca.setTitle(title);
      ca.setType(type);
      ca.setPage(page);
      ca.setRoles(roles);
      return ca;
   }

   public String getTitle() {
      return title;
   }

   public void setTitle(final String title) {
      this.title = title;
   }

   public AuthorizationType getType() {
      return type;
   }

   public void setType(final AuthorizationType type) {
      this.type = type;
   }

   public String getPage() {
      return page;
   }

   public void setPage(final String page) {
      this.page = page;
   }

   @Override
   public String[] getRoles() {
      return roles;
   }

   public void setRoles(final String... roles) {
      this.roles = roles;
   }
}
