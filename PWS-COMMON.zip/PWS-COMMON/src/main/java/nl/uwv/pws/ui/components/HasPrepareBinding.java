package nl.uwv.pws.ui.components;

import com.vaadin.flow.component.HasValue;
import com.vaadin.flow.data.binder.Binder;

/**
 * Interface that can be used by components that allow you to call the {@link HasPrepareBinding#prepareBinding} method
 * to setup all validations for the field before actually binding it to the bean of your choice.
 *
 * @param <T> The type of property this component will bind to.
 */
public interface HasPrepareBinding<T> {
   /**
    * Sets up the BindingBuilder for this field and prepares the validators to use.
    *
    * @param binder The binder to prepare.
    * @param <B> The type of bean to bind to.
    * @return The prepared BindingBuilder that has validators attached.
    */
   @SuppressWarnings({"unchecked", "rawtypes"})
   public default <B> Binder.BindingBuilder<B, T> prepareBinding(final Binder<B> binder) {
      return binder.forField((HasValue) this);
   }
}
