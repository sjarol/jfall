package nl.uwv.pws.backend.service;

import nl.uwv.pws.backend.types.ColumnList;

import java.io.Serializable;
import java.util.List;

@FunctionalInterface
public interface FetchRowsListener extends Serializable {
   /**
    * Called after the {@link ColumnListDataProvider} has performed its
    * {@link ColumnListDataProvider#fetchFromBackEnd} method so any listener can perform some work using the
    * rows that were received, without having to query the database again.
    *
    * NOTE: This may be called multiple time to retrieve subsets of the list as the user scrolls through the grid.
    *
    * @param rows The rows that were fetched.
    */
   public void rowsFetched(final List<ColumnList> rows);
}
