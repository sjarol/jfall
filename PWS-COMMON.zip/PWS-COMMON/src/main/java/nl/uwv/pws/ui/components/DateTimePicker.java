package nl.uwv.pws.ui.components;

import com.vaadin.flow.component.AbstractField.ComponentValueChangeEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.Composite;
import com.vaadin.flow.component.HasValidation;
import com.vaadin.flow.component.HasValueAndElement;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.datepicker.DatePicker;
import com.vaadin.flow.component.datepicker.GeneratedVaadinDatePicker;
import com.vaadin.flow.component.formlayout.FormLayout;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.internal.AbstractFieldSupport;
import com.vaadin.flow.component.timepicker.TimePicker;
import com.vaadin.flow.shared.Registration;
import nl.uwv.pws.ui.util.UIUtils;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.util.Locale;

/**
 * @deprecated Try to use {@link DateTimePickerZSM} instead.
 */
@Deprecated
public class DateTimePicker extends Composite<FormLayout> implements HasValidation,
      HasValueAndElement<ComponentValueChangeEvent<DateTimePicker, LocalDateTime>, LocalDateTime> {

   private static final int NOW_BUTTON_MINUTES = 4;

   private final AbstractFieldSupport<DateTimePicker, LocalDateTime> fieldSupport;

   private final DatePicker date = new DatePicker();
   private final TimePicker time = new TimePicker();
   private final Label label;
   private final Button btnNow;

   private boolean isChanging;

   /**
    * Deze implementatie vervangen door Vaadin DateTimePicker of door DatumTimePickerZSM
    *
    * @see com.vaadin.flow.component.datetimepicker.DateTimePicker
    * @see nl.uwv.pws.ui.components.DateTimePickerZSM
    */
   public DateTimePicker() {
      this.fieldSupport = new AbstractFieldSupport<>(
            this, LocalDateTime.now(), this::valueEquals, this::setInternalValue
      );

      label = new Label();

      //  DATE
      date.setWidth("50%");
      date.setPlaceholder("dd-mm-jjjj");
      date.setLocale(Locale.forLanguageTag("nl"));
      date.addValueChangeListener(this::dateValueChanged);

      //  TIME
      time.setWidth("50%");
      time.setPlaceholder("hh:mm");
      time.setStep(Duration.ofMinutes(1));
      time.setLocale(Locale.forLanguageTag("nl"));
      time.addValueChangeListener(this::timeValueChanged);

      btnNow = UIUtils.createButton("ZSM", ButtonVariant.LUMO_PRIMARY);
      btnNow.addClickListener(event -> setNowDateTimeValue());

      super.getContent().setColspan(label, 2);
      super.getContent().setColspan(btnNow, 2);

      super.getContent().setResponsiveSteps(
            new FormLayout.ResponsiveStep("25em", 1),
            new FormLayout.ResponsiveStep("32em", 2));

      super.getContent().add(label, date, time, btnNow);
   }

   private void dateValueChanged(final ComponentValueChangeEvent<DatePicker, LocalDate> event) {
      dateOrTimeChanged(event.getValue(), this.time.getValue());
   }

   private void timeValueChanged(final ComponentValueChangeEvent<TimePicker, LocalTime> event) {
      dateOrTimeChanged(this.date.getValue(), event.getValue());
   }

   private void dateOrTimeChanged(final LocalDate date, final LocalTime time) {
      if (isChanging || isInvalid()) {
         // Negeer event indien date of time invalid zijn.
         return;
      }
      if (date != null && time != null) {
         this.fieldSupport.setValue(LocalDateTime.of(date, time));
      } else if (date != null) {
         this.fieldSupport.setValue(date.atStartOfDay());
      } else {
         this.fieldSupport.setValue(null);
      }
   }

   private boolean valueEquals(final LocalDateTime value1, final LocalDateTime value2) {
      return this.fieldSupport.valueEquals(value1, value2);
   }

   public Registration addInvalidChangeListener(
         final ComponentEventListener<GeneratedVaadinDatePicker.InvalidChangeEvent<DatePicker>> listener) {
      return date.addInvalidChangeListener(listener);
   }

   private void setNowDateTimeValue() {
      setValue(LocalDateTime.now().truncatedTo(ChronoUnit.MINUTES).plusMinutes(NOW_BUTTON_MINUTES));
   }

   /**
    * @param min Minimum acceptable datetime
    */
   public void setMin(final LocalDateTime min) {
      this.date.setMin(min.toLocalDate());
   }

   /**
    * @param width of the component, subcomponents inherit
    */
   public void setWidth(final String width) {
      this.date.setWidth(width);
      this.time.setWidth(width);
      this.btnNow.setWidth(width);
   }

   public void setLabel(final String labelText) {
      label.setText(labelText);
   }

   @Override
   public void setEnabled(final boolean enabled) {
      reset();

      date.setEnabled(enabled);
      time.setEnabled(enabled);
      btnNow.setEnabled(enabled);
   }

   /**
    * @param required
    */
   public void setRequired(final Boolean required) {
      date.setRequired(required);
      time.setRequired(required);
   }

   public void reset() {
      date.clear();
      time.clear();
   }

   public DatePicker getDate() {
      return date;
   }

   @Override
   public String getErrorMessage() {
      return date.getErrorMessage();
   }

   @Override
   public void setErrorMessage(final String errorMessage) {
      date.setErrorMessage(errorMessage);
   }

   @Override
   public boolean isInvalid() {
      return date.isInvalid() || time.isInvalid();
   }

   @Override
   public void setInvalid(final boolean invalid) {
      date.setInvalid(invalid);
      time.setInvalid(invalid);
   }

   public void setInternalValue(final LocalDateTime value) {
      isChanging = true;
      try {
         if (value == null) {
            this.date.setValue(null);
            this.time.setValue(null);
         } else {
            this.date.setValue(value.toLocalDate());
            this.time.setValue(value.toLocalTime());
         }
      } finally {
         isChanging = false;
      }
   }

   @Override
   public LocalDateTime getValue() {
      return fieldSupport.getValue();
   }

   @Override
   public void setValue(final LocalDateTime value) {
      fieldSupport.setValue(value);
   }

   @Override
   public Registration addValueChangeListener(
         final ValueChangeListener<? super ComponentValueChangeEvent<DateTimePicker, LocalDateTime>> listener) {
      return fieldSupport.addValueChangeListener(listener);
   }
}
