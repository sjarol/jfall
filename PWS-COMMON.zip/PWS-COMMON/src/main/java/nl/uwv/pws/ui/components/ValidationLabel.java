package nl.uwv.pws.ui.components;

import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.data.binder.Binder;

/**
 * Label that displays a general validation messages that are bound directly to the Binder instead of
 * a specific component. Constructing this Label automatically sets itself
 * as statusLabel for the binder you pass into the constructor.
 */
public class ValidationLabel extends Label {
   public static final String NO_RESULTS_ID = "validation-message";

   public ValidationLabel(final Binder<?> binder) {
      super();
      super.setVisible(false);
      super.setId(NO_RESULTS_ID);
      super.getStyle().set("color", "red").set("font-weight", "bold");
      binder.setStatusLabel(this);
   }

   @Override
   public void setText(final String text) {
      super.setText(text);
      setVisible(text != null && !text.isEmpty());
   }
}
