package nl.uwv.pws.ui.components;

import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import nl.uwv.pws.ui.util.UIUtils;
import nl.uwv.pws.ui.views.ViewFrame;

/**
 * Base class for basic dialogs for viewing elaborated information of items.
 * This dialog only consists of a cancel action
 */
public class StyledDialog extends AbstractDialog {
   /**
    * @param parent to check for authorisation
    * @param title  of the dialog
    */
   public StyledDialog(final ViewFrame parent, final String title) {
      super(parent, title);
   }

   /**
    * @param parent to check for authorisation
    * @param title  of the dialog
    * @param width  of the dialog
    * @param height of the dialog
    */
   public StyledDialog(final ViewFrame parent, final String title, final String width, final String height) {
      super(parent, title, width, height);
   }

   /**
    * @param parent               to check for authorisation
    * @param title                of the dialog
    * @param width                of the dialog
    * @param height               of the dialog
    * @param inheritedComponentId CSS ID to give to the component
    */
   public StyledDialog(
         final ViewFrame parent,
         final String title,
         final String width,
         final String height,
         final String inheritedComponentId) {
      super(parent, title, width, height, inheritedComponentId);
   }

   @Override
   void initHeader(final HorizontalLayout headerToInitialize) {
      // No additional initialization required
   }

   @Override
   Button createAndPlaceCancelButton(final HorizontalLayout footerLeft, final HorizontalLayout footerRight) {
      Button cancelButton = UIUtils.createButton("Annuleren", VaadinIcon.CLOSE_CIRCLE);
      footerRight.add(cancelButton);
      return cancelButton;
   }

   @Override
   void addCancelButtonAsFirstOnFooter(
         final Button cancelButton,
         final HorizontalLayout footerLeft,
         final HorizontalLayout footerRight) {
      footerRight.addComponentAsFirst(cancelButton);
   }
}
