package nl.uwv.pws.backend.types;

public interface RowId {
   Object getId();
}
