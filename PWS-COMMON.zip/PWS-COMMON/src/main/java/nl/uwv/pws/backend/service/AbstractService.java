package nl.uwv.pws.backend.service;

import java.io.Serializable;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

/**
 * Basis class voor een Database service.
 * Bepaalt een datasource of de naam voor een datasource uit de applicatie context (web.xml). 
 * 
 */
@SuppressWarnings("serial")
public class AbstractService implements Serializable {
   private static final Logger LOG = LogManager.getLogger(AbstractService.class);
   private static final String PREFIX = "java:/comp/env/";

   private String dsName = null;
   private transient DataSource ds = null;


   public AbstractService(final String dsName) {
      super();
      this.dsName = dsName;
   }

   protected DataSource getDataSource() throws NamingException {
      if (ds == null) {
         Context initContext = getInitialContext();
         try {
            ds = (DataSource) initContext.lookup(getDSName());
         } catch (NamingException e1) {
            try {
               ds = (DataSource) initContext.lookup(PREFIX + getDSName());
               LOG.debug("Prefix used to locate datasource: " + PREFIX);
            } catch (NamingException e2) {
               LOG.debug("NamingException: " + e2.getMessage(), e2);
               // Ook met prefix niet gevonden, raise originele exceptie
               throw e1;
            }
         }
         if (ds == null) {
            throw new NamingException("Datasource not found : " + getDSName());
         }
      }
      return ds;
   }

   /**
    * Bepaal een string waarde uit de web.xml
    * <pre>{@code
    * <!-- fragment in web.xml -->
    * <env-entry>
    *    <env-entry-name>envKey</env-entry-name>
    *    <env-entry-type>java.lang.String</env-entry-type>
    *    <env-entry-value>waarde</env-entry-value>
    * </env-entry>
    * }</pre>
    * @param envKey
    * @param defaultValue
    * @return value uit env-entry of default waarde als de entry-name niet bestaat.
    */
   public static String getStringFromContext(final String envKey, final String defaultValue) {
      String value = defaultValue;
      try {
         Context env = (Context) new InitialContext().lookup("java:comp/env");
         if (env != null) {
            value = (String) env.lookup(envKey);
            LOG.debug("getStringFromContext:" + envKey + "=" + value);
         }
      } catch (NamingException e) {
         LOG.debug("Context lookup faalt: " + e.getMessage(), e);
      }
      return value;
   }


   protected void setDataSource(DataSource ds) {
      this.ds = ds;
   }

   protected Context getInitialContext() throws NamingException {
      return new InitialContext();
   }

   private String getDSName() {
      return dsName;
   }
}
