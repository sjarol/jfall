package nl.uwv.pws.ui.renderer;

import java.sql.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import com.vaadin.flow.data.renderer.BasicRenderer;
import com.vaadin.flow.function.ValueProvider;

/**
 * A template renderer for presenting sql date values.
 */
public class SqlDateRenderer<S> extends BasicRenderer<S, Date> {

   private static final String DEFAULT_PATTERN = "dd.MM.yyyy HH:mm:ss";
   private final DateFormat formatter;
   private final String nullRepresentation;

   /**
    * Creates a new SqlDateRenderer.
    */
   public SqlDateRenderer(final ValueProvider<S, Date> valueProvider) {
      this(valueProvider, DEFAULT_PATTERN, "");
   }

   /**
    * Creates a new SqlDateRenderer.
    */
   public SqlDateRenderer(final ValueProvider<S, Date> valueProvider, final String pattern) {
      this(valueProvider, pattern, "");
   }

   public SqlDateRenderer(
         final ValueProvider<S, Date> valueProvider,
         final String pattern,
         final String nullRepresentation) {
      super(valueProvider);
      this.formatter = new SimpleDateFormat(pattern);
      this.nullRepresentation = nullRepresentation;
   }

   @Override
   protected String getFormattedValue(final Date date) {
      try {
         return date == null ? nullRepresentation : formatter.format(date);
      } catch (Exception e) {
         throw new IllegalStateException(
               "Could not format input date '" + date + "' using formatter '" + formatter + "'", e);
      }
   }
}
