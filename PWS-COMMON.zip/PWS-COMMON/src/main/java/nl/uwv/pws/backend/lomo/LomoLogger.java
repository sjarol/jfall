package nl.uwv.pws.backend.lomo;

import java.io.Serializable;

import javax.servlet.http.HttpServletRequest;
import javax.sql.DataSource;

public interface LomoLogger extends Serializable {

   /*
    * Initialiseer de LomoLogger
    * @param lomoDataSource
    * @param programId
    * @param appiId
    */
   void init(final DataSource lomoDataSource, final String programId, final int appiId);

   /**
    * Logt een bericht in het LOMO log.
    *
    * @param httpServletRequest
    * @param applicatieFunctie
    * @param message
    * @param httpServletRequest
    */
   void addLomoLog(
         final HttpServletRequest httpServletRequest,
         final String applicatieFunctie,
         final LomoLogMessage message
   );
}
