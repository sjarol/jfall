package nl.uwv.pws.ui.components.navigation.drawer;

import java.util.ArrayList;
import java.util.List;

import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.html.Anchor;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.router.AfterNavigationEvent;
import com.vaadin.flow.router.HighlightConditions;
import com.vaadin.flow.router.RouterLink;

import nl.uwv.pws.ui.util.UIUtils;

@CssImport("./styles/components/navi-item.css")
public class NaviItem extends Div {

   private static final String CLASS_NAME = "navi-item";
   private static final String URL_SEP = "/";
   private static final String LINK_SUFFIX = "__link";

   private int level = 0;

   private final Component link;
   private final Class<? extends Component> navigationTarget;
   private final String text;
   private final List<NaviItem> subItems;

   protected Button expandCollapse;
   private boolean subItemsVisible;

   public NaviItem(final VaadinIcon icon, final String text, final Class<? extends Component> navigationTarget) {
      this(text, navigationTarget);
      link.getElement().insertChild(0, new Icon(icon).getElement());
   }

   public NaviItem(final VaadinIcon icon, final String text, final String navigationUrl) {
      this(text, null, navigationUrl);
      link.getElement().insertChild(0, new Icon(icon).getElement());
   }

   public NaviItem(final Image image, final String text, final Class<? extends Component> navigationTarget) {
      this(text, navigationTarget);
      link.getElement().insertChild(0, image.getElement());
   }

   public NaviItem(final String text, final Class<? extends Component> navigationTarget) {
      this(text, navigationTarget, null);
   }

   public NaviItem(final String text, final Class<? extends Component> navigationTarget, final String navUrl) {
      super.setClassName(CLASS_NAME);
      setLevel(0);

      this.text = text;
      String routerUrl = navUrl;

      if (navigationTarget != null) {
         RouterLink routerLink = new RouterLink(null, navigationTarget);
         routerLink.add(new Span(text));
         routerLink.setClassName(CLASS_NAME + LINK_SUFFIX);
         routerLink.setHighlightCondition(HighlightConditions.sameLocation());
         this.link = routerLink;
         this.navigationTarget = navigationTarget;
      } else if (navUrl != null) {
         Anchor anchor = new Anchor();
         anchor.add(new Label(text));
         anchor.setHref(navUrl);
         anchor.setClassName(CLASS_NAME + LINK_SUFFIX);
         this.link = anchor;
         if (navUrl.contains(URL_SEP)) {
            routerUrl = navUrl.substring(navUrl.lastIndexOf(URL_SEP));
         }
         this.navigationTarget = UI.getCurrent().getRouter().getRegistry().getNavigationTarget(routerUrl).orElse(null);
      } else {
         Div div = new Div(new Span(text));
         div.addClickListener(e -> expandCollapse.click());
         div.setClassName(CLASS_NAME + LINK_SUFFIX);
         this.link = div;
         this.navigationTarget = null;
      }

      expandCollapse = UIUtils.createButton(VaadinIcon.CARET_UP, ButtonVariant.LUMO_SMALL, ButtonVariant.LUMO_TERTIARY);
      expandCollapse.addClickListener(event -> setSubItemsVisible(!subItemsVisible));
      expandCollapse.setVisible(false);

      subItems = new ArrayList<>();
      subItemsVisible = true;
      updateAriaLabel();

      super.add(link, expandCollapse);
   }

   private void updateAriaLabel() {
      String action = (subItemsVisible ? "Collapse " : "Expand ") + text;
      UIUtils.setAriaLabel(action, expandCollapse);
   }

   public boolean isHighlighted(final AfterNavigationEvent e) {
      if (link instanceof Anchor) {
         return ((Anchor) link).getHref().contains(e.getLocation().getPath());
      }
      return link instanceof RouterLink
            && ((RouterLink) link).getHighlightCondition().shouldHighlight((RouterLink) link, e);
   }

   public final void setLevel(final int level) {
      this.level = level;
      if (level > 0) {
         getElement().setAttribute("level", Integer.toString(level));
      }
   }

   public int getLevel() {
      return level;
   }

   public Class<? extends Component> getNavigationTarget() {
      return navigationTarget;
   }

   public void addSubItem(final NaviItem item) {
      if (!expandCollapse.isVisible()) {
         expandCollapse.setVisible(true);
      }
      item.setLevel(getLevel() + 1);
      subItems.add(item);
   }

   private void setSubItemsVisible(final boolean visible) {
      if (level == 0) {
         expandCollapse.setIcon(new Icon(visible ? VaadinIcon.CARET_UP : VaadinIcon.CARET_DOWN));
      }
      subItems.forEach(item -> item.setVisible(visible));
      subItemsVisible = visible;
      updateAriaLabel();
   }

   @Override
   public String getText() {
      return text;
   }

   @Override
   public void setVisible(final boolean visible) {
      super.setVisible(visible);

      // If true, we only update the icon. If false, we hide all the sub items
      if (visible) {
         if (level == 0) {
            expandCollapse.setIcon(new Icon(VaadinIcon.CARET_DOWN));
         }
      } else {
         setSubItemsVisible(false);
      }
   }
}
