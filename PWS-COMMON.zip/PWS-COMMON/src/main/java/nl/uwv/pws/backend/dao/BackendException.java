package nl.uwv.pws.backend.dao;

public class BackendException extends RuntimeException {

   public BackendException(final String message) {
      super(message);
   }

   public BackendException(final Throwable cause) {
      super(cause);
   }

   public BackendException(final String message, final Throwable cause) {
      super(message, cause);
   }

   public BackendException(
         final String message,
         final Throwable cause,
         final boolean enableSuppression,
         final boolean writableStackTrace) {
      super(message, cause, enableSuppression, writableStackTrace);
   }
}
