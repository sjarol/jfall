package nl.uwv.pws.ui;

public class AppRuntimeException extends RuntimeException {
   public AppRuntimeException(final String message) {
      super(message);
   }

   public AppRuntimeException(final Throwable cause) {
      super(cause);
   }

   public AppRuntimeException(final String message, final Throwable cause) {
      super(message, cause);
   }

   public AppRuntimeException(
         final String message,
         final Throwable cause,
         final boolean enableSuppression,
         final boolean writableStackTrace) {
      super(message, cause, enableSuppression, writableStackTrace);
   }
}
