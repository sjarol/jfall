package nl.uwv.pws.backend.lomo;

import java.sql.Timestamp;

import javax.servlet.http.HttpServletRequest;
import javax.sql.DataSource;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import nl.uwv.commons.ws.UwvLomoLogger;
import nl.uwv.commons.ws.UwvLomoLogger.LogItemManager;
import nl.uwv.pws.backend.lomo.LomoLogMessage.KeyValue;

public class LomoLoggerPWS implements LomoLogger {
   private static final Logger LOG = LogManager.getLogger(LomoLoggerPWS.class);

   private UwvLomoLogger uwvLomoLogger;

   @Override
   public void init(final DataSource lomoDataSource, final String programId, final int appiId) {
      if (uwvLomoLogger == null) {
         uwvLomoLogger = new UwvLomoLogger();
         try {
            uwvLomoLogger.setDataSource(lomoDataSource);
         } catch (Exception e) {
            LOG.error(e.getClass().getName() + ": " + e.getMessage(), e);
         }
         uwvLomoLogger.setAppiId(appiId);
         uwvLomoLogger.init();
      }
   }

   @Override
   public void addLomoLog(
         final HttpServletRequest httpServletRequest,
         final String applicatieFunctie,
         final LomoLogMessage message) {
      Timestamp timeStamp = new Timestamp(System.currentTimeMillis());

      LogItemManager logger = uwvLomoLogger.createLogItem(
            timeStamp, message.getTransaction().toString(), httpServletRequest, httpServletRequest.getRemoteUser())
            .setHandeling(message.getAction())
            .setResultaatCode(message.getResult().toString())
            .setResultaatBericht(message.getMessage())
            .setApplicatiefunctie(applicatieFunctie);

      if (!message.getDetails().isEmpty()) {
         for (KeyValue detail : message.getDetails()) {
            logger.addDetail(detail.getKey(), detail.getValue());
         }
      } else {
         // Bug in LOMO Logger, detail is verplicht
         logger.addDetail("DUMMY", "nvt");
      }
      logger.doLog();
   }
}
