package nl.uwv.pws.backend.service;

import java.io.Serializable;

@FunctionalInterface
public interface CountRowsListener extends Serializable {
   /**
    * Called after the {@link ColumnListDataProvider} has performed its
    * {@link ColumnListDataProvider#sizeInBackEnd} method so any listener can perform some work using the determined
    * count without having to query the database again.
    *
    * @param rowCount The number of rows that was determined.
    */
   public void rowsCounted(final long rowCount);
}
