package nl.uwv.pws.ui.util.css;

public enum Overflow {
   AUTO("auto"),
   HIDDEN("hidden"),
   SCROLL("scroll"),
   VISIBLE("visible");

   private final String value;

   Overflow(final String value) {
      this.value = value;
   }

   public String getValue() {
      return value;
   }
}
