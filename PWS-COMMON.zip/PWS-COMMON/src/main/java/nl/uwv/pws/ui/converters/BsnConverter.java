package nl.uwv.pws.ui.converters;

import com.vaadin.flow.data.binder.Result;
import com.vaadin.flow.data.binder.ValueContext;
import com.vaadin.flow.data.converter.Converter;
import nl.uwv.pws.ui.model.BsnNumber;

/**
 * Converts between the String representation of a BSN number, as typically inputted into a TextField and a dedicated
 * {@link BsnNumber} Java object.
 */
public class BsnConverter implements Converter<String, BsnNumber> {
   /**
    * {@inheritDoc}
    */
   @Override
   public Result<BsnNumber> convertToModel(final String value, final ValueContext context) {
      return Result.ok(new BsnNumber(value));
   }

   /**
    * {@inheritDoc}
    */
   @Override
   public String convertToPresentation(final BsnNumber bsnNumber, final ValueContext context) {
      return bsnNumber == null ? "" : bsnNumber.getBsn();
   }
}
