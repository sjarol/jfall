package nl.uwv.pws.ui.views;

import com.vaadin.flow.component.dependency.HtmlImport;
import com.vaadin.flow.component.html.H1;
import com.vaadin.flow.component.html.H2;
import com.vaadin.flow.component.html.Image;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.page.Viewport;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import nl.uwv.pws.ui.util.UIUtils;

@Route(value = NotAuthorizedView.ROUTE)
@PageTitle("Niet geauthoriseerd Polis+")
@HtmlImport("frontend://bower_components/vaadin-lumo-styles/presets/compact.html")
@Viewport("width=device-width, minimum-scale=1.0, initial-scale=1.0, user-scalable=yes")
public class NotAuthorizedView extends VerticalLayout {
   public static final String ROUTE = "notauthorized";

   public NotAuthorizedView() {
      H1 title = new H1();
      Label titleLabel = UIUtils.createH1Label("PWS");
      Image logo = new Image(UIUtils.IMG_PATH + "uwvLogo1RGB.svg", "UWV logo");
      logo.getStyle().set("flex-shrink", "0");
      logo.getStyle().set("height", "96px");
      logo.getStyle().set("margin-left", "var(--lumo-space-m)");
      logo.getStyle().set("width", "96px");

      title.getStyle().set("color", "var(--lumo-base-color)");
      title.getStyle().set("background-color", "var(--theme-color-primary, #FFFFF)");
      title.getStyle().set("display", "flex");
      title.getStyle().set("flex-direction", "row");
      title.getStyle().set("align-items", "center");
      title.getStyle().set("justify-content", "center");

      titleLabel.setWidthFull();
      title.setWidthFull();
      title.add(titleLabel, logo);

      H2 melding = new H2();
      Label meldingLabel = UIUtils.createH1Label("U bent niet geautoriseerd voor Polis+ Webschermen.");
      meldingLabel.setWidthFull();
      melding.add(meldingLabel);

      Image notAuthImg = new Image(UIUtils.IMG_PATH + "unauthorized.jpg", "Not Authorized");

      super.add(title, melding, notAuthImg);
   }
}
