package nl.uwv.pws.ui.components.navigation.tab;

import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.icon.VaadinIcon;
import nl.uwv.pws.ui.util.FontSize;
import nl.uwv.pws.ui.util.UIUtils;

public class ClosableNaviTab extends NaviTab {

   private final Button close;

   public ClosableNaviTab(final String label, final Class<? extends Component> navigationTarget) {
      super(label, navigationTarget);
      super.getElement().setAttribute("closable", true);

      close = UIUtils.createButton(VaadinIcon.CLOSE, ButtonVariant.LUMO_TERTIARY_INLINE);
      // ButtonVariant.LUMO_SMALL isn't small enough.
      UIUtils.setFontSize(FontSize.XXS, close);
      super.add(close);
   }

   public Button getCloseButton() {
      return close;
   }
}
