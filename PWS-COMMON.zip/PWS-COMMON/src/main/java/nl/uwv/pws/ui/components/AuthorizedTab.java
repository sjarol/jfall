package nl.uwv.pws.ui.components;

import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.tabs.Tab;

import nl.uwv.pws.ui.util.ComponentAuthorizationHelper;
import nl.uwv.pws.ui.util.HasAuthorization;

public class AuthorizedTab extends Tab implements HasAuthorization {
   boolean tabAuthorized = true;

   public AuthorizedTab() {
      super();
   }

   public AuthorizedTab(final String label) {
      super(label);
   }

   public AuthorizedTab(final Component... components) {
      super(components);
   }

   @Override
   public boolean isAuthorized() {
      return tabAuthorized;
   }

   @Override
   public void setAuthorized(final boolean authorized) {
      tabAuthorized = authorized;
      ComponentAuthorizationHelper.checkAutorizedComponents(this);
   }
}
