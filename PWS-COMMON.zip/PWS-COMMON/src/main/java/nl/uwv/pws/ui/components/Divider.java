package nl.uwv.pws.ui.components;

import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import nl.uwv.pws.ui.util.LumoStyles;
import nl.uwv.pws.ui.util.UIUtils;

public class Divider extends FlexBoxLayout {

   private static final String CLASS_NAME = "divider";

   private final Div lineDiv;

   public Divider(final String height) {
      this(FlexComponent.Alignment.CENTER, height);
   }

   public Divider(final FlexComponent.Alignment alignItems, final String height) {
      super.setAlignItems(alignItems);
      super.setClassName(CLASS_NAME);
      super.setHeight(height);

      lineDiv = new Div();
      UIUtils.setBackgroundColor(LumoStyles.Color.Contrast.PCT_10, lineDiv);
      lineDiv.setHeight("1px");
      lineDiv.setWidthFull();
      super.add(lineDiv);
   }

   public void setLineWidth(final String width) {
      lineDiv.setWidth(width);
   }

   public void setLineHeighth(final String height) {
      lineDiv.setHeight(height);
   }
}
