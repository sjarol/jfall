package nl.uwv.pws.ui.util;

public interface HasAuthorization {
   boolean isAuthorized();

   void setAuthorized(final boolean authorized);
}
