package nl.uwv.pws.ui.layout.size;

public enum Bottom implements Size {

   AUTO("auto", null),
   XS("var(--lumo-space-xs)", "spacing-b-xs"),
   S("var(--lumo-space-s)", "spacing-b-s"),
   M("var(--lumo-space-m)", "spacing-b-m"),
   L("var(--lumo-space-l)", "spacing-b-l"),
   XL("var(--lumo-space-xl)", "spacing-b-xl"),
   RESPONSIVE_M("var(--lumo-space-r-m)", null),
   RESPONSIVE_L("var(--lumo-space-r-l)", null),
   RESPONSIVE_X("var(--lumo-space-r-x)", null);

   LayoutSize bottomSize;

   Bottom(final String variable, final String spacingClassName) {
      bottomSize = new LayoutSize(variable, spacingClassName);
   }

   @Override
   public String[] getMarginAttributes() {
      return new String[]{"margin-bottom"};
   }

   @Override
   public String[] getPaddingAttributes() {
      return new String[]{"padding-bottom"};
   }

   @Override
   public String getSpacingClassName() {
      return bottomSize.getSpacingClassName();
   }

   @Override
   public String getVariable() {
      return bottomSize.getVariable();
   }
}
