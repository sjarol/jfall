package nl.uwv.pws.backend.service;

import java.util.stream.Stream;

import com.vaadin.flow.data.provider.AbstractBackEndDataProvider;
import com.vaadin.flow.data.provider.Query;

@SuppressWarnings("serial")
public class ListBoxProvider extends AbstractBackEndDataProvider<String, String> {
   private ListBoxService listBoxService;

   public ListBoxProvider(final String dsName, final String viewName, final String columnName) {
      this.listBoxService = new ListBoxServiceImpl(dsName, viewName, columnName);
   }

   protected ListBoxService getListBoxService() {
      return listBoxService;
   }

   protected void setListBoxService(ListBoxService listBoxService) {
      this.listBoxService = listBoxService;
   }

   @Override
   protected Stream<String> fetchFromBackEnd(final Query<String, String> query) {
      return getListBoxService().fetchRows(query.getFilter().orElse(null), query.getLimit(), query.getOffset(),
            query.getSortOrders()).stream();
   }

   @Override
   protected int sizeInBackEnd(final Query<String, String> query) {
      return (int) getListBoxService().countRows(query.getFilter().orElse(null));
   }
}
