package nl.uwv.pws.ui.util;

import java.io.IOException;
import java.util.Collection;
import java.util.Optional;

import org.apache.commons.csv.CSVPrinter;

import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.grid.Grid.Column;
import com.vaadin.flow.data.binder.BeanPropertySet;
import com.vaadin.flow.data.binder.PropertyDefinition;
import com.vaadin.flow.data.binder.PropertySet;
import org.apache.commons.lang3.StringUtils;

public class CsvBeanGridExporter<T> extends AbstractCsvGridExporter<T> {
   private PropertySet<T> propertySet;

   public CsvBeanGridExporter(final PropertySet<T> propertySet) {
      this.propertySet = propertySet;
   }

   @Override
   protected boolean isExportable(final Grid.Column<T> column) {
      return super.isExportable(column) && StringUtils.isNotEmpty(column.getKey())
            && (propertySet == null || propertySet.getProperty(column.getKey()).isPresent());
   }

   protected void printHeader(final CSVPrinter printer, final Collection<Grid.Column<T>> columns) throws IOException {
      for (Grid.Column<T> column : columns) {
         if (propertySet == null) {
            printer.print(column.getId().orElse(column.getKey()));
         } else {
            Optional<PropertyDefinition<T, ?>> propertyDefinition = propertySet.getProperty(column.getKey());
            if (propertyDefinition.isPresent()) {
               printer.print(propertyDefinition.get().getCaption());
            }
         }
      }
      printer.println();
   }

   @SuppressWarnings("unchecked")
   protected void printRow(
         final CSVPrinter printer,
         final Collection<Grid.Column<T>> columns,
         final T item) throws IOException {

      if (propertySet == null) {
         propertySet = (PropertySet<T>) BeanPropertySet.get(item.getClass());
      }
      for (Column<T> column : columns) {
         Optional<PropertyDefinition<T, ?>> propertyDefinition = propertySet.getProperty(column.getKey());
         if (propertyDefinition.isPresent()) {
            printer.print(propertyDefinition.get().getGetter().apply(item));
         }
      }
      printer.println();
   }
}
