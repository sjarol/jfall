package nl.uwv.pws.ui.layout.size;

import java.util.ArrayList;
import java.util.List;

public class LayoutSize {
   public static final String SUFFIX_RIGHT = "right";
   public static final String SUFFIX_LEFT = "left";
   public static final String SUFFIX_TOP = "top";
   public static final String SUFFIX_BOTTOM = "bottom";

   private static final String[] margins = new String[]{"margin"};
   private static final String[] paddings = new String[]{"padding"};

   private final String variable;
   private final String spacingClassName;

   protected LayoutSize(final String variable, final String spacingClassName) {
      this.variable = variable;
      this.spacingClassName = spacingClassName;
   }

   public String getSpacingClassName() {
      return this.spacingClassName;
   }

   public String getVariable() {
      return this.variable;
   }

   public String[] getMargins() {
      return margins;
   }

   public String[] getPaddings() {
      return paddings;
   }

   public String[] getMarginsWithSuffix(final String... suffixes) {
      return cloneWithSuffixes(margins, suffixes);
   }

   public String[] getPaddingsWithSuffix(final String... suffixes) {
      return cloneWithSuffixes(paddings, suffixes);
   }

   private String[] cloneWithSuffixes(final String[] array, final String... suffixes) {
      List<String> list = new ArrayList<>();

      for (String item : array) {
         for (String suffix : suffixes) {
            list.add(item + addSuffix(suffix));
         }
      }

      return list.toArray(new String[0]);
   }

   private String addSuffix(final String suffix) {
      return "-" + suffix;
   }
}
