package nl.uwv.pws.backend.dao;

public enum AuthorizationType {
   APP("Application"),
   BTN("Button"),
   CHK("CheckBox"),
   MNU("Menu"),
   TAB("Subtab"),
   TBL("Table");

   private final String description;

   AuthorizationType(final String description) {
      this.description = description;
   }

   @Override
   public String toString() {
      return description;
   }
}
