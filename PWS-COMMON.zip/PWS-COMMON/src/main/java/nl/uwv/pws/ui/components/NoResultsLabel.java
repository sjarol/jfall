package nl.uwv.pws.ui.components;

import com.vaadin.flow.component.html.Label;

/**
 * Label that displays an error-message if no results were found while searching. This label is initially invisible and
 * should be set to visible only if a search-result fails to deliver any results and is typically added above the main
 * grid of a view.
 */
public class NoResultsLabel extends Label {
   public static final String NO_RESULTS_ID = "no_results_label";

   public NoResultsLabel() {
      super("Geen resultaten gevonden");
      super.setVisible(false);
      super.setId(NO_RESULTS_ID);
      super.getStyle().set("color", "red").set("font-weight", "bold");
   }
}
