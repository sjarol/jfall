package nl.uwv.pws.ui;

import java.util.List;

import com.vaadin.flow.router.BeforeEvent;
import com.vaadin.flow.router.HasUrlParameter;
import com.vaadin.flow.router.WildcardParameter;

import nl.uwv.pws.ui.util.EncryptionUtil;

public interface HasEncryptedURLParameter extends HasUrlParameter<String> {

   default void setParameter(final BeforeEvent event, @WildcardParameter final String parameters) {
      List<String> paramList = EncryptionUtil.decodeParameters(parameters);
      if (paramList.size() != 1) {
         throw new IllegalArgumentException("Invalid number of parameters");
      }
      processParameter(event, paramList.get(0));
   }

   void processParameter(final BeforeEvent event, final String parameter);
}
