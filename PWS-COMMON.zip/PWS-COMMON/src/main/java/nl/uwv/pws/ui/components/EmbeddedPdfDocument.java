package nl.uwv.pws.ui.components;

import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.HasSize;
import com.vaadin.flow.component.Tag;
import com.vaadin.flow.server.StreamResource;

@Tag("object")
public class EmbeddedPdfDocument extends Component implements HasSize {
   public EmbeddedPdfDocument(final StreamResource resource) {
      this();
      super.getElement().setAttribute("data", resource);
   }

   public EmbeddedPdfDocument(final String url) {
      this();
      super.getElement().setAttribute("data", url);
   }

   @SuppressWarnings("java:S1699") // Call to overridable method setSizeFull from constructor
   protected EmbeddedPdfDocument() {
      super.getElement().setAttribute("type", "application/pdf");
      setSizeFull();
   }
}
