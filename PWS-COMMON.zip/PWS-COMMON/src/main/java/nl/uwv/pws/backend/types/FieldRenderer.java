package nl.uwv.pws.backend.types;

import com.vaadin.flow.data.renderer.Renderer;
import com.vaadin.flow.function.ValueProvider;

public interface FieldRenderer<T extends RowId> {

   Renderer<T> render(final Field field, final ValueProvider<T, ?> value);
}
