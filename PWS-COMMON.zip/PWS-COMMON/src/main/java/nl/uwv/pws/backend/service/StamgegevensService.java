package nl.uwv.pws.backend.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.commons.collections4.map.PassiveExpiringMap;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import nl.uwv.pws.backend.types.FieldDescriptionProvider;
import nl.uwv.pws.ui.util.UIUtils;

/**
 * Service om stamgegevens op te halen uit de tabellen in SCALAREF.
 * @implNote tabellen SCALAREF.REF_STAMGEGEVENS, SCALAREF.REF_STAMGEGEVENS_CAT 
 *    worden benaderd via synonym REF_STAMGEGEVENS en REF_STAMGEGEVENS_CAT.
 * @author rbo138
 *
 */
@SuppressWarnings("serial")
public class StamgegevensService extends AbstractService implements FieldDescriptionProvider {
   private static final Logger LOG = LogManager.getLogger(StamgegevensService.class);

   /**
    * Keep UserContext in cache for nn minutes
    */
   private static final int ENTRY_EXPIRATION_TIME = 60;
   private static Map<String, String> descriptionCache =
         new PassiveExpiringMap<>(ENTRY_EXPIRATION_TIME, TimeUnit.MINUTES);

   public StamgegevensService(final String dsName) {
      super(dsName);
   }

   public String getDescription(final String catCode) {
      String omschrijving = descriptionCache.get(catCode);
      if (omschrijving == null) {
         omschrijving = getCatNaam(catCode.toUpperCase());
         descriptionCache.put(catCode, omschrijving);
      }
      return omschrijving;
   }

   public String getDescription(final String catCode, final String code) {
      String key = catCode + "@" + code;
      String omschrijving = descriptionCache.get(key);
      if (omschrijving == null) {
         omschrijving = getCatCodeDescr(catCode.toUpperCase(), code.toUpperCase());
         descriptionCache.put(key, omschrijving);
      }
      return omschrijving;
   }

   private String getCatNaam(final String catCode) {
      String melding = String.format("naam voor cat '%s'", catCode);
      String naamMelding = "Onbekende " + melding;
      String naam = null;
      String sql = "SELECT cat.NAAM, cat.DATUMAANVANG, cat.DATUMEINDE"
            + " FROM REF_STAMGEGEVENS_CAT cat WHERE cat.CAT_CD = ?";

      LOG.debug("Bepaal " + melding);
      try (Connection conn = getDataSource().getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
         stmt.setString(1, catCode);
         try (ResultSet rs = stmt.executeQuery()) {
            naam = createNaamFromRS(rs);
         }
      } catch (Exception e) {
         LOG.debug("Sql: " + sql);
         UIUtils.handleError(e, "Fout bij ophalen naam voor categorie");
      }
      if (naam == null) {
         naam = naamMelding;
      }
      LOG.debug("Naam: " + naam);
      return naam;
   }

   private String createNaamFromRS(ResultSet rs) throws SQLException {
      String naam = null;
      if (rs.next()) {
         naam = rs.getString("NAAM");
         String opm = rs.getString("DATUMEINDE");
         if (StringUtils.isNotEmpty(opm)) {
            naam += "* Be\u00EBindigd per " + opm;
         }
      }
      return naam;
   }

   private String getCatCodeDescr(final String cat, final String code) {
      String melding = String.format("omschrijving voor cat %s, code %s", cat, code);
      String descriptionMelding = "Onbekende " + melding;
      String description = null;
      String sql = "SELECT ref.OMSCHRIJVING, ref.DATUMAANVANG, ref.DATUMEINDE"
            + " FROM REF_STAMGEGEVENS ref"
            + " WHERE ref.CAT_CD = ? AND ref.CODE = ?"
            + " ORDER BY ref.DATUMAANVANG";

      LOG.debug("Bepaal " + melding);
      try (Connection conn = getDataSource().getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
         stmt.setString(1, cat);
         try (ResultSet rs = stmt.executeQuery()) {
            description = createDescriptionFromRS(rs);
         }
      } catch (Exception e) {
         LOG.debug("Sql: " + sql);
         UIUtils.handleError(e, "Fout bij ophalen omschrijving uit stamgegevens");
      }
      LOG.debug("Omschrijving: " + description);
      if (StringUtils.isEmpty(description)) {
         description = descriptionMelding;
      }
      LOG.debug("Omschrijving: " + description);
      return description;
   }
   private String createDescriptionFromRS(ResultSet rs) throws SQLException {
      StringBuilder description = new StringBuilder();
      while (rs.next()) {
         if (description.length() > 0) {
            description.append("\n");
         }
         description.append(rs.getString("OMSCHRIJVING"));
         String opm = rs.getString("DATUMEINDE");
         if (StringUtils.isNotEmpty(opm)) {
            description.append("* Be\u00EBindigd per ").append(opm);
         }
      }
      return description.toString();
   }

}
