package nl.uwv.pws.backend.dao;

import java.io.Serializable;

public class MenuPage implements Serializable {
   private String menuCode;
   private String name;
   private String url;
   private String iconName;
   private String description;

   /**
    * @return the menuCode
    */
   public String getMenuCode() {
      return menuCode;
   }

   /**
    * @param menuCode the menuCode to set
    */
   public void setMenuCode(final String menuCode) {
      this.menuCode = menuCode;
   }

   /**
    * @return the name
    */
   public String getName() {
      return name;
   }

   /**
    * @param naam the name to set
    */
   public void setName(final String name) {
      this.name = name;
   }

   /**
    * @return the url
    */
   public String getUrl() {
      return url;
   }

   /**
    * @param url the url to set
    */
   public void setUrl(final String url) {
      this.url = url;
   }

   /**
    * @return the iconName
    */
   public String getIconName() {
      return iconName;
   }

   /**
    * @param iconName the iconName to set
    */
   public void setIconName(final String iconName) {
      this.iconName = iconName;
   }

   /**
    * @return the description
    */
   public String getDescription() {
      return description;
   }

   /**
    * @param omschrijving the omschrijving to set
    */
   public void setDescription(final String description) {
      this.description = description;
   }

   /* (non-Javadoc)
    * @see java.lang.Object#toString()
    */
   @Override
   public String toString() {
      StringBuilder builder = new StringBuilder();
      builder.append("Page [menuCode=");
      builder.append(menuCode);
      builder.append(", name=");
      builder.append(name);
      builder.append(", url=");
      builder.append(url);
      builder.append(", iconName=");
      builder.append(iconName);
      builder.append(", omschrijving=");
      builder.append(description);
      builder.append("]");
      return builder.toString();
   }
}
