package nl.uwv.pws.backend.types;

import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.data.renderer.ComponentRenderer;
import com.vaadin.flow.data.renderer.Renderer;
import com.vaadin.flow.data.renderer.TemplateRenderer;
import com.vaadin.flow.function.ValueProvider;

import nl.uwv.pws.ui.components.DescriptionDialog;
import nl.uwv.pws.ui.util.FontSize;
import nl.uwv.pws.ui.util.TextColor;
import nl.uwv.pws.ui.util.UIUtils;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

public class PropertyFieldRenderer<T extends RowId> implements FieldRenderer<T> {
   private static final Logger LOG = LogManager.getLogger(PropertyFieldRenderer.class);

   private int last = 0;

   private int next() {
      return ++last;
   }

   @Override
   public Renderer<T> render(final Field field, final ValueProvider<T, ?> value) {
      String p = field.getPropertyWithDefault("p" + next());
      LOG.debug("PropertyFieldRenderer[" + p + "] : " + field + ", value=" + value);
      if (field.getType().equalsIgnoreCase("icon")) {
         return new ComponentRenderer<>((T t) -> createVaadinIcon(t, field));
      } else if (field.getFieldDescription() != null) {
         return new ComponentRenderer<>((T t) -> createLabel(p, t, field));
      }
      return TemplateRenderer.<T>of("[[item." + p + "]]").withProperty(p, value);
   }

   private Icon createVaadinIcon(final T t, final Field field) {
      VaadinIcon icon = null;
      String iconName = "QUESTION_CIRCLE_O";
      try {
         if (t instanceof ColumnList) {
            iconName = (String) ((ColumnList) t).getValue(field);
         }
         icon = VaadinIcon.valueOf(iconName);
      } catch (Exception e) {
         LOG.warn("Unable to create Vaadin Icon " + iconName + ", using default", e);
         icon = VaadinIcon.QUESTION_CIRCLE_O;
      }
      return icon.create();
   }

   private Label createLabel(final String p, final T t, final Field field) {
      String fieldValue = ((ColumnList) t).getFormattedValue(field);
      Button button = UIUtils.createButton(
            VaadinIcon.QUESTION, ButtonVariant.LUMO_ICON, ButtonVariant.LUMO_TERTIARY_INLINE
      );
      button.addClickListener(e -> DescriptionDialog.show(
            field.getFieldDescription().getProviderId(),
            field.getFieldDescription().getCategorie(),
            fieldValue
      ));
      Label label = UIUtils.createLabel(FontSize.S, TextColor.SECONDARY, fieldValue);
      label.setId(p);
      label.add(button);

      return label;
   }
}
