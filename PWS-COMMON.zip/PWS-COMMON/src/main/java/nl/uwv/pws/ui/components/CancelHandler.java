package nl.uwv.pws.ui.components;

import java.io.Serializable;

/**
 * Handler to implement for responding to cancel-actions in a {@link ConfirmDialog}.
 */
@FunctionalInterface
public interface CancelHandler extends Serializable {
   /**
    * Triggered if the user clicks the cancel button on a {@link ConfirmDialog} or if the dialog is canceled any other
    * way such as clicking the ESC button or clicking outside of the dialog.
    */
   public void canceled();
}
