package nl.uwv.pws.ui.components;

import com.vaadin.flow.component.AbstractField;
import com.vaadin.flow.component.HasValue;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.textfield.Autocomplete;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.binder.Binder;
import com.vaadin.flow.data.value.ValueChangeMode;
import nl.uwv.pws.ui.converters.BsnConverter;
import nl.uwv.pws.ui.model.BsnNumber;
import nl.uwv.pws.ui.validator.BsnValidator;
import org.apache.commons.lang.StringUtils;

/**
 * Field that can be used in a SearchBar to let the user enter a BSN number to use in the search.
 * This field will left-pad the number with zeroes and performs additional validations.
 */
@SuppressWarnings("java:S110") // Too many parents
public class BsnSearchField extends TextField implements HasPrepareBinding<BsnNumber> {
   private static final String BSN_ZOEK_PLACEHOLDER = "BSN";

   public BsnSearchField() {
      super.setPlaceholder(BSN_ZOEK_PLACEHOLDER);
      super.setWidth("20em");
      super.setPrefixComponent(new Icon(VaadinIcon.SEARCH));
      super.setAutocomplete(Autocomplete.OFF);
      super.setPattern(BsnNumber.VALIDATIE_PATTERN);
      super.setTitle("Zoek op bsn");
      super.setPreventInvalidInput(true);
      super.setRequired(true);
      super.setRequiredIndicatorVisible(true);
      super.addValueChangeListener(new ZeroPaddingValueChangeListener());
      super.setValueChangeMode(ValueChangeMode.ON_CHANGE);
   }

   public BsnSearchField(final String componentId) {
      this();
      super.setId(componentId);
   }

   @Override
   public <B> Binder.BindingBuilder<B, BsnNumber> prepareBinding(final Binder<B> binder) {
      return binder.forField(this)
            .asRequired("Een ingevuld zoekveld is verplicht")
            .withConverter(new BsnConverter())
            .withValidator(new BsnValidator());
   }

   /**
    * ValueChangeListener for the Bsn searchField that will zero-pad the value entered if it has less than the
    * expected number of characters.
    */
   private static class ZeroPaddingValueChangeListener
         implements HasValue.ValueChangeListener<AbstractField.ComponentValueChangeEvent<TextField, String>> {

      /**
       * {@inheritDoc}
       */
      @Override
      public void valueChanged(final AbstractField.ComponentValueChangeEvent<TextField, String> event) {
         String value = event.getValue();
         if (value != null && !value.isEmpty()) {
            event.getSource().setValue(StringUtils.leftPad(value, BsnNumber.AANTAL_TEKENS, '0'));
         }
      }
   }
}
