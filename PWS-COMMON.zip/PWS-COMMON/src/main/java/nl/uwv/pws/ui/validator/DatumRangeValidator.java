package nl.uwv.pws.ui.validator;

import java.time.LocalDate;

import com.vaadin.flow.data.binder.ValidationResult;
import com.vaadin.flow.data.binder.Validator;
import com.vaadin.flow.data.binder.ValueContext;

import nl.uwv.pws.ui.util.Messages;

public class DatumRangeValidator implements Validator<LocalDate> {

   public static final String MSGID_INCOMPLETE = ".range.incompleet";
   public static final String MSGID_RANGE_ERR = ".range.onjuist";
   private static final String MSG_INCOMPLETE = "Voor datumbereik is start en eind datum verplicht";
   private static final String MSG_RANGE_ERR =
         "De start datum moet gelijkzijn aan de einddatum of de eindatum moet groter zijn dan de startdatum";

   boolean validateStartDate;
   LocalDate startOrEndDate;
   String messagePrefix;
   String message;

   public DatumRangeValidator(final boolean validateStartDate, final LocalDate startOrEndDate) {
      this.validateStartDate = validateStartDate;
      this.startOrEndDate = startOrEndDate;
      this.messagePrefix = null;
   }

   public DatumRangeValidator withMelding(final String messagePrefix) {
      this.messagePrefix = messagePrefix;
      return this;
   }


   @Override
   public ValidationResult apply(final LocalDate value, final ValueContext context) {
      return isValid(value) ? ValidationResult.ok()
            : ValidationResult.error(message);
   }

   private boolean isValid(final LocalDate value) {
      LocalDate startDate = validateStartDate ? value : startOrEndDate;
      LocalDate endDate = validateStartDate ? startOrEndDate : value;
      message = null;

      boolean required = startDate == null ^ endDate == null;

      if (required && value == null) {
         message = messagePrefix != null ? Messages.get(messagePrefix + MSGID_INCOMPLETE) : MSG_INCOMPLETE;
      } else if (startDate != null && endDate != null && startDate.isAfter(endDate)) {
         message = messagePrefix != null ? Messages.get(messagePrefix + MSGID_RANGE_ERR) : MSG_RANGE_ERR;
      }
      return message == null;
   }
}
