package nl.uwv.pws.backend.validator;

import java.time.LocalDate;
import java.time.LocalDateTime;

public interface DateValidator {
   boolean isValid(final String dateStr);

   boolean isValid(final LocalDateTime localDateTime);

   boolean isValid(final LocalDate localDate);
}
