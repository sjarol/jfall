package nl.uwv.pws.backend.service;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.sql.DataSource;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.vaadin.flow.server.VaadinServletRequest;

import nl.uwv.pws.backend.lomo.LomoLogMessage;
import nl.uwv.pws.backend.lomo.LomoLogger;
import nl.uwv.pws.backend.lomo.LomoLoggerLog4j;

/**
 * Service voor het loggen van meldingen voor Lomo (UWV logging en monitoring)
 * <p>
 * Een specifiek lomo implementatie kan gebruikt worden mits deze de LomoLogger interface implementeerd.
 * Via addLomoLogger kan deze worden toegevoegd.
 * <p>
 * Voor ongedefinieerde LomoLogger wordt de default UwvlomoLogger gebruikt.
 */
@SuppressWarnings("serial")
public final class LomoLogService extends AbstractService implements LomoLogServiceIfc {
   public static final String PROGRAM_RELEASE = "program.release";
   public static final String PROGRAM_INSTANCE = "program.instance";
   public static final String PROGRAM_ENV = "program.env";
   public static final String PROGRAM_ID = "program.id";

   private static final Logger LOG = LogManager.getLogger(LomoLogService.class);

   public static final String PWS_PROGRAMID = "1600";
   public static final String ENV_LOMO_LOGGER = "lomoLogger";
   public static final String ENV_LOMO_DATASOURCE = "lomoDataSource";

   private static LomoLogServiceIfc instance = null;
   private Map<String, LomoLogger> lomoLoggers = new HashMap<>();
   private static boolean dsFailed = false;

   private LomoLogService() {
      this(getJndiName());
   }

   private LomoLogService(final String dsName) {
      super(dsName);
   }

   protected LomoLogService(DataSource dataSourceMock) {
      super(null);
      super.setDataSource(dataSourceMock);
   }

   /**
    * @return the jndiName
    */
   public static String getJndiName() {
      String jndiName = "";
      if (!isDsFailed()) {
         jndiName = getStringFromContext(ENV_LOMO_DATASOURCE, null);
         setDsFailed(StringUtils.isEmpty(jndiName));
      }
      return jndiName;
   }

   protected static boolean isDsFailed() {
      return dsFailed;
   }

   /**
    * @param failed
    */
   protected static void setDsFailed(boolean failed) {
      dsFailed = failed;
   }

   /**
    * @return the default Datasource for the lomo logging.
    */
   @Override
   public DataSource getLomoDataSource() {
      if (!isDsFailed()) {
         try {
            return getDataSource();
         } catch (Exception e) {
            setDsFailed(true);
            LOG.error(e.getClass().getName() + ": " + e.getMessage(), e);
         }
      }
      return null;
   }

   /**
    * @return de LomoLogger instance
    */
   public static LomoLogServiceIfc getInstance() {
      if (instance == null) {
         createInstance();
      }
      return instance;
   }

   /**
    * Maak een instantie van de LomoLogger aan.
    */
   protected static synchronized void createInstance() {
      LomoLogService service = new LomoLogService();
      service.init(PWS_PROGRAMID);
      instance = service;
   }

   private LomoLogger init(final String programId) {
      LomoLogger lomoLogger = getLomoLoggerFromEnv(ENV_LOMO_LOGGER, new LomoLoggerLog4j());
      addLomoLogger(programId, lomoLogger);

      return lomoLogger;
   }

   @Override
   public void addLomoLogger(final String programId, final LomoLogger lomoLogger) {
      lomoLogger.init(getLomoDataSource(), programId, getAppiId(programId));

      lomoLoggers.put(programId, lomoLogger);
   }

   /**
    * Logt een bericht in het LOMO log.
    *
    * @param programmaId
    * @param applicatieFunctie
    * @param message
    */
   @Override
   public void addLomoLog(final String programmaId, final String applicatieFunctie, final LomoLogMessage message) {
      try {
         LomoLogger lomoLogger = getLomoLogger(programmaId);
         lomoLogger.addLomoLog(getHttpServletRequest(), applicatieFunctie, message);
      } catch (Exception e) {
         LOG.warn(message.toString());
         if (LOG.isDebugEnabled()) {
            LOG.error("LOMOLOGGER exception!", e);
         } else {
            LOG.error("LOMOLOGGER exception " + e.getClass().getName() + ": " + e.getMessage());
         }
      }
   }

   private LomoLogger getLomoLogger(final String programmaId) {
      String programId = programmaId;
      if (StringUtils.isEmpty(programId)) {
         programId = getApplicationProperties().getProperty(PROGRAM_ID);
      }
      
      LomoLogger lomoLogger = lomoLoggers.get(programId);
      if (lomoLogger == null) {
         lomoLogger = init(programId);
      }
      return lomoLogger;
   }

   @SuppressWarnings("unchecked")
   private LomoLogger getLomoLoggerFromEnv(final String envName, final LomoLogger defaultLomoLogger) {
      try {
         String loggerName = getStringFromContext(envName, defaultLomoLogger.getClass().getName());
         LOG.info("Loading LomoLogger " + loggerName);

         Class<LomoLogger> lomoLoggerClass = (Class<LomoLogger>) Thread.currentThread().getContextClassLoader()
               .loadClass(loggerName);

         return lomoLoggerClass.getDeclaredConstructor().newInstance();
      } catch (Exception e) {
         LOG.error("Exceptie bij laden LomoLogger '" + envName + "': ", e);
      }
      return defaultLomoLogger;
   }

   private HttpServletRequest getHttpServletRequest() {
      return VaadinServletRequest.getCurrent().getHttpServletRequest();
   }
   
   private int getAppiId(final String programId) {
      Properties properties = getApplicationProperties();
      String readProgramId = properties.getProperty(PROGRAM_ID);
      if (!StringUtils.equals(programId, readProgramId)) {
         LOG.error("Mismatch programId met application.properties " + programId + " <> " + readProgramId);
      }
      return AuthorizationService.get().getAppiId(
            programId,
            properties.getProperty(PROGRAM_ENV),
            properties.getProperty(PROGRAM_INSTANCE),
            properties.getProperty(PROGRAM_RELEASE)
      );
   }

   protected Properties getApplicationProperties() {
      String propertiesFileName = "application.properties";
      Properties properties = readApplicationProperties(propertiesFileName);
      
      if (!arePropertiesValid(properties)) {
         properties = readApplicationProperties("lomo/" + propertiesFileName);
      }
      return properties;
   }
   
   protected static Properties readApplicationProperties(String propertiesFileName) {
      Properties properties = new Properties();
      ClassLoader loader = Thread.currentThread().getContextClassLoader();

      try (InputStream resourceStream = loader.getResourceAsStream(propertiesFileName)) {
         if (resourceStream != null) {
            properties.load(resourceStream);
         } else {
            LOG.debug("Properties niet gevonden: " + propertiesFileName);
         }
      } catch (Exception e) {
         LOG.error(e.getClass().getName() + ": " + e.getMessage(), e);
      }
      
      return properties;
   }

   protected static boolean arePropertiesValid(Properties properties) {
      if (properties.isEmpty()) {
         return false;
      }
      return isPropertyValid(properties, PROGRAM_ID) && isPropertyValid(properties, PROGRAM_ENV)
            && isPropertyValid(properties, PROGRAM_INSTANCE) && isPropertyValid(properties, PROGRAM_RELEASE);
   }

   protected static boolean isPropertyValid(Properties properties, String propertyName) {
      if (StringUtils.isBlank(properties.getProperty(propertyName))) {
         LOG.warn("Ontbrekende property voor " + propertyName);
         return false;
      }
      return true;
   }
   

}
