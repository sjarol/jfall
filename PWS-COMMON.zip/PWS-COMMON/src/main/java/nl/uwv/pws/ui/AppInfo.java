package nl.uwv.pws.ui;

import java.io.Serializable;

public interface AppInfo extends Serializable {

   /**
    * @return De implementatie versie van de applicatie
    */
   public String getImplementationVersion();

   /**
    * @return De implementatie titel van de applicatie
    */
   public String getImplementationTitle();

   /**
    * @return De specificatie titel van de applicatie
    */
   public String getSpecificationTitle();

   /**
    * @return De specificatie versie van de applicatie
    */
   public String getSpecificationVersion();

   /**
    * @return De build date van de applicatie
    */
   public String getBuildDate();
}
