window.pwsTooltipInit = function(tooltip, anchor, fixedPosition, source) {
   if (!source) {
      source = tooltip.parentElement;
   }
   source.addEventListener("mouseout", function () {
      // Hide tooltip on mouseout
      tooltip.classList.remove("pws-tooltip-visible")
   });
   source.addEventListener("mouseover", function () {
      // Make tooltip visible on mouseover, we need to this before the position-calculations because invisible elements
      // have size 0 x 0
      tooltip.classList.add("pws-tooltip-visible")

      // Calculate the position of the tooltip relative to the left top of the document and move it there
      const tooltipPosition = window.pwsTooltipCalculateTooltipPosition(tooltip, anchor, fixedPosition, source);
      tooltip.style.left = tooltipPosition.x + "px";
      tooltip.style.top = tooltipPosition.y + "px";
   });
}

window.pwsTooltipCalculateTooltipPosition = function(tooltip, anchor, fixedPosition, source) {
   // Get Tooltip width and height
   const tooltipWidth = tooltip.offsetWidth;
   const tooltipHeight = tooltip.offsetHeight;
   const sourceWidth = source.offsetWidth;
   const sourceHeight = source.offsetHeight;

   const sourceOffset = window.pwsTooltipGetOffset(source);

   if (!fixedPosition) {
      // Get viewPort dimensions
      const vw = window.innerWidth;
      const vh = window.innerHeight;

      // get position of source element relative to viewPort
      const viewportOffset = source.getBoundingClientRect();
      const leftSpace = viewportOffset.left;
      const rightSpace = vw - leftSpace - sourceWidth;
      const topSpace = viewportOffset.top;
      const bottomSpace = vh - topSpace - sourceHeight;

      // Clear positional classes since we need to determine this on runtime
      tooltip.classList.remove("pws-tooltip-top");
      tooltip.classList.remove("pws-tooltip-bottom");
      tooltip.classList.remove("pws-tooltip-left");
      tooltip.classList.remove("pws-tooltip-right");

      // Check where the tooltip would fit best
      const requiredHorizontalSpace = (tooltipWidth - sourceWidth) / 2;
      const requiredVerticalSpace = (tooltipHeight - sourceHeight) / 2;
      let fitsAbove = topSpace > tooltipHeight && leftSpace > requiredHorizontalSpace && rightSpace > requiredHorizontalSpace;
      let fitsBelow = bottomSpace > tooltipHeight && leftSpace > requiredHorizontalSpace && rightSpace > requiredHorizontalSpace;
      let fitsLeft = leftSpace > tooltipWidth && topSpace > requiredVerticalSpace && bottomSpace > requiredVerticalSpace;
      let fitsRight = rightSpace > tooltipWidth && topSpace > requiredVerticalSpace && bottomSpace > requiredVerticalSpace;
      if (!fitsAbove && !fitsBelow && !fitsLeft && !fitsRight) {
         const topRemainder = topSpace - tooltipHeight;
         const bottomRemainder = bottomSpace - tooltipHeight;
         const verticalRemainder = Math.max(topRemainder, bottomRemainder);
         const leftRemainder = leftSpace - tooltipWidth;
         const rightRemainder = rightSpace - tooltipHeight;
         const horizontalRemainder = Math.max(leftRemainder, rightRemainder);
         if (verticalRemainder >= horizontalRemainder) {
            fitsAbove = topRemainder >= bottomRemainder;
            fitsBelow = !fitsAbove;
         } else {
            fitsRight = rightRemainder >= leftRemainder;
            fitsLeft = !fitsRight;
         }
      }

      // Update anchor and class to represent the tooltip location
      if (fitsAbove) {
         anchor = "TOP_CENTER";
         tooltip.classList.add("pws-tooltip-top");
      } else if (fitsBelow) {
         anchor = "BOTTOM_CENTER";
         tooltip.classList.add("pws-tooltip-bottom");
      } else if (fitsRight) {
         anchor = "MID_RIGHT";
         tooltip.classList.add("pws-tooltip-right");
      } else if(fitsLeft) {
         anchor = "MID_LEFT";
         tooltip.classList.add("pws-tooltip-left");
      }
   }

   const sourceAnchor = window.pwsTooltipCalculateAnchorPosition(sourceOffset, anchor, sourceWidth, sourceHeight);
   let tooltipTop = 0;
   let tooltipLeft = 0;
   if (tooltip.classList.contains("pws-tooltip-top")) {
      // Tooltip forced to show above source component
      tooltipTop = Math.round(sourceAnchor.y - tooltipHeight - 13);
      tooltipLeft = Math.round(sourceAnchor.x - (tooltipWidth / 2));
   } else if (tooltip.classList.contains("pws-tooltip-bottom")) {
      // Tooltip forced to shown below source component
      tooltipTop = Math.round(sourceAnchor.y + 15);
      tooltipLeft = Math.round(sourceAnchor.x - (tooltipWidth / 2));
   } else if (tooltip.classList.contains("pws-tooltip-right")) {
      // Tooltip forced to show to the right of source component
      tooltipTop = Math.round(sourceAnchor.y - (tooltipHeight / 2));
      tooltipLeft = Math.round(sourceAnchor.x + 17);
   } else if (tooltip.classList.contains("pws-tooltip-left")) {
      // Tooltip forced to show to the left of source component
      tooltipTop = Math.round(sourceAnchor.y - (tooltipHeight / 2));
      tooltipLeft = Math.round(sourceAnchor.x - tooltipWidth - 15);
   }

   return {x: tooltipLeft, y: tooltipTop};
}

window.pwsTooltipCalculateAnchorPosition = function(offset, anchor, sourceWidth, sourceHeight) {
   let x = offset.left;
   let y = offset.top;
   if (anchor) {
      // Determine proper anchor point on source component
      if (anchor.startsWith("MID_")) {
         y += Math.round(sourceHeight / 2);
      } else if (anchor.startsWith("BOTTOM_")) {
         y += sourceHeight;
      }
      if (anchor.endsWith("_CENTER")) {
         x += Math.round(sourceWidth / 2);
      } else if (anchor.endsWith("_RIGHT")) {
         x += sourceWidth;
      }
   }
   return {x: x, y: y};
}

window.pwsTooltipGetOffset = function(element) {
   let left = 0;
   let top = 0;
   while (element && !isNaN(element.offsetLeft) && !isNaN(element.offsetTop)) {
      left += element.offsetLeft - element.scrollLeft;
      top += element.offsetTop - element.scrollTop;
      element = element.offsetParent;
   }
   // Returns offset with a translation of -10 to account for the Vaadin styling
   return {top: top - 10, left: left};
}
