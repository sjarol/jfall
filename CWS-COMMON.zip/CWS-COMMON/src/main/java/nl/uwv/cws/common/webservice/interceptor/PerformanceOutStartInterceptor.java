package nl.uwv.cws.common.webservice.interceptor;

import org.apache.cxf.message.Message;
import org.apache.cxf.phase.AbstractPhaseInterceptor;
import org.apache.cxf.phase.Phase;
import org.springframework.stereotype.Component;

@Component
public class PerformanceOutStartInterceptor extends AbstractPhaseInterceptor<Message> {

    public PerformanceOutStartInterceptor() {
        super(Phase.SETUP);
    }

    @Override
    public void handleMessage(Message message) {
        long startTime = System.currentTimeMillis();
        message.put("response.timing.start", startTime);
    }
}
