package nl.uwv.cws.common.dao.mapper;

import org.springframework.lang.Nullable;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import static nl.uwv.cws.common.util.NullValueUtil.*;

public abstract class CwsRowMapper<T> {
    private static final String EMPTY_COLUMN_LABEL_PREFIX = "";

    protected abstract T mapRow(ResultSet resultSet, List<String> attributen) throws SQLException;

    @Nullable
    protected String readApplicableString(List<String> attributen, String columnLabel, ResultSet resultSet) throws SQLException {
        return readApplicableString(attributen, EMPTY_COLUMN_LABEL_PREFIX, columnLabel, resultSet);
    }

    @Nullable
    protected String readApplicableString(List<String> attributen, String columnLabelPrefix, String columnLabel, ResultSet resultSet) throws SQLException {
        if(attributen.contains(columnLabel)){
            return resultSet.getString(columnLabelPrefix + columnLabel);
        } else {
            return null;
        }
    }

    @Nullable
    protected Date readApplicableDate(List<String> attributen, String columnLabel, ResultSet resultSet) throws SQLException {
        return readApplicableDate(attributen, EMPTY_COLUMN_LABEL_PREFIX, columnLabel, resultSet);
    }

    @Nullable
    protected Date readApplicableDate(List<String> attributen, String columnLabelPrefix, String columnLabel, ResultSet resultSet) throws SQLException {
        if(attributen.contains(columnLabel)){
            return resultSet.getDate(columnLabelPrefix + columnLabel);
        } else {
            return null;
        }
    }

    @Nullable
    protected Integer readApplicableInteger(List<String> attributen, String columnLabel, ResultSet resultSet) throws SQLException {
        return readApplicableInteger(attributen, EMPTY_COLUMN_LABEL_PREFIX, columnLabel, resultSet);
    }

    @Nullable
    protected Integer readApplicableInteger(List<String> attributen, String columnLabelPrefix, String columnLabel, ResultSet resultSet) throws SQLException {
        if(attributen.contains(columnLabel)){
            return resultSet.getInt(columnLabelPrefix + columnLabel);
        } else {
            return null;
        }
    }

    @Nullable
    protected Integer readApplicableNullableInteger(List<String> attributen, String columnLabel, ResultSet resultSet) throws SQLException {
        return readApplicableNullableInteger(attributen, EMPTY_COLUMN_LABEL_PREFIX, columnLabel, resultSet);
    }

    @Nullable
    protected Integer readApplicableNullableInteger(List<String> attributen, String columnLabelPrefix, String columnLabel, ResultSet resultSet) throws SQLException {
        if(attributen.contains(columnLabel)){
            return getIntegerOrNull(resultSet, columnLabelPrefix + columnLabel);
        } else {
            return null;
        }
    }

    @Nullable
    protected Long readApplicableNullableLong(List<String> attributen, String columnLabel, ResultSet resultSet) throws SQLException {
        return readApplicableNullableLong(attributen, EMPTY_COLUMN_LABEL_PREFIX, columnLabel, resultSet);
    }

    @Nullable
    protected Long readApplicableNullableLong(List<String> attributen, String columnLabelPrefix, String columnLabel, ResultSet resultSet) throws SQLException {
        if(attributen.contains(columnLabel)){
            return getLongOrNull(resultSet, columnLabelPrefix + columnLabel);
        } else {
            return null;
        }
    }

    @Nullable
    protected Double readApplicableNullableDouble(List<String> attributen, String columnLabel, ResultSet resultSet) throws SQLException {
        return readApplicableNullableDouble(attributen, EMPTY_COLUMN_LABEL_PREFIX, columnLabel, resultSet);
    }

    @Nullable
    protected Double readApplicableNullableDouble(List<String> attributen, String columnLabelPrefix, String columnLabel, ResultSet resultSet) throws SQLException {
        if(attributen.contains(columnLabel)){
            return getDoubleOrNull(resultSet, columnLabelPrefix + columnLabel);
        } else {
            return null;
        }
    }

    protected boolean isAttributeApplicable(List<String> attributen, String columnLabel){
        return attributen.contains(columnLabel);
    }
}
