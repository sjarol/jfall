package nl.uwv.cws.common.service;

import nl.uwv.cws.common.dao.configuratie.ConfiguratieDao;
import nl.uwv.cws.common.model.CwsCommonFoutmelding;
import nl.uwv.cws.common.model.configuratie.BaseConfiguratieGroepenGegevens;
import nl.uwv.cws.common.model.configuratie.Configuratie;
import nl.uwv.cws.common.model.configuratie.ConfiguratieKey;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDate;

import static nl.uwv.cws.common.exception.CwsCommonExceptionGenerator.functionalError;
import static nl.uwv.cws.common.model.CwsCommonConstants.DATE_FORMATTER;

@Component
public class ConfiguratieService <T, B extends BaseConfiguratieGroepenGegevens> {

    @Autowired
    private ConfiguratieDao<T, B> configuratieDao;

    public Configuratie<T, B> findByConfiguratieKey(ConfiguratieKey configuratieKey) {
        String contractNummer = configuratieKey.getContractNummer();
        String contractStartDate = configuratieKey.getContractStartDate();
        String versie = configuratieKey.getVersie();

        return configuratieDao.findByConfiguratieKey(contractNummer, contractStartDate, versie);
    }

    public void validateFoundConfiguratie(Configuratie<T, B> configuratie) {
        if (configuratie == null) {
            throw functionalError(CwsCommonFoutmelding.F010);
        } else if (!"DE".equals(configuratie.getStatus())) {
            throw functionalError(CwsCommonFoutmelding.F009);
        } else {
            String todayDateAsString = LocalDate.now().format(DATE_FORMATTER);
            Long todayDateAsLong = Long.valueOf(todayDateAsString);
            Long configStartDate = configuratie.getStartDate();
            Long configEndDate = configuratie.getEndDate();
            boolean configDateInvalidForToday = todayDateAsLong < configStartDate || todayDateAsLong > configEndDate;
            if (configDateInvalidForToday) {
                throw functionalError(CwsCommonFoutmelding.F009);
            }
        }
    }
}
