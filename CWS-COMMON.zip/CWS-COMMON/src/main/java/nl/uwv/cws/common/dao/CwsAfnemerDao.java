package nl.uwv.cws.common.dao;

import nl.uwv.common.afnemermodel.domain.Afnemer;
import nl.uwv.cws.common.dao.mapper.CwsAfnemerRowMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Component;

import java.util.List;

import static nl.uwv.cws.common.util.DaoUtil.findOneOrNone;

/**
 * Dao class to access afnemer information specific only for CWS needs. This can seem to be a duplicate of AfnemerDao
 * of afnemermodel library. The need to have this class is to allow independency of afnemermodel when the library does
 * not have the necessary functionality for CWS.
 */
@Component
public class CwsAfnemerDao {

    @Autowired
    @Qualifier("ppls_cws")
    private NamedParameterJdbcTemplate jdbcTemplate;

    @Autowired
    private CwsAfnemerRowMapper rowMapper;

    public Afnemer findOneAfnemerByCconId(Long cconId) {
        String sql =
            " select" +
            "    afn.afn_cd," +
            "    afn.ind_vip" +
            " from CWS_CONFIGURATIE CC" +
            "    INNER JOIN AFN_CONTRACT ac" +
            "      ON ac.contract_id = cc.contract_id" +
            "      AND ac.his_dat_in = cc.cont_his_dat_in" +
            "    INNER JOIN AFN_AFNEMER afn" +
            "      ON ac.afn_cd_afnemer = afn.afn_cd" +
            " where" +
            "    cc.ccon_id = :cconId";
        SqlParameterSource namedParameters = new MapSqlParameterSource().addValue("cconId", cconId);
        List<Afnemer> results = jdbcTemplate.query(sql, namedParameters, rowMapper);

        String errorMessage = "Meerdere afnemers gevonden voor ID configuratie: " + cconId;
        return findOneOrNone(errorMessage, results);
    }
}

