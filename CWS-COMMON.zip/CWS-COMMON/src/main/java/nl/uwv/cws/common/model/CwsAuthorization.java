package nl.uwv.cws.common.model;

import lombok.Builder;
import lombok.Getter;

@Builder
@Getter
public class CwsAuthorization {
    private String username;
    private String oin;
    private boolean isBeheerder;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        CwsAuthorization that = (CwsAuthorization) o;

        if (isBeheerder != that.isBeheerder) return false;
        if (username != null ? !username.equals(that.username) : that.username != null) return false;
        return oin != null ? oin.equals(that.oin) : that.oin == null;
    }

    @Override
    public int hashCode() {
        int result = username != null ? username.hashCode() : 0;
        result = 31 * result + (oin != null ? oin.hashCode() : 0);
        result = 31 * result + (isBeheerder ? 1 : 0);
        return result;
    }
}
