package nl.uwv.cws.common.webservice.rule;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import nl.uwv.cws.common.dao.DataMonitorDao;
import nl.uwv.cws.common.exception.CwsCommonExceptionGenerator;
import nl.uwv.cws.common.exception.CwsResponseXsdInvalidException;
import nl.uwv.cws.common.model.rule.AttributeRuleProperties;
import nl.uwv.cws.common.model.rule.CwsAttributeRule;
import nl.uwv.cws.common.model.rule.CwsXsdPattern;
import nl.uwv.cws.common.model.rule.XsdInvalidDataCollector;
import nl.uwv.cws.common.webservice.rule.transformer.RuleValueTransformer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import static nl.uwv.cws.common.util.ConverterUtil.OBJECT_MAPPER;
import static org.apache.commons.lang3.StringUtils.capitalize;

@Getter
@Slf4j
public class CwsRuleExecutor <T extends CwsAttributeRule> {

    private final String jaxbRootResponseCanonicalName;

    @Autowired
    private DataMonitorDao dataMonitorDao;
    @Autowired
    private CwsRulesHolder<T> cwsRulesHolder;
    @Autowired
    private List<RuleValueTransformer> ruleValueTransformers;

    @Resource(name = "requestScopedXsdInvalidDataCollector")
    private XsdInvalidDataCollector invalidDataCollector;

    // NOTE: Use @Autowired so that the transformers are managed by Spring. Transform to ruleTransformerReferences to collect transformer easier.
    private final Map<CwsAttributeRule, RuleValueTransformer> ruleTransformerReferences = new HashMap<>();

    public CwsRuleExecutor(final String jaxbRootResponseCanonicalName) {
        if (!StringUtils.hasText(jaxbRootResponseCanonicalName)) {
            throw new IllegalArgumentException("Argument jaxbRootResponseCanonicalName should not be null");
        }

        this.jaxbRootResponseCanonicalName = jaxbRootResponseCanonicalName;
    }

    @PostConstruct
    public void mapRuleValueTransformer() {
        ruleValueTransformers.forEach(transformer -> {
            if (ruleTransformerReferences.containsKey(transformer.getTransformRule())) {
                throw new IllegalStateException("Duplicate Transformer Rule found");
            }
            ruleTransformerReferences.put(transformer.getTransformRule(), transformer);
        });
    }

    public void setTransformedValue(Object targetJaxbObject, String attributeName, Object value) {
        Class<?> targetJaxbClass = targetJaxbObject.getClass();
        String capitalizedAttributeName = capitalize(attributeName);
        Method method = getSetterMethod(attributeName, targetJaxbClass, capitalizedAttributeName);

        String canonicalName = targetJaxbClass.getCanonicalName();
        final int chainNamePrefixSizeToRemove = jaxbRootResponseCanonicalName.length() + 1;
        String attributeChainName = canonicalName.substring(chainNamePrefixSizeToRemove).concat(".").concat(capitalizedAttributeName);

        AttributeRuleProperties<T> attributeRuleProperties = cwsRulesHolder.getAttributeRulePropertiesByAttribute(attributeChainName);
        Object transformedValue = transformValueUsingRule(value, attributeRuleProperties);

        if (attributeRuleProperties.isNeedXsdCheck()) {
            executeXsdValidation(attributeChainName, attributeRuleProperties, transformedValue);
        }
        try {
            method.invoke(targetJaxbObject, transformedValue);
        } catch (IllegalAccessException | InvocationTargetException e) {
            throw CwsCommonExceptionGenerator.technicalError("Class method invocation failure", e);
        }
    }

    private Method getSetterMethod(String attributeName, Class<?> targetJaxbClass, String capitalizedAttributeName) {
        String methodName = "set" + capitalizedAttributeName;
        Class<?> attributeDataType;
        try {
            Field attributeField = targetJaxbClass.getDeclaredField(attributeName);
            attributeDataType = attributeField.getType();
        } catch (NoSuchFieldException e) {
            throw CwsCommonExceptionGenerator.technicalError("Class field mismatched", e);
        }
        Method method;
        try {
            method = targetJaxbClass.getMethod(methodName, attributeDataType);
        } catch (NoSuchMethodException e) {
            throw CwsCommonExceptionGenerator.technicalError("Class method mismatched", e);
        }
        return method;
    }

    private Object transformValueUsingRule(Object methodArgument, AttributeRuleProperties<T> attributeRuleProperties) {
        CwsAttributeRule rule = attributeRuleProperties.getRule();
        RuleValueTransformer valueTransformer = ruleTransformerReferences.get(rule);
        return valueTransformer.transform(methodArgument, attributeRuleProperties);
    }

    private void executeXsdValidation(String attributeChainName, AttributeRuleProperties<T> attributeRuleProperties, Object transformedValue) {
        boolean anyXsdViolation = anyXsdViolation(attributeRuleProperties, transformedValue);
        if (anyXsdViolation) {
            String expectedMessage = generateExpectedMessage(attributeRuleProperties.getSizeMin(), attributeRuleProperties.getSizeMax(), attributeRuleProperties.isRequired(), attributeRuleProperties.getPattern());
            invalidDataCollector.addXsdError(attributeChainName, transformedValue, expectedMessage);
        }
    }

    private boolean anyXsdViolation(AttributeRuleProperties<T> attributeRuleProperties, Object transformedValue) {
        if (attributeRuleProperties.isRequired() && transformedValue == null) {
            return true;
        } else if (!attributeRuleProperties.isRequired() && transformedValue == null) {
            return false;
        }

        boolean hasSizeConstraint = attributeRuleProperties.getSizeMin() != null || attributeRuleProperties.getSizeMax() != null;
        if (hasSizeConstraint && violateSizeConstraint(attributeRuleProperties, transformedValue)) {
            return true;
        }

        if (attributeRuleProperties.getPattern() != null) {
            String transformedStringValue = String.valueOf(transformedValue);
            Pattern pattern = cwsRulesHolder.getPatternByEnum(attributeRuleProperties.getPattern());
            boolean valueMismatchPattern = !pattern.matcher(transformedStringValue).matches();
            if (valueMismatchPattern) {
                return true;
            }
        }

        if (attributeRuleProperties.getDecimalMin() != null && violateDecimalMinConstraint(attributeRuleProperties, transformedValue)) {
            return true;
        }

        // NOTE: Digits constraint must contain integer & fraction parts. So || (or operator) is used here.
        boolean hasDigitsConstraint = attributeRuleProperties.getDigitsInteger() != null || attributeRuleProperties.getDigitsFraction() != null;
        return hasDigitsConstraint && violateDigitsConstraint(attributeRuleProperties, transformedValue);
    }

    private boolean violateSizeConstraint(AttributeRuleProperties<T> attributeRuleProperties, Object transformedValue) {
        Class<?> transformedValueClass = transformedValue.getClass();
        if (transformedValueClass.equals(String.class)) {
            String transformedStringValue = (String) transformedValue;
            if (attributeRuleProperties.getSizeMin() != null) {
                boolean valueLowerThanSizeMin = transformedStringValue.length() < attributeRuleProperties.getSizeMin();
                if (valueLowerThanSizeMin) {
                    return true;
                }
            }
            if (attributeRuleProperties.getSizeMax() != null) {
                return transformedStringValue.length() > attributeRuleProperties.getSizeMax();
            }
        }
        return false;
    }

    private boolean violateDecimalMinConstraint(AttributeRuleProperties<T> attributeRuleProperties, Object transformedValue) {
        BigDecimal transformedAsBigDecimal = getBigDecimalValue(transformedValue);

        boolean valueIsNotADigit = transformedAsBigDecimal == null;
        if (valueIsNotADigit) {
            return true;
        }

        return transformedAsBigDecimal.doubleValue() < attributeRuleProperties.getDecimalMin().doubleValue();
    }

    private boolean violateDigitsConstraint(AttributeRuleProperties<T> attributeRuleProperties, Object transformedValue) {
        BigDecimal transformedAsBigDecimal = getBigDecimalValue(transformedValue);

        if(transformedAsBigDecimal != null) {
            int integerPartLength = transformedAsBigDecimal.precision() - transformedAsBigDecimal.scale();
            int maxIntegerPartLength = attributeRuleProperties.getDigitsInteger() - attributeRuleProperties.getDigitsFraction();
            boolean integerLongerThanMaximum = integerPartLength > maxIntegerPartLength;
            if (integerLongerThanMaximum) {
                return true;
            }

            return transformedAsBigDecimal.scale() > attributeRuleProperties.getDigitsFraction();
        }

        return false;
    }

    private BigDecimal getBigDecimalValue(Object transformedValue) {
        BigDecimal transformedAsBigDecimal = null;
        if (transformedValue instanceof BigDecimal) {
            transformedAsBigDecimal = (BigDecimal) transformedValue;
        } else if (transformedValue instanceof Number) {
            transformedAsBigDecimal = (new BigDecimal(String.valueOf(transformedValue))).stripTrailingZeros();
        } else if (transformedValue instanceof CharSequence) {
            try {
                transformedAsBigDecimal = new BigDecimal(String.valueOf(transformedValue));
            } catch (NumberFormatException e) {
                log.error("Ongeldige nummer", e);
            }
        }
        return transformedAsBigDecimal;
    }

    private String generateExpectedMessage(Integer minSize, Integer maxSize, boolean required, CwsXsdPattern expectedPattern) {
        StringBuilder expectedBuilder = new StringBuilder();
        if (required) {
            expectedBuilder.append("Required(NotNull);");
        }
        if (minSize != null) {
            expectedBuilder.append("MinSize: ").append(minSize).append(";");
        }
        if (maxSize != null) {
            expectedBuilder.append("MaxSize: ").append(maxSize).append(";");
        }
        if (expectedPattern != null) {
            expectedBuilder.append("Pattern: '").append(expectedPattern.getPattern()).append("' (").append(expectedPattern.name()).append(")");
        }
        return expectedBuilder.toString();
    }

    public void processXsdValidationResult(final String bsn, final String requestStartDate, final String requestEndDate, final String beschouwingsmoment) throws CwsResponseXsdInvalidException {
        boolean hasXsdError = !invalidDataCollector.getXsdErrors().isEmpty();
        if (hasXsdError) {
            Map<String, Object> xsdFoutLogMap = buildXsdFoutLogMap(requestStartDate, requestEndDate, beschouwingsmoment);

            processResults(bsn, xsdFoutLogMap);
        }
    }

    public void processXsdValidationResult(final String identifier) throws CwsResponseXsdInvalidException {
        boolean hasXsdError = !invalidDataCollector.getXsdErrors().isEmpty();
        if (hasXsdError) {
            Map<String, Object> xsdFoutLogMap = buildXsdFoutLogMap();

            processResults(identifier, xsdFoutLogMap);
        }
    }

    public void processXsdValidationResult(final String identifier, final String beschouwingsmoment) throws CwsResponseXsdInvalidException {
        boolean hasXsdError = !invalidDataCollector.getXsdErrors().isEmpty();
        if (hasXsdError) {
            Map<String, Object> xsdFoutLogMap = buildXsdFoutLogMap(null, null, beschouwingsmoment);

            processResults(identifier, xsdFoutLogMap);
        }
    }

    private void processResults(final String identifier, final Map<String, Object> xsdFoutLogMap) throws CwsResponseXsdInvalidException {
        String xsdFoutLog = null;
        try {
            xsdFoutLog = OBJECT_MAPPER.writeValueAsString(xsdFoutLogMap)
                    // NOTE: OBJECT_MAPPER uses double backslashes to escape backslash. This looks bad on xsdFoutLog. Only apply this for printing in log, otherwise the object cannot be parsed back to Object.
                    .replace("\\\\", "\\");
            dataMonitorDao.keepRecordOfXsdErrorOnResponse(identifier, xsdFoutLog);
        } catch (Exception e) {
            // Alleen melden dat het niet gelukt is om op te slaan, maar stop niet het samenstellen van antwoordbericht.
            log.error("Kan de xsd foutmelding niet opslaan in database. XSD foutmelding: '" + xsdFoutLog + "'. Opgetreden error message: " + e.getMessage());
        }
        throw CwsCommonExceptionGenerator.xsdResponseError();

    }

    private Map<String, Object> buildXsdFoutLogMap(final String requestStartDate, final String requestEndDate, final String beschouwingsmoment) {
        Map<String, Object> xsdFoutLogMap = new HashMap<>();
        xsdFoutLogMap.put("selectieStart", requestStartDate);
        xsdFoutLogMap.put("selectieEnd", requestEndDate);
        if(StringUtils.hasText(beschouwingsmoment)) {
            xsdFoutLogMap.put("beschouwingsmoment", beschouwingsmoment);
        }
        xsdFoutLogMap.put("xsdErrors", invalidDataCollector.getXsdErrors());
        return xsdFoutLogMap;
    }

    private Map<String, Object> buildXsdFoutLogMap() {
        Map<String, Object> xsdFoutLogMap = new HashMap<>();
        xsdFoutLogMap.put("xsdErrors", invalidDataCollector.getXsdErrors());
        return xsdFoutLogMap;
    }
}
