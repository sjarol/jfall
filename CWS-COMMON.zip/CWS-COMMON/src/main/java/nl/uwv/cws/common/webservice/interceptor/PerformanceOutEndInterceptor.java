package nl.uwv.cws.common.webservice.interceptor;

import lombok.extern.slf4j.Slf4j;
import nl.uwv.commons.ws.UwvPerformanceLogger;
import nl.uwv.cws.common.performance.PerformanceTracker;
import org.apache.cxf.message.Message;
import org.apache.cxf.phase.AbstractPhaseInterceptor;
import org.apache.cxf.phase.Phase;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

import static nl.uwv.cws.common.model.CwsCommonConstants.DATE_TIME_FORMATTER;

@Slf4j
@Component
public class PerformanceOutEndInterceptor extends AbstractPhaseInterceptor<Message> {

    @Autowired
    private PerformanceTracker performanceTracker;
    @Autowired
    private UwvPerformanceLogger performanceLogger;

    public PerformanceOutEndInterceptor() {
        super(Phase.SEND);
    }

    @Override
    public void handleMessage(Message message) {
        Long startTime = (Long) message.getExchange().getOutMessage().remove("response.timing.start");
        if (startTime != null) {
            long executionTime = System.currentTimeMillis() - startTime;
            performanceTracker.track("04-OutgoingInterceptors", executionTime);
        } else {
            log.debug("OutgoingInterceptors timer not found");
        }

        Long webserviceStartTime = (Long) message.getExchange().getInMessage().remove("webservice.timing.start");
        if (webserviceStartTime != null) {
            long webserviceExecutionTime = System.currentTimeMillis() - webserviceStartTime;
            performanceLogger.logPerformance(webserviceExecutionTime);
            performanceTracker.track("01-CompleteWebservice", webserviceExecutionTime);
        } else {
            log.debug("Webservice timer not found");
        }

        final String endTimeService = LocalDateTime.now().format(DATE_TIME_FORMATTER);
        log.info(String.format("Eindtijd service: %s", endTimeService));
    }
}