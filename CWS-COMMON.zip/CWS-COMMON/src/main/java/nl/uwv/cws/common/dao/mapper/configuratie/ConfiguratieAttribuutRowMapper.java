package nl.uwv.cws.common.dao.mapper.configuratie;

import nl.uwv.cws.common.model.configuratie.ConfiguratieAttribuut;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

@Component
public class ConfiguratieAttribuutRowMapper implements RowMapper<ConfiguratieAttribuut> {

    @Override
    public ConfiguratieAttribuut mapRow(ResultSet resultSet, int i) throws SQLException {
    	ConfiguratieAttribuut configuratieAttribuut = new ConfiguratieAttribuut();
    	configuratieAttribuut.setId(resultSet.getString("META_COL_ID"));
    	configuratieAttribuut.setParentId(resultSet.getString("PARENT_ID"));
    	configuratieAttribuut.setAttributeName(resultSet.getString("TECH_NAAM"));
    	configuratieAttribuut.setTable(resultSet.getString("BRON_TABEL"));
    	configuratieAttribuut.setColumn(resultSet.getString("BRON_RUBRIEK"));
        return configuratieAttribuut;
    }

}
