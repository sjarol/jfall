package nl.uwv.cws.common.model.rule;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public enum CwsXsdPattern {
    ISO_DATUM(
        "([0-9]{4}((0[1-9])|(1[0-2]))((0[1-9])|(([1-2][0-9])|(3[0-1]))))",
        "Jaar: 0000-9999; Maand: 01-12; Dag: 01-31"
    ),
    GEEN_GETALLEN("\\D*"),
    CODE_APPLICATIE_MELDING("[A-Z0-9]*"),
    ALLEEN_GETALLEN("\\d*"),
    NUL_TOT_EN_MET_NEGEN("[0-9]*"),
    AANTAL_SV_DAGEN("[0-9]{1,3}"),
    AANTAL_VERLOONDE_UREN("[\\-+]?[0-9]{1,5}"),
    AANTAL_CONTRACT_UREN_PER_WEEK("[\\-+]?[0-9]{1,3}[.][0-9]{2}"),
    A_TOT_EN_MET_Z("[A-Z]*"),
    A_TOT_EN_MET_F("[A-F]*"),
    POSTCODE_NL("[1-9][0-9]{3}[A-Z]{2}"),
    DATUMTIJD_BESCHOUWING("[1-2][0-9]{3}(0[1-9]|1[0-2])(0[1-9]|[1-2][0-9]|3[0-1])(([0-1][0-9])|(2[0-3]))([0-5][0-9]){2}[0-9]{6}"),


    ENKEL_NUL_TOT_EN_MET_NEGEN("[0-9]"),
    A_TOT_EN_MET_Z_UP_CASE("[A-Z]*"),
    A_TOT_EN_MET_Z_UPLOW_CASE("[a-zA-Z]*"),
    ENKEL_A_TOT_EN_MET_Z_UPLOW_CASE("[a-zA-Z]"),
    CODE_HUWELIJKS("[A-Z\\.]*"),
    ENKEL_NUL_TOT_EN_MET_ZEVEN("[0-7]");



    private static final Map<String, CwsXsdPattern> allPatternMap = new HashMap<>();

    private String pattern;
    private String description;
    CwsXsdPattern(String pattern) {
        this.pattern = pattern;
    }
    CwsXsdPattern(String pattern, String description) {
        this.pattern = pattern;
        this.description = description;
    }

    public String getPattern() {
        return pattern;
    }

    public static CwsXsdPattern findByPattern(String pattern) {
        if (allPatternMap.isEmpty()) {
            buildPatternMap();
        }
        return allPatternMap.get(pattern);
    }

    private static void buildPatternMap() {
        Arrays.stream(CwsXsdPattern.values())
            .forEach(cwsXsdPattern -> allPatternMap.put(cwsXsdPattern.getPattern(), cwsXsdPattern));
    }
}
