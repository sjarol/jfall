package nl.uwv.cws.common.webservice.rule;

import com.fasterxml.jackson.databind.JavaType;
import nl.uwv.cws.common.model.rule.AttributeRuleProperties;
import nl.uwv.cws.common.model.rule.CwsAttributeRule;
import nl.uwv.cws.common.model.rule.CwsXsdPattern;

import java.util.*;
import java.util.regex.Pattern;

import static java.util.stream.Collectors.joining;
import static nl.uwv.cws.common.util.ConverterUtil.OBJECT_MAPPER;

public class CwsRulesHolder <T extends CwsAttributeRule> {
    private final Map<String, AttributeRuleProperties<T>> groupedAttributeRules = new HashMap<>();
    private final Map<CwsXsdPattern, Pattern> cachedPatterns = new EnumMap<>(CwsXsdPattern.class);

    public CwsRulesHolder(Properties properties, Class<T> cwsRuleClass) {
        final Map<String, Map<String, Object>> groupedAttributeRuleMap = new HashMap<>();
        properties.entrySet()
            .stream()
            .filter(entry -> !((String) entry.getKey()).startsWith("header"))
            .forEach(entry -> {
                String key = (String) entry.getKey();
                Object value = entry.getValue();
                String[] keyChainNamePieces = key.split("\\.");
                String ruleKey = keyChainNamePieces[keyChainNamePieces.length - 1];
                String attributeChainName = Arrays.stream(keyChainNamePieces)
                    .limit(keyChainNamePieces.length - 1L)
                    .collect(joining("."));

                Map<String, Object> attributeRuleMap = groupedAttributeRuleMap.computeIfAbsent(attributeChainName, mapKey -> new HashMap<>());
                attributeRuleMap.put(ruleKey, value);
            });

        final Set<CwsXsdPattern> allCwsXsdPatterns = new HashSet<>();
        groupedAttributeRuleMap.forEach((key, attributeRuleMap) -> {
            JavaType type = OBJECT_MAPPER.getTypeFactory().constructParametricType(AttributeRuleProperties.class, cwsRuleClass);
            AttributeRuleProperties<T> attributeRuleProperties = OBJECT_MAPPER.convertValue(attributeRuleMap, type);

            CwsXsdPattern cwsXsdPattern = attributeRuleProperties.getPattern();
            if (cwsXsdPattern != null) {
                allCwsXsdPatterns.add(cwsXsdPattern);
            }
            groupedAttributeRules.put(key, attributeRuleProperties);
        });

        allCwsXsdPatterns.forEach(cwsXsdPattern -> cachedPatterns.put(cwsXsdPattern, Pattern.compile(cwsXsdPattern.getPattern())));
    }

    public AttributeRuleProperties<T> getAttributeRulePropertiesByAttribute(String attributeChainName) {
        return groupedAttributeRules.get(attributeChainName);
    }

    public Pattern getPatternByEnum(CwsXsdPattern pattern) {
        return cachedPatterns.get(pattern);
    }
}
