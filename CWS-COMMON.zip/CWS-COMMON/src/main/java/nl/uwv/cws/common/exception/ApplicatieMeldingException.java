package nl.uwv.cws.common.exception;

import nl.uwv.cws.common.model.Foutmelding;

import java.io.Serializable;

public class ApplicatieMeldingException extends RuntimeException implements Serializable {

    private final transient Foutmelding foutmelding;

    public ApplicatieMeldingException(Foutmelding foutmelding) {
        this.foutmelding = foutmelding;
    }

    public Foutmelding getFoutmelding() {
        return foutmelding;
    }
}
