package nl.uwv.cws.common.webservice.interceptor;

import lombok.extern.slf4j.Slf4j;
import nl.uwv.cws.common.model.CwsCommonConstants;
import nl.uwv.cws.common.performance.PerformanceTracker;
import org.apache.cxf.binding.soap.SoapMessage;
import org.apache.cxf.binding.soap.interceptor.AbstractSoapInterceptor;
import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.phase.Phase;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.xml.namespace.QName;

@Slf4j
@Component
public class CwsOutFaultInterceptor extends AbstractSoapInterceptor {

    @Autowired
    private PerformanceTracker performanceTracker;

    public CwsOutFaultInterceptor() {
        super(Phase.MARSHAL);
    }

    @Override
    public void handleMessage(SoapMessage message) {
        Fault fault = (Fault) message.getContent(Exception.class);
        String faultErrorMessage = fault.getMessage();

        boolean requestNamespaceInvalid = faultErrorMessage.startsWith("Message part") &&
            faultErrorMessage.contains("CwsNatuurlijkPersoonRequest was not recognized");

        StackTraceElement lastStackTraceElement = fault.getStackTrace()[0];
        boolean requestHeaderIsInvalid =
                lastStackTraceElement.getClassName().equals("org.apache.cxf.binding.soap.interceptor.SoapHeaderInterceptor")
                        && lastStackTraceElement.getMethodName().equals("validateHeader")
                        && faultErrorMessage.contains("caused by: org.xml.sax.SAXParseException");
        boolean requestBodyIsInvalid =
                lastStackTraceElement.getClassName().equals("org.apache.cxf.jaxb.JAXBEncoderDecoder")
                        && lastStackTraceElement.getMethodName().equals("unmarshall");
        String errorMessageInXml = null;
        if (requestNamespaceInvalid || requestHeaderIsInvalid || requestBodyIsInvalid) {
            log.warn(String.format("Soap error ontvangen voor inkomend bericht. Error message: %s", faultErrorMessage));
            errorMessageInXml = "Het vraagbericht voldoet niet aan het xsd";
        } else if (CwsCommonConstants.XSD_RESPONSE_ERROR_MESSAGE_INDICATOR.equals(faultErrorMessage)) {
            log.warn(String.format("Soap error ontvangen voor uitgaand bericht. Error message: %s", faultErrorMessage));
            errorMessageInXml = "Het antwoordbericht voldoet niet aan het xsd";
        } else {
            log.warn(String.format("Soap error ontvangen voor bericht. Error message: %s", faultErrorMessage));
        }

        fault.setStatusCode(500);
        fault.setFaultCode(new QName("Server"));
        fault.setMessage(errorMessageInXml);
        message.setContent(Exception.class, fault);

        Long webserviceStartTime = (Long) message.getExchange().getInMessage().remove("webservice.timing.start");
        if (webserviceStartTime != null) {
            long webserviceExecutionTime = System.currentTimeMillis() - webserviceStartTime;
            performanceTracker.track("01-CompleteWebservice", webserviceExecutionTime);
        } else {
            log.debug("Webservice timer not found");
        }
    }
}
