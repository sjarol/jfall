package nl.uwv.cws.common.model.configuratie;

public interface BaseCwsFilterType {
    String filterName();
    String levCode();
}
