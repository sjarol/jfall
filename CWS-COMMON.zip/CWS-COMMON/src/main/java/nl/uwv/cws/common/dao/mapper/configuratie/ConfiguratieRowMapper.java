package nl.uwv.cws.common.dao.mapper.configuratie;

import nl.uwv.cws.common.model.configuratie.BaseConfiguratieGroepenGegevens;
import nl.uwv.cws.common.model.configuratie.Configuratie;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

@Component
public class ConfiguratieRowMapper <T, B extends BaseConfiguratieGroepenGegevens> implements RowMapper<Configuratie<T, B>> {

    @Override
    public Configuratie<T, B> mapRow(ResultSet resultSet, int i) throws SQLException {
        Configuratie<T, B> configuratie = new Configuratie<>();
        configuratie.setCconId(resultSet.getLong("CCON_ID"));
        configuratie.setContractId(resultSet.getLong("CONTRACT_ID"));
        configuratie.setContractStartDate(resultSet.getLong("CONT_HIS_DAT_IN"));
        configuratie.setNaam(resultSet.getString("NAAM"));
        configuratie.setVersion(resultSet.getLong("VERSION"));
        configuratie.setStatus(resultSet.getString("STATUS"));
        configuratie.setStartDate(resultSet.getLong("HIS_DAT_IN"));
        configuratie.setEndDate(resultSet.getLong("HIS_DAT_END"));
        configuratie.setStartTransactionTimestamp(resultSet.getDate("HIS_TS_IN"));
        configuratie.setEndTransactionTimestamp(resultSet.getDate("HIS_TS_END"));

        return configuratie;
    }
}
