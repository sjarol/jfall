package nl.uwv.cws.common.model.configuratie;

import lombok.Data;

import java.util.Date;

@Data
public class Configuratie<T, U extends BaseConfiguratieGroepenGegevens> {
    private Long cconId;
    private Long contractId;
    private Long contractStartDate;
    private String naam;
    private Long version;
    private String status;
    private Long startDate;
    private Long endDate;
    private Date startTransactionTimestamp;
    private Date endTransactionTimestamp;

    protected T soortSelectie;
    protected U groepenGegevens;
}
