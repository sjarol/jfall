package nl.uwv.cws.common.config;

import nl.uwv.appconf.dao.NonCoreFuncDao;
import nl.uwv.appconf.spring.DbPropertyLoader;
import nl.uwv.commons.ws.UwvPerformanceLogger;
import nl.uwv.commons.ws.UwvQueryLogger;
import nl.uwv.cws.common.model.CwsCommonConstants;
import nl.uwv.cws.common.model.querylog.QueryLogEntry;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.ImportResource;

import javax.sql.DataSource;
import java.util.List;
import java.util.Properties;

@ImportResource({"classpath:/nl/uwv/appconf/resources/applicationContext.xml",
        "classpath:/nl/uwv/appconf/resources/hibernateApplicationContext.xml"})
public abstract class BaseLegacyConfig {

    @Value("${program.id}")
    private String programId;
    @Value("${program.env}")
    private String programEnv;
    @Value("${program.instance}")
    private String programInstance;
    @Value("${program.release}")
    private String programRelease;

    public UwvQueryLogger setupQueryLogger(DataSource dataSource, List<QueryLogEntry> queryLogEntryList) {
        UwvQueryLogger queryLogger = new UwvQueryLogger();
        queryLogger.setDataSource(dataSource);
        queryLogger.setProgramId(programId);

        QueryLogEntry queryLogEntryContractId = QueryLogEntry.builder()
                .referenceKey(CwsCommonConstants.QUERYLOG_REQUEST_CONTRACT_ID)
                .logTableName("WEBSERVICE_REQUEST")
                .logTableColumn("CONTRACT_ID")
                .columnValuePattern("^[0-9]+$")
                .build();
        queryLogEntryList.add(queryLogEntryContractId);

        QueryLogEntry queryLogEntryParams = QueryLogEntry.builder()
                .referenceKey(CwsCommonConstants.QUERYLOG_REQUEST_PARAMS)
                .logTableName("WEBSERVICE_REQUEST")
                .logTableColumn("PARAMS")
                .columnValuePattern(null)
                .build();
        queryLogEntryList.add(queryLogEntryParams);

        queryLogEntryList.forEach(queryLogEntry ->
            queryLogger.addLogTableEntry(queryLogEntry.getReferenceKey(),
                    queryLogEntry.getLogTableName(),
                    queryLogEntry.getLogTableColumn(),
                    queryLogEntry.getColumnValuePattern()));

        queryLogger.init();
        return queryLogger;
    }

    public UwvPerformanceLogger setupPerformanceLogger(DataSource dataSource, DbPropertyLoader dbPropertyLoader) {
        UwvPerformanceLogger performanceLogger = new UwvPerformanceLogger();
        performanceLogger.setDataSource(dataSource);
        performanceLogger.setProgramId(programId);
        Properties dbProperties = dbPropertyLoader.getProperties();
        performanceLogger.setLogRate(dbProperties.getProperty("perf.log.rate"));
        performanceLogger.setPerformanceLogEnabled(Boolean.parseBoolean(dbProperties.getProperty("perf.logging.active")));
        performanceLogger.init();
        return performanceLogger;
    }

    public DbPropertyLoader setupPropertyLoader(NonCoreFuncDao nonCoreFuncDao) {
        DbPropertyLoader dbPropertyLoader = new DbPropertyLoader();
        dbPropertyLoader.setDao(nonCoreFuncDao);
        dbPropertyLoader.setEnvName(programEnv);
        dbPropertyLoader.setInstanceName(programInstance);
        dbPropertyLoader.setRelease(programRelease);
        dbPropertyLoader.setProgId(programId);
        dbPropertyLoader.init();
        return dbPropertyLoader;
    }
}
