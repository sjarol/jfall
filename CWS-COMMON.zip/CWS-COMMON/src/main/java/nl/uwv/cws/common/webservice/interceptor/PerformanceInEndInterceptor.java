package nl.uwv.cws.common.webservice.interceptor;

import lombok.extern.slf4j.Slf4j;
import nl.uwv.cws.common.performance.PerformanceTracker;
import org.apache.cxf.message.Message;
import org.apache.cxf.phase.AbstractPhaseInterceptor;
import org.apache.cxf.phase.Phase;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

import static nl.uwv.cws.common.model.CwsCommonConstants.DATE_TIME_FORMATTER;

@Slf4j
@Component
public class PerformanceInEndInterceptor extends AbstractPhaseInterceptor<Message> {

    @Autowired
    private PerformanceTracker performanceTracker;

    public PerformanceInEndInterceptor() {
        super(Phase.PRE_INVOKE);
    }

    @Override
    public void handleMessage(Message message) {
        String startService = LocalDateTime.now().format(DATE_TIME_FORMATTER);
        log.info(String.format("Starttijd service: %s", startService));

        Long startTime = (Long) message.getExchange().getInMessage().remove("request.timing.start");
        if (startTime != null) {
            long executionTime = System.currentTimeMillis() - startTime;
            performanceTracker.track("02-IncomingInterceptors", executionTime);
        } else {
            log.debug("IncomingInterceptors timer not found");
        }
    }
}