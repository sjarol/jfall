package nl.uwv.cws.common.util;

import nl.uwv.cws.common.exception.CwsCommonExceptionGenerator;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;

import static org.apache.commons.collections4.CollectionUtils.isNotEmpty;

@Component
public final class MapperUtil {
    private MapperUtil (){}

    public static <T, R> void mapToJaxbListIfNotEmpty(List<T> cwsEntityList, List<R> generatedJaxbList, Function<T, R> mapToJaxbObjectFunction) {
        if (isNotEmpty(cwsEntityList)) {
            List<R> jaxbList = cwsEntityList.stream()
                    .map(mapToJaxbObjectFunction)
                    .filter(Objects::nonNull)
                    .collect(Collectors.toList());
            jaxbList = collectNonEmptyObject(jaxbList);
            if (isNotEmpty(jaxbList)) {
                generatedJaxbList.addAll(jaxbList);
            }
        }
    }

    public static <T> T collectNonEmptyObject(T object) {
        boolean containsAnyValue = false;
        if (object != null) {
            containsAnyValue = Arrays.stream(object.getClass().getDeclaredFields()).anyMatch(field -> {
                field.setAccessible(true);
                try {
                    Object fieldObject = field.get(object);
                    if (fieldObject instanceof Collection) {
                        return !CollectionUtils.isEmpty((Collection) fieldObject);
                    } else {
                        return fieldObject != null;
                    }
                } catch (IllegalAccessException e) {
                    throw CwsCommonExceptionGenerator.technicalError("Failed to check object value.", e);
                }
            });
        }
        return containsAnyValue ? object : null;
    }
}
