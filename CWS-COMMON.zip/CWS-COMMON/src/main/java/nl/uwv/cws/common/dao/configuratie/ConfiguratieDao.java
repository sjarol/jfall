package nl.uwv.cws.common.dao.configuratie;

import nl.uwv.cws.common.dao.mapper.configuratie.ConfiguratieRowMapper;
import nl.uwv.cws.common.model.configuratie.BaseConfiguratieGroepenGegevens;
import nl.uwv.cws.common.model.configuratie.Configuratie;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static nl.uwv.cws.common.util.DaoUtil.findOneOrNone;

@Component

public class ConfiguratieDao <T, B extends BaseConfiguratieGroepenGegevens> {

    @Autowired
    @Qualifier("ppls_cws")
    private NamedParameterJdbcTemplate jdbcTemplate;

    @Autowired
    private ConfiguratieRowMapper<T, B> rowMapper;

    public Configuratie<T, B> findByConfiguratieKey(final String contractNummer, final String contractStartDate, final String versie) {
        String sql =
                " SELECT * " +
                        " FROM cws_configuratie " +
                        " WHERE contract_id = :contractId" +
                        " AND cont_his_dat_in = :contractStart" +
                        " AND version = :version" +
                        " AND his_ts_end = DATE '9999-12-31'";

        SqlParameterSource namedParameters = new MapSqlParameterSource()
                .addValue("contractId", Long.valueOf(contractNummer))
                .addValue("contractStart", Long.valueOf(contractStartDate))
                .addValue("version", Long.valueOf(versie));
        List<Configuratie<T, B>> results = jdbcTemplate.query(sql, namedParameters, rowMapper);

        String errorMessage = String.format("Meerdere configuraties gevonden voor keys combinatie: {contract nummer = %s; contract start: %s; versie: %s}",
                contractNummer, contractStartDate, versie);
        return findOneOrNone(errorMessage, results);
    }

    public Map<String, String> findFilterKeyValuesByCconIdAndLevCd(Long cconId, String levCd) {
        String sql = " SELECT lf.TECH_NAAM, cf.VALUE " +
                " FROM cws_con_filter cf " +
                " JOIN cws_lev_filter lf " +
                " ON cf.lev_filter_id = lf.lev_filter_id " +
                " WHERE cf.ccon_id = :cconId " +
                " AND lf.lev_cd = :levCd " +
                " AND cf.his_ts_end = DATE '9999-12-31'";

        SqlParameterSource namedParameters = new MapSqlParameterSource()
                .addValue("cconId", cconId)
                .addValue("levCd", levCd);

        return jdbcTemplate.query(sql, namedParameters,
                rs -> {
                    Map<String, String> filterKeyValues = new HashMap<>();

                    while (rs.next()) {
                        String filterKey = rs.getString("TECH_NAAM");
                        String value = rs.getString("VALUE");
                        filterKeyValues.put(filterKey, value);
                    }
                    return filterKeyValues;
                });
    }

    public List<Integer> findRelevanteGbaRubrieken(Long cconId) {

        String sql =
                "SELECT DISTINCT mr.rubrieknr_gba " +
                        " FROM cws_con_col cc " +
                        " JOIN cws_meta_rubrieknr_gba mr " +
                        " ON cc.meta_col_id = mr.meta_col_id " +
                        " WHERE " +
                        " cc.ccon_id = :cconId";

        SqlParameterSource namedParameters = new MapSqlParameterSource()
                .addValue("cconId", cconId);

        return jdbcTemplate.queryForList(sql, namedParameters, Integer.class);
    }
}
