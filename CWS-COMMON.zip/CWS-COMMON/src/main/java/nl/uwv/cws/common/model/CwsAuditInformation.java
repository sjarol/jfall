package nl.uwv.cws.common.model;

import lombok.Getter;
import lombok.Setter;
import nl.uwv.cws.common.model.configuratie.BaseConfiguratieGroepenGegevens;
import nl.uwv.cws.common.model.configuratie.Configuratie;
import nl.uwv.cws.common.model.selection.SelectionPeriod;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;

import static nl.uwv.cws.common.model.CwsCommonConstants.DATE_FORMATTER;

@Setter
@Getter
public class CwsAuditInformation {
    private String nrInhoudingsplichtige;
    private String kvkNummer;
    private String loonheffingennr;
    private String contractId;
    private String requestedBsn;
    private Integer requestedStartDate = 0;
    private Integer requestedEndDate = 0;
    private Integer determinedEndDate = 0;
    private Long determinedCConId = 0L;
    private Long determinedBeschouwingsmomentMillis = 0L;

    public void addRequestedParameters(String burgerservicenr) {
        this.requestedBsn = burgerservicenr;
    }

    public void addDeterminedSelectionPeriod(String startDate, String endDate) {
        this.requestedStartDate = Integer.valueOf(startDate);
        this.determinedEndDate = Integer.valueOf(endDate == null ? LocalDate.now().format(CwsCommonConstants.DATE_FORMATTER) : endDate);
    }

    public void addDeterminedSelectionPeriod(SelectionPeriod selectionPeriod) {
        this.requestedStartDate = Integer.parseInt(selectionPeriod.getStartDate().format(DATE_FORMATTER));
        this.determinedEndDate = Integer.parseInt(selectionPeriod.getEndDate().format(DATE_FORMATTER));
    }

    public void addDeterminedConfiguratie(Configuratie<?, ? extends BaseConfiguratieGroepenGegevens>  configuratie) {
        this.determinedCConId = configuratie.getCconId();
    }

    public void addDeterminedBeschouwingsmoment(LocalDateTime beschouwingsmoment) {
        this.determinedBeschouwingsmomentMillis = beschouwingsmoment.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
    }
}
