package nl.uwv.cws.common.model.configuratie;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ConfiguratieAttribuut {
    private String id;
    private String attributeName;
    private String parentId;
    private String table;
    private String column;
}
