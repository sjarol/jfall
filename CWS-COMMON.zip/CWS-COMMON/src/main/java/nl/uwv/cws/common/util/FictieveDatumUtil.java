package nl.uwv.cws.common.util;


import nl.uwv.cws.common.model.FictieveDatum;

public final class FictieveDatumUtil {
    private static final String WITH_ZERO_FORMATTED_DATUM = "%08d%n";

    private static final String VULLING_DAG_FICTIEF = "16";
    private static final String VULLING_MAAND_FICTIEF = "07";
    private static final String VULLING_JAAR_FICTIEF = "1850";
    private static final String VULLING_DAG_EN_MAAND_FICTIEF_DAGDEEL = "01";
    private static final String VULLING_DAG_EN_MAAND_FICTIEF_MAANDDEEL = VULLING_MAAND_FICTIEF;
    private static final String VULLING_IEDERE_COMBINATIE_DAG_MAAND_JAAR_FICTIEF = "18500101";

    private FictieveDatumUtil(){}

    public static FictieveDatum buildFictieveDatum(String datum){
        String formattedDatum = getFormattedDatum(datum);
        String jaar = formattedDatum.substring(0, 4);
        String maand = formattedDatum.substring(4, 6);
        String dag = formattedDatum.substring(6);

        return FictieveDatum.builder()
                .rawDatum(datum)
                .dag(dag)
                .maand(maand)
                .jaar(jaar)
                .dagFictief(isDagFictief(dag))
                .maandFictief(isMaandFictief(maand))
                .jaarFictief(isJaarFictief(jaar))
                .dagEnMaandFictief(isDagFictief(dag) && isMaandFictief(maand))
                .dagEnJaarFictief(isDagFictief(dag) && isJaarFictief(jaar))
                .maandEnJaarFictief(isMaandFictief(maand) && isJaarFictief(jaar))
                .dagEnMaandEnJaarFictief(isDagFictief(dag) && isMaandFictief(maand) && isJaarFictief(jaar))
                .datumFicitief(isDagFictief(dag) || isMaandFictief(maand) || isJaarFictief(jaar))
                .build();
    }

    public static boolean isDatumFicitief(String datum){
        final String formattedDatum = getFormattedDatum(datum);
        final String jaar = formattedDatum.substring(0, 4);
        final String maand = formattedDatum.substring(4, 6);
        final String dag = formattedDatum.substring(6);
        return isDagFictief(dag) || isMaandFictief(maand) || isJaarFictief(jaar);
    }

    private static String getFormattedDatum(String datum){
        return String.format(WITH_ZERO_FORMATTED_DATUM, Integer.parseInt(datum)).substring(0, 8);
    }

    public static String getDateAsFictieveDatumIncludeJaar(final FictieveDatum fictieveDatum){
        final String dag = fictieveDatum.getDag();
        final String maand = fictieveDatum.getMaand();

        if (fictieveDatum.isDagFictief() && fictieveDatum.isJaarFictief() ||
                fictieveDatum.isMaandFictief() && fictieveDatum.isJaarFictief() ||
                fictieveDatum.isDagFictief() && fictieveDatum.isMaandFictief() && fictieveDatum.isJaarFictief()) {

            return VULLING_IEDERE_COMBINATIE_DAG_MAAND_JAAR_FICTIEF;
        } else if (fictieveDatum.isJaarFictief()) {

            return VULLING_JAAR_FICTIEF + maand + dag;
        }

        return getDateAsFictieveDatumExcludeJaar(fictieveDatum);
    }

    public static String getDateAsFictieveDatumExcludeJaar(final FictieveDatum fictieveDatum){
        final String dag = fictieveDatum.getDag();
        final String maand = fictieveDatum.getMaand();
        final String jaar = fictieveDatum.getJaar();

        if (fictieveDatum.isDagFictief() && fictieveDatum.isMaandFictief()) {

            return jaar + VULLING_DAG_EN_MAAND_FICTIEF_MAANDDEEL + VULLING_DAG_EN_MAAND_FICTIEF_DAGDEEL;
        } else if (fictieveDatum.isMaandFictief()) {

            return jaar + VULLING_MAAND_FICTIEF + dag;
        } else if (fictieveDatum.isDagFictief()) {

            return jaar + maand + VULLING_DAG_FICTIEF;
        }

        return fictieveDatum.getRawDatum();
    }

    private static boolean isDagFictief(String dag) {
        return isDagOfMaandFictief(dag);
    }

    private static boolean isMaandFictief(String maand) {
        return isDagOfMaandFictief(maand);
    }

    private static boolean isJaarFictief(String year) {
        return year.matches("^0000$");
    }

    private static boolean isDagOfMaandFictief(String dagOfMaand) {
        return dagOfMaand.matches("^00$");
    }
}