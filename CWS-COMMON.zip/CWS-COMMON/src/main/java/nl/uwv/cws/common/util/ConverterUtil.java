package nl.uwv.cws.common.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import nl.uwv.cws.common.model.CwsCommonConstants;
import org.apache.commons.lang3.StringUtils;

import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import static com.fasterxml.jackson.databind.SerializationFeature.INDENT_OUTPUT;

public final class ConverterUtil {
    public static final ObjectMapper OBJECT_MAPPER = new ObjectMapper().enable(INDENT_OUTPUT);

    private ConverterUtil() {
    }

    public static Long totDatumToTotEnMetDatum(Long input) {
        if (input != null) {
            if (input.equals(99991231L)) {
                return null;
            } else {
                LocalDate datum = LocalDate.parse(input.toString(), DateTimeFormatter.BASIC_ISO_DATE);
                return Long.valueOf(DateTimeFormatter.BASIC_ISO_DATE.format(datum.minusDays(1)));
            }
        } else {
            return null;
        }
    }

    public static Date totDatumToTotEnMetDatum(Date input) {
        if (input != null) {
            if (input.toLocalDate().format(CwsCommonConstants.DATE_FORMATTER).equals("99991231")) {
                return null;
            } else {
                return Date.valueOf(input.toLocalDate().minusDays(1));
            }
        } else {
            return null;
        }
    }

    public static Long totEnMetDatumOneindigToNull(Long input) {
        if (input != null) {
            if (input.equals(99991231L)) {
                return null;
            } else {
               return input;
            }
        } else {
            return null;
        }
    }

    public static Date totEnMetDatumOneindigToNull(Date input) {
        if (input != null) {
            if (input.toLocalDate().format(CwsCommonConstants.DATE_FORMATTER).equals("99991231")) {
                return null;
            } else {
                return input;
            }
        } else {
            return null;
        }
    }

    public static String codeToCodeMetVoorloopnul(String code, int width) {
        if (StringUtils.isBlank(code)) {
            return null;
        }

        if (!StringUtils.isNumeric(code)) {
            return code;
        }

        return StringUtils.leftPad(code, width, "0");
    }
}
