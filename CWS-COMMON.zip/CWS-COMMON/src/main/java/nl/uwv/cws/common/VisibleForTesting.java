package nl.uwv.cws.common;

/**
 * For documentation purpose only. To show if that the method is made private packaged for unit testing. See more detail
 * https://google.github.io/guava/releases/19.0/api/docs/com/google/common/annotations/VisibleForTesting.html
 */
public @interface VisibleForTesting {
}
