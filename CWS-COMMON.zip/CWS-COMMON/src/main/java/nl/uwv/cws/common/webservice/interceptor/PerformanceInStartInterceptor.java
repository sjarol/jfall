package nl.uwv.cws.common.webservice.interceptor;

import org.apache.cxf.message.Message;
import org.apache.cxf.phase.AbstractPhaseInterceptor;
import org.apache.cxf.phase.Phase;
import org.springframework.stereotype.Component;

@Component
public class PerformanceInStartInterceptor extends AbstractPhaseInterceptor<Message> {
    public PerformanceInStartInterceptor() {
        super(Phase.RECEIVE);
    }

    @Override
    public void handleMessage(Message message) {
        long startTime = System.currentTimeMillis();
        message.put("webservice.timing.start", startTime);
        message.put("request.timing.start", startTime);
    }
}
