package nl.uwv.cws.common.model.rule;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

public class XsdInvalidDataCollector {
    private List<XsdErrorDetail> xsdErrors = new ArrayList<>();

    public List<XsdErrorDetail> getXsdErrors() {
        return xsdErrors;
    }

    public void addXsdError(String fieldName, Object input, String expected) {
        XsdErrorDetail errorDetail = new XsdErrorDetail();
        errorDetail.setAttribuut(fieldName);
        errorDetail.setOngeldigeWaarde(String.valueOf(input));
        errorDetail.setMelding("Expected: " + expected);
        xsdErrors.add(errorDetail);
    }

    @Setter
    @Getter
    public static class XsdErrorDetail {
        private String attribuut;
        private String melding;
        private String ongeldigeWaarde;
    }
}
