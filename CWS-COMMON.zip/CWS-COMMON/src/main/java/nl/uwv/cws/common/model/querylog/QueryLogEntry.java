package nl.uwv.cws.common.model.querylog;

import lombok.Builder;
import lombok.Getter;

@Builder
@Getter
public class QueryLogEntry {
    private String referenceKey;
    private String logTableName;
    private String logTableColumn;
    private String columnValuePattern;
}
