package nl.uwv.cws.common.exception;

public class CwsResponseXsdInvalidException extends Exception {
    public CwsResponseXsdInvalidException(String message) {
        super(message);
    }
}
