package nl.uwv.cws.common.aspect;

import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

import java.util.Collection;

@Slf4j
@Aspect
@Component
public class SqlLogAspect {

    @Around("execution(public * nl.uwv.cws.*.dao..*Dao.*(..))")
    public Object logDaoResults(ProceedingJoinPoint joinPoint) throws Throwable {
        if (log.isTraceEnabled()) {
            String methodName = joinPoint.getSignature().getDeclaringType().getSimpleName() + "." + joinPoint.getSignature().getName();
            try {
                Object result = joinPoint.proceed();
                logResults(methodName, result);
                return result;
            } catch(Throwable t) {
                log.trace("'" + methodName + "' throws error. Error message: " + t.getMessage());
                throw t;
            }
        } else {
            return joinPoint.proceed();
        }
    }

    private void logResults(String methodName, Object result) {
        String numberOfResultsAsString;
        if (result == null) {
            numberOfResultsAsString = null;
        } else if (result instanceof Collection) {
            numberOfResultsAsString = String.valueOf(((Collection) result).size());
        } else {
            numberOfResultsAsString = String.valueOf(1);
        }
        log.trace("'" + methodName + "' returned number of results: " + numberOfResultsAsString);
    }

    @Before("execution(* org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate.query*(..))")
    public void logSqlQueried(JoinPoint joinPoint) {
        if (log.isTraceEnabled()) {
            Object[] signatureArgs = joinPoint.getArgs();
            log.trace("JdbcTemplate arguments: " + signatureArgs[0].toString());
        }
    }
}