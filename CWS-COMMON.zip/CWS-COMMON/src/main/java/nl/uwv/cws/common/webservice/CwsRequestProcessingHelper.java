package nl.uwv.cws.common.webservice;

import nl.uwv.cws.common.model.configuratie.ConfiguratieKey;

import javax.xml.ws.WebServiceContext;

public interface CwsRequestProcessingHelper<T> {

    void logRequestPart(T cwsRequest);

    void logAudit(WebServiceContext context, T cwsRequest, boolean gegevensGeleverd);

    ConfiguratieKey extractConfiguratieKey(T cwsRequest);
}
