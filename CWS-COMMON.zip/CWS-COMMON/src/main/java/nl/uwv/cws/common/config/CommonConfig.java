package nl.uwv.cws.common.config;

import lombok.extern.slf4j.Slf4j;
import nl.uwv.commons.ws.UwvPerformanceLogger;
import nl.uwv.commons.ws.UwvQueryLogger;
import nl.uwv.logger.domain.RawDataType;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import javax.xml.ws.WebServiceContext;
import java.sql.Timestamp;
import java.util.Map;

@Slf4j
@Configuration
@Profile("boot")
public class CommonConfig {
    @Value("${program.id}")
    private String programId;

    @Bean
    public UwvQueryLogger localQueryLogger() {
        return new UwvQueryLogger() {
            @Override
            public void init() {
                log.info("Query Log is initiated");
            }

            @Override
            public void log(Map<String, RawDataType> columnValues, Timestamp timestamp, WebServiceContext context) {
                log.info(String.format("Query Log is called with columnValues: %s; timestamp:%s",
                    columnValues,
                    timestamp == null ? null : timestamp.toString()));
            }
        };
    }

    @Bean
    public UwvPerformanceLogger localPerformanceLogger() {
        return new UwvPerformanceLogger() {
            @Override
            public void init() {
                log.info("Performance Log is initiated");
            }

            @Override
            public void logPerformance(Long duration) {
                log.info(String.format("Performance Log is called with measurement: %dms", duration));
            }
        };
    }
}
