package nl.uwv.cws.common.service;

import nl.uwv.cws.common.VisibleForTesting;
import nl.uwv.cws.common.model.CwsCommonFoutmelding;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import static nl.uwv.cws.common.exception.CwsCommonExceptionGenerator.functionalError;
import static nl.uwv.cws.common.model.CwsCommonConstants.PATTERN_LOONHEFFINGENNUMMER;
import static nl.uwv.cws.common.util.PatternCheckUtil.isInvalidDate;
import static org.apache.commons.lang3.StringUtils.isEmpty;

@Component
public class RequestValidationService {

    public void validateBsn(String bsn) {

        if (bsn.equals("000000000")) {
            throw functionalError(CwsCommonFoutmelding.F003);
        }
        if (!voldoetAanElfproef(bsn)) {
            throw functionalError(CwsCommonFoutmelding.F004);
        }
    }

    public boolean voldoetAanElfproef(String bsn) {
        int sum = 0;
        for (int i = 0; i < bsn.length(); i++) {
            int num = Character.getNumericValue(bsn.charAt(i));

            if (i != 8) {
                sum += (9 - i) * num;
            } else {
                sum -= num;
            }
        }
        return sum % 11 == 0;
    }

    public void validateLoonheffingennummer(final String loonheffingennummer) {
        if(!StringUtils.hasLength(loonheffingennummer)){
            throw functionalError(CwsCommonFoutmelding.F062);
        }

        if(!loonheffingennummer.matches(PATTERN_LOONHEFFINGENNUMMER)){
            throw functionalError(CwsCommonFoutmelding.F063);
        }
    }


    @VisibleForTesting
    public void validateConfiguratieKey(String contractNr, String contractStart, String versieNrGegevensafnemerConf ) {
        if (isEmpty(contractNr)) {
            throw functionalError(CwsCommonFoutmelding.F021);
        }
        if (isInvalidDate(contractStart)) {
            throw functionalError(CwsCommonFoutmelding.F018);
        }
        if (isEmpty(versieNrGegevensafnemerConf)) {
            throw functionalError(CwsCommonFoutmelding.F017);
        }
    }
}
