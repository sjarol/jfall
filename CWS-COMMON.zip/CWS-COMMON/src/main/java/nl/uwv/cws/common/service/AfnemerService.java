package nl.uwv.cws.common.service;

import nl.uwv.common.afnemermodel.domain.Afnemer;
import nl.uwv.cws.common.dao.CwsAfnemerDao;
import nl.uwv.cws.common.model.CwsCommonFoutmelding;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import static nl.uwv.cws.common.exception.CwsCommonExceptionGenerator.functionalError;

@Component
@CacheConfig(cacheNames = {"afnemer"})
public class AfnemerService {

    @Autowired
    private CwsAfnemerDao cwsAfnemerDao;

    @Cacheable
    public Afnemer getAfnemerOfConfiguration(Long cconId) {
        Afnemer foundAfnemer = cwsAfnemerDao.findOneAfnemerByCconId(cconId);
        if (foundAfnemer == null) {
            throw functionalError(CwsCommonFoutmelding.F005);
        }
        return foundAfnemer;
    }
}
