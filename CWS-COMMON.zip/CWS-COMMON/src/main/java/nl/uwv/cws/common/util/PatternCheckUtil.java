package nl.uwv.cws.common.util;

import nl.uwv.cws.common.model.CwsCommonConstants;

import java.time.format.DateTimeParseException;

public final class PatternCheckUtil {
    private PatternCheckUtil() {
    }

    public static boolean isInvalidDate(String datum) {
        return !isValidDate(datum);
    }

    public static boolean isValidDate(String datum) {
        try {
            CwsCommonConstants.DATE_FORMATTER.parse(datum);
            return true;
        } catch (DateTimeParseException e) {
            return false;
        }
    }
}
