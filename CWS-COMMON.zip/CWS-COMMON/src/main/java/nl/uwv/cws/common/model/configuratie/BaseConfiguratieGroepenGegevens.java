package nl.uwv.cws.common.model.configuratie;

import nl.uwv.cws.common.VisibleForTesting;
import org.springframework.util.StringUtils;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

import static java.util.Collections.emptyList;
import static java.util.stream.Collectors.*;

public abstract class BaseConfiguratieGroepenGegevens {
    private Map<String, List<String>> requiredTablesAndColumns = new HashMap<>();
    private Set<String> requiredEntities = new HashSet<>();

    public void applyConfiguratieAttribuutData(List<ConfiguratieAttribuut> configuratieAttribuutList) {
        requiredTablesAndColumns.clear();
        requiredTablesAndColumns = configuratieAttribuutList.stream()
            .filter(configuratieAttribuut -> configuratieAttribuut.getTable() != null)
            .map(configuratieAttribuut -> {
                configuratieAttribuut.setTable(configuratieAttribuut.getTable().toUpperCase());
                return configuratieAttribuut;
            })
            .collect(groupingBy(ConfiguratieAttribuut::getTable, mapping(ConfiguratieAttribuut::getColumn, toList())));

        requiredEntities.clear();
        requiredEntities = collectRequiredEntities(configuratieAttribuutList);
    }

    private Set<String> collectRequiredEntities(List<ConfiguratieAttribuut> configuratieAttribuutList) {
        Set<String> parentIds = configuratieAttribuutList.parallelStream()
            .map(ConfiguratieAttribuut::getParentId)
            .filter(StringUtils::hasText)
            .collect(Collectors.toSet());
        Map<String, ConfiguratieAttribuut> attribuutReferences = configuratieAttribuutList.parallelStream()
            .collect(toMap(ConfiguratieAttribuut::getId, Function.identity()));

        return configuratieAttribuutList.stream()
            .filter(configuratieAttribuut -> parentIds.contains(configuratieAttribuut.getId()))
            .map(configuratieAttribuut -> collectAttributeChainName(attribuutReferences, configuratieAttribuut))
            .collect(toSet());
    }

    @VisibleForTesting
    String collectAttributeChainName(Map<String, ConfiguratieAttribuut> attribuutReferences, ConfiguratieAttribuut configuratieAttribuut) {
        return getParentAttributeName(attribuutReferences, configuratieAttribuut.getParentId()) + configuratieAttribuut.getAttributeName();
    }

    private String getParentAttributeName(Map<String, ConfiguratieAttribuut> attribuutReferences, String attributeIdToCollect) {
        if (attributeIdToCollect == null) {
            return "";
        } else {
            return collectAttributeChainName(attribuutReferences, attribuutReferences.get(attributeIdToCollect)) + ".";
        }
    }

    public boolean containsRequiredTable(String tableName) {
        return requiredTablesAndColumns.containsKey(tableName.toUpperCase());
    }

    public List<String> getRequiredColumnsOfTable(String tableName) {
        List<String> foundColumns = requiredTablesAndColumns.get(tableName);
        return foundColumns == null ? emptyList() : foundColumns;
    }

    public boolean containsRequiredEntity(String attributeChainName) {
        return requiredEntities.contains(attributeChainName);
    }
}
