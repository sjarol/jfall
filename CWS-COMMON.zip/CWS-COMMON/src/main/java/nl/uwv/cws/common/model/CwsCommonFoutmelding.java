package nl.uwv.cws.common.model;

/**
 * CwsCommonFoutmelding range F00 - F099 en tevens voor onbekende fout F999
 * voor CwsNp specifieke code
 */
public enum CwsCommonFoutmelding implements Foutmelding {
    F003("F", "003", "Burgerservicenummer mag niet gelijk zijn aan 000000000"),
    F004("F", "004", "Burgerservicenummer voldoet niet aan de 11-proef"),
    F005("F", "005", "U bent niet gerechtigd om deze gegevens te bekijken"),
    F008("F", "008", "Burgerservicenummer niet gevonden"),
    F009("F", "009", "GegevensLeveringOvereenkomst is niet geldig"),
    F010("F", "010", "GegevensLeveringOvereenkomst is niet gevonden"),
    F017("F", "017", "Versienummer gegevensafnemer configuratie is een verplicht veld"),
    F018("F", "018", "De opgegeven datum aanvang contract gegevenslevering is geen bestaande datum"),
    F021("F", "021", "Contractnummer gegevenslevering is een verplicht veld"),
    F023("F", "023", "U bent niet gerechtigd om deze GegevensLeveringOvereenkomst op te vragen"),
    F042("F", "042", "KvK-nummer niet gevonden"),
    F062("F", "062", "Loonheffingennummer moet gevuld zijn"),
    F063("F", "063", "Loonheffingennummer bevat ongeldige karakters"),
    F065("F", "065", "Loonheffingennummer niet gevonden in de werkgeversadministratie"),

    F999("F", "999", "Onbekende fout");

    private final String soort;
    private final String code;
    private final String message;

    CwsCommonFoutmelding(String soort, String code, String message) {
        this.soort = soort;
        this.code = code;
        this.message = message;
    }

    @Override
    public String getSoort() {
        return soort;
    }

    @Override
    public String getCode() {
        return code;
    }

    @Override
    public String getMessage() {
        return message;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(this.soort)
            .append(this.code)
            .append(": ")
            .append(this.message);
        return sb.toString();
    }
}
