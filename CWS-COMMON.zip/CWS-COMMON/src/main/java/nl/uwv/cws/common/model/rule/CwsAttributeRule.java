package nl.uwv.cws.common.model.rule;

public interface CwsAttributeRule {
}
