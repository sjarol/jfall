package nl.uwv.cws.common.exception;

import lombok.extern.slf4j.Slf4j;
import nl.uwv.cws.common.model.CwsCommonFoutmelding;
import nl.uwv.cws.common.model.Foutmelding;

import static nl.uwv.cws.common.model.CwsCommonConstants.XSD_RESPONSE_ERROR_MESSAGE_INDICATOR;

/**
 * Utility class to ease Exceptions generation
 */
@Slf4j
public class CwsCommonExceptionGenerator {

    private CwsCommonExceptionGenerator(){}

    public static ApplicatieMeldingException functionalError(Foutmelding foutmelding) {
        log.info("Foutmelding: {} ({})", foutmelding.getCode(), foutmelding.getMessage());
        return new ApplicatieMeldingException(foutmelding);
    }

    public static ApplicatieMeldingException technicalError(String errorMessage, Exception e) {
        log.warn(errorMessage, e);
        return new ApplicatieMeldingException(CwsCommonFoutmelding.F999);
    }

    public static CwsResponseXsdInvalidException xsdResponseError() {
        return new CwsResponseXsdInvalidException(XSD_RESPONSE_ERROR_MESSAGE_INDICATOR);
    }
}
