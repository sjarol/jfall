package nl.uwv.cws.common.service;

import nl.uwv.cws.common.dao.AuthorizationDao;
import nl.uwv.cws.common.model.CwsAuthorization;
import nl.uwv.cws.common.model.CwsCommonFoutmelding;
import nl.uwv.cws.common.model.configuratie.ConfiguratieKey;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import static nl.uwv.cws.common.exception.CwsCommonExceptionGenerator.functionalError;

@Component
@CacheConfig(cacheNames = {"autorisatie"})
public class AuthorizationService {
    @Autowired
    private AuthorizationDao authorizationDao;

    @Cacheable
    public void isAfnemerAuthorised(CwsAuthorization cwsAuthorization, ConfiguratieKey configuratieKey, String levCd) {
        boolean isAuthorised;

        if (cwsAuthorization.isBeheerder()) {
            isAuthorised = true;
        } else {
            isAuthorised = authorizationDao.isAfnemerAuthorisedByUsernameAndOin(cwsAuthorization, configuratieKey, levCd);
        }

        if (!isAuthorised) {
            throw functionalError(CwsCommonFoutmelding.F023);
        }
    }
}
