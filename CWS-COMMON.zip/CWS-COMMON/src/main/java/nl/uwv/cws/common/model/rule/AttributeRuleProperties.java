package nl.uwv.cws.common.model.rule;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
public class AttributeRuleProperties <T> {
    private boolean required;
    private Integer sizeMin;
    private Integer sizeMax;
    private CwsXsdPattern pattern;
    private BigDecimal decimalMin;
    private Integer digitsInteger;
    private Integer digitsFraction;

    private boolean needXsdCheck;
    private T rule;
}
