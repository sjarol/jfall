package nl.uwv.cws.common.model;

public interface Foutmelding {
    String getSoort();

    String getCode();

    String getMessage();

    @Override
    String toString();
}
