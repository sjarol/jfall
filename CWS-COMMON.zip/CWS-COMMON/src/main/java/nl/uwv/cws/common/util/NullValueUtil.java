package nl.uwv.cws.common.util;

import nl.uwv.cws.common.model.CwsCommonConstants;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;

public final class NullValueUtil {

    private NullValueUtil() {
    }

    public static Double getDoubleOrNull(ResultSet resultSet, String columnName) throws SQLException {
        return resultSet.getObject(columnName) == null ? null : resultSet.getDouble(columnName);
    }

    public static Long getLongOrNull(ResultSet resultSet, String columnName) throws SQLException {
        return resultSet.getObject(columnName) == null ? null : resultSet.getLong(columnName);
    }

    public static Integer getIntegerOrNull(ResultSet resultSet, String columnName) throws SQLException {
        return resultSet.getObject(columnName) == null ? null : resultSet.getInt(columnName);
    }

    public static String extractStringValueOrNull(Object value) {
        return value == null ? null : String.valueOf(value);
    }

    public static BigDecimal extractBigDecimalValueOrNull(Double value) {
        return value == null ? null : BigDecimal.valueOf(value).setScale(2);
    }

    public static BigInteger extractBigIntegerValueOrNull(Long value) {
        return value == null ? null : BigInteger.valueOf(value);
    }

    public static BigInteger extractBigIntegerValueOrNull(Integer value) {
        return value == null ? null : BigInteger.valueOf(value);
    }
    
    public static BigInteger extractBigIntegerValueOrNull(String value) {
        return value == null ? null : new BigInteger(value);
    }

    public static String extractStringFromDateValueOrNull(Date value) {
        return value == null ? null : value.toLocalDate().format(CwsCommonConstants.DATE_FORMATTER);
    }

}
