package nl.uwv.cws.common.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Component;

@Component
public class DataMonitorDao {

    @Autowired
    @Qualifier("ppls_cws")
    private NamedParameterJdbcTemplate jdbcTemplate;

    public void keepRecordOfXsdErrorOnResponse(String identifier, String xsdFoutLog) {
        String sql = "INSERT INTO CWS_DATAMONITOR (LOGTIME, IDENTIFIER, XSD_FOUT_LOG) VALUES (SYSTIMESTAMP, :identifier, :xsdFoutLog)";

        SqlParameterSource namedParameters = new MapSqlParameterSource()
            .addValue("identifier", identifier)
            .addValue("xsdFoutLog", xsdFoutLog);
        jdbcTemplate.update(sql, namedParameters);
    }
}
