package nl.uwv.cws.common.aspect;

import lombok.extern.slf4j.Slf4j;
import nl.uwv.cws.common.performance.PerformanceTracker;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;

import static org.springframework.util.StringUtils.hasText;

@Slf4j
@Aspect
@Component
public class PerformanceAspect {

    @Autowired
    private PerformanceTracker performanceTracker;

    @Around("@annotation(LogPerformance) || within(nl.uwv.cws.*.dao..*Dao) || bean(cwsXsdValidator) || bean(uwvQueryLogger)")
    public Object logPerformance(ProceedingJoinPoint joinPoint) throws Throwable {
        if (log.isDebugEnabled()) {
            long start = System.currentTimeMillis();
            Object proceed;
            try {
                proceed = joinPoint.proceed();
            } finally {
                long executionTime = System.currentTimeMillis() - start;

                String registerName;
                MethodSignature signature = (MethodSignature) joinPoint.getSignature();
                Method method = signature.getMethod();
                LogPerformance logPerformance = method.getAnnotation(LogPerformance.class);
                if (logPerformance != null && hasText(logPerformance.value())) {
                    registerName = logPerformance.value();
                } else {
                    String methodName = joinPoint.getSignature().getDeclaringType().getSimpleName() + "." + joinPoint.getSignature().getName();
                    registerName = methodName;
                }
                performanceTracker.track(registerName, executionTime);
            }

            return proceed;
        } else {
            return joinPoint.proceed();
        }
    }
}