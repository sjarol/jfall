package nl.uwv.cws.common.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Component;

import java.sql.Timestamp;
import java.time.LocalDateTime;

@Component
public class SupportingDataDao {
    private static final String TRANSACTIE_TYPE = "CWS00";

    @Autowired
    @Qualifier("ppls_cws")
    private NamedParameterJdbcTemplate jdbcTemplate;

    public LocalDateTime getBeschouwingsPlafond() {
		return getBeschouwingsPlafond(TRANSACTIE_TYPE);
    }

    public LocalDateTime getBeschouwingsPlafond(String transactionType) {
        String sql = "select bepaal_beschouwingsplafond(:transactionType) from dual";
        SqlParameterSource namedParameters = new MapSqlParameterSource().addValue("transactionType", transactionType);
        Timestamp beschouwingsPlafond = jdbcTemplate.queryForObject(sql, namedParameters, Timestamp.class);
        return beschouwingsPlafond.toLocalDateTime();
    }
}
