package nl.uwv.cws.common.model.selection;

import lombok.Builder;
import lombok.Getter;

import java.time.LocalDate;

@Builder
@Getter
public class SelectionPeriod {
    private LocalDate startDate;
    private LocalDate endDate;
}
