package nl.uwv.cws.common.util;

import nl.uwv.cws.common.model.FictieveDatum;

public final class CodeFictieveDatumUtil {

  private CodeFictieveDatumUtil(){}

  private static final int CODE_NIET_FICTIEF = 0;
  private static final int CODE_DAG_FICTIEF = 1;
  private static final int CODE_MAAND_FICTIEF = 2;
  private static final int CODE_DAG_EN_MAAND_FICTIEF = 3;
  private static final int CODE_JAAR_FICTIEF = 4;
  private static final int CODE_DAG_EN_JAAR_FICTIEF = 5;
  private static final int CODE_MAAND_EN_JAAR_FICTIEF = 6;
  private static final int CODE_DAG_EN_MAAND_EN_JAAR_FICTIEF = 7;
  private static final int CODE_NIET_LEVEREN = 8;

  public static Integer determineCodeFictieveGeboortedatum(Integer datum) {
    FictieveDatum fictieveDatumToUse = FictieveDatumUtil.buildFictieveDatum(String.valueOf(datum));

    if (fictieveDatumToUse.isDagEnMaandEnJaarFictief()) {

      return CODE_DAG_EN_MAAND_EN_JAAR_FICTIEF;
    } else if (fictieveDatumToUse.isMaandEnJaarFictief()) {

      return CODE_MAAND_EN_JAAR_FICTIEF;
    } else if (fictieveDatumToUse.isDagEnJaarFictief()) {

      return CODE_DAG_EN_JAAR_FICTIEF;
    } else if (fictieveDatumToUse.isDagEnMaandFictief()) {

      return CODE_DAG_EN_MAAND_FICTIEF;
    } else if (fictieveDatumToUse.isJaarFictief()) {

      return CODE_JAAR_FICTIEF;
    } else if (fictieveDatumToUse.isMaandFictief()) {

      return CODE_MAAND_FICTIEF;
    } else if (fictieveDatumToUse.isDagFictief()) {

      return CODE_DAG_FICTIEF;
    }

    return CODE_NIET_FICTIEF;
  }

  public static Integer determineCodeFictieveOverlijdensdatum(Integer datum) {
    FictieveDatum fictieveDatumToUse = FictieveDatumUtil.buildFictieveDatum(String.valueOf(datum));

    if (fictieveDatumToUse.isDagEnMaandEnJaarFictief()) {

      return CODE_NIET_LEVEREN;
    } else if (fictieveDatumToUse.isDagEnMaandFictief()) {

      return CODE_DAG_EN_MAAND_FICTIEF;
    } else if (fictieveDatumToUse.isMaandFictief()) {

      return CODE_MAAND_FICTIEF;
    } else if (fictieveDatumToUse.isDagFictief()) {

      return CODE_DAG_FICTIEF;
    }

    return CODE_NIET_FICTIEF;
  }
}
