package nl.uwv.cws.common.performance;

import com.fasterxml.jackson.core.JsonProcessingException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.*;
import java.util.function.Function;

import static java.time.LocalDateTime.now;
import static java.util.stream.Collectors.toMap;
import static nl.uwv.cws.common.util.ConverterUtil.OBJECT_MAPPER;

@Slf4j
@Component
public class PerformanceTracker {
    private static final int MAX_NUMBER_OF_EMPTY_TRACKER = 4;
    private static final String AVERAGE = "avg";

    private LocalDateTime startMeasureDateTime = now();
    private Map<String, Pair<Integer, Double>> averageTracker = new HashMap<>();
    private Map<String, List<Long>> timeTracker = new HashMap<>();
    private int numberOfEmptyTracker = 0;

    public void track(String methodName, long time) {
        registerToTimeTracker(this.timeTracker, methodName, time);
    }

    private synchronized void registerToTimeTracker(Map<String, List<Long>> timeTrackerToUse, String methodName, long time) {
        List<Long> recordedTime;
        List<Long> existingRecordedTime = timeTrackerToUse.get(methodName);
        if (existingRecordedTime != null) {
            recordedTime = existingRecordedTime;
        } else {
            recordedTime = new ArrayList<>();
            timeTrackerToUse.put(methodName, recordedTime);
        }
        recordedTime.add(time);
    }

    private Map<String, Pair<Integer, Double>> collectTrackedPerformanceData(Map<String, List<Long>> timeTracker) {
        Set<String> joinedKeySet = new HashSet<>(averageTracker.keySet());
        joinedKeySet.addAll(timeTracker.keySet());

        return joinedKeySet.stream()
            .collect(toMap(Function.identity(), key -> {
                Pair<Integer, Double> averageTracked = averageTracker.get(key);
                List<Long> recordedTimeList = timeTracker.get(key);
                int countEarilerAverage = averageTracked == null ? 0 : averageTracked.getLeft();
                double earlierAverage = averageTracked == null ? 0D : averageTracked.getRight();
                int countTrackedTime = recordedTimeList == null ? 0 : recordedTimeList.size();
                double averageTrackedTime = recordedTimeList == null ? 0D : recordedTimeList.stream()
                    .mapToLong(value -> value)
                    .average()
                    .getAsDouble();

                int totalCount = countEarilerAverage + countTrackedTime;
                double totalNewAverage = (countEarilerAverage * earlierAverage + countTrackedTime * averageTrackedTime) / totalCount;
                return Pair.of(totalCount, totalNewAverage);
            }));
    }

    private Map<String, Map<String, String>> createPrintablePerformanceTracked() {
        final Map<String, Map<String, String>> groupedData = new HashMap<>();
        groupedData.put("XsdValidator", new TreeMap<>());
        groupedData.put("Dao", new TreeMap<>());
        groupedData.put("Service", new TreeMap<>());
        groupedData.put("Other", new TreeMap<>());
        averageTracker.forEach((key, value) -> {
            if (key.contains("XsdValidator.")) {
                groupedData.get("XsdValidator").put(key, "#: " + value.getLeft() + " ; " + AVERAGE + ": " + value.getRight());
            } else if (key.contains("Dao.")) {
                groupedData.get("Dao").put(key, "#: " + value.getLeft() + " ; " + AVERAGE + ": " + value.getRight());
            } else if (key.contains("Service.")) {
                groupedData.get("Service").put(key, "#: " + value.getLeft() + " ; " + AVERAGE + ": " + value.getRight());
            } else {
                groupedData.get("Other").put(key, "#: " + value.getLeft() + " ; " + AVERAGE + ": " + value.getRight());
            }
        });
        return groupedData;
    }

    public Map<String, Map<String, String>> collectLastStateOfPerformance() {
        Map<String, List<Long>> newTimeTracker = new HashMap<>();
        Map<String, List<Long>> oldTimeTracker = timeTracker;
        timeTracker = newTimeTracker;
        averageTracker = collectTrackedPerformanceData(oldTimeTracker);
        return createPrintablePerformanceTracked();
    }

    @Scheduled(fixedDelay = 300_000L)
    public void printPerformanceLog() {
        if (!timeTracker.isEmpty()) {
            try {
                Map<String, Map<String, String>> printablePerformanceTracked = collectLastStateOfPerformance();

                String logMessage =
                    "Total performance data: " +
                        OBJECT_MAPPER.writeValueAsString(printablePerformanceTracked) +
                        "\n" +
                        "Total performance measured since : " +
                        startMeasureDateTime.toString();
                log.debug(logMessage);
            } catch (JsonProcessingException e) {
                log.warn("Failed to print performance tracker as json");
            }
        } else if (!averageTracker.isEmpty()) {
            numberOfEmptyTracker++;
            if (numberOfEmptyTracker > MAX_NUMBER_OF_EMPTY_TRACKER) {
                averageTracker = new HashMap<>();
                numberOfEmptyTracker = 0;
                startMeasureDateTime = now();
                log.debug("PerformanceTracker has been cleaned up.");
            }
        }
    }
}
