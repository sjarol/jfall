package nl.uwv.cws.common.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import javax.sql.DataSource;

@Configuration
@Profile("performance")
public class PerformanceConfig extends CommonConfig {

    @Bean(name = "insertDataSource")
    @ConfigurationProperties(prefix = "insert.db")
    public DataSource cwsInsertDataSource() {
        return DataSourceBuilder.create().build();
    }

}
