package nl.uwv.cws.common.model;

import java.time.format.DateTimeFormatter;
import java.time.format.ResolverStyle;
import java.util.regex.Pattern;

public class CwsCommonConstants {
    public static final String APPLICATIE_NAAM = "POLIS LEVEREN";
    public static final String BUILD_NR = "01";
    public static final String COMUNICATIE_TYPE = "Inkijk";
    public static final String COMMUNICATIE_ELEMENT_RESPONSE = "Response";
    public static final String COMMUNICATIE_ELEMENT_FOUT = "Fout";
    public static final long IND_TESTBERICHT = 2;
    public static final String XSD_REQUEST_ERROR_MESSAGE_INDICATOR = "REQUEST_VIOLATES_XSD";
    public static final String XSD_RESPONSE_ERROR_MESSAGE_INDICATOR = "RESPONSE_VIOLATES_XSD";
    // NOTE: Characters are based on "CEN WORKSHOP AGREEMENT CWA 13873:2000" (http://www.evertype.com/standards/iso10646/pdf/cwa13873.pdf)
    public static final Pattern ANY_NON_MES1_PATTERN = Pattern.compile(
            "[^" +
            "\\u0020-\\u007E\\u00A0-\\u00FF" +
            "\\u0100-\\u0113\\u0116-\\u012B\\u012E-\\u014D\\u0150-\\u017E" +
            "\\u02C7\\u02D8-\\u02DB\\u02DD" +
            "\\u2015\\u2018-\\u2019\\u201C-\\u201D\\u20AC" +
            "\\u2122\\u2126\\u215B-\\u215E\\u2190-\\u2193" +
            "\\u266A]");
    public static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("uuuuMMdd").withResolverStyle(ResolverStyle.STRICT);
    public static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss SSS").withResolverStyle(ResolverStyle.STRICT);
    public static final int MAX_CONTRACT_NR_LENGTH = 10;
    public static final int MAX_CONFIGURATIE_VERSIE_LENGTH = 4;
    public static final String QUERYLOG_REQUEST_NR_IHP = "REQUEST_NR_IHP";
    public static final String QUERYLOG_REQUEST_KVKNUMMER = "REQUEST_KVK_NUMMER";
    public static final String QUERYLOG_REQUEST_LHNR = "REQUEST_LHNR";
    public static final String QUERYLOG_REQUEST_BSN = "REQUEST_BSN";
    public static final String QUERYLOG_REQUEST_PARAMS = "REQUEST_PARAMS";
    public static final String QUERYLOG_REQUEST_CONTRACT_ID = "REQUEST_CONTRACT_ID";
    public static final String IS_NIET_LOGISCH_VERWIJDERD = "his_ts_end >= DATE '9999-12-31' ";
    public static final String PATTERN_LOONHEFFINGENNUMMER = "^([0-9]{9})L([0-9]{2})";
    public static final String PATTERN_ONLY_NUMBERS = "^[0-9]+$";

    public static final String KVK_NUMMER = "kvkNummer";
    public static final String VESTIGINGS_NUMMER = "vestigingsNummer";
    public static final String BESCHOUWINGSMOMENT = "beschouwingsmoment";
    public static final String LOG_TABLE_NAME = "WEBSERVICE_REQUEST";
    public static final String SQL_SELECT = " SELECT ";
    public static final String SQL_FROM = " FROM ";
    public static final String SQL_WHERE = " WHERE ";
    public static final String SQL_AND = " AND ";
    public static final String SQL_UNION = " UNION ";

    private CwsCommonConstants(){}

}
