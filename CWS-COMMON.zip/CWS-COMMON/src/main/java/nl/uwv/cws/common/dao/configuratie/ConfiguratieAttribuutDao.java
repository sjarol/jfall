package nl.uwv.cws.common.dao.configuratie;

import nl.uwv.cws.common.dao.mapper.configuratie.ConfiguratieAttribuutRowMapper;
import nl.uwv.cws.common.model.configuratie.ConfiguratieAttribuut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class ConfiguratieAttribuutDao {

    @Autowired
    @Qualifier("ppls_cws")
    private NamedParameterJdbcTemplate jdbcTemplate;

    @Autowired
    private ConfiguratieAttribuutRowMapper rowMapper;

    public List<ConfiguratieAttribuut> findByCconId(Long cconId) {
        String sql =
            " SELECT " +
                " cmc.meta_col_id, " +
                " cmc.parent_id, " +
                " cmc.tech_naam, " +
                " cmc.bron_tabel, " +
                " cmc.bron_rubriek " +
                " FROM cws_meta_col cmc " +
                " JOIN cws_con_col ccc " +
                " ON cmc.meta_col_id = ccc.meta_col_id " +
                " WHERE ccc.ccon_id = :cconId " +
                " AND ccc.his_ts_end = DATE '9999-12-31'";
        SqlParameterSource namedParameters = new MapSqlParameterSource()
            .addValue("cconId", cconId);
        return jdbcTemplate.query(sql, namedParameters, rowMapper);
    }
}
