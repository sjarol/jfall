package nl.uwv.cws.common.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Component;

import java.util.List;

import static nl.uwv.cws.common.util.DaoUtil.findOneOrNone;

@Component
public class BsnStatusDao {

    @Autowired(required=false)
    @Qualifier("upa_cws")
    public NamedParameterJdbcTemplate jdbcTemplateUpa;

    @Autowired
    @Qualifier("ppls_cws")
    public NamedParameterJdbcTemplate jdbcTemplatePpls;

    public boolean isBsnPresentInUpa(String bsn) {
        String sql = "(SELECT 1 FROM upa_natuurlijk_persoon_npe npe " +
                     " WHERE npe.bsn = :bsn " +
                     " AND npe.rol_npe = 'GBA' " +
                     " AND rownum = 1) ";
        return isBsnPresent(sql, bsn, jdbcTemplateUpa);
    }

    public boolean isBsnPresentInPpls(String bsn) {
        String sql = "(SELECT 1 FROM la_inkomstenverhouding ikv " +
                     " WHERE ikv.sofinr = :bsn " +
                     " AND rownum = 1) ";
        return isBsnPresent(sql, bsn, jdbcTemplatePpls);
    }

    public boolean isBsnPresent(String selectFrom, String bsn, NamedParameterJdbcTemplate jdbcTemplate) {
        String sql =
                " SELECT CASE " +
                " WHEN EXISTS " +
                selectFrom +
                " THEN 1 " +
                " ELSE 0 " +
                " END " +
                " FROM dual";
        SqlParameterSource namedParameters = new MapSqlParameterSource()
                .addValue("bsn", bsn);
        Integer count = jdbcTemplate.queryForObject(sql, namedParameters, Integer.class);
        return count == 1;
    }

    public String findVipCodeByBsnInUpa(String bsn) {
        String sql =
                "  SELECT DISTINCT vip.cd_vip_type AS viptype_cd " +
                "  FROM upa_natuurlijk_persoon_npe npe " +
                "  LEFT OUTER JOIN upa_vip_vip vip " +
                "  ON vip.bsn = npe.bsn " +
                "  AND vip.his_ts_end = TO_TIMESTAMP('99991231', 'YYYYMMDD') " +
                "  WHERE npe.bsn = :bsn" +
                "  AND npe.rol_npe = 'GBA'";
        return findVipCodeByBsn(sql, bsn, jdbcTemplateUpa);
    }

    public String findVipCodeByBsnInPpls(String bsn) {
        String sql =
                "  SELECT DISTINCT vip.viptype_cd AS viptype_cd " +
                "  FROM la_inkomstenverhouding ikv " +
                "  LEFT OUTER JOIN persoon_vip_his vip " +
                "  ON vip.sofinr = ikv.sofinr " +
                "  AND vip.his_dat_in <= TO_NUMBER(TO_CHAR(SYSDATE, 'YYYYMMDD')) " +
                "  AND vip.his_dat_end > TO_NUMBER(TO_CHAR(SYSDATE, 'YYYYMMDD')) " +
                "  AND vip.his_ts_end = TO_TIMESTAMP('99991231', 'YYYYMMDD') " +
                "  AND vip.bron_cd = 'BD' " +
                "  WHERE ikv.sofinr = :bsn";
        return findVipCodeByBsn(sql, bsn, jdbcTemplatePpls);
    }

    public String findVipCodeByBsn(String sql, String bsn, NamedParameterJdbcTemplate jdbcTemplate) {
        SqlParameterSource namedParameters = new MapSqlParameterSource().addValue("bsn", bsn);
        List<String> results = jdbcTemplate.queryForList(sql, namedParameters, String.class);
        String errorMessage = "Meerdere vip codes gevonden voor BSN: ******" + bsn.substring(6);
        return findOneOrNone(errorMessage, results);
    }
}
