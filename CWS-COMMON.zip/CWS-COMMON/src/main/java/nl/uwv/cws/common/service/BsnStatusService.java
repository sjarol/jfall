package nl.uwv.cws.common.service;

import nl.uwv.cws.common.dao.BsnStatusDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class BsnStatusService {

    @Autowired
    private BsnStatusDao bsnStatusDao;

    public boolean isBsnPresentInUpa(String bsn) {
        return bsnStatusDao.isBsnPresentInUpa(bsn);
    }

    public String findVipCodeByBsnInUpa(String bsn) {
        return bsnStatusDao.findVipCodeByBsnInUpa(bsn);
    }

    public boolean isBsnPresentInPpls(String bsn) {
        return bsnStatusDao.isBsnPresentInPpls(bsn);
    }

    public String findVipCodeByBsnInPpls(String bsn) {
        return bsnStatusDao.findVipCodeByBsnInPpls(bsn);
    }
}
