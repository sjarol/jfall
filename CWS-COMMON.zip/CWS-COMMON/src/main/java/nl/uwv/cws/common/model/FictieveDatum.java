package nl.uwv.cws.common.model;

import lombok.Builder;
import lombok.Getter;

@Builder
@Getter
public class FictieveDatum {
    private String dag;
    private String maand;
    private String jaar;
    private String rawDatum;
    private boolean datumFicitief;
    private boolean dagFictief;
    private boolean maandFictief;
    private boolean jaarFictief;
    private boolean dagEnMaandFictief;
    private boolean dagEnJaarFictief;
    private boolean maandEnJaarFictief;
    private boolean dagEnMaandEnJaarFictief;
}
