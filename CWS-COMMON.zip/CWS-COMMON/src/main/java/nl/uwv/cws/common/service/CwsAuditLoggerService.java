package nl.uwv.cws.common.service;

import lombok.extern.slf4j.Slf4j;
import nl.uwv.commons.ws.UwvQueryLogger;
import nl.uwv.cws.common.model.CwsAuditInformation;
import nl.uwv.cws.common.util.ByteUtil;
import nl.uwv.logger.domain.CompressedLong;
import nl.uwv.logger.domain.CompressedRecord;
import nl.uwv.logger.domain.CompressedString;
import nl.uwv.logger.domain.RawDataType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import javax.xml.ws.WebServiceContext;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

import static nl.uwv.cws.common.model.CwsCommonConstants.*;

@Slf4j
@Component
public class CwsAuditLoggerService {

    @Autowired
    private UwvQueryLogger queryLogger;

    public void log(CwsAuditInformation cwsAuditInformation, WebServiceContext context, boolean gegevensGeselecteerd) {
        final String bsn = cwsAuditInformation.getRequestedBsn();
        final String nrihp = cwsAuditInformation.getNrInhoudingsplichtige();
        final String kvknummer = cwsAuditInformation.getKvkNummer();
        final String lhnr = cwsAuditInformation.getLoonheffingennr();
        final String contractId = cwsAuditInformation.getContractId();
        final Long beschouwingsmomentMillis = cwsAuditInformation.getDeterminedBeschouwingsmomentMillis();
        final Long cConId = cwsAuditInformation.getDeterminedCConId();
        final Integer startDate = cwsAuditInformation.getRequestedStartDate();
        final Integer endDate = cwsAuditInformation.getDeterminedEndDate() == 0 ? cwsAuditInformation.getRequestedEndDate() : cwsAuditInformation.getDeterminedEndDate();

        Map<String, RawDataType> values = collectValuesToLog(cConId, startDate, endDate, gegevensGeselecteerd);
        addNumberValueToValues(QUERYLOG_REQUEST_BSN, bsn, values);
        addNumberValueToValues(QUERYLOG_REQUEST_NR_IHP, nrihp, values);
        addNumberValueToValues(QUERYLOG_REQUEST_KVKNUMMER, kvknummer, values);
        addStringValueToValues(QUERYLOG_REQUEST_LHNR, lhnr, values);
        addNumberValueToValues(QUERYLOG_REQUEST_CONTRACT_ID, contractId, values);

        logRequest(context, values, beschouwingsmomentMillis);
    }

    private void addStringValueToValues(final String key, final String value, Map<String, RawDataType> valuesMap){
        if (StringUtils.hasText(value)) {
            valuesMap.put(key, new CompressedString(value));
        }
    }

    private void addNumberValueToValues(final String key, final String value, Map<String, RawDataType> valuesMap){
        if (StringUtils.hasText(value)) {
            valuesMap.put(key, new CompressedLong(value));
        }
    }

    private void logRequest(WebServiceContext context, Map<String, RawDataType> requestParameterMap, Long beschouwingsmomentMillis) {
        try {
            final Timestamp beschouwingsmoment = beschouwingsmomentMillis != 0 ? new Timestamp(beschouwingsmomentMillis) : null;

            log.debug("Calling queryLogger.");
            queryLogger.log(requestParameterMap, beschouwingsmoment, context);
        } catch (Exception e) {
            final String keys = getKeysAsString(requestParameterMap);
            log.error(String.format("Logging van %s is mislukt.", keys), e);
        }
    }

    private Map<String, RawDataType> collectValuesToLog(Long cConId, Integer startDate, Integer endDate, boolean zijnGegevensGeselecteerd){
        Map<String, RawDataType> values = new HashMap<>();

        values.put(QUERYLOG_REQUEST_PARAMS, new CompressedRecord(
                ByteUtil.encodeRequestParams(
                        cConId,
                        startDate,
                        endDate,
                        zijnGegevensGeselecteerd)));

        return values;
    }

    private String getKeysAsString(Map<String, RawDataType> map) {
        return String.join(", ", map.keySet());
    }
}
