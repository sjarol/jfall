package nl.uwv.cws.common.model.configuratie;

import lombok.Builder;
import lombok.Getter;

@Builder
@Getter
public class ConfiguratieKey {

    private String contractNummer;
    private String contractStartDate;
    private String versie;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ConfiguratieKey that = (ConfiguratieKey) o;

        if (contractNummer != null ? !contractNummer.equals(that.contractNummer) : that.contractNummer != null)
            return false;
        if (contractStartDate != null ? !contractStartDate.equals(that.contractStartDate) : that.contractStartDate != null)
            return false;
        return versie != null ? versie.equals(that.versie) : that.versie == null;
    }

    @Override
    public int hashCode() {
        int result = contractNummer != null ? contractNummer.hashCode() : 0;
        result = 31 * result + (contractStartDate != null ? contractStartDate.hashCode() : 0);
        result = 31 * result + (versie != null ? versie.hashCode() : 0);
        return result;
    }
}
