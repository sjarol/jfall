package nl.uwv.cws.common.util;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class ByteUtil {

    private ByteUtil(){}

    public static byte[] encodeRequestParams(long cConId, int startDate, int endDate, boolean gegevensGeselecteerd) {
        ByteBuffer buffer = ByteBuffer.allocate(5 + 4 + 4 + 1);
        buffer.order(ByteOrder.BIG_ENDIAN);

        // Encode first 5 bytes, most significant bytes first: BIG ENDIAN.
        buffer.put((byte) ((cConId >> 32) & 0xFF));
        buffer.put((byte) ((cConId >> 24) & 0xFF));
        buffer.put((byte) ((cConId >> 16) & 0xFF));
        buffer.put((byte) ((cConId >> 8) & 0xFF));
        buffer.put((byte) cConId);

        // Encode first 4 bytes, most significant bytes first: BIG ENDIAN.
        buffer.putInt(startDate);

        // Encode first 4 bytes, most significant bytes first: BIG ENDIAN.
        buffer.putInt(endDate);

        // Encode as 1 byte
        buffer.put((byte)(gegevensGeselecteerd ? 'J' : 'N'));

        return buffer.array();
    }

}
