package nl.uwv.cws.common.util;

import nl.uwv.cws.common.exception.CwsCommonExceptionGenerator;
import org.apache.commons.lang3.StringUtils;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collections;
import java.sql.Types;
import java.util.List;

public final class DaoUtil {
    private DaoUtil(){
    }

    public static <T> T findOneOrNone(String errorMessage, List<T> results) {
        T foundResult = null;
        if (results.size() == 1) {
            foundResult = results.get(0);
        } else if (results.size() > 1) {
            throw CwsCommonExceptionGenerator.technicalError(errorMessage, new IncorrectResultSizeDataAccessException(1, results.size()));
        }
        return foundResult;
    }

    public static boolean convertToBoolean(ResultSet resultSet, String columnLabel) throws SQLException {
        String stringValue = resultSet.getString(columnLabel);
        return StringUtils.isNotEmpty(stringValue) && stringValue.equals("J");
    }

    public static <T> void removeNullsFromList(List<T> list) {
        list.removeAll(Collections.singletonList(null));
    }

    public static <T> void setOptionalParameter(MapSqlParameterSource parameters, String name, T value) {
        if (value == null)
            parameters.addValue(name, value, Types.NULL);
        else
            parameters.addValue(name, value);
    }
}
