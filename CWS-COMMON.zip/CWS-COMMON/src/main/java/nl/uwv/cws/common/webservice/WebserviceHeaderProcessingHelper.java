package nl.uwv.cws.common.webservice;

import lombok.extern.slf4j.Slf4j;
import nl.uwv.cws.common.VisibleForTesting;
import nl.uwv.cws.common.aspect.LogPerformance;
import nl.uwv.cws.common.model.CwsAuditInformation;
import nl.uwv.cws.common.model.CwsAuthorization;
import nl.uwv.cws.common.service.CwsAuditLoggerService;
import nl.uwv.cws.common.util.AuthorizationUtil;
import nl.uwv.schemas.uwvml.header_v0202.UwvMLHeader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.ws.Holder;
import javax.xml.ws.WebServiceContext;
import java.util.GregorianCalendar;
import java.util.UUID;

import static nl.uwv.cws.common.model.CwsCommonConstants.*;

@Component
@Slf4j
public class WebserviceHeaderProcessingHelper {

    @Qualifier("requestScopedBean")
    @Autowired
    private CwsAuditInformation cwsAuditInformation;

    @Autowired
    private CwsAuditLoggerService cwsAuditLoggerService;

    @LogPerformance
    public void logHeader(Holder<UwvMLHeader> uwvMLHeader) {
        String headerString = "Naam applicatie UWV, verkort: " + uwvMLHeader.value.getRouteInformatie().getBron().getApplicatieNaam() +
                              "; Gegevens uitwisselingsnummer: " + uwvMLHeader.value.getRouteInformatie().getGegevensUitwisselingsnr() +
                              "; Bericht referentienummer: " + uwvMLHeader.value.getBerichtIdentificatie().getBerichtReferentienr();
        log.info(headerString);
    }

    public CwsAuthorization createCwsAuthorization(WebServiceContext webserviceContext, Holder<UwvMLHeader> uwvMLHeader, String beheerRol) {
        CwsAuthorization cwsAuthorization;
        if (uwvMLHeader.value.getAuthenticatie() != null) {
            cwsAuthorization = CwsAuthorization.builder()
                    .username(AuthorizationUtil.retrieveTechnischeUsername(webserviceContext))
                    .oin(AuthorizationUtil.extractOinSerialNumber(uwvMLHeader.value.getAuthenticatie().getAccountIdentificatie()))
                    .isBeheerder(AuthorizationUtil.hasBeheerderRol(webserviceContext, beheerRol))
                    .build();
        } else {
            cwsAuthorization = CwsAuthorization.builder()
                    .username(AuthorizationUtil.retrieveTechnischeUsername(webserviceContext))
                    .isBeheerder(AuthorizationUtil.hasBeheerderRol(webserviceContext, beheerRol))
                    .build();
        }
        return cwsAuthorization;
    }

    public void updateHeaderToSuccessResponse(Holder<UwvMLHeader> uwvMLHeader, String berichtnaam) {
        updateHeader(uwvMLHeader, COMMUNICATIE_ELEMENT_RESPONSE, berichtnaam);
    }

    public void updateHeaderToFailureResponse(Holder<UwvMLHeader> uwvMLHeader, String berichtnaam) {
        updateHeader(uwvMLHeader, COMMUNICATIE_ELEMENT_FOUT, berichtnaam);
    }

    @LogPerformance
    @VisibleForTesting
    public void updateHeader(Holder<UwvMLHeader> uwvMLHeader, String communicatieElement, String berichtnaam) {
        XMLGregorianCalendar currentCalendar = getCurrentCalendar();

        uwvMLHeader.value.getRouteInformatie().getBestemming().setApplicatieNaam(uwvMLHeader.value.getRouteInformatie().getBron().getApplicatieNaam());
        uwvMLHeader.value.getRouteInformatie().setGegevensUitwisselingsnr(uwvMLHeader.value.getRouteInformatie().getGegevensUitwisselingsnr());
        uwvMLHeader.value.getRouteInformatie().setRefnrGegevensUitwisselingsExtern(uwvMLHeader.value.getRouteInformatie().getRefnrGegevensUitwisselingsExtern());
        uwvMLHeader.value.getBerichtIdentificatie().setRequestBerichtReferentienr(uwvMLHeader.value.getBerichtIdentificatie().getBerichtReferentienr());
        uwvMLHeader.value.getBerichtIdentificatie().setBerichtReferentienr(UUID.randomUUID().toString());

        uwvMLHeader.value.getRouteInformatie().getBron().setDatTijdVersturenBericht(currentCalendar);
        uwvMLHeader.value.getRouteInformatie().getBron().setApplicatieNaam(APPLICATIE_NAAM);

        uwvMLHeader.value.getBerichtIdentificatie().getBerichtType().setBerichtNaam(berichtnaam);
        uwvMLHeader.value.getBerichtIdentificatie().getBerichtType().setVersieMajor(uwvMLHeader.value.getBerichtIdentificatie().getBerichtType().getVersieMajor());
        uwvMLHeader.value.getBerichtIdentificatie().getBerichtType().setVersieMinor(uwvMLHeader.value.getBerichtIdentificatie().getBerichtType().getVersieMinor());
        uwvMLHeader.value.getBerichtIdentificatie().getBerichtType().setBuildnr(BUILD_NR);
        uwvMLHeader.value.getBerichtIdentificatie().getBerichtType().setCommunicatieType(COMUNICATIE_TYPE);
        uwvMLHeader.value.getBerichtIdentificatie().getBerichtType().setCommunicatieElement(communicatieElement);
        uwvMLHeader.value.getBerichtIdentificatie().setIndTestbericht(IND_TESTBERICHT);
        uwvMLHeader.value.getBerichtIdentificatie().setDatTijdAanmaakBericht(currentCalendar);

        uwvMLHeader.value.getRouteInformatie().getBron().setCdKolomSuwi(null);
        uwvMLHeader.value.getRouteInformatie().getBron().setCdPartijSuwi(null);
        uwvMLHeader.value.getRouteInformatie().getBron().setCdVestigingSuwi(null);
        uwvMLHeader.value.getRouteInformatie().getBron().setNaamContactpersoonAfd(null);
        uwvMLHeader.value.getRouteInformatie().getBron().setMachine(null);

        uwvMLHeader.value.getRouteInformatie().getBestemming().setCdKolomSuwi(null);
        uwvMLHeader.value.getRouteInformatie().getBestemming().setCdPartijSuwi(null);
        uwvMLHeader.value.getRouteInformatie().getBestemming().setCdVestigingSuwi(null);
        uwvMLHeader.value.getRouteInformatie().getBestemming().setMachine(null);

        uwvMLHeader.value.getRouteInformatie().setTussenstation(null);

        uwvMLHeader.value.getBerichtIdentificatie().setHerhalingsPogingnr(null);
        uwvMLHeader.value.getBerichtIdentificatie().setDatTijdVersturenBericht(null);
        uwvMLHeader.value.getBerichtIdentificatie().setDatTijdOntvangstBericht(null);
        uwvMLHeader.value.getBerichtIdentificatie().setApplicatieInformatie(null);

        uwvMLHeader.value.setTransactie(null);
        uwvMLHeader.value.setAuthenticatie(null);
        uwvMLHeader.value.setTransportServiceWensen(null);
    }

    private XMLGregorianCalendar getCurrentCalendar() {
        XMLGregorianCalendar calendar = null;
        try {
            calendar = DatatypeFactory.newInstance().newXMLGregorianCalendar(new GregorianCalendar());
        } catch (DatatypeConfigurationException e) {
            throw new IllegalStateException("Er ging iets mis bij het genereren van de Timestamp voor de header.", e);
        }
        return calendar;
    }
}
