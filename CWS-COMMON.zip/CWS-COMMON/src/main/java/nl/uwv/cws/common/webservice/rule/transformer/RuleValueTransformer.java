package nl.uwv.cws.common.webservice.rule.transformer;

import nl.uwv.cws.common.model.rule.AttributeRuleProperties;
import nl.uwv.cws.common.model.rule.CwsAttributeRule;

public interface RuleValueTransformer <T, R> {
    CwsAttributeRule getTransformRule();
    R transform(T originalValue, AttributeRuleProperties<? extends CwsAttributeRule> attributeRuleProperties);
}
