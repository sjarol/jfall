package nl.uwv.cws.common.dao;

import nl.uwv.cws.common.model.CwsAuthorization;
import nl.uwv.cws.common.model.configuratie.ConfiguratieKey;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Component;

@Component
public class AuthorizationDao {

    @Autowired
    @Qualifier("ppls_cws")
    private NamedParameterJdbcTemplate jdbcTemplate;

    public boolean isAfnemerAuthorisedByUsernameAndOin(CwsAuthorization cwsAuthorization, ConfiguratieKey configuratieKey, String levCd){
        String sql =
                "SELECT CASE " +
                "    WHEN EXISTS " +
                "        (SELECT * " +
                "         FROM AFN_AUTORISATIE_HIS auth " +
                "         INNER JOIN AFN_CONTRACT ac " +
                "         ON ac.contract_id = auth.contract_id " +
                "         AND ac.his_dat_in = auth.his_dat_in " +
                "         AND ac.lev_cd = :levCd " +
                "         WHERE auth.contract_id = :contractId " +
                "         AND auth.his_dat_in = :contractStartDat " +
                "         AND UPPER(auth.username) = :username " +
                "         AND (auth.oin = :oin OR auth.oin IS NULL) " +
                "         AND auth.his_ts_end = DATE '9999-12-31' " +
                "         ) " +
                "    THEN 1 " +
                "    ELSE 0 " +
                "    END " +
                "FROM dual ";

        SqlParameterSource namedParameters = new MapSqlParameterSource()
                .addValue("levCd", levCd)
                .addValue("contractId", configuratieKey.getContractNummer())
                .addValue("contractStartDat", configuratieKey.getContractStartDate())
                .addValue("username", cwsAuthorization.getUsername().toUpperCase())
                .addValue("oin", cwsAuthorization.getOin());

        Integer count = jdbcTemplate.queryForObject(sql, namedParameters, Integer.class);
        return count == 1;
    }
}
