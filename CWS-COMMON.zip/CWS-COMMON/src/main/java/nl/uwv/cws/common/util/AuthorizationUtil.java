package nl.uwv.cws.common.util;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.cxf.configuration.security.AuthorizationPolicy;

import javax.servlet.http.HttpServletRequest;
import javax.xml.ws.WebServiceContext;
import javax.xml.ws.handler.MessageContext;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Slf4j
public class AuthorizationUtil {
    private static final Pattern OIN_SERIALNUMBER_PATTERN = Pattern.compile("SERIALNUMBER=[0-9]+");

    private AuthorizationUtil(){}

    public static String extractOinSerialNumber(String oinCertificateValue) {
        //format of input (overheidcertificaat): "foo=bar, SERIALNUMBER=[oin], bar=foo"
        Matcher matcher = OIN_SERIALNUMBER_PATTERN.matcher(oinCertificateValue.toUpperCase());
        if (matcher.find()) {
            return matcher.group(0).substring(13);
        } else {
            return null;
        }
    }

    public static boolean hasBeheerderRol(WebServiceContext context, String beheerRol) {
        MessageContext messageContext = context.getMessageContext();
        HttpServletRequest servletRequest = (HttpServletRequest) messageContext.get("javax.xml.ws.servlet.request");
        return servletRequest.isUserInRole(beheerRol);
    }

    public static String retrieveTechnischeUsername(WebServiceContext context) {
        MessageContext messageContext = context.getMessageContext();
        HttpServletRequest servletRequest = (HttpServletRequest) messageContext.get("javax.xml.ws.servlet.request");
        String username = servletRequest.getRemoteUser();
        log.debug("servletRequest.getRemoteUser(): " + username);
        if (StringUtils.isEmpty(username)) {
            AuthorizationPolicy policy = (AuthorizationPolicy) messageContext.get(AuthorizationPolicy.class.getName());

            if(policy == null){
                throw new IllegalStateException("No AuthorizationPolicy was found in messageContext, try to use pre-emptive authorization maybe?");
            }

            if(policy.getUserName() == null){
                throw new IllegalStateException("No username was found in AuthorizationPolicy");
            }

            username = policy.getUserName().trim();
            log.debug("AuthorizationPolicy policy.getUserName(): " + username);
        }
        return username;
    }
}
