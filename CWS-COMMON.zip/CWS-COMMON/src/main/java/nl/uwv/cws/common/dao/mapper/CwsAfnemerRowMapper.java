package nl.uwv.cws.common.dao.mapper;

import nl.uwv.common.afnemermodel.domain.Afnemer;
import nl.uwv.common.afnemermodel.lang.AfnemerCode;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

@Component
public class CwsAfnemerRowMapper implements RowMapper<Afnemer> {
    @Override
    public Afnemer mapRow(ResultSet resultSet, int i) throws SQLException {
        Afnemer afnemer = new Afnemer();
        String foundAfnCode = resultSet.getString("AFN_CD");
        afnemer.setCode(new AfnemerCode(foundAfnCode));
        String indicatieVip = resultSet.getString("IND_VIP");
        afnemer.setIndicatieVIP(indicatieVip.equals("J"));
        return afnemer;
    }
}
