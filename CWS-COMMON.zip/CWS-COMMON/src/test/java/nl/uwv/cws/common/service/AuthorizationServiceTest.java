package nl.uwv.cws.common.service;

import nl.uwv.cws.common.dao.AuthorizationDao;
import nl.uwv.cws.common.exception.ApplicatieMeldingException;
import nl.uwv.cws.common.model.CwsAuthorization;
import nl.uwv.cws.common.model.CwsCommonFoutmelding;
import nl.uwv.cws.common.model.configuratie.ConfiguratieKey;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class AuthorizationServiceTest {

    @InjectMocks
    private AuthorizationService requestAuthorizationService;

    @Mock
    private AuthorizationDao mockAuthorizationDao;

    private ConfiguratieKey configuratieKey;
    private final String levCode = "lev_code";
    private final String userName = "username";
    private final String oin = "oin";

    @BeforeEach
    public void setup(){
        configuratieKey = ConfiguratieKey.builder()
                .contractNummer("contractNummer")
                .contractStartDate("contractStartDate")
                .versie("versie")
                .build();
    }

   @Test
    public void givenBeheerder_authorisation_shouldsucceed() {
       final boolean isBeheerder = true;
       CwsAuthorization cwsAuthorization = CwsAuthorization.builder()
               .username(userName)
               .oin(oin)
               .isBeheerder(isBeheerder)
               .build();


       requestAuthorizationService.isAfnemerAuthorised(cwsAuthorization, configuratieKey, levCode);
       verify(mockAuthorizationDao, times(0)).isAfnemerAuthorisedByUsernameAndOin(cwsAuthorization, configuratieKey, levCode);
    }

    @Test
    public void givenNotBeheerder_authorisation_shouldFail() {
        final boolean isBeheerder = false;
        CwsAuthorization cwsAuthorization = CwsAuthorization.builder()
                .username(userName)
                .oin(oin)
                .isBeheerder(isBeheerder)
                .build();

        when(mockAuthorizationDao.isAfnemerAuthorisedByUsernameAndOin(cwsAuthorization, configuratieKey, levCode)).thenReturn(true);

        requestAuthorizationService.isAfnemerAuthorised(cwsAuthorization, configuratieKey, levCode);
        verify(mockAuthorizationDao, times(1)).isAfnemerAuthorisedByUsernameAndOin(cwsAuthorization, configuratieKey, levCode);
    }

    @Test
    public void givenNotAuthorised_validationShouldFail_errorCode_shouldMatch() {
        final boolean isBeheerder = false;
        CwsAuthorization cwsAuthorization = CwsAuthorization.builder()
                .username(userName)
                .oin(oin)
                .isBeheerder(isBeheerder)
                .build();

        when(mockAuthorizationDao.isAfnemerAuthorisedByUsernameAndOin(cwsAuthorization, configuratieKey, levCode)).thenReturn(false);

        ApplicatieMeldingException thrown = Assertions.assertThrows(ApplicatieMeldingException.class, () -> {
            requestAuthorizationService.isAfnemerAuthorised(cwsAuthorization, configuratieKey, levCode);
        });

        Assertions.assertEquals(CwsCommonFoutmelding.F023.getMessage(), thrown.getFoutmelding().getMessage());
        Assertions.assertEquals(CwsCommonFoutmelding.F023.getSoort(), thrown.getFoutmelding().getSoort());
        verify(mockAuthorizationDao, times(1)).isAfnemerAuthorisedByUsernameAndOin(cwsAuthorization, configuratieKey, levCode);
    }

}
