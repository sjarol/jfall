package nl.uwv.cws.common.util;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class ByteUtilTest {
    @Test
    public void testEncodeRequestParams() {
        Integer startDate = 20150101;
        Integer endDate = 20190604;

        byte[] result = ByteUtil.encodeRequestParams(1601, startDate, endDate, true);

        //     5 bytes          4 bytes       4 bytes     1 byte
        // dec 1601             20150101      20190604    J (=74)
        // hex 00.00.00.06.41   01.33.77.55   01.34.15.8C 4A

        Assertions.assertEquals((byte)0x00, result[0]);
        Assertions.assertEquals((byte)0x00, result[1]);
        Assertions.assertEquals((byte)0x00, result[2]);
        Assertions.assertEquals((byte)0x06, result[3]);
        Assertions.assertEquals((byte)0x41, result[4]);
        Assertions.assertEquals((byte)0x01, result[5]);
        Assertions.assertEquals((byte)0x33, result[6]);
        Assertions.assertEquals((byte)0x77, result[7]);
        Assertions.assertEquals((byte)0x55, result[8]);
        Assertions.assertEquals((byte)0x01, result[9]);
        Assertions.assertEquals((byte)0x34, result[10]);
        Assertions.assertEquals((byte)0x15, result[11]);
        Assertions.assertEquals((byte)0x8C, result[12]);
        Assertions.assertEquals((byte)0x4A, result[13]);
    }
}
