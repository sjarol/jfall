package nl.uwv.cws.common.service;

import nl.uwv.cws.common.exception.ApplicatieMeldingException;
import nl.uwv.cws.common.model.CwsCommonFoutmelding;
import nl.uwv.cws.common.model.configuratie.Configuratie;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static nl.uwv.cws.common.model.CwsCommonConstants.DATE_FORMATTER;

public class ConfiguratieServiceTest {

    private ConfiguratieService configuratieService;

    @BeforeEach
    public void setup(){
        configuratieService = new ConfiguratieService();
    }

    @Test
    public void givenNoConfiguratieFound_validationShouldFail_usingCorrectErrorCode() {

        ApplicatieMeldingException thrown = Assertions.assertThrows(ApplicatieMeldingException.class, () -> {
            configuratieService.validateFoundConfiguratie(null);
        });

        Assertions.assertEquals(CwsCommonFoutmelding.F010.getCode(), thrown.getFoutmelding().getCode());
        Assertions.assertEquals(CwsCommonFoutmelding.F010.getMessage(), thrown.getFoutmelding().getMessage());
        Assertions.assertEquals(CwsCommonFoutmelding.F010.getSoort(), thrown.getFoutmelding().getSoort());
    }

    @Test
    public void givenConfiguratieNotDefinitief_validationShouldFail_usingCorrectErrorCode() {
        Configuratie configuratie = new Configuratie();
        configuratie.setStatus("CO");

        ApplicatieMeldingException thrown = Assertions.assertThrows(ApplicatieMeldingException.class, () -> {
            configuratieService.validateFoundConfiguratie(configuratie);
        });

        Assertions.assertEquals(CwsCommonFoutmelding.F009.getCode(), thrown.getFoutmelding().getCode());
        Assertions.assertEquals(CwsCommonFoutmelding.F009.getMessage(), thrown.getFoutmelding().getMessage());
        Assertions.assertEquals(CwsCommonFoutmelding.F009.getSoort(), thrown.getFoutmelding().getSoort());
    }

    @Test
    public void givenInvalidDateForConfiguratie_validationShouldFail_usingCorrectErrorCode() {
        Configuratie configuratie = new Configuratie();
        configuratie.setStatus("DE");
        configuratie.setStartDate(Long.valueOf(LocalDate.of(2099,1,1).format(DATE_FORMATTER)));


        ApplicatieMeldingException thrown = Assertions.assertThrows(ApplicatieMeldingException.class, () -> {
            configuratieService.validateFoundConfiguratie(configuratie);
        });

        Assertions.assertEquals(CwsCommonFoutmelding.F009.getCode(), thrown.getFoutmelding().getCode());
        Assertions.assertEquals(CwsCommonFoutmelding.F009.getMessage(), thrown.getFoutmelding().getMessage());
        Assertions.assertEquals(CwsCommonFoutmelding.F009.getSoort(), thrown.getFoutmelding().getSoort());
    }
}
