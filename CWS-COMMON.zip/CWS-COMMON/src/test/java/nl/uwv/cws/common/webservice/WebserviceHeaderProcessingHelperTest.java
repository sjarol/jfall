package nl.uwv.cws.common.webservice;

import nl.uwv.schemas.uwvml.header_v0202.BerichtIdentificatie;
import nl.uwv.schemas.uwvml.header_v0202.Partij;
import nl.uwv.schemas.uwvml.header_v0202.RouteInformatie;
import nl.uwv.schemas.uwvml.header_v0202.UwvMLHeader;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import javax.xml.ws.Holder;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

@ExtendWith(MockitoExtension.class)
public class WebserviceHeaderProcessingHelperTest {
    @InjectMocks
    private WebserviceHeaderProcessingHelper classUnderTest;

    private UwvMLHeader header;
    private Holder<UwvMLHeader> holderHeader;

    @BeforeEach
    public void setUp() {
        header = new UwvMLHeader();
        holderHeader = new Holder<>();
        holderHeader.value = header;
    }

    @Test
    public void givenCorrectlyFilledHeader_whenUpdateHeaderIsCalled_thenResponseHeaderIsCorrectlySet() {
        header.setRouteInformatie(new UwvMLHeader.RouteInformatie());
        header.getRouteInformatie().setBestemming(new Partij());
        header.getRouteInformatie().setBron(new RouteInformatie.Bron());
        header.getRouteInformatie().getBron().setApplicatieNaam("testApplicatieNaam");

        header.setBerichtIdentificatie(new BerichtIdentificatie());
        header.getBerichtIdentificatie().setBerichtReferentienr("1");
        header.getBerichtIdentificatie().setBerichtType(new BerichtIdentificatie.BerichtType());
        header.getRouteInformatie().setGegevensUitwisselingsnr("123");
        header.getRouteInformatie().setRefnrGegevensUitwisselingsExtern("456");
        header.getBerichtIdentificatie().getBerichtType().setVersieMajor("00");
        header.getBerichtIdentificatie().getBerichtType().setVersieMinor("09");

        classUnderTest.updateHeader(holderHeader, "Response", "CwsLoonaangifteResponse");

        assertEquals("testApplicatieNaam", header.getRouteInformatie().getBestemming().getApplicatieNaam());
        assertEquals("123", header.getRouteInformatie().getGegevensUitwisselingsnr());
        assertEquals("456", header.getRouteInformatie().getRefnrGegevensUitwisselingsExtern());
        assertEquals("1", header.getBerichtIdentificatie().getRequestBerichtReferentienr());
        assertEquals("POLIS LEVEREN", header.getRouteInformatie().getBron().getApplicatieNaam());
        assertEquals("CwsLoonaangifteResponse", header.getBerichtIdentificatie().getBerichtType().getBerichtNaam());
        assertEquals("00", header.getBerichtIdentificatie().getBerichtType().getVersieMajor());
        assertEquals("09", header.getBerichtIdentificatie().getBerichtType().getVersieMinor());
        assertEquals("01", header.getBerichtIdentificatie().getBerichtType().getBuildnr());
        assertEquals("Inkijk", header.getBerichtIdentificatie().getBerichtType().getCommunicatieType());
        assertEquals("Response", header.getBerichtIdentificatie().getBerichtType().getCommunicatieElement());
        assertEquals(2L, header.getBerichtIdentificatie().getIndTestbericht());

        assertNull(header.getRouteInformatie().getBron().getCdKolomSuwi());
        assertNull(header.getRouteInformatie().getBron().getCdPartijSuwi());
        assertNull(header.getRouteInformatie().getBron().getCdVestigingSuwi());
        assertNull(header.getRouteInformatie().getBron().getNaamContactpersoonAfd());
        assertNull(header.getRouteInformatie().getBron().getMachine());
        assertNull(header.getRouteInformatie().getBestemming().getCdKolomSuwi());
        assertNull(header.getRouteInformatie().getBestemming().getCdPartijSuwi());
        assertNull(header.getRouteInformatie().getBestemming().getCdVestigingSuwi());
        assertNull(header.getRouteInformatie().getBestemming().getMachine());
        assertNull(header.getRouteInformatie().getTussenstation());
        assertNull(header.getBerichtIdentificatie().getHerhalingsPogingnr());
        assertNull(header.getBerichtIdentificatie().getDatTijdVersturenBericht());
        assertNull(header.getBerichtIdentificatie().getDatTijdOntvangstBericht());
        assertNull(header.getBerichtIdentificatie().getApplicatieInformatie());
        assertNull(header.getTransactie());
        assertNull(header.getAuthenticatie());
        assertNull(header.getTransportServiceWensen());
    }

    @Test
    public void whenUpdateHeaderIsCalledWithCommunicationElementFout_thenResponseHeaderIsCorrectlySetWithFout() {
        header.setRouteInformatie(new UwvMLHeader.RouteInformatie());
        header.getRouteInformatie().setBestemming(new Partij());
        header.getRouteInformatie().setBron(new RouteInformatie.Bron());
        header.getRouteInformatie().getBron().setApplicatieNaam("testApplicatieNaam");

        header.setBerichtIdentificatie(new BerichtIdentificatie());
        header.getBerichtIdentificatie().setBerichtReferentienr("1");
        header.getBerichtIdentificatie().setBerichtType(new BerichtIdentificatie.BerichtType());
        header.getRouteInformatie().setGegevensUitwisselingsnr("123");
        header.getRouteInformatie().setRefnrGegevensUitwisselingsExtern("456");
        header.getBerichtIdentificatie().getBerichtType().setVersieMajor("00");
        header.getBerichtIdentificatie().getBerichtType().setVersieMinor("09");

        classUnderTest.updateHeader(holderHeader, "Fout", "CwsLoonaangifteResponse");

        assertEquals("testApplicatieNaam", header.getRouteInformatie().getBestemming().getApplicatieNaam());
        assertEquals("123", header.getRouteInformatie().getGegevensUitwisselingsnr());
        assertEquals("456", header.getRouteInformatie().getRefnrGegevensUitwisselingsExtern());
        assertEquals("1", header.getBerichtIdentificatie().getRequestBerichtReferentienr());
        assertEquals("POLIS LEVEREN", header.getRouteInformatie().getBron().getApplicatieNaam());
        assertEquals("CwsLoonaangifteResponse", header.getBerichtIdentificatie().getBerichtType().getBerichtNaam());
        assertEquals("00", header.getBerichtIdentificatie().getBerichtType().getVersieMajor());
        assertEquals("09", header.getBerichtIdentificatie().getBerichtType().getVersieMinor());
        assertEquals("01", header.getBerichtIdentificatie().getBerichtType().getBuildnr());
        assertEquals("Inkijk", header.getBerichtIdentificatie().getBerichtType().getCommunicatieType());
        assertEquals("Fout", header.getBerichtIdentificatie().getBerichtType().getCommunicatieElement());
        assertEquals(2L, header.getBerichtIdentificatie().getIndTestbericht());

        assertNull(header.getRouteInformatie().getBron().getCdKolomSuwi());
        assertNull(header.getRouteInformatie().getBron().getCdPartijSuwi());
        assertNull(header.getRouteInformatie().getBron().getCdVestigingSuwi());
        assertNull(header.getRouteInformatie().getBron().getNaamContactpersoonAfd());
        assertNull(header.getRouteInformatie().getBron().getMachine());
        assertNull(header.getRouteInformatie().getBestemming().getCdKolomSuwi());
        assertNull(header.getRouteInformatie().getBestemming().getCdPartijSuwi());
        assertNull(header.getRouteInformatie().getBestemming().getCdVestigingSuwi());
        assertNull(header.getRouteInformatie().getBestemming().getMachine());
        assertNull(header.getRouteInformatie().getTussenstation());
        assertNull(header.getBerichtIdentificatie().getHerhalingsPogingnr());
        assertNull(header.getBerichtIdentificatie().getDatTijdVersturenBericht());
        assertNull(header.getBerichtIdentificatie().getDatTijdOntvangstBericht());
        assertNull(header.getBerichtIdentificatie().getApplicatieInformatie());
        assertNull(header.getTransactie());
        assertNull(header.getAuthenticatie());
        assertNull(header.getTransportServiceWensen());
    }
}