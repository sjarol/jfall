package nl.uwv.cws.common.service;

import nl.uwv.commons.ws.UwvQueryLogger;
import nl.uwv.cws.common.model.CwsAuditInformation;
import nl.uwv.cws.common.model.CwsCommonConstants;
import nl.uwv.logger.domain.CompressedLong;
import nl.uwv.logger.domain.CompressedRecord;
import nl.uwv.logger.domain.RawDataType;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import javax.xml.ws.WebServiceContext;
import java.sql.Timestamp;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.nullable;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
public class CwsAuditLoggerServiceTest {

    @InjectMocks
    private CwsAuditLoggerService cwsAuditLoggerService;

    @Mock
    private UwvQueryLogger queryLogger;

    @Mock
    private WebServiceContext context;

    @Captor
    private ArgumentCaptor<Map<String, RawDataType>> queryLoggerValuesCaptor;

    @Test
    public void given_logRequest_withRightInformation(){
        CwsAuditInformation cwsAuditInformation = new CwsAuditInformation();
        cwsAuditInformation.addRequestedParameters("1234567890");

        cwsAuditLoggerService.log(cwsAuditInformation, context, Boolean.TRUE);

        verify(queryLogger).log(queryLoggerValuesCaptor.capture(), nullable(Timestamp.class) , any(WebServiceContext.class));
        assertArrayEquals(queryLoggerValuesCaptor.getValue().get(CwsCommonConstants.QUERYLOG_REQUEST_BSN).toByteArray(), new CompressedLong("1234567890").toByteArray());
        assertTrue(queryLoggerValuesCaptor.getValue().get(CwsCommonConstants.QUERYLOG_REQUEST_PARAMS) instanceof CompressedRecord);
    }

}
