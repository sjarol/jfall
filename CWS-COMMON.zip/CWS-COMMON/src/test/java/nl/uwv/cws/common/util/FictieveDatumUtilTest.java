package nl.uwv.cws.common.util;

import nl.uwv.cws.common.model.FictieveDatum;
import org.junit.jupiter.api.Test;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertFalse;

public class FictieveDatumUtilTest {

    @Test
    public void given_nonfictieveDatum_shouldBuildValidDatum() {
        String datumNotFicief = "20050603";
        FictieveDatum fictieveDatum = FictieveDatumUtil.buildFictieveDatum(datumNotFicief);
        assertThat(fictieveDatum.getDag(), is("03"));
        assertThat(fictieveDatum.getMaand(), is("06"));
        assertThat(fictieveDatum.getJaar(), is("2005"));
        assertThat(fictieveDatum.isDagFictief(), is(false));
        assertThat(fictieveDatum.isMaandFictief(), is(false));
        assertThat(fictieveDatum.isJaarFictief(), is(false));
    }

    @Test
    public void given_fictieveDagEnMaandInDatum_shouldBuildValidDatum() {
        String datumNotFicief = "20200000";
        FictieveDatum fictieveDatum = FictieveDatumUtil.buildFictieveDatum(datumNotFicief);
        assertThat(fictieveDatum.getDag(), is("00"));
        assertThat(fictieveDatum.getMaand(), is("00"));
        assertThat(fictieveDatum.getJaar(), is("2020"));
        assertThat(fictieveDatum.isDagFictief(), is(true));
        assertThat(fictieveDatum.isMaandFictief(), is(true));
        assertThat(fictieveDatum.isJaarFictief(), is(false));
        assertThat(fictieveDatum.isDagEnMaandFictief(), is(true));
        assertThat(fictieveDatum.isMaandEnJaarFictief(), is(false));
        assertThat(fictieveDatum.isDagEnMaandEnJaarFictief(), is(false));
    }

    @Test
    public void given_fictieveJaarInDatum_shouldBuildValidDatum() {
        String datumNotFicief = "1105";
        FictieveDatum fictieveDatum = FictieveDatumUtil.buildFictieveDatum(datumNotFicief);
        assertThat(fictieveDatum.getDag(), is("05"));
        assertThat(fictieveDatum.getMaand(), is("11"));
        assertThat(fictieveDatum.getJaar(), is("0000"));
        assertThat(fictieveDatum.isDagFictief(), is(false));
        assertThat(fictieveDatum.isMaandFictief(), is(false));
        assertThat(fictieveDatum.isJaarFictief(), is(true));
        assertThat(fictieveDatum.isDagEnMaandFictief(), is(false));
        assertThat(fictieveDatum.isMaandEnJaarFictief(), is(false));
        assertThat(fictieveDatum.isDagEnMaandEnJaarFictief(), is(false));
    }

    @Test
    public void given_fictieveMaandInDatum_shouldBuildValidDatum() {
        String datumNotFicief = "20200005";
        FictieveDatum fictieveDatum = FictieveDatumUtil.buildFictieveDatum(datumNotFicief);
        assertThat(fictieveDatum.getDag(), is("05"));
        assertThat(fictieveDatum.getMaand(), is("00"));
        assertThat(fictieveDatum.getJaar(), is("2020"));
        assertThat(fictieveDatum.isDagFictief(), is(false));
        assertThat(fictieveDatum.isMaandFictief(), is(true));
        assertThat(fictieveDatum.isJaarFictief(), is(false));
        assertThat(fictieveDatum.isDagEnMaandFictief(), is(false));
        assertThat(fictieveDatum.isMaandEnJaarFictief(), is(false));
        assertThat(fictieveDatum.isDagEnMaandEnJaarFictief(), is(false));
    }

    @Test
    public void given_fictieveDagMaandJaarInDatum_shouldBuildValidDatum() {
        String datumNotFicief = "0";
        FictieveDatum fictieveDatum = FictieveDatumUtil.buildFictieveDatum(datumNotFicief);
        assertThat(fictieveDatum.getDag(), is("00"));
        assertThat(fictieveDatum.getMaand(), is("00"));
        assertThat(fictieveDatum.getJaar(), is("0000"));
        assertThat(fictieveDatum.isDagFictief(), is(true));
        assertThat(fictieveDatum.isMaandFictief(), is(true));
        assertThat(fictieveDatum.isJaarFictief(), is(true));
        assertThat(fictieveDatum.isDagEnMaandFictief(), is(true));
        assertThat(fictieveDatum.isMaandEnJaarFictief(), is(true));
        assertThat(fictieveDatum.isDagEnMaandEnJaarFictief(), is(true));
    }

    @Test
    public void given_fictieveDagInDatum_shouldReturnTrue() {
        assertTrue(FictieveDatumUtil.isDatumFicitief("20220800"));
    }

    @Test
    public void given_fictieveMaandInDatum_shouldReturnTrue() {
        assertTrue(FictieveDatumUtil.isDatumFicitief("20220002"));
    }

    @Test
    public void given_fictieveJaarInDatum_shouldReturnTrue() {
        assertTrue(FictieveDatumUtil.isDatumFicitief("00000802"));
    }

    @Test
    public void given_nonFictieveDatum_shouldReturnFalse() {
        assertFalse(FictieveDatumUtil.isDatumFicitief("20220802"));
    }

    @Test
    public void given_fictieveDagEnMaandEnJaarInDatum_shouldBuildFictieveDatumIncludeJaar() {
        FictieveDatum fictieveDatum = FictieveDatum.builder()
                .dagFictief(true)
                .maandFictief(true)
                .jaarFictief(true)
                .build();
        assertThat(FictieveDatumUtil.getDateAsFictieveDatumIncludeJaar(fictieveDatum), is("18500101"));
    }

    @Test
    public void given_fictieveDagEnJaarInDatum_shouldBuildFictieveDatumIncludeJaar() {
        FictieveDatum fictieveDatum = FictieveDatum.builder()
                .dagFictief(true)
                .jaarFictief(true)
                .build();
        assertThat(FictieveDatumUtil.getDateAsFictieveDatumIncludeJaar(fictieveDatum), is("18500101"));
    }

    @Test
    public void given_fictieveMaandEnJaarInDatum_shouldBuildFictieveDatumIncludeJaar() {
        FictieveDatum fictieveDatum = FictieveDatum.builder()
                .maandFictief(true)
                .jaarFictief(true)
                .build();
        assertThat(FictieveDatumUtil.getDateAsFictieveDatumIncludeJaar(fictieveDatum), is("18500101"));
    }

    @Test
    public void given_fictieveJaarInDatum_shouldBuildFictieveDatumIncludeJaar() {
        FictieveDatum fictieveDatum = FictieveDatum.builder()
                .dag("02")
                .maand("08")
                .jaarFictief(true)
                .build();
        assertThat(FictieveDatumUtil.getDateAsFictieveDatumIncludeJaar(fictieveDatum), is("18500802"));
    }

    @Test
    public void given_fictieveDagEnMaandInDatum_shouldBuildFictieveDatumExcludeJaar() {
        FictieveDatum fictieveDatum = FictieveDatum.builder()
                .jaar("2022")
                .dagFictief(true)
                .maandFictief(true)
                .build();
        assertThat(FictieveDatumUtil.getDateAsFictieveDatumExcludeJaar(fictieveDatum), is("20220701"));
    }

    @Test
    public void given_fictieveDagInDatum_shouldBuildFictieveDatumExcludeJaar() {
        FictieveDatum fictieveDatum = FictieveDatum.builder()
                .maand("08")
                .jaar("2022")
                .dagFictief(true)
                .build();
        assertThat(FictieveDatumUtil.getDateAsFictieveDatumExcludeJaar(fictieveDatum), is("20220816"));
    }

    @Test
    public void given_fictieveMaandInDatum_shouldBuildFictieveDatumExcludeJaar() {
        FictieveDatum fictieveDatum = FictieveDatum.builder()
                .dag("02")
                .jaar("2022")
                .maandFictief(true)
                .build();
        assertThat(FictieveDatumUtil.getDateAsFictieveDatumExcludeJaar(fictieveDatum), is("20220702"));
    }
}
