package nl.uwv.cws.common.exception;

import nl.uwv.cws.common.model.Foutmelding;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
public class CwsCommonExceptionGeneratorTest {

    @Test
    public void given_callToFunctionalError_shouldReturnInstanceOf_ApplicatieMeldingException(){
        Foutmelding foutmelding = new Foutmelding() {
            @Override
            public String getSoort() {
                return "soort";
            }

            @Override
            public String getCode() {
                return "code";
            }

            @Override
            public String getMessage() {
                return "message";
            }
        };
        ApplicatieMeldingException applicatieMeldingException = CwsCommonExceptionGenerator.functionalError(foutmelding);
        assertEquals("code", applicatieMeldingException.getFoutmelding().getCode());
    }


    @Test
    public void given_callToTechnicalError_shouldReturnInstanceOf_ApplicatieMeldingException_witRightMessage(){
        ApplicatieMeldingException applicatieMeldingException = CwsCommonExceptionGenerator.technicalError("anyMessage", new Exception());
        assertEquals("F", applicatieMeldingException.getFoutmelding().getSoort());
        assertEquals("999", applicatieMeldingException.getFoutmelding().getCode());
        assertEquals("Onbekende fout", applicatieMeldingException.getFoutmelding().getMessage());
    }
}
