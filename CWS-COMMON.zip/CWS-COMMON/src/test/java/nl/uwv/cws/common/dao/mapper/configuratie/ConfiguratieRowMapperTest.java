package nl.uwv.cws.common.dao.mapper.configuratie;

import nl.uwv.cws.common.model.configuratie.Configuratie;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Date;
import java.sql.ResultSet;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class ConfiguratieRowMapperTest {

    private ConfiguratieRowMapper configuratieRowMapper = new ConfiguratieRowMapper();

    @Mock
    private ResultSet resultSet;

    @Test
    public void given_resultset_mapToBaseConfiguratie() throws Exception {

        when(resultSet.getLong("CCON_ID")).thenReturn(2L);
        when(resultSet.getLong("CONTRACT_ID")).thenReturn(2L);
        when(resultSet.getLong("CONT_HIS_DAT_IN")).thenReturn(2L);
        when(resultSet.getString("NAAM")).thenReturn("testNaam");
        when(resultSet.getLong("VERSION")).thenReturn(2L);
        when(resultSet.getString("STATUS")).thenReturn("testStatus");
        when(resultSet.getLong("HIS_DAT_IN")).thenReturn(20090101L);
        when(resultSet.getLong("HIS_DAT_END")).thenReturn(20200101L);
        when(resultSet.getDate("HIS_TS_IN")).thenReturn(Date.valueOf(LocalDate.of(2020,1,1)));
        when(resultSet.getDate("HIS_TS_END")).thenReturn(Date.valueOf(LocalDate.of(2099,1,1)));

        Configuratie configuratie = configuratieRowMapper.mapRow(resultSet, 1);

        assertNotNull(configuratie);
        assertEquals(new Long(2), configuratie.getCconId());
        assertEquals(new Long(2), configuratie.getContractId());
        assertEquals(new Long(2), configuratie.getContractStartDate());
        assertEquals("testNaam", configuratie.getNaam());
        assertEquals(new Long(2), configuratie.getVersion());
        assertEquals("testStatus", configuratie.getStatus());
        assertEquals(new Long(20090101L), configuratie.getStartDate());
        assertEquals(new Long(20200101L), configuratie.getEndDate());
        assertEquals(Date.valueOf(LocalDate.of(2020,1,1)), configuratie.getStartTransactionTimestamp());
        assertEquals(Date.valueOf(LocalDate.of(2099,1,1)), configuratie.getEndTransactionTimestamp());
    }
}
