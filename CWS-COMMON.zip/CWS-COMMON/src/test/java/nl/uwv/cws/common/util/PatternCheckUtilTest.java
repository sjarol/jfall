package nl.uwv.cws.common.util;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class PatternCheckUtilTest {

    @Test
    public void given_isInvalidDate_shouldValidateDate(){
        String datum = "20200101";
        assertFalse(PatternCheckUtil.isInvalidDate(datum));

        datum = "99991200";
        assertTrue(PatternCheckUtil.isInvalidDate(datum));
    }
}
