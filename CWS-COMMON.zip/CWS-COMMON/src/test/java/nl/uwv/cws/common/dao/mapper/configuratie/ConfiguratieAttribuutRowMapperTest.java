package nl.uwv.cws.common.dao.mapper.configuratie;


import nl.uwv.cws.common.model.configuratie.ConfiguratieAttribuut;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.ResultSet;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class ConfiguratieAttribuutRowMapperTest {

    private ConfiguratieAttribuutRowMapper configuratieAttribuutRowMapper;

    @BeforeEach
    public void setup(){
        configuratieAttribuutRowMapper = new ConfiguratieAttribuutRowMapper();
    }

    @Mock
    private ResultSet resultSet;

    @Test
    public void given_resultset_mapToBaseConfiguratie() throws Exception {
        when(resultSet.getString("META_COL_ID")).thenReturn("testMetaColId");
        when(resultSet.getString("PARENT_ID")).thenReturn("testParentId");
        when(resultSet.getString("TECH_NAAM")).thenReturn("testTechnaam");
        when(resultSet.getString("BRON_TABEL")).thenReturn("testBronTabel");
        when(resultSet.getString("BRON_RUBRIEK")).thenReturn("testBronRubriek");

        ConfiguratieAttribuut configuratieAttribuut  = configuratieAttribuutRowMapper.mapRow(resultSet, 1);

        assertNotNull(configuratieAttribuut);
        assertEquals("testMetaColId", configuratieAttribuut.getId());
        assertEquals("testParentId", configuratieAttribuut.getParentId());
        assertEquals("testTechnaam", configuratieAttribuut.getAttributeName());
        assertEquals("testBronRubriek", configuratieAttribuut.getColumn());
        assertEquals("testBronTabel", configuratieAttribuut.getTable());
    }
}
