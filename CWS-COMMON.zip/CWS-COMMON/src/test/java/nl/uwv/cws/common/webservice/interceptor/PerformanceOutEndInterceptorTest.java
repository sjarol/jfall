package nl.uwv.cws.common.webservice.interceptor;


import nl.uwv.commons.ws.UwvPerformanceLogger;
import nl.uwv.cws.common.performance.PerformanceTracker;
import org.apache.cxf.message.Exchange;
import org.apache.cxf.message.Message;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class PerformanceOutEndInterceptorTest {

    @InjectMocks
    private PerformanceOutEndInterceptor classUnderTest;
    @Mock
    private PerformanceTracker performanceTracker;
    @Mock
    private UwvPerformanceLogger performanceLogger;
    @Mock
    private Message mockMessage;

    @Captor
    private ArgumentCaptor<String> argument = ArgumentCaptor.forClass(String.class);

    @BeforeEach
    public void setUp() {
        Exchange mockExchange = mock(Exchange.class);
        Message mockOutMessage = mock(Message.class);
        when(mockExchange.getOutMessage()).thenReturn(mockOutMessage);
        when(mockOutMessage.remove("response.timing.start")).thenReturn(1559640419721L);
        Message mockInMessage = mock(Message.class);
        when(mockExchange.getInMessage()).thenReturn(mockInMessage);
        when(mockInMessage.remove("webservice.timing.start")).thenReturn(1559640343533L);
        when(mockMessage.getExchange()).thenReturn(mockExchange);
    }

    @Test
    public void handleMessageIsCalled_logPerformance() {
        classUnderTest.handleMessage(mockMessage);
        verify(performanceTracker, times(2)).track(argument.capture(), anyLong());
        assertArrayEquals(new Object[]{"04-OutgoingInterceptors", "01-CompleteWebservice"}, argument.getAllValues().toArray());
        verify(performanceLogger).logPerformance(anyLong());
    }
}