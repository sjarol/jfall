package nl.uwv.cws.common.util;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
public class NullValueUtilTest {

    @Mock
    private ResultSet resultSet;

    @Test
    public void given_callMethodGetDoubleOrNull_shouldReturnValueAsDouble() throws SQLException {
        Mockito.when(resultSet.getObject("column_name")).thenReturn(1.0);
        NullValueUtil.getDoubleOrNull(resultSet, "column_name");
        verify(resultSet, times(1)).getDouble("column_name");
    }

    @Test
    public void given_callMethodGetDoubleOrNull_shouldReturnNull() throws SQLException {
        Mockito.when(resultSet.getObject("column_name")).thenReturn(null);
        NullValueUtil.getDoubleOrNull(resultSet, "column_name");
        verify(resultSet, times(0)).getDouble("column_name");
    }

    @Test
    public void given_callMethodGetLongOrNull_shouldReturnValueAsLong() throws SQLException {
        Mockito.when(resultSet.getObject("column_name")).thenReturn(1L);
        NullValueUtil.getLongOrNull(resultSet, "column_name");
        verify(resultSet, times(1)).getLong("column_name");
    }

    @Test
    public void given_callMethodGetLongOrNull_shouldReturnNull() throws SQLException {
        Mockito.when(resultSet.getObject("column_name")).thenReturn(null);
        NullValueUtil.getLongOrNull(resultSet, "column_name");
        verify(resultSet, times(0)).getLong("column_name");
    }

    @Test
    public void given_callMethodGetIntegerOrNull_shouldReturnValueAsInteger() throws SQLException {
        Mockito.when(resultSet.getObject("column_name")).thenReturn(1.0);
        NullValueUtil.getIntegerOrNull(resultSet, "column_name");
        verify(resultSet, times(1)).getInt("column_name");
    }

    @Test
    public void given_callMethodGetIntegerOrNull_shouldReturnNull() throws SQLException {
        Mockito.when(resultSet.getObject("column_name")).thenReturn(null);
        NullValueUtil.getIntegerOrNull(resultSet, "column_name");
        verify(resultSet, times(0)).getInt("column_name");
    }

    @Test
    public void given_callMethodExtractMethods_shouldReturnExpectedValue() throws SQLException {
        assertNotNull(NullValueUtil.extractStringValueOrNull("value"));
        assertNull(NullValueUtil.extractStringValueOrNull(null));
        assertNotNull(NullValueUtil.extractStringFromDateValueOrNull(new Date(System.currentTimeMillis())));
        assertNull(NullValueUtil.extractStringFromDateValueOrNull(null));
        assertNotNull(NullValueUtil.extractBigDecimalValueOrNull(1.0));
        assertNull(NullValueUtil.extractBigDecimalValueOrNull(null));
        assertNotNull(NullValueUtil.extractBigIntegerValueOrNull(1L));
        Long nullLong = null;
        assertNull(NullValueUtil.extractBigIntegerValueOrNull(nullLong));
        assertNotNull(NullValueUtil.extractBigIntegerValueOrNull(1));
        Integer nullInteger = null;
        assertNull(NullValueUtil.extractBigIntegerValueOrNull(nullInteger));
        assertNotNull(NullValueUtil.extractBigIntegerValueOrNull("1"));
        String nullString = null;
        assertNull(NullValueUtil.extractBigIntegerValueOrNull(nullString));
    }

}
