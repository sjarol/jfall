package nl.uwv.cws.common.testutils;

import nl.uwv.cws.common.exception.ApplicatieMeldingException;
import org.hamcrest.Description;
import org.hamcrest.TypeSafeMatcher;

public class ExceptionMatcher extends TypeSafeMatcher<ApplicatieMeldingException> {

    private String foundCode;
    private String foundMessage;
    private String foundType;
    private final String expectedCode;
    private final String expectedMessage;
    private final String expectedType;

    public static ExceptionMatcher hasExceptionFields(String expectedCode, String expectedMessage, String expectedType){
        return new ExceptionMatcher(expectedCode, expectedMessage, expectedType);
    }

    private ExceptionMatcher(String expectedCode, String expectedMessage, String expectedType) {
        this.expectedCode = expectedCode;
        this.expectedMessage = expectedMessage;
        this.expectedType = expectedType;
    }

    @Override
    protected boolean matchesSafely(ApplicatieMeldingException e) {
        foundCode = e.getFoutmelding().getCode();
        foundMessage = e.getFoutmelding().getMessage();
        foundType = e.getFoutmelding().getSoort();

        return expectedCode.equalsIgnoreCase(foundCode)
                && expectedMessage.equalsIgnoreCase(foundMessage)
                && expectedType.equalsIgnoreCase(expectedType);
    }

    @Override
    public void describeTo(Description description) {
        description.appendValue(String.format("%s%s %s",foundType, foundCode, foundMessage))
                .appendText(" was found instead of ")
                .appendValue(String.format("%s%s %s",expectedType, expectedCode, expectedMessage));
    }
}
