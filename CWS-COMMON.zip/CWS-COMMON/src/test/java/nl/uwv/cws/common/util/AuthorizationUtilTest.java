package nl.uwv.cws.common.util;

import org.apache.cxf.configuration.security.AuthorizationPolicy;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import javax.servlet.http.HttpServletRequest;
import javax.xml.ws.WebServiceContext;
import javax.xml.ws.handler.MessageContext;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class AuthorizationUtilTest {
    @Mock
    private HttpServletRequest request;

    @Mock
    WebServiceContext wsContext;

    @Mock
    MessageContext msgContext;

    @Mock
    AuthorizationPolicy authorizationPolicy;

    @Test
    public void extractOinSerialNumber_WhenOinPresent_ThenReturnOin() {
        Assertions.assertEquals("0234", AuthorizationUtil.extractOinSerialNumber("foo=bar, SERIALNUMBER=0234, bar=foo"));
    }

    @Test
    public void extractOinSerialNumber_WhenOinIsAbsent_ThenRetunNull() {
        Assertions.assertEquals(null, AuthorizationUtil.extractOinSerialNumber("foo=bar, SERIALNUMBER_NOT_THERE=0234, bar=foo"));
    }

    @Test
    public void hasBeheerderRol_WhenBeheerderRol_ThenReturnTrue() {
        when(wsContext.getMessageContext()).thenReturn(msgContext);
        when(msgContext.get("javax.xml.ws.servlet.request")).thenReturn(request);
        when(request.isUserInRole("CWSNP_RAADPLEGEN_BEHEER")).thenReturn(true);

        assertTrue(AuthorizationUtil.hasBeheerderRol(wsContext, "CWSNP_RAADPLEGEN_BEHEER"));
    }

    @Test
    public void hasBeheerderRol_WhennNoRol_ThenReturnFalse() {
        when(wsContext.getMessageContext()).thenReturn(msgContext);
        when(msgContext.get("javax.xml.ws.servlet.request")).thenReturn(request);
        when(request.isUserInRole("CWSNP_RAADPLEGEN_BEHEER")).thenReturn(false);

        assertFalse(AuthorizationUtil.hasBeheerderRol(wsContext, "CWSNP_RAADPLEGEN_BEHEER"));
    }

    @Test
    public void retrieveTechnischeUsername_WhenRemoteUserPresent_ThenReturnRemoteUser() {
        when(wsContext.getMessageContext()).thenReturn(msgContext);
        when(msgContext.get("javax.xml.ws.servlet.request")).thenReturn(request);
        when(request.getRemoteUser()).thenReturn("SA_REMOTE_USER");

        assertEquals("SA_REMOTE_USER", AuthorizationUtil.retrieveTechnischeUsername(wsContext), "Lookup the remote user");
    }
    @Test
    public void retrieveTechnischeUsername_WhenNoRemoteUserPresent_ThenReturnAuthPolicyUser() {
        when(wsContext.getMessageContext()).thenReturn(msgContext);
        when(msgContext.get("javax.xml.ws.servlet.request")).thenReturn(request);
        when(request.getRemoteUser()).thenReturn(null);
        when(msgContext.get(AuthorizationPolicy.class.getName())).thenReturn(authorizationPolicy);
        when(authorizationPolicy.getUserName()).thenReturn("SA_AUTH_POLICY_USER");

        assertEquals("SA_AUTH_POLICY_USER", AuthorizationUtil.retrieveTechnischeUsername(wsContext), "Lookup the remote user");
    }
}