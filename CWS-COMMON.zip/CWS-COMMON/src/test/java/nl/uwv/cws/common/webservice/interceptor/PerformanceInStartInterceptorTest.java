package nl.uwv.cws.common.webservice.interceptor;

import org.apache.cxf.message.Message;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
public class PerformanceInStartInterceptorTest {

    @InjectMocks
    private PerformanceInStartInterceptor performanceInStartInterceptor;

    @Mock
    private Message message;

    @Captor
    private ArgumentCaptor<String> argument = ArgumentCaptor.forClass(String.class);

    @BeforeEach
    public void setUp() {
    }

    @Test
    public void handleMessageIsCalled_logPerformance() {
        performanceInStartInterceptor.handleMessage(message);

        verify(message, times(2)).put(argument.capture(), anyLong());
        assertEquals("request.timing.start", argument.getValue());
    }
}
