package nl.uwv.cws.common.dao.mapper;


import nl.uwv.common.afnemermodel.domain.Afnemer;
import nl.uwv.common.afnemermodel.lang.AfnemerCode;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.ResultSet;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class CwsAfnemerRowMapperTest {

    private CwsAfnemerRowMapper classUnderTest = new CwsAfnemerRowMapper();

    @Mock
    private ResultSet resultSet;

    @Test
    public void mapRow_AfnemerZonderIndicatieVip() throws Exception {

        when(resultSet.getString("AFN_CD")).thenReturn("AVB/DVB");
        when(resultSet.getString("IND_VIP")).thenReturn("N");

        Afnemer afnemer = classUnderTest.mapRow(resultSet, 1);

        assertNotNull(afnemer);
        assertEquals(new AfnemerCode("AVB/DVB"), afnemer.getCode());
        assertFalse(afnemer.isIndicatieVIP());
    }

    @Test
    public void mapRow_AfnemerMetIndicatieVip() throws Exception {

        when(resultSet.getString("AFN_CD")).thenReturn("AVB/DVB");
        when(resultSet.getString("IND_VIP")).thenReturn("J");

        Afnemer afnemer = classUnderTest.mapRow(resultSet, 1);

        assertNotNull(afnemer);
        assertEquals(new AfnemerCode("AVB/DVB"), afnemer.getCode());
        assertTrue(afnemer.isIndicatieVIP());
    }
}