package nl.uwv.cws.common.util;

import org.junit.jupiter.api.Test;

import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import static nl.uwv.cws.common.util.ConverterUtil.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class ConverterUtilTest {
    @Test
    public void testCodeToCodeMetVoorloopnul_givenNull_returnNull() {
        assertEquals(null, codeToCodeMetVoorloopnul(null, 2));
    }

    @Test
    public void testCodeToCodeMetVoorloopnul_givenCode_returnCodeMetVoorloopnul() {
        assertEquals("01", codeToCodeMetVoorloopnul("1", 2));
    }

    @Test
    public void testCodeToCodeMetVoorloopnul_givenCode_returnCode() {
        assertEquals("58", codeToCodeMetVoorloopnul("58", 2));
    }

    @Test
    public void testCodeToCodeMetVoorloopnul_givenNonNumericCode_returnNonNumericCode() {
        assertEquals("B", codeToCodeMetVoorloopnul("B", 2));
    }

    @Test
    public void testCodeToCodeMetVoorloopnul_givenLarge_number() {
        assertEquals("00000999999999999999", codeToCodeMetVoorloopnul("999999999999999", 20));
    }

    @Test
    public void testTotDatumToTotEnMetDatumLong_givenNull_returnNull() {
        Long longNull = null;
        assertEquals(null, totDatumToTotEnMetDatum(longNull));
    }

    @Test
    public void testTotDatumToTotEnMetDatumLong_given99991231L_returnNull() {
        assertEquals(null, totDatumToTotEnMetDatum(99991231L));
    }

    @Test
    public void testTotDatumToTotEnMetDatumLong_givenValidDate_returnDateMinusDay() {
        assertEquals(20220801L, totDatumToTotEnMetDatum(20220802L));
    }

    @Test
    public void testTotDatumToTotEnMetDatumDate_givenNull_returnNull() {
        Date dateNull = null;
        assertEquals(null, totDatumToTotEnMetDatum(dateNull));
    }

    @Test
    public void testTotDatumToTotEnMetDatumDate_given99991231_returnNull() {
        assertEquals(null, totDatumToTotEnMetDatum(Date.valueOf(LocalDate.parse("99991231", DateTimeFormatter.BASIC_ISO_DATE))));
    }

    @Test
    public void testTotDatumToTotEnMetDatumDate_givenValidDate_returnDateMinusDay() {
        assertEquals(Date.valueOf(LocalDate.parse("20220801", DateTimeFormatter.BASIC_ISO_DATE)), totDatumToTotEnMetDatum(Date.valueOf(LocalDate.parse("20220802", DateTimeFormatter.BASIC_ISO_DATE))));
    }

    @Test
    public void testTotEnMetDatumOneindigToNullLong_givenNull_returnNull() {
        Long longNull = null;
        assertEquals(null, totEnMetDatumOneindigToNull(longNull));
    }

    @Test
    public void testTotEnMetDatumOneindigToNullong_given99991231L_returnNull() {
        assertEquals(null, totEnMetDatumOneindigToNull(99991231L));
    }

    @Test
    public void testTotEnMetDatumOneindigToNullLong_givenValidDate_returnDateMinusDay() {
        assertEquals(20220802L, totEnMetDatumOneindigToNull(20220802L));
    }

    @Test
    public void testTotEnMetDatumOneindigToNullDate_givenNull_returnNull() {
        Date dateNull = null;
        assertEquals(null, totEnMetDatumOneindigToNull(dateNull));
    }

    @Test
    public void testTotEnMetDatumOneindigToNullDate_given99991231_returnNull() {
        assertEquals(null, totEnMetDatumOneindigToNull(Date.valueOf(LocalDate.parse("99991231", DateTimeFormatter.BASIC_ISO_DATE))));
    }

    @Test
    public void testTotEnMetDatumOneindigToNullDate_givenValidDate_returnDateMinusDay() {
        assertEquals(Date.valueOf(LocalDate.parse("20220802", DateTimeFormatter.BASIC_ISO_DATE)), totEnMetDatumOneindigToNull(Date.valueOf(LocalDate.parse("20220802", DateTimeFormatter.BASIC_ISO_DATE))));
    }
}
