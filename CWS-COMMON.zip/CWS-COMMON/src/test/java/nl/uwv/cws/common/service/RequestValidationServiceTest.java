package nl.uwv.cws.common.service;


import nl.uwv.cws.common.exception.ApplicatieMeldingException;
import nl.uwv.cws.common.model.CwsCommonFoutmelding;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class RequestValidationServiceTest {

    private RequestValidationService requestValidationService;

    @BeforeEach
    public void setup(){
        requestValidationService = new RequestValidationService();
    }

    @Test
    public void givenInvalidBsn_validationShouldFail() {
        final String bsn = "000000000";

        ApplicatieMeldingException thrown = Assertions.assertThrows(ApplicatieMeldingException.class, () -> {
            requestValidationService.validateBsn(bsn);
        });

        Assertions.assertEquals(CwsCommonFoutmelding.F003.getMessage(), thrown.getFoutmelding().getMessage());
        Assertions.assertEquals(CwsCommonFoutmelding.F003.getSoort(), thrown.getFoutmelding().getSoort());
    }

    @Test
    public void givenBsn_invalidElfproof_validationShouldFail() {
        final String bsn = "108967332";

        ApplicatieMeldingException thrown = Assertions.assertThrows(ApplicatieMeldingException.class, () -> {
            requestValidationService.validateBsn(bsn);
        });

        Assertions.assertEquals(CwsCommonFoutmelding.F004.getMessage(), thrown.getFoutmelding().getMessage());
        Assertions.assertEquals(CwsCommonFoutmelding.F004.getSoort(), thrown.getFoutmelding().getSoort());
    }

    @Test
    public void givenLoonheffingennummer_isNull_validationShouldFail() {
        final String lhNummer = null;

        ApplicatieMeldingException thrown = Assertions.assertThrows(ApplicatieMeldingException.class, () -> {
            requestValidationService.validateLoonheffingennummer(lhNummer);
        });

        Assertions.assertEquals(CwsCommonFoutmelding.F062.getMessage(), thrown.getFoutmelding().getMessage());
        Assertions.assertEquals(CwsCommonFoutmelding.F062.getSoort(), thrown.getFoutmelding().getSoort());
    }

    @Test
    public void givenLoonheffingennummer_invalid_validationShouldFail() {
        final String lhNummer = "000012246M92";

        ApplicatieMeldingException thrown = Assertions.assertThrows(ApplicatieMeldingException.class, () -> {
            requestValidationService.validateLoonheffingennummer(lhNummer);
        });

        Assertions.assertEquals(CwsCommonFoutmelding.F063.getMessage(), thrown.getFoutmelding().getMessage());
        Assertions.assertEquals(CwsCommonFoutmelding.F063.getSoort(), thrown.getFoutmelding().getSoort());
    }

    @Test
    public void givenEmptyContractNr_forConfiguratieKey_validationShouldFail_errorCode_shouldMatch() {
        final String contractNr = "";
        final String contractStart = "someDate";
        final String versieNrGegevensafnemerConf = "someVersie";

        ApplicatieMeldingException thrown = Assertions.assertThrows(ApplicatieMeldingException.class, () -> {
            requestValidationService.validateConfiguratieKey(contractNr, contractStart, versieNrGegevensafnemerConf);
        });

        Assertions.assertEquals(CwsCommonFoutmelding.F021.getMessage(), thrown.getFoutmelding().getMessage());
        Assertions.assertEquals(CwsCommonFoutmelding.F021.getSoort(), thrown.getFoutmelding().getSoort());
    }

    @Test
    public void givenEmptyContractStartr_forConfiguratieKey_validationShouldFail_errorCode_shouldMatch() {
        final String contractNr = "someNumber";
        final String emptyContractStart = "";
        final String versieNrGegevensafnemerConf = "someVersie";

        ApplicatieMeldingException thrownFirst = Assertions.assertThrows(ApplicatieMeldingException.class, () -> {
            requestValidationService.validateConfiguratieKey(contractNr, emptyContractStart, versieNrGegevensafnemerConf);
        });

        Assertions.assertEquals(CwsCommonFoutmelding.F018.getMessage(), thrownFirst.getFoutmelding().getMessage());
        Assertions.assertEquals(CwsCommonFoutmelding.F018.getSoort(), thrownFirst.getFoutmelding().getSoort());

        final String contractStart = "1234";

        ApplicatieMeldingException thrownSecond = Assertions.assertThrows(ApplicatieMeldingException.class, () -> {
            requestValidationService.validateConfiguratieKey(contractNr, contractStart, versieNrGegevensafnemerConf);
        });

        Assertions.assertEquals(CwsCommonFoutmelding.F018.getMessage(), thrownSecond.getFoutmelding().getMessage());
        Assertions.assertEquals(CwsCommonFoutmelding.F018.getSoort(), thrownSecond.getFoutmelding().getSoort());
    }

    @Test
    public void givenEmptyVersieNrGegevensafnemerConf_forConfiguratieKey_validationShouldFail_errorCode_shouldMatch() {
        final String contractNr = "someNumber";
        String contractStart = "20200101";
        final String versieNrGegevensafnemerConf = "";

        ApplicatieMeldingException thrown = Assertions.assertThrows(ApplicatieMeldingException.class, () -> {
            requestValidationService.validateConfiguratieKey(contractNr, contractStart, versieNrGegevensafnemerConf);
        });

        Assertions.assertEquals(CwsCommonFoutmelding.F017.getMessage(), thrown.getFoutmelding().getMessage());
        Assertions.assertEquals(CwsCommonFoutmelding.F017.getSoort(), thrown.getFoutmelding().getSoort());
    }
}
