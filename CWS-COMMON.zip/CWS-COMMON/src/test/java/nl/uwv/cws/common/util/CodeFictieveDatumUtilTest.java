package nl.uwv.cws.common.util;

import org.junit.jupiter.api.Test;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

/** geboortedatum
 20050603 .........................................0.........................................20050603
 20050600 .........................................1.........................................20050616
 20050003.........................................2.........................................20050703
 20050000.........................................3.........................................20050701
 00000603.........................................4.........................................18500603
 00000600.........................................5.........................................18500101
 00000003 .........................................6.........................................18500101
 00000000 .........................................7.........................................18500101
 overlijdensdatum
 20050603 .........................................0.........................................20050603
 20050600 .........................................1.........................................20050616
 20050003.........................................2.........................................20050703
 20050000.........................................3.........................................20050701
 00000000 .........................................8.........................................null
 *
 */
public class CodeFictieveDatumUtilTest {

    @Test
    public void given_nonFictieveGeboortedatum_shouldApplyCorrectCode() {
        Integer geboortedatumNotFicief = 20050603;
        Integer codeFictieveGeboortedatum = CodeFictieveDatumUtil.determineCodeFictieveGeboortedatum(geboortedatumNotFicief);
        assertThat(codeFictieveGeboortedatum, is(0));
    }

    @Test
    public void given_fictieveDagInGeboortedatum_shouldApplyRuleAsExpected() {
        Integer geboortedatumDagFicief = 20050600;
        Integer codeFictieveGeboortedatum = CodeFictieveDatumUtil.determineCodeFictieveGeboortedatum(geboortedatumDagFicief);
        assertThat(codeFictieveGeboortedatum, is(1));
    }

    @Test
    public void given_fictieveMaandInGeboortedatum_shouldApplyRuleAsExpected() {
        Integer geboortedatumMaandFicief = 20050003;
        Integer codeFictieveGeboortedatum = CodeFictieveDatumUtil.determineCodeFictieveGeboortedatum(geboortedatumMaandFicief);
        assertThat(codeFictieveGeboortedatum, is(2));
    }

    @Test
    public void given_fictieveDagEnMaandInGeboortedatum_shouldApplyRuleAsExpected() {
        Integer geboortedatumDagEnMaandFicief = 20050000;
        Integer codeFictieveGeboortedatum = CodeFictieveDatumUtil.determineCodeFictieveGeboortedatum(geboortedatumDagEnMaandFicief);
        assertThat(codeFictieveGeboortedatum, is(3));
    }

    @Test
    public void given_fictieveJaarInGeboortedatum_shouldApplyRuleAsExpected() {
        Integer geboortedatumJaarFicief = 603;
        Integer codeFictieveGeboortedatum = CodeFictieveDatumUtil.determineCodeFictieveGeboortedatum(geboortedatumJaarFicief);
        assertThat(codeFictieveGeboortedatum, is(4));
    }

    @Test
    public void given_fictieveDagEnJaarInGeboortedatum_shouldApplyRuleAsExpected() {
        Integer geboortedatumDagEnJaarFicief = 600;
        Integer codeFictieveGeboortedatum = CodeFictieveDatumUtil.determineCodeFictieveGeboortedatum(geboortedatumDagEnJaarFicief);
        assertThat(codeFictieveGeboortedatum, is(5));
    }

    @Test
    public void given_fictieveMaandEnJaarInGeboortedatum_shouldApplyRuleAsExpected() {
        Integer geboortedatumMaandEnJaarFicief = 3;
        Integer codeFictieveGeboortedatum = CodeFictieveDatumUtil.determineCodeFictieveGeboortedatum(geboortedatumMaandEnJaarFicief);
        assertThat(codeFictieveGeboortedatum, is(6));
    }

    @Test
    public void given_fictieveMixDagMaandJaarInGeboortedatum_shouldApplyRuleAsExpected() {
        Integer geboortedatumDagFicief = 0;
        Integer codeFictieveGeboortedatum = CodeFictieveDatumUtil.determineCodeFictieveGeboortedatum(geboortedatumDagFicief);
        assertThat(codeFictieveGeboortedatum, is(7));
    }

    @Test
    public void given_nonFictieveOverlijdensdatum_shouldApplyCorrectCode() {
        Integer overlijdensdatumNotFicief = 20050603;
        Integer codeFictieveOverlijdensdatum = CodeFictieveDatumUtil.determineCodeFictieveOverlijdensdatum(overlijdensdatumNotFicief);
        assertThat(codeFictieveOverlijdensdatum, is(0));
    }

    @Test
    public void given_fictieveDagInOverlijdensdatum_shouldApplyRuleAsExpected() {
        Integer overlijdensdatumDagFicief = 20050600;
        Integer codeFictieveOverlijdensdatum = CodeFictieveDatumUtil.determineCodeFictieveOverlijdensdatum(overlijdensdatumDagFicief);
        assertThat(codeFictieveOverlijdensdatum, is(1));
    }

    @Test
    public void given_fictieveMaandInOverlijdensdatum_shouldApplyRuleAsExpected() {
        Integer overlijdensdatumMaandFicief = 20050003;
        Integer codeFictieveOverlijdensdatum = CodeFictieveDatumUtil.determineCodeFictieveOverlijdensdatum(overlijdensdatumMaandFicief);
        assertThat(codeFictieveOverlijdensdatum, is(2));
    }

    @Test
    public void given_fictieveDagEnMaandInOverlijdensdatum_shouldApplyRuleAsExpected() {
        Integer overlijdensdatumDagEnMaandFicief = 20050000;
        Integer codeFictieveOverlijdensdatum = CodeFictieveDatumUtil.determineCodeFictieveOverlijdensdatum(overlijdensdatumDagEnMaandFicief);
        assertThat(codeFictieveOverlijdensdatum, is(3));
    }

    @Test
    public void given_fictieveMixDagMaandJaarInOverlijdensdatum_shouldApplyRuleAsExpected() {
        Integer overlijdensdatumFicief = 0;
        Integer codeFictieveGeboortedatum = CodeFictieveDatumUtil.determineCodeFictieveOverlijdensdatum(overlijdensdatumFicief);
        assertThat(codeFictieveGeboortedatum, is(8));
    }
}
