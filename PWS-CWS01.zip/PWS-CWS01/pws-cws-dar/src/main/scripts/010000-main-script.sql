SET echo OFF
SET define ON
SET verify OFF
SET serveroutput ON
SET sqlblanklines ON

WHENEVER SQLERROR EXIT SQL.SQLCODE
WHENEVER OSERROR  EXIT FAILURE

--XL Deploy Checksum:22d8577d227d28a3c191838e7c3a379c--

PROMPT Start installatie PWS-CWS01-1.0.0

@@./010000/install//001-pre_install.sql

@@./010000/install/pws-cws/001-program_id.sql
@@./010000/install/pws-cws/002-vul_menu_tabel.sql
@@./010000/install/pws-cws/003-vul_aut_tabel.sql
@@./010000/install/999-registreer_versie_in_database.sql

COMMIT;
PROMPT Einde installatie PWS-CWS01-1.0.0
