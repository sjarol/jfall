WHENEVER SQLERROR EXIT SQL.SQLCODE
WHENEVER OSERROR  EXIT FAILURE

SET echo OFF
SET define ON
SET verify OFF
SET serveroutput ON
SET sqlblanklines ON

define version='1.0.0'
define instance='PPLS_WL'
define environment='PPLS'
define programmanm='PWS-CWS01'

select distinct program_version
from
   scaladiv.app_configuration
where
   upper(program_name) = upper('&programmanm')
  and (program_instance = '&instance' or replace(program_instance,'-','') like (replace(substr('&instance',1,instr('&instance','-',-1)-1),'-','') || '%') )
  and program_environment = '&environment'
order by 1 desc;

/*
 * Parameters for registering a program:
 *  - program name
 *  - program major version
 *  - instance name
 *  - environment name
 */
call scaladiv.property_register_program(
    '&programmanm', '&version', '&instance', '&environment');

/*
 * Parameters for registering properties and their defaults:
 *  - program name
 *  - program major version
 *  - instance name
 *  - environment name
 *  - property name
 *  - property default value
 *  - property description
 */
-- Eerst default waardes setten, dan kan er ook een description van de property toegevoegd worden.
call scaladiv.property_set_default(
	'&programmanm', '&version', '&instance', '&environment',
	'perf.logging.active', 'true', 'Performance logger actief');

call scaladiv.property_set_default(
	'&programmanm', '&version', '&instance', '&environment',
	'perf.log.max.sla', '9000', 'in mil sec: als een request langer dan deze value duurt, word een record toegevoegd in de performance tabel');

call scaladiv.property_set_default(
	'&programmanm', '&version', '&instance', '&environment',
	'perf.log.rate', '3', 'de aantal requests dat een toevoeging van een record in de performance tabel triggert');

call scaladiv.property_set_default(
	'&programmanm', '&version', '&instance', '&environment',
	'logging.audit.enabled', 'true', 'audit logging actief');

call scaladiv.property_set_default(
	'&programmanm', '&version', '&instance', '&environment',
	'logging.audit.cachesize', '12', 'Cache grootte van de query logger op request niveau');

call scaladiv.property_set_default(
	'&programmanm', '&version', '&instance', '&environment',
	'log4j.init.file', '{{pws-cws01_log4j-init-file-path}}/log4j_pws_polis_plus.properties', 'Applicatie specifieke LOG4J properties');

call scaladiv.property_set_default(
	'&programmanm', '&version', '&instance', '&environment',
	'incident.file.path', '{{pws-cws01_incidentFilePath}}', 'Locatie voor de applicatie incident logging');

call scaladiv.property_set_default(
	'&programmanm', '&version', '&instance', '&environment',
	'pws09.kenmerk', '{{pws-cws01_pws09_kenmerk}}', 'CWS Productspecificatie kenmerk voor acceptatie omgevingen');



-- Daarna property waardes expliciet zetten met de placeholders.
call scaladiv.property_set_value(
	'&programmanm', '&version', '&instance', '&environment',
	'perf.logging.active', '{{pws-cws01_perf_logging_active}}');

call scaladiv.property_set_value(
	'&programmanm', '&version', '&instance', '&environment',
	'perf.log.max.sla', '{{pws-cws01_perf_log_max_sla}}');

call scaladiv.property_set_value(
	'&programmanm', '&version', '&instance', '&environment',
	'perf.log.rate', '{{pws-cws01_perf_log_rate}}');

call scaladiv.property_set_value(
	'&programmanm', '&version', '&instance', '&environment',
	'logging.audit.enabled', '{{pws-cws01_logging_audit_enabled}}');

call scaladiv.property_set_value(
	'&programmanm', '&version', '&instance', '&environment',
	'logging.audit.cachesize', '{{pws-cws01_logging_audit_cachesize}}');

call scaladiv.property_set_value(
	'&programmanm', '&version', '&instance', '&environment',
	'log4j.init.file', '{{pws-cws01_log4j-init-file-path}}/log4j_pws_polis_plus.properties');

call scaladiv.property_set_value(
	'&programmanm', '&version', '&instance', '&environment',
	'incident.file.path', '{{pws-cws01_incidentFilePath}}');

call scaladiv.property_set_value(
	'&programmanm', '&version', '&instance', '&environment',
	'pws09.kenmerk', '{{pws-cws01_pws09_kenmerk}}');
commit;

PROMPT ===== setup_properties: Ok =====
