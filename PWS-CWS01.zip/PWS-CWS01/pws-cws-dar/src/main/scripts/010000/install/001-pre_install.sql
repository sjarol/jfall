DECLARE
   error_incorrect EXCEPTION;
   returnv NUMBER;
BEGIN
   returnv := programma.installatie_check('DATABASE_LEVEREN','1.4.5');
   IF returnv = 1 THEN
      DBMS_OUTPUT.PUT_LINE('==========================================================');
      DBMS_OUTPUT.PUT_LINE('= DATABASE_LEVEREN 1.4.2 is nog niet geinstalleerd.      =');
      DBMS_OUTPUT.PUT_LINE('==========================================================');
      RAISE error_incorrect;
   END IF;
END;
/
