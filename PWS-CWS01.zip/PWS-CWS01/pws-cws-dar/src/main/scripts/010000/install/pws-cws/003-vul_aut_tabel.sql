DECLARE
   l_appid NUMBER;
   l_mnuid NUMBER;
   l_tabid NUMBER;
BEGIN
   MERGE INTO ppls_pws00.pws_auth_object a
   USING (SELECT 'APP'                                    AS type,
                 'PWS-CWS01'                              AS naam,
                 SYSTIMESTAMP                             AS his_ts_in,
                 TO_TIMESTAMP('31-12-9999', 'DD-MM-YYYY') AS his_ts_end,
                 NULL                                     AS parent_id
          FROM DUAL) b
   ON (a.type = b.type AND a.naam = b.naam AND a.his_ts_end = TO_TIMESTAMP('31-12-9999', 'DD-MM-YYYY'))
   WHEN NOT MATCHED THEN
      INSERT (type, naam, his_ts_in, his_ts_end, parent_id)
      VALUES (b.type, b.naam, b.his_ts_in, b.his_ts_end, b.parent_id);

   SELECT id INTO l_appid FROM ppls_pws00.pws_auth_object
   WHERE type = 'APP' AND naam = 'PWS-CWS01';

-- Add the menu item --
   MERGE INTO ppls_pws00.pws_auth_object a
   USING (SELECT 'MNU'                                    AS type,
                 'Beheer CWS Configuratie'                AS naam,
                 SYSTIMESTAMP                             AS his_ts_in,
                 TO_TIMESTAMP('31-12-9999', 'DD-MM-YYYY') AS his_ts_end,
                 l_appid                                  AS parent_id
          FROM DUAL) b
   ON (a.type = b.type AND a.naam = b.naam AND a.his_ts_end = TO_TIMESTAMP('31-12-9999', 'DD-MM-YYYY'))
   WHEN MATCHED THEN
      UPDATE SET parent_id = b.parent_id
   WHEN NOT MATCHED THEN
      INSERT (type, naam, his_ts_in, his_ts_end, parent_id)
      VALUES (b.type, b.naam, b.his_ts_in, b.his_ts_end, b.parent_id);

   SELECT id INTO l_mnuid FROM ppls_pws00.pws_auth_object
   WHERE type = 'MNU' AND naam = 'Beheer CWS Configuratie';

-- Add tabs --
   MERGE INTO PPLS_PWS00.PWS_AUTH_OBJECT a
   USING (SELECT 'TAB' AS type,
                 'Afnemers en CWS Leveringen' AS naam,
                 SYSTIMESTAMP AS his_ts_in,
                 TO_TIMESTAMP('31-12-9999', 'DD-MM-YYYY') AS his_ts_end,
                 l_mnuid AS parent_id
          FROM DUAL) b
   ON (a.type = b.type and a.naam = b.naam and a.his_ts_end = TO_TIMESTAMP('31-12-9999', 'DD-MM-YYYY'))
   WHEN MATCHED THEN
      UPDATE SET parent_id = b.parent_id
   WHEN NOT MATCHED THEN
      INSERT (type, naam, his_ts_in, his_ts_end, parent_id)
      VALUES (b.type, b.naam, b.his_ts_in, b.his_ts_end, b.parent_id);

   MERGE INTO PPLS_PWS00.PWS_AUTH_OBJECT a
   USING (SELECT 'TAB' AS type,
                 'Overzicht CWS Configuraties' AS naam,
                 SYSTIMESTAMP AS his_ts_in,
                 TO_TIMESTAMP('31-12-9999', 'DD-MM-YYYY') AS his_ts_end,
                 l_mnuid AS parent_id
          FROM DUAL) b
   ON (a.type = b.type and a.naam = b.naam and a.his_ts_end = TO_TIMESTAMP('31-12-9999', 'DD-MM-YYYY'))
   WHEN MATCHED THEN
      UPDATE SET parent_id = b.parent_id
   WHEN NOT MATCHED THEN
      INSERT (type, naam, his_ts_in, his_ts_end, parent_id)
      VALUES (b.type, b.naam, b.his_ts_in, b.his_ts_end, b.parent_id);

   SELECT id INTO l_tabid FROM ppls_pws00.pws_auth_object
   WHERE type = 'TAB' AND naam = 'Afnemers en CWS Leveringen' AND parent_id = l_mnuid;

 --Add tab specific components --
   MERGE INTO PPLS_PWS00.PWS_AUTH_OBJECT a
   USING (SELECT 'BTN' AS type,
                 'Toevoegen' AS naam,
                 SYSTIMESTAMP AS his_ts_in,
                 TO_TIMESTAMP('31-12-9999', 'DD-MM-YYYY') AS his_ts_end,
                 l_tabid AS parent_id
          FROM DUAL) b
   ON (a.type = b.type and a.naam = b.naam and a.parent_id = b.parent_id and a.his_ts_end = TO_TIMESTAMP('31-12-9999', 'DD-MM-YYYY'))
   WHEN NOT MATCHED THEN
      INSERT (type, naam, his_ts_in, his_ts_end, parent_id)
      VALUES (b.type, b.naam, b.his_ts_in, b.his_ts_end, b.parent_id);

   MERGE INTO PPLS_PWS00.PWS_AUTH_OBJECT a
   USING (SELECT 'BTN' AS type,
                 'Wijzigen' AS naam,
                 SYSTIMESTAMP AS his_ts_in,
                 TO_TIMESTAMP('31-12-9999', 'DD-MM-YYYY') AS his_ts_end,
                 l_tabid AS parent_id
          FROM DUAL) b
   ON (a.type = b.type and a.naam = b.naam and a.parent_id = b.parent_id and a.his_ts_end = TO_TIMESTAMP('31-12-9999', 'DD-MM-YYYY'))
   WHEN NOT MATCHED THEN
      INSERT (type, naam, his_ts_in, his_ts_end, parent_id)
      VALUES (b.type, b.naam, b.his_ts_in, b.his_ts_end, b.parent_id);

   MERGE INTO PPLS_PWS00.PWS_AUTH_OBJECT a
   USING (SELECT 'BTN' AS type,
                 'Verwijderen' AS naam,
                 SYSTIMESTAMP AS his_ts_in,
                 TO_TIMESTAMP('31-12-9999', 'DD-MM-YYYY') AS his_ts_end,
                 l_tabid AS parent_id
          FROM DUAL) b
   ON (a.type = b.type and a.naam = b.naam and a.parent_id = b.parent_id and a.his_ts_end = TO_TIMESTAMP('31-12-9999', 'DD-MM-YYYY'))
   WHEN NOT MATCHED THEN
      INSERT (type, naam, his_ts_in, his_ts_end, parent_id)
      VALUES (b.type, b.naam, b.his_ts_in, b.his_ts_end, b.parent_id);

   MERGE INTO PPLS_PWS00.PWS_AUTH_OBJECT a
   USING (SELECT 'BTN' AS type,
                 'Raadplegen' AS naam,
                 SYSTIMESTAMP AS his_ts_in,
                 TO_TIMESTAMP('31-12-9999', 'DD-MM-YYYY') AS his_ts_end,
                 l_tabid AS parent_id
          FROM DUAL) b
   ON (a.type = b.type and a.naam = b.naam and a.parent_id = b.parent_id and a.his_ts_end = TO_TIMESTAMP('31-12-9999', 'DD-MM-YYYY'))
   WHEN NOT MATCHED THEN
      INSERT (type, naam, his_ts_in, his_ts_end, parent_id)
      VALUES (b.type, b.naam, b.his_ts_in, b.his_ts_end, b.parent_id);

   MERGE INTO PPLS_PWS00.PWS_AUTH_OBJECT a
   USING (SELECT 'BTN' AS type,
                 'Configuratie Definitief' AS naam,
                 SYSTIMESTAMP AS his_ts_in,
                 TO_TIMESTAMP('31-12-9999', 'DD-MM-YYYY') AS his_ts_end,
                 l_tabid AS parent_id
          FROM DUAL) b
   ON (a.type = b.type and a.naam = b.naam and a.parent_id = b.parent_id and a.his_ts_end = TO_TIMESTAMP('31-12-9999', 'DD-MM-YYYY'))
   WHEN NOT MATCHED THEN
      INSERT (type, naam, his_ts_in, his_ts_end, parent_id)
      VALUES (b.type, b.naam, b.his_ts_in, b.his_ts_end, b.parent_id);

   MERGE INTO PPLS_PWS00.PWS_AUTH_OBJECT a
   USING (SELECT 'BTN' AS type,
                 'Genereer Productspecificatie' AS naam,
                 SYSTIMESTAMP AS his_ts_in,
                 TO_TIMESTAMP('31-12-9999', 'DD-MM-YYYY') AS his_ts_end,
                 l_tabid AS parent_id
          FROM DUAL) b
   ON (a.type = b.type and a.naam = b.naam and a.parent_id = b.parent_id and a.his_ts_end = TO_TIMESTAMP('31-12-9999', 'DD-MM-YYYY'))
   WHEN NOT MATCHED THEN
      INSERT (type, naam, his_ts_in, his_ts_end, parent_id)
      VALUES (b.type, b.naam, b.his_ts_in, b.his_ts_end, b.parent_id);

   MERGE INTO PPLS_PWS00.PWS_AUTH_OBJECT a
   USING (SELECT 'BTN' AS type,
                 'Export' AS naam,
                 SYSTIMESTAMP AS his_ts_in,
                 TO_TIMESTAMP('31-12-9999', 'DD-MM-YYYY') AS his_ts_end,
                 l_tabid AS parent_id
          FROM DUAL) b
   ON (a.type = b.type and a.naam = b.naam and a.parent_id = b.parent_id and a.his_ts_end = TO_TIMESTAMP('31-12-9999', 'DD-MM-YYYY'))
   WHEN NOT MATCHED THEN
      INSERT (type, naam, his_ts_in, his_ts_end, parent_id)
      VALUES (b.type, b.naam, b.his_ts_in, b.his_ts_end, b.parent_id);

   MERGE INTO PPLS_PWS00.PWS_AUTH_OBJECT a
   USING (SELECT 'BTN' AS type,
                 'Import' AS naam,
                 SYSTIMESTAMP AS his_ts_in,
                 TO_TIMESTAMP('31-12-9999', 'DD-MM-YYYY') AS his_ts_end,
                 l_tabid AS parent_id
          FROM DUAL) b
   ON (a.type = b.type and a.naam = b.naam and a.parent_id = b.parent_id and a.his_ts_end = TO_TIMESTAMP('31-12-9999', 'DD-MM-YYYY'))
   WHEN NOT MATCHED THEN
      INSERT (type, naam, his_ts_in, his_ts_end, parent_id)
      VALUES (b.type, b.naam, b.his_ts_in, b.his_ts_end, b.parent_id);

   COMMIT;
END;
/
