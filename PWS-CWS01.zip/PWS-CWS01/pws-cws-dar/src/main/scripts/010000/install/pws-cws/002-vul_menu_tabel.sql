MERGE INTO PPLS_PWS00.PWS_MENU a
USING (SELECT 'PWS09'                                      AS mnu_cd,
              'Beheer CWS Configuratie'                    AS naam,
              'C01'                                        AS sortering,
              '/cws/ui/cws-config'                         AS url,
              'EDIT'                                       AS icon,
              'PWS-09 Beheer CWS Configuratie bij Afnemer' AS omschrijving,
              SYSTIMESTAMP                                 AS his_ts_in,
              TO_TIMESTAMP('31-12-9999', 'DD-MM-YYYY')     AS his_ts_end
       FROM DUAL) b
ON (a.mnu_cd = b.mnu_cd and a.naam = b.naam and a.his_ts_end > SYSTIMESTAMP)
WHEN NOT MATCHED THEN
   INSERT (mnu_cd, naam, sortering, url, icon, omschrijving, his_ts_in, his_ts_end)
   VALUES (b.mnu_cd, b.naam, b.sortering, b.url, b.icon, b.omschrijving, b.his_ts_in, b.his_ts_end);

COMMIT;
