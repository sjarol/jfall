MERGE INTO SCALAMETA.PROGRAM pgm
USING (SELECT 1609        AS pgrm_id,
              'PWS-CWS01' AS name,
              NULL        AS sys_nm,
              NULL        AS pnlt_cd,
			  NULL        AS pnl_cd
       FROM DUAL) b
ON (pgm.pgrm_id = b.pgrm_id)
WHEN MATCHED THEN
   UPDATE SET
   sys_nm   = b.sys_nm,
   pnlt_cd  = b.pnlt_cd,
   pnl_cd   = b.pnl_cd
WHEN NOT MATCHED THEN
   INSERT (pgrm_id, name, sys_nm, pnlt_cd, pnl_cd)
   VALUES (b.pgrm_id, b.name, b.sys_nm, b.pnlt_cd, b.pnl_cd);

COMMIT;
