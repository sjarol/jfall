UPDATE ppls_pws00.pws_auth_object
SET parent_id = NULL
WHERE type = 'MNU'
AND naam = 'Beheer CWS Configuratie'
AND his_ts_end = TO_TIMESTAMP('31-12-9999', 'DD-MM-YYYY');

DELETE FROM ppls_pws00.pws_auth_object
WHERE type = 'APP'
AND naam = 'PWS-CWS01'
AND his_ts_end = TO_TIMESTAMP('31-12-9999', 'DD-MM-YYYY');

COMMIT;
