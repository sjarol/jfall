DELETE
FROM PPLS_PWS00.PWS_MENU
WHERE mnu_cd = 'PWS09'
AND naam = 'Beheer CWS Configuratie';

COMMIT;
