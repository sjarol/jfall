WHENEVER SQLERROR EXIT SQL.SQLCODE
WHENEVER OSERROR  EXIT FAILURE

SET echo OFF
SET define ON
SET verify OFF
SET serveroutput ON
SET sqlblanklines ON

PROMPT Start rollback PWS-CWS01-1.0.0

@@./010000/uninstall/999-registreer_versie_in_database-rollback.sql
@@./010000/uninstall/pws-cws/003-vul_aut_tabel_rollback.sql
@@./010000/uninstall/pws-cws/002-vul_menu_tabel_rollback.sql

COMMIT;
PROMPT Einde rollback PWS-CWS01-1.0.0
