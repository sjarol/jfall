WHENEVER SQLERROR EXIT SQL.SQLCODE
WHENEVER OSERROR  EXIT FAILURE

SET echo OFF
SET define ON
SET verify OFF
SET serveroutput ON
SET sqlblanklines ON

define pgrm_id=1609
define env_name='PPLS'
define instance_name='PPLS_WL'
define release='1.0.0'

DELETE FROM scaladiv.appi_config WHERE appi_id = (SELECT appi_id
                                                  FROM scaladiv.app_instance
                                                  WHERE pgrm_id       = &pgrm_id
                                                  AND   env_name      = '&env_name'
                                                  AND   instance_name = '&instance_name'
                                                  AND   release       = '&release');

DELETE FROM scaladiv.app_instance WHERE pgrm_id       = &pgrm_id
                                  AND   env_name      = '&env_name'
                                  AND   instance_name = '&instance_name'
                                  AND   release       = '&release';
