package test.common;

import nl.uwv.pws.backend.filter.AbstractSqlFilter;
import org.mockito.ArgumentMatcher;

public class SqlFilterAbstractArgumentMatcher implements ArgumentMatcher<AbstractSqlFilter> {

   public SqlFilterAbstractArgumentMatcher(AbstractSqlFilter filter){
      this.left = filter;
   }

   private AbstractSqlFilter left;

   @Override
   public boolean matches(AbstractSqlFilter right) {
      return right.getFilterSql().equalsIgnoreCase(left.getFilterSql());
   }
}
