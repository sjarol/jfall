package test.common;

import nl.uwv.pws.cws.model.ContractDetails;
import org.mockito.ArgumentMatcher;

public class ContractDetailsArgumentMatcher implements ArgumentMatcher<ContractDetails> {

   public ContractDetailsArgumentMatcher(final ContractDetails ContractDetails){
      this.left = ContractDetails;
   }

   private ContractDetails left;

   @Override
   public boolean matches(ContractDetails right) {
     return right.getContractId().equals(left.getContractId());
   }
}
