package test.common;

import org.mockito.ArgumentMatcher;

public class StringArgumentMatcher implements ArgumentMatcher<String> {

   public StringArgumentMatcher(final String String){
      this.left = String;
   }

   private String left;

   @Override
   public boolean matches(String right) {
     return right.equals(left);
   }
}
