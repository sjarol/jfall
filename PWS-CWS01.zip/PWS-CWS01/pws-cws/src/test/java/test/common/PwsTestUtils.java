package test.common;

import com.vaadin.flow.component.Component;

public class PwsTestUtils {

   public static Component findDescendentsById(final String id, final Component component) {
      return component.getChildren()
            .filter(childComponent -> childComponent.getId().isPresent() && childComponent.getId().get().equalsIgnoreCase(id))
            .findFirst()
            .orElse(null);
   }
}
