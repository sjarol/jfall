package test.common;

import nl.uwv.pws.backend.dao.SqlFilter;
import org.mockito.ArgumentMatcher;

public class SqlFilterArgumentMatcher implements ArgumentMatcher<SqlFilter> {

   public SqlFilterArgumentMatcher(SqlFilter filter){
      this.left = filter;
   }

   private SqlFilter left;

   @Override
   public boolean matches(SqlFilter right) {
     return right.getFilterSql().equalsIgnoreCase(left.getFilterSql());
   }
}
