package nl.uwv.pws.cws.views.beheer.tabs.layout.cwsla;

import com.vaadin.flow.component.checkbox.Checkbox;
import nl.uwv.pws.cws.model.viewtab.BaseCwsOverzichtFilterOption;
import nl.uwv.pws.cws.model.viewtab.CwsLaFilter;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

public class CwsLaOverzichtFilterFormLayoutTest {

   private CwsLaOverzichtFilterFormLayout cwsLaOverzichtFilterFormLayout;
   private List<Checkbox> checkboxList;

   @BeforeEach
   public void setup() {
      cwsLaOverzichtFilterFormLayout = new CwsLaOverzichtFilterFormLayout();
      this.checkboxList = cwsLaOverzichtFilterFormLayout.getCheckboxList();
   }

   @Test
   @DisplayName("CWS-LA OverzichtConfiguratieLayout contains all checkboxes")
   void testCreateLayout() {
      Optional<Checkbox> optionalCheckboxCodeSoortIkv = checkboxList.stream().filter(checkbox -> checkbox.getLabel().equals("Filter code soort inkomstenverhouding")
            && checkbox.getId().get().equals(CwsLaFilter.CD_SOORT_IKVS.name())).findFirst();
      assertThat(optionalCheckboxCodeSoortIkv.isPresent()).isTrue();

      Optional<Checkbox> optionalCheckboxNihilLnsvUitsluiten = checkboxList.stream().filter(checkbox -> checkbox.getLabel().equals("Filter nihil loon SV uitsluiten")
            && checkbox.getId().get().equals(CwsLaFilter.NIHIL_LNSV_UITSLUITEN.name())).findFirst();
      assertThat(optionalCheckboxNihilLnsvUitsluiten.isPresent()).isTrue();

      Optional<Checkbox> optionalCheckboxNihilLnlbphUitsluiten = checkboxList.stream().filter(checkbox -> checkbox.getLabel().equals("Filter nihil loon LB/PH uitsluiten")
            && checkbox.getId().get().equals(CwsLaFilter.NIHIL_LNLBPH_UITSLUITEN.name())).findFirst();
      assertThat(optionalCheckboxNihilLnlbphUitsluiten.isPresent()).isTrue();
   }

   @Test
   @DisplayName("CWS-LA OverzichtConfiguratieLayout return only selected Checkbox")
   void testSelectedFilters() {
      Optional<Checkbox> optionalCheckboxCodeSoortIkv = checkboxList.stream().filter(checkbox -> checkbox.getLabel().equals("Filter code soort inkomstenverhouding")
            && checkbox.getId().get().equals(CwsLaFilter.CD_SOORT_IKVS.name())).findFirst();
      optionalCheckboxCodeSoortIkv.get().setValue(true);

      List<BaseCwsOverzichtFilterOption> filterOptionList = cwsLaOverzichtFilterFormLayout.getSelectedFilters();
      BaseCwsOverzichtFilterOption filterOption = filterOptionList.listIterator().next();

      assertThat(filterOption.getEnumName()).isEqualTo(CwsLaFilter.CD_SOORT_IKVS.name());
      assertThat(filterOption.getColumnName()).isEqualTo("Filter code soort IKV");
      assertThat(filterOption.getHeaderColumnName()).isEqualTo("Filter code soort inkomstenverhouding");
   }
}
