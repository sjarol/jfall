package nl.uwv.pws.cws.backend.service.cwshr;

import nl.uwv.pws.cws.backend.dao.CwsConfigurationDao;
import nl.uwv.pws.cws.backend.service.ProductSpecificationService;
import nl.uwv.pws.cws.model.BaseCwsFilterType;
import nl.uwv.pws.cws.model.CwsConfiguration;
import nl.uwv.pws.cws.model.CwsHrFilterType;
import nl.uwv.pws.cws.model.SelectionCriteria;
import org.junit.jupiter.api.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import java.io.IOException;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.junit.jupiter.api.TestInstance.Lifecycle.PER_CLASS;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@TestInstance(PER_CLASS)
public class CwsHrProductSpecContentGeneratorServiceTest {

   private CwsHrProductSpecContentGeneratorService cwsHrProductSpecContentGeneratorService;

   private MockedStatic<CwsConfigurationDao> cwsConfigurationDaoMockedStatic;
   private CwsConfigurationDao cwsConfigurationDao;

   @BeforeAll
   public void setupOnce() {
      this.cwsConfigurationDaoMockedStatic = Mockito.mockStatic(CwsConfigurationDao.class);
      this.cwsConfigurationDao = mock(CwsConfigurationDao.class);

      cwsConfigurationDaoMockedStatic.when(CwsConfigurationDao::getInstance).thenReturn(cwsConfigurationDao);
   }

   @AfterAll
   public void cleanup(){
      cwsConfigurationDaoMockedStatic.close();
   }


   @Test
   @DisplayName("Should use correct parameters to prepare product specification generation")
   void testFileAndFolderNamesForProductSpecification() {
      cwsHrProductSpecContentGeneratorService = new CwsHrProductSpecContentGeneratorService(CwsConfiguration.builder()
            .configurationId(999999L)
            .configurationVersion(10L)
            .build(),
            "dummyKenmerk", "dummyRequestHeader", "dummyResponseHeader");

      assertThat(cwsHrProductSpecContentGeneratorService.getPdfTemplateFileName()).isEqualTo("../templates/cwshr-product-specificatie-template.odt");
      assertThat(cwsHrProductSpecContentGeneratorService.getExampleRequestFileNames()).isEqualTo(new String [] {"Request_persoon.xml", "Request_maatschappelijkeactiviteit.xml"});
      assertThat(cwsHrProductSpecContentGeneratorService.getExampleXmlFolderName()).isEqualTo("cwshr/");
      assertThat(cwsHrProductSpecContentGeneratorService.getResponseBodyRootElementName()).isEqualTo("CwsHandelsregisterResponse");
   }

   @Test
   @DisplayName("Should return correct mapping for CWS-HR at service construction")
   public void testGetSelectieCriteriaMapping(){
      Map<BaseCwsFilterType, String> filterMap = new HashMap<>();
      filterMap.put(CwsHrFilterType.BEEINDIGD_ADRES_UITSLUITEN, "J");
      SelectionCriteria selectionCriteria = new SelectionCriteria("CWS-HR");
      selectionCriteria.setFilterMap(filterMap);
      when(cwsConfigurationDao.selectSelectionCriteriaByConfigId(anyLong())).thenReturn(selectionCriteria);

      cwsHrProductSpecContentGeneratorService = new CwsHrProductSpecContentGeneratorService(CwsConfiguration.builder()
            .configurationId(999999L)
            .configurationVersion(10L)
            .build(),
            "dummyKenmerk", "dummyRequestHeader", "dummyResponseHeader");
      Map<String, Object> mappingMap = cwsHrProductSpecContentGeneratorService.getSelectieCriteriaMapping();
      String value = (String) mappingMap.get("condition_beeindigdAdresUitsluiten");
      assertThat(value).isEqualTo("true");
   }
}
