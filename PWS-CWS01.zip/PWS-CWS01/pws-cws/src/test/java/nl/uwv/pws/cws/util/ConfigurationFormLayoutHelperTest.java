package nl.uwv.pws.cws.util;

import com.vaadin.flow.component.HasValue;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.datepicker.DatePicker;
import com.vaadin.flow.component.formlayout.FormLayout;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.binder.Binder;
import nl.uwv.pws.cws.model.CwsConfiguration;
import nl.uwv.pws.cws.views.beheer.tabs.layout.ConfigurationFormLayoutHelper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.MockedStatic;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Locale;

import static nl.uwv.pws.cws.util.Constants.*;
import static nl.uwv.pws.cws.util.CwsUIUtils.findComponent;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@SuppressWarnings("ALL")
public class ConfigurationFormLayoutHelperTest {

   private ConfigurationFormLayoutHelper layoutHelper;

   @BeforeEach
   public void setup() {
      layoutHelper = new ConfigurationFormLayoutHelper();
   }

   @Test
   @DisplayName("Should create add Configuration layout using the right components")
   void testCreateAddConfigurationLayout(){
      Binder<CwsConfiguration> binder = mock(Binder.class);
      Binder.BindingBuilder binderBuilder = mock(Binder.BindingBuilder.class);
      when(binder.forField(any(HasValue.class))).thenReturn(binderBuilder);
      ArgumentCaptor<String> requiredMessageCaptor = ArgumentCaptor.forClass(String.class);
      when(binderBuilder.asRequired(requiredMessageCaptor.capture())).thenReturn(binderBuilder);

      try (MockedStatic<UI> uiStaticMock = mockStatic(UI.class)) {
         UI uiMock = mock(UI.class);
         uiStaticMock.when(UI::getCurrent).thenReturn(uiMock);
         when(uiMock.getLocale()).thenReturn(Locale.US);

         CwsConfiguration cwsConfiguration = CwsConfiguration.builder()
               .contractId(12345L)
               .contractStartDate(LocalDate.of(2020, 6, 5))
               .afnemerCode("afnCd")
               .afnemerNaam("afnNaam")
               .berichtVersie("105")
               .configurationStatus("CO")
               .build();

         FormLayout formLayout = layoutHelper.createAddConfigurationLayout(cwsConfiguration, binder, "105");
         TextField textFieldAfnemercode = (TextField) findComponent(COMPONENT_ID_AFNEMERCODE_TEXT_FIELD, formLayout);
         assertThat(textFieldAfnemercode).isNotNull();
         assertThat(textFieldAfnemercode.getValue()).isEqualTo("afnCd");
         assertThat(textFieldAfnemercode.isEnabled()).isFalse();
         assertThat(textFieldAfnemercode.getMaxLength()).isEqualTo(8);

         TextField textFieldAfnemerNaam = (TextField) findComponent(COMPONENT_ID_AFNEMERNAAM_TEXT_FIELD, formLayout);
         assertThat(textFieldAfnemerNaam).isNotNull();
         assertThat(textFieldAfnemerNaam.getValue()).isEqualTo("afnNaam");
         assertThat(textFieldAfnemerNaam.isEnabled()).isFalse();
         assertThat(textFieldAfnemerNaam.getMaxLength()).isEqualTo(200);

         TextField textFieldContractId = (TextField) findComponent(COMPONENT_ID_CONTRACTID_TEXT_FIELD, formLayout);
         assertThat(textFieldContractId).isNotNull();
         assertThat(textFieldContractId.getValue()).isEqualTo("12345");
         assertThat(textFieldContractId.isEnabled()).isFalse();
         assertThat(textFieldContractId.getMaxLength()).isEqualTo(200);

         TextField textFieldContractBeginDate = (TextField) findComponent(COMPONENT_ID_CONTRACTBEGINDATUM_TEXT_FIELD, formLayout);
         assertThat(textFieldContractBeginDate).isNotNull();
         assertThat(textFieldContractBeginDate.getValue()).isEqualTo("05-06-2020");
         assertThat(textFieldContractBeginDate.isEnabled()).isFalse();
         assertThat(textFieldContractBeginDate.getMaxLength()).isEqualTo(200);

         TextField textFieldConfigurationVersion = (TextField) findComponent(COMPONENT_ID_CONFIGURATIEVERSIE_TEXT_FIELD, formLayout);
         assertThat(textFieldConfigurationVersion).isNotNull();
         assertThat(textFieldConfigurationVersion.getValue()).isEmpty();
         assertThat(textFieldConfigurationVersion.isEnabled()).isFalse();
         assertThat(textFieldConfigurationVersion.getMaxLength()).isEqualTo(200);

         TextField textFieldConfigurationNaam = (TextField) findComponent(COMPONENT_ID_CONFIGURATIENAAM_TEXT_FIELD, formLayout);
         assertThat(textFieldConfigurationNaam).isNotNull();
         assertThat(textFieldConfigurationNaam.getValue()).isEmpty();
         assertThat(textFieldConfigurationNaam.isEnabled()).isTrue();
         assertThat(textFieldConfigurationNaam.getMaxLength()).isEqualTo(200);

         DatePicker fieldConfigurationBeginDate = (DatePicker) findComponent(COMPONENT_ID_CONFIGURATIEBEGINDATUM_TEXT_FIELD, formLayout);
         assertThat(fieldConfigurationBeginDate).isNotNull();
         assertThat(fieldConfigurationBeginDate.getValue()).isNull();
         assertThat(fieldConfigurationBeginDate.isEnabled()).isTrue();
         assertThat(requiredMessageCaptor.getValue()).isEqualTo("Begindatum is verplicht");

         DatePicker fieldConfigurationEndDate = (DatePicker) findComponent(COMPONENT_ID_CONFIGURATIEEINDDATUM_TEXT_FIELD, formLayout);
         assertThat(fieldConfigurationEndDate).isNotNull();
         assertThat(fieldConfigurationEndDate.getValue()).isNull();
         assertThat(fieldConfigurationEndDate.isEnabled()).isTrue();

         TextField textFieldConfigurationStatus = (TextField) findComponent(COMPONENT_ID_CONFIGURATIESTATUS_TEXT_FIELD, formLayout);
         assertThat(textFieldConfigurationStatus).isNotNull();
         assertThat(textFieldConfigurationStatus.getValue()).isEqualTo("CO");
         assertThat(textFieldConfigurationStatus.isEnabled()).isFalse();
         assertThat(textFieldConfigurationStatus.getMaxLength()).isEqualTo(200);

         TextField textFieldBerichtVersion = (TextField) findComponent(COMPONENT_ID_BERICHTVERSIE_TEXT_FIELD, formLayout);
         assertThat(textFieldBerichtVersion).isNotNull();
         assertThat(textFieldBerichtVersion.isEnabled()).isFalse();
         assertThat(textFieldBerichtVersion.getMaxLength()).isEqualTo(200);
      }
   }

   @Test
   @DisplayName("Should create modify/view Configuration layout using the right components")
   void testCreateModifyAndViewConfigurationLayout(){
      Binder<CwsConfiguration> binder = mock(Binder.class);
      Binder.BindingBuilder binderBuilder = mock(Binder.BindingBuilder.class);
      when(binder.forField(any(HasValue.class))).thenReturn(binderBuilder);
      ArgumentCaptor<String> requiredMessageCaptor = ArgumentCaptor.forClass(String.class);
      when(binderBuilder.asRequired(requiredMessageCaptor.capture())).thenReturn(binderBuilder);

      try (MockedStatic<UI> uiStaticMock = mockStatic(UI.class)) {
         UI uiMock = mock(UI.class);
         uiStaticMock.when(UI::getCurrent).thenReturn(uiMock);
         when(uiMock.getLocale()).thenReturn(Locale.US);

         CwsConfiguration cwsConfiguration = CwsConfiguration.builder()
               .contractId(12345L)
               .contractStartDate(LocalDate.of(2020, 6, 5))
               .afnemerCode("afnCd")
               .afnemerNaam("afnNaam")
               .berichtVersie("105")
               .configurationStatus("CO")
               .configurationName("test configname")
               .configurationStartDate(LocalDate.of(2021, 6, 5))
               .configurationEndDate(LocalDate.of(2021, 7, 1))
               .registrationStartDateTime(LocalDateTime.of(2021, 7, 1, 11, 30))
               .leverCode("CWS-LA")
               .build();

         FormLayout formLayout = layoutHelper.createAddConfigurationLayout(cwsConfiguration, binder, "105");
         TextField textFieldAfnemercode = (TextField) findComponent(COMPONENT_ID_AFNEMERCODE_TEXT_FIELD, formLayout);
         assertThat(textFieldAfnemercode).isNotNull();
         assertThat(textFieldAfnemercode.getValue()).isEqualTo("afnCd");
         assertThat(textFieldAfnemercode.isEnabled()).isFalse();
         assertThat(textFieldAfnemercode.getMaxLength()).isEqualTo(8);

         TextField textFieldAfnemerNaam = (TextField) findComponent(COMPONENT_ID_AFNEMERNAAM_TEXT_FIELD, formLayout);
         assertThat(textFieldAfnemerNaam).isNotNull();
         assertThat(textFieldAfnemerNaam.getValue()).isEqualTo("afnNaam");
         assertThat(textFieldAfnemerNaam.isEnabled()).isFalse();
         assertThat(textFieldAfnemerNaam.getMaxLength()).isEqualTo(200);

         TextField textFieldContractId = (TextField) findComponent(COMPONENT_ID_CONTRACTID_TEXT_FIELD, formLayout);
         assertThat(textFieldContractId).isNotNull();
         assertThat(textFieldContractId.getValue()).isEqualTo("12345");
         assertThat(textFieldContractId.isEnabled()).isFalse();
         assertThat(textFieldContractId.getMaxLength()).isEqualTo(200);

         TextField textFieldContractBeginDate = (TextField) findComponent(COMPONENT_ID_CONTRACTBEGINDATUM_TEXT_FIELD, formLayout);
         assertThat(textFieldContractBeginDate).isNotNull();
         assertThat(textFieldContractBeginDate.getValue()).isEqualTo("05-06-2020");
         assertThat(textFieldContractBeginDate.isEnabled()).isFalse();
         assertThat(textFieldContractBeginDate.getMaxLength()).isEqualTo(200);

         TextField textFieldConfigurationVersion = (TextField) findComponent(COMPONENT_ID_CONFIGURATIEVERSIE_TEXT_FIELD, formLayout);
         assertThat(textFieldConfigurationVersion).isNotNull();
         assertThat(textFieldConfigurationVersion.getValue()).isEmpty();
         assertThat(textFieldConfigurationVersion.isEnabled()).isFalse();
         assertThat(textFieldConfigurationVersion.getMaxLength()).isEqualTo(200);

         TextField textFieldConfigurationNaam = (TextField) findComponent(COMPONENT_ID_CONFIGURATIENAAM_TEXT_FIELD, formLayout);
         assertThat(textFieldConfigurationNaam).isNotNull();
         assertThat(textFieldConfigurationNaam.getValue()).isEmpty();
         assertThat(textFieldConfigurationNaam.isEnabled()).isTrue();
         assertThat(textFieldConfigurationNaam.getMaxLength()).isEqualTo(200);

         DatePicker fieldConfigurationBeginDate = (DatePicker) findComponent(COMPONENT_ID_CONFIGURATIEBEGINDATUM_TEXT_FIELD, formLayout);
         assertThat(fieldConfigurationBeginDate).isNotNull();
         assertThat(fieldConfigurationBeginDate.getValue()).isNull();
         assertThat(fieldConfigurationBeginDate.isEnabled()).isTrue();
         assertThat(requiredMessageCaptor.getValue()).isEqualTo("Begindatum is verplicht");

         DatePicker fieldConfigurationEndDate = (DatePicker) findComponent(COMPONENT_ID_CONFIGURATIEEINDDATUM_TEXT_FIELD, formLayout);
         assertThat(fieldConfigurationEndDate).isNotNull();
         assertThat(fieldConfigurationEndDate.getValue()).isNull();
         assertThat(fieldConfigurationEndDate.isEnabled()).isTrue();

         TextField textFieldConfigurationStatus = (TextField) findComponent(COMPONENT_ID_CONFIGURATIESTATUS_TEXT_FIELD, formLayout);
         assertThat(textFieldConfigurationStatus).isNotNull();
         assertThat(textFieldConfigurationStatus.getValue()).isEqualTo("CO");
         assertThat(textFieldConfigurationStatus.isEnabled()).isFalse();
         assertThat(textFieldConfigurationStatus.getMaxLength()).isEqualTo(200);

         TextField textFieldBerichtVersion = (TextField) findComponent(COMPONENT_ID_BERICHTVERSIE_TEXT_FIELD, formLayout);
         assertThat(textFieldBerichtVersion).isNotNull();
         assertThat(textFieldBerichtVersion.isEnabled()).isFalse();
         assertThat(textFieldBerichtVersion.getMaxLength()).isEqualTo(200);
      }
   }
}
