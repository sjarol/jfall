package nl.uwv.pws.cws.views.beheer.contract;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.stream.Collectors;

import static org.assertj.core.api.Assertions.assertThat;

public class ContractFieldByAfnemerDescriptorTest {

   @Test
   @DisplayName("Multiple calls to the getInstance() method return the same instance")
   void testGetInstance() {
      assertThat(ContractFieldByAfnemerDescriptor.getInstance()).isSameAs(ContractFieldByAfnemerDescriptor.getInstance());
   }

   @Test
   @DisplayName("There's a descriptor available for each of the fields we support")
   void testFields() {
      ContractFieldByAfnemerDescriptor fieldDescriptor = ContractFieldByAfnemerDescriptor.getInstance();

      // We expect all ContractColumns to be described in the ContractFieldByAfnemerDescriptors
      assertThat(fieldDescriptor.getColumnNames()).containsAnyElementsOf(
            Arrays.stream(ContractColumn.values())
                  .map(Enum::name)
                  .collect(Collectors.toList())
      );
   }
}
