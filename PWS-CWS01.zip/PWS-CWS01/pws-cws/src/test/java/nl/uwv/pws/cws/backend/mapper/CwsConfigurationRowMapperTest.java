package nl.uwv.pws.cws.backend.mapper;

import nl.uwv.pws.cws.model.CwsConfiguration;
import nl.uwv.pws.cws.model.CwsMetaCol;
import nl.uwv.pws.cws.util.CwsUtils;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class CwsConfigurationRowMapperTest {

   @Test
   @DisplayName("Should map the resultset fields")
   void testMapRow() throws SQLException {
      ResultSet resultSet = mock(ResultSet.class);
      when(resultSet.getLong("CCON_ID")).thenReturn(123L);
      when(resultSet.getLong("CONTRACT_ID")).thenReturn(789L);
      when(resultSet.getLong("CONT_HIS_DAT_IN")).thenReturn(20210614L);
      when(resultSet.getString("NAAM")).thenReturn("testNaam");
      when(resultSet.getLong("VERSION")).thenReturn(4L);
      when(resultSet.getString("STATUS")).thenReturn("testStatus");
      when(resultSet.getLong("HIS_DAT_IN")).thenReturn(20210714L);
      when(resultSet.getLong("HIS_DAT_END")).thenReturn(20210715L);
      when(resultSet.getTimestamp("HIS_TS_IN")).thenReturn(Timestamp.valueOf(LocalDateTime.of(2021,6,1, 12,32)));
      when(resultSet.getTimestamp("HIS_TS_END")).thenReturn(Timestamp.valueOf(LocalDateTime.of(9999,12,31, 12,32)));
      when(resultSet.getString("LEV_CD")).thenReturn("testCode");
      when(resultSet.getString("BERICHTVERSIE")).thenReturn("co");

      CwsConfigurationRowMapper cwsConfigurationRowMapper = new CwsConfigurationRowMapper();

      CwsConfiguration cwsConfiguration = cwsConfigurationRowMapper.mapRow(resultSet);
      assertThat(cwsConfiguration.getConfigurationId()).isEqualTo(123L);
      assertThat(cwsConfiguration.getContractId()).isEqualTo(789L);
      assertThat(cwsConfiguration.getContractStartDate()).isEqualTo(LocalDate.of(2021,6,14));
      assertThat(cwsConfiguration.getConfigurationName()).isEqualTo("testNaam");
      assertThat(cwsConfiguration.getConfigurationVersion()).isEqualTo(4L);
      assertThat(cwsConfiguration.getConfigurationStatus()).isEqualTo("testStatus");
      assertThat(cwsConfiguration.getConfigurationStartDate()).isEqualTo(LocalDate.of(2021,7,14));
      assertThat(cwsConfiguration.getConfigurationEndDate()).isEqualTo(LocalDate.of(2021,7,15));
      assertThat(cwsConfiguration.getRegistrationStartDateTime()).isEqualTo(LocalDateTime.of(2021,6,1, 12,32));
      assertThat(cwsConfiguration.getRegistrationEndDateTime()).isEqualTo(LocalDateTime.of(9999,12,31, 12,32));
      assertThat(cwsConfiguration.getLeverCode()).isEqualTo("testCode");
      assertThat(cwsConfiguration.getBerichtVersie()).isEqualTo("co");
   }
}
