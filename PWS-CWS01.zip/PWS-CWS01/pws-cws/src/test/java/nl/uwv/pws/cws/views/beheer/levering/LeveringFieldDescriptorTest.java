package nl.uwv.pws.cws.views.beheer.levering;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.stream.Collectors;

import static org.assertj.core.api.Assertions.assertThat;

public class LeveringFieldDescriptorTest {

   @Test
   @DisplayName("Multiple calls to the getInstance() method return the same instance")
   void testGetInstance() {
      assertThat(LeveringFieldDescriptor.getInstance()).isSameAs(LeveringFieldDescriptor.getInstance());
   }

   @Test
   @DisplayName("There's a descriptor available for each of the fields we support")
   void testFields() {
      LeveringFieldDescriptor fieldDescriptor = LeveringFieldDescriptor.getInstance();

      assertThat(fieldDescriptor.getColumnNames()).containsAnyElementsOf(
            Arrays.stream(LeveringColumn.values())
                  .map(Enum::name)
                  .collect(Collectors.toList())
      );
   }
}
