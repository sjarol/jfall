package nl.uwv.pws.cws.backend.service.cwswg;

import nl.uwv.pws.cws.backend.dao.CwsConfigurationDao;
import nl.uwv.pws.cws.model.BaseCwsFilterType;
import nl.uwv.pws.cws.model.CwsConfiguration;
import nl.uwv.pws.cws.model.CwsWgFilterType;
import nl.uwv.pws.cws.model.SelectionCriteria;
import org.junit.jupiter.api.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import java.util.HashMap;
import java.util.Map;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.junit.jupiter.api.TestInstance.Lifecycle.PER_CLASS;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@TestInstance(PER_CLASS)
public class CwsWgProductSpecContentGeneratorServiceTest {

   private CwsWgProductSpecContentGeneratorService cwsWgProductSpecContentGeneratorService;

   private MockedStatic<CwsConfigurationDao> cwsConfigurationDaoMockedStatic;
   private CwsConfigurationDao cwsConfigurationDao;

   @BeforeAll
   public void setupOnce() {
      this.cwsConfigurationDaoMockedStatic = Mockito.mockStatic(CwsConfigurationDao.class);
      this.cwsConfigurationDao = mock(CwsConfigurationDao.class);

      cwsConfigurationDaoMockedStatic.when(CwsConfigurationDao::getInstance).thenReturn(cwsConfigurationDao);
   }

   @AfterAll
   public void cleanup(){
      cwsConfigurationDaoMockedStatic.close();
   }


   @Test
   @DisplayName("Should use correct parameters to prepare product specification generation")
   void testFileAndFolderNamesForProductSpecification() {
      cwsWgProductSpecContentGeneratorService = new CwsWgProductSpecContentGeneratorService(CwsConfiguration.builder()
            .configurationId(999999L)
            .configurationVersion(10L)
            .build(),
            "dummyKenmerk", "dummyRequestHeader", "dummyResponseHeader");

      assertThat(cwsWgProductSpecContentGeneratorService.getPdfTemplateFileName()).isEqualTo("../templates/cwswg-product-specificatie-template.odt");
      assertThat(cwsWgProductSpecContentGeneratorService.getExampleRequestFileNames()).isEqualTo(new String []
            {"Request_administratieveeenheid.xml", "Request_persooninhoudingsplicht.xml", "Request_werkgeverkvk.xml"});
      assertThat(cwsWgProductSpecContentGeneratorService.getExampleXmlFolderName()).isEqualTo("cwswg/");
      assertThat(cwsWgProductSpecContentGeneratorService.getResponseBodyRootElementName()).isEqualTo("CwsWerkgeverresponse");
   }

   @Test
   @DisplayName("Should return correct mapping for CWS-WG at service construction")
   public void testGetSelectieCriteriaMapping(){
      Map<BaseCwsFilterType, String> filterMap = new HashMap<>();
      filterMap.put(CwsWgFilterType.BEEINDIGD_ADRES_UITSLUITEN_WG, "J");
      SelectionCriteria selectionCriteria = new SelectionCriteria("CWS-WG");
      selectionCriteria.setFilterMap(filterMap);
      when(cwsConfigurationDao.selectSelectionCriteriaByConfigId(anyLong())).thenReturn(selectionCriteria);

      cwsWgProductSpecContentGeneratorService = new CwsWgProductSpecContentGeneratorService(CwsConfiguration.builder()
            .configurationId(999999L)
            .configurationVersion(10L)
            .build(),
            "dummyKenmerk", "dummyRequestHeader", "dummyResponseHeader");
      Map<String, Object> mappingMap = cwsWgProductSpecContentGeneratorService.getSelectieCriteriaMapping();
      String value = (String) mappingMap.get("condition_beeindigdAdresUitsluiten");
      assertThat(value).isEqualTo("true");
   }
}
