package nl.uwv.pws.cws.views.beheer.tabs.layout.cwsnp;

import com.vaadin.flow.component.checkbox.Checkbox;
import nl.uwv.pws.cws.model.viewtab.BaseCwsOverzichtFilterOption;
import nl.uwv.pws.cws.model.viewtab.CwsNpFilter;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

public class CwsNpOverzichtFilterFormLayoutTest {

   private CwsNpOverzichtFilterFormLayout cwsNpOverzichtFilterFormLayout;
   private List<Checkbox> checkboxList;

   @BeforeEach
   public void setup() {
      cwsNpOverzichtFilterFormLayout = new CwsNpOverzichtFilterFormLayout();
      this.checkboxList = cwsNpOverzichtFilterFormLayout.getCheckboxList();
   }

   @Test
   @DisplayName("CWS-NP OverzichtConfiguratieLayout contains all checkboxes")
   void testCreateLayout() {
      cwsNpOverzichtFilterFormLayout = new CwsNpOverzichtFilterFormLayout();
      List<Checkbox> checkboxList = cwsNpOverzichtFilterFormLayout.getCheckboxList();

      Optional<Checkbox> optionalCheckboxLevendPersoonUitsluiten = checkboxList.stream().filter(checkbox -> checkbox.getLabel().equals("Filter levend persoon uitsluiten")
            && checkbox.getId().get().equals(CwsNpFilter.LEVEND_NPE_UITSLUITEN.name())).findFirst();
      assertThat(optionalCheckboxLevendPersoonUitsluiten.isPresent()).isTrue();

      Optional<Checkbox> optionalCheckboxoptionalCheckboxOverledenPersoonUitsluiten = checkboxList.stream().filter(checkbox -> checkbox.getLabel().equals("Filter overleden persoon uitsluiten")
            && checkbox.getId().get().equals(CwsNpFilter.OVERLEDEN_NPE_UITSLUITEN.name())).findFirst();
      assertThat(optionalCheckboxoptionalCheckboxOverledenPersoonUitsluiten.isPresent()).isTrue();
   }

   @Test
   @DisplayName("CWS-NP OverzichtConfiguratieLayout return only selected Checkbox")
   void testSelectedFilters() {
      cwsNpOverzichtFilterFormLayout = new CwsNpOverzichtFilterFormLayout();
      List<Checkbox> checkboxList = cwsNpOverzichtFilterFormLayout.getCheckboxList();

      Optional<Checkbox> optionalOverledenPersoonUitsluiten = checkboxList.stream().filter(checkbox -> checkbox.getLabel().equals("Filter overleden persoon uitsluiten")
            && checkbox.getId().get().equals(CwsNpFilter.OVERLEDEN_NPE_UITSLUITEN.name())).findFirst();
      optionalOverledenPersoonUitsluiten.get().setValue(true);

      List<BaseCwsOverzichtFilterOption> filterOptionList = cwsNpOverzichtFilterFormLayout.getSelectedFilters();
      BaseCwsOverzichtFilterOption filterOption = filterOptionList.listIterator().next();

      assertThat(filterOption.getEnumName()).isEqualTo(CwsNpFilter.OVERLEDEN_NPE_UITSLUITEN.name());
      assertThat(filterOption.getColumnName()).isEqualTo("Filter overleden persoon");
      assertThat(filterOption.getHeaderColumnName()).isEqualTo("Filter overleden persoon uitsluiten");
   }
}
