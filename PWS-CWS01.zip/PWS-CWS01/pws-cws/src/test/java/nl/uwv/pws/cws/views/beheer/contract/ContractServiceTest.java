package nl.uwv.pws.cws.views.beheer.contract;

import com.vaadin.flow.data.provider.QuerySortOrder;
import com.vaadin.flow.data.provider.SortDirection;

import nl.uwv.pws.cws.util.Constants;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class ContractServiceTest {

   @Test
   @DisplayName("ContractService using AfnemerType configures the correct table name, correct columns and default column sort")
   public void testListServiceByAfnemerTypeConfiguration() {
      ContractService contractService = new ContractService(Constants.DS_NAME, ContractServiceType.CONTRACT_BY_AFNEMER);
      assertThat(contractService.getViewName()).isEqualTo("CWS_CONTRACT_VW");
      assertThat(contractService.getDescriptor()).isInstanceOf(ContractFieldByAfnemerDescriptor.class);

      QuerySortOrder defaultSortOrder = contractService.getDefaultSortOrder();
      assertThat(defaultSortOrder).isNotNull();
      assertThat(defaultSortOrder.getSorted()).isEqualTo(ContractColumn.HIS_DAT_END.name());
      assertThat(defaultSortOrder.getDirection()).isEqualTo(SortDirection.DESCENDING);
   }

   @Test
   @DisplayName("ContractService using levering type configures the correct table name, correct columns and default column sort")
   public void testListServiceByLeveringConfiguration() {
      ContractService contractService = new ContractService(Constants.DS_NAME, ContractServiceType.CONTRACT_BY_AFNEMER);
      assertThat(contractService.getViewName()).isEqualTo("CWS_CONTRACT_VW");
      assertThat(contractService.getDescriptor()).isInstanceOf(ContractFieldByAfnemerDescriptor.class);

      QuerySortOrder defaultSortOrder = contractService.getDefaultSortOrder();
      assertThat(defaultSortOrder).isNotNull();
      assertThat(defaultSortOrder.getSorted()).isEqualTo(ContractColumn.HIS_DAT_END.name());
      assertThat(defaultSortOrder.getDirection()).isEqualTo(SortDirection.DESCENDING);
   }
}
