package nl.uwv.pws.cws.views.beheer.tabs.dialogs;

import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.NativeButton;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.upload.Upload;
import nl.uwv.pws.backend.dao.BackendException;
import nl.uwv.pws.cws.backend.service.ImportService;
import nl.uwv.pws.cws.model.CwsConfiguration;
import nl.uwv.pws.cws.util.CwsUIUtils;
import nl.uwv.pws.cws.views.beheer.tabs.dialogs.UploadDialog;
import org.apache.commons.io.IOUtils;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;

import java.io.InputStream;
import java.lang.reflect.Field;
import java.time.LocalDate;
import java.util.Optional;

import static nl.uwv.pws.cws.util.Constants.CANCEL_BUTTON_ID;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

public class UploadDialogTest {

   private UploadDialog uploadDialog;

   @Test
   @DisplayName("Upload dialog contains all fields and cancel button")
   void testUploadDialogContainsAllFields() {
      try (MockedStatic<UI> uiStaticMock = mockStatic(UI.class)) {
         UI uiMock = mock(UI.class);
         uiStaticMock.when(UI::getCurrent).thenReturn(uiMock);

         UploadDialog uploadDialog = new UploadDialog("levcd", 123456L, LocalDate.of(2021,7,13));
         assertThat(uploadDialog.getLeverCode()).isEqualTo("levcd");
         assertThat(uploadDialog.getContractId()).isEqualTo(123456L);
         assertThat(uploadDialog.getContractStartDate()).isEqualTo(LocalDate.of(2021, 7, 13));
         assertThat(uploadDialog.getCancelButton()).isNotNull();
         assertThat(uploadDialog.getCancelButton().getText()).isEqualTo("Annuleren");
         assertThat(uploadDialog.getCancelButton().isEnabled()).isTrue();
         assertThat(uploadDialog.getCancelButton().getWidth()).isEqualTo("10em");
         assertThat(uploadDialog.getCancelButton().getId().get()).isEqualTo(CANCEL_BUTTON_ID);
      }
   }

   @Test
   @DisplayName("should create a component containing Upload component")
   void testCreateContent() {
      try (MockedStatic<UI> uiStaticMock = mockStatic(UI.class)) {
         UI uiMock = mock(UI.class);
         uiStaticMock.when(UI::getCurrent).thenReturn(uiMock);

         UploadDialog uploadDialog = new UploadDialog("levcd", 123456L, LocalDate.of(2021, 7, 13));
         VerticalLayout verticalLayout = uploadDialog.createContent();
         assertThat(verticalLayout).isNotNull();
         Optional<Upload> uploadOptional =  verticalLayout.getChildren().filter(component -> component instanceof Upload).map(Upload.class::cast).findFirst();
         Optional<Div> divOptional =  verticalLayout.getChildren().filter(component -> component instanceof Div).map(Div.class::cast).findFirst();

         assertThat(uploadOptional).isNotEmpty();
         assertThat(divOptional).isNotEmpty();

         Upload upload = uploadOptional.get();
         assertThat(upload.getAcceptedFileTypes().size()).isEqualTo(1);
         assertThat(upload.getAcceptedFileTypes().get(0)).isEqualTo("application/json");

         NativeButton uploadButton = (NativeButton) upload.getUploadButton();
         assertThat(uploadButton.getText()).isEqualTo("Selecteer import bestand");
      }
   }

   @Test
   @DisplayName("should call success notification after upload completes")
   void testProcessUpload() throws NoSuchFieldException, IllegalAccessException {
      try (MockedStatic<UI> uiStaticMock = mockStatic(UI.class);
           MockedStatic<IOUtils> ioUtilsMockedStatic = mockStatic(IOUtils.class);
           MockedStatic<CwsUIUtils> cwsUiUtilsMockedStatic = mockStatic(CwsUIUtils.class)) {
         UI uiMock = mock(UI.class);
         uiStaticMock.when(UI::getCurrent).thenReturn(uiMock);
         byte [] bytesRead = "{dummy:json}".getBytes();
         ioUtilsMockedStatic.when(() -> IOUtils.toByteArray(any(InputStream.class))).thenReturn(bytesRead);

         cwsUiUtilsMockedStatic.when(() -> CwsUIUtils.createButton(anyString(), any(VaadinIcon.class), anyString(), anyBoolean(), anyString())).thenReturn(new Button());

         UploadDialog uploadDialog = new UploadDialog("levcd", 123456L, LocalDate.of(2021, 7, 13));
         ImportService mockImportService = mock(ImportService.class);
         Field field = uploadDialog.getClass().getDeclaredField("importService");
         field.setAccessible(true);
         field.set(uploadDialog, mockImportService);
         when(mockImportService.importConfiguration(anyString(), anyLong(), any(LocalDate.class))).thenReturn(CwsConfiguration.builder().build());

         InputStream inputStream = mock(InputStream.class);
         uploadDialog.processUpload(inputStream);

         cwsUiUtilsMockedStatic.verify(() -> CwsUIUtils.showSuccesNotification("Import succesvol afgerond"));
      }
   }

   @Test
   @DisplayName("should call error notification when upload fails" )
   void testProcessUploadFails() throws NoSuchFieldException, IllegalAccessException {
      try (MockedStatic<UI> uiStaticMock = mockStatic(UI.class);
           MockedStatic<IOUtils> ioUtilsMockedStatic = mockStatic(IOUtils.class);
           MockedStatic<CwsUIUtils> cwsUiUtilsMockedStatic = mockStatic(CwsUIUtils.class)) {
         UI uiMock = mock(UI.class);
         uiStaticMock.when(UI::getCurrent).thenReturn(uiMock);
         byte [] bytesRead = "{dummy:json}".getBytes();
         ioUtilsMockedStatic.when(() -> IOUtils.toByteArray(any(InputStream.class))).thenReturn(bytesRead);

         cwsUiUtilsMockedStatic.when(() -> CwsUIUtils.createButton(anyString(), any(VaadinIcon.class), anyString(), anyBoolean(), anyString())).thenReturn(new Button());

         UploadDialog uploadDialog = new UploadDialog("levcd", 123456L, LocalDate.of(2021, 7, 13));
         ImportService mockImportService = mock(ImportService.class);

         doThrow(new BackendException("some exception occurred")).when(mockImportService).importConfiguration(anyString(), anyLong(), any(LocalDate.class));
         Field field = uploadDialog.getClass().getDeclaredField("importService");
         field.setAccessible(true);
         field.set(uploadDialog, mockImportService);

         InputStream inputStream = mock(InputStream.class);
         uploadDialog.processUpload(inputStream);

         cwsUiUtilsMockedStatic.verify(() -> CwsUIUtils.showErrorNotification("Het bestand kan niet verwerkt worden."));
      }
   }
}
