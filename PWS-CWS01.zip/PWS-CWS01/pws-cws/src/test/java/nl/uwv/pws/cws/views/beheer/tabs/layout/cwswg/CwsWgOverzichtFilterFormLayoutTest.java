package nl.uwv.pws.cws.views.beheer.tabs.layout.cwswg;

import com.vaadin.flow.component.checkbox.Checkbox;
import nl.uwv.pws.cws.model.viewtab.BaseCwsOverzichtFilterOption;
import nl.uwv.pws.cws.model.viewtab.CwsWgFilter;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

public class CwsWgOverzichtFilterFormLayoutTest {

   private CwsWgOverzichtFilterFormLayout cwsWgOverzichtFilterFormLayout;
   private List<Checkbox> checkboxList;

   @BeforeEach
   public void setup() {
      cwsWgOverzichtFilterFormLayout = new CwsWgOverzichtFilterFormLayout();
      this.checkboxList = cwsWgOverzichtFilterFormLayout.getCheckboxList();
   }

   @Test
   @DisplayName("CWS-WG OverzichtConfiguratieLayout contains all checkboxes")
   void testCreateLayout() {
      Optional<Checkbox> optionalCheckboxBeeindigdAdresUitsluiten = checkboxList.stream().filter(checkbox -> checkbox.getLabel().equals("Filter beëindigd adres uitsluiten")
            && checkbox.getId().get().equals(CwsWgFilter.BEEINDIGD_ADRES_UITSLUITEN_WG.name())).findFirst();
      assertThat(optionalCheckboxBeeindigdAdresUitsluiten.isPresent()).isTrue();
   }

   @Test
   @DisplayName("CWS-WG OverzichtConfiguratieLayout return only selected Checkbox")
   void testSelectedFilters() {
      Optional<Checkbox> optionalCheckboxCodeSoortIkv = checkboxList.stream().filter(checkbox -> checkbox.getLabel().equals("Filter beëindigd adres uitsluiten")
            && checkbox.getId().get().equals(CwsWgFilter.BEEINDIGD_ADRES_UITSLUITEN_WG.name())).findFirst();
      optionalCheckboxCodeSoortIkv.get().setValue(true);

      List<BaseCwsOverzichtFilterOption> filterOptionList = cwsWgOverzichtFilterFormLayout.getSelectedFilters();
      BaseCwsOverzichtFilterOption filterOption = filterOptionList.listIterator().next();

      assertThat(filterOption.getEnumName()).isEqualTo(CwsWgFilter.BEEINDIGD_ADRES_UITSLUITEN_WG.name());
      assertThat(filterOption.getColumnName()).isEqualTo("Filter beëindigd adres");
      assertThat(filterOption.getHeaderColumnName()).isEqualTo("Filter beëindigd adres uitsluiten");
   }
}
