package nl.uwv.pws.cws.views.beheer.tabs.layout.cwsihp;

import com.vaadin.flow.component.checkbox.Checkbox;
import nl.uwv.pws.cws.model.viewtab.BaseCwsOverzichtFilterOption;
import nl.uwv.pws.cws.model.viewtab.CwsIhpFilter;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

public class CwsIhpOverzichtFilterFormLayoutTest {

   private CwsIhpOverzichtFilterFormLayout cwsIhpOverzichtFilterFormLayout;
   private List<Checkbox> checkboxList;

   @BeforeEach
   public void setup() {
      cwsIhpOverzichtFilterFormLayout = new CwsIhpOverzichtFilterFormLayout();
      this.checkboxList = cwsIhpOverzichtFilterFormLayout.getCheckboxList();
   }

   @Test
   @DisplayName("CWS-IHP OverzichtConfiguratieLayout contains all checkboxes")
   void testCreateLayout() {
      Optional<Checkbox> optionalCheckboxBeeindigdAdresUitsluiten = checkboxList.stream().filter(checkbox -> checkbox.getLabel().equals("Filter beëindigd adres uitsluiten")
            && checkbox.getId().get().equals(CwsIhpFilter.BEEINDIGD_ADRES_UITSLUITEN_IHP.name())).findFirst();
      assertThat(optionalCheckboxBeeindigdAdresUitsluiten.isPresent()).isTrue();
   }

   @Test
   @DisplayName("CWS-IHP OverzichtConfiguratieLayout return only selected Checkbox")
   void testSelectedFilters() {
      Optional<Checkbox> optionalCheckboxCodeSoortIkv = checkboxList.stream().filter(checkbox -> checkbox.getLabel().equals("Filter beëindigd adres uitsluiten")
            && checkbox.getId().get().equals(CwsIhpFilter.BEEINDIGD_ADRES_UITSLUITEN_IHP.name())).findFirst();
      optionalCheckboxCodeSoortIkv.get().setValue(true);

      List<BaseCwsOverzichtFilterOption> filterOptionList = cwsIhpOverzichtFilterFormLayout.getSelectedFilters();
      BaseCwsOverzichtFilterOption filterOption = filterOptionList.listIterator().next();

      assertThat(filterOption.getEnumName()).isEqualTo(CwsIhpFilter.BEEINDIGD_ADRES_UITSLUITEN_IHP.name());
      assertThat(filterOption.getColumnName()).isEqualTo("Filter beëindigd adres");
      assertThat(filterOption.getHeaderColumnName()).isEqualTo("Filter beëindigd adres uitsluiten");
   }
}
