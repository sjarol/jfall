package nl.uwv.pws.cws.backend.service;

import nl.uwv.pws.backend.dao.BackendException;
import nl.uwv.pws.cws.backend.dao.CwsConfigurationDao;
import nl.uwv.pws.cws.model.CwsConfiguration;
import nl.uwv.pws.cws.util.CwsUtils;
import org.junit.jupiter.api.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.TestInstance.Lifecycle.PER_CLASS;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@TestInstance(PER_CLASS)
public class ImportServiceTest {

   private ImportService importService;
   private MockedStatic<CwsConfigurationDao> cwsConfigurationDaoMockedStatic;
   private CwsConfigurationDao cwsConfigurationDao;
   private String configSpecification;

   @BeforeAll
   public void setup() throws IOException {
      this.cwsConfigurationDaoMockedStatic = Mockito.mockStatic(CwsConfigurationDao.class);
      this.cwsConfigurationDao = mock(CwsConfigurationDao.class);

      cwsConfigurationDaoMockedStatic.when(CwsConfigurationDao::getInstance).thenReturn(cwsConfigurationDao);
      importService = new ImportService();

      Path path = Paths.get("src", "test", "resources", "test_import.json");
      Stream<String> lines = Files.lines(path);
      this.configSpecification = lines.collect(Collectors.joining("\n"));
      lines.close();
   }

   @AfterAll
   public void cleanup(){
      cwsConfigurationDaoMockedStatic.close();
   }


   @Test
   @DisplayName("Should succesfully import a configuration")
   void testImportConfiguration() {
      final Long contractId = 455062L;
      final LocalDate contractStartDate = CwsUtils.getLongAsLocalDate(20201102L);
      when(cwsConfigurationDao.getMetaDataByLeverCodeAndVersie("CWS-HR", "105")).thenReturn(new HashMap<>());
      CwsConfiguration existingCwsConfigurationMock = CwsConfiguration.builder().configurationId(30000L).build();
      when(cwsConfigurationDao.getConfigurationByContractAndConfigVersion(contractId, CwsUtils.getLocalDateAsLong(contractStartDate),  10L))
            .thenReturn(existingCwsConfigurationMock);
      when(cwsConfigurationDao.deleteConfiguration(30000L)).thenReturn(new Timestamp(System.currentTimeMillis()));
      when(cwsConfigurationDao.saveCwsConfiguratie(any(CwsConfiguration.class))).thenReturn(999999L);

      CwsConfiguration importedConfiguration = importService.importConfiguration(configSpecification, contractId, contractStartDate);
      assertThat(importedConfiguration.getConfigurationId()).isEqualTo(999999L);
      assertThat(importedConfiguration.getRegistrationStartDateTime()).isNotNull();
   }


   @Test
   @DisplayName("Validation should fail when configuration parameters from imported file are invalid")
   void testValidationFails() {
      final Long contractId = 100000L;//Invalid contract Id
      final LocalDate contractStartDate = CwsUtils.getLongAsLocalDate(20201102L);
      BackendException exception = assertThrows(BackendException.class, () -> {
         importService.importConfiguration(configSpecification, contractId, contractStartDate);
      });

      String expectedMessage = "Contractnummer en Datum aanvang Contract uit het  importbestand wijken af van het, via het scherm, geselecteerde Contractnummer en Datum aanvang Contract";
      String actualMessage = exception.getMessage();
      assertThat(expectedMessage).contains(actualMessage);
   }
}
