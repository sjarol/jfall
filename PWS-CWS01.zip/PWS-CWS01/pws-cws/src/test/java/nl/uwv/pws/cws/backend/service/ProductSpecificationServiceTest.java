package nl.uwv.pws.cws.backend.service;

import nl.uwv.pws.cws.backend.dao.CwsConfigurationDao;
import nl.uwv.pws.cws.backend.service.cwshr.CwsHrProductSpecContentGeneratorService;
import nl.uwv.pws.cws.backend.service.cwsla.CwsLaProductSpecContentGeneratorService;
import nl.uwv.pws.cws.backend.service.cwsnp.CwsNpProductSpecContentGeneratorService;
import nl.uwv.pws.cws.model.*;
import nl.uwv.pws.cws.util.Constants;
import org.junit.jupiter.api.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.junit.jupiter.api.TestInstance.Lifecycle.PER_CLASS;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@TestInstance(PER_CLASS)
public class ProductSpecificationServiceTest {

   private ProductSpecificationService productSpecificationService;
   private MockedStatic<CwsConfigurationDao> cwsConfigurationDaoMockedStatic;
   private CwsConfigurationDao cwsConfigurationDao;
   private final Long dummyContractId = 5000L;
   private final LocalDate dummyContractStartDate = LocalDate.of(2021, 9, 2);
   private final String dummyPdfFileName = "pdfFile";
   private final String dummyKenmerk = "FAT";

   @BeforeAll
   public void setup() throws IOException {
      this.cwsConfigurationDaoMockedStatic = Mockito.mockStatic(CwsConfigurationDao.class);
      this.cwsConfigurationDao = mock(CwsConfigurationDao.class);

      cwsConfigurationDaoMockedStatic.when(CwsConfigurationDao::getInstance).thenReturn(cwsConfigurationDao);
      productSpecificationService = new ProductSpecificationService();
   }

   @AfterAll
   public void cleanup(){
      cwsConfigurationDaoMockedStatic.close();
   }

   @Test
   @DisplayName("Should use correct headers when CWS-LA afnemer is extern")
   void testRequestAndResponseHeaderAfnemerExternForCwsLa(){
      when(cwsConfigurationDao.isAfnemerExtern(dummyContractId, dummyContractStartDate)).thenReturn(true);

      CwsConfiguration cwsConfiguration = createCwsConfiguration("CWS-LA", null);
      BaseProductSpecContentGeneratorService service = productSpecificationService.determineProductSpecContent(cwsConfiguration, dummyKenmerk);

      assertThat(service).isInstanceOf(CwsLaProductSpecContentGeneratorService.class);
      assertThat(service.getRequestHeader()).contains(Constants.CWS_LA_REQUEST_HEADER_EXTERN);
      assertThat(service.getResponseHeader()).contains(Constants.CWS_LA_RESPONSE_HEADER_EXTERN);
   }

   @Test
   @DisplayName("Should use correct headers when CWS-LA afnemer is intern")
   void testRequestAndResponseHeaderAfnemerInternForCwsLa(){
      when(cwsConfigurationDao.isAfnemerExtern(dummyContractId, dummyContractStartDate)).thenReturn(false);

      CwsConfiguration cwsConfiguration = createCwsConfiguration("CWS-LA", null);
      BaseProductSpecContentGeneratorService service = productSpecificationService.determineProductSpecContent(cwsConfiguration, dummyKenmerk);

      assertThat(service).isInstanceOf(CwsLaProductSpecContentGeneratorService.class);
      assertThat(service.getRequestHeader()).contains(Constants.CWS_LA_REQUEST_HEADER_INTERN);
      assertThat(service.getResponseHeader()).contains(Constants.CWS_LA_RESPONSE_HEADER_INTERN);
   }

   @Test
   @DisplayName("Should use correct headers when CWS-NP afnemer is extern")
   void testRequestAndResponseHeaderAfnemerExternForCwsNp(){
      when(cwsConfigurationDao.isAfnemerExtern(dummyContractId, dummyContractStartDate)).thenReturn(true);

      CwsConfiguration cwsConfiguration = createCwsConfiguration("CWS-NP", null);
      BaseProductSpecContentGeneratorService service = productSpecificationService.determineProductSpecContent(cwsConfiguration, dummyKenmerk);

      assertThat(service).isInstanceOf(CwsNpProductSpecContentGeneratorService.class);
      assertThat(service.getRequestHeader()).contains(Constants.CWS_NP_REQUEST_HEADER_EXTERN);
      assertThat(service.getResponseHeader()).contains(Constants.CWS_NP_RESPONSE_HEADER_EXTERN);
   }

   @Test
   @DisplayName("Should use correct headers when CWS-NP afnemer is intern")
   void testRequestAndResponseHeaderAfnemerInternForCwsNp(){
      when(cwsConfigurationDao.isAfnemerExtern(dummyContractId, dummyContractStartDate)).thenReturn(false);

      CwsConfiguration cwsConfiguration = createCwsConfiguration("CWS-NP", null);
      BaseProductSpecContentGeneratorService service = productSpecificationService.determineProductSpecContent(cwsConfiguration, dummyKenmerk);

      assertThat(service).isInstanceOf(CwsNpProductSpecContentGeneratorService.class);
      assertThat(service.getRequestHeader()).contains(Constants.CWS_NP_REQUEST_HEADER_INTERN);
      assertThat(service.getResponseHeader()).contains(Constants.CWS_NP_RESPONSE_HEADER_INTERN);
   }

   @Test
   @DisplayName("Should use correct headers when CWS-HR afnemer is extern")
   void testRequestAndResponseHeaderAfnemerExternForCwsHr(){
      when(cwsConfigurationDao.isAfnemerExtern(dummyContractId, dummyContractStartDate)).thenReturn(true);

      CwsConfiguration cwsConfiguration = createCwsConfiguration("CWS-HR", null);
      BaseProductSpecContentGeneratorService service = productSpecificationService.determineProductSpecContent(cwsConfiguration, dummyKenmerk);

      assertThat(service).isInstanceOf(CwsHrProductSpecContentGeneratorService.class);
      assertThat(service.getRequestHeader()).contains(Constants.CWS_HR_REQUEST_HEADER_EXTERN);
      assertThat(service.getResponseHeader()).contains(Constants.CWS_HR_RESPONSE_HEADER_EXTERN);
   }

   @Test
   @DisplayName("Should use correct headers when CWS-HR afnemer is intern")
   void testRequestAndResponseHeaderAfnemerInternForCwsHr(){
      when(cwsConfigurationDao.isAfnemerExtern(dummyContractId, dummyContractStartDate)).thenReturn(false);

      CwsConfiguration cwsConfiguration = createCwsConfiguration("CWS-HR", null);
      BaseProductSpecContentGeneratorService service = productSpecificationService.determineProductSpecContent(cwsConfiguration, dummyKenmerk);

      assertThat(service).isInstanceOf(CwsHrProductSpecContentGeneratorService.class);
      assertThat(service.getRequestHeader()).contains(Constants.CWS_HR_REQUEST_HEADER_INTERN);
      assertThat(service.getResponseHeader()).contains(Constants.CWS_HR_RESPONSE_HEADER_INTERN);
   }

   @Test
   @DisplayName("Should successfully generate a zip file for CWS-LA")
   void testGenerateZipfileForCwsLa() throws Exception {
      List<CwsMetaCol> cwsMetaColList = createCwsLaCwsMetaColList();
      when(cwsConfigurationDao.selectConfigurationMetaData(999999L)).thenReturn(cwsMetaColList);
      when(cwsConfigurationDao.getIndVipByAfnemerCode("testAfnCode")).thenReturn("J");

      Map<BaseCwsFilterType, String> filterMap = new HashMap<>();
      filterMap.put(CwsLaFilterType.NIHIL_LNSV_UITSLUITEN, "N");
      filterMap.put(CwsLaFilterType.NIHIL_LNLBPH_UITSLUITEN, "N");
      SelectionCriteria selectionCriteria = new SelectionCriteria("CWS-LA");
      selectionCriteria.setFilterMap(filterMap);
      when(cwsConfigurationDao.selectSelectionCriteriaByConfigId(999999L)).thenReturn(selectionCriteria);

      CwsConfiguration cwsConfiguration = createCwsConfiguration("CWS-LA", "0102");
      ByteArrayOutputStream byteArrayOutputStream = productSpecificationService.generateZipFile(cwsConfiguration, dummyPdfFileName, dummyKenmerk);
      assertThat(byteArrayOutputStream).isNotNull();

      Path path = Paths.get("target", "test-zipfile.zip");
      writeZipFile(byteArrayOutputStream, path);

      List<String> expectedZipFileContentList = new ArrayList<>(Arrays.asList("pdfFile",
            "Request_testAfnCode_testConfigName_10.xml",
            "Response_simpel_testAfnCode_testConfigName_10.xml",
            "Response_complex_testAfnCode_testConfigName_10.xml",
            "Response_funcfout_testAfnCode_testConfigName_10.xml",
            "Response_techfout_testAfnCode_testConfigName_10.xml"));

      List<String> actualZipFileContentList = getZipFileContent(path);
      assertThat(expectedZipFileContentList.containsAll(actualZipFileContentList)).isTrue();

      Files.delete(path);
   }

   @Test
   @DisplayName("Should successfully generate a zip file for CWS-NP")
   void testGenerateZipfileForCwsNp() throws Exception {
      List<CwsMetaCol> cwsMetaColList = createCwsNpCwsMetaColList();
      when(cwsConfigurationDao.selectConfigurationMetaData(999999L)).thenReturn(cwsMetaColList);
      when(cwsConfigurationDao.getIndVipByAfnemerCode("testAfnCode")).thenReturn("N");

      Map<BaseCwsFilterType, String> filterMap = new HashMap<>();
      filterMap.put(CwsNpFilterType.LEVEND_NPE_UITSLUITEN, "N");
      filterMap.put(CwsNpFilterType.OVERLEDEN_NPE_UITSLUITEN, "N");
      SelectionCriteria selectionCriteria = new SelectionCriteria("CWS-NP");
      selectionCriteria.setFilterMap(filterMap);
      when(cwsConfigurationDao.selectSelectionCriteriaByConfigId(999999L)).thenReturn(selectionCriteria);

      CwsConfiguration cwsConfiguration = createCwsConfiguration("CWS-NP", "0005");
      ByteArrayOutputStream byteArrayOutputStream = productSpecificationService.generateZipFile(cwsConfiguration, dummyPdfFileName, dummyKenmerk);
      assertThat(byteArrayOutputStream).isNotNull();

      Path path = Paths.get("target", "test-zipfile.zip");
      writeZipFile(byteArrayOutputStream, path);

      List<String> expectedZipFileContentList = new ArrayList<>(Arrays.asList("pdfFile",
            "Request_testAfnCode_testConfigName_10.xml",
            "Response_testAfnCode_testConfigName_10.xml",
            "Response_funcfout_testAfnCode_testConfigName_10.xml",
            "Response_techfout_testAfnCode_testConfigName_10.xml"));

      List<String> actualZipFileContentList = getZipFileContent(path);
      assertThat(expectedZipFileContentList.containsAll(actualZipFileContentList)).isTrue();

      Files.delete(path);
   }

   @Test
   @DisplayName("Should successfully generate a zip file for CWS-Hr")
   void testGenerateZipfileForCwsHr() throws Exception {
      List<CwsMetaCol> cwsMetaColList = createCwsHrCwsMetaColList();
      when(cwsConfigurationDao.selectConfigurationMetaData(999999L)).thenReturn(cwsMetaColList);
      when(cwsConfigurationDao.getIndVipByAfnemerCode("testAfnCode")).thenReturn("J");

      Map<BaseCwsFilterType, String> filterMap = new HashMap<>();
      filterMap.put(CwsHrFilterType.BEEINDIGD_ADRES_UITSLUITEN, "N");
      SelectionCriteria selectionCriteria = new SelectionCriteria("CWS-HR");
      selectionCriteria.setFilterMap(filterMap);
      when(cwsConfigurationDao.selectSelectionCriteriaByConfigId(999999L)).thenReturn(selectionCriteria);

      CwsConfiguration cwsConfiguration = createCwsConfiguration("CWS-HR", "0105");
      ByteArrayOutputStream byteArrayOutputStream = productSpecificationService.generateZipFile(cwsConfiguration, dummyPdfFileName, dummyKenmerk);
      assertThat(byteArrayOutputStream).isNotNull();

      Path path = Paths.get("target", "test-zipfile.zip");
      writeZipFile(byteArrayOutputStream, path);

      List<String> expectedZipFileContentList = new ArrayList<>(Arrays.asList("pdfFile",
            "Request_persoon_testAfnCode_testConfigName_10.xml",
            "Request_maatschappelijkeactiviteit_testAfnCode_testConfigName_10.xml",
            "Response_complex_testAfnCode_testConfigName_10.xml",
            "Response_simpel_testAfnCode_testConfigName_10.xml",
            "Response_funcfout_testAfnCode_testConfigName_10.xml",
            "Response_techfout_testAfnCode_testConfigName_10.xml"));

      List<String> actualZipFileContentList = getZipFileContent(path);
      assertThat(expectedZipFileContentList.containsAll(actualZipFileContentList)).isTrue();

      Files.delete(path);
   }

   private CwsConfiguration createCwsConfiguration(final String leverCode, final String berichtVersie){
      return CwsConfiguration.builder()
            .configurationId(999999L)
            .afnemerCode("testAfnCode")
            .leverCode(leverCode)
            .contractId(dummyContractId)
            .contractStartDate(dummyContractStartDate)
            .configurationName("testConfigName")
            .configurationVersion(10L)
            .configurationStatus("DE")
            .berichtVersie(berichtVersie)
            .build();
   }

   private void writeZipFile(ByteArrayOutputStream data, Path location) throws Exception {
      Files.deleteIfExists(location);
      try(OutputStream outputStream = new FileOutputStream(location.toString())) {
         data.writeTo(outputStream);
      }
   }

   private List<String> getZipFileContent(final Path pathToZipFile) throws Exception {
      List<String> actualZipFileContentList = new ArrayList<>();
      try (FileInputStream fis = new FileInputStream(pathToZipFile.toString());
           BufferedInputStream bis = new BufferedInputStream(fis);
           ZipInputStream zis = new ZipInputStream(bis)) {

         ZipEntry ze;
         while ((ze = zis.getNextEntry()) != null) {
            actualZipFileContentList.add(ze.getName());
         }
      }

      return actualZipFileContentList;
   }

   private List<CwsMetaCol> createCwsLaCwsMetaColList(){
      List<CwsMetaCol> cwsMetaColList = new ArrayList<>();
      CwsMetaCol cwsMetaCol;
      cwsMetaCol = CwsMetaCol.builder().techNaam("CwsLoonaangifteresponse").funcNaam("BERICHT").metaColId(4000L).parentId(0L).build();
      cwsMetaColList.add(cwsMetaCol);
      cwsMetaCol = CwsMetaCol.builder().techNaam("Gegevenslevering").funcNaam("GEGEVENSLEVERING").metaColId(4001L).parentId(4000L).build();
      cwsMetaColList.add(cwsMetaCol);
      cwsMetaCol = CwsMetaCol.builder().techNaam("NatuurlijkPersoon").funcNaam("NATUURLIJK PERSOON").metaColId(4002L).parentId(4001L).build();
      cwsMetaColList.add(cwsMetaCol);
      cwsMetaCol = CwsMetaCol.builder().techNaam("Burgerservicenr").funcNaam("Burgerservicenummer").metaColId(4003L).parentId(4002L).build();
      cwsMetaColList.add(cwsMetaCol);
      cwsMetaCol = CwsMetaCol.builder().techNaam("Applicatiemelding").funcNaam("APPLICATIEMELDING").metaColId(4004L).parentId(4000L).build();
      cwsMetaColList.add(cwsMetaCol);
      cwsMetaCol = CwsMetaCol.builder().techNaam("CdSrtApplicatiemelding").funcNaam("Code soort applicatiemelding").metaColId(4005L).parentId(4004L).build();
      cwsMetaColList.add(cwsMetaCol);
      cwsMetaCol = CwsMetaCol.builder().techNaam("CdApplicatiemelding").funcNaam("Code applicatiemelding").metaColId(4006L).parentId(4004L).build();
      cwsMetaColList.add(cwsMetaCol);
      cwsMetaCol = CwsMetaCol.builder().techNaam("ToelApplicatiemelding").funcNaam("Toelichting applicatiemelding").metaColId(4007L).parentId(4004L).build();
      cwsMetaColList.add(cwsMetaCol);

      return cwsMetaColList;
   }

   private List<CwsMetaCol> createCwsNpCwsMetaColList(){
      List<CwsMetaCol> cwsMetaColList = new ArrayList<>();
      CwsMetaCol cwsMetaCol;
      cwsMetaCol = CwsMetaCol.builder().techNaam("CwsNatuurlijkPersoonResponse").funcNaam("BERICHT").metaColId(4000L).parentId(0L).build();
      cwsMetaColList.add(cwsMetaCol);
      cwsMetaCol = CwsMetaCol.builder().techNaam("NatuurlijkPersoon").funcNaam("NATUURLIJK PERSOON").metaColId(4001L).parentId(4000L).build();
      cwsMetaColList.add(cwsMetaCol);
      cwsMetaCol = CwsMetaCol.builder().techNaam("Burgerservicenr").funcNaam("Burgerservicenummer").metaColId(4002L).parentId(4001L).build();
      cwsMetaColList.add(cwsMetaCol);
      cwsMetaCol = CwsMetaCol.builder().techNaam("Vipstatus").funcNaam("VIPSTATUS").metaColId(4003L).parentId(4001L).build();
      cwsMetaColList.add(cwsMetaCol);
      cwsMetaCol = CwsMetaCol.builder().techNaam("CdViptype").funcNaam("Code viptype").metaColId(4004L).parentId(4003L).build();
      cwsMetaColList.add(cwsMetaCol);
      cwsMetaCol = CwsMetaCol.builder().techNaam("Applicatiemelding").funcNaam("APPLICATIEMELDING").metaColId(4005L).parentId(4000L).build();
      cwsMetaColList.add(cwsMetaCol);
      cwsMetaCol = CwsMetaCol.builder().techNaam("CdSrtApplicatiemelding").funcNaam("Code soort applicatiemelding").metaColId(4006L).parentId(4005L).build();
      cwsMetaColList.add(cwsMetaCol);

      return cwsMetaColList;
   }

   private List<CwsMetaCol> createCwsHrCwsMetaColList(){
      List<CwsMetaCol> cwsMetaColList = new ArrayList<>();
      CwsMetaCol cwsMetaCol;
      cwsMetaCol = CwsMetaCol.builder().techNaam("CwsHandelsregisterResponse").funcNaam("CwsHandelsregisterResponse").metaColId(4000L).parentId(0L).build();
      cwsMetaColList.add(cwsMetaCol);
      cwsMetaCol = CwsMetaCol.builder().techNaam("Gegevenslevering").funcNaam("GEGEVENSLEVERING").metaColId(4001L).parentId(4000L).build();
      cwsMetaColList.add(cwsMetaCol);
      cwsMetaCol = CwsMetaCol.builder().techNaam("KvkNr").funcNaam("KvK-nummer").metaColId(4002L).parentId(4001L).build();
      cwsMetaColList.add(cwsMetaCol);
      cwsMetaCol = CwsMetaCol.builder().techNaam("NrInhoudingsplichtige").funcNaam("Nummer inhoudingsplichtige").metaColId(4003L).parentId(4001L).build();
      cwsMetaColList.add(cwsMetaCol);
      cwsMetaCol = CwsMetaCol.builder().techNaam("MaatschappelijkeActiviteit").funcNaam("MAATSCHAPPELIJKE ACTIVITEIT").metaColId(4004L).parentId(4001L).build();
      cwsMetaColList.add(cwsMetaCol);
      cwsMetaCol = CwsMetaCol.builder().techNaam("KvkNr").funcNaam("KvK-nummer").metaColId(4005L).parentId(4004L).build();
      cwsMetaColList.add(cwsMetaCol);
      cwsMetaCol = CwsMetaCol.builder().techNaam("Applicatiemelding").funcNaam("APPLICATIEMELDING").metaColId(4006L).parentId(4000L).build();
      cwsMetaColList.add(cwsMetaCol);
      cwsMetaCol = CwsMetaCol.builder().techNaam("CdSrtApplicatiemelding").funcNaam("Code soort applicatiemelding").metaColId(4007L).parentId(4006L).build();
      cwsMetaColList.add(cwsMetaCol);

      return cwsMetaColList;
   }
}
