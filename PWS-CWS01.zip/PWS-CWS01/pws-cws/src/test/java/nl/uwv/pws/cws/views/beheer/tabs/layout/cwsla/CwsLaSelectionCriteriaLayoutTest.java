package nl.uwv.pws.cws.views.beheer.tabs.layout.cwsla;

import com.vaadin.flow.component.checkbox.Checkbox;
import com.vaadin.flow.component.formlayout.FormLayout;
import com.vaadin.flow.component.textfield.TextField;
import nl.uwv.pws.cws.model.BaseCwsFilterType;
import nl.uwv.pws.cws.model.CwsLaFilterType;
import nl.uwv.pws.cws.model.SelectionCriteria;
import nl.uwv.pws.cws.util.CwsUIUtils;
import nl.uwv.pws.cws.views.beheer.configuratie.ConfigurationAction;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;

import static nl.uwv.pws.cws.util.Constants.*;
import static org.assertj.core.api.Assertions.assertThat;

public class CwsLaSelectionCriteriaLayoutTest {


   private CwsLaSelectionCriteriaLayout layout;

   @BeforeEach
   public void setup() {
      layout = new CwsLaSelectionCriteriaLayout();
   }

   @Test
   @DisplayName("Should create Selection criteria layout using correct components for ADD and MODIFY actions")
   void testCreateSelectionCriteriaLayoutForAddConfiguration() {
      Map<BaseCwsFilterType, String> filterMap = new HashMap<>();
      filterMap.put(CwsLaFilterType.CD_SOORT_IKVS, "2");
      filterMap.put(CwsLaFilterType.MAX_LEVERPERIODE, "10");
      filterMap.put(CwsLaFilterType.NIHIL_LNSV_UITSLUITEN, "J");
      filterMap.put(CwsLaFilterType.NIHIL_LNLBPH_UITSLUITEN, "n");
      SelectionCriteria selectionCriteria = new SelectionCriteria("CWS-LA");
      selectionCriteria.setFilterMap(filterMap);
      ConfigurationAction configurationAction =  ConfigurationAction.ADD;
      FormLayout formLayout = layout.createSelectionCriteriaLayout(selectionCriteria, configurationAction);

      TextField textFieldCodeSoortIkv = (TextField)CwsUIUtils.findComponent(COMPONENT_ID_CODESOORTIKVS_TEXT_FIELD, formLayout);
      assertThat(textFieldCodeSoortIkv).isNotNull();
      assertThat(textFieldCodeSoortIkv.getValue()).isEqualTo("2");
      assertThat(textFieldCodeSoortIkv.isEnabled()).isTrue();
      assertThat(textFieldCodeSoortIkv.getMaxLength()).isEqualTo(200);

      TextField textFieldMaxLeverperiode = (TextField)CwsUIUtils.findComponent(COMPONENT_ID_MAXLEVERPERIODE_TEXT_FIELD, formLayout);
      assertThat(textFieldMaxLeverperiode).isNotNull();
      assertThat(textFieldMaxLeverperiode.getValue()).isEqualTo("10");
      assertThat(textFieldMaxLeverperiode.isEnabled()).isTrue();
      assertThat(textFieldMaxLeverperiode.getMaxLength()).isEqualTo(3);

      Checkbox checkboxNihilLoonSvUitsluiten = (Checkbox)CwsUIUtils.findComponent(COMPONENT_ID_NIHILLOONSVUITSLUITEN_CHECKBOX, formLayout);
      assertThat(checkboxNihilLoonSvUitsluiten).isNotNull();
      assertThat(checkboxNihilLoonSvUitsluiten.getValue()).isTrue();
      assertThat(checkboxNihilLoonSvUitsluiten.isEnabled()).isTrue();

      Checkbox checkboxNihilLoonLbPhUitsluiten = (Checkbox)CwsUIUtils.findComponent(COMPONENT_ID_NIHILLOONLBPHUITSLUITEN_CHECKBOX, formLayout);
      assertThat(checkboxNihilLoonLbPhUitsluiten).isNotNull();
      assertThat(checkboxNihilLoonLbPhUitsluiten.getValue()).isFalse();
      assertThat(checkboxNihilLoonLbPhUitsluiten.isEnabled()).isTrue();

      assertThat(layout.getOriginalCodeSoortIkv()).isEqualTo("2");
      assertThat(layout.getOriginalMaxLeverperiode()).isEqualTo("10");
      assertThat(layout.isOriginalNihilLoonSvUitsluiten()).isTrue();
      assertThat(layout.isOriginalNihilLoonLbPhUitsluiten()).isFalse();
   }

   @Test
   @DisplayName("Should create Selection criteria layout using correct components for VIEW actions")
   void testCreateSelectionCriteriaLayoutForViewConfiguation() {
      Map<BaseCwsFilterType, String> filterMap = new HashMap<>();
      filterMap.put(CwsLaFilterType.CD_SOORT_IKVS, "8");
      filterMap.put(CwsLaFilterType.MAX_LEVERPERIODE, "15");
      filterMap.put(CwsLaFilterType.NIHIL_LNSV_UITSLUITEN, "n");
      filterMap.put(CwsLaFilterType.NIHIL_LNLBPH_UITSLUITEN, "n");
      SelectionCriteria selectionCriteria = new SelectionCriteria("CWS-LA");
      selectionCriteria.setFilterMap(filterMap);
      ConfigurationAction configurationAction = ConfigurationAction.VIEW;
      FormLayout formLayout = layout.createSelectionCriteriaLayout(selectionCriteria, configurationAction);

      TextField textFieldCodeSoortIkv = (TextField)CwsUIUtils.findComponent(COMPONENT_ID_CODESOORTIKVS_TEXT_FIELD, formLayout);
      assertThat(textFieldCodeSoortIkv).isNotNull();
      assertThat(textFieldCodeSoortIkv.getValue()).isEqualTo("8");
      assertThat(textFieldCodeSoortIkv.isEnabled()).isFalse();
      assertThat(textFieldCodeSoortIkv.getMaxLength()).isEqualTo(200);

      TextField textFieldMaxLeverperiode = (TextField)CwsUIUtils.findComponent(COMPONENT_ID_MAXLEVERPERIODE_TEXT_FIELD, formLayout);
      assertThat(textFieldMaxLeverperiode).isNotNull();
      assertThat(textFieldMaxLeverperiode.getValue()).isEqualTo("15");
      assertThat(textFieldMaxLeverperiode.isEnabled()).isFalse();
      assertThat(textFieldMaxLeverperiode.getMaxLength()).isEqualTo(3);

      Checkbox checkboxNihilLoonSvUitsluiten = (Checkbox)CwsUIUtils.findComponent(COMPONENT_ID_NIHILLOONSVUITSLUITEN_CHECKBOX, formLayout);
      assertThat(checkboxNihilLoonSvUitsluiten).isNotNull();
      assertThat(checkboxNihilLoonSvUitsluiten.isEnabled()).isFalse();
      assertThat(checkboxNihilLoonSvUitsluiten.getValue()).isFalse();

      Checkbox checkboxNihilLoonLbPhUitsluiten = (Checkbox)CwsUIUtils.findComponent(COMPONENT_ID_NIHILLOONLBPHUITSLUITEN_CHECKBOX, formLayout);
      assertThat(checkboxNihilLoonLbPhUitsluiten).isNotNull();
      assertThat(checkboxNihilLoonLbPhUitsluiten.getValue()).isFalse();
      assertThat(checkboxNihilLoonLbPhUitsluiten.isEnabled()).isFalse();
   }
}
