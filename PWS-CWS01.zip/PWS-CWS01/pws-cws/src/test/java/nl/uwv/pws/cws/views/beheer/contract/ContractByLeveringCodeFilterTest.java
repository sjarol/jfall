package nl.uwv.pws.cws.views.beheer.contract;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class ContractByLeveringCodeFilterTest {

   @Test
   @DisplayName("Given lever code filled, return correct WHERE clause")
   void testWithLeverCode() {
      String leverCode = "lev_code";
      ContractByLeveringCodeFilter filter = new ContractByLeveringCodeFilter(leverCode);

      assertThat(filter.getFilterSql()).isEqualToIgnoringCase("(UPPER(LEV_CD) = ?)");
      assertThat(filter.getParametersSize()).isEqualTo(1);
      assertThat(filter.getParameter(0)).isEqualTo("LEV_CODE");
   }
}
