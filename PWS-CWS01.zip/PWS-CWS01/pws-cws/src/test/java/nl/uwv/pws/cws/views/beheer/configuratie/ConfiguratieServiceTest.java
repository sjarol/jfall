package nl.uwv.pws.cws.views.beheer.configuratie;

import com.vaadin.flow.data.provider.QuerySortOrder;
import com.vaadin.flow.data.provider.SortDirection;
import nl.uwv.pws.backend.desc.FieldDescriptor;
import nl.uwv.pws.cws.util.Constants;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class ConfiguratieServiceTest {

   @Test
   @DisplayName("ConfiguratieService configures the correct table name and default column sort")
   void testListServiceConfiguration() {
      ConfiguratieService configuratieService = new ConfiguratieService(Constants.DS_NAME);
      assertThat(configuratieService.getViewName()).isEqualTo("CWS_CONFIGURATIE_VW");
      assertThat(configuratieService.getDescriptor()).isInstanceOf(FieldDescriptor.class);

      QuerySortOrder defaultSortOrder = configuratieService.getDefaultSortOrder();
      assertThat(defaultSortOrder).isNotNull();
      assertThat(defaultSortOrder.getSorted()).isEqualTo(ConfiguratieColumn.VERSION.name());
      assertThat(defaultSortOrder.getDirection()).isEqualTo(SortDirection.ASCENDING);
   }
}
