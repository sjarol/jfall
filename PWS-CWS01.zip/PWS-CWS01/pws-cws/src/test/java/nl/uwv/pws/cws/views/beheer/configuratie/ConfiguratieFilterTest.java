package nl.uwv.pws.cws.views.beheer.configuratie;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;

import static org.assertj.core.api.Assertions.assertThat;

public class ConfiguratieFilterTest {

   @Test
   @DisplayName("Given contract id and contract start date, create correct sql filer")
   void testCreateSqlFilter() {
      BigDecimal contractId = new BigDecimal("123");
      LocalDate contractStartDate = LocalDate.of(2021,1,1);

      ConfiguratieFilter filter = new ConfiguratieFilter(contractId, contractStartDate);

      assertThat(filter.getFilterSql()).isEqualToIgnoringCase("(CONTRACT_ID = 123 AND CONT_HIS_DAT_IN =  DATE '2021-01-01')");
      assertThat(filter.getParametersSize()).isEqualTo(0);
   }

}
