package nl.uwv.pws.cws.views.beheer.levering;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class LeveringFilterTest {

   @Test
   @DisplayName("Given call to find all leveringen, return correct WHERE clause")
   void testWithAllLeveringen() {
      LeveringFilter filter = new LeveringFilter();

      assertThat(filter.getFilterSql()).isEqualToIgnoringCase("(LEV_CD IS NOT NULL AND UPPER(LEV_CD) LIKE '%CWS%')");
      assertThat(filter.getParametersSize()).isEqualTo(0);
   }
}
