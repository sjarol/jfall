package nl.uwv.pws.cws.backend.service;

import nl.uwv.pws.cws.backend.dao.CwsConfigurationDao;
import nl.uwv.pws.cws.model.*;
import org.junit.jupiter.api.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.TestInstance.Lifecycle.PER_CLASS;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@TestInstance(PER_CLASS)
public class ExportServiceTest {

   private ExportService exportService;
   private MockedStatic<CwsConfigurationDao> cwsConfigurationDaoMockedStatic;
   private CwsConfigurationDao cwsConfigurationDao;
   private String expectedImport;

   @BeforeAll
   public void setup() throws IOException {
      this.cwsConfigurationDaoMockedStatic = Mockito.mockStatic(CwsConfigurationDao.class);
      this.cwsConfigurationDao = mock(CwsConfigurationDao.class);

      cwsConfigurationDaoMockedStatic.when(CwsConfigurationDao::getInstance).thenReturn(cwsConfigurationDao);
      exportService = new ExportService();

      Path path = Paths.get("src", "test", "resources", "test_import.json");
      Stream<String> lines = Files.lines(path);
      this.expectedImport = lines.collect(Collectors.joining("\r\n"));
      lines.close();
   }

   @AfterAll
   public void cleanup(){
      cwsConfigurationDaoMockedStatic.close();
   }

   @Test
   @DisplayName("Should successfully export a configuration")
   void testImportConfiguration() {
      Map<BaseCwsFilterType, String> filterMap = new HashMap<>();
      filterMap.put(CwsHrFilterType.BEEINDIGD_ADRES_UITSLUITEN, "N");
      SelectionCriteria selectionCriteria = new SelectionCriteria("CWS-HR");
      selectionCriteria.setFilterMap(filterMap);
      when(cwsConfigurationDao.selectSelectionCriteriaByConfigId(999999L)).thenReturn(selectionCriteria);

      List<CwsMetaCol> cwsMetaColList = createCwsMetaColList();
      when(cwsConfigurationDao.selectConfigurationMetaData(999999L)).thenReturn(cwsMetaColList);

      CwsConfiguration cwsConfiguration = createCwsConfiguration();
      String importedConfiguration = exportService.generateExportConfigurationString(cwsConfiguration);
      assertThat(importedConfiguration).isEqualTo(expectedImport);
   }

   private CwsConfiguration createCwsConfiguration(){
      return CwsConfiguration.builder()
            .configurationId(999999L)
            .contractId(455062L)
            .leverCode("CWS-HR")
            .berichtVersie("0105")
            .configurationName("config-test-export-import")
            .configurationStatus("CO")
            .configurationVersion(10L)
            .contractStartDate(LocalDate.of(2020, 11, 2))
            .configurationStartDate(LocalDate.of(2021, 8, 31))
            .afnemerCode("CWSFAT")
            .afnemerNaam("NAAM AFNEMER CWSFAT")
            .build();
   }

   private List<CwsMetaCol> createCwsMetaColList(){
      List<CwsMetaCol> cwsMetaColList = new ArrayList<>();
      CwsMetaCol cwsMetaCol;
      cwsMetaCol = CwsMetaCol.builder().techNaam("CwsHandelsregisterResponse").metaColId(4000L).parentId(0L).build();
      cwsMetaColList.add(cwsMetaCol);
      cwsMetaCol = CwsMetaCol.builder().techNaam("Gegevenslevering").metaColId(4001L).parentId(4000L).build();
      cwsMetaColList.add(cwsMetaCol);
      cwsMetaCol = CwsMetaCol.builder().techNaam("KvkNr").metaColId(4002L).parentId(4001L).build();
      cwsMetaColList.add(cwsMetaCol);
      cwsMetaCol = CwsMetaCol.builder().techNaam("NrInhoudingsplichtige").metaColId(4003L).parentId(4001L).build();
      cwsMetaColList.add(cwsMetaCol);
      cwsMetaCol = CwsMetaCol.builder().techNaam("MaatschappelijkeActiviteit").metaColId(4004L).parentId(4001L).build();
      cwsMetaColList.add(cwsMetaCol);
      cwsMetaCol = CwsMetaCol.builder().techNaam("KvkNr").metaColId(4005L).parentId(4004L).build();
      cwsMetaColList.add(cwsMetaCol);

      return cwsMetaColList;
   }
}
