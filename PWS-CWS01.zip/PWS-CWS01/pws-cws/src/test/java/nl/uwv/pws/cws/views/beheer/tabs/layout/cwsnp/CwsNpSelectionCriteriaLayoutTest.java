package nl.uwv.pws.cws.views.beheer.tabs.layout.cwsnp;

import com.vaadin.flow.component.checkbox.Checkbox;
import com.vaadin.flow.component.formlayout.FormLayout;
import nl.uwv.pws.cws.model.BaseCwsFilterType;
import nl.uwv.pws.cws.model.CwsNpFilterType;
import nl.uwv.pws.cws.model.SelectionCriteria;
import nl.uwv.pws.cws.util.CwsUIUtils;
import nl.uwv.pws.cws.views.beheer.configuratie.ConfigurationAction;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;

import static nl.uwv.pws.cws.util.Constants.COMPONENT_ID_LEVENDPERSOONUITSLUITEN_CHECKBOX;
import static nl.uwv.pws.cws.util.Constants.COMPONENT_ID_OVERLEDENPERSOONUITSLUITEN_CHECKBOX;
import static org.assertj.core.api.Assertions.assertThat;

public class CwsNpSelectionCriteriaLayoutTest {


   private CwsNpSelectionCriteriaLayout layoutHelper;

   @BeforeEach
   public void setup() {
      layoutHelper = new CwsNpSelectionCriteriaLayout();
   }

   @Test
   @DisplayName("Should create Selection criteria layout using correct components for ADD and MODIFY actions")
   void testCreateSelectionCriteriaLayoutForAddConfiguration() {
      Map<BaseCwsFilterType, String> filterMap = new HashMap<>();
      filterMap.put(CwsNpFilterType.LEVEND_NPE_UITSLUITEN, "J");
      filterMap.put(CwsNpFilterType.OVERLEDEN_NPE_UITSLUITEN, "n");
      SelectionCriteria selectionCriteria = new SelectionCriteria("CWS-NP");
      selectionCriteria.setFilterMap(filterMap);
      ConfigurationAction configurationAction =  ConfigurationAction.ADD;
      FormLayout formLayout = layoutHelper.createSelectionCriteriaLayout(selectionCriteria, configurationAction);

      Checkbox checkboxLevendPersoonUitsluiten = (Checkbox)CwsUIUtils.findComponent(COMPONENT_ID_LEVENDPERSOONUITSLUITEN_CHECKBOX, formLayout);
      assertThat(checkboxLevendPersoonUitsluiten).isNotNull();
      assertThat(checkboxLevendPersoonUitsluiten.getValue()).isTrue();
      assertThat(checkboxLevendPersoonUitsluiten.isEnabled()).isTrue();

      Checkbox checkboxOverledenPersoonUitsluiten = (Checkbox)CwsUIUtils.findComponent(COMPONENT_ID_OVERLEDENPERSOONUITSLUITEN_CHECKBOX, formLayout);
      assertThat(checkboxOverledenPersoonUitsluiten).isNotNull();
      assertThat(checkboxOverledenPersoonUitsluiten.getValue()).isFalse();
      assertThat(checkboxOverledenPersoonUitsluiten.isEnabled()).isTrue();

      assertThat(layoutHelper.isOriginalLevendPersoonUitsluiten()).isTrue();
      assertThat(layoutHelper.isOriginalOverledenPersoonUitsluiten()).isFalse();
   }

   @Test
   @DisplayName("Should create Selection criteria layout using correct components for VIEW actions")
   void testCreateSelectionCriteriaLayoutForViewConfiguation() {
      Map<BaseCwsFilterType, String> filterMap = new HashMap<>();
      filterMap.put(CwsNpFilterType.LEVEND_NPE_UITSLUITEN, "n");
      filterMap.put(CwsNpFilterType.OVERLEDEN_NPE_UITSLUITEN, "n");
      SelectionCriteria selectionCriteria = new SelectionCriteria("CWS-NP");
      selectionCriteria.setFilterMap(filterMap);
      ConfigurationAction configurationAction = ConfigurationAction.VIEW;
      FormLayout formLayout = layoutHelper.createSelectionCriteriaLayout(selectionCriteria, configurationAction);

      Checkbox checkboxLevendPersoonUitsluiten = (Checkbox)CwsUIUtils.findComponent(COMPONENT_ID_LEVENDPERSOONUITSLUITEN_CHECKBOX, formLayout);
      assertThat(checkboxLevendPersoonUitsluiten).isNotNull();
      assertThat(checkboxLevendPersoonUitsluiten.isEnabled()).isFalse();
      assertThat(checkboxLevendPersoonUitsluiten.getValue()).isFalse();

      Checkbox checkboxOverledenPersoonUitsluiten = (Checkbox)CwsUIUtils.findComponent(COMPONENT_ID_OVERLEDENPERSOONUITSLUITEN_CHECKBOX, formLayout);
      assertThat(checkboxOverledenPersoonUitsluiten).isNotNull();
      assertThat(checkboxOverledenPersoonUitsluiten.getValue()).isFalse();
      assertThat(checkboxOverledenPersoonUitsluiten.isEnabled()).isFalse();
   }
}
