package nl.uwv.pws.cws.backend.mapper;

import nl.uwv.pws.cws.model.CodeSoortIkv;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class CodeSoortIkvRowMapperTest {

   @Test
   @DisplayName("Should map the resultset fields")
   void testMapRow() throws SQLException {
      ResultSet resultSet = mock(ResultSet.class);

      when(resultSet.getString("CODE")).thenReturn("testCode");
      when(resultSet.getString("OMSCHRIJVING")).thenReturn("testOmschrijving");

      LocalDateTime localDateTime = LocalDateTime.of(2021, 8,25,11,20);
      when(resultSet.getTimestamp("DATUMEINDE")).thenReturn(Timestamp.valueOf(localDateTime));

      CodeSoortIkvRowMapper codeSoortIkvRowMapper = new CodeSoortIkvRowMapper();

      CodeSoortIkv codeSoortIkv = codeSoortIkvRowMapper.mapRow(resultSet);
      assertThat(codeSoortIkv.getCode()).isEqualTo("testCode");
      assertThat(codeSoortIkv.getOmschrijving()).isEqualTo("testOmschrijving");
      assertThat(codeSoortIkv.getDatumEinde()).isEqualTo("25-08-2021");
   }
}
