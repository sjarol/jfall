package nl.uwv.pws.cws.views.beheer.contract;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class ContractByAfnemerCodeFilterTest {

   @Test
   @DisplayName("Given afnemer code filled, return correct WHERE clause")
   void testWithAfnemerCode() {
      String afnemerCode = "afn_code";
      ContractByAfnemerCodeFilter filter = new ContractByAfnemerCodeFilter(afnemerCode);

      assertThat(filter.getFilterSql()).isEqualToIgnoringCase("(UPPER(AFN_CD) = ?)");
      assertThat(filter.getParametersSize()).isEqualTo(1);
      assertThat(filter.getParameter(0)).isEqualTo("AFN_CODE");
   }
}
