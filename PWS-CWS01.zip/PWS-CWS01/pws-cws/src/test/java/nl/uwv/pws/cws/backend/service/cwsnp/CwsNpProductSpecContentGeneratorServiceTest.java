package nl.uwv.pws.cws.backend.service.cwsnp;

import nl.uwv.pws.cws.backend.dao.CwsConfigurationDao;
import nl.uwv.pws.cws.model.BaseCwsFilterType;
import nl.uwv.pws.cws.model.CwsConfiguration;
import nl.uwv.pws.cws.model.CwsNpFilterType;
import nl.uwv.pws.cws.model.SelectionCriteria;
import org.junit.jupiter.api.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import java.util.HashMap;
import java.util.Map;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.junit.jupiter.api.TestInstance.Lifecycle.PER_CLASS;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@TestInstance(PER_CLASS)
public class CwsNpProductSpecContentGeneratorServiceTest {

   private CwsNpProductSpecContentGeneratorService cwsNpProductSpecContentGeneratorService;

   private MockedStatic<CwsConfigurationDao> cwsConfigurationDaoMockedStatic;
   private CwsConfigurationDao cwsConfigurationDao;

   @BeforeAll
   public void setupOnce() {
      this.cwsConfigurationDaoMockedStatic = Mockito.mockStatic(CwsConfigurationDao.class);
      this.cwsConfigurationDao = mock(CwsConfigurationDao.class);

      cwsConfigurationDaoMockedStatic.when(CwsConfigurationDao::getInstance).thenReturn(cwsConfigurationDao);
   }

   @AfterAll
   public void cleanup(){
      cwsConfigurationDaoMockedStatic.close();
   }

   @Test
   @DisplayName("Should succesfully import a configuration")
   void testImportConfiguration() {
      cwsNpProductSpecContentGeneratorService = new CwsNpProductSpecContentGeneratorService(CwsConfiguration.builder()
            .configurationId(999999L)
            .configurationVersion(10L)
            .build(),
            "dummyKenmerk", "dummyRequestHeader", "dummyResponseHeader");

      assertThat(cwsNpProductSpecContentGeneratorService.getPdfTemplateFileName()).isEqualTo("../templates/cwsnp-product-specificatie-template.odt");
      assertThat(cwsNpProductSpecContentGeneratorService.getExampleRequestFileNames()).isEqualTo(new String [] {"Request.xml"});
      assertThat(cwsNpProductSpecContentGeneratorService.getExampleXmlFolderName()).isEqualTo("cwsnp/");
      assertThat(cwsNpProductSpecContentGeneratorService.getResponseBodyRootElementName()).isEqualTo("CwsNatuurlijkPersoonResponse");
   }

   @Test
   @DisplayName("Should return correct mapping for CWS-NP at service construction")
   public void testGetSelectieCriteriaMapping(){
      Map<BaseCwsFilterType, String> filterMap = new HashMap<>();
      filterMap.put(CwsNpFilterType.LEVEND_NPE_UITSLUITEN, "N");
      filterMap.put(CwsNpFilterType.OVERLEDEN_NPE_UITSLUITEN, "J");

      SelectionCriteria selectionCriteria = new SelectionCriteria("CWS-NP");
      selectionCriteria.setFilterMap(filterMap);
      when(cwsConfigurationDao.selectSelectionCriteriaByConfigId(anyLong())).thenReturn(selectionCriteria);

      cwsNpProductSpecContentGeneratorService = new CwsNpProductSpecContentGeneratorService(CwsConfiguration.builder()
            .configurationId(999999L)
            .configurationVersion(10L)
            .build(),
            "dummyKenmerk", "dummyRequestHeader", "dummyResponseHeader");

      Map<String, Object> mappingMap = cwsNpProductSpecContentGeneratorService.getSelectieCriteriaMapping();
      String value = (String) mappingMap.get("condition_overledenPersoonUitsluiten");
      assertThat(value).isEqualTo("true");

      value = (String) mappingMap.get("condition_levendPersoonUitsluiten");
      assertThat(value).isEqualTo("false");
   }
}
