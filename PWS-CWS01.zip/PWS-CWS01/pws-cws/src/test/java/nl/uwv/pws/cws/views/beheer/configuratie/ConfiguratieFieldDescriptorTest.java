package nl.uwv.pws.cws.views.beheer.configuratie;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.stream.Collectors;

import static org.assertj.core.api.Assertions.assertThat;

public class ConfiguratieFieldDescriptorTest {

   @Test
   @DisplayName("Multiple calls to the getInstance() method return the same instance")
   void testGetInstance() {
      assertThat(ConfiguratieFieldDescriptor.getInstance()).isSameAs(ConfiguratieFieldDescriptor.getInstance());
   }

   @Test
   @DisplayName("There's a descriptor available for each of the fields we support")
   void testFields() {
      ConfiguratieFieldDescriptor fieldDescriptor = ConfiguratieFieldDescriptor.getInstance();

      assertThat(fieldDescriptor.getColumnNames()).containsAnyElementsOf(
            Arrays.stream(ConfiguratieColumn.values())
                  .map(Enum::name)
                  .collect(Collectors.toList())
      );
   }
}
