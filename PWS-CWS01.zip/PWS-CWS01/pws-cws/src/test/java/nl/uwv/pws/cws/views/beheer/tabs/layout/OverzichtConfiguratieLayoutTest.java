package nl.uwv.pws.cws.views.beheer.tabs.layout;

import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.html.Anchor;
import com.vaadin.flow.data.provider.ListDataProvider;
import nl.uwv.pws.cws.backend.dao.CwsConfigurationDao;
import nl.uwv.pws.cws.backend.dao.CwsConfigurationOverviewDao;
import nl.uwv.pws.cws.model.CwsMetaCol;
import nl.uwv.pws.cws.model.OverviewGridData;
import nl.uwv.pws.cws.model.viewtab.ConfiguratieWithFilters;
import nl.uwv.pws.cws.model.viewtab.CwsOverzichtConfiguratie;
import nl.uwv.pws.cws.model.viewtab.CwsOverzichtSelectieCriteria;
import nl.uwv.pws.cws.util.CwsUIUtils;
import nl.uwv.pws.cws.views.beheer.tabs.layout.cwsla.CwsLaOverzichtFilterFormLayout;
import org.junit.jupiter.api.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import test.common.PwsTestUtils;

import java.util.*;

import static nl.uwv.pws.cws.util.Constants.COMPONENT_ID_OVERZICHT_CWS_CONFIGURATIE_SEARCH_RESULT;
import static nl.uwv.pws.cws.util.Constants.COMPONENT_ID_OVERZICHT_CWS_CONFIGURATIE_SEARCH_RESULT_LABEL_GRID;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.TestInstance.Lifecycle.PER_CLASS;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@TestInstance(PER_CLASS)
public class OverzichtConfiguratieLayoutTest {

   private OverzichtConfiguratieLayout overzichtConfiguratieLayout;
   private MockedStatic<CwsConfigurationDao> cwsConfigurationDaoMockedStatic;
   private MockedStatic<CwsConfigurationOverviewDao> cwsConfigurationOverviewDaoMockedStatic;

   private CwsConfigurationDao cwsConfigurationDao;
   private CwsConfigurationOverviewDao cwsConfigurationOverviewDao;

   @BeforeAll
   public void setup() {
      this.cwsConfigurationDaoMockedStatic = Mockito.mockStatic(CwsConfigurationDao.class);
      this.cwsConfigurationOverviewDaoMockedStatic = Mockito.mockStatic(CwsConfigurationOverviewDao.class);
      this.cwsConfigurationDao = mock(CwsConfigurationDao.class);
      this.cwsConfigurationOverviewDao = mock(CwsConfigurationOverviewDao.class);

      cwsConfigurationDaoMockedStatic.when(CwsConfigurationDao::getInstance).thenReturn(cwsConfigurationDao);
      cwsConfigurationOverviewDaoMockedStatic.when(CwsConfigurationOverviewDao::getInstance).thenReturn(cwsConfigurationOverviewDao);
      when(cwsConfigurationDao.getMaxBerichtVersie(anyString())).thenReturn("102");
      Map<Long, CwsMetaCol> metaColMap = Mockito.anyMap();
      when(cwsConfigurationDao.getMetaDataByLeverCodeAndVersie(anyString(), "102")).thenReturn(metaColMap);
   }

   @AfterAll
   public void cleanup() {
      cwsConfigurationDaoMockedStatic.close();
      cwsConfigurationOverviewDaoMockedStatic.close();
   }

   @Test
   @DisplayName("Should make OverzichtConfiguratieLayout containing ")
   void testFindAndDisplayApplicableConfiguraties() {
      overzichtConfiguratieLayout = new OverzichtConfiguratieLayout("CWS-LA");
      overzichtConfiguratieLayout.setExportConfiguratiesLink(mock(Anchor.class));
      assertThat(overzichtConfiguratieLayout.getFilterCheckboxes()).isInstanceOf(CwsLaOverzichtFilterFormLayout.class);

      Map<Long, CwsMetaCol> metaColMap = new HashMap<>();
      CwsMetaCol cwsMetaCol1 = CwsMetaCol.builder().metaColId(1000L).checked(true).enabled(true).build();
      CwsMetaCol cwsMetaCol2 = CwsMetaCol.builder().metaColId(1001L).checked(true).enabled(true).build();
      metaColMap.put(1000L, cwsMetaCol1);
      metaColMap.put(1001L, cwsMetaCol2);
      overzichtConfiguratieLayout.getMetaColMap().putAll(metaColMap);

      Map<String, Object> map1 = new HashMap<>();
      map1.put("CCON_ID", 1000L);
      map1.put("TECH_NAAM", "testAdres");
      map1.put("FUNC_NAAM", "test func naam1");
      map1.put("BRON_TABEL", "TABEL1");

      Map<String, Object> map2 = new HashMap<>();
      map2.put("CCON_ID", 1001L);
      map2.put("TECH_NAAM", "testAdres2");
      map2.put("FUNC_NAAM", "test func naam2");
      map2.put("BRON_TABEL", "TABEL2");

      CwsOverzichtConfiguratie cwsOverzichtConfiguratie = new CwsOverzichtConfiguratie();
      cwsOverzichtConfiguratie.setConfigId(1001L);
      cwsOverzichtConfiguratie.setName("test configuratie naam");

      overzichtConfiguratieLayout.getFilterCheckboxes().getCheckboxList().listIterator().next().setValue(true);

      Map<String, Boolean> filter = new HashMap<>();
      filter.put("CD_SOORT_IKVS", false);
      filter.put("NIHIL_LNSV_UITSLUITEN", true);
      filter.put("NIHIL_LNLBPH_UITSLUITEN", false);
      ConfiguratieWithFilters configuratieWithFilters = ConfiguratieWithFilters.builder().cconId(1001L).filters(filter).build();

      when(cwsConfigurationOverviewDao.collectAllConfigsWithMatchingFilters(anyString(), any(CwsOverzichtSelectieCriteria.class))).thenReturn(Arrays.asList(configuratieWithFilters));
      when(cwsConfigurationOverviewDao.collectAllConfigsWithMatchingNewestMetaColIds(any(List.class), anyString())).thenReturn(Arrays.asList(map1, map2));
      when(cwsConfigurationOverviewDao.getMetaColDetail(any(List.class))).thenReturn(Arrays.asList(map1, map2));
      when(cwsConfigurationOverviewDao.getConfiguratiesWithAfnemerDetail(any(List.class))).thenReturn(Arrays.asList(cwsOverzichtConfiguratie));
      overzichtConfiguratieLayout.findAndDisplayApplicableConfiguraties();

      Component labelGrid = CwsUIUtils.findComponent(COMPONENT_ID_OVERZICHT_CWS_CONFIGURATIE_SEARCH_RESULT_LABEL_GRID, overzichtConfiguratieLayout);
      Grid<OverviewGridData> grid = (Grid<OverviewGridData>) PwsTestUtils.findDescendentsById(COMPONENT_ID_OVERZICHT_CWS_CONFIGURATIE_SEARCH_RESULT, labelGrid);
      Collection<OverviewGridData> gridItems = ((ListDataProvider<OverviewGridData>)grid.getDataProvider()).getItems();
      assertThat(gridItems.size()).isEqualTo(1);

      OverviewGridData overviewGridData = gridItems.iterator().next();
      assertThat(overviewGridData.getValues().get("Config Naam")).isEqualTo("test configuratie naam");
      assertThat(overviewGridData.getValues().get("test func naam1")).isEqualTo("");
      assertThat(overviewGridData.getValues().get("test func naam2")).isEqualTo("X");
   }

}
