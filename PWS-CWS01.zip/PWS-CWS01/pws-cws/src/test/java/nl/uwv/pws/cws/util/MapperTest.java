package nl.uwv.pws.cws.util;

import nl.uwv.pws.backend.types.ColumnList;
import nl.uwv.pws.cws.model.ConfigurationDetails;
import nl.uwv.pws.cws.model.ContractDetails;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDate;

import static org.assertj.core.api.Assertions.assertThat;

public class MapperTest {

   @Test
   @DisplayName("Should map ColumnList columns correctly to ContractDetail object")
   void testMapToContractDetail(){
      LocalDate hisDatIn = LocalDate.of(2019,10,9);
      LocalDate hisDatEnd = LocalDate.of(2020,10,9);
      ColumnList columnList = new ColumnList(0, new String[] { "CONTRACT_ID", "HIS_DAT_IN", "HIS_DAT_END", "LEV_CD", "AFN_CD", "AFN_NAAM" },
            new Object[] { new BigDecimal("12345"), Date.valueOf(hisDatIn), Date.valueOf(hisDatEnd),"LEVCD_1", "ACODE", "ANAAM"});
      ContractDetails contractDetails = Mapper.mapToContractDetail(columnList);
      assertThat(contractDetails.getContractId()).isEqualTo(new BigDecimal("12345"));
      assertThat(contractDetails.getContractStartDate()).isEqualTo(hisDatIn);
      assertThat(contractDetails.getContractEndDate()).isEqualTo(hisDatEnd);
      assertThat(contractDetails.getLeverCode()).isEqualTo("LEVCD_1" );
      assertThat(contractDetails.getAfnemerCode()).isEqualTo("ACODE" );
      assertThat(contractDetails.getAfnemerNaam()).isEqualTo("ANAAM" );
   }

   @Test
   @DisplayName("Should map ColumnList columns correctly to ConfigurationDetails object")
   void testMapToConfigurationDetail(){
      ColumnList columnList = new ColumnList(0, new String[] { "CCON_ID", "VERSION", "STATUS" },
            new Object[] { new BigDecimal("12345"), BigDecimal.ONE ,"CO"});
      ConfigurationDetails configurationDetails = Mapper.mapToConfigurationDetail(columnList);
      assertThat(configurationDetails.getConfigurationId()).isEqualTo(new BigDecimal("12345"));
      assertThat(configurationDetails.getConfigurationVersion()).isEqualTo(BigDecimal.ONE);
      assertThat(configurationDetails.getConfigurationStatus()).isEqualTo("CO");
   }
}
