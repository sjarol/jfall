package nl.uwv.pws.cws.views.beheer.contract;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class ContractByContractIdFilterTest {

   @Test
   @DisplayName("Given contract id filled, return correct WHERE clause")
   void testWithLeverCode() {
      String contractId = "123456";
      ContractByContractIdFilter filter = new ContractByContractIdFilter(contractId);

      assertThat(filter.getFilterSql()).isEqualToIgnoringCase("(CONTRACT_ID = ?)");
      assertThat(filter.getParametersSize()).isEqualTo(1);
      assertThat(filter.getParameter(0)).isEqualTo("123456");
   }
}
