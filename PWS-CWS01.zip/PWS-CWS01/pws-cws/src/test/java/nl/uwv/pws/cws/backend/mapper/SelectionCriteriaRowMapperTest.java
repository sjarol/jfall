package nl.uwv.pws.cws.backend.mapper;

import nl.uwv.pws.cws.model.CwsHrFilterType;
import nl.uwv.pws.cws.model.CwsLaFilterType;
import nl.uwv.pws.cws.model.CwsNpFilterType;
import nl.uwv.pws.cws.model.SelectionCriteria;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

import java.sql.ResultSet;
import java.sql.SQLException;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class SelectionCriteriaRowMapperTest {

   private ResultSet resultSet;

   @BeforeEach
   public void setup() throws SQLException {
      resultSet = mock(ResultSet.class);
      when(resultSet.next()).thenAnswer(new Answer<Boolean>() {
         private int iterations = 1;

         public Boolean answer(InvocationOnMock invocation) {
            return iterations-- > 0;
         }
      });
   }

   @Test
   @DisplayName("Should map the resultset fields to CWS-LA SelectionCriteria and filtermap contains CD_SOORT_IKVS")
   void testMapRowSelectionCriteriaCdSoortIkvs() throws SQLException {

      when(resultSet.getString("LEV_CD")).thenReturn("CWS-LA");
      when(resultSet.getString("TECH_NAAM")).thenReturn("CD_SOORT_IKVS");
      when(resultSet.getString("VALUE")).thenReturn("testValue");

      SelectionCriteriaRowMapper selectionCriteriaRowMapper = new SelectionCriteriaRowMapper();

      SelectionCriteria selectionCriteria = selectionCriteriaRowMapper.mapRow(resultSet);
      assertThat(selectionCriteria.getLevCode()).isEqualTo("CWS-LA");
      assertThat(selectionCriteria.getFilterMap().get(CwsLaFilterType.CD_SOORT_IKVS)).isEqualTo("testValue");
   }

   @Test
   @DisplayName("Should map the resultset fields to CWS-LA SelectionCriteria and filtermap contains MAX_LEVERPERIODE")
   void testMapRowSelectionCriteriaMaxLeverPeriode() throws SQLException {
      when(resultSet.getString("LEV_CD")).thenReturn("CWS-LA");
      when(resultSet.getString("TECH_NAAM")).thenReturn("MAX_LEVERPERIODE");
      when(resultSet.getString("VALUE")).thenReturn("testValue");

      SelectionCriteriaRowMapper selectionCriteriaRowMapper = new SelectionCriteriaRowMapper();

      SelectionCriteria selectionCriteria = selectionCriteriaRowMapper.mapRow(resultSet);
      assertThat(selectionCriteria.getLevCode()).isEqualTo("CWS-LA");
      assertThat(selectionCriteria.getFilterMap().get(CwsLaFilterType.MAX_LEVERPERIODE)).isEqualTo("testValue");
   }

   @Test
   @DisplayName("Should map the resultset fields to CWS-LA SelectionCriteria and filtermap contains NIHIL_LNSV_UITSLUITEN")
   void testMapRowSelectionCriteriaNihilLnsvUitsluiten() throws SQLException {
      when(resultSet.getString("LEV_CD")).thenReturn("CWS-LA");
      when(resultSet.getString("TECH_NAAM")).thenReturn("NIHIL_LNSV_UITSLUITEN");
      when(resultSet.getString("VALUE")).thenReturn("N");

      SelectionCriteriaRowMapper selectionCriteriaRowMapper = new SelectionCriteriaRowMapper();

      SelectionCriteria selectionCriteria = selectionCriteriaRowMapper.mapRow(resultSet);

      assertThat(selectionCriteria.getLevCode()).isEqualTo("CWS-LA");
      assertThat(selectionCriteria.getFilterMap().get(CwsLaFilterType.NIHIL_LNSV_UITSLUITEN)).isEqualTo("N");
   }

   @Test
   @DisplayName("Should map the resultset fields to CWS-LA SelectionCriteria and filtermap contains NIHIL_LNLBPH_UITSLUITEN")
   void testMapRowSelectionCriteriaNihilLnlbphUitsluiten() throws SQLException {
      when(resultSet.getString("LEV_CD")).thenReturn("CWS-LA");
      when(resultSet.getString("TECH_NAAM")).thenReturn("NIHIL_LNLBPH_UITSLUITEN");
      when(resultSet.getString("VALUE")).thenReturn("J");

      SelectionCriteriaRowMapper selectionCriteriaRowMapper = new SelectionCriteriaRowMapper();

      SelectionCriteria selectionCriteria = selectionCriteriaRowMapper.mapRow(resultSet);

      assertThat(selectionCriteria.getLevCode()).isEqualTo("CWS-LA");
      assertThat(selectionCriteria.getFilterMap().get(CwsLaFilterType.NIHIL_LNLBPH_UITSLUITEN)).isEqualTo("J");
   }

   @Test
   @DisplayName("Should map the resultset fields to CWS-NP SelectionCriteria and filtermap contains LEVEND_NPE_UITSLUITEN")
   void testMapRowSelectionCriteriaLevendNpeUitsluiten() throws SQLException {
      when(resultSet.getString("LEV_CD")).thenReturn("CWS-NP");
      when(resultSet.getString("TECH_NAAM")).thenReturn("LEVEND_NPE_UITSLUITEN");
      when(resultSet.getString("VALUE")).thenReturn("N");

      SelectionCriteriaRowMapper selectionCriteriaRowMapper = new SelectionCriteriaRowMapper();

      SelectionCriteria selectionCriteria = selectionCriteriaRowMapper.mapRow(resultSet);

      assertThat(selectionCriteria.getLevCode()).isEqualTo("CWS-NP");
      assertThat(selectionCriteria.getFilterMap().get(CwsNpFilterType.LEVEND_NPE_UITSLUITEN)).isEqualTo("N");
   }

   @Test
   @DisplayName("Should map the resultset fields to CWS-NP SelectionCriteria and filtermap contains OVERLEDEN_NPE_UITSLUITEN")
   void testMapRowSelectionCriteriaOverledenNpeUitsluiten() throws SQLException {
      when(resultSet.getString("LEV_CD")).thenReturn("CWS-NP");
      when(resultSet.getString("TECH_NAAM")).thenReturn("OVERLEDEN_NPE_UITSLUITEN");
      when(resultSet.getString("VALUE")).thenReturn("J");

      SelectionCriteriaRowMapper selectionCriteriaRowMapper = new SelectionCriteriaRowMapper();

      SelectionCriteria selectionCriteria = selectionCriteriaRowMapper.mapRow(resultSet);

      assertThat(selectionCriteria.getLevCode()).isEqualTo("CWS-NP");
      assertThat(selectionCriteria.getFilterMap().get(CwsNpFilterType.OVERLEDEN_NPE_UITSLUITEN)).isEqualTo("J");
   }

   @Test
   @DisplayName("Should map the resultset fields to CWS-HR SelectionCriteria and filtermap contains BEEINDIGD_ADRES_UITSLUITEN")
   void testMapRowSelectionCriteriaBeeindigdAdresUitsluiten() throws SQLException {
      when(resultSet.getString("LEV_CD")).thenReturn("CWS-HR");
      when(resultSet.getString("TECH_NAAM")).thenReturn("BEEINDIGD_ADRES_UITSLUITEN");
      when(resultSet.getString("VALUE")).thenReturn("J");

      SelectionCriteriaRowMapper selectionCriteriaRowMapper = new SelectionCriteriaRowMapper();

      SelectionCriteria selectionCriteria = selectionCriteriaRowMapper.mapRow(resultSet);

      assertThat(selectionCriteria.getLevCode()).isEqualTo("CWS-HR");
      assertThat(selectionCriteria.getFilterMap().get(CwsHrFilterType.BEEINDIGD_ADRES_UITSLUITEN)).isEqualTo("J");
   }
}
