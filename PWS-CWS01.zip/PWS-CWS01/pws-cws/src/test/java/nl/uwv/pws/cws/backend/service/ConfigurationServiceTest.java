package nl.uwv.pws.cws.backend.service;

import nl.uwv.pws.cws.backend.dao.CwsConfigurationDao;
import nl.uwv.pws.cws.model.CwsConfiguration;
import nl.uwv.pws.cws.model.CwsMetaCol;
import nl.uwv.pws.cws.model.SelectionCriteria;
import nl.uwv.pws.cws.util.ConfigurationStatus;
import org.junit.jupiter.api.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import java.io.IOException;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.TestInstance.Lifecycle.PER_CLASS;
import static org.mockito.Mockito.*;

@TestInstance(PER_CLASS)
public class ConfigurationServiceTest {

   private ConfigurationService configurationService;
   private MockedStatic<CwsConfigurationDao> cwsConfigurationDaoMockedStatic;
   private CwsConfigurationDao cwsConfigurationDao;

   @BeforeAll
   public void setup() throws IOException {
      this.cwsConfigurationDaoMockedStatic = Mockito.mockStatic(CwsConfigurationDao.class);
      this.cwsConfigurationDao = mock(CwsConfigurationDao.class);

      cwsConfigurationDaoMockedStatic.when(CwsConfigurationDao::getInstance).thenReturn(cwsConfigurationDao);
      configurationService = new ConfigurationService();
   }

   @AfterAll
   public void cleanup(){
      cwsConfigurationDaoMockedStatic.close();
   }

   @Test
   @DisplayName("Should successfully finalize a configuration")
   void testConfirmFinalizeConfiguration() {
      CwsConfiguration cwsConfiguration = createCwsConfiguration();

      SelectionCriteria selectionCriteriaDummy = new SelectionCriteria("CWS-HR");
      when(cwsConfigurationDao.selectSelectionCriteriaByConfigId(999999L)).thenReturn(selectionCriteriaDummy);

      CwsMetaCol cwsMetaCol = CwsMetaCol.builder().metaColId(4000L).build();
      List<CwsMetaCol> cwsMetaColListDummy = new ArrayList<>();
      cwsMetaColListDummy.add(cwsMetaCol);
      when(cwsConfigurationDao.selectConfigurationMetaData(999999L)).thenReturn(cwsMetaColListDummy);

      final Timestamp timestamp = Timestamp.valueOf(LocalDateTime.of(2021,9,1,12,23,10));
      when(cwsConfigurationDao.deleteConfiguration(999999L)).thenReturn(timestamp);
      when(cwsConfigurationDao.saveCwsConfiguratie(cwsConfiguration)).thenReturn(30000L);

      configurationService.confirmFinalizeConfiguration(cwsConfiguration);

      verify(this.cwsConfigurationDao, times(1)).selectSelectionCriteriaByConfigId(cwsConfiguration.getConfigurationId());
      verify(this.cwsConfigurationDao, times(1)).selectConfigurationMetaData(cwsConfiguration.getConfigurationId());
      verify(this.cwsConfigurationDao, times(1)).deleteConfiguration(cwsConfiguration.getConfigurationId());
      assertThat(cwsConfiguration.getRegistrationStartDateTime()).isEqualTo(timestamp.toLocalDateTime());
      assertThat(cwsConfiguration.getConfigurationStatus()).isEqualTo(ConfigurationStatus.DE.name());
      verify(this.cwsConfigurationDao, times(1)).saveCwsConfiguratie(cwsConfiguration);
      verify(this.cwsConfigurationDao, times(1)).saveSelectionCriteria(30000L, timestamp.toLocalDateTime(), selectionCriteriaDummy);

      Set<Long> testSet = new HashSet<>();
      testSet.add(4000L); //MetaColId from CwsMetaCol above
      verify(this.cwsConfigurationDao, times(1)).saveConfigurationAttributes(30000L, timestamp.toLocalDateTime(), testSet);
   }

   @Test
   @DisplayName("Should successfully delete a configuration")
   void testDeleteConfiguration() {
      configurationService.confirmDeleteConfiguration(30000L);
      verify(this.cwsConfigurationDao, times(1)).deleteConfiguration(30000L);
   }

   private CwsConfiguration createCwsConfiguration(){
      return CwsConfiguration.builder()
            .configurationId(999999L)
            .contractId(455062L)
            .leverCode("CWS-HR")
            .berichtVersie("0105")
            .configurationName("config-test-export-import")
            .configurationStatus("CO")
            .configurationVersion(10L)
            .contractStartDate(LocalDate.of(2020, 11, 2))
            .configurationStartDate(LocalDate.of(2021, 8, 31))
            .afnemerCode("CWSFAT")
            .afnemerNaam("NAAM AFNEMER CWSFAT")
            .build();
   }
}
