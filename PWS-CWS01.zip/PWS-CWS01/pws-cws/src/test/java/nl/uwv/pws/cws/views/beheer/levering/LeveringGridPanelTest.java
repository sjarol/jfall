package nl.uwv.pws.cws.views.beheer.levering;

import com.vaadin.flow.component.AbstractField;
import com.vaadin.flow.component.HasValue;
import com.vaadin.flow.component.HasValue.ValueChangeListener;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.data.selection.SelectionListener;
import nl.uwv.pws.backend.types.ColumnList;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import test.common.SqlFilterAbstractArgumentMatcher;

import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.*;

public class LeveringGridPanelTest {

   private LeveringGridPanel spyLeveringGridPanel;

   @BeforeEach
   public void setup(){
      ValueChangeListener<AbstractField.ComponentValueChangeEvent<Grid<ColumnList>, ColumnList>> valueChangeListener = mock(ValueChangeListener.class);
      spyLeveringGridPanel = spy(new LeveringGridPanel(valueChangeListener));
   }

   @Test
   @DisplayName("Given a call to findAlleLeveringen, should use the related filter")
   void testFindContractsByContractId() {
      spyLeveringGridPanel.findAlleLeveringen();

      verify(spyLeveringGridPanel).search(argThat(new SqlFilterAbstractArgumentMatcher(new LeveringFilter())));
   }
}
