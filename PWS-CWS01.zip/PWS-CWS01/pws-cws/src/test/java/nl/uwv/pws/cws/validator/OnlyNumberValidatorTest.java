package nl.uwv.pws.cws.validator;

import com.vaadin.flow.data.binder.ValidationResult;
import com.vaadin.flow.data.binder.ValueContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static com.vaadin.flow.data.binder.ErrorLevel.ERROR;
import static org.assertj.core.api.Assertions.assertThat;

public class OnlyNumberValidatorTest {

   private OnlyNumberValidator onlyNumberValidator;

   @BeforeEach
   public void setup(){
      onlyNumberValidator = new OnlyNumberValidator("Contract Id mag alleen cijfers bevatten");
   }

   @Test
   @DisplayName("Validation fails when an unparsable number was passed in")
   public void validateOnNumberFails() {
      ValidationResult result = onlyNumberValidator.apply("INVALID_VAL", new ValueContext());
      assertThat(result).isNotNull();
      assertThat(result.isError()).isTrue();
      assertThat(result.getErrorLevel()).hasValue(ERROR);
      assertThat(result.getErrorMessage()).isEqualTo("Contract Id mag alleen cijfers bevatten");
   }


   @Test
   @DisplayName("Validatie succeeds when argument is a valid number")
   public void validateOnNumberSucceeds() {
      ValidationResult result = onlyNumberValidator.apply("123", new ValueContext());
      assertThat(result).isNotNull();
      assertThat(result.isError()).isFalse();
   }
}
