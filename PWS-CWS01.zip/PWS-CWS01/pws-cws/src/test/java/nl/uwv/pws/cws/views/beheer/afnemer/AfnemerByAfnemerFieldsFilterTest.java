package nl.uwv.pws.cws.views.beheer.afnemer;

import nl.uwv.pws.cws.model.SearchCriteria;
import nl.uwv.pws.cws.views.AfnemersSearchBar;
import nl.uwv.pws.cws.views.beheer.tabs.events.AfnemersSearchEvent;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

class AfnemerByAfnemerFieldsFilterTest {

   private AfnemersSearchBar afnemersSearchBar;
   private SearchCriteria searchCriteria;

   @BeforeEach
   public void setup(){
      searchCriteria = new SearchCriteria();
      afnemersSearchBar = mock(AfnemersSearchBar.class);
   }

   @Test
   @DisplayName("Given all search criteria is null, return only afnemers having AFN_CD filled")
   void testAllFieldNull() {
      AfnemersSearchEvent afnemersSearchEvent = new AfnemersSearchEvent(afnemersSearchBar, false, searchCriteria);
      AfnemerByAfnemerFieldsFilter filter = new AfnemerByAfnemerFieldsFilter(afnemersSearchEvent);

      assertThat(filter.getFilterSql()).isEqualToIgnoringCase("(AFN_CD IS NOT NULL)");
      assertThat(filter.getParametersSize()).isEqualTo(0);
   }

   @Test
   @DisplayName("Given only afnemer code filled, return correct WHERE clause")
   void testWithAfnemerCode() {
      searchCriteria.setAfnemerCode("afn_code");
      AfnemersSearchEvent afnemersSearchEvent = new AfnemersSearchEvent(afnemersSearchBar, false, searchCriteria);
      AfnemerByAfnemerFieldsFilter filter = new AfnemerByAfnemerFieldsFilter(afnemersSearchEvent);

      assertThat(filter.getFilterSql()).isEqualToIgnoringCase("(UPPER(AFN_CD) LIKE '%'||?||'%')");
      assertThat(filter.getParametersSize()).isEqualTo(1);
      assertThat(filter.getParameter(0)).isEqualTo("AFN_CODE");
   }

   @Test
   @DisplayName("Given only afnemer code filled, return correct WHERE clause")
   void testWithAfnemerCodeAsArgument() {
      AfnemerByAfnemerFieldsFilter filter = new AfnemerByAfnemerFieldsFilter("afn_code");

      assertThat(filter.getFilterSql()).isEqualToIgnoringCase("(UPPER(AFN_CD) = ?)");
      assertThat(filter.getParametersSize()).isEqualTo(1);
      assertThat(filter.getParameter(0)).isEqualTo("AFN_CODE");
   }

   @Test
   @DisplayName("Given no argument (only default constructor), return correct WHERE clause")
   void testWithNoArgument() {
      AfnemerByAfnemerFieldsFilter filter = new AfnemerByAfnemerFieldsFilter();

      assertThat(filter.getFilterSql()).isEqualTo("1 = 1");
      assertThat(filter.getParametersSize()).isEqualTo(0);
   }

   @Test
   @DisplayName("Given only afnemer naam filled, return correct WHERE clause")
   void testWithAfnemerNaam() {
      searchCriteria.setAfnemerNaam("afn_naam");
      AfnemersSearchEvent afnemersSearchEvent = new AfnemersSearchEvent(afnemersSearchBar, false, searchCriteria);
      AfnemerByAfnemerFieldsFilter filter = new AfnemerByAfnemerFieldsFilter(afnemersSearchEvent);

      assertThat(filter.getFilterSql()).isEqualToIgnoringCase("(UPPER(NAAM) LIKE '%'||?||'%')");
      assertThat(filter.getParametersSize()).isEqualTo(1);
      assertThat(filter.getParameter(0)).isEqualTo("AFN_NAAM");
   }

   @Test
   @DisplayName("Given only ugc id filled, return correct WHERE clause")
   void testWithUgcId() {
      searchCriteria.setUgcId("123456");
      AfnemersSearchEvent afnemersSearchEvent = new AfnemersSearchEvent(afnemersSearchBar, false, searchCriteria);
      AfnemerByAfnemerFieldsFilter filter = new AfnemerByAfnemerFieldsFilter(afnemersSearchEvent);

      assertThat(filter.getFilterSql()).isEqualToIgnoringCase("(TO_CHAR(UGC_ID) LIKE '%'||?||'%')");
      assertThat(filter.getParametersSize()).isEqualTo(1);
      assertThat(filter.getParameter(0)).isEqualTo("123456");
   }

   @Test
   @DisplayName("Given afnemer code AND afnemenr naam filled, return correct WHERE clause")
   void testWithAfnemerCodeAndAfnemerNaam() {
      searchCriteria.setAfnemerCode("afn_code");
      searchCriteria.setAfnemerNaam("afnnaam");
      AfnemersSearchEvent afnemersSearchEvent = new AfnemersSearchEvent(afnemersSearchBar, false, searchCriteria);
      AfnemerByAfnemerFieldsFilter filter = new AfnemerByAfnemerFieldsFilter(afnemersSearchEvent);

      assertThat(filter.getFilterSql()).isEqualTo("(UPPER(AFN_CD) LIKE '%'||?||'%' AND UPPER(NAAM) LIKE '%'||?||'%')");
      assertThat(filter.getParametersSize()).isEqualTo(2);
      assertThat(filter.getParameter(0)).isEqualToIgnoringCase("AFN_CODE");
      assertThat(filter.getParameter(1)).isEqualToIgnoringCase("AFNNAAM");
   }

   @Test
   @DisplayName("Given afnemer code AND ugc id filled, return correct WHERE clause")
   void testWithAfnemerCodeAndUgcId() {
      searchCriteria.setUgcId("123456");
      searchCriteria.setAfnemerCode("afn_code");
      AfnemersSearchEvent afnemersSearchEvent = new AfnemersSearchEvent(afnemersSearchBar, false, searchCriteria);
      AfnemerByAfnemerFieldsFilter filter = new AfnemerByAfnemerFieldsFilter(afnemersSearchEvent);

      assertThat(filter.getFilterSql()).isEqualTo("(UPPER(AFN_CD) LIKE '%'||?||'%' AND TO_CHAR(UGC_ID) LIKE '%'||?||'%')");
      assertThat(filter.getParametersSize()).isEqualTo(2);
      assertThat(filter.getParameter(0)).isEqualToIgnoringCase("AFN_CODE");
      assertThat(filter.getParameter(1)).isEqualTo("123456");
   }

   @Test
   @DisplayName("Given all search criteria filled, return correct WHERE clause")
   void testWithAfnemerCodeAfnemerNaamAndUgcId() {
      searchCriteria.setUgcId("123456");
      searchCriteria.setAfnemerCode("afn_code");
      searchCriteria.setAfnemerNaam("afnnaam");
      AfnemersSearchEvent afnemersSearchEvent = new AfnemersSearchEvent(afnemersSearchBar, false, searchCriteria);
      AfnemerByAfnemerFieldsFilter filter = new AfnemerByAfnemerFieldsFilter(afnemersSearchEvent);

      assertThat(filter.getFilterSql()).isEqualTo("(UPPER(AFN_CD) LIKE '%'||?||'%' AND UPPER(NAAM) LIKE '%'||?||'%' AND TO_CHAR(UGC_ID) LIKE '%'||?||'%')");
      assertThat(filter.getParametersSize()).isEqualTo(3);
      assertThat(filter.getParameter(0)).isEqualToIgnoringCase("AFN_CODE");
      assertThat(filter.getParameter(1)).isEqualToIgnoringCase("AFNNAAM");
      assertThat(filter.getParameter(2)).isEqualTo("123456");
   }
}
