package nl.uwv.pws.cws.backend.service;

import nl.uwv.pws.cws.backend.dao.CwsConfigurationDao;
import org.junit.jupiter.api.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import java.io.IOException;
import java.util.Properties;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.TestInstance.Lifecycle.PER_CLASS;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@TestInstance(PER_CLASS)
public class AppiConfigServiceTest {

   private AppiConfigService appiConfigService;
   private MockedStatic<CwsConfigurationDao> cwsConfigurationDaoMockedStatic;
   private CwsConfigurationDao cwsConfigurationDao;

   @BeforeAll
   public void setup() throws IOException {
      this.cwsConfigurationDaoMockedStatic = Mockito.mockStatic(CwsConfigurationDao.class);
      this.cwsConfigurationDao = mock(CwsConfigurationDao.class);

      cwsConfigurationDaoMockedStatic.when(CwsConfigurationDao::getInstance).thenReturn(cwsConfigurationDao);
      appiConfigService = new AppiConfigService();
   }

   @AfterAll
   public void cleanup(){
      cwsConfigurationDaoMockedStatic.close();
   }

   @Test
   @DisplayName("Should successfully initialize application properties")
   void testConfirmInitializeApplication() {
      final int dummyApiId = 5000;
      when(cwsConfigurationDao.getAppiId(anyString(), anyString(), anyString(), anyString())).thenReturn(dummyApiId);

      Properties properties = new Properties();
      properties.put("pws09.kenmerk", "FAT");
      when(cwsConfigurationDao.getAppiConfig(dummyApiId)).thenReturn(properties);

      appiConfigService.initialize();

      assertThat(appiConfigService.contains("pws09.kenmerk")).isTrue();
      assertThat(appiConfigService.getValue("pws09.kenmerk")).isEqualTo("FAT");
      assertThat(appiConfigService.getValue("undefined")).isNull();
   }
}
