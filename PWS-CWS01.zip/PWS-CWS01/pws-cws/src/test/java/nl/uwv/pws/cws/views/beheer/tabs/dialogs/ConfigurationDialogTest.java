package nl.uwv.pws.cws.views.beheer.tabs.dialogs;

import com.vaadin.flow.component.AbstractField;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.datepicker.DatePicker;
import com.vaadin.flow.component.formlayout.FormLayout;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.provider.hierarchy.HierarchicalDataProvider;
import nl.uwv.pws.cws.backend.dao.CwsConfigurationDao;
import nl.uwv.pws.cws.model.CwsConfiguration;
import nl.uwv.pws.cws.model.CwsLaFilterType;
import nl.uwv.pws.cws.model.CwsMetaCol;
import nl.uwv.pws.cws.model.SelectionCriteria;
import nl.uwv.pws.cws.util.CwsUIUtils;
import nl.uwv.pws.cws.util.Validator;
import nl.uwv.pws.cws.views.beheer.configuratie.ConfigurationAction;
import nl.uwv.pws.cws.views.beheer.tabs.dialogs.ConfigurationDialog;
import nl.uwv.pws.cws.views.beheer.tabs.layout.BaseSelectionCriteriaFormLayout;
import nl.uwv.pws.cws.views.beheer.tabs.layout.ConfigurationFormLayoutHelper;
import nl.uwv.pws.cws.views.beheer.tabs.layout.cwsla.CwsLaSelectionCriteriaLayout;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.MockedStatic;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

import static nl.uwv.pws.cws.util.Constants.*;
import static nl.uwv.pws.cws.util.CwsUIUtils.createCheckbox;
import static nl.uwv.pws.cws.util.CwsUIUtils.createTextField;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

@SuppressWarnings("ALL")
public class ConfigurationDialogTest {

   private ConfigurationDialog configurationDialog;

   @BeforeEach
   public void setup() {
      configurationDialog = new ConfigurationDialog(null);
   }

   @Test
   @DisplayName("ConfigureDialog handels Add configuration")
   void testConfigureDialogAddConfiguration() {
      CwsConfigurationDao cwsConfigurationDao = mock(CwsConfigurationDao.class);
      when(cwsConfigurationDao.getMaxBerichtVersie("CWS-LA")).thenReturn("105");

      Map<Long, CwsMetaCol> metaColMap = new HashMap<>();
      CwsMetaCol cwsMetaCol = mock(CwsMetaCol.class);
      metaColMap.put(1L, cwsMetaCol);

      when(cwsConfigurationDao.getMetaDataByLeverCodeAndVersie("CWS-LA", "105")).thenReturn(metaColMap);
      configurationDialog.setCwsConfigurationDao(cwsConfigurationDao);

      ConfigurationFormLayoutHelper layoutHelper = mock(ConfigurationFormLayoutHelper.class);
      FormLayout formLayout = new FormLayout();
      when(layoutHelper.createAddConfigurationLayout(any(CwsConfiguration.class), any(com.vaadin.flow.data.binder.Binder.class), anyString())).thenReturn(formLayout);
      configurationDialog.setConfigurationFormLayoutHelper(layoutHelper);

      CwsConfiguration cwsConfiguration = CwsConfiguration.builder()
            .leverCode("CWS-LA")
            .build();
      configurationDialog.configureDialog(cwsConfiguration, ConfigurationAction.ADD);

      assertThat(formLayout.getWidth()).isEqualTo("50%");
      assertThat(configurationDialog.getErrorLabel()).isNotNull();
      assertThat(configurationDialog.getErrorLabel().getId().get()).isEqualTo("overzicht-cws-configuratie-editor-layout-form-error");
      assertThat(configurationDialog.getErrorLabel().getWidth()).isEqualTo("100%");
      assertThat(configurationDialog.getCwsMetaColTreeGrid()).isNotNull();
      assertThat(configurationDialog.getCwsMetaColTreeGrid().getId().get()).isEqualTo("cws-tree-grid");
   }

   @Test
   @DisplayName("ConfigureDialog handels Modify configuration")
   void testConfigureDialogModifyConfiguration(){
      CwsConfiguration selectedCwsConfiguration = CwsConfiguration.builder()
            .berichtVersie("105")
            .configurationStatus("CO")
            .configurationName("test configname")
            .configurationId(123L)
            .configurationStartDate(LocalDate.of(2021, 6, 5))
            .configurationEndDate(LocalDate.of(2021, 7, 1))
            .registrationStartDateTime(LocalDateTime.of(2021, 7, 1, 11,30))
            .leverCode("CWS-LA")
            .build();
      CwsConfigurationDao cwsConfigurationDao = mock(CwsConfigurationDao.class);
      when(cwsConfigurationDao.getConfigurationByContractAndConfigVersion(123L, 20210601L, 105L)).thenReturn(selectedCwsConfiguration);

      List<Long> selectedAttributes = new ArrayList<>();
      selectedAttributes.add(978L);
      when(cwsConfigurationDao.selectCheckedMetadataAttributes(123L)).thenReturn(selectedAttributes);
      Map<Long, CwsMetaCol> metaColMap = new HashMap<>();
      CwsMetaCol cwsMetaCol = CwsMetaCol.builder().metaColId(978L).build();
      metaColMap.put(1L, cwsMetaCol);

      when(cwsConfigurationDao.getMetaDataByLeverCodeAndVersie("CWS-LA", "105")).thenReturn(metaColMap);
      configurationDialog.setCwsConfigurationDao(cwsConfigurationDao);

      ConfigurationFormLayoutHelper layoutHelper = mock(ConfigurationFormLayoutHelper.class);
      FormLayout formLayout = new FormLayout();
      when(layoutHelper.createModifyAndViewConfigurationLayout(any(CwsConfiguration.class), any(com.vaadin.flow.data.binder.Binder.class), any(ConfigurationAction.class))).thenReturn(formLayout);
      configurationDialog.setConfigurationFormLayoutHelper(layoutHelper);

      CwsConfiguration cwsConfiguration = CwsConfiguration.builder()
            .leverCode("CWS-LA")
            .contractId(123L)
            .contractStartDate(LocalDate.of(2021, 6, 1))
            .configurationVersion(105L)
            .configurationId(123L)
            .build();
      configurationDialog.configureDialog(cwsConfiguration, ConfigurationAction.MODIFY);

      assertThat(configurationDialog.getCwsConfiguration().getBerichtVersie()).isEqualTo("105");
      assertThat(configurationDialog.getCwsConfiguration().getConfigurationStatus()).isEqualTo("CO");
      assertThat(configurationDialog.getCwsConfiguration().getConfigurationName()).isEqualTo("test configname");
      assertThat(configurationDialog.getCwsConfiguration().getConfigurationStartDate()).isEqualTo(LocalDate.of(2021, 6, 5));
      assertThat(configurationDialog.getCwsConfiguration().getConfigurationEndDate()).isEqualTo(LocalDate.of(2021, 7, 1));
      assertThat(configurationDialog.getCwsConfiguration().getRegistrationStartDateTime()).isEqualTo(LocalDateTime.of(2021, 7, 1, 11,30));
      assertThat(configurationDialog.getSelectedConfigurationStartDate()).isEqualTo(LocalDate.of(2021, 6, 5));

      assertThat(cwsMetaCol.isChecked()).isTrue();

      assertThat(formLayout.getWidth()).isEqualTo("50%");
      assertThat(configurationDialog.getErrorLabel()).isNotNull();
      assertThat(configurationDialog.getErrorLabel().getId().get()).isEqualTo("overzicht-cws-configuratie-editor-layout-form-error");
      assertThat(configurationDialog.getErrorLabel().getWidth()).isEqualTo("100%");
      assertThat(configurationDialog.getCwsMetaColTreeGrid()).isNotNull();
      assertThat(configurationDialog.getCwsMetaColTreeGrid().getId().get()).isEqualTo("cws-tree-grid");
   }


   @Test
   @DisplayName("ConfigureDialog handels View configuration")
   void testConfigureDialogViewConfiguration(){
      CwsConfiguration selectedCwsConfiguration = CwsConfiguration.builder()
            .berichtVersie("105")
            .configurationStatus("DE")
            .configurationName("test configname")
            .configurationId(123L)
            .configurationStartDate(LocalDate.of(2021, 6, 5))
            .configurationEndDate(LocalDate.of(2021, 7, 1))
            .registrationStartDateTime(LocalDateTime.of(2021, 7, 1, 11,30))
            .leverCode("CWS-LA")
            .build();
      CwsConfigurationDao cwsConfigurationDao = mock(CwsConfigurationDao.class);
      when(cwsConfigurationDao.getConfigurationByContractAndConfigVersion(123L, 20210601L, 105L)).thenReturn(selectedCwsConfiguration);

      List<Long> selectedAttributes = new ArrayList<>();
      selectedAttributes.add(978L);
      when(cwsConfigurationDao.selectCheckedMetadataAttributes(123L)).thenReturn(selectedAttributes);
      Map<Long, CwsMetaCol> metaColMap = new HashMap<>();
      CwsMetaCol cwsMetaCol = CwsMetaCol.builder()
            .metaColId(978L)
            .enabled(true)
            .checked(false)
            .build();
      metaColMap.put(1L, cwsMetaCol);

      when(cwsConfigurationDao.getMetaDataByLeverCodeAndVersie("CWS-LA", "105")).thenReturn(metaColMap);
      configurationDialog.setCwsConfigurationDao(cwsConfigurationDao);

      ConfigurationFormLayoutHelper layoutHelper = mock(ConfigurationFormLayoutHelper.class);
      FormLayout formLayout = new FormLayout();
      when(layoutHelper.createModifyAndViewConfigurationLayout(any(CwsConfiguration.class), any(com.vaadin.flow.data.binder.Binder.class), any(ConfigurationAction.class))).thenReturn(formLayout);
      configurationDialog.setConfigurationFormLayoutHelper(layoutHelper);

      CwsConfiguration cwsConfiguration = CwsConfiguration.builder()
            .leverCode("CWS-LA")
            .contractId(123L)
            .contractStartDate(LocalDate.of(2021, 6, 1))
            .configurationVersion(105L)
            .configurationId(123L)
            .build();
      configurationDialog.configureDialog(cwsConfiguration, ConfigurationAction.MODIFY);

      assertThat(configurationDialog.getCwsConfiguration().getBerichtVersie()).isEqualTo("105");
      assertThat(configurationDialog.getCwsConfiguration().getConfigurationStatus()).isEqualTo("DE");
      assertThat(configurationDialog.getCwsConfiguration().getConfigurationName()).isEqualTo("test configname");
      assertThat(configurationDialog.getCwsConfiguration().getConfigurationStartDate()).isEqualTo(LocalDate.of(2021, 6, 5));
      assertThat(configurationDialog.getCwsConfiguration().getConfigurationEndDate()).isEqualTo(LocalDate.of(2021, 7, 1));
      assertThat(configurationDialog.getCwsConfiguration().getRegistrationStartDateTime()).isEqualTo(LocalDateTime.of(2021, 7, 1, 11,30));
      assertThat(configurationDialog.getSelectedConfigurationStartDate()).isEqualTo(LocalDate.of(2021, 6, 5));
      //TODO
      assertThat(cwsMetaCol.isChecked()).isTrue();
      assertThat(cwsMetaCol.isEnabled()).isFalse();

      assertThat(formLayout.getWidth()).isEqualTo("50%");
      assertThat(configurationDialog.getErrorLabel()).isNotNull();
      assertThat(configurationDialog.getErrorLabel().getId().get()).isEqualTo("overzicht-cws-configuratie-editor-layout-form-error");
      assertThat(configurationDialog.getErrorLabel().getWidth()).isEqualTo("100%");
      assertThat(configurationDialog.getCwsMetaColTreeGrid()).isNotNull();
      assertThat(configurationDialog.getCwsMetaColTreeGrid().getId().get()).isEqualTo("cws-tree-grid");
   }

   @Test
   @DisplayName("when checkbox value changes cwsMetaCol should update it's context")
   void testCheckboxSelected(){
      AbstractField.ComponentValueChangeEvent componentValueChangeEvent = mock(AbstractField.ComponentValueChangeEvent.class);
      CwsMetaCol cwsMetaCol = mock(CwsMetaCol.class);
      HierarchicalDataProvider dataProvider = mock(HierarchicalDataProvider.class);
      when(componentValueChangeEvent.getValue()).thenReturn(Boolean.TRUE);

      configurationDialog.checkboxSelected(componentValueChangeEvent, cwsMetaCol, dataProvider);

      verify(cwsMetaCol, times(1)).updateDescendants(Boolean.TRUE);
      verify(cwsMetaCol, times(1)).setChecked(Boolean.TRUE);
      verify(dataProvider, times(1)).refreshItem(cwsMetaCol);
      verify(cwsMetaCol, times(1)).updateAscendants(Boolean.TRUE);
   }

   @Test
   @DisplayName("Should save data correctly for Add configuration")
   void testOpslaanForAddConfiguration(){

      CwsConfiguration cwsConfiguration = CwsConfiguration.builder()
            .leverCode("CWS-LA")
            .contractId(123L)
            .contractStartDate(LocalDate.of(2021, 6, 1))
            .contractEndDate(LocalDate.of(2026, 6, 1))
            .configurationVersion(105L)
            .configurationId(123L)
            .build();
      configurationDialog.setCwsConfiguration(cwsConfiguration);
      configurationDialog.setConfigurationAction(ConfigurationAction.ADD);
      CwsLaSelectionCriteriaLayout cwsLaSelectionCriteriaLayoutHelper = new CwsLaSelectionCriteriaLayout();
      cwsLaSelectionCriteriaLayoutHelper.setTextFieldCodeSoortIkv(createTextField(COMPONENT_ID_CODESOORTIKVS_TEXT_FIELD, "12", true, 200));
      cwsLaSelectionCriteriaLayoutHelper.setTextFieldMaxLeverperiode(createTextField(COMPONENT_ID_MAXLEVERPERIODE_TEXT_FIELD, "999", true, 3));
      cwsLaSelectionCriteriaLayoutHelper.setCheckboxNihilLoonSvUitsluiten(createCheckbox(COMPONENT_ID_NIHILLOONSVUITSLUITEN_CHECKBOX, false, true));
      cwsLaSelectionCriteriaLayoutHelper.setCheckboxNihilLoonLbPhUitsluiten(createCheckbox(COMPONENT_ID_NIHILLOONLBPHUITSLUITEN_CHECKBOX, false, true));
      configurationDialog.setSelectionCriteriaLayoutHelper(cwsLaSelectionCriteriaLayoutHelper);

      try (MockedStatic<UI> uiStaticMock = mockStatic(UI.class);
           MockedStatic<CwsUIUtils> cwsUIUtilsStaticMock = mockStatic(CwsUIUtils.class)) {
         UI uiMock = mock(UI.class);
         uiStaticMock.when(UI::getCurrent).thenReturn(uiMock);
         when(uiMock.getLocale()).thenReturn(Locale.US);

         DatePicker datePicker = new DatePicker();
         FormLayout formLayoutMock = mock(FormLayout.class);
         cwsUIUtilsStaticMock.when(() -> CwsUIUtils.findComponent(COMPONENT_ID_CONFIGURATIEBEGINDATUM_TEXT_FIELD, formLayoutMock)).thenReturn(datePicker);
         cwsUIUtilsStaticMock.when(() -> CwsUIUtils.findComponent(COMPONENT_ID_CONFIGURATIEEINDDATUM_TEXT_FIELD, formLayoutMock)).thenReturn(datePicker);
         configurationDialog.setLayout(formLayoutMock);

         Map<Long, CwsMetaCol> metaColMap = new HashMap<>();
         CwsMetaCol cwsMetaCol1 = CwsMetaCol.builder()
               .metaColId(123L)
               .enabled(true)
               .checked(true)
               .build();
         CwsMetaCol cwsMetaCol2 = CwsMetaCol.builder()
               .metaColId(234L)
               .checked(true)
               .enabled(true)
               .build();
         CwsMetaCol cwsMetaCol3 = CwsMetaCol.builder()
               .metaColId(789L)
               .displayIcon(true)
               .enabled(true)
               .build();
         CwsMetaCol cwsMetaColMandatory = CwsMetaCol.builder()
               .metaColId(777L)
               .enabled(false)
               .displayIcon(true)
               .build();
         metaColMap.put(1L, cwsMetaCol1);
         metaColMap.put(2L, cwsMetaCol2);
         metaColMap.put(3L, cwsMetaCol3);
         metaColMap.put(4L, cwsMetaColMandatory);
         configurationDialog.setMetaColMap(metaColMap);
         assertThat(configurationDialog.getCurrentSelectedMetaColIdsExcludeMandatory().size()).isEqualTo(3);
         assertThat(configurationDialog.getCurrentSelectedMetaColIdsIncludeMandatory().size()).isEqualTo(4);

         Validator validator = mock(Validator.class);
         configurationDialog.setValidator(validator);

         CwsConfigurationDao cwsConfigurationDao = mock(CwsConfigurationDao.class);
         when(cwsConfigurationDao.getSystimestamp()).thenReturn(Timestamp.valueOf(LocalDateTime.of(2021,6,1,18,00)));
         when(cwsConfigurationDao.saveCwsConfiguratie(any(CwsConfiguration.class))).thenReturn(888L);

         BaseSelectionCriteriaFormLayout selectionCriteriaFormLayoutHelper = mock(BaseSelectionCriteriaFormLayout.class);

         ArgumentCaptor<Long> configurationIdMessageCaptor = ArgumentCaptor.forClass(Long.class);
         ArgumentCaptor<LocalDateTime> configurationRegisterDateMessageCaptor = ArgumentCaptor.forClass(LocalDateTime.class);
         ArgumentCaptor<Set> selectedIdsMessageCaptor = ArgumentCaptor.forClass(Set.class);
         ArgumentCaptor<SelectionCriteria> selectionCriteriaMessageCaptor = ArgumentCaptor.forClass(SelectionCriteria.class);
         doNothing().when(cwsConfigurationDao).saveConfigurationAttributes(configurationIdMessageCaptor.capture(), configurationRegisterDateMessageCaptor.capture(), selectedIdsMessageCaptor.capture());
         when(selectionCriteriaFormLayoutHelper.determineSelectionCriteria()).thenReturn(new SelectionCriteria("CWS-LA"));
         doNothing().when(cwsConfigurationDao).saveSelectionCriteria(configurationIdMessageCaptor.capture(), configurationRegisterDateMessageCaptor.capture(), selectionCriteriaMessageCaptor.capture());
         configurationDialog.setCwsConfigurationDao(cwsConfigurationDao);

         configurationDialog.validateAndSave();

         Long configurationId = configurationIdMessageCaptor.getValue();
         LocalDateTime configurationRegisterDate = configurationRegisterDateMessageCaptor.getValue();
         Set<Long> selectedIds = selectedIdsMessageCaptor.getValue();
         assertThat(configurationId).isEqualTo(888);
         assertThat(configurationRegisterDate).isEqualTo(LocalDateTime.of(2021,6,1,18,00));
         assertThat(selectedIds.size()).isEqualTo(4);
         SelectionCriteria selectionCriteria = selectionCriteriaMessageCaptor.getValue();
         assertThat(selectionCriteria.getLevCode()).isEqualTo("CWS-LA");
         assertThat(selectionCriteria.getFilterMap().get(CwsLaFilterType.MAX_LEVERPERIODE)).isEqualTo("999");
      }
   }

   @Test
   @DisplayName("Should save data correctly for Modify or View configuration")
   void testOpslaanForModifyAndViewConfiguration() {
      CwsConfiguration cwsConfiguration = CwsConfiguration.builder()
            .contractStartDate(LocalDate.of(2021, 6, 1))
            .contractEndDate(LocalDate.of(2026, 6, 1))
            .configurationStartDate(LocalDate.of(2021, 6, 2))
            .configurationEndDate(LocalDate.of(2025,7,2))
            .configurationName("aValueForConfigName")
            .configurationId(888L)
            .build();
      configurationDialog.setCwsConfiguration(cwsConfiguration);
      configurationDialog.setConfigurationAction(ConfigurationAction.MODIFY);
      CwsLaSelectionCriteriaLayout cwsLaSelectionCriteriaLayoutHelper = new CwsLaSelectionCriteriaLayout();
      cwsLaSelectionCriteriaLayoutHelper.setTextFieldCodeSoortIkv(createTextField(COMPONENT_ID_CODESOORTIKVS_TEXT_FIELD, "12", true, 200));
      cwsLaSelectionCriteriaLayoutHelper.setTextFieldMaxLeverperiode(createTextField(COMPONENT_ID_MAXLEVERPERIODE_TEXT_FIELD, "999", true, 3));
      cwsLaSelectionCriteriaLayoutHelper.setCheckboxNihilLoonSvUitsluiten(createCheckbox(COMPONENT_ID_NIHILLOONSVUITSLUITEN_CHECKBOX, false, true));
      cwsLaSelectionCriteriaLayoutHelper.setCheckboxNihilLoonLbPhUitsluiten(createCheckbox(COMPONENT_ID_NIHILLOONLBPHUITSLUITEN_CHECKBOX, false, true));
      configurationDialog.setSelectionCriteriaLayoutHelper(cwsLaSelectionCriteriaLayoutHelper);

      try (MockedStatic<UI> uiStaticMock = mockStatic(UI.class);
           MockedStatic<CwsUIUtils> cwsUIUtilsStaticMock = mockStatic(CwsUIUtils.class)) {
         UI uiMock = mock(UI.class);
         uiStaticMock.when(UI::getCurrent).thenReturn(uiMock);
         when(uiMock.getLocale()).thenReturn(Locale.US);

         DatePicker fieldConfigurationBeginDate = new DatePicker();
         fieldConfigurationBeginDate.setValue(LocalDate.of(2021,6,1));
         DatePicker fieldConfigurationEndDate = new DatePicker();
         fieldConfigurationEndDate.setValue(LocalDate.of(2025,7,1));
         TextField fieldConfigurationNaam = new TextField();
         fieldConfigurationNaam.setValue("someOtherValueForConfigName");
         FormLayout formLayoutMock = mock(FormLayout.class);
         cwsUIUtilsStaticMock.when(() -> CwsUIUtils.findComponent(COMPONENT_ID_CONFIGURATIEBEGINDATUM_TEXT_FIELD, formLayoutMock)).thenReturn(fieldConfigurationBeginDate);
         cwsUIUtilsStaticMock.when(() -> CwsUIUtils.findComponent(COMPONENT_ID_CONFIGURATIEEINDDATUM_TEXT_FIELD, formLayoutMock)).thenReturn(fieldConfigurationEndDate);
         cwsUIUtilsStaticMock.when(() -> CwsUIUtils.findComponent(COMPONENT_ID_CONFIGURATIENAAM_TEXT_FIELD, formLayoutMock)).thenReturn(fieldConfigurationNaam);
         configurationDialog.setLayout(formLayoutMock);

         Map<Long, CwsMetaCol> metaColMap = new HashMap<>();
         CwsMetaCol cwsMetaCol1 = CwsMetaCol.builder()
               .metaColId(123L)
               .enabled(true)
               .checked(true)
               .build();
         CwsMetaCol cwsMetaCol2 = CwsMetaCol.builder()
               .metaColId(234L)
               .checked(true)
               .enabled(true)
               .build();
         CwsMetaCol cwsMetaCol3 = CwsMetaCol.builder()
               .metaColId(789L)
               .displayIcon(true)
               .enabled(true)
               .build();
         CwsMetaCol cwsMetaColMandatory = CwsMetaCol.builder()
               .metaColId(777L)
               .enabled(false)
               .displayIcon(true)
               .build();
         metaColMap.put(1L, cwsMetaCol1);
         metaColMap.put(2L, cwsMetaCol2);
         metaColMap.put(3L, cwsMetaCol3);
         metaColMap.put(4L, cwsMetaColMandatory);
         configurationDialog.setMetaColMap(metaColMap);
         assertThat(configurationDialog.getCurrentSelectedMetaColIdsExcludeMandatory().size()).isEqualTo(3);
         assertThat(configurationDialog.getCurrentSelectedMetaColIdsIncludeMandatory().size()).isEqualTo(4);

         Validator validator = mock(Validator.class);
         configurationDialog.setValidator(validator);

         CwsConfigurationDao cwsConfigurationDao = mock(CwsConfigurationDao.class);
         List<Long> selectedAttributes = Arrays.asList(1L,2L);
         when(cwsConfigurationDao.selectCheckedMetadataAttributes(888L)).thenReturn(selectedAttributes);
         when(cwsConfigurationDao.saveCwsConfiguratie(any(CwsConfiguration.class))).thenReturn(888L);
         when(cwsConfigurationDao.deleteConfiguration(888L)).thenReturn(Timestamp.valueOf(LocalDateTime.of(2021,6,1,18,00)));

         BaseSelectionCriteriaFormLayout selectionCriteriaFormLayoutHelper = mock(BaseSelectionCriteriaFormLayout.class);

         ArgumentCaptor<Long> configurationIdMessageCaptor = ArgumentCaptor.forClass(Long.class);
         ArgumentCaptor<LocalDateTime> configurationRegisterDateMessageCaptor = ArgumentCaptor.forClass(LocalDateTime.class);
         ArgumentCaptor<Set> selectedIdsMessageCaptor = ArgumentCaptor.forClass(Set.class);
         ArgumentCaptor<SelectionCriteria> selectionCriteriaMessageCaptor = ArgumentCaptor.forClass(SelectionCriteria.class);
         doNothing().when(cwsConfigurationDao).saveConfigurationAttributes(configurationIdMessageCaptor.capture(), configurationRegisterDateMessageCaptor.capture(), selectedIdsMessageCaptor.capture());
         when(selectionCriteriaFormLayoutHelper.determineSelectionCriteria()).thenReturn(new SelectionCriteria("CWS-LA"));
         doNothing().when(cwsConfigurationDao).saveSelectionCriteria(configurationIdMessageCaptor.capture(), configurationRegisterDateMessageCaptor.capture(), selectionCriteriaMessageCaptor.capture());
         configurationDialog.setCwsConfigurationDao(cwsConfigurationDao);

         configurationDialog.validateAndSave();

         assertThat(cwsConfiguration.getRegistrationStartDateTime()).isEqualTo(LocalDateTime.of(2021,6,1,18,00));
         assertThat(cwsConfiguration.getConfigurationName()).isEqualTo("someOtherValueForConfigName");
         assertThat(cwsConfiguration.getConfigurationStartDate()).isEqualTo(LocalDate.of(2021,6,1));
         assertThat(cwsConfiguration.getConfigurationEndDate()).isEqualTo(LocalDate.of(2025,7,1));

         Long configurationId = configurationIdMessageCaptor.getValue();
         LocalDateTime configurationRegisterDate = configurationRegisterDateMessageCaptor.getValue();
         Set<Long> selectedIds = selectedIdsMessageCaptor.getValue();
         assertThat(configurationId).isEqualTo(888);
         assertThat(configurationRegisterDate).isEqualTo(LocalDateTime.of(2021, 6, 1, 18, 00));
         assertThat(selectedIds.size()).isEqualTo(4);
         SelectionCriteria selectionCriteria = selectionCriteriaMessageCaptor.getValue();
         assertThat(selectionCriteria.getLevCode()).isEqualTo("CWS-LA");
         assertThat(selectionCriteria.getFilterMap().get(CwsLaFilterType.MAX_LEVERPERIODE)).isEqualTo("999");
      }
   }
}
