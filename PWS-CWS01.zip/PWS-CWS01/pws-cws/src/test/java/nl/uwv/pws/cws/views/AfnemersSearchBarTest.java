package nl.uwv.pws.cws.views;

import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.textfield.TextField;
import nl.uwv.pws.cws.views.beheer.tabs.events.AfnemersSearchEvent;
import nl.uwv.pws.cws.views.beheer.tabs.events.SearchAlleAfnemersEvent;
import nl.uwv.pws.cws.views.beheer.tabs.events.SearchAlleLeveringenEvent;
import nl.uwv.pws.cws.views.beheer.tabs.events.ValidationFailedEvent;
import nl.uwv.pws.ui.components.FlexBoxLayout;
import nl.uwv.pws.ui.components.ValidationLabel;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.concurrent.atomic.AtomicReference;

import static nl.uwv.pws.cws.util.Constants.*;
import static org.assertj.core.api.Assertions.assertThat;

public class AfnemersSearchBarTest {

   private AfnemersSearchBar afnemersSearchBar;

   private TextField ugcIdSearchField;
   private TextField contractIdSearchField;
   private TextField afnemerCodeSearchField;
   private TextField afnemerNaamSearchField;
   private Button searchButton;
   private Button alleAfnemersButton;
   private Button alleCwsLeveringenButton;
   private ValidationLabel validationLabel;

   public AfnemersSearchBarTest() {
      afnemersSearchBar = new AfnemersSearchBar();

      FlexBoxLayout searchLayout = (FlexBoxLayout) afnemersSearchBar.getChildren()
            .filter(child -> child instanceof FlexBoxLayout)
            .findFirst().orElse(null);
      assertThat(searchLayout).isNotNull();
      assertThat(searchLayout.getWidth()).isEqualTo("100%");

      ugcIdSearchField = findChild(COMPONENT_ID_UGCID_TEXT_FIELD, searchLayout);
      contractIdSearchField = findChild(COMPONENT_ID_CONTRACTID_TEXT_FIELD, searchLayout);
      afnemerCodeSearchField = findChild(COMPONENT_ID_AFNEMERCODE_TEXT_FIELD, searchLayout);
      afnemerNaamSearchField = findChild(COMPONENT_ID_AFNEMERNAAM_TEXT_FIELD, searchLayout);
      searchButton = findChild(COMPONENT_ID_ZOEKEN_BUTTON, searchLayout);
      alleAfnemersButton = findChild(COMPONENT_ID_ZOEKEN_CWS_AFNEMERS_BUTTON, searchLayout);
      alleCwsLeveringenButton = findChild(COMPONENT_ID_ZOEKEN_CWS_LEVERINGEN_BUTTON, searchLayout);

      validationLabel = findChild(ValidationLabel.NO_RESULTS_ID, afnemersSearchBar);

      assertThat(validationLabel.getText()).isEmpty();
      assertThat(validationLabel.isVisible()).isFalse();
   }

   @Test
   @DisplayName("Given search button clicked when no search field is filled, should result in validation event and an error message is shown")
   void testNoSearchArguments() {
      AtomicReference<Boolean> eventStorage = new AtomicReference<>(null);
      afnemersSearchBar.addListener(ValidationFailedEvent.class, event ->  eventStorage.set(true));
      searchButton.click();
      assertThat(eventStorage.get()).isNotNull();
      assertThat(eventStorage.get().booleanValue()).isTrue();

      // Validation message should be shown
      assertThat(validationLabel.getText()).isEqualTo("Een ingevuld zoekveld is verplicht");
      assertThat(validationLabel.isVisible()).isTrue();
   }

   @Test
   @DisplayName("Given search button clicked and afnemer code is filled, should result in a search event and no error message is shown")
   void testSearchByAfnemerCode() {
      AtomicReference<AfnemersSearchEvent> eventStorage = new AtomicReference<>(null);
      afnemersSearchBar.addListener(AfnemersSearchEvent.class, eventStorage::set);

      afnemerCodeSearchField.setValue("AFN_CODE");
      searchButton.click();

      assertThat(eventStorage.get()).isNotNull();
      AfnemersSearchEvent afnemersSearchEvent = eventStorage.get();

      assertThat(afnemersSearchEvent.getAfnemerCode()).isEqualTo("AFN_CODE");
      assertThat(afnemersSearchEvent.getAfnemerNaam()).isNull();
      assertThat(afnemersSearchEvent.getUgcId()).isNull();
      assertThat(afnemersSearchEvent.getContractId()).isNull();


      assertThat(validationLabel.getText()).isEmpty();
      assertThat(validationLabel.isVisible()).isFalse();
   }

   @Test
   @DisplayName("Given search button clicked and contract id is filled, should result in a search event and no error message is shown")
   void testSearchByContractId() {
      AtomicReference<AfnemersSearchEvent> eventStorage = new AtomicReference<>(null);
      afnemersSearchBar.addListener(AfnemersSearchEvent.class, eventStorage::set);

      contractIdSearchField.setValue("123456");
      searchButton.click();

      assertThat(eventStorage.get()).isNotNull();
      AfnemersSearchEvent afnemersSearchEvent = eventStorage.get();

      assertThat(afnemersSearchEvent.getAfnemerCode()).isNull();
      assertThat(afnemersSearchEvent.getAfnemerNaam()).isNull();
      assertThat(afnemersSearchEvent.getUgcId()).isNull();
      assertThat(afnemersSearchEvent.getContractId()).isEqualTo("123456");

      assertThat(validationLabel.getText()).isEmpty();
      assertThat(validationLabel.isVisible()).isFalse();
   }

   @Test
   @DisplayName("Given search button clicked and afnemer naam is filled, should result in a search event and no error message is shown")
   void testSearchByAfnemerNaam() {
      AtomicReference<AfnemersSearchEvent> eventStorage = new AtomicReference<>(null);
      afnemersSearchBar.addListener(AfnemersSearchEvent.class, eventStorage::set);

      afnemerNaamSearchField.setValue("AFN_NAAM");
      searchButton.click();

      assertThat(eventStorage.get()).isNotNull();
      AfnemersSearchEvent afnemersSearchEvent = eventStorage.get();

      assertThat(afnemersSearchEvent.getAfnemerCode()).isNull();
      assertThat(afnemersSearchEvent.getAfnemerNaam()).isEqualTo("AFN_NAAM");
      assertThat(afnemersSearchEvent.getUgcId()).isNull();
      assertThat(afnemersSearchEvent.getContractId()).isNull();

      assertThat(validationLabel.getText()).isEmpty();
      assertThat(validationLabel.isVisible()).isFalse();
   }

   @Test
   @DisplayName("Given search button clicked and UGC id filled, should result in a search event and no error message is shown")
   void testSearchByUgcId() {
      AtomicReference<AfnemersSearchEvent> eventStorage = new AtomicReference<>(null);
      afnemersSearchBar.addListener(AfnemersSearchEvent.class, eventStorage::set);

      ugcIdSearchField.setValue("123");
      searchButton.click();

      assertThat(eventStorage.get()).isNotNull();
      AfnemersSearchEvent afnemersSearchEvent = eventStorage.get();

      assertThat(afnemersSearchEvent.getAfnemerCode()).isNull();
      assertThat(afnemersSearchEvent.getAfnemerNaam()).isNull();
      assertThat(afnemersSearchEvent.getUgcId()).isEqualTo("123");
      assertThat(afnemersSearchEvent.getContractId()).isNull();

      assertThat(validationLabel.getText()).isEmpty();
      assertThat(validationLabel.isVisible()).isFalse();
   }

   @Test
   @DisplayName("Given search Alle afnemers button clicked, should result in a search event and no error message is shown, search fields are empty")
   void testAlleAfnemers() {
      AtomicReference<SearchAlleAfnemersEvent> eventStorage = new AtomicReference<>(null);
      afnemersSearchBar.addListener(SearchAlleAfnemersEvent.class, eventStorage::set);

      alleAfnemersButton.click();

      assertThat(eventStorage.get()).isNotNull();
      SearchAlleAfnemersEvent searchAlleAfnemersEvent = eventStorage.get();

      assertThat(searchAlleAfnemersEvent).isNotNull();
      assertThat(ugcIdSearchField.getValue()).isEmpty();
      assertThat(contractIdSearchField.getValue()).isEmpty();
      assertThat(afnemerCodeSearchField.getValue()).isEmpty();
      assertThat(afnemerNaamSearchField.getValue()).isEmpty();
      assertThat(validationLabel.getText()).isEmpty();
      assertThat(validationLabel.isVisible()).isFalse();
   }

   @Test
   @DisplayName("Given search Alle Cws Leveringen button clicked, should result in a search event and no error message is shown, search fields are empty")
   void testAlleLeveringen() {
      AtomicReference<SearchAlleLeveringenEvent> eventStorage = new AtomicReference<>(null);
      afnemersSearchBar.addListener(SearchAlleLeveringenEvent.class, eventStorage::set);

      alleCwsLeveringenButton.click();

      assertThat(eventStorage.get()).isNotNull();
      SearchAlleLeveringenEvent searchAlleLeveringenEvent = eventStorage.get();

      assertThat(searchAlleLeveringenEvent).isNotNull();
      assertThat(ugcIdSearchField.getValue()).isEmpty();
      assertThat(contractIdSearchField.getValue()).isEmpty();
      assertThat(afnemerCodeSearchField.getValue()).isEmpty();
      assertThat(afnemerNaamSearchField.getValue()).isEmpty();
      assertThat(validationLabel.getText()).isEmpty();
      assertThat(validationLabel.isVisible()).isFalse();
   }

   @Test
   @DisplayName("Given search button clicked when Ugc id field has invalid input, validation should fail and error message is shown")
   void testValidationFailsOnUgcId() {
      AtomicReference<Boolean> eventStorage = new AtomicReference<>(null);
      afnemersSearchBar.addListener(ValidationFailedEvent.class, event ->  eventStorage.set(true));
      ugcIdSearchField.setValue("abc");
      searchButton.click();
      assertThat(eventStorage.get()).isNotNull();
      assertThat(eventStorage.get().booleanValue()).isTrue();

      // Validation message should be shown
      assertThat(validationLabel.getText()).isEqualTo("UGC Id mag alleen cijfers bevatten");
      assertThat(validationLabel.isVisible()).isTrue();
   }


   @Test
   @DisplayName("Given search button clicked when Contract id field has invalid input, validation should fail and error message is shown")
   void testValidationFailsOnContractId() {
      AtomicReference<Boolean> eventStorage = new AtomicReference<>(null);
      afnemersSearchBar.addListener(ValidationFailedEvent.class, event ->  eventStorage.set(true));
      contractIdSearchField.setValue("abc");
      searchButton.click();
      assertThat(eventStorage.get()).isNotNull();
      assertThat(eventStorage.get().booleanValue()).isTrue();

      // Validation message should be shown
      assertThat(validationLabel.getText()).isEqualTo("Contract Id mag alleen cijfers bevatten");
      assertThat(validationLabel.isVisible()).isTrue();
   }


   @SuppressWarnings("unchecked")
   private <T extends Component> T findChild(final String id, final Component parent) {
      T result = (T) parent.getChildren()
            .filter(child -> id.equals(child.getId().orElse(null)))
            .findFirst().orElse(null);
      assertThat(result).withFailMessage("Unable to locate child component with id " + id).isNotNull();
      return result;
   }

}
