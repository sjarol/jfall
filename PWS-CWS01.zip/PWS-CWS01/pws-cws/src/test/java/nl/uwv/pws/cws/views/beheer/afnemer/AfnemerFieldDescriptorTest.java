package nl.uwv.pws.cws.views.beheer.afnemer;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.stream.Collectors;

import static org.assertj.core.api.Assertions.assertThat;

class AfnemerFieldDescriptorTest {

   @Test
   @DisplayName("Multiple calls to the getInstance() method return the same instance")
   void testGetInstance() {
      // Multiple calls return same instance
      assertThat(AfnemerFieldDescriptor.getInstance()).isSameAs(AfnemerFieldDescriptor.getInstance());
   }

   @Test
   @DisplayName("There's a descriptor available for each of the fields we support")
   void testFields() {
      AfnemerFieldDescriptor fieldDescriptor = AfnemerFieldDescriptor.getInstance();

      // We expect all AfnemerColumns to be described in the AfnemerFieldDescriptors
      assertThat(fieldDescriptor.getColumnNames()).containsAnyElementsOf(
            Arrays.stream(AfnemerColumn.values())
                  .map(Enum::name)
                  .collect(Collectors.toList())
      );
   }
}
