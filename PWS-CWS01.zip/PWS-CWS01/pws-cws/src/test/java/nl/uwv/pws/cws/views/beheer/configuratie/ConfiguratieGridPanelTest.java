package nl.uwv.pws.cws.views.beheer.configuratie;

import com.vaadin.flow.component.AbstractField.ComponentValueChangeEvent;
import com.vaadin.flow.component.HasValue.ValueChangeListener;
import com.vaadin.flow.component.grid.Grid;
import nl.uwv.pws.backend.types.ColumnList;
import nl.uwv.pws.cws.model.ContractDetails;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import test.common.SqlFilterArgumentMatcher;

import java.math.BigDecimal;
import java.time.LocalDate;

import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.*;

public class ConfiguratieGridPanelTest {

   private ConfiguratieGridPanel spyConfiguratieGridPanel;

   @BeforeEach
   public void setup(){
      ValueChangeListener<ComponentValueChangeEvent<Grid<ColumnList>, ColumnList>> valueChangeListener = mock(ValueChangeListener.class);
      spyConfiguratieGridPanel = spy(new ConfiguratieGridPanel(valueChangeListener));
   }

   @Test
   @DisplayName("Given a call to findConfiguratie, should use the correct related filter")
   void testFindConfiguratie() {
      ContractDetails contractDetails = ContractDetails.builder().contractId(BigDecimal.ONE).contractStartDate(LocalDate.now()).build();
      spyConfiguratieGridPanel.findConfiguratie(contractDetails);
      verify(spyConfiguratieGridPanel).search(argThat(new SqlFilterArgumentMatcher(new ConfiguratieFilter(BigDecimal.ONE, LocalDate.now()))));
   }
}
