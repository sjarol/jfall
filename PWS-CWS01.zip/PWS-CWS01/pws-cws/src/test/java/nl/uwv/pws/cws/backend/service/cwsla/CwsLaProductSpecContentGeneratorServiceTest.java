package nl.uwv.pws.cws.backend.service.cwsla;

import nl.uwv.pws.cws.backend.dao.CwsConfigurationDao;
import nl.uwv.pws.cws.model.*;
import org.junit.jupiter.api.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import java.util.*;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.junit.jupiter.api.TestInstance.Lifecycle.PER_CLASS;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;

@TestInstance(PER_CLASS)
public class CwsLaProductSpecContentGeneratorServiceTest {

   private CwsLaProductSpecContentGeneratorService cwsLaProductSpecContentGeneratorService;

   private MockedStatic<CwsConfigurationDao> cwsConfigurationDaoMockedStatic;
   private CwsConfigurationDao cwsConfigurationDao;

   @BeforeAll
   public void setupOnce() {
      this.cwsConfigurationDaoMockedStatic = Mockito.mockStatic(CwsConfigurationDao.class);
      this.cwsConfigurationDao = mock(CwsConfigurationDao.class);

      cwsConfigurationDaoMockedStatic.when(CwsConfigurationDao::getInstance).thenReturn(cwsConfigurationDao);
   }

   @AfterAll
   public void cleanup(){
      cwsConfigurationDaoMockedStatic.close();
   }


   @Test
   @DisplayName("Should use correct parameters to prepare product specification generation")
   void testFileAndFolderNamesForProductSpecification() {
      cwsLaProductSpecContentGeneratorService = new CwsLaProductSpecContentGeneratorService(CwsConfiguration.builder()
            .configurationId(999999L)
            .configurationVersion(10L)
            .build(),
            "dummyKenmerk", "dummyRequestHeader", "dummyResponseHeader");

      assertThat(cwsLaProductSpecContentGeneratorService.getPdfTemplateFileName()).isEqualTo("../templates/cwsla-product-specificatie-template.odt");
      assertThat(cwsLaProductSpecContentGeneratorService.getExampleRequestFileNames()).isEqualTo(new String [] {"Request.xml"});
      assertThat(cwsLaProductSpecContentGeneratorService.getExampleXmlFolderName()).isEqualTo("cwsla/");
      assertThat(cwsLaProductSpecContentGeneratorService.getResponseBodyRootElementName()).isEqualTo("CwsLoonaangifteresponse");
   }

   @Test
   @DisplayName("Should return correct mapping for CWS-LA at service construction when no codeSoortIkv is present")
   public void testGetSelectieCriteriaMappingEmptyCodeSoortIkv(){
      Map<BaseCwsFilterType, String> filterMap = new HashMap<>();
      filterMap.put(CwsLaFilterType.NIHIL_LNSV_UITSLUITEN, "N");
      filterMap.put(CwsLaFilterType.NIHIL_LNLBPH_UITSLUITEN, "J");
      filterMap.put(CwsLaFilterType.MAX_LEVERPERIODE, "3");

      SelectionCriteria selectionCriteria = new SelectionCriteria("CWS-LA");
      selectionCriteria.setFilterMap(filterMap);
      when(cwsConfigurationDao.selectSelectionCriteriaByConfigId(anyLong())).thenReturn(selectionCriteria);

      cwsLaProductSpecContentGeneratorService = new CwsLaProductSpecContentGeneratorService(CwsConfiguration.builder()
            .configurationId(999999L)
            .configurationVersion(10L)
            .build(),
            "dummyKenmerk", "dummyRequestHeader", "dummyResponseHeader");

      Map<String, Object> mappingMap = cwsLaProductSpecContentGeneratorService.getSelectieCriteriaMapping();
      String value = (String) mappingMap.get("configuratie_maxLeverperiode");
      assertThat(value).isEqualTo("Er worden gegevens geleverd van maximaal 3 maand(en) terug vanaf systeemdatum.");

      value = (String) mappingMap.get("condition_NihilSv");
      assertThat(value).isEqualTo("false");

      value = (String) mappingMap.get("condition_NihilLbPh");
      assertThat(value).isEqualTo("true");

      value = (String) mappingMap.get("condition_noCdSrtIkv");
      assertThat(value).isEqualTo("true");

      value = (String) mappingMap.get("condition_showTableCdSrtIkv");
      assertThat(value).isEqualTo("false");

      List<CodeSoortIkv> cdSrtIkvs = (List<CodeSoortIkv>) mappingMap.get("rows");
      CodeSoortIkv codeSoortIkv = cdSrtIkvs.listIterator().next();
      assertThat(codeSoortIkv.getCode()).isEqualTo("");
      assertThat(codeSoortIkv.getOmschrijving()).isEqualTo("");
      assertThat(codeSoortIkv.getDatumEinde()).isEqualTo("");
   }

   @Test
   @DisplayName("Should return correct mapping for CWS-LA at service construction when codeSoortIkv is present")
   public void testGetSelectieCriteriaMappingWhenCodeSoortIkvIsPresent(){
      Map<BaseCwsFilterType, String> filterMap = new HashMap<>();
      filterMap.put(CwsLaFilterType.NIHIL_LNSV_UITSLUITEN, "J");
      filterMap.put(CwsLaFilterType.NIHIL_LNLBPH_UITSLUITEN, "N");
      filterMap.put(CwsLaFilterType.MAX_LEVERPERIODE, "3");
      filterMap.put(CwsLaFilterType.CD_SOORT_IKVS, "11-18");

      SelectionCriteria selectionCriteria = new SelectionCriteria("CWS-LA");
      selectionCriteria.setFilterMap(filterMap);
      when(cwsConfigurationDao.selectSelectionCriteriaByConfigId(anyLong())).thenReturn(selectionCriteria);

      cwsLaProductSpecContentGeneratorService = new CwsLaProductSpecContentGeneratorService(CwsConfiguration.builder()
            .configurationId(999999L)
            .configurationVersion(10L)
            .build(),
            "dummyKenmerk", "dummyRequestHeader", "dummyResponseHeader");

      Map<String, Object> mappingMap = cwsLaProductSpecContentGeneratorService.getSelectieCriteriaMapping();
      String value = (String) mappingMap.get("configuratie_maxLeverperiode");
      assertThat(value).isEqualTo("Er worden gegevens geleverd van maximaal 3 maand(en) terug vanaf systeemdatum.");

      value = (String) mappingMap.get("condition_NihilSv");
      assertThat(value).isEqualTo("true");

      value = (String) mappingMap.get("condition_NihilLbPh");
      assertThat(value).isEqualTo("false");

      value = (String) mappingMap.get("condition_noCdSrtIkv");
      assertThat(value).isEqualTo("false");

      value = (String) mappingMap.get("condition_showTableCdSrtIkv");
      assertThat(value).isEqualTo("true");

      Set<String> ikvCodesSet = new HashSet<>(Arrays.asList("11","12","13","14","15", "16", "17", "18"));
      verify(cwsConfigurationDao, times(1)).findCodeSoortIkvStamgegevens(new ArrayList<>(ikvCodesSet));
   }
}
