package nl.uwv.pws.cws.views.beheer.tabs;

import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.tabs.Tab;
import nl.uwv.pws.cws.backend.dao.CwsConfigurationDao;
import nl.uwv.pws.cws.model.CwsMetaCol;
import nl.uwv.pws.cws.views.BeheerConfiguratieView;
import nl.uwv.pws.cws.views.beheer.tabs.layout.OverzichtConfiguratieLayout;
import org.junit.jupiter.api.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import test.common.PwsTestUtils;

import java.util.Map;

import static nl.uwv.pws.cws.util.Constants.*;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.TestInstance.Lifecycle.PER_CLASS;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;


@TestInstance(PER_CLASS)
public class OverzichtCwsConfiguratiesTabTest {

   private OverzichtCwsConfiguratiesTab tab;

   private BeheerConfiguratieView beheerConfiguratieViewMock;
   private MockedStatic<CwsConfigurationDao> cwsConfigurationDaoMockedStatic;
   private CwsConfigurationDao cwsConfigurationDao;

   @BeforeAll
   public void setup() {
      this.beheerConfiguratieViewMock = mock(BeheerConfiguratieView.class);

      this.cwsConfigurationDaoMockedStatic = Mockito.mockStatic(CwsConfigurationDao.class);
      this.cwsConfigurationDao = mock(CwsConfigurationDao.class);

      cwsConfigurationDaoMockedStatic.when(CwsConfigurationDao::getInstance).thenReturn(cwsConfigurationDao);
      when(cwsConfigurationDao.getMaxBerichtVersie(anyString())).thenReturn("102");
      Map<Long, CwsMetaCol> metaColMap = Mockito.anyMap();
      when(cwsConfigurationDao.getMetaDataByLeverCodeAndVersie(anyString(), "102")).thenReturn(metaColMap);

      tab = new OverzichtCwsConfiguratiesTab(beheerConfiguratieViewMock);
   }

   @AfterAll
   public void cleanup(){
      cwsConfigurationDaoMockedStatic.close();
   }

   @Test
   @DisplayName("OverzichtCwsConfiguratiesTab contains all sub tabs and layouts")
   void testCreateOverzichtCwsConfiguratiesTab() {
      Component cwsLaSubTab = PwsTestUtils.findDescendentsById(COMPONENT_ID_OVERZICHT_CWS_CONFIGURATIES_TAB_SUBTAB_CWSLA_ID, tab.getAuthorizedSubTabs());
      assertThat(cwsLaSubTab).isNotNull();

      Component cwsNpSubTab = PwsTestUtils.findDescendentsById(COMPONENT_ID_OVERZICHT_CWS_CONFIGURATIES_TAB_SUBTAB_CWSNP_ID, tab.getAuthorizedSubTabs());
      assertThat(cwsNpSubTab).isNotNull();

      Component cwsHrSubTab = PwsTestUtils.findDescendentsById(COMPONENT_ID_OVERZICHT_CWS_CONFIGURATIES_TAB_SUBTAB_CWSHR_ID, tab.getAuthorizedSubTabs());
      assertThat(cwsHrSubTab).isNotNull();

      Component cwsWgSubTab = PwsTestUtils.findDescendentsById(COMPONENT_ID_OVERZICHT_CWS_CONFIGURATIES_TAB_SUBTAB_CWSWG_ID, tab.getAuthorizedSubTabs());
      assertThat(cwsWgSubTab).isNotNull();

      Component cwsIhpSubTab = PwsTestUtils.findDescendentsById(COMPONENT_ID_OVERZICHT_CWS_CONFIGURATIES_TAB_SUBTAB_CWSIHP_ID, tab.getAuthorizedSubTabs());
      assertThat(cwsIhpSubTab).isNotNull();

      Map<Tab, OverzichtConfiguratieLayout> layoutMap = tab.getTabsToLayouts();
      assertThat(layoutMap.size()).isEqualTo(5);
      OverzichtConfiguratieLayout overzichtConfiguratieLayoutCwsLa = layoutMap.get(cwsLaSubTab);
      assertThat(overzichtConfiguratieLayoutCwsLa.getLeverCode()).isEqualTo("CWS-LA");

      OverzichtConfiguratieLayout overzichtConfiguratieLayoutCwsNp = layoutMap.get(cwsNpSubTab);
      assertThat(overzichtConfiguratieLayoutCwsNp.getLeverCode()).isEqualTo("CWS-NP");

      OverzichtConfiguratieLayout overzichtConfiguratieLayoutCwsHr = layoutMap.get(cwsHrSubTab);
      assertThat(overzichtConfiguratieLayoutCwsHr.getLeverCode()).isEqualTo("CWS-HR");

      OverzichtConfiguratieLayout overzichtConfiguratieLayoutCwsWg = layoutMap.get(cwsWgSubTab);
      assertThat(overzichtConfiguratieLayoutCwsWg.getLeverCode()).isEqualTo("CWS-WG");

      OverzichtConfiguratieLayout overzichtConfiguratieLayoutCwsIhp = layoutMap.get(cwsIhpSubTab);
      assertThat(overzichtConfiguratieLayoutCwsIhp.getLeverCode()).isEqualTo("CWS-IHP");
   }

   @Test
   @DisplayName("Should make layouts invisible other than the selected tab and select the correct tab")
   void testGetViewContent() {
      tab.getViewContent();

      Tab selectedTab = tab.getAuthorizedSubTabs().getSelectedTab();
      assertThat(selectedTab.getId().get()).isEqualTo(COMPONENT_ID_OVERZICHT_CWS_CONFIGURATIES_TAB_SUBTAB_CWSLA_ID);
      assertThat(selectedTab.isVisible()).isTrue();
   }
}
