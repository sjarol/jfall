package nl.uwv.pws.cws.views.beheer.tabs.layout.cwshr;

import com.vaadin.flow.component.checkbox.Checkbox;
import nl.uwv.pws.cws.model.viewtab.BaseCwsOverzichtFilterOption;
import nl.uwv.pws.cws.model.viewtab.CwsHrFilter;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

public class CwsHrOverzichtFilterFormLayoutTest {

   private CwsHrOverzichtFilterFormLayout cwsHrOverzichtFilterFormLayout;
   private List<Checkbox> checkboxList;

   @BeforeEach
   public void setup() {
      cwsHrOverzichtFilterFormLayout = new CwsHrOverzichtFilterFormLayout();
      this.checkboxList = cwsHrOverzichtFilterFormLayout.getCheckboxList();
   }

   @Test
   @DisplayName("CWS-HR OverzichtConfiguratieLayout contains all checkboxes")
   void testCreateLayout() {
      Optional<Checkbox> optionalCheckboxBeeindigdAdresUitsluiten = checkboxList.stream().filter(checkbox -> checkbox.getLabel().equals("Filter beëindigd adres uitsluiten")
            && checkbox.getId().get().equals(CwsHrFilter.BEEINDIGD_ADRES_UITSLUITEN.name())).findFirst();
      assertThat(optionalCheckboxBeeindigdAdresUitsluiten.isPresent()).isTrue();
   }

   @Test
   @DisplayName("CWS-HR OverzichtConfiguratieLayout return only selected Checkbox")
   void testSelectedFilters() {
      Optional<Checkbox> optionalCheckboxCodeSoortIkv = checkboxList.stream().filter(checkbox -> checkbox.getLabel().equals("Filter beëindigd adres uitsluiten")
            && checkbox.getId().get().equals(CwsHrFilter.BEEINDIGD_ADRES_UITSLUITEN.name())).findFirst();
      optionalCheckboxCodeSoortIkv.get().setValue(true);

      List<BaseCwsOverzichtFilterOption> filterOptionList = cwsHrOverzichtFilterFormLayout.getSelectedFilters();
      BaseCwsOverzichtFilterOption filterOption = filterOptionList.listIterator().next();

      assertThat(filterOption.getEnumName()).isEqualTo(CwsHrFilter.BEEINDIGD_ADRES_UITSLUITEN.name());
      assertThat(filterOption.getColumnName()).isEqualTo("Filter beëindigd adres");
      assertThat(filterOption.getHeaderColumnName()).isEqualTo("Filter beëindigd adres uitsluiten");
   }
}
