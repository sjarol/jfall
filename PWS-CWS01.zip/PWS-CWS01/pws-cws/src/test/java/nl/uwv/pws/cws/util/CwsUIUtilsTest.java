package nl.uwv.pws.cws.util;

import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.formlayout.FormLayout;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import nl.uwv.pws.ui.util.FontWeight;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

@SuppressWarnings("ALL")
public class CwsUIUtilsTest {

   @Test
   @DisplayName("Should create a Button using the arguments")
   void testCreateButton(){
      Button button = CwsUIUtils.createButton("someText", VaadinIcon.AIRPLANE, "someId", true, "10em");
      assertThat(button.getText()).isEqualTo("someText");
      assertThat(button.getId().get()).isEqualTo("someId");
      assertThat(button.isEnabled()).isTrue();
      assertThat(button.getWidth()).isEqualTo("10em");
   }

   @Test
   @DisplayName("Should create a ButtonStrip using the arguments")
   void testCreateButtonStrip(){
      HorizontalLayout horizontalLayout = CwsUIUtils.createButtonStrip("someId", "10em");
      assertThat(horizontalLayout.getId().get()).isEqualTo("someId");
      assertThat(horizontalLayout.getWidth()).isEqualTo("10em");
      assertThat(horizontalLayout.isVisible()).isTrue();
   }

   @Test
   @DisplayName("Should find a component in a FormLayout")
   void testFindComponent(){
      FormLayout formLayout = new FormLayout();
      HorizontalLayout horizontalLayout = CwsUIUtils.createButtonStrip("someId", "10em");
      Button button = new Button();
      button.setId("someId");
      horizontalLayout.add(button);
      formLayout.add(horizontalLayout);
      Component component = CwsUIUtils.findComponent("someId", formLayout);
      assertThat(component).isNotNull();
   }

   @Test
   @DisplayName("Should create a label and use style bold")
   void testCreateHeaderLabel(){
      Label label = CwsUIUtils.createHeaderLabel("header label");
      assertThat(label.getText()).isEqualTo("header label");
      assertThat(label.getStyle().get("font-weight")).isEqualTo(FontWeight.BOLD.getValue());
   }
}
