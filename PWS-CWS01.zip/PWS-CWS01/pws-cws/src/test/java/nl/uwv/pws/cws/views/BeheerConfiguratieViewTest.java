package nl.uwv.pws.cws.views;

import com.vaadin.flow.component.AttachEvent;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.router.Route;
import nl.uwv.pws.backend.dao.AuthorizationType;
import nl.uwv.pws.ui.MainLayout;
import nl.uwv.pws.ui.util.AuthorizedComponent;
import nl.uwv.pws.ui.util.AuthorizedView;
import nl.uwv.pws.ui.util.PageMenuCode;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

public class BeheerConfiguratieViewTest {

   @Test
   @DisplayName("Class annotations should be present")
   void testAnnotationsArePresent() {
      Route route = BeheerConfiguratieView.class.getAnnotation(Route.class);
      assertThat(route).isNotNull();
      assertThat(route.value()).isEqualTo("ui/cws-config");
      assertThat(route.layout()).isEqualTo(MainLayout.class);

      PageMenuCode pageMenuCode = BeheerConfiguratieView.class.getAnnotation(PageMenuCode.class);
      assertThat(pageMenuCode).isNotNull();
      assertThat(pageMenuCode.value()).isEqualTo("PWS09");

      AuthorizedView authorizedView = BeheerConfiguratieView.class.getAnnotation(AuthorizedView.class);
      assertThat(authorizedView).isNotNull();
      assertThat(authorizedView.value()).isEqualTo("Beheer CWS Configuratie");

      CssImport cssImport = BeheerConfiguratieView.class.getAnnotation(CssImport.class);
      assertThat(cssImport).isNotNull();
      assertThat(cssImport.value()).isEqualTo("./styles/pws-cws.css");

      for(Field field : BeheerConfiguratieView.class.getDeclaredFields()){
         if(field.getName().equals("afnemersEnLeveringenTab")){
            AuthorizedComponent authorizedComponent = field.getAnnotation(AuthorizedComponent.class);
            assertThat(authorizedComponent).isNotNull();
            assertThat(authorizedComponent.value()).isEqualTo("Afnemers en CWS Leveringen");
            assertThat(authorizedComponent.type()).isEqualTo(AuthorizationType.TAB);
         }else if(field.getName().equals("overzichtCwsConfiguratiesTab")){
            AuthorizedComponent authorizedComponent = field.getAnnotation(AuthorizedComponent.class);
            assertThat(authorizedComponent).isNotNull();
            assertThat(authorizedComponent.value()).isEqualTo("Overzicht CWS Configuraties");
            assertThat(authorizedComponent.type()).isEqualTo(AuthorizationType.TAB);
         }
      }
   }
}
