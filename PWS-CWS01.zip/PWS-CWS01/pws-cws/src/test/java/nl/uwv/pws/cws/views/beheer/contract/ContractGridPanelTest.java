package nl.uwv.pws.cws.views.beheer.contract;

import com.vaadin.flow.component.AbstractField.ComponentValueChangeEvent;
import com.vaadin.flow.component.HasValue.ValueChangeListener;
import com.vaadin.flow.component.grid.Grid;
import nl.uwv.pws.backend.service.CountRowsListener;
import nl.uwv.pws.backend.types.ColumnList;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import test.common.SqlFilterAbstractArgumentMatcher;

import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.*;

public class ContractGridPanelTest {

   private ContractGridPanel spyContractGridPanel;

   @BeforeEach
   public void setup(){
      String componentId = "componentId";
      ValueChangeListener<ComponentValueChangeEvent<Grid<ColumnList>, ColumnList>> valueChangeListener = mock(ValueChangeListener.class);
      CountRowsListener countRowsListener = mock(CountRowsListener.class);
      spyContractGridPanel = spy(new ContractGridPanel(valueChangeListener, countRowsListener, componentId, ContractServiceType.CONTRACT_BY_AFNEMER));
   }

   @Test
   @DisplayName("Given a call to findContractsByContractId, should use the correct related filter")
   void testFindContractsByContractId() {
      String contractId = "123456";
      spyContractGridPanel.findContractsByContractId(contractId);

      verify(spyContractGridPanel).search(argThat(new SqlFilterAbstractArgumentMatcher(new ContractByContractIdFilter(contractId))));
   }

   @Test
   @DisplayName("Given a call to findContractsByAfnemerCode, should use the correct related filter")
   void testFindContractsByAfnemerCode() {
      String afnemerCode = "afn_code";
      spyContractGridPanel.findContractsByAfnemerCode(afnemerCode);

      verify(spyContractGridPanel).search(argThat(new SqlFilterAbstractArgumentMatcher(new ContractByAfnemerCodeFilter(afnemerCode))));
   }

   @Test
   @DisplayName("Given a call to findContractsByLeveringCode, should use the correct related filter")
   void testFindContractsByLeveringCode() {
      String leverCode = "lev_code";
      spyContractGridPanel.findContractsByLeveringCode(leverCode);

      verify(spyContractGridPanel).search(argThat(new SqlFilterAbstractArgumentMatcher(new ContractByLeveringCodeFilter(leverCode))));
   }
}
