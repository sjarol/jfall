package nl.uwv.pws.cws.util;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDate;

import static org.assertj.core.api.Assertions.assertThat;

public class CwsUtilsTest {

   @Test
   @DisplayName("Should return BigDecimal if argument is of type BigDecimal")
   void testGetBigDecimal(){
      Object someValue = new BigDecimal("12");
      BigDecimal valueToUse = CwsUtils.getBigDecimal(someValue);
      assertThat(valueToUse).isNotNull();

      Object otherValue = "12";
      BigDecimal otherValueToUse = CwsUtils.getBigDecimal(otherValue);
      assertThat(otherValueToUse).isNull();
   }

   @Test
   @DisplayName("Should return LocalDate if argument is of type Date")
   void testGetDateAsLocalDate(){
      Object someValue = Date.valueOf(LocalDate.now());
      LocalDate valueToUse = CwsUtils.getDateAsLocalDate(someValue);
      assertThat(valueToUse).isNotNull();

      Object otherValue = "12";
      LocalDate otherValueToUse = CwsUtils.getDateAsLocalDate(otherValue);
      assertThat(otherValueToUse).isNull();
   }

   @Test
   @DisplayName("Should return LocalDate if argument is of type Date using the right pattern")
   void testGetLocalDateAsString(){
      String valueToUse = CwsUtils.getLocalDateAsString(LocalDate.of(2021,6,1));
      assertThat(valueToUse).isEqualTo("01-06-2021");
   }

   @Test
   @DisplayName("Should return LocalDate if argument is of type Long using the right pattern")
   void testGetLongAsLocalDate(){
      LocalDate valueToUse = CwsUtils.getLongAsLocalDate(20210601L);
      assertThat(valueToUse).isEqualTo(LocalDate.of(2021,6,1));
   }

   @Test
   @DisplayName("Should return Long if argument is of type LocalDate using the right pattern")
   void testGetLocalDateAsLong(){
      long valueToUse = CwsUtils.getLocalDateAsLong(LocalDate.of(2021,6,1));
      assertThat(valueToUse).isEqualTo(20210601L);
   }

   @Test
   @DisplayName("Should create right .pdf file name based on input parameters")
   void testCreatePdfFileName(){
      String pdfFileName = CwsUtils.createPdfFileName("FAT", "unittest config", "102", "afnCode");
      assertThat(pdfFileName).isEqualTo("FAT_Productspec_afnCode_unittest config_102.pdf");
   }

   @Test
   @DisplayName("Should create right .json export file name based on input parameters")
   void testCreateExportFileName(){
      String overviewFileName = CwsUtils.createExportFileName("unittest config", "102", "afnCode");
      assertThat(overviewFileName).startsWith("ExportCWS_");
      assertThat(overviewFileName).containsSubsequence("_unittest config_");
      assertThat(overviewFileName).containsSubsequence("_102_");
      assertThat(overviewFileName).endsWith(".json");

      int startIndexDate = overviewFileName.lastIndexOf("_102_") + 5; //_102_ has 5 chars
      int endIndexDate = overviewFileName.indexOf(".json");
      assertThat(overviewFileName.substring(startIndexDate, endIndexDate).length()).isEqualTo(14);
      assertThat(overviewFileName.substring(startIndexDate, endIndexDate).matches("\\d+")).isTrue();
   }

   @ParameterizedTest
   @DisplayName("should replace characters from file name")
   @ValueSource(strings = {"\\export/FileName\\",
         ":export*FileName?",
         "\"export\"FileName\"",
         "<export>FileName|"})
   void testReplaceNotAllowedChars(String input){
      assertThat(CwsUtils.replaceNotAllowedChars(input)).isEqualTo("-export-FileName-");
   }

}
