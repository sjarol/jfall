package nl.uwv.pws.cws.views.beheer.tabs.layout.cwsihp;

import com.vaadin.flow.component.checkbox.Checkbox;
import com.vaadin.flow.component.formlayout.FormLayout;
import nl.uwv.pws.cws.model.BaseCwsFilterType;
import nl.uwv.pws.cws.model.CwsIhpFilterType;
import nl.uwv.pws.cws.model.SelectionCriteria;
import nl.uwv.pws.cws.util.CwsUIUtils;
import nl.uwv.pws.cws.views.beheer.configuratie.ConfigurationAction;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;

import static nl.uwv.pws.cws.util.Constants.COMPONENT_ID_BEEINDIGDADRESUITSLUITEN_CHECKBOX;
import static org.assertj.core.api.Assertions.assertThat;

public class CwsIhpSelectionCriteriaLayoutTest {


   private CwsIhpSelectionCriteriaLayout layout;

   @BeforeEach
   public void setup() {
      layout = new CwsIhpSelectionCriteriaLayout();
   }

   @Test
   @DisplayName("Should create Selection criteria layout using correct components for ADD and MODIFY actions")
   void testCreateSelectionCriteriaLayoutForAddConfiguration() {
      Map<BaseCwsFilterType, String> filterMap = new HashMap<>();
      filterMap.put(CwsIhpFilterType.BEEINDIGD_ADRES_UITSLUITEN_IHP, "J");
      SelectionCriteria selectionCriteria = new SelectionCriteria("CWS-IHP");
      selectionCriteria.setFilterMap(filterMap);
      ConfigurationAction configurationAction =  ConfigurationAction.ADD;
      FormLayout formLayout = layout.createSelectionCriteriaLayout(selectionCriteria, configurationAction);

      Checkbox checkboxBeeindigdAdresUitsluiten = (Checkbox)CwsUIUtils.findComponent(COMPONENT_ID_BEEINDIGDADRESUITSLUITEN_CHECKBOX, formLayout);
      assertThat(checkboxBeeindigdAdresUitsluiten).isNotNull();
      assertThat(checkboxBeeindigdAdresUitsluiten.getValue()).isTrue();
      assertThat(checkboxBeeindigdAdresUitsluiten.isEnabled()).isTrue();

      assertThat(layout.isOriginalBeeindigdAdresUitsluiten()).isTrue();
   }

   @Test
   @DisplayName("Should create Selection criteria layout using correct components for VIEW actions")
   void testCreateSelectionCriteriaLayoutForViewConfiguation() {
      Map<BaseCwsFilterType, String> filterMap = new HashMap<>();
      filterMap.put(CwsIhpFilterType.BEEINDIGD_ADRES_UITSLUITEN_IHP, "n");
      SelectionCriteria selectionCriteria = new SelectionCriteria("CWS-IHP");
      selectionCriteria.setFilterMap(filterMap);
      ConfigurationAction configurationAction = ConfigurationAction.VIEW;
      FormLayout formLayout = layout.createSelectionCriteriaLayout(selectionCriteria, configurationAction);

      Checkbox checkboxBeeindigdAdresUitsluiten = (Checkbox)CwsUIUtils.findComponent(COMPONENT_ID_BEEINDIGDADRESUITSLUITEN_CHECKBOX, formLayout);
      assertThat(checkboxBeeindigdAdresUitsluiten).isNotNull();
      assertThat(checkboxBeeindigdAdresUitsluiten.isEnabled()).isFalse();
      assertThat(checkboxBeeindigdAdresUitsluiten.getValue()).isFalse();
   }
}
