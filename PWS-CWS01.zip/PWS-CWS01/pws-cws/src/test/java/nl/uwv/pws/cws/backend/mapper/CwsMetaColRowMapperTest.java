package nl.uwv.pws.cws.backend.mapper;

import nl.uwv.pws.cws.model.CwsMetaCol;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.sql.ResultSet;
import java.sql.SQLException;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class CwsMetaColRowMapperTest {

   @Test
   @DisplayName("Should map the resultset fields")
   void testMapRow() throws SQLException {
      ResultSet resultSet = mock(ResultSet.class);
      when(resultSet.getLong("META_COL_ID")).thenReturn(123L);
      when(resultSet.getLong("META_ROOT_ID")).thenReturn(789L);
      when(resultSet.getLong("PARENT_ID")).thenReturn(24L);
      when(resultSet.getString("TECH_NAAM")).thenReturn("testTechNaam");
      when(resultSet.getString("FUNC_NAAM")).thenReturn("testFuncNaam");
      when(resultSet.getString("OMSCHRIJVING")).thenReturn("testOmschrijving");
      when(resultSet.getLong("VOLGNR")).thenReturn(4L);
      when(resultSet.getString("BRON_TABEL")).thenReturn("testBronTabel");
      when(resultSet.getString("BRON_RUBRIEK")).thenReturn("testBronRubriek");
      when(resultSet.getString("IND_VERPLICHT")).thenReturn("testIndicatieVerplicht");

      CwsMetaColRowMapper cwsMetaColRowMapper = new CwsMetaColRowMapper();

      CwsMetaCol cwsMetaCol = cwsMetaColRowMapper.mapRow(resultSet);
      assertThat(cwsMetaCol.getMetaColId()).isEqualTo(123L);
      assertThat(cwsMetaCol.getMetaRootId()).isEqualTo(789L);
      assertThat(cwsMetaCol.getParentId()).isEqualTo(24L);
      assertThat(cwsMetaCol.getTechNaam()).isEqualTo("testTechNaam");
      assertThat(cwsMetaCol.getFuncNaam()).isEqualTo("testFuncNaam");
      assertThat(cwsMetaCol.getOmschrijving()).isEqualTo("testOmschrijving");
      assertThat(cwsMetaCol.getVolgnr()).isEqualTo(4L);
      assertThat(cwsMetaCol.getBronTabel()).isEqualTo("testBronTabel");
      assertThat(cwsMetaCol.getBronRubriek()).isEqualTo("testBronRubriek");
      assertThat(cwsMetaCol.getIndVerplicht()).isEqualTo("testIndicatieVerplicht");
   }
}
