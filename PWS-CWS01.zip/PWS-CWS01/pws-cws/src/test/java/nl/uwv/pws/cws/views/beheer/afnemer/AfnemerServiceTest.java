package nl.uwv.pws.cws.views.beheer.afnemer;

import com.vaadin.flow.data.provider.QuerySortOrder;
import com.vaadin.flow.data.provider.SortDirection;
import nl.uwv.pws.cws.util.Constants;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class AfnemerServiceTest {

   @Test
   @DisplayName("AfnemerService configures the correct table name and default column sort")
   void testListServiceConfiguration() {
      AfnemerService afnemerService = new AfnemerService(Constants.DS_NAME);
      assertThat(afnemerService.getViewName()).isEqualTo("AFN_AFNEMER");
      assertThat(afnemerService.getDescriptor()).isInstanceOf(AfnemerFieldDescriptor.class);

      QuerySortOrder defaultSortOrder = afnemerService.getDefaultSortOrder();
      assertThat(defaultSortOrder).isNotNull();
      assertThat(defaultSortOrder.getSorted()).isEqualTo(AfnemerColumn.AFN_CD.name());
      assertThat(defaultSortOrder.getDirection()).isEqualTo(SortDirection.ASCENDING);
   }
}
