package nl.uwv.pws.cws.views.beheer.levering;

import com.vaadin.flow.data.provider.QuerySortOrder;
import com.vaadin.flow.data.provider.SortDirection;
import nl.uwv.pws.cws.util.Constants;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class LeveringServiceTest {

   @Test
   @DisplayName("LeveringService configures the correct table name and default column sort")
   void testListServiceConfiguration() {
      LeveringService leveringService = new LeveringService(Constants.DS_NAME);
      assertThat(leveringService.getViewName()).isEqualTo("AFN_LEVERING_TYPE");
      assertThat(leveringService.getDescriptor()).isInstanceOf(LeveringFieldDescriptor.class);

      QuerySortOrder defaultSortOrder = leveringService.getDefaultSortOrder();
      assertThat(defaultSortOrder).isNotNull();
      assertThat(defaultSortOrder.getSorted()).isEqualTo(LeveringColumn.LEV_CD.name());
      assertThat(defaultSortOrder.getDirection()).isEqualTo(SortDirection.ASCENDING);
   }
}
