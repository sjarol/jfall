package nl.uwv.pws.cws.views.beheer.tabs;

import com.vaadin.flow.component.AbstractField.ComponentValueChangeEvent;
import com.vaadin.flow.component.HasValue;
import com.vaadin.flow.component.html.Anchor;
import com.vaadin.flow.component.textfield.TextField;
import nl.uwv.pws.backend.types.ColumnList;
import nl.uwv.pws.cws.model.ConfigurationDetails;
import nl.uwv.pws.cws.model.ContractDetails;
import nl.uwv.pws.cws.model.CwsConfiguration;
import nl.uwv.pws.cws.model.SearchCriteria;
import nl.uwv.pws.cws.util.CwsUIUtils;
import nl.uwv.pws.cws.views.AfnemersSearchBar;
import nl.uwv.pws.cws.views.BeheerConfiguratieView;
import nl.uwv.pws.cws.views.beheer.afnemer.AfnemerGridPanel;
import nl.uwv.pws.cws.views.beheer.configuratie.ConfiguratieGridPanel;
import nl.uwv.pws.cws.views.beheer.configuratie.ConfigurationAction;
import nl.uwv.pws.cws.views.beheer.contract.ContractGridPanel;
import nl.uwv.pws.cws.views.beheer.contract.ContractServiceType;
import nl.uwv.pws.cws.views.beheer.tabs.dialogs.ConfigurationDialog;
import nl.uwv.pws.cws.views.beheer.tabs.events.AfnemersSearchEvent;
import nl.uwv.pws.cws.views.beheer.tabs.events.SearchAlleAfnemersEvent;
import nl.uwv.pws.cws.views.beheer.tabs.events.SearchAlleLeveringenEvent;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.MockedStatic;
import test.common.ContractDetailsArgumentMatcher;
import test.common.StringArgumentMatcher;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Properties;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.*;

@SuppressWarnings("ALL")
public class AfnemersEnLeveringenTabTest {

   private AfnemersEnLeveringenTab tab;

   @BeforeEach
   public void setup() {
      BeheerConfiguratieView beheerConfiguratieViewMock = mock(BeheerConfiguratieView.class);
      tab = new AfnemersEnLeveringenTab(beheerConfiguratieViewMock);
   }

   @Test
   @DisplayName("AfnemersEnLeveringenTab contains all tab items")
   void testCreateAfnemersEnLeveringenTab() {
      assertThat(tab.getLabel()).isEqualTo("Afnemers en CWS Leveringen");
      assertThat(tab.getId().get()).isEqualTo("afnemers-en-cws-leveringen-tab");
      assertThat(tab.getTabParent()).isInstanceOf(BeheerConfiguratieView.class);
      assertThat(tab.getSearchBar()).isNotNull();
      assertThat(tab.getAfnemerGridPanel()).isNotNull();
      assertThat(tab.getAfnemerContractGridPanel()).isNotNull();
      assertThat(tab.getAfnemerContractGridPanel()).isNotNull();
      assertThat(tab.getLeveringGridPanel()).isNotNull();
      assertThat(tab.getLeveringContractGridPanel()).isNotNull();
      assertThat(tab.getConfiguratieGridPanel()).isNotNull();
      assertThat(tab.getNoResultsLabelAfnemerGridPanel()).isNotNull();
      assertThat(tab.getNoResultsLabelAfnemerContractGridPanel()).isNotNull();
      assertThat(tab.getButtonBar()).isNotNull();

      assertThat(tab.getAfnemerContractGridPanel().isVisible()).isFalse();
      assertThat(tab.getLeveringGridPanel().isVisible()).isFalse();
      commonAssersions();
   }

   @Test
   @DisplayName("Should select LeveringGridPanel and show/hide correct components")
   void testFindAlleLeveringen() {
      tab.findAlleLeveringen(new SearchAlleLeveringenEvent(new AfnemersSearchBar(), true));
      assertThat(tab.getSearchAction()).isEqualTo(AfnemersEnLeveringenTab.SearchAction.FIND_ALLE_LEVERINGEN);
      assertThat(tab.getLeveringGridPanel().isVisible()).isTrue();
      commonAssersions();
   }

   @Test
   @DisplayName("Should select AfnemerContractGridPanel and show/hide correct components")
   void testFindAlleAfnemers() {
      tab.findAlleAfnemers(new SearchAlleAfnemersEvent(new AfnemersSearchBar(), true));
      assertThat(tab.getSearchAction()).isEqualTo(AfnemersEnLeveringenTab.SearchAction.FIND_ALLE_AFNEMERS);
      assertThat(tab.getAfnemerContractGridPanel().isVisible()).isTrue();
      commonAssersions();
   }

   @Test
   @DisplayName("Should select AfnemerContractGridPanel by afnemer code and show/hide correct components")
   void testFindRelatedAfnemersAndContractsByAfnemerCode() {
      SearchCriteria searchCriteria = new SearchCriteria();
      searchCriteria.setAfnemerCode("code");
      tab.findRelatedAfnemersAndContracts(new AfnemersSearchEvent(new AfnemersSearchBar(), true, searchCriteria));
      assertThat(tab.getSearchAction()).isEqualTo(AfnemersEnLeveringenTab.SearchAction.FIND_BY_CRITERIA);

      commonAssersions();
   }

   @Test
   @DisplayName("Should select AfnemerContractGridPanel by contract id and show/hide correct components")
   void testFindRelatedAfnemersAndContractsByContractId() {
      SearchCriteria searchCriteria = new SearchCriteria();
      searchCriteria.setContractId("12345");
      tab.findRelatedAfnemersAndContracts(new AfnemersSearchEvent(new AfnemersSearchBar(), true, searchCriteria));
      assertThat(tab.getSearchAction()).isEqualTo(AfnemersEnLeveringenTab.SearchAction.FIND_BY_CONTRACTID);

      commonAssersions();
   }

   @Test
   @DisplayName("Should select afnemerSelected by contract id and show/hide correct components when action is FIND_BY_CRITERIA")
   void testAfnemerSelectedActionIsFindByCriteria() {
      ColumnList columnList = new ColumnList(0, new String[] { "AFN_CD", "kolom 2" }, new Object[] { "AFN_1", "value 2" });
      HasValue hasValue = mock(HasValue.class);
      when(hasValue.getValue()).thenReturn(columnList);
      ComponentValueChangeEvent event = new ComponentValueChangeEvent(mock(TextField.class) ,hasValue, null, true );

      tab.setSearchAction(AfnemersEnLeveringenTab.SearchAction.FIND_BY_CRITERIA);
      ContractGridPanel afnemerContractGridPanel = spy(new ContractGridPanel(null, null, "", ContractServiceType.CONTRACT_BY_AFNEMER));
      tab.setAfnemerContractGridPanel(afnemerContractGridPanel);
      tab.afnemerSelected(event);

      assertThat(tab.getAfnemerGridPanel().isVisible()).isTrue();
      assertThat(tab.getAfnemerContractGridPanel().isVisible()).isTrue();
      assertThat(tab.getConfiguratieGridPanel().isVisible()).isFalse();

      verify(afnemerContractGridPanel).findContractsByAfnemerCode(argThat(new StringArgumentMatcher("AFN_1")));
   }

   @Test
   @DisplayName("Should select afnemerSelected by contract id and show/hide correct components when action is FIND_ALLE_AFNEMERS")
   void testAfnemerSelectedActionIsFindAlleAfnemers() {
      ColumnList columnList = new ColumnList(0, new String[] { "AFN_CD", "kolom 2" }, new Object[] { "AFN_1", "value 2" });
      HasValue hasValue = mock(HasValue.class);
      when(hasValue.getValue()).thenReturn(columnList);
      ComponentValueChangeEvent event = new ComponentValueChangeEvent(mock(TextField.class) ,hasValue, null, true );

      tab.setSearchAction(AfnemersEnLeveringenTab.SearchAction.FIND_ALLE_AFNEMERS);
      ContractGridPanel afnemerContractGridPanel = spy(new ContractGridPanel(null, null, "", ContractServiceType.CONTRACT_BY_AFNEMER));
      tab.setAfnemerContractGridPanel(afnemerContractGridPanel);
      tab.afnemerSelected(event);

      assertThat(tab.getAfnemerGridPanel().isVisible()).isTrue();
      assertThat(tab.getAfnemerContractGridPanel().isVisible()).isTrue();
      assertThat(tab.getConfiguratieGridPanel().isVisible()).isFalse();

      verify(afnemerContractGridPanel).findContractsByAfnemerCode(argThat(new StringArgumentMatcher("AFN_1")));
   }

   @Test
   @DisplayName("Should use selected levering code to find contracts and show/hide correct components")
   void testLeveringSelected() {
      ColumnList columnList = new ColumnList(0, new String[] { "LEV_CD", "kolom 2" }, new Object[] { "LEVCD_1", "value 2" });
      HasValue hasValue = mock(HasValue.class);
      when(hasValue.getValue()).thenReturn(columnList);
      ComponentValueChangeEvent event = new ComponentValueChangeEvent(mock(TextField.class) ,hasValue, null, true );

      ContractGridPanel leveringContractGridPanel = spy(new ContractGridPanel(null, null, "", ContractServiceType.CONTRACT_BY_LEVERING));
      tab.setLeveringContractGridPanel(leveringContractGridPanel);
      tab.leveringSelected(event);

      assertThat(tab.getConfiguratieGridPanel().isVisible()).isFalse();
      assertThat(tab.getButtonBar().isVisible()).isFalse();
      assertThat(tab.getLeveringContractGridPanel().isVisible()).isTrue();

      verify(leveringContractGridPanel).findContractsByLeveringCode(argThat(new StringArgumentMatcher("LEVCD_1")));
   }

   @Test
   @DisplayName("Should use selected levering contract to find configuraties and show/hide correct components")
   void testLeveringContractSelected() {
      ColumnList columnList = new ColumnList(0, new String[] { "CONTRACT_ID", "kolom 2" }, new Object[] { new BigDecimal("123"), "value 2" });
      HasValue hasValue = mock(HasValue.class);
      when(hasValue.getValue()).thenReturn(columnList);
      ComponentValueChangeEvent event = new ComponentValueChangeEvent(mock(TextField.class) ,hasValue, null, true );

      ConfiguratieGridPanel configuratieGridPanel = spy(new ConfiguratieGridPanel(null));
      tab.setConfiguratieGridPanel(configuratieGridPanel);
      tab.leveringContractSelected(event);

      assertThat(tab.getConfiguratieGridPanel().isVisible()).isTrue();
      assertThat(tab.getButtonBar().isVisible()).isTrue();
      assertThat(tab.getModifyConfigurationButton().isEnabled()).isFalse();
      assertThat(tab.getDeleteConfigurationButton().isEnabled()).isFalse();
      assertThat(tab.getViewConfigurationButton().isEnabled()).isFalse();
      assertThat(tab.getFinalizeConfigurationButton().isEnabled()).isFalse();
      assertThat(tab.getGenerateProductSpecButton().isEnabled()).isFalse();
      assertThat(tab.getExportConfigurationButton().isEnabled()).isFalse();

      ContractDetails contractDetails = ContractDetails.builder().contractId(new BigDecimal("123")).build();
      verify(configuratieGridPanel).findConfiguratie(argThat(new ContractDetailsArgumentMatcher(contractDetails)));
   }

   @Test
   @DisplayName("Should use selected afnemer contract to find configuraties and show/hide correct components")
   void testAfnemerContractSelected() {
      ColumnList columnList = new ColumnList(0, new String[] { "AFN_CD", "CONTRACT_ID" }, new Object[] { "AFN_1", new BigDecimal("123") });
      HasValue hasValue = mock(HasValue.class);
      when(hasValue.getValue()).thenReturn(columnList);
      ComponentValueChangeEvent event = new ComponentValueChangeEvent(mock(TextField.class) ,hasValue, null, true );

      AfnemerGridPanel afnemerGridPanel = spy(new AfnemerGridPanel(null, null));
      afnemerGridPanel.setVisible(false);
      ConfiguratieGridPanel configuratieGridPanel = spy(new ConfiguratieGridPanel(null));
      configuratieGridPanel.setVisible(false);
      tab.setAfnemerGridPanel(afnemerGridPanel);
      tab.setConfiguratieGridPanel(configuratieGridPanel);
      tab.afnemerContractSelected(event);

      assertThat(tab.getAfnemerContractGridPanel().isVisible()).isTrue();
      assertThat(tab.getConfiguratieGridPanel().isVisible()).isTrue();
      assertThat(tab.getButtonBar().isVisible()).isTrue();
      assertThat(tab.getAddConfigurationButton().isEnabled()).isTrue();
      assertThat(tab.getModifyConfigurationButton().isEnabled()).isFalse();
      assertThat(tab.getDeleteConfigurationButton().isEnabled()).isFalse();
      assertThat(tab.getViewConfigurationButton().isEnabled()).isFalse();
      assertThat(tab.getFinalizeConfigurationButton().isEnabled()).isFalse();
      assertThat(tab.getGenerateProductSpecButton().isEnabled()).isFalse();
      assertThat(tab.getExportConfigurationButton().isEnabled()).isFalse();

      ContractDetails contractDetails = ContractDetails.builder().contractId(new BigDecimal("123")).build();
      verify(configuratieGridPanel).findConfiguratie(argThat(new ContractDetailsArgumentMatcher(contractDetails)));
   }

   @Test
   @DisplayName("Should use selected configuratie and show/hide correct components")
   void testConfiguratieSelectedStatusConcept() {
      ColumnList columnList = new ColumnList(0, new String[] { "CCON_ID", "VERSION", "STATUS" }, new Object[] { new BigDecimal("12345"), new BigDecimal("7"), "CO" });
      HasValue hasValue = mock(HasValue.class);
      when(hasValue.getValue()).thenReturn(columnList);
      ComponentValueChangeEvent event = new ComponentValueChangeEvent(mock(TextField.class) ,hasValue, null, true );

      ConfiguratieGridPanel configuratieGridPanel = spy(new ConfiguratieGridPanel(null));
      tab.setConfiguratieGridPanel(configuratieGridPanel);
      tab.getAppiConfigService().setProps(new Properties());
      tab.setContractDetails(createContractDetails());
      tab.setGenerateProductSpecLink(mock(Anchor.class));
      tab.setExportProductSpecLink(mock(Anchor.class));
      tab.configuratieSelected(event);

      assertThat(tab.getModifyConfigurationButton().isEnabled()).isTrue();
      assertThat(tab.getGenerateProductSpecButton().isEnabled()).isTrue();
      assertThat(tab.getExportConfigurationButton().isEnabled()).isTrue();
      assertThat(tab.getViewConfigurationButton().isEnabled()).isTrue();
      assertThat(tab.getFinalizeConfigurationButton().isEnabled()).isTrue();
      assertThat(tab.getDeleteConfigurationButton().isEnabled()).isTrue();
      assertThat(configuratieGridPanel.getPreSelectedColumnList().getId()).isEqualTo(columnList.getId());
      assertThat(configuratieGridPanel.getPreSelectedColumnList().getValue("CCON_ID")).isEqualTo(columnList.getValue("CCON_ID"));
      assertThat(configuratieGridPanel.getPreSelectedColumnList().getValue("VERSION")).isEqualTo(columnList.getValue("VERSION"));
      assertThat(configuratieGridPanel.getPreSelectedColumnList().getValue("STATUS")).isEqualTo(columnList.getValue("STATUS"));
   }


   @Test
   @DisplayName("Should set finalize and delete button disabled when configuratie status is Definitief ")
   void testConfiguratieSelectedStatusDefinitief() {
      ColumnList columnList = new ColumnList(0, new String[]{"CCON_ID", "VERSION", "STATUS"}, new Object[]{new BigDecimal("12345"), new BigDecimal("7"), "DE"});
      HasValue hasValue = mock(HasValue.class);
      when(hasValue.getValue()).thenReturn(columnList);
      ComponentValueChangeEvent event = new ComponentValueChangeEvent(mock(TextField.class), hasValue, null, true);

      ConfiguratieGridPanel configuratieGridPanel = spy(new ConfiguratieGridPanel(null));
      tab.setConfiguratieGridPanel(configuratieGridPanel);
      tab.setContractDetails(createContractDetails());
      tab.getAppiConfigService().setProps(new Properties());
      tab.setGenerateProductSpecLink(mock(Anchor.class));
      tab.setExportProductSpecLink(mock(Anchor.class));
      tab.configuratieSelected(event);

      assertThat(tab.getModifyConfigurationButton().isEnabled()).isTrue();
      assertThat(tab.getGenerateProductSpecButton().isEnabled()).isTrue();
      assertThat(tab.getExportConfigurationButton().isEnabled()).isTrue();
      assertThat(tab.getViewConfigurationButton().isEnabled()).isTrue();
      assertThat(tab.getFinalizeConfigurationButton().isEnabled()).isFalse();
      assertThat(tab.getDeleteConfigurationButton().isEnabled()).isFalse();
      assertThat(configuratieGridPanel.getPreSelectedColumnList().getId()).isEqualTo(columnList.getId());
      assertThat(configuratieGridPanel.getPreSelectedColumnList().getValue("CCON_ID")).isEqualTo(columnList.getValue("CCON_ID"));
      assertThat(configuratieGridPanel.getPreSelectedColumnList().getValue("VERSION")).isEqualTo(columnList.getValue("VERSION"));
      assertThat(configuratieGridPanel.getPreSelectedColumnList().getValue("STATUS")).isEqualTo(columnList.getValue("STATUS"));
   }

   @Test
   @DisplayName("Should reset the pre selected columList ")
   void testResetSelectedConfiguratie() {
      ConfiguratieGridPanel configuratieGridPanel = new ConfiguratieGridPanel(null);
      tab.setConfiguratieGridPanel(configuratieGridPanel);
      tab.resetSelectedConfiguratie();

      assertThat(configuratieGridPanel.getPreSelectedColumnList()).isNull();
   }

   @Test
   @DisplayName("Should not display label no result found for afnemer grid")
   void testAfnemerRowsCountedNoResult() {
      tab.setSearchAction(null);
      tab.afnemerRowsCounted(0);

      assertThat(tab.getNoResultsLabelAfnemerGridPanel().isVisible()).isFalse();
   }

   @Test
   @DisplayName("Should display label no result found for afnemer grid")
   void testAfnemerRowsCountedFoundResult() {
      tab.setSearchAction(AfnemersEnLeveringenTab.SearchAction.FIND_BY_CRITERIA);
      tab.getAfnemerGridPanel().setSearchPerformed(true);
      tab.afnemerRowsCounted(0);

      assertThat(tab.getNoResultsLabelAfnemerGridPanel().isVisible()).isTrue();
   }

   @Test
   @DisplayName("Should not display label no result found for contract grid")
   void testContractRowsCountedNoResult() {
      tab.setSearchAction(null);
      tab.afnemerRowsCounted(0);

      assertThat(tab.getNoResultsLabelAfnemerContractGridPanel().isVisible()).isFalse();
   }

   @Test
   @DisplayName("Should display label no result found for contract grid")
   void testContractRowsCountedFoundResult() {
      tab.setSearchAction(AfnemersEnLeveringenTab.SearchAction.FIND_BY_CONTRACTID);
      tab.getAfnemerContractGridPanel().setSearchPerformed(true);
      tab.afnemerContractRowsCounted(0);

      assertThat(tab.getNoResultsLabelAfnemerContractGridPanel().isVisible()).isTrue();
   }

   @Test
   @DisplayName("Should create configuration and open a dialog set the ConfigurationAction to ADD")
   void testAddConfiguration() {
      try (MockedStatic<CwsUIUtils> cwsUIUtilsStaticMock = mockStatic(CwsUIUtils.class)) {
         ConfigurationDialog configurationDialog = mock(ConfigurationDialog.class);
         cwsUIUtilsStaticMock.when(() -> CwsUIUtils.createConfigurationDialog()).thenReturn(configurationDialog);

         ContractDetails contractDetails = createContractDetails();
         tab.setContractDetails(contractDetails);
         tab.addConfiguration();

         verify(configurationDialog, times(1)).configureDialog(any(CwsConfiguration.class), eq(ConfigurationAction.ADD));
         verify(configurationDialog, times(1)).hideCancelButton();
         verify(configurationDialog, times(1)).open();
         verify(configurationDialog, times(1)).addCloseListener(ArgumentMatchers.any());
      }
   }

   @Test
   @DisplayName("Should create configuration dialog call open and set the ConfigurationAction to MODIFY")
   void testModifyConfiguration() {
      try (MockedStatic<CwsUIUtils> cwsUIUtilsStaticMock = mockStatic(CwsUIUtils.class)) {
         ConfigurationDialog configurationDialog = mock(ConfigurationDialog.class);
         cwsUIUtilsStaticMock.when(() -> CwsUIUtils.createConfigurationDialog()).thenReturn(configurationDialog);

         tab.setConfigurationDetails(createConfigurationDetails());
         tab.setContractDetails(createContractDetails());
         tab.modifyConfiguration();

         verify(configurationDialog, times(1)).configureDialog(any(CwsConfiguration.class), eq(ConfigurationAction.MODIFY));
         verify(configurationDialog, times(1)).hideCancelButton();
         verify(configurationDialog, times(1)).open();
         verify(configurationDialog, times(1)).addCloseListener(ArgumentMatchers.any());
      }
   }

   @Test
   @DisplayName("Should create configuration dialog call open and the ConfigurationAction to VIEW")
   void testViewConfiguration() {
      try (MockedStatic<CwsUIUtils> cwsUIUtilsStaticMock = mockStatic(CwsUIUtils.class)) {
         ConfigurationDialog configurationDialog = mock(ConfigurationDialog.class);
         cwsUIUtilsStaticMock.when(() -> CwsUIUtils.createConfigurationDialog()).thenReturn(configurationDialog);

         tab.setConfigurationDetails(createConfigurationDetails());
         tab.setContractDetails(createContractDetails());
         tab.viewConfiguration();

         verify(configurationDialog, times(1)).configureDialog(any(CwsConfiguration.class), eq(ConfigurationAction.VIEW));
         verify(configurationDialog, times(1)).hideCancelButton();
         verify(configurationDialog, times(1)).open();
      }
   }

   private ContractDetails createContractDetails(){
      return ContractDetails.builder()
            .afnemerCode("afnCd")
            .afnemerNaam("afnNaam")
            .contractId(new BigDecimal("12345"))
            .contractStartDate(LocalDate.of(2021,6,8))
            .contractEndDate(LocalDate.of(2022,6,8))
            .leverCode("levCd")
            .build();
   }

   private ConfigurationDetails createConfigurationDetails(){
      return ConfigurationDetails.builder()
            .configurationId(new BigDecimal("456"))
            .configurationVersion(BigDecimal.ONE)
            .configurationStatus("CO")
            .build();
   }

   private void commonAssersions() {
      assertThat(tab.getNoResultsLabelAfnemerGridPanel().isVisible()).isFalse();
      assertThat(tab.getNoResultsLabelAfnemerContractGridPanel().isVisible()).isFalse();
      assertThat(tab.getButtonBar().isVisible()).isFalse();
      assertThat(tab.getAfnemerGridPanel().isVisible()).isFalse();
      assertThat(tab.getLeveringContractGridPanel().isVisible()).isFalse();
      assertThat(tab.getConfiguratieGridPanel().isVisible()).isFalse();
      assertThat(tab.getConfiguratieGridPanel().getPreSelectedColumnList()).isNull();
   }
}
