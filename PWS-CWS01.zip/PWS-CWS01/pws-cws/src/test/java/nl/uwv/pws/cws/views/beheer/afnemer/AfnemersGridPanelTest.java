package nl.uwv.pws.cws.views.beheer.afnemer;

import com.vaadin.flow.component.AbstractField.ComponentValueChangeEvent;
import com.vaadin.flow.component.HasValue.ValueChangeListener;
import com.vaadin.flow.component.grid.Grid;
import nl.uwv.pws.backend.service.CountRowsListener;
import nl.uwv.pws.backend.types.ColumnList;
import nl.uwv.pws.cws.model.SearchCriteria;
import nl.uwv.pws.cws.util.Constants;
import nl.uwv.pws.cws.views.AfnemersSearchBar;
import nl.uwv.pws.cws.views.beheer.tabs.events.AfnemersSearchEvent;
import nl.uwv.pws.ui.util.QueryLogger;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import test.common.SqlFilterArgumentMatcher;

import javax.sql.DataSource;
import java.util.Arrays;
import java.util.List;

import static org.mockito.Mockito.*;


public class AfnemersGridPanelTest {

   private AfnemerGridPanel spyAfnemerGridPanel;

   @BeforeEach
   public void setup(){
      ValueChangeListener<ComponentValueChangeEvent<Grid<ColumnList>, ColumnList>> valueChangeListener = mock(ValueChangeListener.class);
      CountRowsListener countRowsListener = mock(CountRowsListener.class);
      spyAfnemerGridPanel = spy(new AfnemerGridPanel(valueChangeListener, countRowsListener));
   }

   @Test
   @DisplayName("Given a call to findAlleAfnemers, should use the correct filter")
   void findAlleAfnemers() {
      spyAfnemerGridPanel.findAlleAfnemers();

      verify(spyAfnemerGridPanel).search(argThat(new SqlFilterArgumentMatcher(new AfnemerByAfnemerFieldsFilter())));
   }

   @Test
   @DisplayName("Given a call to findAfnemersByCriteria, should use the correct filter")
   void findAfnemersByCriteria() {
      AfnemersSearchBar afnemersSearchBar = mock(AfnemersSearchBar.class);
      spyAfnemerGridPanel.findAfnemersByCriteria(new AfnemersSearchEvent(afnemersSearchBar, false, new SearchCriteria()));

      AfnemersSearchEvent afnemersSearchEvent = new AfnemersSearchEvent(afnemersSearchBar, false,  new SearchCriteria());
      verify(spyAfnemerGridPanel).search(argThat(new SqlFilterArgumentMatcher(new AfnemerByAfnemerFieldsFilter(afnemersSearchEvent))));
   }

   @Test
   @DisplayName("Given a call to findAfnemersByAfnemerCode, should use the correct filter")
   void findAfnemersByAfnemerCode() {
      spyAfnemerGridPanel.findAfnemersByAfnemerCode("afn_code");
      verify(spyAfnemerGridPanel).search(argThat(new SqlFilterArgumentMatcher(new AfnemerByAfnemerFieldsFilter("afn_code"))));
   }

   @Test
   @DisplayName("Given rows found, for each afnemer QueryLogger should be called using the afnemercode")
   void testQueryLoggerIsCalledForEachLhnrAndAfnCode() {
      DataSource mockDataSource = mock(DataSource.class);
      AfnemerService afnemersService = new AfnemerService(Constants.DS_NAME) {
         @Override
         protected DataSource getDataSource() {
            return mockDataSource;
         }
      };
      AfnemerGridPanel afnemerGridPanel = new AfnemerGridPanel(event -> { }, event -> { });

      List<ColumnList> rows = Arrays.asList(mock(ColumnList.class), mock(ColumnList.class));

      // Mock QueryLogger::getInstance and make sure it returns a mock QueryLogger
      try (MockedStatic<QueryLogger> queryLoggerStaticMock = mockStatic(QueryLogger.class)) {
         QueryLogger queryLoggerMock = mock(QueryLogger.class);
         queryLoggerStaticMock.when(QueryLogger::getInstance).thenReturn(queryLoggerMock);

         afnemerGridPanel.onRowsFetched(rows);

         // Verify that for each  afnemer code, the (mock) QueryLogger is called
         verify(queryLoggerMock).callQueryLog(QueryLogger.LogType.AFN_AFNCD, rows.get(0), AfnemerColumn.AFN_CD);
         verify(queryLoggerMock).callQueryLog(QueryLogger.LogType.AFN_AFNCD, rows.get(1), AfnemerColumn.AFN_CD);
      }
   }
}
