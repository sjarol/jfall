package nl.uwv.pws.cws.util;

import nl.uwv.pws.cws.exception.FormValidationException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.HashSet;

import static org.assertj.core.api.Assertions.assertThat;

public class ValidatorTest {

   private Validator validator;

   @BeforeEach
   public void setup() {
      validator = new Validator();
   }

   @Test
   @DisplayName("Should validate configurationBeginDate is before contractStartDate")
   void testValidateAfnemerConfiguratiePeriodConfigurationStartDate() {
      final LocalDate contractStartDate = LocalDate.of(2021, 6, 1);
      final LocalDate configurationBeginDate = LocalDate.of(2020, 7, 1);
      Exception exception = Assertions.assertThrows(FormValidationException.class, () -> {
         validator.validateAfnemerConfiguratiePeriod(contractStartDate, null, configurationBeginDate, null);
      });

      String expectedMessage = "Begindatum configuratie mag niet voor begindatum contract liggen";
      String actualMessage = exception.getMessage();

      assertThat(actualMessage).isEqualTo(expectedMessage);
   }

   @Test
   @DisplayName("Should validate configurationBeginDate is after contractEndDate")
   void testValidateAfnemerConfiguratiePeriodConfigurationEndDate() {
      final LocalDate contractStartDate = LocalDate.of(2020, 6, 1);
      final LocalDate contractEndDate = LocalDate.of(2021, 6, 1);
      final LocalDate configurationBeginDate = LocalDate.of(2022, 7, 1);
      Exception exception = Assertions.assertThrows(FormValidationException.class, () -> {
         validator.validateAfnemerConfiguratiePeriod(contractStartDate, contractEndDate, configurationBeginDate, null);
      });

      String expectedMessage = "Begindatum configuratie mag niet na einddatum contract liggen";
      String actualMessage = exception.getMessage();

      assertThat(actualMessage).isEqualTo(expectedMessage);
   }

   @Test
   @DisplayName("Should validate configurationEndDate is before contractEndDate")
   void testValidateAfnemerConfiguratiePeriodContractEndDate() {
      final LocalDate contractStartDate = LocalDate.of(2020, 6, 1);
      final LocalDate contractEndDate = LocalDate.of(2021, 6, 1);
      final LocalDate configurationBeginDate = LocalDate.of(2021, 1, 1);
      final LocalDate configurationEndDate = LocalDate.of(2022, 7, 1);
      Exception exception = Assertions.assertThrows(FormValidationException.class, () -> {
         validator.validateAfnemerConfiguratiePeriod(contractStartDate, contractEndDate, configurationBeginDate, configurationEndDate);
      });

      String expectedMessage = "Einddatum configuratie mag niet na einddatum contract liggen";
      String actualMessage = exception.getMessage();

      assertThat(actualMessage).isEqualTo(expectedMessage);
   }

   @Test
   @DisplayName("Should validate configurationBeginDate is before configurationEndDate")
   void testValidateAfnemerConfiguratiePeriodConfigurationBeginAndEndDate() {
      final LocalDate contractStartDate = LocalDate.of(2020, 6, 1);
      final LocalDate contractEndDate = LocalDate.of(2021, 6, 1);
      final LocalDate configurationBeginDate = LocalDate.of(2020, 7, 2);
      final LocalDate configurationEndDate = LocalDate.of(2020, 7,1);
      Exception exception = Assertions.assertThrows(FormValidationException.class, () -> {
         validator.validateAfnemerConfiguratiePeriod(contractStartDate, contractEndDate, configurationBeginDate, configurationEndDate);
      });

      String expectedMessage = "Einddatum configuratie mag niet voor begindatum configuratie liggen";
      String actualMessage = exception.getMessage();

      assertThat(actualMessage).isEqualTo(expectedMessage);
   }

   @Test
   @DisplayName("Validate at least one attribute is selected")
   void testvalidateAtLeastOneAttributeChecked() {
      Exception exception = Assertions.assertThrows(FormValidationException.class, () -> {
         validator.validateAtLeastOneAttributeChecked(new HashSet<>());
      });

      String expectedMessage = "Selecteer minstens één attribuut";
      String actualMessage = exception.getMessage();

      assertThat(actualMessage).isEqualTo(expectedMessage);
   }
}
