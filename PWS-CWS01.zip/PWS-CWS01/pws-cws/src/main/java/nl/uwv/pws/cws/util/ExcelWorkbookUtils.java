package nl.uwv.pws.cws.util;

import nl.uwv.pws.cws.model.OverviewGridData;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.util.List;
import java.util.Set;
import java.util.stream.IntStream;

public class ExcelWorkbookUtils {

   public static CellStyle createConfigurationHeaderCellStyle(final XSSFWorkbook workbook){
      CellStyle cellStyle = workbook.createCellStyle();
      cellStyle.setFillForegroundColor(IndexedColors.WHITE.getIndex());
      cellStyle.setAlignment(HorizontalAlignment.CENTER);
      Font font = workbook.createFont();
      font.setBold(true);
      font.setFontHeightInPoints((short)15);
      font.setColor(IndexedColors.BLUE.getIndex());
      cellStyle.setFont(font);

      return cellStyle;
   }

   public static CellStyle createResultHeader(final XSSFWorkbook workbook){
      CellStyle cellStyle = workbook.createCellStyle();
      Font fontBold = workbook.createFont();
      fontBold.setBold(true);
      cellStyle.setFont(fontBold);

      return cellStyle;
   }

   public static void addHeaderCellsToRow(final Set<String> headers, final XSSFRow row, final CellStyle cellStyle){
      int headerCellIndex = 0;
      for (String header : headers) {
         Cell cell = row.createCell(headerCellIndex++);
         cell.setCellValue(header);
         cell.setCellStyle(cellStyle);
      }
   }

   public static Integer createConfigurationHeader(final XSSFSheet spreadsheet, final CellStyle cellStyle, final Integer itemSize, final Integer headerLength){
      int rowIndex = 0;
      XSSFRow row = spreadsheet.createRow(rowIndex++);
      Cell cell2 = row.createCell( 0);
      cell2.setCellValue(String.format("Configuratie(s) (%d)", itemSize));
      cell2.setCellStyle(cellStyle);
      spreadsheet.createRow(rowIndex++);

      spreadsheet.addMergedRegion(new CellRangeAddress(
            0, //first row (0-based)
            1, //last row  (0-based)
            0, //first column (0-based)
            headerLength - 1  //last column  (0-based)
      ));

      return rowIndex;
   }

   public static void processResultToSheet(final XSSFWorkbook workbook, final XSSFSheet spreadsheet,
                                         final List<OverviewGridData> items, final Integer nextRowIndex){
      int rowIndex = nextRowIndex;

      final OverviewGridData OverviewGridDataHeaders = items.listIterator().next();
      final Set<String> headers = OverviewGridDataHeaders.getValues().keySet();

      XSSFRow headerRow = spreadsheet.createRow(rowIndex++);
      CellStyle styleBold = createResultHeader(workbook);
      addHeaderCellsToRow(headers, headerRow, styleBold);

      for(OverviewGridData overviewGridData : items){
         Set<String> keyid  = overviewGridData.getValues().keySet();
         final XSSFRow overviewGridDataRow = spreadsheet.createRow(rowIndex++);

         int cellIndex = 0;
         for (String key : keyid) {
            Object objectValue = overviewGridData.get(key);

            Cell cell = overviewGridDataRow.createCell(cellIndex++);
            if (objectValue != null) {
               cell.setCellValue(objectValue.toString());
            }
         }
      }

      resizeHeaderCellLength(spreadsheet, headers.size());
   }

   public static void resizeHeaderCellLength(final XSSFSheet spreadsheet, final Integer headerLength){
      IntStream.range(0, headerLength).forEach(spreadsheet::autoSizeColumn);
   }
}
