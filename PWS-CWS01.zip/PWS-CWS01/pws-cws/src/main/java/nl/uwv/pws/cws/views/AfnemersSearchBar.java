package nl.uwv.pws.cws.views;

import com.vaadin.flow.component.Key;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.textfield.Autocomplete;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.binder.Binder;
import com.vaadin.flow.data.binder.ValidationResult;
import lombok.Getter;
import lombok.Setter;
import nl.uwv.pws.cws.model.SearchCriteria;
import nl.uwv.pws.cws.validator.OnlyNumberValidator;
import nl.uwv.pws.cws.views.beheer.common.BaseCwsVerticalLayout;
import nl.uwv.pws.cws.views.beheer.tabs.events.AfnemersSearchEvent;
import nl.uwv.pws.cws.views.beheer.tabs.events.SearchAlleAfnemersEvent;
import nl.uwv.pws.cws.views.beheer.tabs.events.SearchAlleLeveringenEvent;
import nl.uwv.pws.cws.views.beheer.tabs.events.ValidationFailedEvent;
import nl.uwv.pws.ui.components.FlexBoxLayout;
import nl.uwv.pws.ui.components.Tooltip;
import nl.uwv.pws.ui.components.ValidationLabel;
import nl.uwv.pws.ui.layout.size.Right;
import nl.uwv.pws.ui.util.UIUtils;
import nl.uwv.pws.ui.validator.AtLeastOneValueValidator;

import static nl.uwv.pws.cws.util.Constants.*;

@Setter
@Getter
public final class AfnemersSearchBar extends BaseCwsVerticalLayout {

   private static final String AFNEMER_CODE_PLACEHOLDER = "Afnemer Code";
   private static final String AFNEMER_NAAM_PLACEHOLDER = "Afnemer Naam";
   private static final String UGC_ID_PLACEHOLDER = "UGC Id";
   private static final String CONTRACT_ID_PLACEHOLDER = "Contract Id";

   private static final int AFNEMER_CODE_MAX_LENGTH = 8;
   private static final int AFNEMER_NAAM_MAX_LENGTH = 200;
   private static final int UGC_ID_MAX_LENGTH = 10;
   private static final int CONTRACT_ID_MAX_LENGTH = 10;

   private final SearchCriteria searchCriteria = new SearchCriteria();
   private final Binder<SearchCriteria> binder;

   private final ValidationLabel validationLabel;
   private final AtLeastOneValueValidator<SearchCriteria> atLeastOneValueValidator;
   private final OnlyNumberValidator contractIdOnlyNumberValidator;
   private final OnlyNumberValidator ugcIdOnlyNumberValidator;

   public AfnemersSearchBar() {
      setWidthFull();

      FlexBoxLayout searchLayout = new FlexBoxLayout();
      searchLayout.setWidthFull();

      searchLayout.setSpacing(Right.S);

      // Flex direction == row: Alignment works vertically, justify horizontally
      searchLayout.setAlignItems(Alignment.BASELINE);
      searchLayout.setJustifyContentMode(JustifyContentMode.START);

      binder = new Binder<>();
      binder.setBean(searchCriteria);
      atLeastOneValueValidator = new AtLeastOneValueValidator<>(
            "Een ingevuld zoekveld is verplicht",
            searchCriteria::getAfnemerCode, searchCriteria::getAfnemerNaam, searchCriteria::getUgcId, searchCriteria::getContractId
      );
      contractIdOnlyNumberValidator = new OnlyNumberValidator("Contract Id mag alleen cijfers bevatten");
      ugcIdOnlyNumberValidator = new OnlyNumberValidator("UGC Id mag alleen cijfers bevatten");

      searchLayout.add(createUgcIdSearchField(binder));
      searchLayout.add(createContractIdSearchField(binder));
      searchLayout.add(createAfnemerCodeSearchField(binder));
      searchLayout.add(createAfnemerNaamSearchField(binder));

      searchLayout.add(createSearchButton());
      searchLayout.add(createAlleAfnemersButton());
      searchLayout.add(createAlleCwsLeveringenButton());

      // Add the searchLayout on the top
      add(searchLayout);

      // Add the ValidationLabel below
      validationLabel = new ValidationLabel(binder);
      add(validationLabel);
   }

   private TextField createAfnemerCodeSearchField(final Binder<SearchCriteria> binder) {
      TextField afnemerCodeSearchField = new TextField();
      afnemerCodeSearchField.setId(COMPONENT_ID_AFNEMERCODE_TEXT_FIELD);
      afnemerCodeSearchField.setPlaceholder(AFNEMER_CODE_PLACEHOLDER);
      afnemerCodeSearchField.setWidth(TWAALF_EM);
      afnemerCodeSearchField.setHeight(TWEEENEENHALF_EM);
      afnemerCodeSearchField.setAutocomplete(Autocomplete.OFF);
      afnemerCodeSearchField.setTitle("Filter afnemers op afnemer code");
      afnemerCodeSearchField.setMaxLength(AFNEMER_CODE_MAX_LENGTH);
      afnemerCodeSearchField.setClearButtonVisible(true);
      binder.forField(afnemerCodeSearchField)
            .withNullRepresentation("")
            .bind(SearchCriteria::getAfnemerCode, SearchCriteria::setAfnemerCode);
      afnemerCodeSearchField.focus();
      return afnemerCodeSearchField;
   }

   private TextField createAfnemerNaamSearchField(final Binder<SearchCriteria> binder) {
      TextField afnemerNaamSearchField = new TextField();
      afnemerNaamSearchField.setId(COMPONENT_ID_AFNEMERNAAM_TEXT_FIELD);
      afnemerNaamSearchField.setPlaceholder(AFNEMER_NAAM_PLACEHOLDER);
      afnemerNaamSearchField.setWidth(TWAALF_EM);
      afnemerNaamSearchField.setHeight(TWEEENEENHALF_EM);
      afnemerNaamSearchField.setAutocomplete(Autocomplete.OFF);
      afnemerNaamSearchField.setTitle("Filter afnemers op naam");
      afnemerNaamSearchField.setMaxLength(AFNEMER_NAAM_MAX_LENGTH);
      afnemerNaamSearchField.setClearButtonVisible(true);
      binder.forField(afnemerNaamSearchField)
            .withNullRepresentation("")
            .bind(SearchCriteria::getAfnemerNaam, SearchCriteria::setAfnemerNaam);
      return afnemerNaamSearchField;
   }

   public TextField createUgcIdSearchField(final Binder<SearchCriteria> binder) {
      TextField ugcIdSearchField = new TextField();
      ugcIdSearchField.setId(COMPONENT_ID_UGCID_TEXT_FIELD);
      ugcIdSearchField.setPlaceholder(UGC_ID_PLACEHOLDER);
      ugcIdSearchField.setWidth(TWAALF_EM);
      ugcIdSearchField.setHeight(TWEEENEENHALF_EM);
      ugcIdSearchField.setAutocomplete(Autocomplete.OFF);
      ugcIdSearchField.setTitle("Filter afnemers op UGC ID");
      ugcIdSearchField.setMaxLength(UGC_ID_MAX_LENGTH);
      ugcIdSearchField.setClearButtonVisible(true);

      binder.forField(ugcIdSearchField)
            .withNullRepresentation("")
            .bind(SearchCriteria::getUgcId, SearchCriteria::setUgcId);
      return ugcIdSearchField;
   }

   public TextField createContractIdSearchField(final Binder<SearchCriteria> binder) {
      TextField contractIdSearchField = new TextField();
      contractIdSearchField.setId(COMPONENT_ID_CONTRACTID_TEXT_FIELD);
      contractIdSearchField.setPlaceholder(CONTRACT_ID_PLACEHOLDER);
      contractIdSearchField.setWidth(TWAALF_EM);
      contractIdSearchField.setHeight(TWEEENEENHALF_EM);
      contractIdSearchField.setAutocomplete(Autocomplete.OFF);
      contractIdSearchField.setTitle("Filter afnemers op Contract Id");
      contractIdSearchField.setMaxLength(CONTRACT_ID_MAX_LENGTH);
      contractIdSearchField.setClearButtonVisible(true);
      binder.forField(contractIdSearchField)
            .withNullRepresentation("")
            .bind(SearchCriteria::getContractId, SearchCriteria::setContractId);
      return contractIdSearchField;
   }

   public Button createSearchButton() {
      Button searchButton = UIUtils.createPrimaryButton("Zoek", VaadinIcon.SEARCH);
      searchButton.setId(COMPONENT_ID_ZOEKEN_BUTTON);
      searchButton.addClickShortcut(Key.ENTER);

      searchButton.addClickListener(clickEvent -> {
         ValidationResult atLeastOneValueResult = atLeastOneValueValidator.apply(searchCriteria, null);
         ValidationResult contractIdOnlyNumberResult = contractIdOnlyNumberValidator.apply(searchCriteria.getContractId(), null);
         ValidationResult ugcIdOnlyNumberResult = ugcIdOnlyNumberValidator.apply(searchCriteria.getUgcId(), null);
         if (!atLeastOneValueResult.isError() && !contractIdOnlyNumberResult.isError() && !ugcIdOnlyNumberResult.isError()) {
            fireEvent(new AfnemersSearchEvent(this, clickEvent.isFromClient(), binder.getBean()));
         } else {
            if (ugcIdOnlyNumberResult.isError()) {
               validationLabel.setText(ugcIdOnlyNumberResult.getErrorMessage());
            }
            if (contractIdOnlyNumberResult.isError()) {
               validationLabel.setText(contractIdOnlyNumberResult.getErrorMessage());
            }
            if (atLeastOneValueResult.isError()) {
               validationLabel.setText(atLeastOneValueResult.getErrorMessage());
            }
            fireEvent(new ValidationFailedEvent(this, clickEvent.isFromClient()));
         }
      });

      return searchButton;
   }

   public Button createAlleAfnemersButton() {
      Button alleAfnemersButton = UIUtils.createButton(ALLE_AFNEMERS_CAPTION, ButtonVariant.LUMO_TERTIARY_INLINE);
      alleAfnemersButton.addClassName("cws-button-link");
      alleAfnemersButton.setId(COMPONENT_ID_ZOEKEN_CWS_AFNEMERS_BUTTON);
      alleAfnemersButton.addClickListener(clickEvent -> {
         clearFieldsAndRebindBean(searchCriteria);
         fireEvent(new SearchAlleAfnemersEvent(this, clickEvent.isFromClient()));
      });

      add(alleAfnemersButton);
      return alleAfnemersButton;
   }

   private Button createAlleCwsLeveringenButton() {
      Button alleCwsLeveringenButton = UIUtils.createButton(ALLE_CWS_LEVERINGEN_CAPTION, ButtonVariant.LUMO_TERTIARY_INLINE);
      alleCwsLeveringenButton.addClassName("cws-button-link");
      alleCwsLeveringenButton.setId(COMPONENT_ID_ZOEKEN_CWS_LEVERINGEN_BUTTON);

      alleCwsLeveringenButton.addClickListener(clickEvent -> {
         clearFieldsAndRebindBean(searchCriteria);
         fireEvent(new SearchAlleLeveringenEvent(this, clickEvent.isFromClient()));
      });

      Tooltip tooltip = Tooltip.builder()
            .forComponent(alleCwsLeveringenButton)
            .withBody("Let op: zijn alleen de CWS leveringen die een afnemer gekoppeld hebben")
            .withPosition(Tooltip.Position.RIGHT).build();

      add(alleCwsLeveringenButton, tooltip);
      return alleCwsLeveringenButton;
   }

   private void clearFieldsAndRebindBean(final SearchCriteria searchCriteria) {
      searchCriteria.setAfnemerCode(null);
      searchCriteria.setAfnemerNaam(null);
      searchCriteria.setUgcId(null);
      searchCriteria.setContractId(null);

      binder.readBean(searchCriteria);
   }
}
