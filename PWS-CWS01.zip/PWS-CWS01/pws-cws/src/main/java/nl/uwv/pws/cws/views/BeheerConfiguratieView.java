package nl.uwv.pws.cws.views;

import com.vaadin.flow.component.AttachEvent;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.tabs.Tabs;
import com.vaadin.flow.router.HasDynamicTitle;
import com.vaadin.flow.router.Route;
import nl.uwv.pws.backend.dao.AuthorizationType;
import nl.uwv.pws.cws.ApplicationInfo;
import nl.uwv.pws.cws.views.beheer.tabs.AfnemersEnLeveringenTab;
import nl.uwv.pws.cws.views.beheer.tabs.OverzichtCwsConfiguratiesTab;
import nl.uwv.pws.cws.views.beheer.tabs.TabView;
import nl.uwv.pws.ui.MainLayout;
import nl.uwv.pws.ui.components.navigation.bar.AppBar;
import nl.uwv.pws.ui.util.AuthorizedComponent;
import nl.uwv.pws.ui.util.AuthorizedView;
import nl.uwv.pws.ui.util.PageMenuCode;
import nl.uwv.pws.ui.views.ViewFrame;

/**
 * Main PWS-09 View.
 */
@Route(value = "ui/cws-config", layout = MainLayout.class)
@PageMenuCode("PWS09")
@AuthorizedView("Beheer CWS Configuratie")
@CssImport("./styles/pws-cws.css")
public class BeheerConfiguratieView extends ViewFrame implements HasDynamicTitle {
   private static final String APP_BAR_ID = "app-bar-beheerconfiguratie";

   @AuthorizedComponent(value = "Afnemers en CWS Leveringen", type = AuthorizationType.TAB)
   private AfnemersEnLeveringenTab afnemersEnLeveringenTab;

   @AuthorizedComponent(value = "Overzicht CWS Configuraties", type = AuthorizationType.TAB)
   private OverzichtCwsConfiguratiesTab overzichtCwsConfiguratiesTab;

   public BeheerConfiguratieView() {
      afnemersEnLeveringenTab = new AfnemersEnLeveringenTab(this);
      overzichtCwsConfiguratiesTab = new OverzichtCwsConfiguratiesTab(this);
   }

   @Override
   protected void onAttachView(final AttachEvent attachEvent) {
      initAppBar();
   }

   private void initAppBar() {
      AppBar appBar = MainLayout.get().getAppBar();
      appBar.setId(APP_BAR_ID);
      appBar.setAppInfo(new ApplicationInfo());
      appBar.addTabSelectionListener(this::tabSelectionChanged);
      appBar.addTab(afnemersEnLeveringenTab);
      appBar.addTab(overzichtCwsConfiguratiesTab);

      appBar.setHelp(
            "/help/Handleiding_PWS09_Beheer_CWS_Configuratie_bij_Afnemer.pdf",
            "Handleiding PWS09 Beheer CWS Configuration bij Afnemer"
      );
   }

   private void tabSelectionChanged(final Tabs.SelectedChangeEvent e) {
      TabView tabView = (TabView) e.getSelectedTab();

      setViewHeader(tabView.getViewHeader());
      setViewContent(tabView.getViewContent());
   }
}
