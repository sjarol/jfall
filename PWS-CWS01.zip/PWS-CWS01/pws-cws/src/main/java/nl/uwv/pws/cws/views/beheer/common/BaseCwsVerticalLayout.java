package nl.uwv.pws.cws.views.beheer.common;

import com.vaadin.flow.component.ComponentEvent;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.shared.Registration;
import nl.uwv.pws.ui.layout.FullVerticalLayout;

public abstract class BaseCwsVerticalLayout extends FullVerticalLayout {

   @Override
   public <T extends ComponentEvent<?>> Registration addListener(Class<T> eventType,
                                                                 ComponentEventListener<T> listener) {
      return getEventBus().addListener(eventType, listener);
   }
}
