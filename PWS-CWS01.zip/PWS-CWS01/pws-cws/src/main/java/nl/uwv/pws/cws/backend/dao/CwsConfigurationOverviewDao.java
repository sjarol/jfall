package nl.uwv.pws.cws.backend.dao;

import nl.uwv.pws.backend.dao.BackendException;
import nl.uwv.pws.backend.service.AbstractService;
import nl.uwv.pws.cws.model.viewtab.ConfiguratieWithFilters;
import nl.uwv.pws.cws.model.viewtab.CwsOverzichtConfiguratie;
import nl.uwv.pws.cws.model.viewtab.CwsOverzichtFilterUtil;
import nl.uwv.pws.cws.model.viewtab.CwsOverzichtSelectieCriteria;
import nl.uwv.pws.cws.util.Constants;
import nl.uwv.pws.cws.util.CwsUtils;
import nl.uwv.pws.ui.util.UIUtils;
import org.apache.commons.lang3.tuple.Pair;

import javax.naming.NamingException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static java.util.stream.Collectors.joining;
import static java.util.stream.Collectors.toMap;

public class CwsConfigurationOverviewDao extends AbstractService {

   private static final String CONFIGURATIE_OVERZICHT_SQL_TEMPLATE =
        " SELECT ccon.ccon_id " +
            "     , acon.afn_cd_afnemer" +
            "     , ccon.contract_id" +
            "     , SAFE_TO_DATE(ccon.cont_his_dat_in, 'YYYYMMDD') as cont_his_dat_in" +
            "     , ccon.version" +
            "     , ccon.naam" +
            "     , SAFE_TO_DATE(ccon.his_dat_in, 'YYYYMMDD') as his_dat_in" +
            "     , FORMAT_DATEIND_TM(ccon.his_dat_end) as his_dat_end" +
            "     , ccon.status" +
            "     , cmr.lev_cd" +
            "     , cmr.berichtversie" +
            " FROM cws_configuratie ccon " +
            " JOIN afn_contract acon " +
            " ON ccon.contract_id = acon.contract_id " +
            " AND ccon.cont_his_dat_in = acon.his_dat_in " +
            " JOIN cws_meta_root cmr " +
            " ON cmr.meta_root_id = ccon.meta_root_id " +
            " WHERE ccon.his_ts_end = DATE '9999-12-31' " +
            " AND ccon.ccon_id IN (${CCON_ID_IN_VALUES}) " +
            " ORDER BY 3 DESC, 4 DESC, 5 DESC";

   private static volatile CwsConfigurationOverviewDao instance;
   private static final Object mutex = new Object();

   private CwsConfigurationOverviewDao() {
      super(Constants.DS_NAME);
   }

   public static CwsConfigurationOverviewDao getInstance() {
      CwsConfigurationOverviewDao localRef = instance;
      if (localRef == null) {
         synchronized (mutex) {
            localRef = instance;
            if (localRef == null)
               instance = localRef = new CwsConfigurationOverviewDao();
         }
      }

      return localRef;
   }

   public List<Map<String, Object>> collectAllConfigsWithMatchingNewestMetaColIds(final List<Long> selectedNewestMetaColIds, final String leverCode) {
       StringBuilder inParameterListBuilder = new StringBuilder(selectedNewestMetaColIds.size() * 2);
       for (int i = 0; i < selectedNewestMetaColIds.size(); i++) {
          inParameterListBuilder.append(",?");
       }

       final String sqlQuery = "SELECT cc.ccon_id, mc.tech_naam, mc.bron_tabel " +
             "FROM cws_meta_col mc " +
             "INNER join cws_meta_root root ON root.meta_root_id = mc.meta_root_id " +
             "INNER join cws_con_col cc ON cc.meta_col_id = mc.meta_col_id " +
             "WHERE root.lev_cd = ? " +
             "AND (tech_naam, bron_tabel) IN (" +
             "  SELECT tech_naam, bron_tabel " +
             "  FROM cws_meta_col " +
             "  WHERE meta_col_id IN (" + inParameterListBuilder.substring(1) + ")" +
             ") " +
             "AND cc.his_ts_end = DATE '9999-12-31'";


       try (Connection conn = getDataSource().getConnection();
            PreparedStatement statement = conn.prepareStatement(sqlQuery)) {

          statement.setString(1, leverCode);
          for (int i = 0; i < selectedNewestMetaColIds.size(); i++) {
             statement.setLong(i + 2, selectedNewestMetaColIds.get(i));
          }

          List<Map<String, Object>> allApplicableMetaColList = new ArrayList<>();
          try (ResultSet resultSet = statement.executeQuery()) {
             while (resultSet.next()) {
                Map<String, Object> metaColMap = new HashMap<>();
                metaColMap.put("CCON_ID", resultSet.getLong("CCON_ID"));
                metaColMap.put("TECH_NAAM", resultSet.getString("TECH_NAAM"));
                metaColMap.put("BRON_TABEL", resultSet.getString("BRON_TABEL"));
                allApplicableMetaColList.add(metaColMap);
             }
             return allApplicableMetaColList;
          }
       } catch (SQLException | NamingException e) {
            UIUtils.handleError(e);
            throw new BackendException("Fout bij ophalen van Mata data", e);
      }
    }

    public List<CwsOverzichtConfiguratie> getConfiguratiesWithAfnemerDetail(List<Long> cconIds) {
       String configuratieOverzichtSql = CONFIGURATIE_OVERZICHT_SQL_TEMPLATE
             .replace("${CCON_ID_IN_VALUES}", cconIds.stream()
                   .map(String::valueOf)
                   .collect(joining(", ")));

       List<CwsOverzichtConfiguratie> rows = new ArrayList<>();
       try (Connection conn = getDataSource().getConnection();
            PreparedStatement statement = conn.prepareStatement(configuratieOverzichtSql);
            ResultSet resultSet = statement.executeQuery()) {

             while (resultSet.next()) {
                rows.add(mapToConfiguratieVoorOverzicht(resultSet));
             }
             return rows;


       } catch (SQLException | NamingException e) {
          UIUtils.handleError(e);
          throw new BackendException("Fout bij ophalen van Mata data", e);
       }
    }

    private CwsOverzichtConfiguratie mapToConfiguratieVoorOverzicht(ResultSet resultSet) throws SQLException {
        CwsOverzichtConfiguratie configuration = new CwsOverzichtConfiguratie();

        configuration.setConfigId(resultSet.getLong("CCON_ID"));
        configuration.setAfnemerCode(resultSet.getString("AFN_CD_AFNEMER"));
        configuration.setLeveringCode(resultSet.getString("LEV_CD"));
        configuration.setContractId(resultSet.getLong("CONTRACT_ID"));

        configuration.setContractStartDate(CwsUtils.getDateAsLocalDate(resultSet.getDate("CONT_HIS_DAT_IN")));
        configuration.setVersie(resultSet.getLong("VERSION"));
        configuration.setName(resultSet.getString("NAAM"));
        configuration.setConfigStartDate(CwsUtils.getDateAsLocalDate(resultSet.getDate("HIS_DAT_IN")));
        configuration.setConfigEndDate(CwsUtils.getDateAsLocalDate(resultSet.getDate("HIS_DAT_END")));
        configuration.setStatus(resultSet.getString("STATUS"));
        configuration.setBerichtVersie(resultSet.getString("BERICHTVERSIE"));

        return configuration;
    }

    public List<ConfiguratieWithFilters> collectAllConfigsWithMatchingFilters(String leverCode, CwsOverzichtSelectieCriteria overzichtSelectieCriteria) {
      final String sqlQuery = " SELECT ccf.ccon_id, " +
            " clf.tech_naam, " +
            " ccf.value " +
            " FROM cws_con_filter ccf JOIN cws_lev_filter clf ON (clf.lev_filter_id = ccf.lev_filter_id AND clf.lev_cd = ?) " +
            " WHERE CLF.TECH_NAAM in (" + overzichtSelectieCriteria.getSelectedSelectieCriteriaNamesForSqlInClause() + ") " +
            " AND CCF.HIS_TS_END = DATE '9999-12-31' " +
            " ORDER BY CCF.CCON_ID, TECH_NAAM ";

      try (Connection conn = getDataSource().getConnection();
            PreparedStatement statement = conn.prepareStatement(sqlQuery)) {
            statement.setString(1, leverCode);

         try (ResultSet resultSet = statement.executeQuery()) {
            Map<Long, List<Pair<String, Boolean>>> allFiltersGroupedByCconId = new HashMap<>();
            while (resultSet.next()) {
               long cconId = resultSet.getLong("CCON_ID");
               String techNaam = resultSet.getString("TECH_NAAM");
               String value = resultSet.getString("VALUE");

               List<Pair<String, Boolean>> filtersOfConfig = allFiltersGroupedByCconId.computeIfAbsent(cconId, mapKey -> new ArrayList<>());
               boolean resultCondition = CwsOverzichtFilterUtil.testCwsOverzichtFilterCondition(leverCode, techNaam, value);
               filtersOfConfig.add(Pair.of(techNaam, resultCondition));
            }
            return allFiltersGroupedByCconId.entrySet().stream().map(entry -> {
               Long cconId = entry.getKey();
               List<Pair<String, Boolean>> filterConditionPairs = entry.getValue();

               ConfiguratieWithFilters configuratieWithFilters = ConfiguratieWithFilters.builder().cconId(cconId).build();
               Map<String, Boolean> configFiltersMap = filterConditionPairs.stream()
                     .collect(toMap(Pair::getLeft, Pair::getRight));

               configuratieWithFilters.setFilters(configFiltersMap);
               return configuratieWithFilters;
            })
                  // Only take configuration with any match to the selected filters
                  .filter(configuratieWithFilters ->
                        configuratieWithFilters.getFilters().entrySet().stream()
                              .anyMatch(Map.Entry::getValue))
                  .collect(Collectors.toList());
         }
       } catch (SQLException | NamingException e) {
          UIUtils.handleError(e);
          throw new BackendException("Fout bij ophalen van Configuratie filters", e);
       }
    }

    public List<Map<String, Object>> getMetaColDetail(List<Long> metadataIds) {
        List<Map<String, Object>> metaColDetailList = new ArrayList<>();

       StringBuilder inParameterListBuilder = new StringBuilder(metadataIds.size() * 2);
       for (int i = 0; i < metadataIds.size(); i++) {
          inParameterListBuilder.append(",?");
       }

       String sqlQuery = "SELECT tech_naam, bron_tabel, func_naam " +
             "FROM cws_meta_col " +
             "WHERE meta_col_id IN (" + inParameterListBuilder.substring(1) + ")";
       try (Connection conn = getDataSource().getConnection();
            PreparedStatement statement = conn.prepareStatement(sqlQuery)) {
             for (int i = 0; i < metadataIds.size(); i++) {
                statement.setLong(i + 1, metadataIds.get(i));
             }

          try (ResultSet resultSet = statement.executeQuery()) {
             while (resultSet.next()) {
                Map<String, Object> metaColMap = new HashMap<>();
                metaColMap.put("TECH_NAAM", resultSet.getString("TECH_NAAM"));
                metaColMap.put("BRON_TABEL", resultSet.getString("BRON_TABEL"));
                metaColMap.put("FUNC_NAAM", resultSet.getString("FUNC_NAAM"));
                metaColDetailList.add(metaColMap);
             }
          }

          return metaColDetailList;

       } catch (SQLException | NamingException e) {
          UIUtils.handleError(e);
          throw new BackendException("Fout bij ophalen van Mata data detail", e);
       }
    }
}
