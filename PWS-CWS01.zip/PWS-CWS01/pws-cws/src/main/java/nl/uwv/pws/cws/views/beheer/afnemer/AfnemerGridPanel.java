package nl.uwv.pws.cws.views.beheer.afnemer;

import com.vaadin.flow.component.AbstractField.ComponentValueChangeEvent;
import com.vaadin.flow.component.HasValue.ValueChangeListener;
import com.vaadin.flow.component.grid.Grid;
import lombok.Getter;
import nl.uwv.pws.backend.dao.SqlFilter;
import nl.uwv.pws.backend.service.CountRowsListener;
import nl.uwv.pws.backend.types.ColumnList;
import nl.uwv.pws.cws.util.Constants;
import nl.uwv.pws.cws.views.beheer.common.AbstractBeheerConfiguratieGridPanel;
import nl.uwv.pws.cws.views.beheer.tabs.events.AfnemersSearchEvent;
import nl.uwv.pws.ui.util.QueryLogger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

import static nl.uwv.pws.cws.util.Constants.AFNEMERS_CAPTION;

/**
 * Panel that contains a NoResultsLabel (only visible if after searching there are no results),
 * a title, a grid to display afnemer records and a couple of buttons.
 */
@Getter
public class AfnemerGridPanel extends AbstractBeheerConfiguratieGridPanel<SqlFilter> {
   private static final Logger LOG = LoggerFactory.getLogger(AfnemerGridPanel.class);
   public static final String COMPONENT_ID = "afnemers-panel";

   public AfnemerGridPanel(final ValueChangeListener<ComponentValueChangeEvent<Grid<ColumnList>, ColumnList>> valueChangeListener,
                           final CountRowsListener countRowsListener) {
      super(COMPONENT_ID, AFNEMERS_CAPTION,
            new AfnemerService(Constants.DS_NAME),
            valueChangeListener, countRowsListener);
   }

   public void findAlleAfnemers() {
      LOG.debug("Finding alle afnemers");
      search(new AfnemerByAfnemerFieldsFilter());
   }

   public void findAfnemersByCriteria(final AfnemersSearchEvent searchEvent) {
      LOG.debug("Finding afnemers considering afnemercode, afnemer naam and UgcId");
      search(new AfnemerByAfnemerFieldsFilter(searchEvent));
   }

   public void findAfnemersByAfnemerCode(final String selectedAfnemerCode) {
      LOG.debug("Finding afnemers by afnemercode {} ", selectedAfnemerCode);
      search(new AfnemerByAfnemerFieldsFilter(selectedAfnemerCode));
   }

   @Override
   protected void onRowsFetched(final List<ColumnList> rows) {
      QueryLogger queryLogger = QueryLogger.getInstance();
      rows.forEach(row -> queryLogger.callQueryLog(QueryLogger.LogType.AFN_AFNCD, row, AfnemerColumn.AFN_CD));
   }
}
