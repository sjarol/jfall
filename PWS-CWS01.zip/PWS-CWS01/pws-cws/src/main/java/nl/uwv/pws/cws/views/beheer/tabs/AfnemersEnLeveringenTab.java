package nl.uwv.pws.cws.views.beheer.tabs;

import com.helger.commons.annotation.VisibleForTesting;
import com.vaadin.flow.component.AbstractField.ComponentValueChangeEvent;
import com.vaadin.flow.component.ClickEvent;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.ComponentEventListener;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.dialog.GeneratedVaadinDialog.OpenedChangeEvent;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.html.Anchor;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.server.StreamResource;
import lombok.Getter;
import lombok.Setter;
import nl.uwv.pws.backend.dao.AuthorizationType;
import nl.uwv.pws.backend.dao.BackendException;
import nl.uwv.pws.backend.types.ColumnList;
import nl.uwv.pws.cws.backend.service.AppiConfigService;
import nl.uwv.pws.cws.backend.service.ConfigurationService;
import nl.uwv.pws.cws.backend.service.ExportService;
import nl.uwv.pws.cws.backend.service.ProductSpecificationService;
import nl.uwv.pws.cws.model.ConfigurationDetails;
import nl.uwv.pws.cws.model.ContractDetails;
import nl.uwv.pws.cws.model.CwsConfiguration;
import nl.uwv.pws.cws.util.*;
import nl.uwv.pws.cws.views.AfnemersSearchBar;
import nl.uwv.pws.cws.views.BeheerConfiguratieView;
import nl.uwv.pws.cws.views.beheer.tabs.dialogs.ConfigurationDialog;
import nl.uwv.pws.cws.views.beheer.tabs.dialogs.EditorConfirmationDialog;
import nl.uwv.pws.cws.views.beheer.tabs.dialogs.UploadDialog;
import nl.uwv.pws.cws.views.beheer.afnemer.AfnemerColumn;
import nl.uwv.pws.cws.views.beheer.afnemer.AfnemerGridPanel;
import nl.uwv.pws.cws.views.beheer.configuratie.ConfiguratieGridPanel;
import nl.uwv.pws.cws.views.beheer.configuratie.ConfigurationAction;
import nl.uwv.pws.cws.views.beheer.contract.ContractColumn;
import nl.uwv.pws.cws.views.beheer.contract.ContractGridPanel;
import nl.uwv.pws.cws.views.beheer.contract.ContractServiceType;
import nl.uwv.pws.cws.views.beheer.tabs.events.AfnemersSearchEvent;
import nl.uwv.pws.cws.views.beheer.tabs.events.SearchAlleAfnemersEvent;
import nl.uwv.pws.cws.views.beheer.tabs.events.SearchAlleLeveringenEvent;
import nl.uwv.pws.cws.views.beheer.tabs.events.ValidationFailedEvent;
import nl.uwv.pws.cws.views.beheer.levering.LeveringColumn;
import nl.uwv.pws.cws.views.beheer.levering.LeveringGridPanel;
import nl.uwv.pws.ui.components.AuthorizedTab;
import nl.uwv.pws.ui.components.DialogSettings;
import nl.uwv.pws.ui.components.NoResultsLabel;
import nl.uwv.pws.ui.layout.FullVerticalLayout;
import nl.uwv.pws.ui.util.AuthorizedComponent;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.time.LocalDate;

import static nl.uwv.pws.cws.util.Constants.*;
import static nl.uwv.pws.cws.util.CwsUIUtils.createButton;
import static nl.uwv.pws.cws.util.CwsUIUtils.createButtonStrip;

@Getter
@Setter
public class AfnemersEnLeveringenTab extends AuthorizedTab implements TabView {

   private static final Logger LOG = LoggerFactory.getLogger(AfnemersEnLeveringenTab.class);
   protected enum SearchAction { FIND_ALLE_AFNEMERS, FIND_ALLE_LEVERINGEN, FIND_BY_CONTRACTID, FIND_BY_CRITERIA}

   public static final String TAB_NAME = "Afnemers en CWS Leveringen";
   private static final String AFNEMER_CONTRACT_PANEL_ID = "afnemer-contracts-panel";
   private static final String LEVERING_CONTRACT_PANEL_ID = "leveringen-contracts-panel";
   private static final String EDIT_BUTTON_STRIP_ID_POSTFIX = "edit-button-strip";
   private static final String CONFIGURATION_BUTTON_STRIP_ID_POSTFIX = "configuration-button-strip";

   private AfnemersSearchBar searchBar;
   private AfnemerGridPanel afnemerGridPanel;
   private ContractGridPanel afnemerContractGridPanel;

   private LeveringGridPanel leveringGridPanel;
   private ContractGridPanel leveringContractGridPanel;
   private ConfiguratieGridPanel configuratieGridPanel;

   private NoResultsLabel noResultsLabelAfnemerGridPanel;
   private NoResultsLabel noResultsLabelAfnemerContractGridPanel;
   private ColumnList preSelectedConfiguratieItem;

   private BeheerConfiguratieView tabParent;
   private HorizontalLayout buttonBar;

   private ContractDetails contractDetails;
   private ConfigurationDetails configurationDetails;
   private EditorConfirmationDialog confirmDialog;
   private SearchAction searchAction;

   @AuthorizedComponent(value = "Toevoegen", type = AuthorizationType.BTN)
   private Button addConfigurationButton;

   @AuthorizedComponent(value = "Wijzigen", type = AuthorizationType.BTN)
   private Button modifyConfigurationButton;

   @AuthorizedComponent(value = "Verwijderen", type = AuthorizationType.BTN)
   private Button deleteConfigurationButton;

   @AuthorizedComponent(value = "Raadplegen", type = AuthorizationType.BTN)
   private Button viewConfigurationButton;

   @AuthorizedComponent(value = "Configuratie Definitief", type = AuthorizationType.BTN)
   private Button finalizeConfigurationButton;

   @AuthorizedComponent(value = "Genereer Productspecificatie", type = AuthorizationType.BTN)
   private Button generateProductSpecButton;

   @AuthorizedComponent(value = "Export", type = AuthorizationType.BTN)
   private Button exportConfigurationButton;

   @AuthorizedComponent(value = "Import", type = AuthorizationType.BTN)
   private Button importConfigurationButton;

   private Anchor generateProductSpecLink;
   private Anchor exportProductSpecLink;
   private final ProductSpecificationService productSpecificationService;
   private final ConfigurationService configurationService;
   private final AppiConfigService appiConfigService;
   private final ExportService exportService;

   public AfnemersEnLeveringenTab(final BeheerConfiguratieView beheerConfiguratieView) {
      super(TAB_NAME);
      this.setId(Constants.AFNEMERS_EN_LEVERINGEN_TAB_ID);
      this.tabParent = beheerConfiguratieView;
      searchBar = new AfnemersSearchBar();
      afnemerGridPanel = new AfnemerGridPanel(this::afnemerSelected, this::afnemerRowsCounted);
      afnemerContractGridPanel = new ContractGridPanel(this::afnemerContractSelected, this::afnemerContractRowsCounted,
            AFNEMER_CONTRACT_PANEL_ID, ContractServiceType.CONTRACT_BY_AFNEMER);
      leveringGridPanel = new LeveringGridPanel(this::leveringSelected);
      leveringContractGridPanel = new ContractGridPanel(this::leveringContractSelected, this::afnemerContractRowsCounted,
            LEVERING_CONTRACT_PANEL_ID, ContractServiceType.CONTRACT_BY_LEVERING);
      configuratieGridPanel = new ConfiguratieGridPanel(this::configuratieSelected);

      searchBar.addListener(AfnemersSearchEvent.class, this::findRelatedAfnemersAndContracts);
      searchBar.addListener(SearchAlleAfnemersEvent.class, this::findAlleAfnemers);
      searchBar.addListener(ValidationFailedEvent.class, this::resetNoResultsLabel);
      searchBar.addListener(SearchAlleLeveringenEvent.class, this::findAlleLeveringen);

      this.noResultsLabelAfnemerGridPanel = new NoResultsLabel();
      this.noResultsLabelAfnemerContractGridPanel =  new NoResultsLabel();
      buttonBar = createButtonBar();
      hideAll();

      productSpecificationService = new ProductSpecificationService();
      configurationService = new ConfigurationService();
      appiConfigService = new AppiConfigService();
      exportService = new ExportService();
   }

   private HorizontalLayout createButtonBar() {
      HorizontalLayout editButtonsStrip = createButtonStrip(AFNEMERS_EN_LEVERINGEN_TAB_ID + EDIT_BUTTON_STRIP_ID_POSTFIX, "60%");
      HorizontalLayout configurationButtonsStrip = createButtonStrip(AFNEMERS_EN_LEVERINGEN_TAB_ID + CONFIGURATION_BUTTON_STRIP_ID_POSTFIX, "40%");

      this.addConfigurationButton = createButton("Toevoegen", VaadinIcon.PLUS_SQUARE_O, ADD_BUTTON_ID, true, "10em");
      addEventToButton(addConfigurationButton, event -> addConfiguration());

      this.modifyConfigurationButton = createButton("Wijzigen", VaadinIcon.EDIT, EDIT_BUTTON_ID, false, "10em");
      addEventToButton(modifyConfigurationButton, event -> modifyConfiguration());

      this.deleteConfigurationButton = createButton("Verwijderen", VaadinIcon.TRASH, DELETE_BUTTON_ID, false, "10em");
      addEventToButton(deleteConfigurationButton, event -> deleteConfiguration());

      this.viewConfigurationButton = createButton("Raadplegen", VaadinIcon.EYE, VIEW_BUTTON_ID, false, "10em");
      addEventToButton(viewConfigurationButton, event -> viewConfiguration());

      this.finalizeConfigurationButton = createButton("Configuratie Definitief", VaadinIcon.CHECK, FINALIZE_CONFIGURATION_BUTTON_ID, false, "19em");
      addEventToButton(finalizeConfigurationButton, event -> finalizeConfiguration());

      editButtonsStrip.add(addConfigurationButton);
      editButtonsStrip.add(modifyConfigurationButton);
      editButtonsStrip.add(deleteConfigurationButton);
      editButtonsStrip.add(viewConfigurationButton);
      editButtonsStrip.add(finalizeConfigurationButton);


      this.generateProductSpecButton = createButton("Genereer Productspecificatie", VaadinIcon.DOWNLOAD, GENERATE_PRODUCTSPEC_BUTTON_ID, false, "20em");
      this.generateProductSpecLink = new Anchor();
      this.generateProductSpecLink.getElement().setAttribute("download", true);
      this.generateProductSpecLink.add(generateProductSpecButton);

      this.exportConfigurationButton = createButton("Export", VaadinIcon.DOWNLOAD, EXPORT_BUTTON_ID, false, "10em");
      this.exportProductSpecLink = new Anchor();
      this.exportProductSpecLink.getElement().setAttribute("download", true);
      this.exportProductSpecLink.add(exportConfigurationButton);

      this.importConfigurationButton = createButton("Import", VaadinIcon.UPLOAD, IMPORT_BUTTON_ID, true, "10em");
      addEventToButton(importConfigurationButton, event -> importConfiguration());

      configurationButtonsStrip.add(generateProductSpecLink);
      configurationButtonsStrip.add(exportProductSpecLink);
      configurationButtonsStrip.add(importConfigurationButton);

      HorizontalLayout horizontalLayout = new HorizontalLayout(editButtonsStrip, configurationButtonsStrip);
      horizontalLayout.setWidthFull();
      return horizontalLayout;
   }

   @Override
   public Component getViewHeader() {
      return searchBar;
   }

   @Override
   public Component getViewContent() {
      return new FullVerticalLayout(
            noResultsLabelAfnemerGridPanel,
            noResultsLabelAfnemerContractGridPanel,
            leveringGridPanel,
            leveringContractGridPanel,
            afnemerGridPanel,
            afnemerContractGridPanel,
            configuratieGridPanel,
            buttonBar);
   }

   @VisibleForTesting
   protected void findAlleLeveringen(final SearchAlleLeveringenEvent event) {
      searchAction = SearchAction.FIND_ALLE_LEVERINGEN;
      hideAll();
      leveringGridPanel.show();
      leveringGridPanel.findAlleLeveringen();
   }

   private void resetNoResultsLabel(final ValidationFailedEvent event) {
      hideNoResultLabel();
   }

   @VisibleForTesting
   protected void findAlleAfnemers(final SearchAlleAfnemersEvent searchAlleAfnemersEvent) {
      searchAction = SearchAction.FIND_ALLE_AFNEMERS;
      hideAll();
      afnemerContractGridPanel.show();
      afnemerGridPanel.findAlleAfnemers();
   }

   @VisibleForTesting
   protected void findRelatedAfnemersAndContracts(final AfnemersSearchEvent searchEvent) {
      hideAll();
      final String contractId = searchEvent.getContractId();
      if (StringUtils.isNotBlank(contractId)) {
         searchAction = SearchAction.FIND_BY_CONTRACTID;
         afnemerContractGridPanel.findContractsByContractId(contractId);
      } else {
         searchAction = SearchAction.FIND_BY_CRITERIA;
         afnemerGridPanel.findAfnemersByCriteria(searchEvent);
      }
   }


   @VisibleForTesting
   protected void afnemerSelected(final ComponentValueChangeEvent<Grid<ColumnList>, ColumnList> event) {
      if(searchAction.equals(SearchAction.FIND_BY_CRITERIA)) {
         hideButtonBar();
      }
      afnemerGridPanel.show();
      afnemerContractGridPanel.show();

      ColumnList columnList = event.getValue();
      String selectedAfnemerCd = columnList == null ? null : (String) columnList.getValue(AfnemerColumn.AFN_CD.name());

      if (StringUtils.isNotBlank(selectedAfnemerCd) && (searchAction.equals(SearchAction.FIND_BY_CRITERIA) || searchAction.equals(SearchAction.FIND_ALLE_AFNEMERS))) {
         LOG.debug("Afnemer code selected: {}", selectedAfnemerCd);
         configuratieGridPanel.hide();
         hideButtonBar();
         afnemerContractGridPanel.findContractsByAfnemerCode(selectedAfnemerCd);
      }
   }

   @VisibleForTesting
   protected void leveringSelected(final ComponentValueChangeEvent<Grid<ColumnList>, ColumnList> event) {
      configuratieGridPanel.hide();
      hideButtonBar();
      ColumnList columnList = event.getValue();
      String selectedLeveringCode = columnList == null ? null : (String) columnList.getValue(LeveringColumn.LEV_CD.name());

      if (StringUtils.isNotBlank(selectedLeveringCode)) {
         LOG.debug("Levering code selected: {}", selectedLeveringCode);
         leveringContractGridPanel.show();
         leveringContractGridPanel.findContractsByLeveringCode(selectedLeveringCode);
      }
   }

   @VisibleForTesting
   protected void leveringContractSelected(final ComponentValueChangeEvent<Grid<ColumnList>, ColumnList> event) {
      contractSelected(event);
   }

   @VisibleForTesting
   protected void afnemerContractSelected(final ComponentValueChangeEvent<Grid<ColumnList>, ColumnList> event) {
      afnemerContractGridPanel.show();

      ColumnList columnList = event.getValue();
      String selectedAfnemerCode = null;
      if (columnList != null) {
         selectedAfnemerCode = (String) columnList.getValue(ContractColumn.AFN_CD.name());
      }

      if (!afnemerGridPanel.isVisible()) {
         LOG.debug("Afnemer selected: afnemerCode {}", selectedAfnemerCode);
         afnemerGridPanel.findAfnemersByAfnemerCode(selectedAfnemerCode);
      }

      contractSelected(event);
   }

   private void contractSelected(final ComponentValueChangeEvent<Grid<ColumnList>, ColumnList> event) {
      configuratieGridPanel.show();
      showButtonBar();
      resetConfiguratieButtons();
      ColumnList columnList = event.getValue();
      if (columnList != null) {
         this.contractDetails = Mapper.mapToContractDetail(columnList);
         configuratieGridPanel.findConfiguratie(contractDetails);
      }
   }

   @VisibleForTesting
   protected void configuratieSelected(final ComponentValueChangeEvent<Grid<ColumnList>, ColumnList> event) {
      modifyConfigurationButton.setEnabled(true);
      generateProductSpecButton.setEnabled(true);
      exportConfigurationButton.setEnabled(true);
      viewConfigurationButton.setEnabled(true);

      ColumnList columnList = event.getValue();
      if (columnList != null) {
         configuratieGridPanel.setPreSelectedColumnList(columnList);
         this.configurationDetails = Mapper.mapToConfigurationDetail(columnList);

         prepareSpecificationLinks();
      }

      if (configurationDetails != null && ConfigurationStatus.CO.name().equalsIgnoreCase(configurationDetails.getConfigurationStatus())) {
         finalizeConfigurationButton.setEnabled(true);
         deleteConfigurationButton.setEnabled(true);
      } else {
         finalizeConfigurationButton.setEnabled(false);
         deleteConfigurationButton.setEnabled(false);
      }
   }

   private void prepareSpecificationLinks(){
      final String kermerk = getPdfKenmerk();
      final String configurationName = this.configurationDetails.getConfigurationName();
      final String configurationVersion = this.configurationDetails.getConfigurationVersion().toPlainString();
      final String afnemerCode = this.contractDetails.getAfnemerCode();
      final String pdfFileName = CwsUtils.createPdfFileName(kermerk, configurationName, configurationVersion, afnemerCode);
      final String zipFilename = pdfFileName.replace(".pdf", ".zip");
      this.generateProductSpecLink.setHref(new StreamResource(zipFilename, () -> createProductSpecificationResource(pdfFileName)));

      final String exportFileName = CwsUtils.createExportFileName(configurationName, configurationVersion, afnemerCode);
      this.exportProductSpecLink.setHref(new StreamResource(exportFileName, this::createExportableConfigurationResource));
   }

   private InputStream createProductSpecificationResource(final String pdfFileName) {
      CwsConfiguration cwsConfiguration = createCwsConfigurationFromSelection();
      String pdfKenmerk = getPdfKenmerk();

      try {
         ByteArrayOutputStream byteArrayOutputStream = productSpecificationService.generateZipFile(cwsConfiguration, pdfFileName, pdfKenmerk);
         return new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
      } catch (SAXException | ParserConfigurationException | IOException e) {
         throw new BackendException("Kan product specificatie zip niet genereren.", e);
      }
   }

   private InputStream createExportableConfigurationResource() {
      CwsConfiguration cwsConfiguration = createCwsConfigurationFromSelection();
      String configSpecString = exportService.generateExportConfigurationString(cwsConfiguration);
      return new ByteArrayInputStream(configSpecString.getBytes());
   }

   private void hideAll(){
      hideNoResultLabel();
      hideButtonBar();
      hideAfnemerRelatedPanels();
      hideLeveringRelatedPanels();

      resetSelectedConfiguratie();
   }

   protected void resetSelectedConfiguratie(){
      configuratieGridPanel.setPreSelectedColumnList(null);
   }

   private void hideAfnemerRelatedPanels() {
      afnemerGridPanel.hide();
      hideAfnemerContractRelatedPanels();
   }

   private void hideLeveringRelatedPanels() {
      hideNoResultLabel();
      leveringGridPanel.hide();
      hideLeveringContractRelatedPanels();
   }

   private void hideAfnemerContractRelatedPanels() {
      hideNoResultLabel();
      afnemerContractGridPanel.hide();
      configuratieGridPanel.hide();
   }

   private void hideLeveringContractRelatedPanels() {
      leveringContractGridPanel.hide();
      configuratieGridPanel.hide();
   }

   private void hideNoResultLabel() {
      noResultsLabelAfnemerGridPanel.setVisible(false);
      noResultsLabelAfnemerContractGridPanel.setVisible(false);
   }

   public void afnemerRowsCounted(final long rowCount) {
      if (noResultsLabelAfnemerGridPanel != null && searchAction != null && searchAction.equals(SearchAction.FIND_BY_CRITERIA)) {
         noResultsLabelAfnemerGridPanel.setVisible(afnemerGridPanel.isSearchPerformed() && rowCount == 0);
      }
   }

   public void afnemerContractRowsCounted(final long rowCount) {
      if (noResultsLabelAfnemerContractGridPanel != null && searchAction != null && searchAction.equals(SearchAction.FIND_BY_CONTRACTID)) {
         noResultsLabelAfnemerContractGridPanel.setVisible(afnemerContractGridPanel.isSearchPerformed() && rowCount == 0);
      }
   }

   private void showButtonBar() {
      buttonBar.setVisible(true);
   }

   private void hideButtonBar() {
      buttonBar.setVisible(false);
   }

   private void addEventToButton(Button button, ComponentEventListener<ClickEvent<Button>> listener) {
      button.addClickListener(listener);
   }

   protected void addConfiguration() {
      ConfigurationDialog configurationDialog = CwsUIUtils.createConfigurationDialog();
      CwsConfiguration cwsConfiguration = buildDefaultCwsConfigurationToAdd().build();
      cwsConfiguration.setConfigurationId(null);
      cwsConfiguration.setConfigurationVersion(null);
      configurationDialog.configureDialog(cwsConfiguration, ConfigurationAction.ADD);
      configurationDialog.hideCancelButton();
      configurationDialog.open();
      configurationDialog.addCloseListener(dialogOpenedChangeEvent -> updateConfigurationPanel(dialogOpenedChangeEvent, cwsConfiguration));
   }

   protected void modifyConfiguration() {
      ConfigurationDialog configurationDialog = CwsUIUtils.createConfigurationDialog();
      CwsConfiguration cwsConfiguration = createCwsConfigurationFromSelection();
      configurationDialog.configureDialog(cwsConfiguration, ConfigurationAction.MODIFY);
      configurationDialog.hideCancelButton();
      configurationDialog.open();
      configurationDialog.addCloseListener(dialogOpenedChangeEvent -> updateConfigurationPanel(dialogOpenedChangeEvent, cwsConfiguration));
   }

   protected void viewConfiguration() {
      ConfigurationDialog configurationDialog = CwsUIUtils.createConfigurationDialog();
      CwsConfiguration cwsConfiguration = createCwsConfigurationFromSelection();
      configurationDialog.configureDialog(cwsConfiguration, ConfigurationAction.VIEW);
      configurationDialog.hideCancelButton();
      configurationDialog.open();
   }

   protected void importConfiguration() {
      final String leverCode = this.contractDetails.getLeverCode();
      final Long contractId = this.contractDetails.getContractId().longValue();
      final LocalDate contractStartDate = this.contractDetails.getContractStartDate();
      UploadDialog uploadDialog = new UploadDialog(leverCode, contractId, contractStartDate);
      uploadDialog.hideCancelButton();
      uploadDialog.open();
      uploadDialog.addCloseListener(dialogOpenedChangeEvent -> configuratieGridPanel.findConfiguratie(contractDetails));
   }

   protected void deleteConfiguration() {
      DialogSettings dialogSettings = new DialogSettings("Waarschuwing!","Weet u het zeker?", null, "Ja, Zeker weten", true);
      this.confirmDialog = new EditorConfirmationDialog();
      confirmDialog.open(dialogSettings, null, item -> confirmDeleteConfiguration(), null);
   }

   protected void confirmDeleteConfiguration() {
      final Long configurationId = this.configurationDetails.getConfigurationId().longValue();
      configurationService.confirmDeleteConfiguration(configurationId);
      confirmDialog.close();
      configuratieGridPanel.findConfiguratie(this.contractDetails);
   }

   protected void updateConfigurationPanel(final OpenedChangeEvent<Dialog> dialogOpenedChangeEvent, final CwsConfiguration cwsConfiguration) {
      if (!dialogOpenedChangeEvent.isOpened()) {
         final ContractDetails contractDetails = ContractDetails.builder()
               .contractId(BigDecimal.valueOf(cwsConfiguration.getContractId()))
               .contractStartDate(cwsConfiguration.getContractStartDate())
               .build();
         configuratieGridPanel.findConfiguratie(contractDetails);
      }
   }

   private CwsConfiguration createCwsConfigurationFromSelection() {
      Long configurationId = null;
      String configurationStatus = null;
      Long configurationVersion = null;
      String berichtVersie = null;
      String configurationName = null;
      LocalDate configurationStartDate = null;
      LocalDate configurationEndDate = null;
      if(this.configurationDetails != null) {
         configurationId = this.configurationDetails.getConfigurationId() != null ? this.configurationDetails.getConfigurationId().longValue() : null;
         configurationStatus = this.configurationDetails.getConfigurationStatus();
         configurationVersion = this.configurationDetails.getConfigurationVersion() != null ? this.configurationDetails.getConfigurationVersion().longValue() : null;
         berichtVersie = this.configurationDetails.getBerichtVersie();
         configurationName = this.configurationDetails.getConfigurationName();
         configurationStartDate = this.configurationDetails.getConfigurationStartDate();
         configurationEndDate = this.configurationDetails.getConfigurationEndDate();
      }

      CwsConfiguration.CwsConfigurationBuilder cwsConfigurationBuilder = buildDefaultCwsConfigurationToAdd();
      return cwsConfigurationBuilder
            .configurationId(configurationId)
            .configurationStatus(configurationStatus)
            .configurationVersion(configurationVersion)
            .berichtVersie(berichtVersie)
            .configurationName(configurationName)
            .configurationStartDate(configurationStartDate)
            .configurationEndDate(configurationEndDate)
            .build();
   }

   private CwsConfiguration.CwsConfigurationBuilder buildDefaultCwsConfigurationToAdd() {
      return CwsConfiguration.builder()
            .afnemerCode(this.contractDetails.getAfnemerCode())
            .afnemerNaam(this.contractDetails.getAfnemerNaam())
            .contractId(this.contractDetails.getContractId().longValue())
            .contractStartDate(this.contractDetails.getContractStartDate())
            .contractEndDate(this.contractDetails.getContractEndDate())
            .leverCode(this.contractDetails.getLeverCode());
   }

   protected void finalizeConfiguration() {
      DialogSettings dialogSettings = new DialogSettings("Waarschuwing!","Weet u het zeker?", null, "Ja, Zeker weten", true);
      this.confirmDialog = new EditorConfirmationDialog();
      confirmDialog.open(dialogSettings, null, item -> confirmFinalizeConfiguration(), null);
   }

   protected void confirmFinalizeConfiguration() {
      final CwsConfiguration cwsConfiguration = createCwsConfigurationFromSelection();
      configurationService.confirmFinalizeConfiguration(cwsConfiguration);
      confirmDialog.close();
      configuratieGridPanel.findConfiguratie(this.contractDetails);
   }

   private String getPdfKenmerk(){
      String propName = "pws09.kenmerk";
      appiConfigService.initialize();
      return appiConfigService.getValue(propName);
   }

   private void resetConfiguratieButtons() {
      modifyConfigurationButton.setEnabled(false);
      deleteConfigurationButton.setEnabled(false);
      viewConfigurationButton.setEnabled(false);
      finalizeConfigurationButton.setEnabled(false);

      generateProductSpecButton.setEnabled(false);
      exportConfigurationButton.setEnabled(false);
   }
}
