package nl.uwv.pws.cws.views.beheer.tabs.layout.cwsihp;

import nl.uwv.pws.cws.model.viewtab.BaseCwsOverzichtFilterOption;
import nl.uwv.pws.cws.model.viewtab.CwsIhpFilter;
import nl.uwv.pws.cws.views.beheer.tabs.layout.BaseOverzichtFilterLayout;

public class CwsIhpOverzichtFilterFormLayout extends BaseOverzichtFilterLayout {

   public CwsIhpOverzichtFilterFormLayout() {
     super(initiateCheckboxWithId("Filter beëindigd adres uitsluiten", CwsIhpFilter.BEEINDIGD_ADRES_UITSLUITEN_IHP));
    }

    @Override
    protected BaseCwsOverzichtFilterOption filterOptionValueOf(String id) {
        return CwsIhpFilter.valueOf(id);
    }
}
