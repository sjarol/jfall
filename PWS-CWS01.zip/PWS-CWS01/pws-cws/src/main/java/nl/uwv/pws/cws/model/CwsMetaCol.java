package nl.uwv.pws.cws.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.LinkedList;
import java.util.List;

@Getter
@Builder
@Setter
public class CwsMetaCol {
   private Long metaColId;
   private Long metaRootId;
   private Long parentId;
   private String techNaam;
   private String funcNaam;
   private String omschrijving;
   private Long volgnr;
   private String bronTabel;
   private String bronRubriek;
   private String indVerplicht;

   private CwsMetaCol parent;
   private List<CwsMetaCol> children;
   private boolean checked;
   private boolean displayIcon;
   private boolean enabled;

   public List<CwsMetaCol> updateDescendants(final boolean checked) {
      List<CwsMetaCol> changedDescendants = new LinkedList<>();
      setDescendantsChecked(children, checked, changedDescendants);
      return changedDescendants;
   }

   private void setDescendantsChecked(final List<CwsMetaCol> descendants, final boolean checked, final List<CwsMetaCol> changedDescendants) {
      if (descendants != null && !descendants.isEmpty()) {
         for (CwsMetaCol descendant : descendants) {
            if (descendant.isChecked() != checked) {
               descendant.setChecked(checked);
               changedDescendants.add(descendant);
            }
            setDescendantsChecked(descendant.getChildren(), checked, changedDescendants);
         }
      }
   }

   public List<CwsMetaCol> updateAscendants(final boolean selected) {
      LinkedList<CwsMetaCol> ascendants = new LinkedList<>();
      CwsMetaCol node = getParent();
      if (allDescendantsSelected(this) || noDescendantsSelected(this)) {
         this.displayIcon = false;
      }
      if (node != null) {
         updateFirstAscendant(node, selected);
         ascendants.add(node);
         ascendants.addAll(updateAscendantsSkipFirst(node));
      }
      return ascendants;
   }

   private void updateFirstAscendant(final CwsMetaCol ascendant, boolean selected) {
      boolean allDescendantsSelected = allDescendantsSelected(ascendant);
      if (allDescendantsSelected) {
         ascendant.checked = true;
         ascendant.displayIcon = false;
         return;
      }

      if (!selected && noDescendantsSelected(ascendant)) {
         ascendant.displayIcon = false;
         ascendant.checked = false;
      } else {
         ascendant.displayIcon = true;
      }
   }

   private List<CwsMetaCol> updateAscendantsSkipFirst(CwsMetaCol node) {
      LinkedList<CwsMetaCol> ascendants = new LinkedList<>();
      if (node != null) {
         node = node.getParent();
      }

      while (node != null) {
         if(noDescendantsSelected(node)) {
            node.displayIcon = false;
            node.checked = false;
         }else if(!allDescendantsSelected(node)){
            node.displayIcon = true;
         }
         ascendants.add(node);
         node = node.getParent();
      }
      return ascendants;
   }

   public void disableAllRequiredAndTheParents() {
      if (this.isRequired()) {
         this.enabled = false;
         this.checked = true;

         CwsMetaCol node = getParent();
         while (node != null) {
            boolean hasUnselectedDescendants = allDescendantsSelected(node);
            node.displayIcon = !hasUnselectedDescendants;
            node.checked = true;
            node.enabled = false;
            node = node.getParent();
         }
      } else {
         this.enabled = true;
      }
   }

   public void disableAllRequiredAndTheParentsIgnoreChecked() {
      if (this.isRequired()) {
         this.enabled = false;

         CwsMetaCol node = getParent();
         while (node != null) {
            boolean hasUnselectedDescendants = allDescendantsSelected(node);
            node.displayIcon = !hasUnselectedDescendants;
            node.enabled = false;
            node = node.getParent();
         }
      } else {
         this.enabled = true;
      }
   }

   public boolean isRequired() {
      return this.indVerplicht != null && this.indVerplicht.equalsIgnoreCase("J");
   }

   private boolean allDescendantsSelected(final CwsMetaCol node) {
      if (node.getChildren() == null) {
         return node.isChecked();
      }

      boolean allSelected = node.getChildren().stream().allMatch(child -> {
         if (child.getChildren() != null) {
            return allDescendantsSelected(child);
         }
         return child.isChecked();
      });
      return allSelected;
   }

   private boolean noDescendantsSelected(final CwsMetaCol node) {
      if (node.getChildren() == null) {
         return node.isChecked();
      }

      return node.getChildren().stream().allMatch(child -> {
         if (child.getChildren() != null) {
            return noDescendantsSelected(child);
         }

         return !child.isChecked();
      });
   }

   public boolean isParent(){
      return children != null && !children.isEmpty();
   }
}


