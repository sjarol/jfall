package nl.uwv.pws.cws.backend.dao;

import nl.uwv.pws.backend.dao.BackendException;
import nl.uwv.pws.backend.service.AbstractService;
import nl.uwv.pws.cws.backend.mapper.CodeSoortIkvRowMapper;
import nl.uwv.pws.cws.backend.mapper.CwsConfigurationRowMapper;
import nl.uwv.pws.cws.backend.mapper.CwsMetaColRowMapper;
import nl.uwv.pws.cws.backend.mapper.SelectionCriteriaRowMapper;
import nl.uwv.pws.cws.model.*;
import nl.uwv.pws.cws.util.ConfigurationStatus;
import nl.uwv.pws.cws.util.Constants;
import nl.uwv.pws.ui.util.UIUtils;
import oracle.jdbc.OracleTypes;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.naming.NamingException;
import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

import static java.util.stream.Collectors.toList;
import static nl.uwv.pws.cws.util.CwsUtils.getLocalDateAsLong;

public class CwsConfigurationDao extends AbstractService {
   private static final Logger LOG = LoggerFactory.getLogger(CwsConfigurationDao.class);
   private final CwsMetaColRowMapper cwsMetaColRowMapper;
   private final CwsConfigurationRowMapper cwsConfigurationRowMapper;
   private final SelectionCriteriaRowMapper selectionCriteriaRowMapper;
   private final CodeSoortIkvRowMapper codeSoortIkvRowMapper;

   private static volatile CwsConfigurationDao instance;
   private static final Object mutex = new Object();

   private CwsConfigurationDao() {
      super(Constants.DS_NAME);
      this.cwsMetaColRowMapper = new CwsMetaColRowMapper();
      this.cwsConfigurationRowMapper = new CwsConfigurationRowMapper();
      this.selectionCriteriaRowMapper = new SelectionCriteriaRowMapper();
      codeSoortIkvRowMapper = new CodeSoortIkvRowMapper();
   }

   /**
    * Using localRef, we are reducing the access of volatile variable to just one for positive usecase.
    * If we do not use localRef, then we would have to access volatile variable twice - once
    * for checking null and then at method return time.
    * Accessing volatile memory is quite an expensive affair because it involves reaching out to main memory.
    *
    * The second call to localRef = instance is Refreshing local reference to latest value after acquiring a lock,
    * since volatile variable may have changed by this time due.
    *
    * https://www.javacodemonk.com/threadsafe-singleton-design-pattern-java-806ad7e6
    *
    * @return CwsConfigurationDao
    **/
   public static CwsConfigurationDao getInstance() {
      CwsConfigurationDao localRef = instance;
      if (localRef == null) {
         synchronized (mutex) {
            localRef = instance;
            if (localRef == null)
               instance = localRef = new CwsConfigurationDao();
         }
      }

      return localRef;
   }

   public Long saveCwsConfiguratie(CwsConfiguration cwsConfiguration) {
      final String levCode = cwsConfiguration.getLeverCode();
      final Long contractId = cwsConfiguration.getContractId();
      final Long contractStartDate = getLocalDateAsLong(cwsConfiguration.getContractStartDate());
      final String naam = cwsConfiguration.getConfigurationName();
      final Long configStartDate = getLocalDateAsLong(cwsConfiguration.getConfigurationStartDate());
      final LocalDate configurationEndDate = cwsConfiguration.getConfigurationEndDate();
      final long configEndDate = configurationEndDate != null ? getLocalDateAsLong(configurationEndDate) : Long.parseLong(Constants.END_OF_TIME);
      final Long configVersie = cwsConfiguration.getConfigurationVersion() != null ? cwsConfiguration.getConfigurationVersion() : getNewConfigurationVersion(contractId, contractStartDate);
      final Timestamp hisTsIn = cwsConfiguration.getRegistrationStartDateTime() != null ? Timestamp.valueOf(cwsConfiguration.getRegistrationStartDateTime()) : Timestamp.valueOf(LocalDateTime.now());
      final String berichtVersie = cwsConfiguration.getBerichtVersie();
      final String configuredStatus = cwsConfiguration.getConfigurationStatus();
      final String status = configuredStatus != null ? configuredStatus : ConfigurationStatus.CO.name();

      Long configurationId = null;
      final ResultSet resultSet;
      final String[] idColumn = {"ccon_id"};
      final String insertQuery = "INSERT INTO cws_configuratie " +
            "(contract_id, cont_his_dat_in, naam, version, status, his_dat_in, his_ts_in, his_dat_end, his_ts_end, meta_root_id) " +
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, TO_TIMESTAMP('99991231', 'YYYYMMDD'), (SELECT meta_root_id FROM cws_meta_root WHERE lev_cd=? AND berichtversie=?))";
      try (Connection conn = getDataSource().getConnection()) {
         conn.setAutoCommit(false);
         try (PreparedStatement statement = conn.prepareStatement(insertQuery, idColumn)) {
            statement.setLong(1, contractId);
            statement.setLong(2, contractStartDate);
            statement.setString(3, naam);
            statement.setLong(4, configVersie);

            statement.setString(5, status);
            statement.setLong(6, configStartDate);
            statement.setTimestamp(7, hisTsIn);
            statement.setLong(8, configEndDate);
            statement.setString(9, levCode);
            statement.setString(10, berichtVersie);

            statement.execute();
            conn.commit();

            resultSet = statement.getGeneratedKeys();
            if (resultSet.next()) {
               configurationId = resultSet.getLong(1);
            }

         } catch (SQLException e) {
            rollback(conn);
         } finally {
            conn.setAutoCommit(true);
         }
      } catch (SQLException | NamingException e) {
         UIUtils.handleError(e);
         throw new BackendException("Fout bij het opslaan van configuratie", e);
      }

      return configurationId;
   }

   private Long getNewConfigurationVersion(long contractId, Long contractStartDate) {
      final String sqlQuery = "SELECT MAX(version) " +
            "FROM cws_configuratie " +
            "WHERE contract_id = ? " +
            "AND cont_his_dat_in = ? ";
      try (Connection conn = getDataSource().getConnection();
           PreparedStatement statement = conn.prepareStatement(sqlQuery)) {
         statement.setLong(1, contractId);
         statement.setLong(2, contractStartDate);

         long newVersion = 1L;
         try (ResultSet resultSet = statement.executeQuery()) {
            if (resultSet.next() && resultSet.getObject(1) != null) {
               newVersion = resultSet.getLong(1) + 1;
            }
         }
         return newVersion;

      } catch (SQLException | NamingException e) {
         UIUtils.handleError(e);
         throw new BackendException("Fout bij het ophalen van configuatie versie", e);
      }
   }

   public Timestamp deleteConfiguration(final Long configuratieId) {
      String sqlQueryUpdateConCol = "UPDATE cws_con_col SET his_ts_end=? WHERE ccon_id=?";
      String sqlQueryUpdateCwsConFilter = "UPDATE cws_con_filter SET his_ts_end=? WHERE ccon_id=?";
      String sqlQueryUpdateCwsConfiguratie = "UPDATE cws_configuratie SET his_ts_end=? WHERE ccon_id=?";

      final Timestamp timestamp = getSystimestamp();
      try (Connection conn = getDataSource().getConnection()) {
         conn.setAutoCommit(false);
         try (PreparedStatement statementUpdateConCol = conn.prepareStatement(sqlQueryUpdateConCol);
              PreparedStatement statementUpdateCwsConFilter = conn.prepareStatement(sqlQueryUpdateCwsConFilter);
              PreparedStatement statementUpdateCwsConfiguratie = conn.prepareStatement(sqlQueryUpdateCwsConfiguratie)) {
            statementUpdateConCol.setTimestamp(1, timestamp);
            statementUpdateConCol.setLong(2, configuratieId);
            statementUpdateConCol.executeUpdate();

            statementUpdateCwsConFilter.setTimestamp(1, timestamp);
            statementUpdateCwsConFilter.setLong(2, configuratieId);
            statementUpdateCwsConFilter.executeUpdate();

            statementUpdateCwsConfiguratie.setTimestamp(1, timestamp);
            statementUpdateCwsConfiguratie.setLong(2, configuratieId);
            statementUpdateCwsConfiguratie.executeUpdate();
         } catch (SQLException e) {
            rollback(conn);
         } finally {
            conn.setAutoCommit(true);
         }
      } catch (SQLException | NamingException e) {
         UIUtils.handleError(e);
         throw new BackendException("Fout bij het updaten van configuatie tabellen", e);
      }

      return timestamp;
   }

   public Map<Long, CwsMetaCol> getMetaDataByLeverCodeAndVersie(final String leverCode, final String berichtVersie) {
      String sqlQuery = "SELECT cmc.* " +
            "FROM cws_meta_col cmc " +
            "INNER JOIN cws_meta_root cmr " +
            "ON cmr.meta_root_id = cmc.meta_root_id " +
            "AND cmr.lev_cd = ? " +
            "AND cmr.berichtversie = ? " +
            "ORDER BY volgnr ASC";

      try (Connection conn = getDataSource().getConnection();
           PreparedStatement statement = conn.prepareStatement(sqlQuery)) {
         statement.setString(1, leverCode);
         statement.setString(2, berichtVersie);

         Map<Long, CwsMetaCol> cwsMetaColMap = new LinkedHashMap<>();
         Set<Long> parentIds = new HashSet<>();
         try (ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
               CwsMetaCol cwsMetaCol = cwsMetaColRowMapper.mapRow(resultSet);
               CwsMetaCol cwsMetaColParent = cwsMetaColMap.get(cwsMetaCol.getParentId());
               if (cwsMetaColParent != null) {
                  parentIds.add(cwsMetaColParent.getMetaColId());
                  cwsMetaCol.setParent(cwsMetaColParent);
               }
               cwsMetaColMap.put(cwsMetaCol.getMetaColId(), cwsMetaCol);
            }

            parentIds.forEach(id -> {
               List<CwsMetaCol> children = cwsMetaColMap.values().stream()
                     .filter(cwsMetaCol -> cwsMetaCol.getParentId().equals(id))
                     .collect(toList());
               CwsMetaCol cwsMetaCol = cwsMetaColMap.get(id);
               cwsMetaCol.setChildren(children);
            });

            return cwsMetaColMap;
         }
      } catch (SQLException | NamingException e) {
         UIUtils.handleError(e);
         throw new BackendException("Fout bij ophalen van CWS meta data", e);
      }
   }

   public CwsConfiguration getConfigurationByContractAndConfigVersion(final Long contractId, final Long contractStartDate, final Long configuratieVersion) {
      String sqlQuery = "SELECT con.*, cmr.* " +
            "FROM cws_configuratie con " +
            "INNER JOIN cws_meta_root cmr " +
            "ON cmr.meta_root_id = con.meta_root_id " +
            "WHERE con.contract_id = ? " +
            "AND con.cont_his_dat_in = ? " +
            "AND con.version = ? " +
            "AND con.his_ts_end = TO_TIMESTAMP('99991231', 'YYYYMMDD')";

      try (Connection conn = getDataSource().getConnection();
           PreparedStatement statement = conn.prepareStatement(sqlQuery)) {
         statement.setLong(1, contractId);
         statement.setLong(2, contractStartDate);
         statement.setLong(3, configuratieVersion);

         try (ResultSet resultSet = statement.executeQuery()) {
            if (resultSet.next()) {
               return cwsConfigurationRowMapper.mapRow(resultSet);
            }
         }
         return null;
      } catch (SQLException | NamingException e) {
         UIUtils.handleError(e);
         throw new BackendException("Fout bij ophalen van configuratie", e);
      }
   }

   public CwsConfiguration getConfigurationByConfigId(final Long configurationId) {
      String sqlQuery = "SELECT con.*, cmr.* " +
            "FROM cws_configuratie con " +
            "INNER JOIN cws_meta_root cmr " +
            "ON cmr.meta_root_id = con.meta_root_id " +
            "WHERE con.ccon_id = ? " +
            "AND con.his_ts_end = DATE '9999-12-31'";

      try (Connection conn = getDataSource().getConnection();
           PreparedStatement statement = conn.prepareStatement(sqlQuery)) {
         statement.setLong(1, configurationId);

         try (ResultSet resultSet = statement.executeQuery()) {
            if (resultSet.next()) {
               return cwsConfigurationRowMapper.mapRow(resultSet);
            }
         }
         return null;
      } catch (SQLException | NamingException e) {
         UIUtils.handleError(e);
         throw new BackendException("Fout bij ophalen van configuratie", e);
      }
   }

   public SelectionCriteria selectSelectionCriteriaByConfigId(final Long configurationId) {
      String sqlQuery = "SELECT " +
            "clf.lev_cd, " +
            "clf.tech_naam, " +
            "ccf.value " +
            "FROM cws_con_filter ccf " +
            "JOIN cws_lev_filter clf " +
            "ON clf.lev_filter_id = ccf.lev_filter_id " +
            "WHERE ccf.ccon_id = ? " +
            "AND ccf.his_ts_end = DATE '9999-12-31'";

      try (Connection conn = getDataSource().getConnection();
           PreparedStatement statement = conn.prepareStatement(sqlQuery)) {
         statement.setLong(1, configurationId);
         try (ResultSet resultSet = statement.executeQuery()) {
            LOG.debug("cconid: " + configurationId);
            return selectionCriteriaRowMapper.mapRow(resultSet);
         }
      } catch (SQLException | NamingException e) {
         UIUtils.handleError(e);
         throw new BackendException("Fout bij ophalen van configuratie", e);
      }
   }

   public List<CwsMetaCol> selectConfigurationMetaData(final Long configurationId) {
      String sqlQuery = " SELECT " +
            " cmc.* " +
            " FROM cws_meta_col cmc " +
            " JOIN cws_con_col ccc " +
            " ON cmc.meta_col_id = ccc.meta_col_id " +
            " WHERE ccc.ccon_id = :cconId " +
            " AND ccc.his_ts_end = DATE '9999-12-31'" +
            " ORDER BY cmc.volgnr asc";
      try (Connection conn = getDataSource().getConnection();
           PreparedStatement statement = conn.prepareStatement(sqlQuery)) {
         statement.setLong(1, configurationId);
         try (ResultSet resultSet = statement.executeQuery()) {
            LOG.debug("cconid: " + configurationId);
            List<CwsMetaCol> configurationMetaData = new ArrayList<>();
            while (resultSet.next()) {
               configurationMetaData.add(cwsMetaColRowMapper.mapRow(resultSet));
            }
            return configurationMetaData;
         }
      } catch (SQLException | NamingException e) {
         UIUtils.handleError(e);
         throw new BackendException("Fout bij ophalen van configuratie", e);
      }
   }

   public String getIndVipByAfnemerCode(String afnemerCode) {
      String sqlQuery = " SELECT " +
            " afn.IND_VIP " +
            " FROM AFN_AFNEMER afn " +
            " WHERE afn.afn_cd = :afnemerCode ";
      try (Connection conn = getDataSource().getConnection();
           PreparedStatement statement = conn.prepareStatement(sqlQuery)) {
         statement.setString(1, afnemerCode);
         try (ResultSet resultSet = statement.executeQuery()) {
            LOG.debug("afnemerCode: {}", afnemerCode);
            String indicatieVip = "N";
            while (resultSet.next()) {
               indicatieVip = resultSet.getString("IND_VIP");
            }
            return indicatieVip;
         }
      } catch (SQLException | NamingException e) {
         UIUtils.handleError(e);
         throw new BackendException("Fout bij ophalen van indicatie Vip", e);
      }
   }

   public String getUgcIdByAfnemerCode(final String afnemerCode) {
      String sqlQuery = " SELECT " +
            " afn.UGC_ID " +
            " FROM AFN_AFNEMER afn " +
            " WHERE afn.afn_cd = :afnemerCode ";

      try (Connection conn = getDataSource().getConnection();
           PreparedStatement statement = conn.prepareStatement(sqlQuery)) {
         statement.setString(1, afnemerCode);
         try (ResultSet resultSet = statement.executeQuery()) {
            LOG.debug("afnemerCode: {}", afnemerCode);
            String ugcId = "";
            while (resultSet.next()) {
               ugcId = resultSet.getString("UGC_ID");
            }
            return ugcId;
         }
      } catch (SQLException | NamingException e) {
         UIUtils.handleError(e);
         throw new BackendException("Fout bij ophalen van UGC Id", e);
      }
   }

   public Timestamp getSystimestamp() {
      String sqlQuery = "SELECT SYSTIMESTAMP FROM DUAL";
      Timestamp timestamp;
      try (Connection conn = getDataSource().getConnection();
           PreparedStatement statement = conn.prepareStatement(sqlQuery);
           ResultSet resultSet = statement.executeQuery()) {

         if (resultSet.next()) {
            timestamp = resultSet.getTimestamp(1);
         } else {
            throw new BackendException("Failed to determine transaction time.");
         }

         return timestamp;
      } catch (SQLException | NamingException e) {
         UIUtils.handleError(e);
         throw new BackendException("Fout bij ophalen van Oracle systeem time", e);
      }
   }

   public String getMaxBerichtVersie(String leverCode) {
      String maxBerichtVersie = null;
      String sqlVersionQuery = "SELECT MAX(berichtversie) " +
            "FROM cws_meta_root " +
            "WHERE lev_cd = ?";

      try (Connection conn = getDataSource().getConnection();
           PreparedStatement statement = conn.prepareStatement(sqlVersionQuery)) {
         statement.setString(1, leverCode);

         try (ResultSet resultSet = statement.executeQuery()) {
            if (resultSet.next() && resultSet.getObject(1) != null) {
               maxBerichtVersie = (String) resultSet.getObject(1);
            }
         }
         return maxBerichtVersie;
      } catch (SQLException | NamingException e) {
         UIUtils.handleError(e);
         throw new BackendException("Fout bij het ophalen van max bericht versie", e);
      }
   }

   public void saveConfigurationAttributes(final Long configurationId, final LocalDateTime registrationStartDate, final Set<Long> metadataAttributeIds) {
      String sqlQuery = "INSERT INTO cws_con_col " +
            "(ccon_id, his_ts_in, his_ts_end, meta_col_id) " +
            "VALUES (?, ?, DATE '9999-12-31', ?)";
      try (Connection conn = getDataSource().getConnection()) {
         conn.setAutoCommit(false);
         try (PreparedStatement statement = conn.prepareStatement(sqlQuery)) {
            metadataAttributeIds.stream().sorted().forEach(metadataId -> {
               try {
                  statement.setLong(1, configurationId);
                  statement.setTimestamp(2, Timestamp.valueOf(registrationStartDate));
                  statement.setLong(3, metadataId);
                  statement.addBatch();
               } catch (SQLException e) {
                  throw new BackendException(e.getLocalizedMessage(), e);
               }
            });
            statement.executeBatch();
            conn.commit();
         } catch (SQLException e) {
            rollback(conn);
         }
      } catch (SQLException | NamingException e) {
         UIUtils.handleError(e);
         throw new BackendException("Fout bij het opslaan van meta data attribute ids", e);
      }
   }

   public void saveSelectionCriteria(final Long configurationId, final LocalDateTime registrationStartDate, final SelectionCriteria selectionCriteria) {
      String sqlQuery = "INSERT INTO cws_con_filter " +
            "(ccon_id, lev_filter_id, value, his_ts_in, his_ts_end) " +
            "VALUES (?, (SELECT lev_filter_id FROM cws_lev_filter WHERE lev_cd = ? AND tech_naam = ?), ?, ?, DATE '9999-12-31')";

      try (Connection conn = getDataSource().getConnection()) {
         conn.setAutoCommit(false);
         try (PreparedStatement statement = conn.prepareStatement(sqlQuery)) {
            Map<BaseCwsFilterType, String> filterMap = selectionCriteria.getFilterMap();

            filterMap.keySet().stream().sorted().forEach(key -> {
               try {
                  statement.setLong(1, configurationId);
                  statement.setString(2, key.levCode());
                  statement.setString(3, key.filterName());
                  statement.setString(4, filterMap.get(key));
                  statement.setTimestamp(5, Timestamp.valueOf(registrationStartDate));
                  statement.addBatch();
               } catch (SQLException e) {
                  throw new BackendException(e.getLocalizedMessage(), e);
               }
            });
            statement.executeBatch();
            conn.commit();
         } catch (SQLException e) {
            rollback(conn);
         }
      } catch (SQLException | NamingException e) {
         UIUtils.handleError(e);
         throw new BackendException("Fout bij het opslaan van selectie criteria", e);
      }
   }

   public List<Long> selectCheckedMetadataAttributes(final Long configId) {
      String sqlQuery = "SELECT meta_col_id " +
            "FROM cws_con_col WHERE ccon_id = ? " +
            "AND his_ts_end = DATE '9999-12-31'";

      List<Long> checkedAttributes = new ArrayList<>();
      try (Connection conn = getDataSource().getConnection();
           PreparedStatement statement = conn.prepareStatement(sqlQuery)) {
         statement.setLong(1, configId);

         try (ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
               checkedAttributes.add(resultSet.getLong(1));
            }
         }

         return checkedAttributes;
      } catch (SQLException | NamingException e) {
         UIUtils.handleError(e);
         throw new BackendException("Fout bij het ophalen van selected meta data ", e);
      }
   }

   public boolean isAfnemerExtern(Long contractId, LocalDate contractStartDate) {
      String sqlQuery = " SELECT " +
            " aut.OIN " +
            " FROM AFN_AUTORISATIE_HIS aut " +
            " WHERE aut.CONTRACT_ID=? " +
            " AND aut.HIS_DAT_IN=? " +
            " AND " +
            " aut.HIS_TS_END=TO_TIMESTAMP('99991231', 'YYYYMMDD')";

      try (Connection conn = getDataSource().getConnection();
           PreparedStatement statement = conn.prepareStatement(sqlQuery)) {
         statement.setLong(1, contractId);
         statement.setLong(2, getLocalDateAsLong(contractStartDate));

         String oin = null;
         try (ResultSet resultSet = statement.executeQuery()) {
            if (resultSet.next()) {
               oin = resultSet.getString("OIN");
            }
         }

         return StringUtils.isNotBlank(oin);
      } catch (SQLException | NamingException e) {
         UIUtils.handleError(e);
         throw new BackendException("Fout bij het ophalen van selectie criteria", e);
      }
   }

   public int getAppiId(String programId, String envName, String instanceName, String release) {
      LOG.debug("Bepaal appiId voor programId {}, envName {}, instance {}, release {} ", programId, envName, instanceName, release);
      String sqlCall = "{ ? = call PPLS_PWS00.PWS_GUI.GET_APPI_ID(?, ?, ?, ?) }";
      int appiId;

      try (Connection conn = getDataSource().getConnection();
           CallableStatement callStmt = conn.prepareCall(sqlCall)) {
         callStmt.registerOutParameter(1, java.sql.Types.VARCHAR);
         callStmt.setString(2, programId);
         callStmt.setString(3, envName);
         callStmt.setString(4, instanceName);
         callStmt.setString(5, release);

         callStmt.execute();
         appiId = callStmt.getInt(1);
         LOG.debug("AppiId: {} ", appiId);
         return appiId;
      } catch (SQLException | NamingException e) {
         UIUtils.handleError(e);
         throw new BackendException("Fout bij het ophalen van app instance", e);
      }
   }

   public Properties getAppiConfig(int appiId) {
      LOG.debug("Haal applicatie configuratie op voor {}", appiId);
      Properties properties = new Properties();
      final String decodeKey = "eYYx+86j3Emzn49XMhJQZlFY3BDanj1f7kTeLfDl6Rs=";
      String sqlCall = "{ ? = call PPLS_PWS00.PWS_GUI.GET_APPI_CONFIG(?,?) }";

      try (Connection conn = getDataSource().getConnection();
           CallableStatement callStmt = conn.prepareCall(sqlCall)) {
         callStmt.registerOutParameter(1, OracleTypes.CURSOR);
         callStmt.setInt(2, appiId);
         callStmt.setString(3, decodeKey);
         callStmt.execute();

         try (ResultSet resultSet = (ResultSet) callStmt.getObject(1)) {
            while (resultSet.next()) {
               String propertyValue = resultSet.getString("prop_value");
               properties.setProperty(resultSet.getString("prop_name"), (StringUtils.isEmpty(propertyValue) ? "" : propertyValue));
            }
         }

         return properties;
      } catch (SQLException | NamingException e) {
         UIUtils.handleError(e);
         throw new BackendException("Fout bij het ophalen van app config", e);
      }
   }

   public List<CodeSoortIkv> findCodeSoortIkvStamgegevens(List<String> ikvCodes) {
      StringBuilder inParameterListBuilder = new StringBuilder(ikvCodes.size() * 2);
      for (int i = 0; i < ikvCodes.size(); i++) {
         inParameterListBuilder.append(",?");
      }

      String sqlQuery = "SELECT CODE, OMSCHRIJVING, DATUMEINDE FROM STAMGEGEVENS_VW " +
            "WHERE CODE IN (" + inParameterListBuilder.substring(1) + ")" +
            "AND CAT_CD = 'SIV'";

      try (Connection conn = getDataSource().getConnection();
           PreparedStatement statement = conn.prepareStatement(sqlQuery)) {
         for (int i = 0; i < ikvCodes.size(); i++) {
            statement.setString(i + 1, ikvCodes.get(i));
         }

         ArrayList<CodeSoortIkv> stamgegevens = new ArrayList<>();
         try (ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
               CodeSoortIkv codeSoortIkv = codeSoortIkvRowMapper.mapRow(resultSet);
               stamgegevens.add(codeSoortIkv);
            }
         }
         return stamgegevens;
      } catch (SQLException | NamingException e) {
         UIUtils.handleError(e);
         throw new BackendException("Fout bij het ophalen van code soort IKV", e);
      }
   }

   private void rollback(Connection conn) {
      if (conn != null) {
         try {
            conn.rollback();
         } catch (SQLException e) {
            LOG.warn("Rollback connection: " + e.getMessage());
         }
      }
   }
}



