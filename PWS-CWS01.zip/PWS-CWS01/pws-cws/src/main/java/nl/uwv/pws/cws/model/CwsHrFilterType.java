package nl.uwv.pws.cws.model;

import static nl.uwv.pws.cws.util.Constants.CWSHR_LEV_CODE;

public enum CwsHrFilterType implements BaseCwsFilterType {
    BEEINDIGD_ADRES_UITSLUITEN;

    @Override
    public String filterName() {
        return name();
    }

    @Override
    public String levCode() {
        return CWSHR_LEV_CODE;
    }
}
