package nl.uwv.pws.cws.views.beheer.levering;

import nl.uwv.pws.backend.filter.AbstractSqlFilter;

public class LeveringFilter extends AbstractSqlFilter {

   public LeveringFilter() {
      super("(" + LeveringColumn.LEV_CD + " IS NOT NULL AND UPPER(" + LeveringColumn.LEV_CD + ") LIKE '%CWS%')");
   }
}
