package nl.uwv.pws.cws.backend.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import nl.uwv.pws.backend.dao.BackendException;
import nl.uwv.pws.cws.model.CwsConfiguration;
import nl.uwv.pws.cws.model.CwsMetaCol;
import nl.uwv.pws.cws.model.SelectionCriteria;
import nl.uwv.pws.cws.model.specification.ImportableConfigurationSpecification;
import nl.uwv.pws.cws.util.CwsUtils;
import nl.uwv.pws.cws.views.beheer.SelectionCriteriaFactoryUtil;
import org.apache.commons.lang3.tuple.Pair;

import java.io.IOException;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.fasterxml.jackson.databind.SerializationFeature.INDENT_OUTPUT;
import static java.util.stream.Collectors.toMap;

@Slf4j
public class ImportService extends BaseService {
   private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper().enable(INDENT_OUTPUT);

   public CwsConfiguration importConfiguration(final String configSpecification, final Long contractId, final LocalDate contractStartDate){
      ImportableConfigurationSpecification importableConfiguratieSpec = jsonStringAsObject(configSpecification, ImportableConfigurationSpecification.class);
      ImportableConfigurationSpecification.Metadata metadata = importableConfiguratieSpec.getMetadata();
      ImportableConfigurationSpecification.Configuration configuration = importableConfiguratieSpec.getConfiguratie();

      CwsConfiguration importedConfiguration = mapToCwsConfiguration(metadata, configuration);
      List<String> importedAttributen = configuration.getAttributen();
      SelectionCriteria importedSelectionCriteria = SelectionCriteriaFactoryUtil.createGenericSelectieCriteria(metadata.getLevCode(), configuration.getSoortSelectie());
      validateConfigSpec(importedConfiguration.getContractId(), importedConfiguration.getContractStartDate(), contractId, contractStartDate);

      Map<Long, CwsMetaCol> metadataAttributes = cwsConfigurationDao.getMetaDataByLeverCodeAndVersie(importedConfiguration.getLeverCode(), importedConfiguration.getBerichtVersie());
      Set<Long> toImportMetaColIds = importableAttributenToMetaColIds(new ArrayList<>(metadataAttributes.values()), importedAttributen);

      CwsConfiguration existingConfiguration = cwsConfigurationDao.getConfigurationByContractAndConfigVersion(importedConfiguration.getContractId(),
            CwsUtils.getLocalDateAsLong(importedConfiguration.getContractStartDate()), importedConfiguration.getConfigurationVersion());

      if (existingConfiguration != null) {
         Timestamp importTimestamp = cwsConfigurationDao.deleteConfiguration(existingConfiguration.getConfigurationId());
         importedConfiguration.setRegistrationStartDateTime(importTimestamp.toLocalDateTime());
      }

      final Long configurationId = cwsConfigurationDao.saveCwsConfiguratie(importedConfiguration);
      importedConfiguration.setConfigurationId(configurationId);
      final LocalDateTime registrationStartDateTime = Optional.ofNullable(importedConfiguration.getRegistrationStartDateTime()).orElse(LocalDateTime.now());
      cwsConfigurationDao.saveSelectionCriteria(configurationId, registrationStartDateTime, importedSelectionCriteria);
      cwsConfigurationDao.saveConfigurationAttributes(configurationId, registrationStartDateTime, toImportMetaColIds);

      log.info("Import van configuratie met configuratie specification {} is succesvol afgerond", configSpecification);
      return importedConfiguration;
   }

   private CwsConfiguration mapToCwsConfiguration(final ImportableConfigurationSpecification.Metadata metadata, final ImportableConfigurationSpecification.Configuration configuration) {
      return CwsConfiguration.builder()
            .leverCode(metadata.getLevCode())
            .berichtVersie(metadata.getBerichtversie())
            .contractId(configuration.getContractId())
            .contractStartDate(CwsUtils.getLongAsLocalDate(configuration.getContractStartDate()))
            .configurationVersion(configuration.getVersion())
            .configurationName(configuration.getNaam())
            .configurationStartDate(CwsUtils.getLongAsLocalDate(configuration.getContractStartDate()))
            .configurationEndDate(CwsUtils.getLongAsLocalDate(configuration.getEndDate()))
            .configurationStatus(configuration.getStatus().name())
            .build();
   }

   private Set<Long> importableAttributenToMetaColIds(List<CwsMetaCol> cwsMetaColList, List<String> toImportAttributen) {
      Map<String, Long> chainNameMetaColIdMap = toMapOfChainNameAndMetaColId(cwsMetaColList);
      return toImportAttributen.stream()
            .filter(key -> chainNameMetaColIdMap.get(key) != null)
            .map(chainNameMetaColIdMap::get)
            .collect(Collectors.toCollection(TreeSet::new));
   }

   private void validateConfigSpec(final Long importedContractId, final LocalDate importedContractStartDate, final Long contractId, final LocalDate contractStartDate) {
      if (!importedContractId.equals(contractId) ||
            !importedContractStartDate.equals(contractStartDate)) {
         throw new BackendException("Contractnummer en Datum aanvang Contract uit het  importbestand wijken af van het, via het scherm, geselecteerde Contractnummer en Datum aanvang Contract");
      }
   }

   private Map<String, Long> toMapOfChainNameAndMetaColId(List<CwsMetaCol> cwsMetaColList) {
      Map<CwsMetaCol, Map> map = buildAttributesTreeAsConfigurationAttribute(cwsMetaColList);
      List<Pair<String, Long>> chainNameToMetaColIdList = new ArrayList<>();
      addChildrenChainToList(chainNameToMetaColIdList, map, "");
      return chainNameToMetaColIdList.parallelStream()
            .collect(toMap(Pair::getLeft, Pair::getRight));
   }

   private Map<CwsMetaCol, Map> buildAttributesTreeAsConfigurationAttribute(List<CwsMetaCol> cwsMetaColList) {
      return buildAttributesTree(cwsMetaColList, Function.identity());
   }

   private void addChildrenChainToList(List<Pair<String, Long>> exportableAttributes, Map<CwsMetaCol, Map> childrenMap, String parentAttributeChain) {
      childrenMap.forEach((attribute, children) -> {
         String attributeChain = parentAttributeChain + attribute.getTechNaam();
         exportableAttributes.add(Pair.of(attributeChain.toUpperCase(), attribute.getMetaColId()));
         if (children != null && !children.isEmpty()) {
            addChildrenChainToList(exportableAttributes, children, attributeChain + ".");
         }
      });
   }

   private static <T> T jsonStringAsObject(String jsonString, Class<T> expectedClass) {
      try {
         return OBJECT_MAPPER.readValue(jsonString, expectedClass);
      } catch (IOException e) {
         log.error("Error : " + e.getMessage(), e);
         throw new BackendException("Het bestand kan niet verwerkt worden.", e);
      }
   }
}
