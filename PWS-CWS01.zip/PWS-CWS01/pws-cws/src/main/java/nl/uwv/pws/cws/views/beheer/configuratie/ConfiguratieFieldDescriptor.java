package nl.uwv.pws.cws.views.beheer.configuratie;

import nl.uwv.pws.backend.desc.FieldDescParser;
import nl.uwv.pws.backend.desc.FieldDescriptor;

/**
 * FieldDescriptor that reads its column definitions from the file configuratie.desc.
 */
final class ConfiguratieFieldDescriptor extends FieldDescriptor {
   private static final ConfiguratieFieldDescriptor INSTANCE = new ConfiguratieFieldDescriptor(
         ConfiguratieFieldDescriptor.class.getPackage().getName().replace('.', '/') + "/configuratie.desc"
   );

   private ConfiguratieFieldDescriptor(final String resource) {
      super(new FieldDescParser().parse(resource));
   }

   static ConfiguratieFieldDescriptor getInstance() {
      return INSTANCE;
   }
}
