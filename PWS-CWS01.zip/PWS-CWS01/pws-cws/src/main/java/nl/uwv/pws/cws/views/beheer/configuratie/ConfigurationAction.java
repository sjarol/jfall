package nl.uwv.pws.cws.views.beheer.configuratie;

public enum ConfigurationAction {
        ADD,
        MODIFY,
        VIEW,
        DELETE
}
