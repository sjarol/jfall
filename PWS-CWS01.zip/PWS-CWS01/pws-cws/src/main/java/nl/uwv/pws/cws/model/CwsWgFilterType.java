package nl.uwv.pws.cws.model;

import static nl.uwv.pws.cws.util.Constants.CWSWG_LEV_CODE;

public enum CwsWgFilterType implements BaseCwsFilterType {
    BEEINDIGD_ADRES_UITSLUITEN_WG;

    @Override
    public String filterName() {
        return name();
    }

    @Override
    public String levCode() {
        return CWSWG_LEV_CODE;
    }
}
