package nl.uwv.pws.cws.views.beheer.tabs.events;

import com.vaadin.flow.component.ComponentEvent;
import lombok.Getter;
import nl.uwv.pws.cws.views.beheer.contract.ContractGridPanel;

import java.math.BigDecimal;
import java.time.LocalDate;

@Getter
public class ConfiguratieSearchEvent extends ComponentEvent<ContractGridPanel> {

   private BigDecimal selectedContractId;
   private LocalDate selectedStartDate;

   public ConfiguratieSearchEvent(ContractGridPanel source, boolean fromClient, BigDecimal selectedContractId, LocalDate selectedStartDate) {
      super(source, fromClient);

      this.selectedContractId = selectedContractId;
      this.selectedStartDate = selectedStartDate;
   }
}
