package nl.uwv.pws.cws.util;

import java.io.Serializable;
import java.util.Properties;

/**
 * De standaardimplementatie van System.properties is niet thread safe. Als
 * gevolg hiervan zijn de gevolgen van het wijzigen van een System property niet
 * te voorspellen. Deze class is wel thread safe en dient ter vervanging van de
 * standaardimplementatie van System.properties.
 *
 * @credits http://stackoverflow.com/questions/9579958/system-setproperty-used-by-a-thread-impacts-other-
 *          thread-in-communication-to-ext
 */
public final class ThreadLocalProperties extends Properties implements Serializable {
	/**
	 *
	 */
	private static final long serialVersionUID = 8374928768105023137L;

	/**
	 * overschrijft de standaardproperties met ThreadLocalProperties
	 */
	private static void init() {
		System.setProperties(new ThreadLocalProperties(System.getProperties()));
	}

	private final transient ThreadLocal<Properties> localProperties = new ThreadLocal<Properties>() {
		@Override
		protected Properties initialValue() {
			return new Properties();
		}
	};

	private ThreadLocalProperties(Properties properties) {
		super(properties);
	}

	@Override
	public String getProperty(String key) {
		String localValue = localProperties.get().getProperty(key);
		return localValue == null ? super.getProperty(key) : localValue;
	}

	@Override
	public Object setProperty(String key, String value) {
		if (value == null && localProperties.get().containsKey(key)) {
			localProperties.get().remove(key);
			return null;
		} else {
			return localProperties.get().setProperty(key, value);
		}
	}

	/**
	 * Deze method dient aangeroepen te worden voordat properties worden
	 * opgevraagd
	 */
	public static synchronized void assertPropertiesAreThreadSafe() {
		if (!(System.getProperties() instanceof ThreadLocalProperties)) {
			init();
		}
	}
}
