package nl.uwv.pws.cws.views.beheer.configuratie;

import nl.uwv.pws.backend.types.Column;

/**
 * List of columns in the view CWS_CONFIGURATIE_VW.
 */
public enum ConfiguratieColumn implements Column {
   CCON_ID,
   CONTRACT_ID,
   CONT_HIS_DAT_IN,
   VERSION,
   STATUS,
   BERICHTVERSIE,
   NAAM,
   HIS_DAT_IN,
   HIS_DAT_END
}
