package nl.uwv.pws.cws.util;

import com.vaadin.flow.component.AbstractField.ComponentValueChangeEvent;
import com.vaadin.flow.component.checkbox.Checkbox;
import com.vaadin.flow.data.provider.hierarchy.HierarchicalDataProvider;
import com.vaadin.flow.function.SerializablePredicate;
import nl.uwv.pws.cws.model.CwsMetaCol;

@FunctionalInterface
public interface TreeGridValueChangeListenerConsumer <T extends ComponentValueChangeEvent<Checkbox, Boolean>,
      U extends CwsMetaCol, V extends HierarchicalDataProvider<CwsMetaCol, SerializablePredicate<CwsMetaCol>>> {
      void checkboxSelected(T t, U u, V v);
}
