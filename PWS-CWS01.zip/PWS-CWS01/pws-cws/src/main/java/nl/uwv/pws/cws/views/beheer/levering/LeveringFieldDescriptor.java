package nl.uwv.pws.cws.views.beheer.levering;

import nl.uwv.pws.backend.desc.FieldDescParser;
import nl.uwv.pws.backend.desc.FieldDescriptor;

/**
 * FieldDescriptor that reads its column definitions from the file levering.desc.
 */
final class LeveringFieldDescriptor extends FieldDescriptor {
   private static final LeveringFieldDescriptor INSTANCE = new LeveringFieldDescriptor(
         LeveringFieldDescriptor.class.getPackage().getName().replace('.', '/') + "/levering.desc"
   );

   private LeveringFieldDescriptor(final String resource) {
      super(new FieldDescParser().parse(resource));
   }

   static LeveringFieldDescriptor getInstance() {
      return INSTANCE;
   }
}
