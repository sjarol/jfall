package nl.uwv.pws.cws.model.specification;

import java.util.Arrays;

public enum ExportFunctionVersion {
    V1("6fd8504fea9f698ca805bc0b8f6afe54");

    private String checksum;
    ExportFunctionVersion(String checksum) {
        this.checksum = checksum;
    }

    public static ExportFunctionVersion mostRecentVersion() {
        int maxVersionNumber = Arrays.stream(values())
            .map(value -> value.name().substring(1))
            .mapToInt(Integer::valueOf)
            .max()
            .getAsInt();

        return valueOf("V" + maxVersionNumber);
    }
}//NOTE: This is the calculated checksum of ExportableConfigurationSpecification. If the checksum mismatched the last version value, it is time to create new version. ExportFunctionVersion checksum: 6fd8504fea9f698ca805bc0b8f6afe54
