package nl.uwv.pws.cws.model;

import lombok.Builder;
import lombok.Getter;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Builder
@Getter
public class ConfigurationDetails {
   private BigDecimal configurationId;
   private BigDecimal configurationVersion;
   private String configurationStatus;

   private String berichtVersie;
   private String configurationName;
   private LocalDate configurationStartDate;
   private LocalDate configurationEndDate;
}
