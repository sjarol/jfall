package nl.uwv.pws.cws.model;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class SearchCriteria {
   private String afnemerCode;
   private String afnemerNaam;
   private String ugcId;
   private String contractId;
}
