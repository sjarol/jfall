package nl.uwv.pws.cws.backend.service.cwswg;

import nl.uwv.pws.cws.backend.service.BaseProductSpecContentGeneratorService;
import nl.uwv.pws.cws.model.*;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import static nl.uwv.pws.cws.util.CwsUtils.convertStringToBoolean;
import static org.apache.commons.lang3.StringUtils.isEmpty;

public class CwsWgProductSpecContentGeneratorService extends BaseProductSpecContentGeneratorService {
   private static final String CWSWG_PDFTEMPLATE = "../templates/cwswg-product-specificatie-template.odt";
   private static final String CWSWG_EXAMPLE_FOLDER = "cwswg/";
   private static final String CWSWG_RESPONSE_ROOT_ELEMENT = "CwsWerkgeverresponse";
   private static final String SIMPLE_RESPONSE_FILE_NAME = "Response_simpel.xml";
   private static final String COMPLEX_RESPONSE_FILE_NAME = "Response_complex.xml";
   private static final String FILTERED_COMPLEX_RESPONSE_FILE_NAME = "Response_filtered_complex.xml";
   protected static final String REQUEST_MULTI_FILE_NAMES = "Request_administratieveeenheid.xml;Request_persooninhoudingsplicht.xml;Request_werkgeverkvk.xml";

   public CwsWgProductSpecContentGeneratorService(final CwsConfiguration cwsConfiguration, final String pdfKenmerk,
                                                  final String requestHeader, final String responseHeader) {
      super(cwsConfiguration, pdfKenmerk, requestHeader, responseHeader);
   }

   @Override
   protected String[] getExampleRequestFileNames() {
      return REQUEST_MULTI_FILE_NAMES.split(";");
   }

   @Override
   protected String getPdfTemplateFileName() {
      return CWSWG_PDFTEMPLATE;
   }

   @Override
   protected String getExampleXmlFolderName() {
      return CWSWG_EXAMPLE_FOLDER;
   }

   @Override
   protected String getResponseBodyRootElementName() {
      return CWSWG_RESPONSE_ROOT_ELEMENT;
   }

   @Override
   public String generateComplexExampleResponseFileName() {
      return generateXmlNameForFile(COMPLEX_RESPONSE_FILE_NAME);
   }

   @Override
   public String generateFilteredComplexExampleResponseContent() throws IOException, SAXException, ParserConfigurationException {
      return generateExampleResponseContent(FILTERED_COMPLEX_RESPONSE_FILE_NAME);
   }

   @Override
   public String generateComplexExampleResponseContent() throws IOException, SAXException, ParserConfigurationException {
      return generateExampleResponseContent(COMPLEX_RESPONSE_FILE_NAME);
   }

   @Override
   public String generateSimpleExampleResponseFileName() {
      return generateXmlNameForFile(SIMPLE_RESPONSE_FILE_NAME);
   }

   @Override
   public String generateSimpleExampleResponseContent() throws IOException, SAXException, ParserConfigurationException {
      return generateExampleResponseContent(SIMPLE_RESPONSE_FILE_NAME);
   }

   @Override
   public Map<String, Object> getSelectieCriteriaMapping() {
      Map<String, Object> mapping = new HashMap<>();

      Map<BaseCwsFilterType, String> filterMap = selectionCriteria.getFilterMap();
      mapping.put("condition_beeindigdAdresUitsluiten", Boolean.toString(convertStringToBoolean(filterMap.get(CwsWgFilterType.BEEINDIGD_ADRES_UITSLUITEN_WG))));

      return mapping;
   }
}
