package nl.uwv.pws.cws.util;

import nl.uwv.pws.cws.exception.FormValidationException;
import nl.uwv.pws.cws.model.CwsMetaCol;

import java.time.LocalDate;
import java.util.*;

public class Validator {

   public void validateAfnemerConfiguratiePeriod(final LocalDate contractStartDate, final LocalDate contractEndDate, final LocalDate configurationBeginDate, final LocalDate configurationEndDate) {

      if (configurationBeginDate.isBefore(contractStartDate)) {
         throw new FormValidationException("Begindatum configuratie mag niet voor begindatum contract liggen");
      } else if (contractEndDate != null && configurationBeginDate.isAfter(contractEndDate)) {
         throw new FormValidationException("Begindatum configuratie mag niet na einddatum contract liggen");
      }

      if (configurationEndDate != null) {
         if (contractEndDate != null && configurationEndDate.isAfter(contractEndDate)) {
            throw new FormValidationException("Einddatum configuratie mag niet na einddatum contract liggen");
         }
         if (configurationEndDate.isBefore(configurationBeginDate)) {
            throw new FormValidationException("Einddatum configuratie mag niet voor begindatum configuratie liggen");
         }
      }
   }


   public void validateAtLeastOneAttributeChecked(final Set<Long> selectedIds) {
      if (selectedIds.isEmpty()) {
         throw new FormValidationException("Selecteer minstens één attribuut");
      }
   }

   public void isValid(Map<Long, CwsMetaCol> metaColMap, final String adresParentItem) {
      CwsMetaCol targetParent = findCwsMetaColByTechnicalName(new ArrayList<>(metaColMap.values()), adresParentItem);
      CwsMetaCol rootAdreshouding = findCwsMetaColByTechnicalName(targetParent.getChildren(), "adreshouding"); //get root adres parent

      rootAdreshouding.getChildren().stream()
            .forEach(cwsMetaCol -> {
         final boolean codeAfgeschermdAdresPresent = isRequiredFieldPresent(cwsMetaCol, "cdAfgeschermdAdres");

         final boolean adresMemberSelected = anyAdresMemberSelected(cwsMetaCol);
         final boolean codeAdresrolChecked = requiredFieldSelected(cwsMetaCol, "cdAdresrol");
         final boolean codeAfgeschermdAdresChecked = requiredFieldSelected(cwsMetaCol, "cdAfgeschermdAdres");
         final boolean validateCodeAfgeschermdAdres = (adresParentItem.equalsIgnoreCase("persoon") ||
               adresParentItem.equalsIgnoreCase("vestiginghandelsregister") ||
               adresParentItem.equalsIgnoreCase("persooninhoudingsplichtige"));

         if ((adresMemberSelected && !codeAdresrolChecked) || (!codeAdresrolChecked && codeAfgeschermdAdresChecked)) {
            throw new FormValidationException(
                  String.format("Selecteer ook 'Code adresrol' in %s > %s", targetParent.getFuncNaam(), cwsMetaCol.getFuncNaam()));
         }

         if (codeAfgeschermdAdresPresent && (
               (validateCodeAfgeschermdAdres && adresMemberSelected && !codeAfgeschermdAdresChecked) ||
                     (codeAdresrolChecked && !codeAfgeschermdAdresChecked))) {
            throw new FormValidationException(
                  String.format("Selecteer ook 'Code afgeschermd adres' in %s > %s", targetParent.getFuncNaam(), cwsMetaCol.getFuncNaam()));
         }
      });
   }

   private CwsMetaCol findCwsMetaColByTechnicalName(final List<CwsMetaCol> cwsMetaColList, final String technicalName) {
      return cwsMetaColList.stream()
            .filter(cwsMetaCol -> cwsMetaCol.getTechNaam().equalsIgnoreCase(technicalName))
            .findFirst().orElseThrow(() -> new IllegalStateException("Invalid technical name provided to search in meta data "));
   }

   private boolean anyAdresMemberSelected(final CwsMetaCol cwsMetaCol) {
      long count = cwsMetaCol.getChildren().stream()
            .filter(cwsMetaColAdresMember -> {

               if (cwsMetaColAdresMember.getChildren() != null ) {
                  return anyAdresMemberSelected(cwsMetaColAdresMember);
               }

               final String technicalName = cwsMetaColAdresMember.getTechNaam();
               return !(technicalName.equalsIgnoreCase("cdAdresrol") || technicalName.equalsIgnoreCase("cdAfgeschermdAdres"))
                     && cwsMetaColAdresMember.isChecked();
            }).count();

      return count > 0;
   }

   private boolean isRequiredFieldPresent(final CwsMetaCol cwsMetaCol, final String fieldName) {
      long count = cwsMetaCol.getChildren().stream()
            .filter(cwsMetaColAdresMember -> {
               final String technicalName = cwsMetaColAdresMember.getTechNaam();
               return technicalName.equalsIgnoreCase(fieldName);
            }).count();

      return count > 0;
   }


   private boolean requiredFieldSelected(final CwsMetaCol cwsMetaCol, final String fieldToValidate) {
      Optional<CwsMetaCol> validCwsMetaCol = cwsMetaCol.getChildren().stream().filter(cwsMetaColAdresMember -> {
         final String technicalName = cwsMetaColAdresMember.getTechNaam();
         if (technicalName.equalsIgnoreCase(fieldToValidate)) {
            return cwsMetaColAdresMember.isChecked();
         }
         return false;
      }).findFirst();

      return validCwsMetaCol.isPresent();
   }
}
