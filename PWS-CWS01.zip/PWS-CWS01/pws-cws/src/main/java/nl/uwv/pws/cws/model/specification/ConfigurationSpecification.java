package nl.uwv.pws.cws.model.specification;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import lombok.Getter;
import lombok.Setter;
import nl.uwv.pws.cws.model.BaseCwsFilterType;
import nl.uwv.pws.cws.util.ConfigurationStatus;
import nl.uwv.pws.cws.util.CwsFilterTypeDeserializer;

import java.util.List;
import java.util.Map;

@Getter
@Setter
public class ConfigurationSpecification {

   private ExportFunctionVersion exportFunctionVersion;
   private ExportableConfigurationSpecification.Metadata metadata;
   private ExportableConfigurationSpecification.Configuration configuratie;

   @Getter
   @Setter
   public static class Metadata {
      private String levCode;
      private String berichtversie;
   }

   @Getter
   @Setter
   public static class Configuration {
      private Long contractId;
      private Long contractStartDate;
      private String naam;
      private Long version;
      private ConfigurationStatus status;
      private Long startDate;
      private Long endDate;

      @JsonDeserialize(keyUsing = CwsFilterTypeDeserializer.class)
      private Map<BaseCwsFilterType, String> soortSelectie;
      private List<String> attributen;
   }
}
