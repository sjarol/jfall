package nl.uwv.pws.cws.views.beheer.tabs.layout;

import com.vaadin.flow.component.formlayout.FormLayout;
import nl.uwv.pws.cws.exception.FormValidationException;
import nl.uwv.pws.cws.model.SelectionCriteria;
import nl.uwv.pws.cws.views.beheer.configuratie.ConfigurationAction;

public abstract class BaseSelectionCriteriaFormLayout extends FormLayout {
   public abstract SelectionCriteria determineSelectionCriteria();

   public abstract void validate() throws FormValidationException;

   public abstract boolean originalValuesHaveNotChanged();

   public abstract FormLayout createSelectionCriteriaLayout(SelectionCriteria selectedSelectionCriteria, ConfigurationAction configurationAction);
}
