package nl.uwv.pws.cws.model;

import static nl.uwv.pws.cws.util.Constants.CWSIHP_LEV_CODE;

public enum CwsIhpFilterType implements BaseCwsFilterType {
    BEEINDIGD_ADRES_UITSLUITEN_IHP;

    @Override
    public String filterName() {
        return name();
    }

    @Override
    public String levCode() {
        return CWSIHP_LEV_CODE;
    }
}
