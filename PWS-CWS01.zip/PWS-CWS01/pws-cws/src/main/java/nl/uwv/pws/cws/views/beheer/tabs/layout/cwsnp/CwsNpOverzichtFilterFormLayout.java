package nl.uwv.pws.cws.views.beheer.tabs.layout.cwsnp;

import nl.uwv.pws.cws.model.viewtab.BaseCwsOverzichtFilterOption;
import nl.uwv.pws.cws.model.viewtab.CwsNpFilter;
import nl.uwv.pws.cws.views.beheer.tabs.layout.BaseOverzichtFilterLayout;

public class CwsNpOverzichtFilterFormLayout extends BaseOverzichtFilterLayout {

   public CwsNpOverzichtFilterFormLayout() {
        super(initiateCheckboxWithId("Filter levend persoon uitsluiten", CwsNpFilter.LEVEND_NPE_UITSLUITEN),
              initiateCheckboxWithId("Filter overleden persoon uitsluiten", CwsNpFilter.OVERLEDEN_NPE_UITSLUITEN)
             );
    }

    @Override
    protected BaseCwsOverzichtFilterOption filterOptionValueOf(String id) {
        return CwsNpFilter.valueOf(id);
    }
}
