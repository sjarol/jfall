package nl.uwv.pws.cws.views.beheer.levering;

import com.vaadin.flow.data.provider.QuerySortOrder;
import com.vaadin.flow.data.provider.SortDirection;
import nl.uwv.pws.backend.desc.FieldDescriptor;
import nl.uwv.pws.backend.service.AbstractListService;

public class LeveringService extends AbstractListService {
   private static final String VIEW_NAME = "AFN_LEVERING_TYPE";

   LeveringService(final String dataSourceName) {
      super(dataSourceName);
   }

   protected String getViewName() {
      return VIEW_NAME;
   }

   public FieldDescriptor getDescriptor() {
      return LeveringFieldDescriptor.getInstance();
   }

   protected QuerySortOrder getDefaultSortOrder() {
      return new QuerySortOrder(LeveringColumn.LEV_CD.name(), SortDirection.ASCENDING);
   }
}
