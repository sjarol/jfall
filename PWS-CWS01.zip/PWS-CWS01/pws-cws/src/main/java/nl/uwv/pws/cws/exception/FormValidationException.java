package nl.uwv.pws.cws.exception;

public class FormValidationException extends RuntimeException {
	public FormValidationException(String message) {
        super(message);
    }
}
