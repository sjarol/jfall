package nl.uwv.pws.cws.views.beheer.contract;

import com.vaadin.flow.component.AbstractField.ComponentValueChangeEvent;
import com.vaadin.flow.component.HasValue.ValueChangeListener;
import com.vaadin.flow.component.grid.Grid;
import lombok.Getter;
import nl.uwv.pws.backend.filter.AbstractSqlFilter;
import nl.uwv.pws.backend.service.CountRowsListener;
import nl.uwv.pws.backend.types.ColumnList;
import nl.uwv.pws.cws.util.Constants;
import nl.uwv.pws.cws.views.beheer.common.AbstractBeheerConfiguratieGridPanel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static nl.uwv.pws.cws.util.Constants.CONTRACTEN_CAPTION;

@Getter
public class ContractGridPanel extends AbstractBeheerConfiguratieGridPanel<AbstractSqlFilter> {
   private static final Logger LOG = LoggerFactory.getLogger(ContractGridPanel.class);

   public ContractGridPanel(final ValueChangeListener<ComponentValueChangeEvent<Grid<ColumnList>, ColumnList>> valueChangeListener,
                            final CountRowsListener countRowsListener,
                            final String componentId,
                            final ContractServiceType serviceType) {
      super(componentId, CONTRACTEN_CAPTION,
            new ContractService(Constants.DS_NAME, serviceType),
            valueChangeListener, countRowsListener);
   }

   public void findContractsByContractId(final String contractId) {
      LOG.debug("Finding contracts using contract id {}", contractId);
      search(new ContractByContractIdFilter(contractId));
   }

   public void findContractsByAfnemerCode(final String afnemerCode) {
      LOG.debug("Finding contracts using afnemerCode code {}", afnemerCode);
      search(new ContractByAfnemerCodeFilter(afnemerCode));
   }

   public void findContractsByLeveringCode(final String leveringCode) {
      LOG.debug("Finding contracts using leveringCode code {}", leveringCode);
      search(new ContractByLeveringCodeFilter(leveringCode));
   }
}
