package nl.uwv.pws.cws.model;

import lombok.Builder;
import lombok.Getter;

import java.math.BigDecimal;
import java.time.LocalDate;

@Builder
@Getter
public class ContractDetails {
   private BigDecimal contractId;
   private LocalDate contractStartDate;
   private LocalDate contractEndDate;
   private String afnemerCode;
   private String afnemerNaam;
   private String leverCode;
}
