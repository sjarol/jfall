package nl.uwv.pws.cws.model.viewtab;

import nl.uwv.pws.backend.dao.BackendException;

import static nl.uwv.pws.cws.util.Constants.*;

public final class CwsOverzichtFilterUtil {
    private CwsOverzichtFilterUtil() {
    }

    public static boolean testCwsOverzichtFilterCondition(String levCode, String filterName, String value) {
        BaseCwsOverzichtFilterOption cwsOverzichtFilterOption;
        if (CWSLA_LEV_CODE.equals(levCode)) {
            cwsOverzichtFilterOption = CwsLaFilter.valueOf(filterName);
        } else if (CWSNP_LEV_CODE.equals(levCode)) {
            cwsOverzichtFilterOption = CwsNpFilter.valueOf(filterName);
        } else if (CWSHR_LEV_CODE.equals(levCode)) {
            cwsOverzichtFilterOption = CwsHrFilter.valueOf(filterName);
        } else if (CWSWG_LEV_CODE.equals(levCode)) {
           cwsOverzichtFilterOption = CwsWgFilter.valueOf(filterName);
        } else if (CWSIHP_LEV_CODE.equals(levCode)) {
           cwsOverzichtFilterOption = CwsIhpFilter.valueOf(filterName);
        } else {
            throw new BackendException("Unknown SelectieCriteria Lev Code");
        }
        return cwsOverzichtFilterOption.testCondition(value);
    }
}
