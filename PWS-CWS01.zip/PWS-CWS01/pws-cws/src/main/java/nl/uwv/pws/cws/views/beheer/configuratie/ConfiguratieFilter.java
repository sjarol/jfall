package nl.uwv.pws.cws.views.beheer.configuratie;

import nl.uwv.pws.backend.dao.SqlFilter;
import nl.uwv.pws.ui.util.DateUtils;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;


public class ConfiguratieFilter implements SqlFilter, Serializable {
   private final String sqlFilter;
   private final List<String> parameters = new ArrayList<>();

   public ConfiguratieFilter(final BigDecimal contractId, LocalDate contractStartDate) {
      this.sqlFilter = createSqlFilter(contractId, contractStartDate);
   }


   private String createSqlFilter(final BigDecimal contractId, final LocalDate contractBeginDatum) {
      // Non-String parameters, create full where-clause without dynamic parameters
      return String.format(
            "(%s = %d AND %s = %s)",
            ConfiguratieColumn.CONTRACT_ID,
            contractId.longValue(),
            ConfiguratieColumn.CONT_HIS_DAT_IN,
            DateUtils.localDateToOraDateConstant(contractBeginDatum)
      );
   }

   @Override
   public String getFilterSql() {
      return sqlFilter;
   }

   @Override
   public int getParametersSize() {
      return parameters.size();
   }

   @Override
   public String getParameter(final int index) {
      return parameters.get(index);
   }
}
