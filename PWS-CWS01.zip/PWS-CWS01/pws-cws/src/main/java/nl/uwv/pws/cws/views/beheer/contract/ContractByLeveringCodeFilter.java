package nl.uwv.pws.cws.views.beheer.contract;

import nl.uwv.pws.backend.filter.AbstractSqlFilter;
import org.apache.commons.lang3.StringUtils;

public class ContractByLeveringCodeFilter extends AbstractSqlFilter {

   public ContractByLeveringCodeFilter(final String leveringCode) {
      super("(UPPER(" + ContractColumn.LEV_CD + ") = ?)", StringUtils.isNotBlank(leveringCode) ? leveringCode.toUpperCase() : null);
   }
}
