package nl.uwv.pws.cws.model;

import static nl.uwv.pws.cws.util.Constants.CWSNP_LEV_CODE;

public enum CwsNpFilterType implements BaseCwsFilterType {
    LEVEND_NPE_UITSLUITEN,
    OVERLEDEN_NPE_UITSLUITEN;

    @Override
    public String filterName() {
        return name();
    }

    @Override
    public String levCode() {
        return CWSNP_LEV_CODE;
    }
}
