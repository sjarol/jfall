package nl.uwv.pws.cws.views.beheer.contract;

public enum ContractServiceType {
   CONTRACT_BY_AFNEMER,
   CONTRACT_BY_LEVERING
}
