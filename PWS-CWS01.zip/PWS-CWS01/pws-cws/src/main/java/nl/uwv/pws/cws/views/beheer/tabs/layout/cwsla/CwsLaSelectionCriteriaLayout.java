package nl.uwv.pws.cws.views.beheer.tabs.layout.cwsla;

import com.vaadin.flow.component.checkbox.Checkbox;
import com.vaadin.flow.component.formlayout.FormLayout;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.textfield.TextField;
import lombok.Getter;
import lombok.Setter;

import nl.uwv.pws.cws.exception.FormValidationException;
import nl.uwv.pws.cws.model.CwsLaFilterType;
import nl.uwv.pws.cws.model.SelectionCriteria;
import nl.uwv.pws.cws.util.CwsUIUtils;
import nl.uwv.pws.cws.views.beheer.tabs.layout.BaseSelectionCriteriaFormLayout;
import nl.uwv.pws.cws.views.beheer.SelectionCriteriaFactoryUtil;
import nl.uwv.pws.cws.views.beheer.configuratie.ConfigurationAction;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static nl.uwv.pws.cws.util.Constants.COMPONENT_ID_CODESOORTIKVS_TEXT_FIELD;
import static nl.uwv.pws.cws.util.Constants.COMPONENT_ID_MAXLEVERPERIODE_TEXT_FIELD;
import static nl.uwv.pws.cws.util.Constants.COMPONENT_ID_NIHILLOONSVUITSLUITEN_CHECKBOX;
import static nl.uwv.pws.cws.util.Constants.COMPONENT_ID_NIHILLOONLBPHUITSLUITEN_CHECKBOX;
import static nl.uwv.pws.cws.util.CwsUIUtils.createCheckbox;
import static nl.uwv.pws.cws.util.CwsUIUtils.createHeaderLabel;
import static nl.uwv.pws.cws.util.CwsUIUtils.createTextField;
import static nl.uwv.pws.cws.util.CwsUtils.convertStringToBoolean;
import static org.apache.commons.lang3.StringUtils.isEmpty;
import static org.apache.commons.lang3.StringUtils.isNotEmpty;

@Getter
@Setter
public class CwsLaSelectionCriteriaLayout extends BaseSelectionCriteriaFormLayout {
   private static final Matcher CODE_SOORT_IKV_INPUT_MATCHER = Pattern.compile("\\d{2}(;\\d{2}|-\\d{2})*").matcher("");
   private static final Matcher MAX_LEVERPERIODE_INPUT_MATCHER = Pattern.compile("\\d{1,3}").matcher("");

   private static final boolean DISABLED = false;
   private static final boolean ENABLED = true;
   private static final boolean REQUIRED_FIELD = true;
   private static final boolean OPTIONAL_FIELD = false;

   private TextField textFieldCodeSoortIkv;
   private TextField textFieldMaxLeverperiode;
   private Checkbox checkboxNihilLoonSvUitsluiten;
   private Checkbox checkboxNihilLoonLbPhUitsluiten;

   private String originalCodeSoortIkv;
   private String originalMaxLeverperiode;
   private boolean originalNihilLoonSvUitsluiten;
   private boolean originalNihilLoonLbPhUitsluiten;

   @Override
   public FormLayout createSelectionCriteriaLayout(SelectionCriteria selectionCriteria, final ConfigurationAction configurationAction) {
      FormLayout formLayout = new FormLayout();
      Label label = createHeaderLabel("Selectiecriteria CWS");
      formLayout.add(label);

      boolean enabled = configurationAction.equals(ConfigurationAction.VIEW) ? DISABLED : ENABLED;
      if (selectionCriteria != null) {

         this.originalCodeSoortIkv = selectionCriteria.getFilterMap().get(CwsLaFilterType.CD_SOORT_IKVS);
         this.originalMaxLeverperiode = selectionCriteria.getFilterMap().get(CwsLaFilterType.MAX_LEVERPERIODE);
         this.originalNihilLoonSvUitsluiten = convertStringToBoolean(selectionCriteria.getFilterMap().get(CwsLaFilterType.NIHIL_LNSV_UITSLUITEN));
         this.originalNihilLoonLbPhUitsluiten = convertStringToBoolean(selectionCriteria.getFilterMap().get(CwsLaFilterType.NIHIL_LNLBPH_UITSLUITEN));

         createSelectionCriteriaComponents(enabled);
      } else {
         createSelectionCriteriaComponents(enabled);
      }
      addFormItemsCwsLa(formLayout);
      return formLayout;
   }

   private void createSelectionCriteriaComponents(boolean enabled) {
      textFieldCodeSoortIkv = createTextField(COMPONENT_ID_CODESOORTIKVS_TEXT_FIELD, this.originalCodeSoortIkv, enabled, 200);
      textFieldMaxLeverperiode = createTextField(COMPONENT_ID_MAXLEVERPERIODE_TEXT_FIELD,this.originalMaxLeverperiode, enabled, 3);
      checkboxNihilLoonSvUitsluiten = createCheckbox(COMPONENT_ID_NIHILLOONSVUITSLUITEN_CHECKBOX,this.originalNihilLoonSvUitsluiten, enabled);
      checkboxNihilLoonLbPhUitsluiten = createCheckbox(COMPONENT_ID_NIHILLOONLBPHUITSLUITEN_CHECKBOX, this.originalNihilLoonLbPhUitsluiten, enabled);
   }

  private void addFormItemsCwsLa(FormLayout formLayout) {
     CwsUIUtils.addFormItem(formLayout, textFieldCodeSoortIkv, "Code soort Inkomstenverhouding: \u00A0", OPTIONAL_FIELD);
     CwsUIUtils.addFormItem(formLayout, textFieldMaxLeverperiode, "Maximale Leverperiode:", REQUIRED_FIELD);
     CwsUIUtils.addFormItem(formLayout, checkboxNihilLoonSvUitsluiten, "Nihil Loon SV uitsluiten: \u00A0", OPTIONAL_FIELD);
     CwsUIUtils.addFormItem(formLayout, checkboxNihilLoonLbPhUitsluiten, "Nihil Loon LB/PH uitsluiten: \u00A0", OPTIONAL_FIELD);
  }

   @Override
   public SelectionCriteria determineSelectionCriteria() {
      String codeSoortIkvs = textFieldCodeSoortIkv.getValue();
      String maxLeverperiode = textFieldMaxLeverperiode.getValue();
      boolean nihilLoonSvUitsluiten = checkboxNihilLoonSvUitsluiten.getValue();
      boolean nihilLoonLbPhUitsluiten = checkboxNihilLoonLbPhUitsluiten.getValue();

      return SelectionCriteriaFactoryUtil.createCwsLaSelectieCriteria(codeSoortIkvs, maxLeverperiode, nihilLoonSvUitsluiten, nihilLoonLbPhUitsluiten);
   }

   @Override
   public void validate() throws FormValidationException {
      String codeSoortIkvs = textFieldCodeSoortIkv.getValue();
      String maxLeverperiode = textFieldMaxLeverperiode.getValue();
      if (isNotEmpty(codeSoortIkvs) && !CODE_SOORT_IKV_INPUT_MATCHER.reset(codeSoortIkvs).matches()) {
         throw new FormValidationException("Voer een code soort IKV in het juiste formaat, numeriek 2 posities, eventueel met de juiste scheidingstekens in.");
      }
      if (isEmpty(maxLeverperiode)) {
         throw new FormValidationException("Maximale leverperiode is verplicht.");
      }
      if (!MAX_LEVERPERIODE_INPUT_MATCHER.reset(maxLeverperiode).matches()) {
         throw new FormValidationException("Ingevoerd nummer is niet numeriek");
      }
      if (Integer.parseInt(maxLeverperiode) < 1) {
         throw new FormValidationException("Minimale waarde is 1 en maximale waarde is 999");
      }
   }

   @Override
   public boolean originalValuesHaveNotChanged() {
      String codeSoortIkvs = textFieldCodeSoortIkv.getValue();
      String maxLeverperiode = textFieldMaxLeverperiode.getValue();
      boolean nihilLoonSvUitsluiten = checkboxNihilLoonSvUitsluiten.getValue();
      boolean nihilLoonLbPhUitsluiten = checkboxNihilLoonLbPhUitsluiten.getValue();

      return (isEmpty(originalCodeSoortIkv) ? isEmpty(codeSoortIkvs) : originalCodeSoortIkv.equals(codeSoortIkvs))
            && originalMaxLeverperiode.equals(maxLeverperiode)
            && originalNihilLoonSvUitsluiten == nihilLoonSvUitsluiten
            && originalNihilLoonLbPhUitsluiten == nihilLoonLbPhUitsluiten;
   }
}
