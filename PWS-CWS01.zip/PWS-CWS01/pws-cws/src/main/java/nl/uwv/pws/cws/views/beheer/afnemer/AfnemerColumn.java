package nl.uwv.pws.cws.views.beheer.afnemer;

import nl.uwv.pws.backend.types.Column;

/**
 * List of all columns in the table AFN_AFNEMER that matter to our application.
 */
public enum AfnemerColumn implements Column {
   AFN_CD
}
