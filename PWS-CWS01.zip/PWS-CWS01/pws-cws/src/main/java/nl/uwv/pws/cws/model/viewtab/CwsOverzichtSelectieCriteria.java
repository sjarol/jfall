package nl.uwv.pws.cws.model.viewtab;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static java.util.Collections.emptyList;
import static java.util.Collections.emptyMap;
import static java.util.stream.Collectors.*;

public class CwsOverzichtSelectieCriteria {
    private List<ConfiguratieWithFilters> allApplicableConfigs;

    private List<BaseCwsOverzichtFilterOption> selectedFilters = new ArrayList<>();

    public List<BaseCwsOverzichtFilterOption> getSelectedFilters() {
        return selectedFilters;
    }

    public void setSelectedFilters(List<BaseCwsOverzichtFilterOption> selectedFilters) {
        this.selectedFilters = selectedFilters;
    }

    public void setAllApplicableConfigs(List<ConfiguratieWithFilters> allApplicableConfigs) {
        this.allApplicableConfigs = allApplicableConfigs;
    }

    public List<Long> getAllApplicableConfigIds() {
        return this.allApplicableConfigs == null ? emptyList() : this.allApplicableConfigs.stream()
            .map(ConfiguratieWithFilters::getCconId)
            .distinct()
            .collect(toList());
    }

    public boolean hasSelectedFilter() {
        return !selectedFilters.isEmpty();
    }

    public Map<Long, Map<String, Boolean>> getConfigsWithFilters() {
        return this.allApplicableConfigs == null ? emptyMap() : this.allApplicableConfigs.stream()
            .collect(toMap(ConfiguratieWithFilters::getCconId, ConfiguratieWithFilters::getFilters));
    }

    public String getSelectedSelectieCriteriaNamesForSqlInClause() {
        return "'" + selectedFilters.stream()
            .map(BaseCwsOverzichtFilterOption::getEnumName)
            .collect(joining("','")) + "'";
    }
}
