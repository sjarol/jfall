package nl.uwv.pws.cws.views.beheer.tabs.events;

import com.vaadin.flow.component.ComponentEvent;
import nl.uwv.pws.cws.views.AfnemersSearchBar;

public class SearchAlleAfnemersEvent extends ComponentEvent<AfnemersSearchBar> {

   public SearchAlleAfnemersEvent(AfnemersSearchBar source, boolean fromClient) {
      super(source, fromClient);
   }
}
