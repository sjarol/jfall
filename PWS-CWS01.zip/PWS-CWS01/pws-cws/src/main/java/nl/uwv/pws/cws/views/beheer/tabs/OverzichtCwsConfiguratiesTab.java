package nl.uwv.pws.cws.views.beheer.tabs;

import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.tabs.Tab;
import lombok.Getter;
import nl.uwv.pws.backend.dao.AuthorizationType;
import nl.uwv.pws.cws.views.BeheerConfiguratieView;
import nl.uwv.pws.cws.views.beheer.tabs.layout.OverzichtConfiguratieLayout;
import nl.uwv.pws.ui.components.AuthorizedTab;
import nl.uwv.pws.ui.components.AuthorizedTabs;
import nl.uwv.pws.ui.util.AuthorizedComponent;

import java.util.HashMap;
import java.util.Map;

import static nl.uwv.pws.cws.util.Constants.*;

@Getter
public class OverzichtCwsConfiguratiesTab extends AuthorizedTab implements TabView {

   public static final String TAB_NAME = "Overzicht CWS Configuraties";

   private BeheerConfiguratieView tabParent;

   @AuthorizedComponent(value = "CWS-Loonaangifte", type = AuthorizationType.TAB)
   private AuthorizedTab cwsLaSubTab;

   @AuthorizedComponent(value = "CWS-Natuurlijk Persoon", type = AuthorizationType.TAB)
   private AuthorizedTab cwsNpSubTab;

   @AuthorizedComponent(value = "CWS-Handelsregister", type = AuthorizationType.TAB)
   private AuthorizedTab cwsHrSubTab;

   @AuthorizedComponent(value = "CWS-Werkgever", type = AuthorizationType.TAB)
   private AuthorizedTab cwsWgSubTab;

   @AuthorizedComponent(value = "CWS-Inhoudingsplichtige", type = AuthorizationType.TAB)
   private AuthorizedTab cwsIhpSubTab;

   private AuthorizedTabs authorizedSubTabs;
   private OverzichtConfiguratieLayout cwsLaLayout;
   private OverzichtConfiguratieLayout cwsNpLayout;
   private OverzichtConfiguratieLayout cwsHrLayout;
   private OverzichtConfiguratieLayout cwsWgLayout;
   private OverzichtConfiguratieLayout cwsIhpLayout;
   private VerticalLayout layoutContents;
   private Map<Tab, OverzichtConfiguratieLayout> tabsToLayouts;

   public OverzichtCwsConfiguratiesTab(BeheerConfiguratieView beheerConfiguratieView) {
      super(TAB_NAME);
      this.tabParent = beheerConfiguratieView;
      this.setId(COMPONENT_ID_OVERZICHT_CWS_CONFIGURATIES_TAB_ID);

      cwsLaSubTab = new AuthorizedTab("CWS-Loonaangifte");
      cwsLaSubTab.setId(COMPONENT_ID_OVERZICHT_CWS_CONFIGURATIES_TAB_SUBTAB_CWSLA_ID);
      cwsNpSubTab = new AuthorizedTab("CWS-Natuurlijk Persoon");
      cwsNpSubTab.setId(COMPONENT_ID_OVERZICHT_CWS_CONFIGURATIES_TAB_SUBTAB_CWSNP_ID);
      cwsHrSubTab = new AuthorizedTab("CWS-Handelsregister");
      cwsHrSubTab.setId(COMPONENT_ID_OVERZICHT_CWS_CONFIGURATIES_TAB_SUBTAB_CWSHR_ID);
      cwsWgSubTab = new AuthorizedTab("CWS-Werkgever");
      cwsWgSubTab.setId(COMPONENT_ID_OVERZICHT_CWS_CONFIGURATIES_TAB_SUBTAB_CWSWG_ID);
      cwsIhpSubTab = new AuthorizedTab("CWS-Inhoudingsplichtige");
      cwsIhpSubTab.setId(COMPONENT_ID_OVERZICHT_CWS_CONFIGURATIES_TAB_SUBTAB_CWSIHP_ID);

      cwsLaLayout = new OverzichtConfiguratieLayout(CWSLA_LEV_CODE);
      cwsNpLayout = new OverzichtConfiguratieLayout(CWSNP_LEV_CODE);
      cwsHrLayout = new OverzichtConfiguratieLayout(CWSHR_LEV_CODE);
      cwsWgLayout = new OverzichtConfiguratieLayout(CWSWG_LEV_CODE);
      cwsIhpLayout = new OverzichtConfiguratieLayout(CWSIHP_LEV_CODE);
      authorizedSubTabs = new AuthorizedTabs();
      authorizedSubTabs.setWidthFull();
      authorizedSubTabs.add(cwsLaSubTab, cwsNpSubTab, cwsHrSubTab, cwsWgSubTab, cwsIhpSubTab);
      authorizedSubTabs.setSelectedTab(cwsLaSubTab);
      layoutContents = new VerticalLayout(cwsLaLayout, cwsNpLayout, cwsHrLayout, cwsWgLayout, cwsIhpLayout);
      layoutContents.setHeightFull();

      tabsToLayouts = new HashMap<>();
      tabsToLayouts.put(cwsLaSubTab, cwsLaLayout);
      tabsToLayouts.put(cwsNpSubTab, cwsNpLayout);
      tabsToLayouts.put(cwsHrSubTab, cwsHrLayout);
      tabsToLayouts.put(cwsWgSubTab, cwsWgLayout);
      tabsToLayouts.put(cwsIhpSubTab, cwsIhpLayout);

      showOnlyCwsLaTabAtStart();
   }

   @Override
   public Component getViewHeader() {
      return new HorizontalLayout(authorizedSubTabs);
   }

   @Override
   public Component getViewContent() {
      authorizedSubTabs.addSelectedChangeListener(event -> {
         tabsToLayouts.values().forEach(layout -> layout.setVisible(false));
         Component selectedLayout = tabsToLayouts.get(authorizedSubTabs.getSelectedTab());
         selectedLayout.setVisible(true);
      });

     return layoutContents;
   }

   private void showOnlyCwsLaTabAtStart() {
      tabsToLayouts.values().stream().filter(layout -> !layout.getLeverCode().equalsIgnoreCase(CWSLA_LEV_CODE)).forEach(layout -> layout.setVisible(false));
   }
}
