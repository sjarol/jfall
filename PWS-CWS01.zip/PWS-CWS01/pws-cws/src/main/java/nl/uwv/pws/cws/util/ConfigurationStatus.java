package nl.uwv.pws.cws.util;

public enum ConfigurationStatus {

    DE("Definitief"),
    CO("Concept");

    private final String omschrijving;

   ConfigurationStatus(String omschrijving) {
        this.omschrijving = omschrijving;
    }

    public String getStatusOmschrijving() {
        return this.omschrijving;
    }

}

