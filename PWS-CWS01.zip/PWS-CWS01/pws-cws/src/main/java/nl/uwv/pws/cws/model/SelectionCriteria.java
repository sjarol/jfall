package nl.uwv.pws.cws.model;

import lombok.Getter;
import lombok.Setter;

import java.util.Map;

@Getter
@Setter
public class SelectionCriteria {

   public SelectionCriteria(String levCode) {
      this.levCode = levCode;
   }

   private String levCode;
   private Map<BaseCwsFilterType, String> filterMap;
}
