package nl.uwv.pws.cws.model.viewtab;

import lombok.Getter;
import lombok.Setter;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static java.util.Collections.emptyList;
import static java.util.stream.Collectors.*;

@Getter
@Setter
public class CwsOverzichtMetaAttributes {
    private List<Long> selectedAttributesMetaColIds;
    private List<Map<String, Object>> selectedMetaColDetails;
    private List<Map<String, Object>> allApplicableConfigs;

    public boolean hasSelectedMetaAttributes() {
        return !CollectionUtils.isEmpty(selectedAttributesMetaColIds);
    }

    public List<Long> getAllApplicableConfigIds() {
        return this.allApplicableConfigs == null ? emptyList() : this.allApplicableConfigs.stream()
            .map(conColMap -> (Long) conColMap.get("CCON_ID"))
            .distinct()
            .collect(Collectors.toList());
    }

    public List<String> getSelectedMetaColUniqueNames() {
        return selectedMetaColDetails == null ? emptyList() : selectedMetaColDetails.stream()
            .map(this::createUniqueAttributeIdentifierFromMap)
            .collect(toList());
    }

    public Map<Long, List<String>> getConfigsWithUniqueColumns() {
        return selectedMetaColDetails == null ? java.util.Collections.emptyMap() : this.allApplicableConfigs.stream()
            .collect(groupingBy(map -> (Long) map.get("CCON_ID"),
                mapping(this::createUniqueAttributeIdentifierFromMap, toList())));
    }

    private String createUniqueAttributeIdentifierFromMap(Map<String, Object> map) {
        String techNaam = (String) map.get("TECH_NAAM");
        String bronTabel = (String) map.get("BRON_TABEL");
        return techNaam.concat("-").concat(bronTabel);
    }

   public String getFuncionalColumnNameByUniqueName(String uniqName) {
      return selectedMetaColDetails.stream()
            .filter(map ->{
               String techNaam = (String) map.get("TECH_NAAM");
               String bronTabel = (String) map.get("BRON_TABEL");

               return techNaam.concat("-").concat(bronTabel).equalsIgnoreCase(uniqName);
            }).map(map -> (String) map.get("FUNC_NAAM"))
            .findFirst().orElse(null);
   }
}
