package nl.uwv.pws.cws.model.viewtab;

import java.util.function.Function;

import static org.apache.commons.lang3.StringUtils.isNotEmpty;

public enum CwsNpFilter implements BaseCwsOverzichtFilterOption {
    LEVEND_NPE_UITSLUITEN(
        "Filter levend persoon",
        "Filter levend persoon uitsluiten",
        value -> isNotEmpty(value) && value.equals("J")),
    OVERLEDEN_NPE_UITSLUITEN(
        "Filter overleden persoon",
        "Filter overleden persoon uitsluiten",
        value -> isNotEmpty(value) && value.equals("J"));

    private String columnName;
    private String headerColumnName;
    private Function<String, Boolean> conditionFunction;

    CwsNpFilter(String columnName, String headerColumnName, Function<String, Boolean> conditionFunction) {
        this.columnName = columnName;
        this.headerColumnName = headerColumnName;
        this.conditionFunction = conditionFunction;
    }

    @Override
    public String getColumnName() {
        return this.columnName;
    }

    @Override
    public String getHeaderColumnName() {
        return this.headerColumnName;
    }

    @Override
    public String getEnumName() {
        return this.name();
    }

    @Override
    public boolean testCondition(String value) {
        return this.conditionFunction.apply(value);
    }
}
