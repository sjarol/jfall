package nl.uwv.pws.cws.model;

import lombok.Getter;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

@Getter
public class OverviewGridData {
   private Map<String, Object> values = new LinkedHashMap<>();

   public void set(String key, final Object value) {
      values.put(key, value);
   }

   public Object get(final String key) {
      return values.get(key);
   }
}
