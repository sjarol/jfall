package nl.uwv.pws.cws.backend.service.cwsihp;

import nl.uwv.pws.cws.backend.service.BaseProductSpecContentGeneratorService;
import nl.uwv.pws.cws.model.BaseCwsFilterType;
import nl.uwv.pws.cws.model.CwsConfiguration;
import nl.uwv.pws.cws.model.CwsIhpFilterType;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import static nl.uwv.pws.cws.util.CwsUtils.convertStringToBoolean;

public class CwsIhpProductSpecContentGeneratorService extends BaseProductSpecContentGeneratorService {
   private static final String CWSIHP_PDFTEMPLATE = "../templates/cwsihp-product-specificatie-template.odt";
   private static final String CWSIHP_EXAMPLE_FOLDER = "cwsihp/";
   private static final String CWSIHP_RESPONSE_ROOT_ELEMENT = "CwsInhoudingsplichtigeResponse";
   private static final String SIMPLE_RESPONSE_FILE_NAME = "Response_simpel.xml";
   private static final String COMPLEX_RESPONSE_FILE_NAME = "Response_complex.xml";
   private static final String FILTERED_COMPLEX_RESPONSE_FILE_NAME = "Response_filtered_complex.xml";
   protected static final String REQUEST_MULTI_FILE_NAMES = "Request_administratieveeenheid.xml;Request_persooninhoudingsplichtige.xml;Request_werkgeverkvk.xml";

   public CwsIhpProductSpecContentGeneratorService(final CwsConfiguration cwsConfiguration, final String pdfKenmerk,
                                                   final String requestHeader, final String responseHeader) {
      super(cwsConfiguration, pdfKenmerk, requestHeader, responseHeader);
   }

   @Override
   protected String[] getExampleRequestFileNames() {
      return REQUEST_MULTI_FILE_NAMES.split(";");
   }

   @Override
   protected String getPdfTemplateFileName() {
      return CWSIHP_PDFTEMPLATE;
   }

   @Override
   protected String getExampleXmlFolderName() {
      return CWSIHP_EXAMPLE_FOLDER;
   }

   @Override
   protected String getResponseBodyRootElementName() {
      return CWSIHP_RESPONSE_ROOT_ELEMENT;
   }

   @Override
   public String generateComplexExampleResponseFileName() {
      return generateXmlNameForFile(COMPLEX_RESPONSE_FILE_NAME);
   }

   @Override
   public String generateFilteredComplexExampleResponseContent() throws IOException, SAXException, ParserConfigurationException {
      return generateExampleResponseContent(FILTERED_COMPLEX_RESPONSE_FILE_NAME);
   }

   @Override
   public String generateComplexExampleResponseContent() throws IOException, SAXException, ParserConfigurationException {
      return generateExampleResponseContent(COMPLEX_RESPONSE_FILE_NAME);
   }

   @Override
   public String generateSimpleExampleResponseFileName() {
      return generateXmlNameForFile(SIMPLE_RESPONSE_FILE_NAME);
   }

   @Override
   public String generateSimpleExampleResponseContent() throws IOException, SAXException, ParserConfigurationException {
      return generateExampleResponseContent(SIMPLE_RESPONSE_FILE_NAME);
   }

   @Override
   public Map<String, Object> getSelectieCriteriaMapping() {
      Map<String, Object> mapping = new HashMap<>();

      Map<BaseCwsFilterType, String> filterMap = selectionCriteria.getFilterMap();
      mapping.put("condition_beeindigdAdresUitsluiten", Boolean.toString(convertStringToBoolean(filterMap.get(CwsIhpFilterType.BEEINDIGD_ADRES_UITSLUITEN_IHP))));

      return mapping;
   }
}
