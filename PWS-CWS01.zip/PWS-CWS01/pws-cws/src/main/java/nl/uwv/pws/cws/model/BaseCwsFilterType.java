package nl.uwv.pws.cws.model;

public interface BaseCwsFilterType {
    String filterName();
    String levCode();
}
