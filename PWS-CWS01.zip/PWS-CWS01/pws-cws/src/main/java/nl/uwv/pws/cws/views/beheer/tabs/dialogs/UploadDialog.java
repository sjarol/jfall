package nl.uwv.pws.cws.views.beheer.tabs.dialogs;

import com.helger.commons.annotation.VisibleForTesting;
import com.vaadin.flow.component.HasComponents;
import com.vaadin.flow.component.HtmlComponent;
import com.vaadin.flow.component.Tag;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.NativeButton;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.upload.Upload;
import com.vaadin.flow.component.upload.receivers.MemoryBuffer;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import nl.uwv.pws.backend.dao.BackendException;
import nl.uwv.pws.cws.backend.service.ImportService;
import nl.uwv.pws.cws.model.CwsConfiguration;
import nl.uwv.pws.cws.util.CwsUIUtils;
import nl.uwv.pws.cws.util.CwsUtils;
import nl.uwv.pws.ui.components.StyledDialog;
import nl.uwv.pws.ui.views.ViewFrame;
import org.apache.commons.io.IOUtils;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;

import static nl.uwv.pws.cws.util.Constants.*;
import static nl.uwv.pws.cws.util.CwsUIUtils.createButton;

@Slf4j
@Getter
public class UploadDialog extends StyledDialog {

   private ImportService importService;
   private String leverCode;
   private Long contractId;
   private LocalDate contractStartDate;
   private Button cancelButton;

   public UploadDialog(final String leverCode, final Long contractId, final LocalDate contractStartDate){
      this(null, "Import Configuratie", "30em", "20em", COMPONENT_ID_IMPORT_PRODUCT_SPEC_LAYOUT, leverCode, contractId, contractStartDate);
   }

   private UploadDialog(final ViewFrame parent, final String title, final String width, final String height, final String inheritedComponentId,
                        final String leverCode, final Long contractId, final LocalDate contractStartDate) {
      super(parent, title, width, height, inheritedComponentId);
      this.setDraggable(true);
      this.setModal(true);
      this.setResizable(false);
      this.importService = new ImportService();
      this.leverCode = leverCode;
      this.contractId = contractId;
      this.contractStartDate = contractStartDate;
      this.cancelButton = createButton("Annuleren", VaadinIcon.CLOSE, CANCEL_BUTTON_ID, true, "10em");
      this.cancelButton.addClickListener((event) -> this.close());

      this.setContent(createContent());
      this.addCustomButtonRight(cancelButton);
   }

   @VisibleForTesting
   VerticalLayout createContent() {
      MemoryBuffer buffer = new MemoryBuffer();
      Upload upload = new Upload(buffer);
      NativeButton uploadButton = new NativeButton("Selecteer import bestand");
      upload.setId(UPLOAD_BUTTON_ID);
      upload.setUploadButton(uploadButton);
      upload.setAcceptedFileTypes("application/json");

      Div output = new Div();
      upload.addSucceededListener(event -> {
         Span dropLabel = new Span("Gekozen bestand " + event.getFileName());
         upload.setDropLabel(dropLabel);

         processUpload(buffer.getInputStream());
         showOutput(event.getFileName(), output);
      });

      VerticalLayout content = new VerticalLayout(
            upload,
            output
      );

      return content;
   }

   @VisibleForTesting
   void processUpload(final InputStream stream) {
      try {
         log.info("Start import van configuratie met levercode {} contractId {} contractstartDate {}", leverCode, contractId, CwsUtils.getLocalDateAsString(contractStartDate));
         final byte[] bytes = IOUtils.toByteArray(stream);
         final String configSpecification = new String(bytes, StandardCharsets.UTF_8);

         CwsConfiguration importedConfiguration = importService.importConfiguration(configSpecification, this.contractId, this.contractStartDate);
         log.info("Import met succes afgerond, de nieuwe configuratieId {}", importedConfiguration.getConfigurationId());

         CwsUIUtils.showSuccesNotification("Import succesvol afgerond");
         this.close();
      } catch (IOException | BackendException e) {
         log.error("Import van configuratie is mislukt");
         CwsUIUtils.showErrorNotification("Het bestand kan niet verwerkt worden.");
      } finally {
         IOUtils.closeQuietly(stream);
      }
   }

   private void showOutput(String text, HasComponents outputContainer) {
      HtmlComponent p = new HtmlComponent(Tag.P);
      p.getElement().setText(text);
      outputContainer.add(p);
   }
}
