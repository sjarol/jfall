package nl.uwv.pws.cws.backend.service.cwsla;

import nl.uwv.pws.cws.backend.service.BaseProductSpecContentGeneratorService;
import nl.uwv.pws.cws.model.BaseCwsFilterType;
import nl.uwv.pws.cws.model.CodeSoortIkv;
import nl.uwv.pws.cws.model.CwsConfiguration;
import nl.uwv.pws.cws.model.CwsLaFilterType;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import static nl.uwv.pws.cws.util.CwsUtils.convertStringToBoolean;
import static org.apache.commons.lang3.StringUtils.isEmpty;

public class CwsLaProductSpecContentGeneratorService extends BaseProductSpecContentGeneratorService {
    private static final String CWSLA_PDFTEMPLATE = "../templates/cwsla-product-specificatie-template.odt";
    private static final String CWSLA_EXAMPLE_FOLDER = "cwsla/";
    private static final String CWSLA_RESPONSE_ROOT_ELEMENT = "CwsLoonaangifteresponse";
    private static final String SIMPLE_RESPONSE_FILE_NAME = "Response_simpel.xml";
    private static final String COMPLEX_RESPONSE_FILE_NAME = "Response_complex.xml";

   public CwsLaProductSpecContentGeneratorService(final CwsConfiguration cwsConfiguration, final String kenmerk,
                                                  final String requestHeader, final String responseHeader) {
      super(cwsConfiguration, kenmerk, requestHeader, responseHeader);
   }

    @Override
    protected String[] getExampleRequestFileNames() {
        return new String [] {REQUEST_FILE_NAME};
    }

    @Override
    protected String getPdfTemplateFileName() {
        return CWSLA_PDFTEMPLATE;
    }

    @Override
    protected String getExampleXmlFolderName() {
        return CWSLA_EXAMPLE_FOLDER;
    }

    @Override
    protected String getResponseBodyRootElementName() {
        return CWSLA_RESPONSE_ROOT_ELEMENT;
    }

    @Override
    public String generateComplexExampleResponseFileName() {
        return generateXmlNameForFile(COMPLEX_RESPONSE_FILE_NAME);
    }

    @Override
    public String generateFilteredComplexExampleResponseContent() { return null; }

    @Override
    public String generateComplexExampleResponseContent() throws IOException, SAXException, ParserConfigurationException {
        return generateExampleResponseContent(COMPLEX_RESPONSE_FILE_NAME);
    }

    @Override
    public String generateSimpleExampleResponseFileName() {
        return generateXmlNameForFile(SIMPLE_RESPONSE_FILE_NAME);
    }

    @Override
    public String generateSimpleExampleResponseContent() throws IOException, SAXException, ParserConfigurationException {
        return generateExampleResponseContent(SIMPLE_RESPONSE_FILE_NAME);
    }

    @Override
    public Map<String, Object> getSelectieCriteriaMapping() {
        Map<String, Object> mapping = new HashMap<>();

        Map<BaseCwsFilterType, String> filterMap = selectionCriteria.getFilterMap();
        mapping.put("configuratie_maxLeverperiode", determineMaxLeverperiode(filterMap));

        mapping.put("condition_NihilSv", Boolean.toString(convertStringToBoolean(filterMap.get(CwsLaFilterType.NIHIL_LNSV_UITSLUITEN))));
        mapping.put("condition_NihilLbPh", Boolean.toString(convertStringToBoolean(filterMap.get(CwsLaFilterType.NIHIL_LNLBPH_UITSLUITEN))));

        String cdSoortIkvs = filterMap.get(CwsLaFilterType.CD_SOORT_IKVS);
        if (isEmpty(cdSoortIkvs)) {
            mapping.put("condition_noCdSrtIkv", "true");
            mapping.put("condition_showTableCdSrtIkv", "false");
        } else {
            mapping.put("condition_noCdSrtIkv", "false");
            mapping.put("condition_showTableCdSrtIkv", "true");
        }
        mapping.put("rows", getCdSrtIkvStamgegevens(cdSoortIkvs));

        return mapping;
    }

    private List<CodeSoortIkv> getCdSrtIkvStamgegevens(String codeSoortIkvs) {
        List<CodeSoortIkv> cdSrtIkvs;
        if (isEmpty(codeSoortIkvs)) {
            cdSrtIkvs = new ArrayList<>();
            CodeSoortIkv emptyCdSrtIkv = CodeSoortIkv.builder()
                  .code("").omschrijving("").datumEinde("").build();
            cdSrtIkvs.add(emptyCdSrtIkv);
        } else {
            Set<String> ikvCodesSet = collectSetOfCodeSoortIkv(codeSoortIkvs);
            cdSrtIkvs = cwsConfigurationDao.findCodeSoortIkvStamgegevens(new ArrayList<>(ikvCodesSet));
        }
        return cdSrtIkvs;
    }

    private Set<String> collectSetOfCodeSoortIkv(String givenSoortIkvCodes) {
        return Stream.of(givenSoortIkvCodes.split(";"))
                .flatMap(token -> {
                    if (token.length() == 2) {
                        return Stream.of(token);
                    } else {
                        int firstToken = Integer.parseInt(token.substring(0, 2));
                        int secondToken = Integer.parseInt(token.substring(3));
                        int start = Math.min(firstToken, secondToken);
                        int end = Math.max(firstToken, secondToken);
                        return IntStream.rangeClosed(start, end)
                                .boxed()
                                .map(String::valueOf);
                    }
                }).collect(Collectors.toSet());
    }

    @Override
    protected String replaceSpecificResponseContent(String replacedExampleResponse) {
        String cdSoortIkvs = selectionCriteria.getFilterMap().get(CwsLaFilterType.CD_SOORT_IKVS);
        return replacedExampleResponse
                .replace("${CDSRTIKV}", isEmpty(cdSoortIkvs) ? "11" : cdSoortIkvs.substring(0, 2));
    }

    private String determineMaxLeverperiode(Map<BaseCwsFilterType, String> filterMap) {
        String maxLeverperiode = filterMap.get(CwsLaFilterType.MAX_LEVERPERIODE);
        if (maxLeverperiode == null) {
            maxLeverperiode = "Geen maximale leverperiode van toepassing.";
        } else {
            maxLeverperiode = "Er worden gegevens geleverd van maximaal " + maxLeverperiode + " maand(en) terug vanaf systeemdatum.";
        }
        return maxLeverperiode;
    }
}
