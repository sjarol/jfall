package nl.uwv.pws.cws.backend.service;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import nl.uwv.pws.cws.model.CwsConfiguration;
import nl.uwv.pws.cws.model.CwsMetaCol;
import nl.uwv.pws.cws.model.SelectionCriteria;
import nl.uwv.pws.cws.model.viewtab.ConfiguratieWithFilters;
import nl.uwv.pws.cws.model.viewtab.CwsOverzichtConfiguratie;
import nl.uwv.pws.cws.model.viewtab.CwsOverzichtSelectieCriteria;
import nl.uwv.pws.cws.util.ConfigurationStatus;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static java.util.stream.Collectors.toSet;

@Getter
@Slf4j
public class ConfigurationService extends BaseService {

   public void confirmFinalizeConfiguration(final CwsConfiguration cwsConfiguration) {
      final Long configurationId = cwsConfiguration.getConfigurationId();
      log.debug("confirmFinalizeConfiguration called with configurationId {}", configurationId);
      SelectionCriteria currentSelectionCriteria = cwsConfigurationDao.selectSelectionCriteriaByConfigId(configurationId);
      List<CwsMetaCol> currentCwsMetaColList = cwsConfigurationDao.selectConfigurationMetaData(configurationId);
      Set<Long> currentMetaColIdSet = currentCwsMetaColList.stream().map(CwsMetaCol::getMetaColId).collect(toSet());

      Timestamp deleteTimestamp = cwsConfigurationDao.deleteConfiguration(configurationId);
      LocalDateTime newRegistrationStartDateTime = deleteTimestamp.toLocalDateTime();
      cwsConfiguration.setRegistrationStartDateTime(newRegistrationStartDateTime);
      cwsConfiguration.setConfigurationStatus(ConfigurationStatus.DE.name());

      Long newConfigurationId = cwsConfigurationDao.saveCwsConfiguratie(cwsConfiguration);
      cwsConfigurationDao.saveSelectionCriteria(newConfigurationId, newRegistrationStartDateTime, currentSelectionCriteria);
      cwsConfigurationDao.saveConfigurationAttributes(newConfigurationId, newRegistrationStartDateTime, currentMetaColIdSet);
   }

   public void confirmDeleteConfiguration(final Long configurationId) {
      log.debug("confirmDeleteConfiguration called with configurationId {}", configurationId);
      cwsConfigurationDao.deleteConfiguration(configurationId);
   }

   public String getMaxBerichtVersie(final String leverCode) {
      return cwsConfigurationDao.getMaxBerichtVersie(leverCode);
   }

   public Map<Long, CwsMetaCol> getMetaDataByLeverCodeAndVersie(final String leverCode, final String maxBerichtVersie) {
      return cwsConfigurationDao.getMetaDataByLeverCodeAndVersie(leverCode, maxBerichtVersie);
   }

   public List<ConfiguratieWithFilters> collectAllConfigsWithMatchingFilters(final String leverCode, final CwsOverzichtSelectieCriteria cwsOverzichtSelectieCriteria) {
      return cwsConfigurationOverviewDao.collectAllConfigsWithMatchingFilters(leverCode, cwsOverzichtSelectieCriteria);
   }

   public List<Map<String, Object>> collectAllConfigsWithMatchingNewestMetaColIds(final List<Long> selectedAttributesMetaColIds, final String leverCode) {
      return cwsConfigurationOverviewDao.collectAllConfigsWithMatchingNewestMetaColIds(selectedAttributesMetaColIds, leverCode);
   }

   public List<Map<String, Object>> getMetaColDetail(final List<Long> selectedAttributesMetaColIds) {
      return cwsConfigurationOverviewDao.getMetaColDetail(selectedAttributesMetaColIds);
   }

   public List<CwsOverzichtConfiguratie> getConfiguratiesWithAfnemerDetail(final List<Long> configIdsForOverzicht) {
      return cwsConfigurationOverviewDao.getConfiguratiesWithAfnemerDetail(configIdsForOverzicht);
   }
}
