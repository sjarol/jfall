package nl.uwv.pws.cws.util;

import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.KeyDeserializer;
import nl.uwv.pws.cws.model.*;

import java.io.IOException;
import java.util.stream.Stream;

public class CwsFilterTypeDeserializer extends KeyDeserializer {

    @Override
    public Object deserializeKey(final String key, final DeserializationContext deserializationContext) throws IOException {

        return Stream.of(CwsLaFilterType.values(), CwsNpFilterType.values(), CwsHrFilterType.values(), CwsWgFilterType.values(), CwsIhpFilterType.values())
                .flatMap(Stream::of)
                .filter(filter -> filter.name().equals(key))
                .findAny()
                .orElseThrow(() -> new RuntimeException("Could not deserialize selected filter type: " + key));
    }
}
