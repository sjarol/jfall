package nl.uwv.pws.cws.views.beheer.contract;

import nl.uwv.pws.backend.desc.FieldDescParser;
import nl.uwv.pws.backend.desc.FieldDescriptor;

public final class ContractFieldByLeveringDescriptor extends FieldDescriptor {

   private static final ContractFieldByLeveringDescriptor INSTANCE = new ContractFieldByLeveringDescriptor(
         ContractFieldByLeveringDescriptor.class.getPackage().getName().replace('.', '/') + "/contract_by_levering.desc"
   );

   private ContractFieldByLeveringDescriptor(final String resource) {
      super(new FieldDescParser().parse(resource));
   }

   static ContractFieldByLeveringDescriptor getInstance() {
      return INSTANCE;
   }
}
