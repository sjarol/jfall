package nl.uwv.pws.cws.backend.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public interface CwsRowMapper<T> {
   T mapRow (ResultSet resultSet) throws SQLException;
}
