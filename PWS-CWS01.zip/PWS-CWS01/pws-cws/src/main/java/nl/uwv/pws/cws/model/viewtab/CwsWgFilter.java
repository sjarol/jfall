package nl.uwv.pws.cws.model.viewtab;

import java.util.function.Function;

import static org.apache.commons.lang3.StringUtils.isNotEmpty;

public enum CwsWgFilter implements BaseCwsOverzichtFilterOption {
    BEEINDIGD_ADRES_UITSLUITEN_WG(
        "Filter beëindigd adres",
        "Filter beëindigd adres uitsluiten",
        value -> isNotEmpty(value) && value.equals("J"));

    private String columnName;
    private String headerColumnName;
    private Function<String, Boolean> conditionFunction;

    CwsWgFilter(String columnName, String headerColumnName, Function<String, Boolean> conditionFunction) {
        this.columnName = columnName;
        this.headerColumnName = headerColumnName;
        this.conditionFunction = conditionFunction;
    }

    @Override
    public String getColumnName() {
        return this.columnName;
    }

    @Override
    public String getHeaderColumnName() {
        return this.headerColumnName;
    }

    @Override
    public String getEnumName() {
        return this.name();
    }

    @Override
    public boolean testCondition(String value) {
        return this.conditionFunction.apply(value);
    }
}
