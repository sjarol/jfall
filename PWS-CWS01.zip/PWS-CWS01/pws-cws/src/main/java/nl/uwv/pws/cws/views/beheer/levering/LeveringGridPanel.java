package nl.uwv.pws.cws.views.beheer.levering;

import com.vaadin.flow.component.AbstractField.ComponentValueChangeEvent;
import com.vaadin.flow.component.HasValue.ValueChangeListener;
import com.vaadin.flow.component.grid.Grid;
import lombok.Getter;
import nl.uwv.pws.backend.filter.AbstractSqlFilter;
import nl.uwv.pws.backend.types.ColumnList;
import nl.uwv.pws.cws.util.Constants;
import nl.uwv.pws.cws.views.beheer.common.AbstractBeheerConfiguratieGridPanel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static nl.uwv.pws.cws.util.Constants.ALLE_CWS_LEVERINGEN_CAPTION;

@Getter
public class LeveringGridPanel extends AbstractBeheerConfiguratieGridPanel<AbstractSqlFilter> {
   private static final Logger LOG = LoggerFactory.getLogger(LeveringGridPanel.class);
   public static final String COMPONENT_ID = "leveringen-panel";

   public LeveringGridPanel(final ValueChangeListener<ComponentValueChangeEvent<Grid<ColumnList>, ColumnList>> valueChangeListener) {
      super(COMPONENT_ID, ALLE_CWS_LEVERINGEN_CAPTION, new LeveringService(Constants.DS_NAME), valueChangeListener, null);
   }

   public void findAlleLeveringen() {
      LOG.debug("Finding alle leveringen");
      search(new LeveringFilter());
   }
}
