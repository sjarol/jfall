package nl.uwv.pws.cws.util;

import nl.uwv.pws.backend.types.ColumnList;
import nl.uwv.pws.cws.model.ConfigurationDetails;
import nl.uwv.pws.cws.model.ContractDetails;
import nl.uwv.pws.cws.views.beheer.configuratie.ConfiguratieColumn;
import nl.uwv.pws.cws.views.beheer.contract.ContractColumn;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

public final class Mapper {

   private Mapper() {
      throw new IllegalStateException("Utility class");
   }

   public static ContractDetails mapToContractDetail(final ColumnList columnList) {
      final BigDecimal contractId = CwsUtils.getBigDecimal(columnList.getValue(ContractColumn.CONTRACT_ID.name()));
      final LocalDate startDate = CwsUtils.getDateAsLocalDate(columnList.getValue(ContractColumn.HIS_DAT_IN.name()));
      final LocalDate endDate = CwsUtils.getDateAsLocalDate(columnList.getValue(ContractColumn.HIS_DAT_END.name()));
      final String afnemerCode = (String) columnList.getValue(ContractColumn.AFN_CD.name());
      final String afnemerNaam = (String) columnList.getValue(ContractColumn.AFN_NAAM.name());
      final String leverCode = (String) columnList.getValue(ContractColumn.LEV_CD.name());

      return ContractDetails.builder()
            .contractId(contractId)
            .contractStartDate(startDate)
            .contractEndDate(endDate)
            .afnemerCode(afnemerCode)
            .afnemerNaam(afnemerNaam)
            .leverCode(leverCode)
         .build();
   }

   public static ConfigurationDetails mapToConfigurationDetail(final ColumnList columnList) {
      final BigDecimal cwsConfigurationId = CwsUtils.getBigDecimal(columnList.getValue(ConfiguratieColumn.CCON_ID.name()));
      final BigDecimal version = CwsUtils.getBigDecimal(columnList.getValue(ConfiguratieColumn.VERSION.name()));
      final String status = (String) columnList.getValue(ConfiguratieColumn.STATUS.name());
      final String berichtVersie = (String) columnList.getValue(ConfiguratieColumn.BERICHTVERSIE.name());
      final String configurationName = (String) columnList.getValue(ConfiguratieColumn.NAAM.name());
      final LocalDate configurationStartDate = CwsUtils.getDateAsLocalDate(columnList.getValue(ConfiguratieColumn.HIS_DAT_IN.name()));
      final LocalDate configurationEndDate = CwsUtils.getDateAsLocalDate(columnList.getValue(ConfiguratieColumn.HIS_DAT_END.name()));

      return ConfigurationDetails.builder()
            .configurationId(cwsConfigurationId)
            .configurationVersion(version)
            .configurationStatus(status)
            .berichtVersie(berichtVersie)
            .configurationName(configurationName)
            .configurationStartDate(configurationStartDate)
            .configurationEndDate(configurationEndDate)
            .build();
   }

}
