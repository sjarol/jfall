package nl.uwv.pws.cws.views.beheer.tabs.layout.cwshr;

import nl.uwv.pws.cws.model.viewtab.BaseCwsOverzichtFilterOption;
import nl.uwv.pws.cws.model.viewtab.CwsHrFilter;
import nl.uwv.pws.cws.views.beheer.tabs.layout.BaseOverzichtFilterLayout;

public class CwsHrOverzichtFilterFormLayout extends BaseOverzichtFilterLayout {

   public CwsHrOverzichtFilterFormLayout() {
     super(initiateCheckboxWithId("Filter beëindigd adres uitsluiten", CwsHrFilter.BEEINDIGD_ADRES_UITSLUITEN));
    }

    @Override
    protected BaseCwsOverzichtFilterOption filterOptionValueOf(String id) {
        return CwsHrFilter.valueOf(id);
    }
}
