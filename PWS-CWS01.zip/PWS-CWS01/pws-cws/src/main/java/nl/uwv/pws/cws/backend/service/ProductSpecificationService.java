package nl.uwv.pws.cws.backend.service;

import com.helger.commons.annotation.VisibleForTesting;
import lombok.Getter;
import nl.uwv.pws.backend.dao.BackendException;
import nl.uwv.pws.cws.backend.service.cwsihp.CwsIhpProductSpecContentGeneratorService;
import nl.uwv.pws.cws.backend.service.cwswg.CwsWgProductSpecContentGeneratorService;
import nl.uwv.pws.cws.model.CwsConfiguration;
import nl.uwv.pws.cws.backend.service.cwshr.CwsHrProductSpecContentGeneratorService;
import nl.uwv.pws.cws.backend.service.cwsla.CwsLaProductSpecContentGeneratorService;
import nl.uwv.pws.cws.backend.service.cwsnp.CwsNpProductSpecContentGeneratorService;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import static nl.uwv.pws.cws.util.Constants.*;


@Getter
public class ProductSpecificationService extends BaseService {

   public ByteArrayOutputStream generateZipFile(final CwsConfiguration cwsConfiguration, final String pdfFileName, final String pdfKenmerk)
         throws IOException, ParserConfigurationException, SAXException {

      if (cwsConfiguration == null) {
         throw new IllegalArgumentException("cws Configuration is not set");
      }

      final BaseProductSpecContentGeneratorService contentGenerator = determineProductSpecContent(cwsConfiguration, pdfKenmerk);
      String leverCode = cwsConfiguration.getLeverCode();

      try (ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream()) {
         try (ZipOutputStream zipOutputStream = new ZipOutputStream(byteArrayOutputStream)) {
            byte[] pdfBytes = contentGenerator.generatePdfByteArray();
            addZipEntryContent(zipOutputStream, new ByteArrayInputStream(pdfBytes), pdfFileName);

            Arrays.stream(contentGenerator.getExampleRequestFileNames()).forEach(fileName -> {
               String generatedRequestFileName = contentGenerator.generateExampleRequestFromFileName(fileName);
               try {
                  String generatedRequestXmlContent = contentGenerator.generateRequestContent(fileName);
                  addZipEntryContent(zipOutputStream, new ByteArrayInputStream(generatedRequestXmlContent.getBytes()), generatedRequestFileName);
               } catch (IOException e) {
                  throw new BackendException("Failed to add request file to zip", e);
               }
            });

            String complexResponseFileName = contentGenerator.generateComplexExampleResponseFileName();
            if (StringUtils.isNotEmpty(complexResponseFileName)) {
               String generatedComplexResponseXmlContent;
               if (CWSHR_LEV_CODE.equalsIgnoreCase(leverCode) || CWSWG_LEV_CODE.equalsIgnoreCase(leverCode) || CWSIHP_LEV_CODE.equalsIgnoreCase(leverCode)) {
                  generatedComplexResponseXmlContent = (contentGenerator.getSelectieCriteriaMapping().get("condition_beeindigdAdresUitsluiten").equals("true")) ? contentGenerator.generateFilteredComplexExampleResponseContent() : contentGenerator.generateComplexExampleResponseContent();
               } else {
                  generatedComplexResponseXmlContent = contentGenerator.generateComplexExampleResponseContent();
               }
               addZipEntryContent(zipOutputStream, new ByteArrayInputStream(generatedComplexResponseXmlContent.getBytes()), complexResponseFileName);
            }

            String simpleResponseFileName = contentGenerator.generateSimpleExampleResponseFileName();
            if (StringUtils.isNotEmpty(simpleResponseFileName)) {
               String generatedSimpleResponseXmlContent = contentGenerator.generateSimpleExampleResponseContent();
               addZipEntryContent(zipOutputStream, new ByteArrayInputStream(generatedSimpleResponseXmlContent.getBytes()), simpleResponseFileName);
            }

            String funcFoutResponseFileName = contentGenerator.generateFunctioneleFoutResponseFileName();
            String generatedFuncFoutResponseXmlContent = contentGenerator.generateFunctioneleFoutResponseContent();
            addZipEntryContent(zipOutputStream, new ByteArrayInputStream(generatedFuncFoutResponseXmlContent.getBytes()), funcFoutResponseFileName);

            String techFoutResponseFileName = contentGenerator.generateTechnischeFoutResponseFileName();
            InputStream techFoutResponseXmlContent = contentGenerator.generateTechnischeFoutResponseContent();
            addZipEntryContent(zipOutputStream, techFoutResponseXmlContent, techFoutResponseFileName);
         }

         return byteArrayOutputStream;
      }
   }

   @VisibleForTesting
   BaseProductSpecContentGeneratorService determineProductSpecContent(final CwsConfiguration cwsConfiguration, final String pdfKenmerk) {
      final String leverCode = cwsConfiguration.getLeverCode();
      final Long contractId = cwsConfiguration.getContractId();
      final LocalDate contractStartDate = cwsConfiguration.getContractStartDate();

      validateLevercode(leverCode);
      boolean isAfnemerExtern = cwsConfigurationDao.isAfnemerExtern(contractId, contractStartDate);

      if (CWSLA_LEV_CODE.equalsIgnoreCase(leverCode)) {
         String requestHeader = isAfnemerExtern ? CWS_LA_REQUEST_HEADER_EXTERN : CWS_LA_REQUEST_HEADER_INTERN;
         String responseHeader = isAfnemerExtern ? CWS_LA_RESPONSE_HEADER_EXTERN : CWS_LA_RESPONSE_HEADER_INTERN;

         return new CwsLaProductSpecContentGeneratorService(cwsConfiguration, pdfKenmerk,
               requestHeader, responseHeader);
      } else if (CWSNP_LEV_CODE.equalsIgnoreCase(leverCode)) {
         String requestHeader = isAfnemerExtern ? CWS_NP_REQUEST_HEADER_EXTERN : CWS_NP_REQUEST_HEADER_INTERN;
         String responseHeader = isAfnemerExtern ? CWS_NP_RESPONSE_HEADER_EXTERN : CWS_NP_RESPONSE_HEADER_INTERN;

         return new CwsNpProductSpecContentGeneratorService(cwsConfiguration, pdfKenmerk,
               requestHeader, responseHeader);
      } else if (CWSHR_LEV_CODE.equalsIgnoreCase(leverCode)){
         String requestHeader = isAfnemerExtern ? CWS_HR_REQUEST_HEADER_EXTERN : CWS_HR_REQUEST_HEADER_INTERN;
         String responseHeader = isAfnemerExtern ? CWS_HR_RESPONSE_HEADER_EXTERN : CWS_HR_RESPONSE_HEADER_INTERN;

         return new CwsHrProductSpecContentGeneratorService(cwsConfiguration, pdfKenmerk,
               requestHeader, responseHeader);
      } else if (CWSWG_LEV_CODE.equalsIgnoreCase(leverCode)) {
         String requestHeader = isAfnemerExtern ? CWS_WG_REQUEST_HEADER_EXTERN : CWS_WG_REQUEST_HEADER_INTERN;
         String responseHeader = isAfnemerExtern ? CWS_WG_RESPONSE_HEADER_EXTERN : CWS_WG_RESPONSE_HEADER_INTERN;

         return new CwsWgProductSpecContentGeneratorService(cwsConfiguration, pdfKenmerk,
               requestHeader, responseHeader);
      } else if (CWSIHP_LEV_CODE.equalsIgnoreCase(leverCode)) {
         String requestHeader = isAfnemerExtern ? CWS_IHP_REQUEST_HEADER_EXTERN : CWS_IHP_REQUEST_HEADER_INTERN;
         String responseHeader = isAfnemerExtern ? CWS_IHP_RESPONSE_HEADER_EXTERN : CWS_IHP_RESPONSE_HEADER_INTERN;

         return new CwsIhpProductSpecContentGeneratorService(cwsConfiguration, pdfKenmerk,
               requestHeader, responseHeader);
      }  else{
         throw new IllegalStateException("Ongeldige lever code");
      }
   }

   private void addZipEntryContent(ZipOutputStream zipOut, InputStream inputStream, String zipEntryName) throws IOException {
      ZipEntry zipEntry = new ZipEntry(zipEntryName);
      zipOut.putNextEntry(zipEntry);
      IOUtils.copy(inputStream, zipOut);
   }

   private void validateLevercode(String levercode){
      if(StringUtils.isEmpty(levercode) || Stream.of(CWSLA_LEV_CODE, CWSNP_LEV_CODE, CWSHR_LEV_CODE, CWSWG_LEV_CODE, CWSIHP_LEV_CODE).noneMatch(s -> s.equalsIgnoreCase(levercode))){
         throw new BackendException("Unknown SelectieCriteria Lev Code");
      }
   }
}
