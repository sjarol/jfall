package nl.uwv.pws.cws.backend.mapper;

import nl.uwv.pws.backend.dao.BackendException;
import nl.uwv.pws.cws.model.CwsHrFilterType;
import nl.uwv.pws.cws.model.CwsIhpFilterType;
import nl.uwv.pws.cws.model.CwsLaFilterType;
import nl.uwv.pws.cws.model.CwsNpFilterType;
import nl.uwv.pws.cws.model.CwsWgFilterType;
import nl.uwv.pws.cws.model.SelectionCriteria;
import nl.uwv.pws.cws.views.beheer.SelectionCriteriaFactoryUtil;

import java.sql.ResultSet;
import java.sql.SQLException;

import static nl.uwv.pws.cws.util.Constants.*;
import static nl.uwv.pws.cws.util.CwsUtils.convertStringToBoolean;

public class SelectionCriteriaRowMapper implements CwsRowMapper<SelectionCriteria> {

   public SelectionCriteria mapRow(final ResultSet resultSet) throws SQLException {
      if (resultSet.next()) {
         String levCode = resultSet.getString("LEV_CD");
         SelectionCriteria cwsSelectieCriteria = new SelectionCriteria(levCode);

         if (levCode.equals(CWSLA_LEV_CODE)) {
            cwsSelectieCriteria = mapCwsLaSelectieCriteria(resultSet);
         } else if (levCode.equals(CWSNP_LEV_CODE)) {
            cwsSelectieCriteria = mapCwsNpSelectieCriteria(resultSet);
         } else if (levCode.equals(CWSHR_LEV_CODE)) {
            cwsSelectieCriteria = mapCwsHrSelectieCriteria(resultSet);
         } else if (levCode.equals(CWSWG_LEV_CODE)) {
            cwsSelectieCriteria = mapCwsWgSelectieCriteria(resultSet);
         } else if (levCode.equals(CWSIHP_LEV_CODE)) {
            cwsSelectieCriteria = mapCwsIhpSelectieCriteria(resultSet);
         }
         return cwsSelectieCriteria;
      } else {
         throw new BackendException("De Selectie Criteria van configuratie ontbreekt. Dit mag niet gebeuren.");
      }
   }

   private SelectionCriteria mapCwsLaSelectieCriteria(ResultSet resultSet) throws SQLException {
      SelectionCriteria selectionCriteria;
      String cdSoortIkv = "";
      String maxLeverperiode = "";
      boolean nihilLoonSvUitsluiten = false;
      boolean nihilLoonLbPhUitsluiten = false;
      do { // NOTE: Use do while because the if result.next was executed before.
         String techNaam = resultSet.getString("TECH_NAAM");
         String value = resultSet.getString("VALUE");
         if (CwsLaFilterType.CD_SOORT_IKVS.name().equals(techNaam)) {
            cdSoortIkv = value;
         } else if (CwsLaFilterType.MAX_LEVERPERIODE.name().equals(techNaam)) {
            maxLeverperiode = value;
         } else if (CwsLaFilterType.NIHIL_LNSV_UITSLUITEN.name().equals(techNaam)) {
            nihilLoonSvUitsluiten = convertStringToBoolean(value);
         } else if (CwsLaFilterType.NIHIL_LNLBPH_UITSLUITEN.name().equals(techNaam)) {
            nihilLoonLbPhUitsluiten = convertStringToBoolean(value);
         }
      } while (resultSet.next());
      selectionCriteria = SelectionCriteriaFactoryUtil.createCwsLaSelectieCriteria(cdSoortIkv, maxLeverperiode, nihilLoonSvUitsluiten, nihilLoonLbPhUitsluiten);
      return selectionCriteria;
   }

   private SelectionCriteria mapCwsNpSelectieCriteria(ResultSet resultSet) throws SQLException {
      SelectionCriteria selectionCriteria;
      boolean levendPersoonUitsluiten = false;
      boolean overledenPersoonUitsluiten = false;
      do { // NOTE: Use do while because the if result.next was executed before.
         String techNaam = resultSet.getString("TECH_NAAM");
         String value = resultSet.getString("VALUE");
         if (CwsNpFilterType.LEVEND_NPE_UITSLUITEN.name().equals(techNaam)) {
            levendPersoonUitsluiten = convertStringToBoolean(value);
         } else if (CwsNpFilterType.OVERLEDEN_NPE_UITSLUITEN.name().equals(techNaam)) {
            overledenPersoonUitsluiten = convertStringToBoolean(value);
         }
      } while (resultSet.next());
      selectionCriteria = SelectionCriteriaFactoryUtil.createCwsNpSelectieCriteria(levendPersoonUitsluiten, overledenPersoonUitsluiten);
      return selectionCriteria;
   }

   private SelectionCriteria mapCwsHrSelectieCriteria(ResultSet resultSet) throws SQLException {
      SelectionCriteria selectionCriteria;
      boolean beeindigdAdresUitsluiten = false;
      do { // NOTE: Use do while because the if result.next was executed before.
         String techNaam = resultSet.getString("TECH_NAAM");
         String value = resultSet.getString("VALUE");
         if (CwsHrFilterType.BEEINDIGD_ADRES_UITSLUITEN.name().equals(techNaam)) {
            beeindigdAdresUitsluiten = convertStringToBoolean(value);
         }
      } while (resultSet.next());
      selectionCriteria = SelectionCriteriaFactoryUtil.createCwsHrSelectieCriteria(beeindigdAdresUitsluiten);
      return selectionCriteria;
   }

   private SelectionCriteria mapCwsWgSelectieCriteria(ResultSet resultSet) throws SQLException {
      SelectionCriteria selectionCriteria;
      boolean beeindigdAdresUitsluiten = false;
      do { // NOTE: Use do while because the if result.next was executed before.
         String techNaam = resultSet.getString("TECH_NAAM");
         String value = resultSet.getString("VALUE");
         if (CwsWgFilterType.BEEINDIGD_ADRES_UITSLUITEN_WG.name().equals(techNaam)) {
            beeindigdAdresUitsluiten = convertStringToBoolean(value);
         }
      } while (resultSet.next());
      selectionCriteria = SelectionCriteriaFactoryUtil.createCwsWgSelectieCriteria(beeindigdAdresUitsluiten);
      return selectionCriteria;
   }

   private SelectionCriteria mapCwsIhpSelectieCriteria(ResultSet resultSet) throws SQLException {
      SelectionCriteria selectionCriteria;
      boolean beeindigdAdresUitsluiten = false;
      do { // NOTE: Use do while because the if result.next was executed before.
         String techNaam = resultSet.getString("TECH_NAAM");
         String value = resultSet.getString("VALUE");
         if (CwsIhpFilterType.BEEINDIGD_ADRES_UITSLUITEN_IHP.name().equals(techNaam)) {
            beeindigdAdresUitsluiten = convertStringToBoolean(value);
         }
      } while (resultSet.next());
      selectionCriteria = SelectionCriteriaFactoryUtil.createCwsIhpSelectieCriteria(beeindigdAdresUitsluiten);
      return selectionCriteria;
   }
}
