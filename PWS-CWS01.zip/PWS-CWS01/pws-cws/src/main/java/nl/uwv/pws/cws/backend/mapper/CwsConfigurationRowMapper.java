package nl.uwv.pws.cws.backend.mapper;

import nl.uwv.pws.cws.model.CwsConfiguration;
import nl.uwv.pws.cws.util.CwsUtils;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDate;

public class CwsConfigurationRowMapper implements CwsRowMapper<CwsConfiguration> {

   public CwsConfiguration mapRow(final ResultSet resultSet) throws SQLException {
      final Long configurationId = resultSet.getLong("CCON_ID");
      final Long contractId = resultSet.getLong("CONTRACT_ID");
      final LocalDate contractStartDate = CwsUtils.getLongAsLocalDate(resultSet.getLong("CONT_HIS_DAT_IN"));
      final String name = resultSet.getString("NAAM");
      final Long version = resultSet.getLong("VERSION");
      final String status = resultSet.getString("STATUS");
      final LocalDate configurationStartDate = CwsUtils.getLongAsLocalDate(resultSet.getLong("HIS_DAT_IN"));
      final LocalDate configurationEndDate = CwsUtils.getLongAsLocalDate(resultSet.getLong("HIS_DAT_END"));
      final Timestamp registrationStartDateTime = resultSet.getTimestamp("HIS_TS_IN");
      final Timestamp registrationEndDateTime = resultSet.getTimestamp("HIS_TS_END");
      final String leverCode = resultSet.getString("LEV_CD");
      final String berichtVersie = resultSet.getString("BERICHTVERSIE");

      return CwsConfiguration.builder()
            .configurationId(configurationId)
            .contractId(contractId)
            .contractStartDate(contractStartDate)
            .configurationName(name)
            .configurationVersion(version)
            .configurationStatus(status)
            .configurationStartDate(configurationStartDate)
            .configurationEndDate(configurationEndDate)
            .registrationStartDateTime(registrationStartDateTime != null ? registrationStartDateTime.toLocalDateTime() : null)
            .registrationEndDateTime(registrationEndDateTime != null ? registrationEndDateTime.toLocalDateTime() : null)
            .leverCode(leverCode)
            .berichtVersie(berichtVersie)
            .build();
   }
}
