package nl.uwv.pws.cws.views.beheer.tabs.layout;

import com.helger.commons.annotation.VisibleForTesting;
import com.vaadin.flow.component.AbstractField.ComponentValueChangeEvent;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.Unit;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.checkbox.Checkbox;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.html.Anchor;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.treegrid.TreeGrid;
import com.vaadin.flow.data.provider.ListDataProvider;
import com.vaadin.flow.data.provider.hierarchy.HierarchicalDataProvider;
import com.vaadin.flow.function.SerializablePredicate;
import com.vaadin.flow.server.StreamResource;
import lombok.Getter;
import lombok.Setter;
import nl.uwv.pws.backend.dao.BackendException;
import nl.uwv.pws.cws.backend.service.ConfigurationService;
import nl.uwv.pws.cws.backend.service.ExportService;
import nl.uwv.pws.cws.model.CwsMetaCol;
import nl.uwv.pws.cws.model.OverviewGridData;
import nl.uwv.pws.cws.model.viewtab.*;
import nl.uwv.pws.cws.util.CwsUIUtils;
import nl.uwv.pws.cws.util.CwsUtils;
import nl.uwv.pws.cws.views.beheer.tabs.layout.cwshr.CwsHrOverzichtFilterFormLayout;
import nl.uwv.pws.cws.views.beheer.tabs.layout.cwsihp.CwsIhpOverzichtFilterFormLayout;
import nl.uwv.pws.cws.views.beheer.tabs.layout.cwsla.CwsLaOverzichtFilterFormLayout;
import nl.uwv.pws.cws.views.beheer.tabs.layout.cwsnp.CwsNpOverzichtFilterFormLayout;
import nl.uwv.pws.cws.views.beheer.tabs.layout.cwswg.CwsWgOverzichtFilterFormLayout;
import nl.uwv.pws.ui.components.LabelGrid;
import nl.uwv.pws.ui.layout.FullVerticalLayout;
import nl.uwv.pws.ui.util.UIUtils;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Collectors;

import static nl.uwv.pws.cws.util.Constants.*;
import static nl.uwv.pws.cws.util.CwsUIUtils.findComponent;

@Getter
@Setter
public class OverzichtConfiguratieLayout extends FullVerticalLayout {

   private static final String EXPORT_OVERZICHT_LABEL = "Export Overzicht";
   private static final int CONFIGURATIES_TABLE_PAGE_LENGTH = 18;
   private static final int CWS_CONFIGURATIES_AFN_CD = 0;
   private static final int CWS_CONFIGURATIES_LEV_CD = 1;
   private static final int CWS_CONFIGURATIES_CONTRACT_ID = 2;
   private static final int CWS_CONFIGURATIES_CONT_HIS_DAT_IN = 3;
   private static final int CWS_CONFIGURATIES_VERSION = 4;
   private static final int CWS_CONFIGURATIES_NAAM = 5;
   private static final int CWS_CONFIGURATIES_HIS_DAT_IN = 6;
   private static final int CWS_CONFIGURATIES_HIS_DAT_END = 7;
   private static final int CWS_CONFIGURATIES_STATUS = 8;
   private static final int CWS_CONFIGURATIES_BERICHTVERSIE = 9;

   private final String leverCode;
   private final BaseOverzichtFilterLayout filterCheckboxes;
   private Map<Long, CwsMetaCol> metaColMap;
   private Button tonenConfiguratiesButton;
   private Button exportConfiguratiesButton;
   private Anchor exportConfiguratiesLink;
   private final ConfigurationService configurationService;

   public OverzichtConfiguratieLayout(final String leverCode) {
      this.leverCode = leverCode;
      this.configurationService = new ConfigurationService();
      setHeightFull();

      Label headerLabel = new Label("Selecteer gegevenselementen");
      setId(COMPONENT_ID_OVERZICHT_CWS_CONFIGURATIE_LAYOUT + "-" + leverCode.toLowerCase());

      TreeGrid<CwsMetaCol> configurationItemsTree = setupConfigurationSelection();
      configurationItemsTree.setMinHeight(700, Unit.PIXELS);
      createButtonTonen();
      createButtonExport();

      this.filterCheckboxes = determineOverzichtFilterLayout(this.leverCode);
      HorizontalLayout buttonGroups = new HorizontalLayout();
      buttonGroups.setSpacing(true);
      buttonGroups.add(this.tonenConfiguratiesButton, this.exportConfiguratiesLink);
      add(headerLabel, this.filterCheckboxes, configurationItemsTree, buttonGroups);
      setSizeFull();
   }

   private BaseOverzichtFilterLayout determineOverzichtFilterLayout(String levCode) {
      if (CWSLA_LEV_CODE.equals(levCode)) {
         return new CwsLaOverzichtFilterFormLayout();
      } else if (CWSNP_LEV_CODE.equals(levCode)) {
         return new CwsNpOverzichtFilterFormLayout();
      } else if (CWSHR_LEV_CODE.equals(levCode)) {
         return new CwsHrOverzichtFilterFormLayout();
      } else if (CWSWG_LEV_CODE.equals(levCode)) {
         return new CwsWgOverzichtFilterFormLayout();
      } else if (CWSIHP_LEV_CODE.equals(levCode)) {
         return new CwsIhpOverzichtFilterFormLayout();
      } else {
         throw new BackendException("Unknown SelectieCriteria Lev Code");
      }
   }

   private TreeGrid<CwsMetaCol> setupConfigurationSelection() {
      final String maxBerichtVersie = this.configurationService.getMaxBerichtVersie(this.leverCode);
      this.metaColMap = this.configurationService.getMetaDataByLeverCodeAndVersie(this.leverCode, maxBerichtVersie);

      this.metaColMap.values().forEach(CwsMetaCol::disableAllRequiredAndTheParentsIgnoreChecked);
      return CwsUIUtils.createTreeGrid(new ArrayList<>(metaColMap.values()), this::checkboxSelected);
   }

   private void checkboxSelected(final ComponentValueChangeEvent<Checkbox, Boolean> valueChangeEvent,
                                final CwsMetaCol cwsMetaCol, final HierarchicalDataProvider<CwsMetaCol, SerializablePredicate<CwsMetaCol>> dataProvider) {
      boolean checked = Boolean.TRUE.equals(valueChangeEvent.getValue());
      cwsMetaCol.updateDescendants(checked).forEach(dataProvider::refreshItem);
      cwsMetaCol.setChecked(checked);
      dataProvider.refreshItem(cwsMetaCol);

      cwsMetaCol.updateAscendants(checked).forEach(dataProvider::refreshItem);
   }

   private void createButtonTonen() {
      this.tonenConfiguratiesButton = CwsUIUtils.createButton("Toon Configuraties", VaadinIcon.SEARCH, this.leverCode + COMPONENT_ID_TOONCONFIGURATIE_BUTTON , true, "20em");
      tonenConfiguratiesButton.addClickListener(buttonClickEvent -> findAndDisplayApplicableConfiguraties());
   }

   private void createButtonExport() {
      this.exportConfiguratiesLink = new Anchor();
      this.exportConfiguratiesLink.getElement().setAttribute("download", true);
      this.exportConfiguratiesButton = CwsUIUtils.createButton("Excel", VaadinIcon.ARROW_FORWARD, COMPONENT_ID_EXPORTCONFIGURATIE_BUTTON , true, "10em");
      this.exportConfiguratiesLink.setVisible(false);
      this.exportConfiguratiesLink.add(exportConfiguratiesButton);
      this.exportConfiguratiesLink.setVisible(false);
   }

   @VisibleForTesting
   void findAndDisplayApplicableConfiguraties() {
      tonenConfiguratiesButton.setEnabled(false);

      CwsOverzichtSelectieCriteria cwsOverzichtSelectieCriteria = new CwsOverzichtSelectieCriteria();
      cwsOverzichtSelectieCriteria.setSelectedFilters(this.filterCheckboxes.getSelectedFilters());

      CwsOverzichtMetaAttributes cwsOverzichtMetaAttributes = new CwsOverzichtMetaAttributes();
      cwsOverzichtMetaAttributes.setSelectedAttributesMetaColIds(getCurrentSelectedMetaColIdsExcludeMandatory());

      if (!cwsOverzichtSelectieCriteria.hasSelectedFilter() && !cwsOverzichtMetaAttributes.hasSelectedMetaAttributes()) {
         removeCwsConfiguratiesSearchResultGrid();
         CwsUIUtils.showErrorNotification("Er is geen gegevenselement(en) gekozen");
      } else {
         findApplicableConfigurations(cwsOverzichtSelectieCriteria, cwsOverzichtMetaAttributes);
      }
      tonenConfiguratiesButton.setEnabled(true);
   }

   @VisibleForTesting
   List<Long> getCurrentSelectedMetaColIdsExcludeMandatory() {
      return this.metaColMap.values().stream()
            .filter(cwsMetaCol -> cwsMetaCol.isEnabled() && cwsMetaCol.isChecked() && !cwsMetaCol.isParent())
            .map(CwsMetaCol::getMetaColId)
            .collect(Collectors.toList());
   }

   private void findApplicableConfigurations(CwsOverzichtSelectieCriteria cwsOverzichtSelectieCriteria, CwsOverzichtMetaAttributes cwsOverzichtMetaAttributes) {
      if (cwsOverzichtSelectieCriteria.hasSelectedFilter()) {
         List<ConfiguratieWithFilters> allApplicableConfigs = this.configurationService.collectAllConfigsWithMatchingFilters(this.leverCode, cwsOverzichtSelectieCriteria);
         cwsOverzichtSelectieCriteria.setAllApplicableConfigs(allApplicableConfigs);
      }

      if (cwsOverzichtMetaAttributes.hasSelectedMetaAttributes()) {
         List<Map<String, Object>> allApplicableConfigs = this.configurationService.collectAllConfigsWithMatchingNewestMetaColIds(cwsOverzichtMetaAttributes.getSelectedAttributesMetaColIds(), this.leverCode);
         cwsOverzichtMetaAttributes.setAllApplicableConfigs(allApplicableConfigs);
         List<Map<String, Object>> selectedMetaColDetails = this.configurationService.getMetaColDetail(cwsOverzichtMetaAttributes.getSelectedAttributesMetaColIds());
         cwsOverzichtMetaAttributes.setSelectedMetaColDetails(selectedMetaColDetails);
      }

      List<Long> configIdsForOverzicht = new ArrayList<>();
      configIdsForOverzicht.addAll(cwsOverzichtMetaAttributes.getAllApplicableConfigIds());
      configIdsForOverzicht.addAll(cwsOverzichtSelectieCriteria.getAllApplicableConfigIds());
      if (configIdsForOverzicht.isEmpty()) {
         removeCwsConfiguratiesSearchResultGrid();
         this.exportConfiguratiesLink.setVisible(false);
         CwsUIUtils.showErrorNotification("Er is geen configuratie gevonden");
      } else {
         List<CwsOverzichtConfiguratie> configuratiesWithSelection = this.configurationService.getConfiguratiesWithAfnemerDetail(configIdsForOverzicht);
         combineConfigurationSelections(configuratiesWithSelection, cwsOverzichtMetaAttributes, cwsOverzichtSelectieCriteria);

         removeCwsConfiguratiesSearchResultGrid();
         final List<OverviewGridData> items = createOverviewGridData(configuratiesWithSelection, cwsOverzichtMetaAttributes, cwsOverzichtSelectieCriteria);
         final ToonConfigurationDataProvider<OverviewGridData> dataProvider = new ToonConfigurationDataProvider<>(items);
         final Grid<OverviewGridData> foundConfigurationsGrid = UIUtils.createGrid(COMPONENT_ID_OVERZICHT_CWS_CONFIGURATIE_SEARCH_RESULT);
         foundConfigurationsGrid.setItems(dataProvider.getItems());
         foundConfigurationsGrid.setSizeUndefined();
         foundConfigurationsGrid.setMinHeight(700, Unit.PIXELS);
         OverviewGridData overviewGridData = items.listIterator().next();
         overviewGridData.getValues().keySet().forEach(key ->
               foundConfigurationsGrid.addColumn(data ->
                     data.get(key)).setHeader(getCleanHeaderName(key)).setSortable(true));
         foundConfigurationsGrid.getColumns().forEach(col -> col.setAutoWidth(true));

         LabelGrid<OverviewGridData> labelGrid = new LabelGrid<>(String.format("Configuratie(s) (%d)", items.size()), foundConfigurationsGrid);
         labelGrid.setId(COMPONENT_ID_OVERZICHT_CWS_CONFIGURATIE_SEARCH_RESULT_LABEL_GRID);

         final String exportFileName = CwsUtils.createExportOverviewFileName();
         this.exportConfiguratiesLink.setHref(new StreamResource(exportFileName, () -> new ExportService().createOverviewWorkBook(items)));
         this.exportConfiguratiesLink.setVisible(true);
         add(labelGrid);
      }
   }

   private String getCleanHeaderName(String headerName){
      if (headerName.contains("(")) {
         return headerName.substring(0, headerName.indexOf("("));
      }
      return headerName;
   }

   private List<OverviewGridData> createOverviewGridData(final List<CwsOverzichtConfiguratie> configurationList,
                                                         final CwsOverzichtMetaAttributes overzichtMetaAttributes,
                                                         final CwsOverzichtSelectieCriteria cwsOverzichtSelectieCriteria){
      List<OverviewGridData> items = new ArrayList<>();
      Map<String, String> repeatedColumnMap = new HashMap<>();

      configurationList.forEach(cwsOverzichtConfiguratie -> {
         OverviewGridData overviewGridData = new OverviewGridData();
         overviewGridData.set("Afn Cd", cwsOverzichtConfiguratie.getAfnemerCode());
         overviewGridData.set("Levering", cwsOverzichtConfiguratie.getLeveringCode());
         overviewGridData.set("Contr nr", cwsOverzichtConfiguratie.getContractId());
         overviewGridData.set("Contr Begindatum", CwsUtils.getLocalDateAsString(cwsOverzichtConfiguratie.getConfigStartDate()));
         overviewGridData.set("Versie", cwsOverzichtConfiguratie.getVersie());
         overviewGridData.set("Config Naam", cwsOverzichtConfiguratie.getName());
         overviewGridData.set("Config Begindatum", CwsUtils.getLocalDateAsString(cwsOverzichtConfiguratie.getConfigStartDate()));
         overviewGridData.set("Config Einddatum", CwsUtils.getLocalDateAsString(cwsOverzichtConfiguratie.getConfigEndDate()));
         overviewGridData.set("Status", cwsOverzichtConfiguratie.getStatus());
         overviewGridData.set("Berichtversie", cwsOverzichtConfiguratie.getBerichtVersie());

         List<BaseCwsOverzichtFilterOption> selectedFilters = cwsOverzichtSelectieCriteria.getSelectedFilters();
         selectedFilters.forEach(selectedFilter -> {
            Map<String, Boolean> configSelectieCriteria = cwsOverzichtConfiguratie.getSelectieCriteria();
            boolean selectieCriteriaValid = configSelectieCriteria != null && configSelectieCriteria.get(selectedFilter.getEnumName());
            String columnHeaderName = selectedFilter.getHeaderColumnName();
            String value = getStringByBoolean(selectieCriteriaValid);
            overviewGridData.set(columnHeaderName, value);
         });

         List<String> selectedMetaColUniqueNames = overzichtMetaAttributes.getSelectedMetaColUniqueNames();
         selectedMetaColUniqueNames.forEach(metaColUniqueName -> {
            Map<String, Boolean> configMetaCol = cwsOverzichtConfiguratie.getMetaColValues();
            boolean metaColValid = configMetaCol != null && configMetaCol.get(metaColUniqueName);
            String value = getStringByBoolean(metaColValid);
            String columnHeaderName = overzichtMetaAttributes.getFuncionalColumnNameByUniqueName(metaColUniqueName);
            if (overviewGridData.getValues().containsKey(columnHeaderName)) {
               if (repeatedColumnMap.containsKey(metaColUniqueName)) {
                  overviewGridData.set(repeatedColumnMap.get(metaColUniqueName), value);
               } else {
                  final int intRandom = ThreadLocalRandom.current().nextInt(20);
                  columnHeaderName += " (" + intRandom + ")";
                  repeatedColumnMap.put(metaColUniqueName, columnHeaderName);
                  overviewGridData.set(columnHeaderName, value);
               }
            } else {
               overviewGridData.set(columnHeaderName, value);
            }
         });

         items.add(overviewGridData);
      });

      return items;
   }

   private String getStringByBoolean(boolean value){
      return value ? "X" : "";
   }

   private void combineConfigurationSelections(List<CwsOverzichtConfiguratie> configuratieList, CwsOverzichtMetaAttributes cwsOverzichtMetaAttributes, CwsOverzichtSelectieCriteria cwsOverzichtSelectieCriteria) {
      if (cwsOverzichtSelectieCriteria.hasSelectedFilter()) {
         Map<Long, Map<String, Boolean>> configsWithFilters = cwsOverzichtSelectieCriteria.getConfigsWithFilters();
         configuratieList.forEach(cwsOverzichtConfiguratie -> {
            Long cconId = cwsOverzichtConfiguratie.getConfigId();
            cwsOverzichtConfiguratie.setSelectieCriteria(configsWithFilters.get(cconId));
         });
      }

      if (cwsOverzichtMetaAttributes.hasSelectedMetaAttributes()) {
         Map<Long, List<String>> groupedUniqueAttributeIdentifierByCconId = cwsOverzichtMetaAttributes.getConfigsWithUniqueColumns();
         configuratieList.forEach(cwsOverzichtConfiguratie -> {
            Long cconId = cwsOverzichtConfiguratie.getConfigId();
            Map<String, Boolean> configMetaColValues = setValuesForAllSelectedMetaCols(cwsOverzichtMetaAttributes.getSelectedMetaColUniqueNames(), groupedUniqueAttributeIdentifierByCconId.get(cconId));
            cwsOverzichtConfiguratie.setMetaColValues(configMetaColValues);
         });
      }
   }

   private Map<String, Boolean> setValuesForAllSelectedMetaCols(List<String> selectedMetaColUniqueNames, List<String> uniqueAttributesForConfig) {
      Map<String, Boolean> configMetaColData = new HashMap<>();
      selectedMetaColUniqueNames.forEach(metaColUniqueName -> {
         Boolean configContainsAttribute = uniqueAttributesForConfig != null && uniqueAttributesForConfig.contains(metaColUniqueName);
         configMetaColData.put(metaColUniqueName, configContainsAttribute);
      });
      return configMetaColData;
   }

   private void removeCwsConfiguratiesSearchResultGrid() {
      Component searchResult = findComponent(COMPONENT_ID_OVERZICHT_CWS_CONFIGURATIE_SEARCH_RESULT_LABEL_GRID, this);
      if (searchResult != null) {
         remove(searchResult);
      }
   }

   @Getter
   static class ToonConfigurationDataProvider<T> extends ListDataProvider<T> {

      public ToonConfigurationDataProvider(Collection<T> items) {
         super(items);
      }

      @Override
      public String getId(T item) {
         Objects.requireNonNull(item,"Cannot provide an id for a null item.");
         if (item instanceof OverviewGridData) {
            if (((OverviewGridData) item).get("id") != null) {
               return ((OverviewGridData) item).get("id").toString();
            } else {
               return item.toString();
            }
         } else {
            return item.toString();
         }
      }
   }
}
