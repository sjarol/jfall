package nl.uwv.pws.cws.views.beheer.tabs;

import com.vaadin.flow.component.Component;
import nl.uwv.pws.ui.util.HasAuthorization;

public interface TabView extends HasAuthorization {

   Component getViewHeader();

   Component getViewContent();
}
