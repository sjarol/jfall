package nl.uwv.pws.cws.model;

import lombok.Builder;
import lombok.Getter;

@Builder
@Getter
public class CodeSoortIkv {
    private String code;
    private String omschrijving;
    private String datumEinde;
}
