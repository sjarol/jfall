package nl.uwv.pws.cws.views.beheer.tabs.layout;

import com.vaadin.flow.component.checkbox.Checkbox;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import lombok.Getter;
import nl.uwv.pws.cws.model.viewtab.BaseCwsOverzichtFilterOption;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Getter
public abstract class BaseOverzichtFilterLayout extends VerticalLayout {
    private List<Checkbox> checkboxList;

    public BaseOverzichtFilterLayout(Checkbox...checkBoxes) {
        this.checkboxList = Arrays.asList(checkBoxes);
       checkboxList.forEach(this::add);
    }

    protected abstract BaseCwsOverzichtFilterOption filterOptionValueOf(String id);

    public List<BaseCwsOverzichtFilterOption> getSelectedFilters() {
        return this.checkboxList.stream()
            .filter(Checkbox::getValue)
            .map(checkbox -> checkbox.getId().get())
            .map(this::filterOptionValueOf)
            .collect(Collectors.toList());
    }

    protected static Checkbox initiateCheckboxWithId(String description, BaseCwsOverzichtFilterOption cwsOverzichtFilterOption) {
        Checkbox checkbox = new Checkbox(description);
        checkbox.setId(cwsOverzichtFilterOption.getEnumName());
        return checkbox;
    }

}
