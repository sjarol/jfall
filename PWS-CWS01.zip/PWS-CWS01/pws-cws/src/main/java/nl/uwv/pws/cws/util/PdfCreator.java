package nl.uwv.pws.cws.util;

import fr.opensagres.xdocreport.converter.ConverterTypeTo;
import fr.opensagres.xdocreport.converter.ConverterTypeVia;
import fr.opensagres.xdocreport.converter.Options;
import fr.opensagres.xdocreport.core.XDocReportException;
import fr.opensagres.xdocreport.document.IXDocReport;
import fr.opensagres.xdocreport.document.registry.XDocReportRegistry;
import fr.opensagres.xdocreport.template.IContext;
import fr.opensagres.xdocreport.template.TemplateEngineKind;
import fr.opensagres.xdocreport.template.formatter.FieldsMetadata;
import lombok.extern.slf4j.Slf4j;
import nl.uwv.pws.backend.dao.BackendException;
import org.apache.commons.lang3.StringUtils;

import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.*;

/**
 * Genereert een PDF-rapport op basis van een .odt sjabloon.
 */
@Slf4j
public final class PdfCreator {

	private static final String SAX_DRIVER = "org.xml.sax.driver";
   private static final String XERCES_DRIVER = "org.apache.xerces.parsers.SAXParser";
	private static final String SAX_PARSER_FACTORY = "javax.xml.parsers.SAXParserFactory";
	private static final String XERCES = "org.apache.xerces.jaxp.SAXParserFactoryImpl";
	private static final String DOT = ".";

	/**
	 * Genereert een dynamisch pdf-rapport. Parameters die herhaald moeten
	 * worden dienen te worden ingevoerd als een list in de mapping parameter.
	 * In de listTypes moet de class worden opgevoerd voor alle parameters die
	 * in een list worden meegegeven (de typeparameter van de List). Alleen
	 * lists met als generieke parameter een POJO class worden ondersteund.
	 * NB: Lists mogen niet gelijktijdig worden gemodificeerd, terwijl het rapport wordt gemaakt!
	 *
	 * @param template
	 *            odt-template
	 * @param mapping
	 *            mapping van sjabloonparameters naar java objecten
	 * @param listTypes
	 *            specificatie van welke sjabloonparameters een list zijn
	 * @return
	 */
	public static byte[] makeReport(InputStream template, Map<String, Object> mapping,
									Map<String, Class<?>> listTypes) {

		synchronized (XDocReportRegistry.class){

			ByteArrayOutputStream out = null;
			String previousSaxDriver = System.getProperty(SAX_DRIVER);
			String previousSaxParserFactory = System.getProperty(SAX_PARSER_FACTORY);
			XDocReportRegistry.getRegistry().clear();

			try {
            /**
             * XDOCreports is afhankelijk van xerces 2.9.1. Voor correcte
             * werking dient de xerces saxparserfactoryimpl de standaard
             * saxparserfactory te zijn. Vervolgens is gebleken dat XDOC
             * alleen correct werkt als wel de weblogic implementatie van de
             * sax driver wordt gebruikt.
             */
            ThreadLocalProperties.assertPropertiesAreThreadSafe();
            System.setProperty(SAX_DRIVER, XERCES_DRIVER);
				System.setProperty(SAX_PARSER_FACTORY, XERCES);

				out = new ByteArrayOutputStream();
				IXDocReport report = XDocReportRegistry.getRegistry().loadReport(template,
					TemplateEngineKind.Freemarker);
				Options options = Options.getTo(ConverterTypeTo.PDF).via(ConverterTypeVia.ODFDOM);
				IContext ctx = report.createContext();

				if (listTypes.size() > 0) {
					registerListTypes(report, listTypes);
				}

				ctx.putMap(mapping);
				report.convert(ctx, options, out);
				return out.toByteArray();

			} catch (IOException e) {
				throw new BackendException(e);
			} catch (XDocReportException e) {
				throw new BackendException(e);
			} finally {
				/**
				 * system properties terugzetten, voor het geval de thread nog iets gaat
				 * doen waarvoor een sax parser wordt gebruikt.
				 */
				System.setProperty(SAX_DRIVER, previousSaxDriver);
				System.setProperty(SAX_PARSER_FACTORY, previousSaxParserFactory);
				closeAll(template, out);
			}
		}
	}

	/**
	 * Genereert een pdf op basis van een statische template.
	 *
	 * @param template
	 *            odt-sjabloon
	 * @param mapping
	 *            mapping tussen sjabloonparameters en java objecten
	 * @return report
	 */
	public static byte[] makeReport(InputStream template, Map<String, Object> mapping) {
		return makeReport(template, mapping, Collections.<String, Class<?>>emptyMap());
	}

	private PdfCreator() {

	}

	private static void registerListTypes(IXDocReport report,
			Map<String, Class<?>> listTypes) {
		FieldsMetadata metadata = report.createFieldsMetadata();
		Iterator<Map.Entry<String, Class<?>>> i = listTypes.entrySet().iterator();

		while (i.hasNext()) {

			Map.Entry<String, Class<?>> e = i.next();
			List<String> fieldNames = getFieldNames(e.getValue());
			String prefix = e.getKey() + DOT;

			for (String fieldName : fieldNames) {
				metadata.addFieldAsList(prefix + fieldName);
			}
		}
	}

	private static List<String> getFieldNames(Class<?> clazz) {
		Field[] fields = clazz.getDeclaredFields();
		int length = fields.length;

		List<String> names = new ArrayList<String>();
		for (int i = 0; i < length; i++) {
			if (!Modifier.isStatic(fields[i].getModifiers())){
				names.add(fields[i].getName());
			}
		}

		return names;
	}

	private static void closeAll(Closeable... cls) {
		for (Closeable c : cls) {
			if (c != null) {
				try {
					c.close();
				} catch (IOException e) {
					throw new BackendException(e);
				}
			}
		}
	}
}
