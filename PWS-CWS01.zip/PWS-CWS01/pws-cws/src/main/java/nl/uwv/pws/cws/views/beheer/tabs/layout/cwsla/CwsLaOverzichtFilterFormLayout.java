package nl.uwv.pws.cws.views.beheer.tabs.layout.cwsla;

import nl.uwv.pws.cws.model.viewtab.BaseCwsOverzichtFilterOption;
import nl.uwv.pws.cws.model.viewtab.CwsLaFilter;
import nl.uwv.pws.cws.views.beheer.tabs.layout.BaseOverzichtFilterLayout;

public class CwsLaOverzichtFilterFormLayout extends BaseOverzichtFilterLayout {
    public CwsLaOverzichtFilterFormLayout() {
        super(initiateCheckboxWithId("Filter code soort inkomstenverhouding", CwsLaFilter.CD_SOORT_IKVS),
              initiateCheckboxWithId("Filter nihil loon SV uitsluiten", CwsLaFilter.NIHIL_LNSV_UITSLUITEN),
              initiateCheckboxWithId("Filter nihil loon LB/PH uitsluiten", CwsLaFilter.NIHIL_LNLBPH_UITSLUITEN)
            );
    }

    @Override
    protected BaseCwsOverzichtFilterOption filterOptionValueOf(String id) {
        return CwsLaFilter.valueOf(id);
    }
}
