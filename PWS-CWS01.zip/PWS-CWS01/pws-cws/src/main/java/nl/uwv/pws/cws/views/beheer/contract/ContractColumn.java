package nl.uwv.pws.cws.views.beheer.contract;

import nl.uwv.pws.backend.types.Column;

/**
 * List of columns in the view CWS_CONTRACT_VW.
 */
public enum ContractColumn implements Column {
   AFN_CD,
   AFN_NAAM,
   LEV_CD,
   CONTRACT_ID,
   HIS_DAT_IN,
   HIS_DAT_END
}
