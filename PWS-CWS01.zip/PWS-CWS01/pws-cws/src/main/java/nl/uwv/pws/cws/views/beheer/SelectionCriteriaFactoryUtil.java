package nl.uwv.pws.cws.views.beheer;

import nl.uwv.pws.cws.model.*;

import java.util.HashMap;
import java.util.Map;

import static nl.uwv.pws.cws.model.CwsLaFilterType.*;
import static nl.uwv.pws.cws.model.CwsNpFilterType.LEVEND_NPE_UITSLUITEN;
import static nl.uwv.pws.cws.model.CwsNpFilterType.OVERLEDEN_NPE_UITSLUITEN;
import static nl.uwv.pws.cws.util.Constants.*;
import static nl.uwv.pws.cws.util.CwsUtils.convertBooleanToString;

public final class SelectionCriteriaFactoryUtil {

   private SelectionCriteriaFactoryUtil() {
   }

   public static SelectionCriteria createCwsLaSelectieCriteria(final String cdSoortIkv, final String maxLeverperiode,
                                                               final boolean nihilLoonSvUitsluiten, final boolean nihilLoonLbPhUitsluiten) {
      SelectionCriteria selectieCriteria = new SelectionCriteria(CWSLA_LEV_CODE);
      Map<BaseCwsFilterType, String> filterMap = new HashMap<>();
      filterMap.put(CD_SOORT_IKVS, cdSoortIkv);
      filterMap.put(MAX_LEVERPERIODE, maxLeverperiode);
      filterMap.put(NIHIL_LNSV_UITSLUITEN, convertBooleanToString(nihilLoonSvUitsluiten));
      filterMap.put(NIHIL_LNLBPH_UITSLUITEN, convertBooleanToString(nihilLoonLbPhUitsluiten));

      selectieCriteria.setFilterMap(filterMap);

      return selectieCriteria;
   }

   public static SelectionCriteria createCwsNpSelectieCriteria(final boolean levendPersoonUitsluiten, final boolean overledenPersoonUitsluiten) {
      SelectionCriteria selectieCriteria = new SelectionCriteria(CWSNP_LEV_CODE);
      Map<BaseCwsFilterType, String> filterMap = new HashMap<>();
      filterMap.put(LEVEND_NPE_UITSLUITEN, convertBooleanToString(levendPersoonUitsluiten));
      filterMap.put(OVERLEDEN_NPE_UITSLUITEN, convertBooleanToString(overledenPersoonUitsluiten));

      selectieCriteria.setFilterMap(filterMap);
      return selectieCriteria;
   }

   public static SelectionCriteria createCwsHrSelectieCriteria(final boolean beeindigdAdresUitsluiten) {
      SelectionCriteria selectieCriteria = new SelectionCriteria(CWSHR_LEV_CODE);
      Map<BaseCwsFilterType, String> filterMap = new HashMap<>();
      filterMap.put(CwsHrFilterType.BEEINDIGD_ADRES_UITSLUITEN, convertBooleanToString(beeindigdAdresUitsluiten));

      selectieCriteria.setFilterMap(filterMap);
      return selectieCriteria;
   }

   public static SelectionCriteria createCwsIhpSelectieCriteria(final boolean beeindigdAdresUitsluiten) {
      SelectionCriteria selectieCriteria = new SelectionCriteria(CWSIHP_LEV_CODE);
      Map<BaseCwsFilterType, String> filterMap = new HashMap<>();
      filterMap.put(CwsIhpFilterType.BEEINDIGD_ADRES_UITSLUITEN_IHP, convertBooleanToString(beeindigdAdresUitsluiten));

      selectieCriteria.setFilterMap(filterMap);
      return selectieCriteria;
   }

   public static SelectionCriteria createCwsWgSelectieCriteria(final boolean beeindigdAdresUitsluiten) {
      SelectionCriteria selectieCriteria = new SelectionCriteria(CWSWG_LEV_CODE);
      Map<BaseCwsFilterType, String> filterMap = new HashMap<>();
      filterMap.put(CwsWgFilterType.BEEINDIGD_ADRES_UITSLUITEN_WG, convertBooleanToString(beeindigdAdresUitsluiten));

      selectieCriteria.setFilterMap(filterMap);
      return selectieCriteria;
   }

   public static SelectionCriteria createGenericSelectieCriteria(final String levercode, final Map<BaseCwsFilterType, String> importedSoortSelectie) {
      SelectionCriteria selectionCriteria = new SelectionCriteria(levercode);
      selectionCriteria.setFilterMap(importedSoortSelectie);
      return selectionCriteria;
   }
}
