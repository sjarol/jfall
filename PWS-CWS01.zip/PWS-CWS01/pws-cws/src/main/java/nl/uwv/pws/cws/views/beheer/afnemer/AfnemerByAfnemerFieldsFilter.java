package nl.uwv.pws.cws.views.beheer.afnemer;

import lombok.Getter;
import nl.uwv.pws.backend.dao.SqlFilter;
import nl.uwv.pws.cws.views.beheer.tabs.events.AfnemersSearchEvent;
import org.apache.commons.lang3.StringUtils;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * SqlFilter to use for querying the proper subset of afnemer records.
 */
@Getter
public class AfnemerByAfnemerFieldsFilter implements SqlFilter, Serializable {
   private final String sqlFilter;
   private final List<String> parameters = new ArrayList<>();
   private String afnemerCode;
   private boolean allowedToUseWildcard;
   private String afnemerName;
   private String ugcId;

   public AfnemerByAfnemerFieldsFilter(final AfnemersSearchEvent searchEvent) {
      this.allowedToUseWildcard = true;
      this.afnemerCode = StringUtils.trimToNull(searchEvent.getAfnemerCode());
      this.afnemerName = StringUtils.trimToNull(searchEvent.getAfnemerNaam());
      this.ugcId = StringUtils.trimToNull(searchEvent.getUgcId());
      this.sqlFilter = createSqlFilter();
   }

   public AfnemerByAfnemerFieldsFilter(final String afnemerCode) {
      this.allowedToUseWildcard = false;
      this.afnemerCode = afnemerCode;
      this.sqlFilter = createSqlFilter();
   }

   public AfnemerByAfnemerFieldsFilter() {
      sqlFilter = "1 = 1";
   }

   private String createSqlFilter() {
      if (afnemerCode == null && afnemerName == null && ugcId == null) {
         return String.format("(%s IS NOT NULL)", AfnemerColumn.AFN_CD);
      }
      StringBuilder filter = new StringBuilder();
      if (afnemerCode != null) {
         if (allowedToUseWildcard) {
            filter.append("UPPER(AFN_CD) LIKE '%'||?||'%'");
         } else {
            filter.append("UPPER(AFN_CD) = ?");
         }
         parameters.add(afnemerCode.toUpperCase());
      }
      if (afnemerName != null) {
         if (filter.length() > 0) {
            filter.append(" AND ");
         }
         filter.append("UPPER(NAAM) LIKE '%'||?||'%'");
         parameters.add(afnemerName.toUpperCase());
      }
      if (ugcId != null) {
         if (filter.length() > 0) {
            filter.append(" AND ");
         }
         filter.append("TO_CHAR(UGC_ID) LIKE '%'||?||'%'");
         parameters.add(ugcId);
      }

      return "(" + filter.toString() + ")";
   }

   @Override
   public String getFilterSql() {
      return sqlFilter;
   }

   @Override
   public int getParametersSize() {
      return parameters.size();
   }

   @Override
   public String getParameter(final int index) {
      return parameters.get(index);
   }
}
