package nl.uwv.pws.cws.model;

import static nl.uwv.pws.cws.util.Constants.CWSLA_LEV_CODE;

public enum CwsLaFilterType implements BaseCwsFilterType {
    CD_SOORT_IKVS,
    MAX_LEVERPERIODE,
    NIHIL_LNSV_UITSLUITEN,
    NIHIL_LNLBPH_UITSLUITEN;

    @Override
    public String filterName() {
        return name();
    }

    @Override
    public String levCode() {
        return CWSLA_LEV_CODE;
    }
}
