package nl.uwv.pws.cws.views.beheer.tabs.layout.cwswg;

import nl.uwv.pws.cws.model.viewtab.BaseCwsOverzichtFilterOption;
import nl.uwv.pws.cws.model.viewtab.CwsWgFilter;
import nl.uwv.pws.cws.views.beheer.tabs.layout.BaseOverzichtFilterLayout;

public class CwsWgOverzichtFilterFormLayout extends BaseOverzichtFilterLayout {

   public CwsWgOverzichtFilterFormLayout() {
     super(initiateCheckboxWithId("Filter beëindigd adres uitsluiten", CwsWgFilter.BEEINDIGD_ADRES_UITSLUITEN_WG));
    }

    @Override
    protected BaseCwsOverzichtFilterOption filterOptionValueOf(String id) {
        return CwsWgFilter.valueOf(id);
    }
}
