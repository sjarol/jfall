package nl.uwv.pws.cws.backend.service;


import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import nl.uwv.pws.cws.ApplicationInfo;
import nl.uwv.pws.cws.backend.dao.CwsConfigurationDao;
import nl.uwv.pws.cws.util.Constants;
import org.apache.commons.lang3.StringUtils;

import java.util.Properties;

@Slf4j
@Setter
public class AppiConfigService extends BaseService {
   private Properties props;

   public void initialize(){
      if(props == null) {
         String programId = Constants.PGRM_ID;
         String envName = Constants.ENV_NAME;
         String instanceName = Constants.INSTANCE_NAME;
         String release = new ApplicationInfo().getImplementationVersion();

         int appiId = getAppiId(programId, envName, instanceName, release);
         props = cwsConfigurationDao.getAppiConfig(appiId);
      }
   }

   private int getAppiId(String programId, String envName, String instanceName, String release) {
      String releaseNr = release.replace("-SNAPSHOT", "");
      return cwsConfigurationDao.getAppiId(programId, envName, instanceName, releaseNr);
   }

   /**
    * Heeft de property een waarde?
    *
    * @param propertyName
    * @return boolean
    */
   public boolean contains(String propertyName) {
      log.debug("AppiConfigService - contains " + propertyName);
      return props.containsKey(propertyName);
   }

   public String getValue(String propertyName) {
      log.debug("AppiConfigService - getValue {} ", propertyName);
      String value = props.getProperty(propertyName);
      if (StringUtils.isEmpty(value)) {
         log.debug("Property is onbekend of heeft geen waarde.");
      } else {
         log.debug("value {}", value);
      }
      return value;
   }
}
