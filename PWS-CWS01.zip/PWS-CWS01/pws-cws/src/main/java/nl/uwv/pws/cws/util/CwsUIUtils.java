package nl.uwv.pws.cws.util;

import com.vaadin.flow.component.AbstractField.ComponentValueChangeEvent;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.checkbox.Checkbox;
import com.vaadin.flow.component.datepicker.DatePicker;
import com.vaadin.flow.component.formlayout.FormLayout;
import com.vaadin.flow.component.grid.GridVariant;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.notification.NotificationVariant;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.component.treegrid.TreeGrid;
import com.vaadin.flow.data.provider.hierarchy.HierarchicalDataProvider;
import com.vaadin.flow.data.value.ValueChangeMode;
import com.vaadin.flow.function.SerializablePredicate;
import nl.uwv.pws.cws.model.CwsMetaCol;
import nl.uwv.pws.cws.views.beheer.tabs.dialogs.ConfigurationDialog;
import nl.uwv.pws.ui.util.FontSize;
import nl.uwv.pws.ui.util.FontWeight;
import nl.uwv.pws.ui.util.TextColor;
import nl.uwv.pws.ui.util.UIUtils;
import org.apache.commons.lang3.StringUtils;

import java.time.LocalDate;
import java.util.List;
import java.util.Locale;

import static nl.uwv.pws.cws.util.Constants.TWENTY_EM;

public class CwsUIUtils {

   private CwsUIUtils() {
      throw new IllegalStateException("Utility class");
   }

   public static Label createHeaderLabel(final String labelText) {
      Label label = UIUtils.createLabel(FontSize.L, TextColor.HEADER, labelText);
      UIUtils.setFontWeight(FontWeight.BOLD, label);
      return label;
   }

   public static Button createButton(final String text, final VaadinIcon icon, final String id, final boolean enabled, String width) {
      Button button = new Button(text, icon.create());
      button.setId(id);
      button.addThemeVariants(ButtonVariant.LUMO_PRIMARY);
      button.setEnabled(enabled);
      button.setWidth(width);
      button.setVisible(true);
      return button;
   }

   public static Checkbox createCheckbox(final String id, final boolean fieldValue, final boolean enabled) {
      Checkbox checkbox = new Checkbox();
      checkbox.setId(id);
      checkbox.setEnabled(enabled);
      checkbox.setValue(fieldValue);

      return checkbox;
   }

   public static TextField createTextField(final String id, final String fieldValue, final boolean enabled, final Integer maxLength) {
      TextField textField = new TextField();
      textField.setId(id);
      textField.setEnabled(enabled);
      textField.setWidth(TWENTY_EM);
      textField.setValueChangeMode(ValueChangeMode.ON_CHANGE);
      textField.setClearButtonVisible(true);

      if (maxLength != null) {
         textField.setMaxLength(maxLength);
      }
      if (fieldValue != null) {
         textField.setValue(fieldValue);
      }

      return textField;
   }

   public static DatePicker createDatePicker(final String id, final boolean required, final LocalDate value, final boolean enabled) {
      DatePicker datePicker = new DatePicker();
      datePicker.setId(id);
      datePicker.setValue(value);
      datePicker.setLocale(Locale.forLanguageTag("nl"));
      datePicker.setEnabled(true);
      datePicker.setRequiredIndicatorVisible(required);
      datePicker.setRequired(required);
      datePicker.setEnabled(enabled);
      datePicker.setErrorMessage("Datum is niet correct");
      return datePicker;
   }

   public static HorizontalLayout createButtonStrip(final String id, String width) {
      HorizontalLayout buttonsStrip = new HorizontalLayout();
      buttonsStrip.setId(id);
      buttonsStrip.setVisible(true);
      buttonsStrip.setWidth(width);

      return buttonsStrip;
   }

   public static void showErrorNotification(final String message) {
      UIUtils.showNotification(message, -1, Notification.Position.MIDDLE, NotificationVariant.LUMO_ERROR);
   }

   public static void showSuccesNotification(final String message) {
      UIUtils.showSuccessNotification(message);
   }

   public static ConfigurationDialog createConfigurationDialog(){
      return new ConfigurationDialog(null);
   }

   public static FormLayout.FormItem addFormItem(final FormLayout layout, final Component item, final String label, final boolean isRequired) {
      Label pwsLabel = UIUtils.createLabel(TextColor.PRIMARY, label);
      if (isRequired) {
         pwsLabel.addClassName("required");
      }
      FormLayout.FormItem formItem = layout.addFormItem(item, pwsLabel);
      formItem.getElement().getStyle().set("--vaadin-form-item-label-width", "33%");

      return formItem;
   }

   public static Component findComponent(final String id, final Component component) {
      return component.getChildren()
            .flatMap(Component::getChildren)
            .filter(childComponent -> childComponent.getId().isPresent() && childComponent.getId().get().equalsIgnoreCase(id))
            .findFirst()
            .orElse(null);
   }

   public static TreeGrid<CwsMetaCol> createTreeGrid(List<CwsMetaCol> cwsMetaColList, TreeGridValueChangeListenerConsumer<ComponentValueChangeEvent<Checkbox, Boolean>,
         CwsMetaCol, HierarchicalDataProvider<CwsMetaCol, SerializablePredicate<CwsMetaCol>>> treeGridValueChangeListenerConsumer) {
      TreeGrid<CwsMetaCol> tree = new TreeGrid<>();
      tree.removeAllColumns();
      cwsMetaColList.forEach(entry -> tree.getTreeData().addItem(entry.getParent(), entry));
      HierarchicalDataProvider<CwsMetaCol, SerializablePredicate<CwsMetaCol>> dataProvider = tree.getDataProvider();

      tree.addComponentHierarchyColumn(cwsMetaCol -> {
         HorizontalLayout container = new HorizontalLayout();

         Checkbox checkbox = new Checkbox(cwsMetaCol.isChecked());
         String checkboxId = buildCheckboxId(cwsMetaCol.getFuncNaam(), cwsMetaCol.getParent());
         checkbox.setId(checkboxId);
         checkbox.setEnabled(cwsMetaCol.isEnabled());
         Label checkboxLabel = new Label(cwsMetaCol.getFuncNaam());
         if(!cwsMetaCol.isEnabled()){
            checkbox.setClassName("v-disabled");
            checkboxLabel.setClassName("v-disabled");
         }

         checkbox.addValueChangeListener(valueChangeEvent -> treeGridValueChangeListenerConsumer.checkboxSelected(valueChangeEvent, cwsMetaCol, dataProvider));
         container.add(checkbox);

         if (cwsMetaCol.isDisplayIcon()) {
            container.add(new Label("  *  "));
         }

         container.add(checkboxLabel);
         return container;
      }).setHeader("Attribuut");

      tree.setSizeUndefined();
      tree.expand(cwsMetaColList);
      tree.addThemeVariants(GridVariant.LUMO_ROW_STRIPES);
      tree.getDataProvider().refreshAll();

      return tree;
   }

   private static String buildCheckboxId(final String attributeName, final CwsMetaCol parent) {
      if (parent == null) {
         return StringUtils.deleteWhitespace(attributeName).toUpperCase();
      }
      return buildCheckboxId(parent.getFuncNaam() + "." + attributeName, parent.getParent());
   }
}
