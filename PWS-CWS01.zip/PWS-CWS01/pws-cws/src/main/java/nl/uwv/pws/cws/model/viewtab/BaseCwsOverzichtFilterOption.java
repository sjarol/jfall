package nl.uwv.pws.cws.model.viewtab;

public interface BaseCwsOverzichtFilterOption {
    String getColumnName();
    String getHeaderColumnName();
    String getEnumName();
    boolean testCondition(String value);
}
