package nl.uwv.pws.cws.views.beheer.contract;

import nl.uwv.pws.backend.desc.FieldDescParser;
import nl.uwv.pws.backend.desc.FieldDescriptor;

/**
 * FieldDescriptor that reads its column definitions from the file contract_by_afnemer.desc.
 */
public final class ContractFieldByAfnemerDescriptor extends FieldDescriptor {
   private static final ContractFieldByAfnemerDescriptor INSTANCE = new ContractFieldByAfnemerDescriptor(
         ContractFieldByAfnemerDescriptor.class.getPackage().getName().replace('.', '/') + "/contract_by_afnemer.desc"
   );

   private ContractFieldByAfnemerDescriptor(final String resource) {
      super(new FieldDescParser().parse(resource));
   }

   static ContractFieldByAfnemerDescriptor getInstance() {
      return INSTANCE;
   }
}
