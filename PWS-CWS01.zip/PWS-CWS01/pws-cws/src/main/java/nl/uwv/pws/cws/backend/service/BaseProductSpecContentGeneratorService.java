package nl.uwv.pws.cws.backend.service;

import lombok.Getter;
import nl.uwv.pws.cws.model.CwsConfiguration;
import nl.uwv.pws.cws.model.CwsMetaCol;
import nl.uwv.pws.cws.model.SelectionCriteria;
import nl.uwv.pws.cws.util.ConfigurationStatus;
import nl.uwv.pws.cws.util.CwsUtils;
import nl.uwv.pws.cws.util.PdfCreator;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.joox.Match;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.function.Function;
import java.util.stream.IntStream;

import static java.util.stream.Collectors.joining;
import static nl.uwv.pws.cws.model.CwsNpFilterType.OVERLEDEN_NPE_UITSLUITEN;
import static nl.uwv.pws.cws.util.Constants.*;
import static nl.uwv.pws.cws.util.CwsUtils.convertStringToBoolean;
import static org.apache.commons.lang3.StringUtils.EMPTY;
import static org.joox.JOOX.$;

@Getter
public abstract class BaseProductSpecContentGeneratorService extends BaseService {
    private static final String QUADRUPLE_SPACES = "    ";
    private static final DateTimeFormatter DATUM_TIJD_FORMAT = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");

    protected static final String METADATA_BASE_FOLDER = "../templates/metadata/";
    protected static final String REQUEST_FILE_NAME = "Request.xml";

    protected static final String FUNC_FOUT_RESPONSE_FILE_NAME = "Response_funcfout.xml";
    protected static final String TECH_FOUT_RESPONSE_FILE_NAME = "Response_techfout.xml";

    protected final String pdfKenmerk;
    protected final String requestHeader;
    protected final String responseHeader;
    protected final CwsConfiguration cwsConfiguration;
    protected final SelectionCriteria selectionCriteria;
    private final String plainProductSpecFileName;

    public BaseProductSpecContentGeneratorService(final CwsConfiguration cwsConfiguration, final String pdfKenmerk,
                                                  final String requestHeader, final String responseHeader) {
        this.pdfKenmerk = pdfKenmerk;
        this.cwsConfiguration = cwsConfiguration;
        this.requestHeader = requestHeader;
        this.responseHeader = responseHeader;
        this.selectionCriteria = findSelectionCriteria();
        this.plainProductSpecFileName = CwsUtils.createPlainProductSpecFileName(cwsConfiguration.getConfigurationName(), cwsConfiguration.getConfigurationVersion().toString(), cwsConfiguration.getAfnemerCode());
    }

    protected abstract String [] getExampleRequestFileNames();
    protected abstract String getPdfTemplateFileName();
    protected abstract String getExampleXmlFolderName();
    protected abstract String getResponseBodyRootElementName();
    protected abstract Map<String, Object> getSelectieCriteriaMapping();

    protected abstract String generateComplexExampleResponseFileName();
    protected abstract String generateSimpleExampleResponseFileName();
    protected abstract String generateFilteredComplexExampleResponseContent() throws IOException, SAXException, ParserConfigurationException;
    protected abstract String generateComplexExampleResponseContent() throws IOException, SAXException, ParserConfigurationException;
    protected abstract String generateSimpleExampleResponseContent() throws IOException, SAXException, ParserConfigurationException;

   public byte[] generatePdfByteArray() {
        InputStream pdfResource = BaseProductSpecContentGeneratorService.class.getResourceAsStream(getPdfTemplateFileName());
        Map<String, Object> pdfMapping = createBasicPdfMapping();
        pdfMapping.putAll(getSelectieCriteriaMapping());
        return PdfCreator.makeReport(pdfResource, pdfMapping);
    }

    protected Map<String, Object> createBasicPdfMapping() {
        Map<String, Object> mapping = new HashMap<>();
        mapping.put("product_code", mapProductCodeToOmschrijving(cwsConfiguration.getLeverCode()));
        mapping.put("aanmaakdatum", DATUM_TIJD_FORMAT.format(LocalDateTime.now()));
        mapping.put("afnemer_code", cwsConfiguration.getAfnemerCode());
        mapping.put("afnemer_naam", Optional.ofNullable(cwsConfiguration.getAfnemerNaam()).orElse(""));
        mapping.put("ugc_id", findUgcId(cwsConfiguration.getAfnemerCode()));
        mapping.put("contractnummer", cwsConfiguration.getContractId().toString());
        mapping.put("datum_aanvang_contract", CwsUtils.getLocalDateAsString(cwsConfiguration.getContractStartDate()));
        mapping.put("kenmerk", StringUtils.isNotBlank(pdfKenmerk) ? "- ".concat(pdfKenmerk) : "");
        if (cwsConfiguration.getConfigurationVersion() != null) {
            mapping.put("configuratie_versienummer", cwsConfiguration.getConfigurationVersion());
            String configName = Optional.ofNullable(cwsConfiguration.getConfigurationName()).orElse(EMPTY);
            mapping.put("configuratie_naam", configName);
            mapping.put("configuratie_status", mapConfiguratieStatusCodeToDescription(cwsConfiguration.getConfigurationStatus()));
        }

        String treeAsText = transformTreeToText(getSelectedAttributesTree(cwsConfiguration.getConfigurationId()), 0);
        mapping.put("attributen", treeAsText);
        return mapping;
    }

    public String generateExampleRequestFromFileName(String fileName) {
        return generateXmlNameForFile(fileName);
    }

    public String generateRequestContent(String exampleRequestFileName) throws IOException {
        String fullRequestXmlLocation = getFullExampleLocation(exampleRequestFileName);

        InputStream requestXmlAsStream = BaseProductSpecContentGeneratorService.class.getResourceAsStream(fullRequestXmlLocation);
        String requestXmlTemplate = IOUtils.toString(requestXmlAsStream, StandardCharsets.UTF_8.name());
        String contractStartDateValue = CwsUtils.getLocalDateAsLong(cwsConfiguration.getContractStartDate()).toString();

        String replacedExampleRequest = requestXmlTemplate
                .replace("${HEADER}", requestHeader)
                .replace("${VERSION}", cwsConfiguration.getBerichtVersie())
                .replace("${CONTRACT_NUMMER}", cwsConfiguration.getContractId().toString())
                .replace("${CONTRACT_START}", contractStartDateValue)
                .replace("${CONFIGURATIE_VERSIE}", cwsConfiguration.getConfigurationVersion().toString());

        return replaceSpecificRequestContent(replacedExampleRequest);
    }

    /**
     * Override me if you need to replace more for specific module
     *
     * @param replacedExampleRequest
     * @return
     */
    protected String replaceSpecificRequestContent(String replacedExampleRequest) {
        return replacedExampleRequest;
    }

    protected String generateExampleResponseContent(String responseFileName) throws ParserConfigurationException, SAXException, IOException {
        String fullXmlLocation = getFullExampleLocation(responseFileName);
        String replacedExampleResponse = generateExampleResponseByConfiguratie(fullXmlLocation);
        return replaceSpecificResponseContent(replacedExampleResponse);
    }

    /**
     * Override me if you need to replace more for specific module
     *
     * @param replacedExampleResponse
     * @return
     */
    protected String replaceSpecificResponseContent(String replacedExampleResponse) {
        return replacedExampleResponse;
    }

    private String generateExampleResponseByConfiguratie(String fullXmlLocation) throws ParserConfigurationException, SAXException, IOException {
        InputStream fullXmlInputStream = BaseProductSpecContentGeneratorService.class.getResourceAsStream(fullXmlLocation);
        String responseXmlTemplate = IOUtils.toString(fullXmlInputStream, StandardCharsets.UTF_8.name());

        responseXmlTemplate = responseXmlTemplate
                .replace("${HEADER}", responseHeader)
                .replace("${VERSION}", cwsConfiguration.getBerichtVersie())
                .replace("${MAJOR_VERSION}", cwsConfiguration.getBerichtVersie().substring(0, 2))
                .replace("${MINOR_VERSION}", cwsConfiguration.getBerichtVersie().substring(2));


        List<CwsMetaCol> cwsMetaColList = cwsConfigurationDao.selectConfigurationMetaData(cwsConfiguration.getConfigurationId());
        excludeVipsFromConfigurationAttributes(cwsMetaColList);
        if (CWSNP_LEV_CODE.equals(cwsConfiguration.getLeverCode())) {
            excludeFiltersFromConfigurationAttributes(cwsMetaColList);
        }
        return generateResponseBasedOnWantedElements(new ByteArrayInputStream(responseXmlTemplate.getBytes()), buildSmallTree(cwsMetaColList, CwsMetaCol::getTechNaam));
    }

    private void excludeFiltersFromConfigurationAttributes(List<CwsMetaCol> cwsMetaColList) {
        SelectionCriteria selectionCriteria = cwsConfigurationDao.selectSelectionCriteriaByConfigId(cwsConfiguration.getConfigurationId());
        if (convertStringToBoolean(selectionCriteria.getFilterMap().get(OVERLEDEN_NPE_UITSLUITEN))) {
           cwsMetaColList.removeIf(attribuut ->
                 attribuut.getTechNaam().equals("DatOverlijden") || attribuut.getTechNaam().equals("CdFictieveOverlijdensdat"));
        }
    }

    private void excludeVipsFromConfigurationAttributes(List<CwsMetaCol> cwsMetaColList) {
        String afnemerVipGerechtigd = cwsConfigurationDao.getIndVipByAfnemerCode(cwsConfiguration.getAfnemerCode());
        if (afnemerVipGerechtigd.equalsIgnoreCase("N")) {
           cwsMetaColList.removeIf(attribuut ->
                 attribuut.getTechNaam().equalsIgnoreCase("Vipstatus") || attribuut.getTechNaam().equalsIgnoreCase("CdViptype"));
        }
    }

    private String generateResponseBasedOnWantedElements(InputStream xsdInputStream, Map<String, Map> configuratieEntityMap)
            throws IOException, SAXException, ParserConfigurationException {
        Document xsdDocument = getXmlAsDocument(xsdInputStream);
        Match documentMatch = $(xsdDocument);
        Match responseNode = documentMatch.xpath("//*[local-name()='Body']/*[local-name()='" + getResponseBodyRootElementName() + "']");
        Map responseEntityMap = configuratieEntityMap.get(getResponseBodyRootElementName());
        filterMatchingChildren(responseNode, responseEntityMap);
        removeUnderscoreFromTagsIfAnyFound(responseNode, xsdDocument);
        removeEmptyTags(responseNode);
        return getDocumentFromString(documentMatch);
    }

    public String generateFunctioneleFoutResponseFileName() {
        return generateXmlNameForFile(FUNC_FOUT_RESPONSE_FILE_NAME);
    }

    public String generateFunctioneleFoutResponseContent() throws IOException {
        String fullXmlLocation = getFullExampleLocation(FUNC_FOUT_RESPONSE_FILE_NAME);

        InputStream xmlAsStream = BaseProductSpecContentGeneratorService.class.getResourceAsStream(fullXmlLocation);
        String responseXmlTemplate = IOUtils.toString(xmlAsStream, StandardCharsets.UTF_8.name());
        final String berichtVersie = cwsConfiguration.getBerichtVersie();

        return responseXmlTemplate
                .replace("${HEADER}", responseHeader)
                .replace("${VERSION}", berichtVersie)
                .replace("${MAJOR_VERSION}", berichtVersie.substring(0, 2))
                .replace("${MINOR_VERSION}", berichtVersie.substring(2));
    }

    public String generateTechnischeFoutResponseFileName() {
        return generateXmlNameForFile(TECH_FOUT_RESPONSE_FILE_NAME);
    }

    public InputStream generateTechnischeFoutResponseContent() {
        String fullXmlLocation = getFullExampleLocation(TECH_FOUT_RESPONSE_FILE_NAME);
        return BaseProductSpecContentGeneratorService.class.getResourceAsStream(fullXmlLocation);
    }

    protected String generateXmlNameForFile(String exampleFileName) {
        String prefix = "_";
        String xmlNameForFile = prefix + plainProductSpecFileName + ".xml";
        return exampleFileName.replace(".xml", xmlNameForFile);
    }

    private String getFullExampleLocation(String exampleFileName) {
        return METADATA_BASE_FOLDER + getExampleXmlFolderName() + cwsConfiguration.getBerichtVersie() + "/" + exampleFileName;
    }

    private SelectionCriteria findSelectionCriteria() {
        return cwsConfigurationDao.selectSelectionCriteriaByConfigId(cwsConfiguration.getConfigurationId());
    }

    private String findUgcId(String afnemercode) {
        return cwsConfigurationDao.getUgcIdByAfnemerCode(afnemercode);
    }

    private String mapConfiguratieStatusCodeToDescription(String code) {
        return ConfigurationStatus.valueOf(code).getStatusOmschrijving();
    }

    private String mapProductCodeToOmschrijving(String productCode) {
        String result = "Productspecificatie";
        if (CWSLA_LEV_CODE.equals(productCode)) {
            result += " webservice loonaangiftegegevens";
        } else if (CWSNP_LEV_CODE.equals(productCode)){
            result += " webservice Natuurlijke Persoonsgegevens";
        } else if (CWSHR_LEV_CODE.equals(productCode)){
            result += " webservice Handelsregistergegevens";
        } else if (CWSWG_LEV_CODE.equals(productCode)){
           result += " webservice Werkgever gegevens";
        } else if (CWSIHP_LEV_CODE.equals(productCode)){
           result += " webservice Inhoudingsplichtige gegevens";
        } else {
            result += " " + productCode;
        }
        return result;
    }

    private Map<String, Map> buildSmallTree(List<CwsMetaCol> cwsMetaColList, Function<CwsMetaCol, String> collectTreeNameFunction) {
        Map<String, Map<String, Map>> childHolderMap = new LinkedHashMap<>();
        Map<String, Map> rootMap = new LinkedHashMap<>();
       cwsMetaColList.forEach(attribute -> childHolderMap.put(String.valueOf(attribute.getMetaColId()), new LinkedHashMap<>()));
       cwsMetaColList.forEach(attribute -> {
            Map<String, Map> childrenHolderObject = childHolderMap.get(String.valueOf(attribute.getMetaColId()));
            // Review comment: Met Function (vergelijkbaar als stream.map) kan je codes leesbaarder maken.
            String naam = collectTreeNameFunction.apply(attribute);
            if (attribute.getParentId() == 0) {
                rootMap.put(naam, childrenHolderObject);
            } else {
                Map<String, Map> parentObject = childHolderMap.get(String.valueOf(attribute.getParentId()));
                if(isAdreshoudingElement(naam)){
                    naam += "_" + getCleanFunctionalNameLowerCased(attribute.getFuncNaam());
                }
                parentObject.put(naam, childrenHolderObject);
            }
        });
        return rootMap;
    }

    private Document getXmlAsDocument(InputStream xsdInputStream) throws ParserConfigurationException, SAXException, IOException {
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        return dBuilder.parse(xsdInputStream);
    }

    private void filterMatchingChildren(Match node, Map entityMap) {
        // For every children of entityMap, remove mismatched nodes;
        node.xpath("./*").each(ctx -> {

            Match childMatch = $(ctx);
            String childName = childMatch.tag();
            if (!entityMap.containsKey(childName)) {
                childMatch.remove();
            } else if (!((Map) entityMap.get(childName)).isEmpty()) {
                Map child = (Map) entityMap.get(childName);
                filterMatchingChildren(childMatch, child);
            }
        });
    }

    private void removeUnderscoreFromTagsIfAnyFound(Match documentMatch, Document xsdDocument) {
        documentMatch.xpath("./*").each().forEach(matched -> {
            matched.get().forEach(element -> {
                String tagName = element.getTagName();
                if (tagName.contains("_")) {
                    tagName = tagName.substring(0, tagName.indexOf("_"));
                    xsdDocument.renameNode(element, "", tagName);
                }

                if (element.hasChildNodes()) {
                    Match childMatch = $(element);
                    removeUnderscoreFromTagsIfAnyFound(childMatch, xsdDocument);
                }
            });
        });
    }

    private void removeEmptyTags(Match node) {
        node.xpath("./*").each(ctx -> {
            Element element = ctx.element();

            if(element.hasChildNodes()){
                Match childMatch = $(element);
                removeEmptyTags(childMatch);
            }

            StringBuilder childText = new StringBuilder();
            for(int i = 0; i < element.getChildNodes().getLength(); i++){
                Node childNode = element.getChildNodes().item(i);
                if(childNode.getTextContent() != null) {
                    childText.append(childNode.getTextContent().replaceAll("\n", "").replaceAll("\\s", ""));
                }
            }

            if(StringUtils.isBlank(childText.toString())) {
                Match childMatch = $(element);
                childMatch.remove();
            }
        });
    }

    private String getDocumentFromString(Match documentMatch) {
        return Arrays.stream(documentMatch.toString().split("\n"))
                .filter(StringUtils::isNotBlank)
                .collect(joining("\n"));
    }

    private boolean isAdreshoudingElement(String attributeName){
        return StringUtils.isNotBlank(attributeName) && attributeName.toLowerCase().matches("adreshouding");
    }

    private Map<String, Map> getSelectedAttributesTree(long cconId) {
        List<CwsMetaCol> cwsMetaColList = cwsConfigurationDao.selectConfigurationMetaData(cconId);
        excludeVipsFromConfigurationAttributes(cwsMetaColList);
        if (CWSNP_LEV_CODE.equals(cwsConfiguration.getLeverCode())) {
            excludeFiltersFromConfigurationAttributes(cwsMetaColList);
        }
        return buildSmallTree(cwsMetaColList, CwsMetaCol::getFuncNaam);
    }

    private String transformTreeToText(Map<String, Map> smallTree, int indentLevel) {
        return smallTree.entrySet().stream()
                .map(entry -> {
                    String childText = transformTreeToText(entry.getValue(), indentLevel + 1);
                    String key = entry.getKey();
                    String indent = createIndentSpaces(indentLevel);
                    String lineText = indentLevel + QUADRUPLE_SPACES + indent + key + "\n" + childText;
                    return lineText;
                })
                .collect(joining());
    }

    private String createIndentSpaces(int indentLevel) {
        return IntStream.range(0, indentLevel).mapToObj(index -> QUADRUPLE_SPACES).collect(joining());
    }
}
