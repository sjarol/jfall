package nl.uwv.pws.cws.util;

public interface Constants {
   String PGRM_ID = "1609";
   String ENV_NAME = "PPLS";
   String INSTANCE_NAME = "PPLS_WL";

   String END_OF_TIME = "99991231";

   String TWEEE_EM = "2em";
   String TWEEENEENHALF_EM = "2.5em";
   String TWAALF_EM = "12em";
   String TWENTY_EM = "20em";

   String DS_NAME = "nl/uwv/ppls/ppls_pws_cws01";
   String CWSLA_LEV_CODE = "CWS-LA";
   String CWSNP_LEV_CODE = "CWS-NP";
   String CWSHR_LEV_CODE = "CWS-HR";
   String CWSWG_LEV_CODE = "CWS-WG";
   String CWSIHP_LEV_CODE = "CWS-IHP";

   String CONTRACTEN_CAPTION = "Contract(en)";
   String AFNEMERS_CAPTION = "Afnemer(s)";
   String ALLE_AFNEMERS_CAPTION = "Alle Afnemers";
   String ALLE_CWS_LEVERINGEN_CAPTION = "CWS Levering(en)";
   String CONFIGURATIE_DIALOG_CAPTION = "CWS Configuratie(s)";

   String COMPONENT_ID_OVERZICHT_CWS_CONFIGURATIES_TAB_ID = "overzicht-cws-configuraties-tab";
   String COMPONENT_ID_OVERZICHT_CWS_CONFIGURATIES_TAB_SUBTAB_CWSLA_ID = "overzicht-cws-configuraties-tab-subtab-cwsla";
   String COMPONENT_ID_OVERZICHT_CWS_CONFIGURATIES_TAB_SUBTAB_CWSNP_ID = "overzicht-cws-configuraties-tab-subtab-cwsnp";
   String COMPONENT_ID_OVERZICHT_CWS_CONFIGURATIES_TAB_SUBTAB_CWSHR_ID = "overzicht-cws-configuraties-tab-subtab-cwshr";
   String COMPONENT_ID_OVERZICHT_CWS_CONFIGURATIES_TAB_SUBTAB_CWSWG_ID = "overzicht-cws-configuraties-tab-subtab-cwswg";
   String COMPONENT_ID_OVERZICHT_CWS_CONFIGURATIES_TAB_SUBTAB_CWSIHP_ID = "overzicht-cws-configuraties-tab-subtab-cwsihp";

   String COMPONENT_ID_ZOEKEN_BUTTON = "zoeken-button";
   String COMPONENT_ID_ZOEKEN_CWS_LEVERINGEN_BUTTON = "zoeken-cws-leveringen-button";
   String COMPONENT_ID_ZOEKEN_CWS_AFNEMERS_BUTTON = "zoeken-cws-afnemers-button";
   String COMPONENT_ID_TOONCONFIGURATIE_BUTTON = "toon-configuraties-button";
   String COMPONENT_ID_EXPORTCONFIGURATIE_BUTTON = "export-configuraties-button";

   String COMPONENT_ID_OVERZICHT_CWS_CONFIGURATIE_LAYOUT = "overzicht-cws-configuratie-layout";
   String COMPONENT_ID_OVERZICHT_CWS_CONFIGURATIE_SEARCH_RESULT_LABEL_GRID = "overzicht-cws-configuratie-search-result-label-grid";
   String COMPONENT_ID_OVERZICHT_CWS_CONFIGURATIE_SEARCH_RESULT = "overzicht-cws-configuratie-search-result";
   String COMPONENT_ID_OVERZICHT_CWS_CONFIGURATIE_EDITOR_LAYOUT = "overzicht-cws-configuratie-editor-layout";
   String COMPONENT_ID_IMPORT_PRODUCT_SPEC_LAYOUT = "import-product-specification-layout";

   String COMPONENT_ID_AFNEMERCODE_TEXT_FIELD = "afnemercode-text-field";
   String COMPONENT_ID_AFNEMERNAAM_TEXT_FIELD = "afnemernaam-text-field";
   String COMPONENT_ID_CONTRACTID_TEXT_FIELD = "contractid-text-field";
   String COMPONENT_ID_CONTRACTBEGINDATUM_TEXT_FIELD = "contractbegindatum-text-field";
   String COMPONENT_ID_CONFIGURATIEVERSIE_TEXT_FIELD = "configversie-text-field";
   String COMPONENT_ID_CONFIGURATIENAAM_TEXT_FIELD = "configuratienaam-text-field";
   String COMPONENT_ID_CONFIGURATIEBEGINDATUM_TEXT_FIELD = "configuratiebegindatum-text-field";
   String COMPONENT_ID_CONFIGURATIEEINDDATUM_TEXT_FIELD = "configuratieeinddatum-text-field";
   String COMPONENT_ID_CONFIGURATIESTATUS_TEXT_FIELD = "configuratiestatus-text-field";
   String COMPONENT_ID_BERICHTVERSIE_TEXT_FIELD = "berichtversie-text-field";
   String COMPONENT_ID_UGCID_TEXT_FIELD = "ugc-id-text-field";

   String COMPONENT_ID_CODESOORTIKVS_TEXT_FIELD = "codesoortikvs-text-field";
   String COMPONENT_ID_MAXLEVERPERIODE_TEXT_FIELD = "maxleverperiode-text-field";
   String COMPONENT_ID_NIHILLOONSVUITSLUITEN_CHECKBOX = "nihilloonsvuitsluiten-check-box";
   String COMPONENT_ID_NIHILLOONLBPHUITSLUITEN_CHECKBOX = "nihilloonlbphuitsluiten-check-box";
   String COMPONENT_ID_LEVENDPERSOONUITSLUITEN_CHECKBOX = "levendpersoonuitsluiten-check-box";
   String COMPONENT_ID_OVERLEDENPERSOONUITSLUITEN_CHECKBOX = "overledenpersoonuitsluiten-check-box";
   String COMPONENT_ID_BEEINDIGDADRESUITSLUITEN_CHECKBOX = "beeindigdadresuitsluiten-check-box";

   String AFNEMERS_EN_LEVERINGEN_TAB_ID = "afnemers-en-cws-leveringen-tab";
   String ADD_BUTTON_ID = AFNEMERS_EN_LEVERINGEN_TAB_ID + "-toevoegen-button";
   String EDIT_BUTTON_ID = AFNEMERS_EN_LEVERINGEN_TAB_ID + "-wijzigen-button";
   String DELETE_BUTTON_ID = AFNEMERS_EN_LEVERINGEN_TAB_ID + "-verwijderen-button";
   String VIEW_BUTTON_ID = AFNEMERS_EN_LEVERINGEN_TAB_ID + "-raadplegen-button";
   String FINALIZE_CONFIGURATION_BUTTON_ID = AFNEMERS_EN_LEVERINGEN_TAB_ID + "-configuratie-definitief-button";
   String GENERATE_PRODUCTSPEC_BUTTON_ID = AFNEMERS_EN_LEVERINGEN_TAB_ID + "-genereer-productspecificatie-button";
   String EXPORT_BUTTON_ID = AFNEMERS_EN_LEVERINGEN_TAB_ID + "-export-button";
   String IMPORT_BUTTON_ID = AFNEMERS_EN_LEVERINGEN_TAB_ID + "-import-button";
   String CANCEL_BUTTON_ID = AFNEMERS_EN_LEVERINGEN_TAB_ID + "-cancel-button";
   String UPLOAD_BUTTON_ID = AFNEMERS_EN_LEVERINGEN_TAB_ID + "upload-button";

   String CWS_REQUEST_HEADER_EXTERN =
         "    <soap:Header xmlns:wsa=\"http://www.w3.org/2005/08/addressing\">\n" +
               "        <wsa:Action>http://services.uwv.nl/RaadplegenGegevensbron/request</wsa:Action>\n" +
               "        <wsa:ReplyTo>\n" +
               "            <wsa:Address>http://www.w3.org/2005/08/addressing/anonymous</wsa:Address>\n" +
               "        </wsa:ReplyTo>\n" +
               "        <wsa:From>\n" +
               "            <wsa:Address>http://www.w3.org/2005/08/addressing/anonymous</wsa:Address>\n" +
               "        </wsa:From>\n" +
               "        <wsa:MessageID>uuid:2fdec59d-99a5-43fa-9d22-87f256f4c816</wsa:MessageID>\n" +
               "        <wsa:To>HIER KOMT DE BIJHORENDE URL</wsa:To>\n" +
               "    </soap:Header>";

   String CWS_LA_REQUEST_HEADER_EXTERN = CWS_REQUEST_HEADER_EXTERN.replace("Gegevensbron", "Loonaangiftegegevens");
   String CWS_NP_REQUEST_HEADER_EXTERN = CWS_REQUEST_HEADER_EXTERN.replace("Gegevensbron", "Persoonsgegevens");
   String CWS_HR_REQUEST_HEADER_EXTERN = CWS_REQUEST_HEADER_EXTERN.replace("Gegevensbron", "Handelsregistergegevens");
   String CWS_WG_REQUEST_HEADER_EXTERN = CWS_REQUEST_HEADER_EXTERN.replace("Gegevensbron", "Werkgevergegevens");
   String CWS_IHP_REQUEST_HEADER_EXTERN = CWS_REQUEST_HEADER_EXTERN.replace("Gegevensbron", "Inhoudingsplichtigegegevens");

   String CWS_RESPONSE_HEADER_EXTERN =
         "    <soap:Header>\n" +
               "        <wsa:Action wsu:Id=\"id-0-c70a8d51fae999c5b88c3632763e44b4\" xmlns:wsa=\"http://www.w3.org/2005/08/addressing\" xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\">http://services.uwv.nl/RaadplegenGegevensbron/response</wsa:Action>\n" +
               "        <wsa:MessageID wsu:Id=\"id-1-dc382891703d543d79306b9c9f184d77\" xmlns:wsa=\"http://www.w3.org/2005/08/addressing\" xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\">MessageId-ae692b7a-824c-10fa-c6e8-0eb613c51a26</wsa:MessageID>\n" +
               "        <wsa:To wsu:Id=\"id-2-d3dc0cc40f3a33a781ffc15be25686fa\" xmlns:wsa=\"http://www.w3.org/2005/08/addressing\" xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\">http://www.w3.org/2005/08/addressing/anonymous</wsa:To>\n" +
               "        <wsa:From wsu:Id=\"id-3-0e65e171a51290c0e656aae3e1fb5efa\" xmlns:wsa=\"http://www.w3.org/2005/08/addressing\" xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\">\n" +
               "            <wsa:Address>HIER KOMT DE BIJHORENDE URL</wsa:Address>\n" +
               "        </wsa:From>\n" +
               "        <wsa:RelatesTo wsa:RelationshipType=\"http://www.w3.org/2005/08/addressing/reply\" wsu:Id=\"id-4-f96032e2c46b938a17d1a2c8efa68a46\" xmlns:wsa=\"http://www.w3.org/2005/08/addressing\" xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\">uuid:2fdec59d-99a5-43fa-9d22-87f256f4c816</wsa:RelatesTo>\n" +
               "    </soap:Header>";

   String CWS_LA_RESPONSE_HEADER_EXTERN = CWS_RESPONSE_HEADER_EXTERN.replace("Gegevensbron", "Loonaangiftegegevens");
   String CWS_NP_RESPONSE_HEADER_EXTERN = CWS_RESPONSE_HEADER_EXTERN.replace("Gegevensbron", "Persoonsgegevens");
   String CWS_HR_RESPONSE_HEADER_EXTERN = CWS_RESPONSE_HEADER_EXTERN.replace("Gegevensbron", "Handelsregistergegevens");
   String CWS_WG_RESPONSE_HEADER_EXTERN = CWS_RESPONSE_HEADER_EXTERN.replace("Gegevensbron", "Werkgevergegevens");
   String CWS_IHP_RESPONSE_HEADER_EXTERN = CWS_RESPONSE_HEADER_EXTERN.replace("Gegevensbron", "Inhoudingsplichtigegegevens");

   String CWS_REQUEST_HEADER_INTERN =
         "    <soap:Header\n" +
               "        xmlns:head=\"http://schemas.uwv.nl/UwvML/Header-v0202\">\n" +
               "        <head:UwvMLHeader>\n" +
               "            <RouteInformatie>\n" +
               "                <Bron>\n" +
               "                    <ApplicatieNaam>AFNEMER</ApplicatieNaam>\n" +
               "                    <DatTijdVersturenBericht>2019-09-17T15:03:54.060+02:00</DatTijdVersturenBericht>\n" +
               "                </Bron>\n" +
               "                <Bestemming>\n" +
               "                    <ApplicatieNaam>POLIS LEVEREN</ApplicatieNaam>\n" +
               "                </Bestemming>\n" +
               "                <GegevensUitwisselingsnr>uuid:1a0b0ef0-11dc-11dd-bbc3-00096bab0d1c</GegevensUitwisselingsnr>\n" +
               "            </RouteInformatie>\n" +
               "            <BerichtIdentificatie>\n" +
               "                <BerichtReferentienr>f5b89ad5-6c52-48b0-a825-a109629e28fc</BerichtReferentienr>\n" +
               "                <BerichtType>\n" +
               "                    <BerichtNaam>requestBericht</BerichtNaam>\n" +
               "                    <VersieMajor>01</VersieMajor>\n" +
               "                    <VersieMinor>00</VersieMinor>\n" +
               "                    <Buildnr>01</Buildnr>\n" +
               "                    <CommunicatieType>Inkijk</CommunicatieType>\n" +
               "                    <CommunicatieElement>Request</CommunicatieElement>\n" +
               "                </BerichtType>\n" +
               "                <DatTijdAanmaakBericht>2019-09-17T15:03:54.060+02:00</DatTijdAanmaakBericht>\n" +
               "                <IndTestbericht>2</IndTestbericht>\n" +
               "            </BerichtIdentificatie>\n" +
               "        </head:UwvMLHeader>\n" +
               "    </soap:Header>";

   String CWS_LA_REQUEST_HEADER_INTERN = CWS_REQUEST_HEADER_INTERN;
   String CWS_NP_REQUEST_HEADER_INTERN = CWS_REQUEST_HEADER_INTERN;
   String CWS_HR_REQUEST_HEADER_INTERN = CWS_REQUEST_HEADER_INTERN;
   String CWS_WG_REQUEST_HEADER_INTERN = CWS_REQUEST_HEADER_INTERN;
   String CWS_IHP_REQUEST_HEADER_INTERN = CWS_REQUEST_HEADER_INTERN;

   String CWS_RESPONSE_HEADER_INTERN =
         "    <soap:Header>\n" +
               "        <ns4:UwvMLHeader\n" +
               "                xmlns:ns5=\"http://schemas.uwv.nl/UwvML/ApplicatieFout-v0200\"\n" +
               "                xmlns:ns4=\"http://schemas.uwv.nl/UwvML/Header-v0202\"\n" +
               "                xmlns:ns3=\"http://schemas.uwv.nl/UwvML/Berichten/CwsGegevensbronResponse-v${VERSION}\"\n" +
               "                xmlns:ns2=\"http://schemas.uwv.nl/UwvML/Berichten/CwsGegevensbronRequest-v${VERSION}\">\n" +
               "            <RouteInformatie>\n" +
               "                <Bron>\n" +
               "                    <ApplicatieNaam>POLIS LEVEREN</ApplicatieNaam>\n" +
               "                    <DatTijdVersturenBericht>2019-09-17T15:04:54.060+02:00</DatTijdVersturenBericht>\n" +
               "                </Bron>\n" +
               "                <Bestemming>\n" +
               "                    <ApplicatieNaam>POLIS LEVEREN</ApplicatieNaam>\n" +
               "                </Bestemming>\n" +
               "                <GegevensUitwisselingsnr>uuid:1a0b0ef0-11dc-11dd-bbc3-00096bab0d1c</GegevensUitwisselingsnr>\n" +
               "            </RouteInformatie>\n" +
               "            <BerichtIdentificatie>\n" +
               "                <BerichtReferentienr>f5b89ad5-6c52-48b0-a825-a109629e28fc</BerichtReferentienr>\n" +
               "                <BerichtType>\n" +
               "                    <BerichtNaam>CwsGegevensbronResponse</BerichtNaam>\n" +
               "                    <VersieMajor>${MAJOR_VERSION}</VersieMajor>\n" +
               "                    <VersieMinor>${MINOR_VERSION}</VersieMinor>\n" +
               "                    <Buildnr>01</Buildnr>\n" +
               "                    <CommunicatieType>Inkijk</CommunicatieType>\n" +
               "                    <CommunicatieElement>Response</CommunicatieElement>\n" +
               "                </BerichtType>\n" +
               "                <DatTijdAanmaakBericht>2019-09-17T15:04:54.060+02:00</DatTijdAanmaakBericht>\n" +
               "                <RequestBerichtReferentienr>f5b89ad5-6c52-48b0-a825-a109629e28fc</RequestBerichtReferentienr>\n" +
               "                <IndTestbericht>2</IndTestbericht>\n" +
               "            </BerichtIdentificatie>\n" +
               "        </ns4:UwvMLHeader>\n" +
               "    </soap:Header>";

   String CWS_LA_RESPONSE_HEADER_INTERN = CWS_RESPONSE_HEADER_INTERN.replace("Gegevensbron", "Loonaangifte");
   String CWS_NP_RESPONSE_HEADER_INTERN = CWS_RESPONSE_HEADER_INTERN.replace("Gegevensbron", "NatuurlijkPersoon");
   String CWS_HR_RESPONSE_HEADER_INTERN = CWS_RESPONSE_HEADER_INTERN.replace("Gegevensbron", "Handelsregister");
   String CWS_WG_RESPONSE_HEADER_INTERN = CWS_RESPONSE_HEADER_INTERN.replace("Gegevensbron", "Werkgever");
   String CWS_IHP_RESPONSE_HEADER_INTERN = CWS_RESPONSE_HEADER_INTERN.replace("Gegevensbron", "Inhoudingsplichtige");

}
