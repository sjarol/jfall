package nl.uwv.pws.cws.views.beheer.tabs.layout.cwsnp;

import com.vaadin.flow.component.checkbox.Checkbox;
import com.vaadin.flow.component.formlayout.FormLayout;
import lombok.Getter;
import lombok.Setter;
import com.vaadin.flow.component.html.Label;


import nl.uwv.pws.cws.exception.FormValidationException;
import nl.uwv.pws.cws.model.CwsNpFilterType;
import nl.uwv.pws.cws.model.SelectionCriteria;
import nl.uwv.pws.cws.util.CwsUIUtils;
import nl.uwv.pws.cws.views.beheer.tabs.layout.BaseSelectionCriteriaFormLayout;
import nl.uwv.pws.cws.views.beheer.SelectionCriteriaFactoryUtil;
import nl.uwv.pws.cws.views.beheer.configuratie.ConfigurationAction;

import static nl.uwv.pws.cws.util.Constants.COMPONENT_ID_LEVENDPERSOONUITSLUITEN_CHECKBOX;
import static nl.uwv.pws.cws.util.Constants.COMPONENT_ID_OVERLEDENPERSOONUITSLUITEN_CHECKBOX;
import static nl.uwv.pws.cws.util.CwsUIUtils.createCheckbox;
import static nl.uwv.pws.cws.util.CwsUIUtils.createHeaderLabel;
import static nl.uwv.pws.cws.util.CwsUtils.convertStringToBoolean;

@Getter
@Setter
public class CwsNpSelectionCriteriaLayout extends BaseSelectionCriteriaFormLayout {

   private static final boolean DISABLED = false;
   private static final boolean ENABLED = true;
   private static final boolean OPTIONAL_FIELD = false;

   private Checkbox checkboxLevendPersoonUitsluiten;
   private Checkbox checkboxOverledenPersoonUitsluiten;

   private boolean originalLevendPersoonUitsluiten;
   private boolean originalOverledenPersoonUitsluiten;

   @Override
   public FormLayout createSelectionCriteriaLayout(SelectionCriteria selectionCriteria, final ConfigurationAction configurationAction) {
      FormLayout formLayout = new FormLayout();
      Label label = createHeaderLabel("Selectiecriteria CWS");
      formLayout.add(label);

      boolean enabled = configurationAction.equals(ConfigurationAction.VIEW) ? DISABLED : ENABLED;
      if (selectionCriteria != null) {
         this.originalLevendPersoonUitsluiten = convertStringToBoolean(selectionCriteria.getFilterMap().get(CwsNpFilterType.LEVEND_NPE_UITSLUITEN));
         this.originalOverledenPersoonUitsluiten = convertStringToBoolean(selectionCriteria.getFilterMap().get(CwsNpFilterType.OVERLEDEN_NPE_UITSLUITEN));
         createSelectionCriteriaComponents(enabled);

      } else {
         createSelectionCriteriaComponents(enabled);
      }
      addFormItemsCwsNp(formLayout);

      return formLayout;
   }

   private void createSelectionCriteriaComponents(final boolean enabled) {
      checkboxLevendPersoonUitsluiten = createCheckbox(COMPONENT_ID_LEVENDPERSOONUITSLUITEN_CHECKBOX, this.originalLevendPersoonUitsluiten, enabled);
      checkboxOverledenPersoonUitsluiten = createCheckbox(COMPONENT_ID_OVERLEDENPERSOONUITSLUITEN_CHECKBOX, this.originalOverledenPersoonUitsluiten, enabled);
   }

   private void addFormItemsCwsNp(FormLayout formLayout) {
      CwsUIUtils.addFormItem(formLayout, checkboxLevendPersoonUitsluiten, "Levend persoon uitsluiten: \u00A0", OPTIONAL_FIELD);
      CwsUIUtils.addFormItem(formLayout, checkboxOverledenPersoonUitsluiten, "Overleden persoon uitsluiten: \u00A0", OPTIONAL_FIELD);
   }

   @Override
   public boolean originalValuesHaveNotChanged() {
      boolean levendPersoonUitsluiten = checkboxLevendPersoonUitsluiten.getValue();
      boolean overledenPersoonUitsluiten = checkboxOverledenPersoonUitsluiten.getValue();

      return (originalLevendPersoonUitsluiten == levendPersoonUitsluiten
            && originalOverledenPersoonUitsluiten == overledenPersoonUitsluiten);
   }

   @Override
   public SelectionCriteria determineSelectionCriteria() {
      boolean levendPersoonUitsluiten = checkboxLevendPersoonUitsluiten.getValue();
      boolean overledenPersoonUitsluiten = checkboxOverledenPersoonUitsluiten.getValue();

      return SelectionCriteriaFactoryUtil.createCwsNpSelectieCriteria(levendPersoonUitsluiten, overledenPersoonUitsluiten);
   }

   @Override
   public void validate() throws FormValidationException {
      boolean levendPersoonUitsluiten = checkboxLevendPersoonUitsluiten.getValue();
      boolean overledenPersoonUitsluiten = checkboxOverledenPersoonUitsluiten.getValue();
      if (levendPersoonUitsluiten && overledenPersoonUitsluiten) {
         throw new FormValidationException("Levend óf Overleden Persoon uitsluiten aanvinken");
      }
   }
}
