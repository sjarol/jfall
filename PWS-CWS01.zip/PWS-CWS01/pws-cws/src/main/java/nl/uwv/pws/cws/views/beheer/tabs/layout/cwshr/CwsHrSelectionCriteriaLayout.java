package nl.uwv.pws.cws.views.beheer.tabs.layout.cwshr;

import com.vaadin.flow.component.checkbox.Checkbox;
import com.vaadin.flow.component.formlayout.FormLayout;
import com.vaadin.flow.component.html.Label;
import lombok.Getter;
import lombok.Setter;
import nl.uwv.pws.cws.model.CwsHrFilterType;
import nl.uwv.pws.cws.model.SelectionCriteria;
import nl.uwv.pws.cws.util.CwsUIUtils;
import nl.uwv.pws.cws.views.beheer.tabs.layout.BaseSelectionCriteriaFormLayout;
import nl.uwv.pws.cws.views.beheer.SelectionCriteriaFactoryUtil;
import nl.uwv.pws.cws.views.beheer.configuratie.ConfigurationAction;

import static nl.uwv.pws.cws.util.Constants.COMPONENT_ID_BEEINDIGDADRESUITSLUITEN_CHECKBOX;
import static nl.uwv.pws.cws.util.CwsUIUtils.createCheckbox;
import static nl.uwv.pws.cws.util.CwsUIUtils.createHeaderLabel;
import static nl.uwv.pws.cws.util.CwsUtils.convertStringToBoolean;

@Getter
@Setter
public class CwsHrSelectionCriteriaLayout extends BaseSelectionCriteriaFormLayout {

   private static final boolean DISABLED = false;
   private static final boolean ENABLED = true;
   private static final boolean OPTIONAL_FIELD = false;

   private Checkbox checkboxBeeindigdAdresUitsluiten;

   private boolean originalBeeindigdAdresUitsluiten;

   @Override
   public FormLayout createSelectionCriteriaLayout(SelectionCriteria selectionCriteria, final ConfigurationAction configurationAction) {
      FormLayout formLayout = new FormLayout();
      Label label = createHeaderLabel("Selectiecriteria CWS");
      formLayout.add(label);

      boolean enabled = configurationAction.equals(ConfigurationAction.VIEW) ? DISABLED : ENABLED;
      if (selectionCriteria != null) {
         this.originalBeeindigdAdresUitsluiten = convertStringToBoolean(selectionCriteria.getFilterMap().get(CwsHrFilterType.BEEINDIGD_ADRES_UITSLUITEN));
         createSelectionCriteriaComponents(enabled);
      } else {
         createSelectionCriteriaComponents( enabled);
      }
      addFormItemsCwsHr(formLayout);
      return formLayout;
   }

   private void createSelectionCriteriaComponents(boolean enabled) {
      checkboxBeeindigdAdresUitsluiten = createCheckbox(COMPONENT_ID_BEEINDIGDADRESUITSLUITEN_CHECKBOX, this.originalBeeindigdAdresUitsluiten, enabled);
   }

   private void addFormItemsCwsHr(FormLayout formLayout) {
      CwsUIUtils.addFormItem(formLayout, checkboxBeeindigdAdresUitsluiten, "Beëindigd adres uitsluiten: \u00A0", OPTIONAL_FIELD);
   }

   @Override
   public SelectionCriteria determineSelectionCriteria() {
      boolean beeindigdAdresUitsluiten = checkboxBeeindigdAdresUitsluiten.getValue();
      return SelectionCriteriaFactoryUtil.createCwsHrSelectieCriteria(beeindigdAdresUitsluiten);
   }

   @Override
   public void validate() {}

   @Override
   public boolean originalValuesHaveNotChanged() {
      boolean beeindigdAdresUitsluiten = checkboxBeeindigdAdresUitsluiten.getValue();
      return (originalBeeindigdAdresUitsluiten == beeindigdAdresUitsluiten);
   }
}
