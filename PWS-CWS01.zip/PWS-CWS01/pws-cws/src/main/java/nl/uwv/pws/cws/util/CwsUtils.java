package nl.uwv.pws.cws.util;

import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.ResolverStyle;
import java.util.Date;

public final class CwsUtils {

   private CwsUtils() {
      throw new IllegalStateException("Utility class");
   }

   public static final DateTimeFormatter DATE_FORMATTER_DDMMYYYY = DateTimeFormatter.ofPattern("dd-MM-yyyy").withResolverStyle(ResolverStyle.STRICT);
   public static final DateTimeFormatter DATE_FORMATTER_YYYYMMDD = DateTimeFormatter.ofPattern("yyyyMMdd").withResolverStyle(ResolverStyle.STRICT);
   public static final DateTimeFormatter DATE_FORMATTER_YYYYMMDD_HHMMSS = DateTimeFormatter.ofPattern("yyyyMMddHHmmss").withResolverStyle(ResolverStyle.STRICT);


   public static BigDecimal getBigDecimal(final Object bd) {
      if (bd instanceof BigDecimal) {
         return (BigDecimal) bd;
      }
      return null;
   }

   public static LocalDate getDateAsLocalDate(final Object date) {
      if (date instanceof Date) {
         return Instant.ofEpochMilli(((Date) date).getTime()).atZone(ZoneId.systemDefault()).toLocalDate();
      }
      return null;
   }

   public static String getLocalDateAsString(final LocalDate date) {
      if (date == null) {
         return null;
      }
      return date.format(DATE_FORMATTER_DDMMYYYY);
   }

   public static String getLocalDateTimeAsString(final LocalDateTime date) {
      if (date == null) {
         return null;
      }
      return date.format(DATE_FORMATTER_DDMMYYYY);
   }

   public static LocalDate getLongAsLocalDate(final Long value) {
      if (value == null) {
         return null;
      }
      return LocalDate.parse(value.toString(), DateTimeFormatter.BASIC_ISO_DATE);
   }

   public static Long getLocalDateAsLong(final LocalDate date) {
      if (date == null) {
         return null;
      }
      return Long.parseLong(date.format(DATE_FORMATTER_YYYYMMDD));
   }

   public static String getFormattedCurrentTimestamp() {
      return LocalDateTime.now().format(DATE_FORMATTER_YYYYMMDD_HHMMSS);
   }

   public static String convertBooleanToString(boolean value){
      return value ? "J" : "N";
   }

   public static boolean convertStringToBoolean(String value){
      return value.equalsIgnoreCase("J");
   }

   public static String createPdfFileName(final String kenmerk, final String configurationName, final String configurationVersion, final String afnemerCode) {
      final String kenmerkToUse = StringUtils.isNotBlank(kenmerk) ? kenmerk.concat("_") : "";
      final String productSpecFileName = createPlainProductSpecFileName(configurationName, configurationVersion, afnemerCode);
      return kenmerkToUse +
            "Productspec_" +
            productSpecFileName +
            ".pdf";
   }

   public static String createPlainProductSpecFileName(final String configurationName, final String configurationVersion, final String afnemerCode) {
      StringBuilder nameBuilder = new StringBuilder();
      nameBuilder.append(afnemerCode)
            .append("_");
      if(StringUtils.isNotBlank(configurationName)){
         nameBuilder.append(configurationName)
               .append("_");
      }
      nameBuilder.append(configurationVersion);

      return replaceNotAllowedChars(nameBuilder.toString());
   }

   public static String createExportFileName(final String configurationName, final String configurationVersie, final String afnemerCode) {
      StringBuilder nameBuilder = new StringBuilder();
      String formattedDate = getFormattedCurrentTimestamp();
      String name = nameBuilder.append("ExportCWS_")
            .append(afnemerCode)
            .append("_")
            .append(configurationName)
            .append("_")
            .append(configurationVersie)
            .append("_")
            .append(formattedDate)
            .append(".json")
            .toString();
      return replaceNotAllowedChars(name);
   }

   public static String createExportOverviewFileName(){
      String formattedDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy_MM_dd_HH_mm_ss"));
      return "Export Overzicht_"+ formattedDate + ".xlsx";
   }

   public static String replaceNotAllowedChars(String originalName) {
      return originalName
            .replaceAll("[\\\\/:*?\"<>|]", "-");
   }
}
