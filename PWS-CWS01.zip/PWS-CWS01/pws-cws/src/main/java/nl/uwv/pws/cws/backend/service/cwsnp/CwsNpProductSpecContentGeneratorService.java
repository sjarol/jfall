package nl.uwv.pws.cws.backend.service.cwsnp;

import nl.uwv.pws.cws.backend.service.BaseProductSpecContentGeneratorService;
import nl.uwv.pws.cws.model.BaseCwsFilterType;
import nl.uwv.pws.cws.model.CwsConfiguration;
import nl.uwv.pws.cws.model.CwsNpFilterType;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import static nl.uwv.pws.cws.util.CwsUtils.convertStringToBoolean;

public class CwsNpProductSpecContentGeneratorService extends BaseProductSpecContentGeneratorService {
    private static final String CWSNP_PDFTEMPLATE = "../templates/cwsnp-product-specificatie-template.odt";
    private static final String CWSNP_EXAMPLE_FOLDER = "cwsnp/";
    private static final String CWSNP_RESPONSE_ROOT_ELEMENT = "CwsNatuurlijkPersoonResponse";
    private static final String RESPONSE_FILE_NAME = "Response.xml";

   public CwsNpProductSpecContentGeneratorService(final CwsConfiguration cwsConfiguration, final String kenmerk,
                                                  final String requestHeader, final String responseHeader) {
      super(cwsConfiguration, kenmerk, requestHeader, responseHeader);
   }

    @Override
    protected String[] getExampleRequestFileNames() {
        return new String [] {REQUEST_FILE_NAME};
    }

    @Override
    protected String getPdfTemplateFileName() {
        return CWSNP_PDFTEMPLATE;
    }

    @Override
    protected String getExampleXmlFolderName() {
        return CWSNP_EXAMPLE_FOLDER;
    }

    @Override
    protected String getResponseBodyRootElementName() {
        return CWSNP_RESPONSE_ROOT_ELEMENT;
    }

    @Override
    public String generateComplexExampleResponseFileName() {
        return null;
    }

    @Override
    public String generateFilteredComplexExampleResponseContent() { return null; }

    @Override
    public String generateComplexExampleResponseContent() {
        return null;
    }

    @Override
    public String generateSimpleExampleResponseFileName() {
        return generateXmlNameForFile(RESPONSE_FILE_NAME);
    }

    @Override
    public String generateSimpleExampleResponseContent() throws IOException, SAXException, ParserConfigurationException {
        return generateExampleResponseContent(RESPONSE_FILE_NAME);
    }

    @Override
    public Map<String, Object> getSelectieCriteriaMapping() {
        Map<String, Object> mapping = new HashMap<>();

        Map<BaseCwsFilterType, String> filterMap = selectionCriteria.getFilterMap();
        mapping.put("condition_overledenPersoonUitsluiten", Boolean.toString(convertStringToBoolean(filterMap.get(CwsNpFilterType.OVERLEDEN_NPE_UITSLUITEN))));
        mapping.put("condition_levendPersoonUitsluiten", Boolean.toString(convertStringToBoolean(filterMap.get(CwsNpFilterType.LEVEND_NPE_UITSLUITEN))));

        return mapping;
    }
}
