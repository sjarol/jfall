package nl.uwv.pws.cws.backend.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import nl.uwv.pws.backend.dao.BackendException;
import nl.uwv.pws.cws.model.*;
import nl.uwv.pws.cws.model.specification.ConfigurationSpecification.Configuration;
import nl.uwv.pws.cws.model.specification.ConfigurationSpecification.Metadata;
import nl.uwv.pws.cws.model.specification.ExportFunctionVersion;
import nl.uwv.pws.cws.model.specification.ExportableConfigurationSpecification;
import nl.uwv.pws.cws.util.ConfigurationStatus;
import nl.uwv.pws.cws.util.Constants;
import nl.uwv.pws.cws.util.CwsUtils;
import nl.uwv.pws.cws.util.ExcelWorkbookUtils;
import nl.uwv.pws.ui.util.UIUtils;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

import static com.fasterxml.jackson.databind.SerializationFeature.INDENT_OUTPUT;

@Slf4j
public class ExportService extends BaseService {
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper().enable(INDENT_OUTPUT);

    public String generateExportConfigurationString(final CwsConfiguration cwsConfiguration) {
        SelectionCriteria selectionCriteria = cwsConfigurationDao.selectSelectionCriteriaByConfigId(cwsConfiguration.getConfigurationId());
        List<CwsMetaCol> cwsMetaColList = cwsConfigurationDao.selectConfigurationMetaData(cwsConfiguration.getConfigurationId());

        ExportableConfigurationSpecification exportableConfiguratieSpec = new ExportableConfigurationSpecification();
        exportableConfiguratieSpec.setExportFunctionVersion(ExportFunctionVersion.mostRecentVersion());

        Metadata metadata = createMetadata(cwsConfiguration);
        exportableConfiguratieSpec.setMetadata(metadata);

        Configuration configuration = createExportableConfiguration(cwsConfiguration, selectionCriteria, cwsMetaColList);
        exportableConfiguratieSpec.setConfiguratie(configuration);

        return objectAsJsonString(exportableConfiguratieSpec);
    }

    private Metadata createMetadata(CwsConfiguration cwsConfiguration) {
        Metadata metadata = new Metadata();
        metadata.setLevCode(cwsConfiguration.getLeverCode());
        metadata.setBerichtversie(cwsConfiguration.getBerichtVersie());
        return metadata;
    }

    private Configuration createExportableConfiguration(CwsConfiguration cwsConfiguration, SelectionCriteria selectionCriteria, List<CwsMetaCol> cwsMetaColList) {
       Configuration exportableConfiguratie = new Configuration();
        exportableConfiguratie.setContractId(cwsConfiguration.getContractId());
        exportableConfiguratie.setContractStartDate(CwsUtils.getLocalDateAsLong(cwsConfiguration.getContractStartDate()));
        exportableConfiguratie.setNaam(cwsConfiguration.getConfigurationName());
        exportableConfiguratie.setVersion(cwsConfiguration.getConfigurationVersion());
        exportableConfiguratie.setStatus(ConfigurationStatus.valueOf(cwsConfiguration.getConfigurationStatus()));
        exportableConfiguratie.setStartDate(CwsUtils.getLocalDateAsLong(cwsConfiguration.getConfigurationStartDate()));
        final Long configurationEndDate = CwsUtils.getLocalDateAsLong(cwsConfiguration.getConfigurationEndDate());
        exportableConfiguratie.setEndDate(Optional.ofNullable(configurationEndDate).orElse(Long.parseLong(Constants.END_OF_TIME)));

        Map<BaseCwsFilterType, String> cwsLaSoortSelection = selectionCriteria.getFilterMap();
        exportableConfiguratie.setSoortSelectie(cwsLaSoortSelection);

        List<String> exportableAttributes = toExportableAttributes(cwsMetaColList);
        exportableConfiguratie.setAttributen(exportableAttributes);
        return exportableConfiguratie;
    }

    private List<String> toExportableAttributes(List<CwsMetaCol> cwsMetaColList) {
        Map<String, Map> attributesTree = buildAttributesTree(cwsMetaColList);
        List<String> exportableAttributes = new ArrayList<>();
        addChildrenChainNameToList(exportableAttributes, attributesTree, "");
        return exportableAttributes;
    }

   private void addChildrenChainNameToList(List<String> exportableAttributes, Map<String, Map> childrenMap, String parentAttributeChain) {
      childrenMap.forEach((attributeName, children) -> {
         String attributeChain = parentAttributeChain + attributeName;
         exportableAttributes.add(attributeChain);
         if (children != null && !children.isEmpty()) {
            addChildrenChainNameToList(exportableAttributes, children, attributeChain + ".");
         }
      });
   }

   private static String objectAsJsonString(Object object) {
        try {
            return OBJECT_MAPPER.writeValueAsString(object);
        } catch (JsonProcessingException e) {
            throw new BackendException("Kan export bestand niet genereren.", e);
        }
    }


    public InputStream createOverviewWorkBook(final List<OverviewGridData> items) {
       final OverviewGridData overviewGridDataHeaders = items.listIterator().next();
       final Set<String> headers = overviewGridDataHeaders.getValues().keySet();
       FileOutputStream out = null;

       try {
          XSSFWorkbook workbook = new XSSFWorkbook();
          Path tempWorkBook = Files.createTempFile(null, ".xlsx");

          // first header
          final CellStyle configurationHeaderCellStyle = ExcelWorkbookUtils.createConfigurationHeaderCellStyle(workbook);
          final XSSFSheet spreadsheet = workbook.createSheet("Configuraties");
          final int rowIndex = ExcelWorkbookUtils.createConfigurationHeader(spreadsheet, configurationHeaderCellStyle, items.size(), headers.size());

          ExcelWorkbookUtils.processResultToSheet(workbook, spreadsheet, items, rowIndex);

          out = new FileOutputStream(tempWorkBook.toFile());
          workbook.write(out);

          log.debug("Writesheet.xlsx written successfully");

          return Files.newInputStream(tempWorkBook);
       } catch (IOException e) {
          UIUtils.handleError(e);
          throw new BackendException("Fout bij het maken van Excel worksheet ", e);
       } finally {
          if (out != null) {
             try {
                out.close();
             } catch (IOException e) {
                UIUtils.handleError(e);
             }
          }
       }
    }
}
