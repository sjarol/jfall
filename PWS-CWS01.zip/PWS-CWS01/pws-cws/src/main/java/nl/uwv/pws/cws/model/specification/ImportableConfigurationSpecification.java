package nl.uwv.pws.cws.model.specification;

public class ImportableConfigurationSpecification extends ConfigurationSpecification{ }
