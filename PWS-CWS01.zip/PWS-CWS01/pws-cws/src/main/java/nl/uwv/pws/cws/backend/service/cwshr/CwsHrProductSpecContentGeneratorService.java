package nl.uwv.pws.cws.backend.service.cwshr;

import nl.uwv.pws.cws.backend.service.BaseProductSpecContentGeneratorService;
import nl.uwv.pws.cws.model.BaseCwsFilterType;
import nl.uwv.pws.cws.model.CwsConfiguration;
import nl.uwv.pws.cws.model.CwsHrFilterType;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import static nl.uwv.pws.cws.util.CwsUtils.convertStringToBoolean;

public class CwsHrProductSpecContentGeneratorService extends BaseProductSpecContentGeneratorService {
    private static final String CWSHR_PDFTEMPLATE = "../templates/cwshr-product-specificatie-template.odt";
    private static final String CWSHR_EXAMPLE_FOLDER = "cwshr/";
    private static final String CWSHR_RESPONSE_ROOT_ELEMENT = "CwsHandelsregisterResponse";
    private static final String SIMPLE_RESPONSE_FILE_NAME = "Response_simpel.xml";
    private static final String COMPLEX_RESPONSE_FILE_NAME = "Response_complex.xml";
    private static final String FILTERED_COMPLEX_RESPONSE_FILE_NAME = "Response_filtered_complex.xml";
    protected static final String REQUEST_MULTI_FILE_NAMES = "Request_persoon.xml;Request_maatschappelijkeactiviteit.xml";

    public CwsHrProductSpecContentGeneratorService(final CwsConfiguration cwsConfiguration, final String pdfKenmerk,
                                                   final String requestHeader, final String responseHeader) {
        super(cwsConfiguration, pdfKenmerk, requestHeader, responseHeader);
    }

    @Override
    protected String[] getExampleRequestFileNames() {
        return REQUEST_MULTI_FILE_NAMES.split(";");
    }

    @Override
    protected String getPdfTemplateFileName() {
        return CWSHR_PDFTEMPLATE;
    }

    @Override
    protected String getExampleXmlFolderName() {
        return CWSHR_EXAMPLE_FOLDER;
    }

    @Override
    protected String getResponseBodyRootElementName() {
        return CWSHR_RESPONSE_ROOT_ELEMENT;
    }

    @Override
    public String generateComplexExampleResponseFileName() {
        return generateXmlNameForFile(COMPLEX_RESPONSE_FILE_NAME);
    }

    @Override
    public String generateFilteredComplexExampleResponseContent() throws IOException, SAXException, ParserConfigurationException {
        return generateExampleResponseContent(FILTERED_COMPLEX_RESPONSE_FILE_NAME);
    }

    @Override
    public String generateComplexExampleResponseContent() throws IOException, SAXException, ParserConfigurationException {
        return generateExampleResponseContent(COMPLEX_RESPONSE_FILE_NAME);
    }

    @Override
    public String generateSimpleExampleResponseFileName() {
        return generateXmlNameForFile(SIMPLE_RESPONSE_FILE_NAME);
    }

    @Override
    public String generateSimpleExampleResponseContent() throws IOException, SAXException, ParserConfigurationException {
        return generateExampleResponseContent(SIMPLE_RESPONSE_FILE_NAME);
    }

    @Override
    public Map<String, Object> getSelectieCriteriaMapping() {
        Map<String, Object> mapping = new HashMap<>();

        Map<BaseCwsFilterType, String> filterMap = selectionCriteria.getFilterMap();
        mapping.put("condition_beeindigdAdresUitsluiten", Boolean.toString(convertStringToBoolean(filterMap.get(CwsHrFilterType.BEEINDIGD_ADRES_UITSLUITEN))));

        return mapping;
    }
}
