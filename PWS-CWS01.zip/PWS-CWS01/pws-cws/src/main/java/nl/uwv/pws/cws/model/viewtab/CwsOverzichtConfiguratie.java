package nl.uwv.pws.cws.model.viewtab;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;
import java.util.Map;

@Getter
@Setter
public class CwsOverzichtConfiguratie {
    private Long configId;
    private String afnemerCode;
    private String leveringCode;
    private Long contractId;
    private LocalDate contractStartDate;
    private Long versie;
    private String name;
    private LocalDate configStartDate;
    private LocalDate configEndDate;
    private String status;
    private String berichtVersie;

    private Map<String, Boolean> selectieCriteria;
    private Map<String, Boolean> metaColValues;
}
