package nl.uwv.pws.cws.model.specification;

public class ExportableConfigurationSpecification extends ConfigurationSpecification{

}
