package nl.uwv.pws.cws.views.beheer.contract;

import com.vaadin.flow.data.provider.QuerySortOrder;
import com.vaadin.flow.data.provider.SortDirection;
import nl.uwv.pws.backend.desc.FieldDescriptor;
import nl.uwv.pws.backend.service.AbstractListService;

import static nl.uwv.pws.cws.views.beheer.contract.ContractServiceType.CONTRACT_BY_AFNEMER;

public class ContractService extends AbstractListService {
   private static final String VIEW_NAME = "CWS_CONTRACT_VW";

   private ContractServiceType contractServiceType;

   ContractService(final String dataSourceName, ContractServiceType serviceType) {
      super(dataSourceName);
      this.contractServiceType = serviceType;
   }

   protected String getViewName() {
      return VIEW_NAME;
   }

   public FieldDescriptor getDescriptor() {
      if (this.contractServiceType.equals(CONTRACT_BY_AFNEMER)) {
         return ContractFieldByAfnemerDescriptor.getInstance();
      }

      return ContractFieldByLeveringDescriptor.getInstance();
   }

   protected QuerySortOrder getDefaultSortOrder() {
      return new QuerySortOrder(ContractColumn.HIS_DAT_END.name(), SortDirection.DESCENDING);
   }
}
