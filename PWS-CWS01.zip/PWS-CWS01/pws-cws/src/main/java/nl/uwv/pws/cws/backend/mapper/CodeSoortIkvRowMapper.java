package nl.uwv.pws.cws.backend.mapper;

import nl.uwv.pws.cws.model.CodeSoortIkv;
import nl.uwv.pws.cws.util.CwsUtils;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;

public class CodeSoortIkvRowMapper implements CwsRowMapper<CodeSoortIkv> {

   @Override
   public CodeSoortIkv mapRow(ResultSet resultSet) throws SQLException {
      final String code = resultSet.getString("CODE");
      final String omschrijving =resultSet.getString("OMSCHRIJVING");
      String datumEinde = "";
      if (resultSet.getTimestamp("DATUMEINDE") != null) {
         final LocalDateTime retrievedDatumEinde = resultSet.getTimestamp("DATUMEINDE").toLocalDateTime();
         datumEinde = CwsUtils.getLocalDateTimeAsString(retrievedDatumEinde);
      }

      return CodeSoortIkv.builder()
            .code(code)
            .omschrijving(omschrijving)
            .datumEinde(datumEinde)
            .build();
   }
}
