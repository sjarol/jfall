package nl.uwv.pws.cws.model.viewtab;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.Map;

@Builder
@Getter
@Setter
public class ConfiguratieWithFilters {
    private Long cconId;
    private Map<String, Boolean> filters;
}
