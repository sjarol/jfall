package nl.uwv.pws.cws.views.beheer.levering;

import nl.uwv.pws.backend.types.Column;

/**
 * List of columns in the view AFN_LEVERING_TYPE.
 */
public enum LeveringColumn implements Column {
   LEV_CD
}
