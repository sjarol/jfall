package nl.uwv.pws.cws.views.beheer.common;

import com.vaadin.flow.component.AbstractField.ComponentValueChangeEvent;
import com.vaadin.flow.component.HasValue.ValueChangeListener;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.data.provider.ConfigurableFilterDataProvider;
import lombok.Getter;
import lombok.Setter;
import nl.uwv.pws.backend.dao.SqlFilter;
import nl.uwv.pws.backend.service.AbstractListService;
import nl.uwv.pws.backend.service.ColumnListDataProvider;
import nl.uwv.pws.backend.service.CountRowsListener;
import nl.uwv.pws.backend.types.ColumnList;
import nl.uwv.pws.ui.components.LabelGrid;
import nl.uwv.pws.ui.util.UIUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * Generic GridPanel that contains code that is mostly shared between the different GridPanel implementations
 * in the ContractBeheerGridView.
 *
 * @param <F> The type of SqlFilter to use for filtering data in the grid of this panel.
 */

@Getter
@Setter
public abstract class AbstractBeheerConfiguratieGridPanel<F extends SqlFilter> extends LabelGrid<ColumnList> {
   private static final Logger LOG = LoggerFactory.getLogger(AbstractBeheerConfiguratieGridPanel.class);

   public static final String GRID_ID_POSTFIX = "_grid";
   private final Grid<ColumnList> grid;

   private final ConfigurableFilterDataProvider<ColumnList, Void, SqlFilter> dataProvider;

   private ColumnList preSelectedItem;
   private boolean searchPerformed = false;

   protected AbstractBeheerConfiguratieGridPanel(
         final String componentId,
         final String title,
         final AbstractListService listService,
         final ValueChangeListener<ComponentValueChangeEvent<Grid<ColumnList>, ColumnList>> valueChangeListener,
         final CountRowsListener countRowsListener) {

      super(title, UIUtils.createGrid(componentId + GRID_ID_POSTFIX, listService.getDescriptor()));

      // Set id for panel
      super.setId(componentId);

      // Setup the grid
      ColumnListDataProvider columnListDataProvider = new ColumnListDataProvider(listService);
      super.addDataSizeConsumerToProvider(columnListDataProvider);

      // Listen to fetch-calls on the dataprovider so we can act whenever new rows come in
      if (countRowsListener != null) {
         columnListDataProvider.addCountRowsListener(countRowsListener);
      }
      columnListDataProvider.addFetchRowsListener(this::rowsFetched);
      dataProvider = columnListDataProvider.withConfigurableFilter();

      this.grid = super.getGrid();
      grid.setHeight("150px");
      grid.setDataProvider(dataProvider);
      grid.setSelectionMode(Grid.SelectionMode.SINGLE);
      grid.asSingleSelect().addValueChangeListener(valueChangeEvent -> rowChanged(valueChangeEvent, valueChangeListener));
      super.getContent().addClassName("cws-search-result-panel");
   }

   /**
    * Called whenever Vaadin asks the service to fetch a couple of rows for rendering the grid.
    * Note: Vaadin fetches data in batches, so the list of rows might be a sub-set of all rows that
    * maths the current filter.
    *
    * @param rows The rows that were fetched from the database.
    */
   private void rowsFetched(final List<ColumnList> rows) {
      selectFirstRow(rows);
      onRowsFetched(rows);
   }

   private void rowChanged(final ComponentValueChangeEvent<Grid<ColumnList>, ColumnList> event,
                           final ValueChangeListener<ComponentValueChangeEvent<Grid<ColumnList>, ColumnList>> valueChangeListener) {
      onRowChanged(event);
      ColumnList columnListNew = event.getValue();
      if (valueChangeListener != null && columnListNew != null) {
         valueChangeListener.valueChanged(event);
      }
   }

   /**
    * Can be used to programmatically select the first row in the grid.
    *
    * @param rows The list of available rows.
    */
   public void selectFirstRow(final List<ColumnList> rows) {
      if (rows == null || rows.isEmpty() || preSelectedItem != null) {
         LOG.debug("Nothing to select");
         return;
      }

      LOG.debug("Selecting first row that was just fetched...");
      ColumnList firstItem = rows.get(0);
      preSelectedItem = firstItem;
      grid.select(firstItem);
   }

   /**
    * Can be triggered when a search is performed to update the filter on the grids' dataProvider.
    *
    * @param filter The filter to use for searching.
    */
   public void search(final F filter) {
      LOG.debug("Searching: {}...", filter);
      searchPerformed = true;
      preSelectedItem = null;
      dataProvider.setFilter(filter);
   }

   protected void onRowChanged(final ComponentValueChangeEvent<Grid<ColumnList>, ColumnList> evt) {}

   /**
    * Called when the database is queried and a list of records is returned.
    *
    * @param rows The rows of data that have been fetched.
    */
   protected void onRowsFetched(final List<ColumnList> rows) {}

   public void reset() {
      search(null);
   }

   public void hide() {
      setVisible(false);
   }

   public void show() {
      setVisible(true);
   }
}
