package nl.uwv.pws.cws.views.beheer.configuratie;

import com.vaadin.flow.data.provider.QuerySortOrder;
import com.vaadin.flow.data.provider.SortDirection;
import nl.uwv.pws.backend.desc.FieldDescriptor;
import nl.uwv.pws.backend.service.AbstractListService;

class ConfiguratieService extends AbstractListService {
   private static final String VIEW_NAME = "CWS_CONFIGURATIE_VW";

   ConfiguratieService(final String dataSourceName) {
      super(dataSourceName);
   }

   protected String getViewName() {
      return VIEW_NAME;
   }

   public FieldDescriptor getDescriptor() {
      return ConfiguratieFieldDescriptor.getInstance();
   }

   protected QuerySortOrder getDefaultSortOrder() {
      return new QuerySortOrder(ConfiguratieColumn.VERSION.name(), SortDirection.ASCENDING);
   }
}
