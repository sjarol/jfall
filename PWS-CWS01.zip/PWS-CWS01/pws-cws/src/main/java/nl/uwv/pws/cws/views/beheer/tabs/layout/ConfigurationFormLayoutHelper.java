package nl.uwv.pws.cws.views.beheer.tabs.layout;

import com.vaadin.flow.component.datepicker.DatePicker;
import com.vaadin.flow.component.formlayout.FormLayout;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.binder.Binder;
import nl.uwv.pws.cws.model.CwsConfiguration;
import nl.uwv.pws.cws.util.ConfigurationStatus;
import nl.uwv.pws.cws.util.CwsUtils;
import nl.uwv.pws.cws.views.beheer.configuratie.ConfigurationAction;

import static nl.uwv.pws.cws.util.Constants.*;
import static nl.uwv.pws.cws.util.CwsUIUtils.*;

public class ConfigurationFormLayoutHelper {

   private static final boolean DISABLED = false;
   private static final boolean ENABLED = true;
   private static final boolean REQUIRED_FIELD = true;
   private static final boolean OPTIONAL_FIELD = false;

   private TextField textFieldAfnemercode;
   private TextField textFieldAfnemerNaam;
   private TextField textFieldContractId;
   private TextField textFieldContractBeginDate;
   private TextField textFieldConfigurationVersion;
   private TextField textFieldConfigurationNaam;
   private DatePicker fieldConfigurationBeginDate;
   private DatePicker fieldConfigurationEndDate;
   private TextField textFieldConfigurationStatus;
   private TextField textFieldBerichtVersion;

   public FormLayout createAddConfigurationLayout(final CwsConfiguration cwsConfiguration, final Binder<CwsConfiguration> binder, final String berichtVersion) {
      FormLayout formLayout = new FormLayout();

      final String configurationStatus = ConfigurationStatus.CO.name();

      textFieldAfnemercode = createTextField(COMPONENT_ID_AFNEMERCODE_TEXT_FIELD, cwsConfiguration.getAfnemerCode(), DISABLED, 8);
      textFieldAfnemerNaam = createTextField(COMPONENT_ID_AFNEMERNAAM_TEXT_FIELD, cwsConfiguration.getAfnemerNaam(), DISABLED, 200);
      textFieldContractId = createTextField(COMPONENT_ID_CONTRACTID_TEXT_FIELD, cwsConfiguration.getContractId().toString(), DISABLED, 200);
      textFieldContractBeginDate = createTextField(COMPONENT_ID_CONTRACTBEGINDATUM_TEXT_FIELD, CwsUtils.getLocalDateAsString(cwsConfiguration.getContractStartDate()), DISABLED, 200);
      textFieldConfigurationVersion = createTextField(COMPONENT_ID_CONFIGURATIEVERSIE_TEXT_FIELD,null, DISABLED, 200);
      textFieldConfigurationNaam = createTextField(COMPONENT_ID_CONFIGURATIENAAM_TEXT_FIELD, null, ENABLED, 200);
      binder.forField(textFieldConfigurationNaam).bind(CwsConfiguration::getConfigurationName, CwsConfiguration::setConfigurationName);

      fieldConfigurationBeginDate = createDatePicker(COMPONENT_ID_CONFIGURATIEBEGINDATUM_TEXT_FIELD, OPTIONAL_FIELD, null, ENABLED);
      binder.forField(fieldConfigurationBeginDate).asRequired("Begindatum is verplicht").bind(CwsConfiguration::getConfigurationStartDate, CwsConfiguration::setConfigurationStartDate);
      fieldConfigurationEndDate = createDatePicker(COMPONENT_ID_CONFIGURATIEEINDDATUM_TEXT_FIELD, OPTIONAL_FIELD, null, ENABLED);
      binder.forField(fieldConfigurationEndDate).bind(CwsConfiguration::getConfigurationEndDate, CwsConfiguration::setConfigurationEndDate);

      textFieldConfigurationStatus = createTextField(COMPONENT_ID_CONFIGURATIESTATUS_TEXT_FIELD, configurationStatus, DISABLED, 200);
      binder.forField(textFieldConfigurationStatus).bind(CwsConfiguration::getConfigurationStatus, CwsConfiguration::setConfigurationStatus);
      textFieldBerichtVersion = createTextField(COMPONENT_ID_BERICHTVERSIE_TEXT_FIELD, berichtVersion, DISABLED, 200);
      binder.forField(textFieldBerichtVersion).bind(CwsConfiguration::getBerichtVersie, CwsConfiguration::setBerichtVersie);

      addFormItems(formLayout);
      return formLayout;
   }

   public FormLayout createModifyAndViewConfigurationLayout(final CwsConfiguration cwsConfiguration, final Binder<CwsConfiguration> binder, final ConfigurationAction configurationAction) {
      FormLayout formLayout = new FormLayout();

      textFieldAfnemercode = createTextField(COMPONENT_ID_AFNEMERCODE_TEXT_FIELD, cwsConfiguration.getAfnemerCode(), DISABLED, 8);
      textFieldAfnemerNaam = createTextField(COMPONENT_ID_AFNEMERNAAM_TEXT_FIELD, cwsConfiguration.getAfnemerNaam(), DISABLED, 200);
      textFieldContractId = createTextField(COMPONENT_ID_CONTRACTID_TEXT_FIELD, cwsConfiguration.getContractId().toString(), DISABLED, 200);
      textFieldContractBeginDate = createTextField(COMPONENT_ID_CONTRACTBEGINDATUM_TEXT_FIELD, CwsUtils.getLocalDateAsString(cwsConfiguration.getContractStartDate()), DISABLED, 200);
      textFieldConfigurationVersion = createTextField(COMPONENT_ID_CONFIGURATIEVERSIE_TEXT_FIELD, cwsConfiguration.getConfigurationVersion().toString(), DISABLED, 200);

      boolean enabled = configurationAction.equals(ConfigurationAction.VIEW) ? DISABLED : ENABLED;
      textFieldConfigurationNaam = createTextField(COMPONENT_ID_CONFIGURATIENAAM_TEXT_FIELD, cwsConfiguration.getConfigurationName(), enabled, 30);
      fieldConfigurationBeginDate = createDatePicker(COMPONENT_ID_CONFIGURATIEBEGINDATUM_TEXT_FIELD, REQUIRED_FIELD, cwsConfiguration.getConfigurationStartDate(), enabled);
      binder.forField(fieldConfigurationBeginDate).asRequired("Begindatum is verplicht").bind(CwsConfiguration::getConfigurationStartDate, CwsConfiguration::setConfigurationStartDate);
      fieldConfigurationEndDate = createDatePicker(COMPONENT_ID_CONFIGURATIEEINDDATUM_TEXT_FIELD, OPTIONAL_FIELD, cwsConfiguration.getConfigurationEndDate(), enabled);

      textFieldConfigurationStatus = createTextField(COMPONENT_ID_CONFIGURATIESTATUS_TEXT_FIELD, cwsConfiguration.getConfigurationStatus(), DISABLED, 200);
      textFieldBerichtVersion = createTextField(COMPONENT_ID_BERICHTVERSIE_TEXT_FIELD, cwsConfiguration.getBerichtVersie(), DISABLED, 200);

      addFormItems(formLayout);

      return formLayout;
   }

  private void addFormItems(FormLayout formLayout) {
     addFormItem(formLayout, textFieldAfnemercode, "Afn. Code:", OPTIONAL_FIELD);
     addFormItem(formLayout, textFieldAfnemerNaam, "Naam Afnemer:", OPTIONAL_FIELD);
     addFormItem(formLayout, textFieldContractId, "Contract ID:", OPTIONAL_FIELD);
     addFormItem(formLayout, textFieldContractBeginDate, "Contract Begindatum:", OPTIONAL_FIELD);
     addFormItem(formLayout, textFieldConfigurationVersion, "Versie Configuratie:", OPTIONAL_FIELD);
     addFormItem(formLayout, textFieldConfigurationNaam, "Naam Configuratie:", OPTIONAL_FIELD);
     addFormItem(formLayout, fieldConfigurationBeginDate, "Begindatum:", REQUIRED_FIELD);
     addFormItem(formLayout, fieldConfigurationEndDate, "Einddatum:", OPTIONAL_FIELD);
     addFormItem(formLayout, textFieldConfigurationStatus, "Status:", OPTIONAL_FIELD);
     addFormItem(formLayout, textFieldBerichtVersion, "Bericht Versie:", OPTIONAL_FIELD);
  }
}
