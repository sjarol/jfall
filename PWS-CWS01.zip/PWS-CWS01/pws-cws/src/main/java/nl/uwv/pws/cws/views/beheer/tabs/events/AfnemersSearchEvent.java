package nl.uwv.pws.cws.views.beheer.tabs.events;

import com.vaadin.flow.component.ComponentEvent;
import lombok.Getter;
import nl.uwv.pws.cws.model.SearchCriteria;
import nl.uwv.pws.cws.views.AfnemersSearchBar;

/**
 * Events that is triggered whenever the user searches for afnemer records. This event holds all
 * the data entered by the user in the search fields.
 */
@Getter
public class AfnemersSearchEvent extends ComponentEvent<AfnemersSearchBar> {
   private String afnemerCode;
   private String afnemerNaam;
   private String ugcId;
   private String contractId;

   public AfnemersSearchEvent(
         final AfnemersSearchBar searchBar,
         final boolean fromClient,
         final SearchCriteria searchCriteria) {
      super(searchBar, fromClient);
      this.afnemerCode = searchCriteria.getAfnemerCode();
      this.afnemerNaam = searchCriteria.getAfnemerNaam();
      this.ugcId = searchCriteria.getUgcId();
      this.contractId = searchCriteria.getContractId();
   }
}
