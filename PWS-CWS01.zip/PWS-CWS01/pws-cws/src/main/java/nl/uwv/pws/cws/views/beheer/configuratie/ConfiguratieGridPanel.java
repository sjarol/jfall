package nl.uwv.pws.cws.views.beheer.configuratie;

import com.vaadin.flow.component.AbstractField.ComponentValueChangeEvent;
import com.vaadin.flow.component.HasValue.ValueChangeListener;
import com.vaadin.flow.component.grid.Grid;
import lombok.Getter;
import lombok.Setter;
import nl.uwv.pws.backend.dao.SqlFilter;
import nl.uwv.pws.backend.types.ColumnList;
import nl.uwv.pws.cws.model.ContractDetails;
import nl.uwv.pws.cws.util.Constants;
import nl.uwv.pws.cws.views.beheer.common.AbstractBeheerConfiguratieGridPanel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static nl.uwv.pws.cws.util.Constants.CONFIGURATIE_DIALOG_CAPTION;

@Setter
@Getter
public class ConfiguratieGridPanel extends AbstractBeheerConfiguratieGridPanel<SqlFilter> {
   private static final Logger LOG = LoggerFactory.getLogger(ConfiguratieGridPanel.class);
   public static final String COMPONENT_ID = "configuratie-panel";
   private ColumnList preSelectedColumnList;

   public ConfiguratieGridPanel(final ValueChangeListener<ComponentValueChangeEvent<Grid<ColumnList>, ColumnList>> valueChangeListener) {
      super(COMPONENT_ID, CONFIGURATIE_DIALOG_CAPTION, new ConfiguratieService(Constants.DS_NAME), valueChangeListener, null);
   }

   public void findConfiguratie(final ContractDetails contractDetails) {
      final BigDecimal contractId = contractDetails.getContractId();
      final LocalDate contractStartDate = contractDetails.getContractStartDate();

      LOG.debug("Finding configuraties using contract id {} and contract start date {}", contractId, contractStartDate);
      search(new ConfiguratieFilter(contractId, contractStartDate));
   }

   public void selectFirstRow(final List<ColumnList> rows) {
      if(preSelectedColumnList != null){
         Optional<ColumnList> firstItem = rows.stream().filter(columnList -> columnList.getId().equals(preSelectedColumnList.getId())).findFirst();
         firstItem.ifPresent(item -> super.getGrid().select(item));
      } else {
         ColumnList firstItem = rows.get(0);
         super.getGrid().select(firstItem);
      }
   }
}
