package nl.uwv.pws.cws.views.beheer.afnemer;

import nl.uwv.pws.backend.desc.FieldDescParser;
import nl.uwv.pws.backend.desc.FieldDescriptor;

/**
 * FieldDescriptor that reads its column definitions from the file afnemers.desc.
 */
final class AfnemerFieldDescriptor extends FieldDescriptor {
   private static final AfnemerFieldDescriptor INSTANCE = new AfnemerFieldDescriptor(
         AfnemerFieldDescriptor.class.getPackage().getName().replace('.', '/') + "/afnemers.desc"
   );

   private AfnemerFieldDescriptor(final String resource) {
      super(new FieldDescParser().parse(resource));
   }

   static AfnemerFieldDescriptor getInstance() {
      return INSTANCE;
   }
}
