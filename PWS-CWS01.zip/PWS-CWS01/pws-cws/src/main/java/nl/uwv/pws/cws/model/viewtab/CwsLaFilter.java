package nl.uwv.pws.cws.model.viewtab;

import org.apache.commons.lang3.StringUtils;

import java.util.function.Function;

import static org.apache.commons.lang3.StringUtils.isNotEmpty;

public enum CwsLaFilter implements BaseCwsOverzichtFilterOption {
    CD_SOORT_IKVS(
        "Filter code soort IKV",
        "Filter code soort inkomstenverhouding",
        StringUtils::isNotEmpty),
    NIHIL_LNSV_UITSLUITEN(
        "Filter nihil loon SV",
        "Filter nihil loon SV uitsluiten",
        value -> isNotEmpty(value) && value.equals("J")),
    NIHIL_LNLBPH_UITSLUITEN(
        "Filter nihil loon LB/PH",
        "Filter nihil loon LB/PH uitsluiten",
        value -> isNotEmpty(value) && value.equals("J"));

    private String columnName;
    private String headerColumnName;
    private Function<String, Boolean> conditionFunction;

    CwsLaFilter(String columnName, String headerColumnName, Function<String, Boolean> conditionFunction) {
        this.columnName = columnName;
        this.headerColumnName = headerColumnName;
        this.conditionFunction = conditionFunction;
    }

    @Override
    public String getColumnName() {
        return this.columnName;
    }

    @Override
    public String getHeaderColumnName() {
        return this.headerColumnName;
    }

    @Override
    public String getEnumName() {
        return this.name();
    }

    @Override
    public boolean testCondition(String value) {
        return this.conditionFunction.apply(value);
    }
}
