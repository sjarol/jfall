package nl.uwv.pws.cws.views.beheer.tabs.events;

import com.vaadin.flow.component.ComponentEvent;
import nl.uwv.pws.cws.views.AfnemersSearchBar;

public class ValidationFailedEvent extends ComponentEvent<AfnemersSearchBar> {
     public ValidationFailedEvent(
         final AfnemersSearchBar searchBar,
         final boolean fromClient) {
      super(searchBar, fromClient);
   }
}
