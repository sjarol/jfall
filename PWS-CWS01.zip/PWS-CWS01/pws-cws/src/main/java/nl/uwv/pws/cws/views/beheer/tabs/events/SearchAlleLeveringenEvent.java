package nl.uwv.pws.cws.views.beheer.tabs.events;

import com.vaadin.flow.component.ComponentEvent;
import nl.uwv.pws.cws.views.AfnemersSearchBar;

public class SearchAlleLeveringenEvent extends ComponentEvent<AfnemersSearchBar> {

   public SearchAlleLeveringenEvent(AfnemersSearchBar source, boolean fromClient) {
      super(source, fromClient);
   }
}
