package nl.uwv.pws.cws.views.beheer.contract;

import nl.uwv.pws.backend.filter.AbstractSqlFilter;


public class ContractByContractIdFilter extends AbstractSqlFilter {

   public ContractByContractIdFilter(final String contractId) {
      super("(" + ContractColumn.CONTRACT_ID + " = ?)", contractId);
   }
}
