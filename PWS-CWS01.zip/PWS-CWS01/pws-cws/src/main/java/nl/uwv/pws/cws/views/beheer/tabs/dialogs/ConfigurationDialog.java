package nl.uwv.pws.cws.views.beheer.tabs.dialogs;

import com.helger.commons.annotation.VisibleForTesting;
import com.vaadin.flow.component.AbstractField.ComponentValueChangeEvent;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.checkbox.Checkbox;
import com.vaadin.flow.component.datepicker.DatePicker;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.formlayout.FormLayout;
import com.vaadin.flow.component.html.Label;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.component.treegrid.TreeGrid;
import com.vaadin.flow.data.binder.Binder;
import com.vaadin.flow.data.binder.ValidationException;
import com.vaadin.flow.data.provider.hierarchy.HierarchicalDataProvider;
import com.vaadin.flow.function.SerializablePredicate;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import nl.uwv.pws.backend.dao.BackendException;
import nl.uwv.pws.cws.backend.dao.CwsConfigurationDao;
import nl.uwv.pws.cws.exception.FormValidationException;
import nl.uwv.pws.cws.model.CwsConfiguration;
import nl.uwv.pws.cws.model.CwsMetaCol;
import nl.uwv.pws.cws.model.SelectionCriteria;
import nl.uwv.pws.cws.util.ConfigurationStatus;
import nl.uwv.pws.cws.util.CwsUIUtils;
import nl.uwv.pws.cws.util.CwsUtils;
import nl.uwv.pws.cws.util.Validator;
import nl.uwv.pws.cws.views.beheer.configuratie.ConfigurationAction;
import nl.uwv.pws.cws.views.beheer.tabs.layout.BaseSelectionCriteriaFormLayout;
import nl.uwv.pws.cws.views.beheer.tabs.layout.ConfigurationFormLayoutHelper;
import nl.uwv.pws.cws.views.beheer.tabs.layout.cwshr.CwsHrSelectionCriteriaLayout;
import nl.uwv.pws.cws.views.beheer.tabs.layout.cwsihp.CwsIhpSelectionCriteriaLayout;
import nl.uwv.pws.cws.views.beheer.tabs.layout.cwsla.CwsLaSelectionCriteriaLayout;
import nl.uwv.pws.cws.views.beheer.tabs.layout.cwsnp.CwsNpSelectionCriteriaLayout;
import nl.uwv.pws.cws.views.beheer.tabs.layout.cwswg.CwsWgSelectionCriteriaLayout;
import nl.uwv.pws.ui.components.StyledDialog;
import nl.uwv.pws.ui.util.FontSize;
import nl.uwv.pws.ui.util.TextColor;
import nl.uwv.pws.ui.util.UIUtils;
import nl.uwv.pws.ui.views.ViewFrame;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import static nl.uwv.pws.cws.util.Constants.*;
import static nl.uwv.pws.cws.util.CwsUIUtils.createHeaderLabel;
import static nl.uwv.pws.cws.util.CwsUIUtils.findComponent;

@Slf4j
@Getter
@Setter
@CssImport(value = "./styles/custom-form-item.css", themeFor = "vaadin-form-item")
@CssImport(value = "./styles/tree-grid-styles.css", themeFor="vaadin-grid")
public class ConfigurationDialog extends StyledDialog {
   private static final LocalDate POLIS_DEFAULT_END_DATE = LocalDate.of(9999,12,31);
   private static final long POLIS_DEFAULT_END_YEAR = 9999L;

   private CwsConfigurationDao cwsConfigurationDao;
   private CwsConfiguration cwsConfiguration;
   private ConfigurationAction configurationAction;
   private LocalDate selectedConfigurationStartDate;

   private FormLayout layout;
   private ConfigurationFormLayoutHelper configurationFormLayoutHelper;
   private Validator validator;
   private Label errorLabel;
   private FormLayout selectionCriteriaLayout;
   private BaseSelectionCriteriaFormLayout selectionCriteriaLayoutHelper;
   private Map<Long, CwsMetaCol> metaColMap;
   private TreeGrid<CwsMetaCol> cwsMetaColTreeGrid;
   private Binder<CwsConfiguration> binder;

   public ConfigurationDialog(ViewFrame parent) {
      this(parent, "CWS Configuratie", "70em", "100%", COMPONENT_ID_OVERZICHT_CWS_CONFIGURATIE_EDITOR_LAYOUT);
      this.setDraggable(true);
      this.setModal(true);
      this.setResizable(true);

      this.binder = new Binder<>(CwsConfiguration.class);
      this.cwsConfigurationDao = CwsConfigurationDao.getInstance();
      this.configurationFormLayoutHelper = new ConfigurationFormLayoutHelper();
      this.validator = new Validator();
   }

   public void configureDialog(final CwsConfiguration cwsConfiguration, final ConfigurationAction configurationAction){
      this.cwsConfiguration = cwsConfiguration;
      initSelectionCriteriaLayoutHelper();
      this.configurationAction = configurationAction;
      setContent(createContent());
   }

   private ConfigurationDialog(ViewFrame parent, String title, String width, String height, String inheritedComponentId) {
      super(parent, title, width, height, inheritedComponentId);
   }

   private void initSelectionCriteriaLayoutHelper() {
      if (CWSLA_LEV_CODE.equals(this.cwsConfiguration.getLeverCode())) {
         this.selectionCriteriaLayoutHelper = new CwsLaSelectionCriteriaLayout();
      } else if (CWSNP_LEV_CODE.equals(this.cwsConfiguration.getLeverCode())) {
         this.selectionCriteriaLayoutHelper = new CwsNpSelectionCriteriaLayout();
      } else if (CWSHR_LEV_CODE.equals(this.cwsConfiguration.getLeverCode())) {
         this.selectionCriteriaLayoutHelper = new CwsHrSelectionCriteriaLayout();
      } else if (CWSWG_LEV_CODE.equals(this.cwsConfiguration.getLeverCode())) {
         this.selectionCriteriaLayoutHelper = new CwsWgSelectionCriteriaLayout();
      } else if (CWSIHP_LEV_CODE.equals(this.cwsConfiguration.getLeverCode())) {
         this.selectionCriteriaLayoutHelper = new CwsIhpSelectionCriteriaLayout();
      } else {
         throw new BackendException("Unknown SelectieCriteria Lev Code");
      }
   }

   private Component createContent() {
      Label headerLabel = createHeaderLabel("Afnemer Configuratie");
      Component form = createForm();
      Component errorLabel = createErrorLabel();
      Component selectionCriteriaForm = createFormSelectionCriteria();
      cwsMetaColTreeGrid = setupConfigurationSelection();
      cwsMetaColTreeGrid.setId("cws-tree-grid");
      VerticalLayout content = new VerticalLayout(
            headerLabel,
            form,
            errorLabel,
            selectionCriteriaForm,
            cwsMetaColTreeGrid
      );

      content.setSizeUndefined();
      return content;
   }

   private Component createErrorLabel() {
      errorLabel = UIUtils.createLabel(FontSize.L, TextColor.ERROR, "");
      errorLabel.setWidthFull();
      errorLabel.setId(COMPONENT_ID_OVERZICHT_CWS_CONFIGURATIE_EDITOR_LAYOUT + "-form-error");

      return errorLabel;
   }

   private Component createFormSelectionCriteria() {
      SelectionCriteria selectedSelectionCriteria = null;
      if (!configurationAction.equals(ConfigurationAction.ADD)) {
         selectedSelectionCriteria = this.cwsConfigurationDao.selectSelectionCriteriaByConfigId(this.cwsConfiguration.getConfigurationId());
      }
      this.selectionCriteriaLayout = selectionCriteriaLayoutHelper.createSelectionCriteriaLayout(selectedSelectionCriteria, this.configurationAction);
      selectionCriteriaLayout.setResponsiveSteps(new FormLayout.ResponsiveStep("40em", 1));
      selectionCriteriaLayout.setWidthFull();
      return selectionCriteriaLayout;
   }

   private TreeGrid<CwsMetaCol> setupConfigurationSelection() {
      TreeGrid<CwsMetaCol> tree = null;
      this.metaColMap = this.cwsConfigurationDao.getMetaDataByLeverCodeAndVersie(this.cwsConfiguration.getLeverCode(), this.cwsConfiguration.getBerichtVersie());
      if (configurationAction.equals(ConfigurationAction.ADD)) {
         this.metaColMap.values().forEach(CwsMetaCol::disableAllRequiredAndTheParents);
         tree = CwsUIUtils.createTreeGrid(new ArrayList<>(metaColMap.values()), this::checkboxSelected);

      } else if (configurationAction.equals(ConfigurationAction.MODIFY) || configurationAction.equals(ConfigurationAction.VIEW)) {
         final String configurationStatusDefinitief = ConfigurationStatus.DE.name();
         final List<Long> selectedAttributes = this.cwsConfigurationDao.selectCheckedMetadataAttributes(this.cwsConfiguration.getConfigurationId());
         this.metaColMap.values().forEach(cwsMetaCol -> {
            if (selectedAttributes.contains(cwsMetaCol.getMetaColId())) {
               cwsMetaCol.setChecked(true);
            }

            if (this.cwsConfiguration.getConfigurationStatus().equalsIgnoreCase(configurationStatusDefinitief) || configurationAction.equals(ConfigurationAction.VIEW)) {
               cwsMetaCol.setEnabled(false);
            } else {
               cwsMetaCol.disableAllRequiredAndTheParents();
            }
         });
         tree = CwsUIUtils.createTreeGrid(new ArrayList<>(metaColMap.values()), this::checkboxSelected);
      } else {
         throw new IllegalStateException("unsupported ConfigurationAction provided");
      }

      return tree;
   }

   public void checkboxSelected(final ComponentValueChangeEvent<Checkbox, Boolean> valueChangeEvent, final CwsMetaCol cwsMetaCol, final HierarchicalDataProvider<CwsMetaCol, SerializablePredicate<CwsMetaCol>> dataProvider) {
      boolean checked = Boolean.TRUE.equals(valueChangeEvent.getValue());
      cwsMetaCol.updateDescendants(checked).forEach(dataProvider::refreshItem);
      cwsMetaCol.setChecked(checked);
      dataProvider.refreshItem(cwsMetaCol);

      cwsMetaCol.updateAscendants(checked).forEach(dataProvider::refreshItem);
   }

   private Component createForm() {
      if (configurationAction.equals(ConfigurationAction.ADD)) {
         createFormForNewConfiguration();
      } else {
         createFormForExistingConfiguration();
      }
      layout.setResponsiveSteps(new FormLayout.ResponsiveStep("40em", 1));
      layout.setWidth("50%");
      return layout;
   }

   private void createFormForNewConfiguration() {
      final String latestBerichtVersie = cwsConfigurationDao.getMaxBerichtVersie(this.cwsConfiguration.getLeverCode());
      this.cwsConfiguration.setBerichtVersie(latestBerichtVersie);

      this.layout = configurationFormLayoutHelper.createAddConfigurationLayout(this.cwsConfiguration, this.binder, latestBerichtVersie);

      addButtonOpslaan();
   }

   private void createFormForExistingConfiguration() {
      final Long contractId = this.cwsConfiguration.getContractId();
      final LocalDate contractStartDate = this.cwsConfiguration.getContractStartDate();
      final Long configurationVersion = this.cwsConfiguration.getConfigurationVersion();
      final CwsConfiguration selectedCwsConfiguration = this.cwsConfigurationDao.getConfigurationByContractAndConfigVersion(contractId, CwsUtils.getLocalDateAsLong(contractStartDate), configurationVersion);
      this.cwsConfiguration.setConfigurationId(selectedCwsConfiguration.getConfigurationId());
      this.cwsConfiguration.setBerichtVersie(selectedCwsConfiguration.getBerichtVersie());
      this.cwsConfiguration.setConfigurationStatus(selectedCwsConfiguration.getConfigurationStatus());
      this.cwsConfiguration.setConfigurationName(selectedCwsConfiguration.getConfigurationName());
      this.cwsConfiguration.setConfigurationStartDate(selectedCwsConfiguration.getConfigurationStartDate());
      this.cwsConfiguration.setConfigurationEndDate(selectedCwsConfiguration.getConfigurationEndDate());
      this.cwsConfiguration.setRegistrationStartDateTime(selectedCwsConfiguration.getRegistrationStartDateTime());
      this.cwsConfiguration.setRegistrationEndDateTime(selectedCwsConfiguration.getRegistrationEndDateTime());
      this.selectedConfigurationStartDate = selectedCwsConfiguration.getConfigurationStartDate();

      resetDateWhenEndOfTimes();
      this.layout = configurationFormLayoutHelper.createModifyAndViewConfigurationLayout(cwsConfiguration, this.binder, this.configurationAction);

      if (configurationAction.equals(ConfigurationAction.MODIFY)) {
         addButtonOpslaan();
      }
   }

   private void addButtonOpslaan() {
      Button opslaan = CwsUIUtils.createButton("Opslaan", VaadinIcon.CHECK_CIRCLE, COMPONENT_ID_OVERZICHT_CWS_CONFIGURATIE_EDITOR_LAYOUT + "-button-opslaan", true, "10em");
      opslaan.addClickListener(buttonClickEvent -> validateAndSave());
      this.addCustomButtonLeft(opslaan);
   }

   @VisibleForTesting
   void validateAndSave() {
      try {

         binder.writeBean(this.cwsConfiguration);
         final LocalDate contractStartDate = this.cwsConfiguration.getContractStartDate();
         final LocalDate contractEndDate = this.cwsConfiguration.getContractEndDate();
         final DatePicker fieldConfigurationStartDate = (DatePicker) findComponent(COMPONENT_ID_CONFIGURATIEBEGINDATUM_TEXT_FIELD, this.layout);
         final DatePicker fieldConfigurationEndDate = (DatePicker)findComponent(COMPONENT_ID_CONFIGURATIEEINDDATUM_TEXT_FIELD, this.layout);
         validator.validateAfnemerConfiguratiePeriod(contractStartDate, contractEndDate, fieldConfigurationStartDate.getValue(), fieldConfigurationEndDate.getValue());
         selectionCriteriaLayoutHelper.validate();

         if (this.cwsConfiguration.getConfigurationStatus() != null && this.cwsConfiguration.getConfigurationStatus().equals(ConfigurationStatus.CO.name())) {
            validator.validateAtLeastOneAttributeChecked(getCurrentSelectedMetaColIdsExcludeMandatory());
         }

         if (CWSHR_LEV_CODE.equals(this.cwsConfiguration.getLeverCode())) {
            validator.isValid(metaColMap, "persoon");
            validator.isValid(metaColMap, "vestiginghandelsregister");
         }

         if (CWSWG_LEV_CODE.equals(this.cwsConfiguration.getLeverCode())) {
            validator.isValid(metaColMap, "administratieveeenheid");
         }

         if (CWSIHP_LEV_CODE.equals(this.cwsConfiguration.getLeverCode())) {
            validator.isValid(metaColMap, "persooninhoudingsplichtige");
            validator.isValid(metaColMap, "vestiginghandelsregister");
            validator.isValid(metaColMap, "administratieveeenheid");
         }

         if (configurationAction.equals(ConfigurationAction.ADD)) {
            saveAdd();
         } else {
            saveModify(fieldConfigurationStartDate, fieldConfigurationEndDate);
         }
         this.close();
      } catch (ValidationException e) {
         log.warn("invalid input provided by the user", e);
      } catch (FormValidationException e) {
         log.warn("Form validation failed", e);
         CwsUIUtils.showErrorNotification(e.getMessage());
      }
   }

   private void saveAdd() {
      this.cwsConfiguration.setRegistrationStartDateTime(cwsConfigurationDao.getSystimestamp().toLocalDateTime());

      saveConfiguration();
   }

   private void saveModify(final DatePicker fieldConfigurationStartDate, final DatePicker fieldConfigurationEndDate) {
      final TextField fieldConfigurationNaam = (TextField) findComponent(COMPONENT_ID_CONFIGURATIENAAM_TEXT_FIELD, this.layout);

      if (!isConfigurationModified(fieldConfigurationNaam, fieldConfigurationStartDate, fieldConfigurationEndDate)) {
         this.close();
         CwsUIUtils.showErrorNotification("Niet opgeslagen, gegevens zijn ongewijzigd");
         return;
      }

      final Timestamp deleteTimestamp = cwsConfigurationDao.deleteConfiguration(this.cwsConfiguration.getConfigurationId());
      this.cwsConfiguration.setRegistrationStartDateTime(deleteTimestamp.toLocalDateTime());

      this.cwsConfiguration.setConfigurationName(fieldConfigurationNaam.getValue());
      this.cwsConfiguration.setConfigurationStartDate(fieldConfigurationStartDate.getValue());
      this.cwsConfiguration.setConfigurationEndDate(fieldConfigurationEndDate.getValue());

      saveConfiguration();
   }

   private void saveConfiguration() {
      Long configurationId = cwsConfigurationDao.saveCwsConfiguratie(this.cwsConfiguration);
      saveSelectionCriteria(configurationId, this.cwsConfiguration.getRegistrationStartDateTime(), selectionCriteriaLayoutHelper.determineSelectionCriteria());
      saveConfigurationAttributes(configurationId, this.cwsConfiguration.getRegistrationStartDateTime(), getCurrentSelectedMetaColIdsIncludeMandatory());
   }

   private boolean isConfigurationModified(final TextField fieldConfigurationNaam, final DatePicker fieldConfigurationStartDate, final DatePicker fieldConfigurationEndDate) {
      final String configurationNameCurrent = this.cwsConfiguration.getConfigurationName();
      String configurationNameCurrentToUse = configurationNameCurrent == null ? StringUtils.EMPTY : configurationNameCurrent;
      String fieldConfigurationNaamToUse = fieldConfigurationNaam.getValue() == null ? StringUtils.EMPTY : fieldConfigurationNaam.getValue();

      LocalDate configurationStartDateCurrentToUse = this.selectedConfigurationStartDate;
      LocalDate fieldConfigurationStartDateToUse = fieldConfigurationStartDate.getValue();

      final LocalDate configurationEndDateCurrent = this.cwsConfiguration.getConfigurationEndDate();
      LocalDate configurationEndDateCurrentToUse = configurationEndDateCurrent == null ? POLIS_DEFAULT_END_DATE : configurationEndDateCurrent;
      LocalDate fieldConfigurationEndDateToUse = fieldConfigurationEndDate.getValue() == null ? POLIS_DEFAULT_END_DATE : fieldConfigurationEndDate.getValue();

      final List<Long> selectedAttributes = this.cwsConfigurationDao.selectCheckedMetadataAttributes(this.cwsConfiguration.getConfigurationId());
      final Set<Long> currentSelectedIds = getCurrentSelectedMetaColIdsIncludeMandatory();

      return !fieldConfigurationNaamToUse.equals(configurationNameCurrentToUse) ||
            !fieldConfigurationStartDateToUse.equals(configurationStartDateCurrentToUse) ||
            !fieldConfigurationEndDateToUse.equals(configurationEndDateCurrentToUse) ||
            !CollectionUtils.isEqualCollection(currentSelectedIds, selectedAttributes) ||
            !selectionCriteriaLayoutHelper.originalValuesHaveNotChanged();
   }

   private void resetDateWhenEndOfTimes() {
      if (this.cwsConfiguration.getConfigurationEndDate() != null && this.cwsConfiguration.getConfigurationEndDate().getYear() == POLIS_DEFAULT_END_YEAR) {
         this.cwsConfiguration.setConfigurationEndDate(null);
      }
   }

   @VisibleForTesting
   Set<Long> getCurrentSelectedMetaColIdsExcludeMandatory() {
      return this.metaColMap.values().stream()
            .filter(cwsMetaCol -> cwsMetaCol.isEnabled() && (cwsMetaCol.isChecked() || cwsMetaCol.isDisplayIcon()))
            .map(CwsMetaCol::getMetaColId)
            .collect(Collectors.toSet());
   }

   @VisibleForTesting
   Set<Long> getCurrentSelectedMetaColIdsIncludeMandatory() {
      return this.metaColMap.values().stream()
            .filter(cwsMetaCol -> cwsMetaCol.isChecked() || cwsMetaCol.isDisplayIcon())
            .map(CwsMetaCol::getMetaColId)
            .collect(Collectors.toSet());
   }

   private void saveConfigurationAttributes(final Long configurationId, final LocalDateTime configurationStartDateTime, final Set<Long> selectedIds) {
      cwsConfigurationDao.saveConfigurationAttributes(configurationId, configurationStartDateTime, selectedIds);
   }

   private void saveSelectionCriteria(final Long configurationId, final LocalDateTime configurationStartDateTime, SelectionCriteria selectionCriteria) {
      cwsConfigurationDao.saveSelectionCriteria(configurationId, configurationStartDateTime, selectionCriteria);
   }
}
