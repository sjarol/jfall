package nl.uwv.pws.cws.backend.mapper;

import nl.uwv.pws.cws.model.CwsMetaCol;

import java.sql.ResultSet;
import java.sql.SQLException;

public class CwsMetaColRowMapper implements CwsRowMapper<CwsMetaCol> {

   public CwsMetaCol mapRow(final ResultSet resultSet) throws SQLException {
      final Long metaColId = resultSet.getLong("META_COL_ID");
      final Long metaRootId = resultSet.getLong("META_ROOT_ID");
      final Long parentId = resultSet.getLong("PARENT_ID");
      final String techNaam = resultSet.getString("TECH_NAAM");
      final String funcNaam = resultSet.getString("FUNC_NAAM");
      final String omschrijving = resultSet.getString("OMSCHRIJVING");
      final Long volgnr = resultSet.getLong("VOLGNR");
      final String bronTabel = resultSet.getString("BRON_TABEL");
      final String bronRubriek = resultSet.getString("BRON_RUBRIEK");
      final String indVerplicht = resultSet.getString("IND_VERPLICHT");

      return CwsMetaCol.builder()
            .metaColId(metaColId)
            .metaRootId(metaRootId)
            .parentId(parentId)
            .techNaam(techNaam)
            .funcNaam(funcNaam)
            .omschrijving(omschrijving)
            .volgnr(volgnr)
            .bronTabel(bronTabel)
            .bronRubriek(bronRubriek)
            .indVerplicht(indVerplicht)
            .build();
   }
}
