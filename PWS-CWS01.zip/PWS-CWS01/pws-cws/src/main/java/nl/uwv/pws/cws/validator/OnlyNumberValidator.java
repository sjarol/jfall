package nl.uwv.pws.cws.validator;

import com.vaadin.flow.data.binder.ValidationResult;
import com.vaadin.flow.data.binder.Validator;
import com.vaadin.flow.data.binder.ValueContext;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;

public class OnlyNumberValidator implements Validator<String> {

   private String message;

   public OnlyNumberValidator(String message) {
      this.message = message;
   }

   @Override
   public ValidationResult apply(String value, ValueContext valueContext) {

      if (StringUtils.isNotBlank(value) && !NumberUtils.isCreatable(value)) {
         return ValidationResult.error(message);
      }
      return ValidationResult.ok();
   }
}
