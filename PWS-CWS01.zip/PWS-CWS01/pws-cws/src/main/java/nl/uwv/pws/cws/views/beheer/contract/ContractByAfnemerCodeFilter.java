package nl.uwv.pws.cws.views.beheer.contract;

import nl.uwv.pws.backend.filter.AbstractSqlFilter;
import org.apache.commons.lang3.StringUtils;

public class ContractByAfnemerCodeFilter extends AbstractSqlFilter {

   public ContractByAfnemerCodeFilter(final String afnemerCode) {
      super("(UPPER(" + ContractColumn.AFN_CD + ") = ?)", StringUtils.isNotBlank(afnemerCode) ? afnemerCode.toUpperCase() : null);
//
//      super("(" + ContractColumn.HIS_DAT_END + " IS NOT NULL " +
//            "AND UPPER(" + ContractColumn.AFN_CD + ") = ?)", StringUtils.isNotBlank(afnemerCode) ? afnemerCode.toUpperCase() : null);
   }
}
