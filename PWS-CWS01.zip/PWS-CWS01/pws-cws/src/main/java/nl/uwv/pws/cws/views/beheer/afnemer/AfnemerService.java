package nl.uwv.pws.cws.views.beheer.afnemer;

import com.vaadin.flow.data.provider.QuerySortOrder;
import com.vaadin.flow.data.provider.SortDirection;
import nl.uwv.pws.backend.desc.FieldDescriptor;
import nl.uwv.pws.backend.service.AbstractListService;

/**
 * Service that counts and queries afnemer records so they can be used in a Vaadin Grid component.
 */
class AfnemerService extends AbstractListService {
   private static final String SYNONYM_NAME = "AFN_AFNEMER";

   AfnemerService(final String dataSourceName) {
      super(dataSourceName);
   }

   protected String getViewName() {
      return SYNONYM_NAME;
   }

   public FieldDescriptor getDescriptor() {
      return AfnemerFieldDescriptor.getInstance();
   }

   protected QuerySortOrder getDefaultSortOrder() {
      return new QuerySortOrder(AfnemerColumn.AFN_CD.name(), SortDirection.ASCENDING);
   }
}
