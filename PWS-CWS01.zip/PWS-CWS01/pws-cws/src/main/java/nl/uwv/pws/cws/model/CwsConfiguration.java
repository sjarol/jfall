package nl.uwv.pws.cws.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Map;

@Setter
@Getter
@Builder
public class CwsConfiguration {
   private String leverCode;
   private String berichtVersie;

   private Long configurationId;
   private Long contractId;
   private LocalDate contractStartDate;
   private LocalDate contractEndDate;
   private String configurationName;
   private Long configurationVersion;
   private String configurationStatus;
   private LocalDate configurationStartDate;
   private LocalDate configurationEndDate;
   private LocalDateTime registrationStartDateTime;
   private LocalDateTime registrationEndDateTime;

   private String afnemerCode;
   private String afnemerNaam;

   private Map<BaseCwsFilterType, String> filterMap;
}
