package nl.uwv.pws.cws.backend.service;

import nl.uwv.pws.cws.backend.dao.CwsConfigurationDao;
import nl.uwv.pws.cws.backend.dao.CwsConfigurationOverviewDao;
import nl.uwv.pws.cws.model.CwsMetaCol;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

public class BaseService {

   protected final CwsConfigurationDao cwsConfigurationDao;
   protected final CwsConfigurationOverviewDao cwsConfigurationOverviewDao;

   public BaseService(){
      this.cwsConfigurationDao = CwsConfigurationDao.getInstance();
      this.cwsConfigurationOverviewDao = CwsConfigurationOverviewDao.getInstance();
   }

   protected <T> Map<T, Map> buildAttributesTree(final List<CwsMetaCol> configuratieAttribuutList, final Function<CwsMetaCol, T> treeNodeObjectFunction) {
      Map<Long, Map> childHolderMap = new LinkedHashMap<>();
      Map<T, Map> rootMap = new LinkedHashMap<>();
      configuratieAttribuutList.forEach(attribute -> childHolderMap.put(attribute.getMetaColId(), new LinkedHashMap<T, Map>()));
      configuratieAttribuutList.forEach(attribute -> {
         Map<T, Map> childrenHolderObject = childHolderMap.get(attribute.getMetaColId());
         if (attribute.getParentId() == 0) {
            rootMap.put(treeNodeObjectFunction.apply(attribute), childrenHolderObject);
         } else {
            Map<T, Map> parentObject = childHolderMap.get(attribute.getParentId());
            parentObject.put(treeNodeObjectFunction.apply(attribute), childrenHolderObject);
         }
      });
      return rootMap;
   }

   protected Map<String, Map> buildAttributesTree(final List<CwsMetaCol> cwsMetaColList) {
      return buildAttributesTree(cwsMetaColList, cwsMetaCol -> cwsMetaCol.getTechNaam().toUpperCase());
   }

   protected String getCleanFunctionalNameLowerCased(final String name){
      return name
            .replace("(","")
            .replace(")", "")
            .replaceAll("\\s","")
            .toLowerCase();
   }
}
