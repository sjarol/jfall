PWS-CWS
====================

Polis+ Configrable Webservice
---------------------------
Deze module bevat de het cwsConfiguration scherm voor CWS leveringen.

## Installation
To create a production build, you can run:
```bash
mvn clean package -Pproduction
```
