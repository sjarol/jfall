import groovy.json.JsonSlurper
import org.jenkinsci.plugins.pipeline.modeldefinition.Utils
def NODE_LABEL = (env.node == null ? "aix-regular-build" : env.node)
def recipients = env.recipients
def repository = env.repo
def testAutomationRepository = env.testAutomationRepository
def testAutomationBranch = (env.testAutomationBranch == null ? "master" : env.testAutomationBranch)
def testDirName = env.testDirName
def testProjectToRun = env.testProjectToRun
def credentials = env.credentials
// Check of de branch al begint met origin/. Dit kan de Jenkins git choice plugin doen.
// Als dat niet zo is, dan ervoor zetten zodat de build ook goed gaat met origin/ ervoor.
def branch = (branch.substring(0,branch.indexOf('/')+1) == "origin/" ? env.branch : "origin/" + env.branch)
def pom = (env.pom == null ? "pom.xml" : env.pom)
def sonarpom = (env.sonarpom == null ? "${pom}" : env.sonarpom)
def settings = (env.settings == null ? "o2-settings" : env.settings)
def profiles = (env.profiles == null ? "" : env.profiles)
def disablePipeline = env.disablePipeline
def reportDir = env.reportDir
def xlDeployUrl = env.xlDeployUrl
def jenkinsUrl = env.jenkinsUrl
// Aparte variabele serverCred voor deploy naar welke omgeving, Ontwikkel of Test.
// Dat zijn aparte "server credentials" omdat het verschillende servers zijn.
// Gebruik waardes Ontwikkel of Test als waarde voor xldEnv in de job parameters
def serverCred = (xldEnv.toLowerCase() == "ontwikkel" ? "XL Deploy OTOD O DXC" : "XL Deploy OTOD T DXC")

STEPS = "+scm+build+sonar+publish+deploy+automation" + (env.steps == null ? "" : env.steps)
boolean IS_SET(String s) {
	return STEPS.contains(s) && !STEPS.contains("-" + s)
}

node ("${NODE_LABEL}") {
	sh "echo \$(pwd)"
	if(disablePipeline == 'true'){
		echo "pipeline has been disabled, set property disablePipeline to false to enable the pipeline"
	}else {
		try {
			// Make CWS-DB check optional if skipcwsdb is explicitly set in "steps".
			if (!IS_SET('skipcwsdb')) { 
				stage('CWS-DB installed?'){
					def cwsDbJobStatus = getJobStatus("CI/job/CWS/job/CWS-Database/job/CWS-DB")
					if(cwsDbJobStatus == "SUCCESS" || cwsDbJobStatus == "UNSTABLE"){
						echo "cwsDbJobStatus ${cwsDbJobStatus}"
					}else{
						error "CWS-DB was not installed successfully, quitting pipeline."
					}
				}
			}

			stage('SCM checkout') {
				if (IS_SET('scm')) {
					if (repository.contains("git")) {
						checkout([$class                           : 'GitSCM',
								  branches                         : [[name: "${branch}"]],
								  doGenerateSubmoduleConfigurations: false,
								  extensions                       : [[$class: 'CleanCheckout']], submoduleCfg: [],
								  userRemoteConfigs                : [
										  [credentialsId: "${credentials}",
										   url          : "${repository}"]
								  ]
						])
					} else if (repository.contains("svn")) {
						checkout([$class        : 'SubversionSCM',
								  locations     : [[cancelProcessOnExternalsFail: true,
													credentialsId               : "${credentials}", local: '.',
													remote                      : "${repository}/${branch}"
												   ]],
								  quietOperation: true, workspaceUpdater: [$class: 'CheckoutUpdater']
						])
					}
				}
			}

			stage('Maven build') {
				if (IS_SET('build')) {
					sleep(1)
					withMaven(maven: 'Maven', mavenSettingsConfig: "${settings}") {
						sh "mvn clean install ${profiles} -DskipTests -f ${pom}"
					}
				}
			}

			stage('Test with coverage') {
				if (IS_SET('build')) {
					withMaven(maven: 'Maven', mavenSettingsConfig: "${settings}") {
						sh "mvn test -Psonar ${profiles} -fn -f ${pom}"
					}
				}
			}

			stage('Integration-test') {
				echo "skip integration-test -f ${pom}"
				Utils.markStageSkippedForConditional('Integration-test')
			}

			stage('SonarQube analysis') {
				if (IS_SET('sonar')) {
					withSonarQubeEnv('Sonar') {
						withMaven(maven: 'Maven', mavenSettingsConfig: "${settings}") {
							sh "mvn sonar:sonar -fae -Psonar ${profiles} -DfailIfNoTests=false -f ${sonarpom}"
						}
					}
				}
			}

			stage("Quality Gate") {
				if (IS_SET('sonar')) {
					sleep(12)
					timeout(time: 5, unit: 'MINUTES') {

						try {
							waitForQualityGate()
						}
						catch (err) {
							// do nothing
						}
					}
					timeout(time: 20, unit: 'SECONDS') {
						def qg = waitForQualityGate()
						if (qg.status != 'OK') {
							error "Pipeline aborted due to quality gate failure: ${qg.status}"
							//currentBuild.result = 'FAILURE'
							//Utils.markStageFailedAndContinued('Quality Gate')
							//return
						}
						// Status can only be demoted: SUCCESS -> UNSTABLE -> FAILURE
						echo "Pipeline quality gate succeeded: ${qg.status}"
					}
				}
			}

			stage('Publish artifacts') {
				if (IS_SET('publish')) {
				    // Credential is anders voor Ontwikkel en Test. Selecteer o.b.v. de xldEnv waarde. Default Test.
					def DARFILE = findFiles(glob: '**/*.dar')[0].path
					//def manifest = findFiles(glob: '**/deployit-manifest.xml')[0].path
					echo "DAR found: ${DARFILE}"
					xldPublishPackage serverCredentials: serverCred, darPath: DARFILE
				}
			}

			stage('Deploy application') {
				def deployit = "${xlDeployUrl}/deployit/repository"
				def APPID = env.application
				// environment can be a comma separated list, trim leading or trailing spaces.
				def TARGETS_INPUT = environment.split("\\s*,\\s*")
				// Environment inputs have to be checked first. Define new list for the resulting environments.
				def List<String> TARGETS_OUTPUT = []
				def VERSION_ID = (env.version == null ? "lastVersion" : env.version)
				

				if (IS_SET('deploy')) {
					// Voor zowel XL Deploy O als XL Deploy T kan dezelfde credential gebruikt worden.
					withCredentials([usernamePassword(credentialsId: "b2b43254-207b-46d0-bc10-202c3606d781",
							passwordVariable: 'PASS', usernameVariable: 'USER')]) {
						def cred = "--user $USER:$PASS"
						def opts = "-i -X GET  -H 'Accept: application/json'"
						// Retrieve application
						if (!APPID.contains("Applications/")) {
							def output = sh(returnStdout: true,
									script: "curl -k $cred \'$deployit/query?namePattern=$APPID&type=udm.Application\' $opts")
							output.readLines().findResult { line ->
								if (line =~ /^\[\{/) {
									println "Application : " + line
									def result = new JsonSlurper().parseText(line)
									APPID = result.ref[0]
								}
							}
						}
						// Retrieve last version
						if ("lastVersion".contains(VERSION_ID)) {
							def ref = APPID.replaceAll(" ", "%20")
							def output = sh(returnStdout: true,
									script: "curl -k $cred \'$deployit/ci/$ref\' $opts")
							output.readLines().findResult { line ->
								if (line =~ /^\{/) {
									println "item : " + line
									def result = new JsonSlurper().parseText(line)
									println "lastVersion : " + result.lastVersion
									VERSION_ID = result.lastVersion
								}
							}
						}
						// Retrieve environment(s). Allow for comma separated list of environments
						for (target in TARGETS_INPUT) {
							if (!target.contains("Environments/")) {
								ref = target.replaceAll(" ", "%20")
								def output = sh(returnStdout: true,
										script: "curl -k $cred \'$deployit/query?namePattern=$ref&type=udm.Environment\' $opts")
								output.readLines().findResult { line ->
									if (line =~ /^\[\{/) {
										println "Environment : " + line
										def result = new JsonSlurper().parseText(line)
										TARGETS_OUTPUT.add(result)
									}
								}
							}
							else {
								println "Environment : " + target
								TARGETS_OUTPUT.add(target)
							}
						}
					}
					
					for (target_output in TARGETS_OUTPUT) {
						xldDeploy serverCredentials: serverCred,
								//environmentId: 'Environments/Gegevensdiensten/POLIS LEVEREN/Bulk/Ontwikkel/O2AIX Bulk',
								//packageId: 'Applications/Gegevensdiensten/POLIS LEVEREN/JENKINS_TEST/test/1.0-20200115155615'
								environmentId: target_output, packageId: APPID + "/" + VERSION_ID					
					}


				}
			}

			if (IS_SET('automation')) {
				stage('Prepare for Test automation') {
					def directoryExists = fileExists "${testDirName}"
					if (directoryExists) {
						echo "Directory ${testDirName} exists, about to delete it"

						dir("${testDirName}") {
							deleteDir()
							echo "Deleted directory ${testDirName}"
						}
					}

					sh "mkdir -p ${testDirName}"
					echo "Directory ${testDirName} created"
				}

				stage('SCM checkout Test automation') {
					dir("${testDirName}") {
						checkout([$class                           : 'GitSCM',
								  branches                         : [[name: "${testAutomationBranch}"]],
								  doGenerateSubmoduleConfigurations: false,
								  extensions                       : [[$class: 'CleanCheckout']],
								  userRemoteConfigs                : [
										  [credentialsId: "${credentials}",
										   url          : "${testAutomationRepository}"]]
						])

						withMaven(maven: 'Maven', mavenSettingsConfig: "${settings}") {

							echo "Building test automation checked out from: ${testAutomationRepository}"
							sh "echo \$(pwd)"
							sh "mvn clean install -DskipTests -f ${pom}"
						}
					}
				}

				stage('Build and run Test automation') {
					dir("${testDirName}") {
						withMaven(maven: 'Maven', mavenSettingsConfig: "${settings}") {

							echo "Build and run test project in: ${testDirName}"
							dir("${testProjectToRun}") {
								try{
									sh "mvn clean verify -f ${pom}"
								}finally{
									publishSerenity("${reportDir}")
								}
							}
						}
					}
				}
			}
		} catch (e) {
			echo "Stack trace ${e}"
			currentBuild.result = "FAILED"

		} finally {
			if (sendRecoveredNotification() || currentBuild.currentResult != "SUCCESS") {
				notifyByEmail("${recipients}")
			}
		}
	}
}

def publishSerenity(String reportDir){
	publishHTML([
			allowMissing: false,
			alwaysLinkToLastBuild: false,
			keepAll: false,
			reportDir: "$reportDir",
			reportFiles: 'index.html',
			reportName: 'Serenity Report',
			reportTitles: ''])
}

def sendRecoveredNotification(){
	return currentBuild.getPreviousBuild().getResult().toString() != "SUCCESS" && currentBuild.currentResult == "SUCCESS"
}


def notifyByEmail(String recipients) {
	def status, logRegex, body

	switch (currentBuild.currentResult) {
		case 'SUCCESS':
			status = 'succeeded'
			logRegex = 'SUCCESS'
			break

		case 'UNSTABLE':
			status = 'unstable'
			logRegex = 'FAILURE'
			break

		case 'FAILURE':
			status = 'failed'
			logRegex = 'FAILURE'
			break

		case 'ABORTED':
			status = 'canceled'
			logRegex = 'ABORTED'
			break

	}

	if (sendRecoveredNotification()) {
		body = """ <p> Build is back to normal on Job:
            <a style = "font-size:14px;text-decoration:underline;font-weight:bold" href="${BUILD_URL}/console">${
			JOB_NAME
		} - build# ${BUILD_NUMBER} </a></p>
            <p> <pre> \${BUILD_LOG_REGEX, regex = "^.*?$logRegex.*?\$", linesBefore = 25, linesAfter = 150, maxMatches = 10, showTruncatedLines = false, escapeHtml = false} </pre></p> """

	}else{
		body = """ <p> Build $status on Job:
            <a style = "font-size:14px;text-decoration:underline;font-weight:bold" href="${BUILD_URL}/console">${
			JOB_NAME
		} - build# ${BUILD_NUMBER} </a></p>
            <p> <pre> \${BUILD_LOG_REGEX, regex = "^.*?$logRegex.*?\$", linesBefore = 25, linesAfter = 150, maxMatches = 10, showTruncatedLines = false, escapeHtml = false} $recipients</pre></p> """
	}


	emailext(subject: "Build $status - ${JOB_NAME} #${BUILD_NUMBER} "
			, body: "${body}"
			, mimeType: 'text/html'
			, from: '"Jenkins server" <noreply.jenkins@uwv.nl>'
			, recipientProviders: [[$class: 'DevelopersRecipientProvider']]
			, to: "$recipients")
}

def getJobStatus(String jobName){
	def cwsDbBuildInfo = httpRequest "${jenkinsUrl}/job/${jobName}/lastBuild/api/json"
	echo "cwsDbBuildInfo reponse ${cwsDbBuildInfo}"
	def responseAsJson = new JsonSlurper().parseText(cwsDbBuildInfo.getContent())
	return responseAsJson['result']
}
