#!/bin/bash

git svn rebase
