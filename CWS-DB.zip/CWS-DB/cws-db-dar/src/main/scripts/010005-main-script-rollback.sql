SET echo OFF
SET define ON
SET verify OFF
SET serveroutput ON
SET sqlblanklines ON

WHENEVER SQLERROR EXIT SQL.SQLCODE
WHENEVER OSERROR  EXIT FAILURE

PROMPT Start rollback cws-db-1.0.5

PROMPT Start 999-registreer_versie_in_database-rollback.sql
@@./010005/uninstall/999-registreer_versie_in_database-rollback.sql

-- ppls_cws00
PROMPT Start 10-cwshr_configuraties-rollback.sql
@@./010005/uninstall/ppls_cws00/010-cwshr_configuraties-rollback.sql
PROMPT Start 004-alter_cws_configuratie-rollback.sql
@@./010005/uninstall/ppls_cws00/004-alter_cws_configuratie-rollback.sql
PROMPT Start 003-vul_cws_lev_filter-rollback.sql
@@./010005/uninstall/ppls_cws00/003-vul_cws_lev_filter-rollback.sql
PROMPT Start 002-vul_cws_meta_col-rollback.sql
@@./010005/uninstall/ppls_cws00/002-vul_cws_meta_col-rollback.sql
PROMPT Start 001-vul_cws_meta_root-rollback.sql
@@./010005/uninstall/ppls_cws00/001-vul_cws_meta_root-rollback.sql

-- ppls_cws04
PROMPT Start 001-create_user-rollback.sql
@@./010005/uninstall/ppls_cws04/001-create_user-rollback.sql

-- scalaafn: Levering type niet verwijderen ivm mogelijk bestaan child records na draaien levering

-- scalameta
PROMPT Start 002-columnx-rollback.sql
@@./010005/uninstall/scalameta/002-columnx-rollback.sql
PROMPT Start 001-domainx-rollback.sql
@@./010005/uninstall/scalameta/001-domainx-rollback.sql

commit;
PROMPT Einde rollback cws-db-1.0.5