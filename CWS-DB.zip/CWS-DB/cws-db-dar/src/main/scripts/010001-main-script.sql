SET echo OFF
SET define ON
SET verify OFF
SET serveroutput ON
SET sqlblanklines ON

WHENEVER SQLERROR EXIT SQL.SQLCODE
WHENEVER OSERROR  EXIT FAILURE

--XL Deploy Checksum:42a6f7cae245f9f5ddbb362cfe11dd66--

PROMPT Start install cws-db-1.0.1
PROMPT Start alter_cws_configuratie.sql
@@./010001/install/ppls_cws00/alter_cws_configuratie.sql
PROMPT Start 999-registreer_versie_in_database.sql
@@./010001/install/999-registreer_versie_in_database.sql

commit;
PROMPT Einde install cws-db-1.0.1