delete from scalalever.lev_prop_values where prop_id in (select prop_id from scalalever.lev_properties where lev_cd='CWS-LA' and prop_naam='transformer.berichtversie.max');
delete from scalalever.lev_properties where lev_cd='CWS-LA' and prop_naam='transformer.berichtversie.max';
