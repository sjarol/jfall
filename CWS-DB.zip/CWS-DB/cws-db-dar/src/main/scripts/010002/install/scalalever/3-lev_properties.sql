INSERT INTO scalalever.lev_properties (
    prop_id,
    lev_cd,
    prop_naam,
    his_ts_in,
    his_ts_end,
    prop_type,
    datatype,
    required,
    format,
    his_days_keep,
    his_rows_keep,
    omschr
) VALUES (
    SCALALEVER.LEV_PROPERTIES_SEQ.NEXTVAL,
    'CWS-LA',
    'transformer.berichtversie.max',
    systimestamp,
    to_timestamp('31129999', 'DDMMYYYY'),
    'F',
    'STRING',
    'J',
    '0000',
    null,
    null,
    'Naar welke berichtversie maximaal getransformeerd moet worden'
);

COMMIT;

declare
    l_err_message varchar2(512);
begin
    l_err_message := NULL;
    SCALALEVER.LEV_PROP.SET_PROPERTY('CWS-LA','transformer.berichtversie.max', '0009', 'Automatisch door CWS-DB package ingesteld', systimestamp, l_err_message);
    IF l_err_message IS NOT NULL THEN
        raise_application_error(-20001, l_err_message);
    END IF;
end;
/
