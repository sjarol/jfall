SET echo OFF
SET define ON
SET verify OFF
SET serveroutput ON
SET sqlblanklines ON

WHENEVER SQLERROR EXIT SQL.SQLCODE
WHENEVER OSERROR  EXIT FAILURE

--XL Deploy Checksum:60264145c4fe5aaf8fa49c81b97967c7--

PROMPT Start install cws-db-1.3.0

-- ppls_cws00
PROMPT Start 001-vul_cws_meta_root.sql
@@./010300/install/ppls_cws00/001-vul_cws_meta_root.sql
PROMPT Start 002-vul_cws_meta_col.sql
@@./010300/install/ppls_cws00/002-vul_cws_meta_col.sql

-- scalalever
PROMPT Start 001-lev_properties.sql
@@./010300/install/scalalever/001-lev_properties.sql


PROMPT Start 999-registreer_versie_in_database.sql
@@./010300/install/999-registreer_versie_in_database.sql

commit;
PROMPT Einde install cws-db-1.3.0
