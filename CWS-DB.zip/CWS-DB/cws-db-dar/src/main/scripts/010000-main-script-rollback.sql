SET echo OFF
SET define ON
SET verify OFF
SET serveroutput ON
SET sqlblanklines ON

WHENEVER SQLERROR EXIT SQL.SQLCODE
WHENEVER OSERROR  EXIT FAILURE

PROMPT Start rollback cws-db-1.0.0
PROMPT Start 999-registreer_versie_in_database-rollback.sql
@@./010000/uninstall/999-registreer_versie_in_database-rollback.sql
PROMPT Start 7-alter_en_vul_cws_con_col-rollback.sql
@@./010000/uninstall/ppls_cws00/7-alter_en_vul_cws_con_col-rollback.sql
PROMPT Start 6-alter_en_vul_cws_configuratie-rollback.sql
@@./010000/uninstall/ppls_cws00/6-alter_en_vul_cws_configuratie-rollback.sql
PROMPT Start 3-cws_meta_col-rollback.sql
@@./010000/uninstall/ppls_cws00/3-cws_meta_col-rollback.sql
PROMPT Start 1-cws_meta_root-rollback.sql
@@./010000/uninstall/ppls_cws00/1-cws_meta_root-rollback.sql

commit;
PROMPT Einde rollback cws-db-1.0.0