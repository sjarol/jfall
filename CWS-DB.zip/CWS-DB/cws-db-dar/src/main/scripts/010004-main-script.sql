SET echo OFF
SET define ON
SET verify OFF
SET serveroutput ON
SET sqlblanklines ON

WHENEVER SQLERROR EXIT SQL.SQLCODE
WHENEVER OSERROR  EXIT FAILURE

--XL Deploy Checksum:72f95380e7f093701080d18915b994d1--

PROMPT Start install cws-db-1.0.4

PROMPT Start 1-create_user.sql
@@./010004/install/ppls_cws01/1-create_user.sql
PROMPT Start 2-grants.sql
@@./010004/install/ppls_cws01/2-grants.sql
PROMPT Start 3-synoniemen.sql
@@./010004/install/ppls_cws01/3-synoniemen.sql
PROMPT Start 999-registreer_versie_in_database.sql
@@./010004/install/999-registreer_versie_in_database.sql

commit;
PROMPT Einde install cws-db-1.0.4
