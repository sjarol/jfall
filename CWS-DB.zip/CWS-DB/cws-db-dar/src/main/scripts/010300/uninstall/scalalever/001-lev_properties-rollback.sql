delete from scalalever.lev_prop_values where prop_id in (select prop_id from scalalever.lev_properties where lev_cd='CWS-NP' and prop_naam='transformer.cwsnp.berichtversie.max');
delete from scalalever.lev_properties where lev_cd='CWS-NP' and prop_naam='transformer.cwsnp.berichtversie.max';

delete from scalalever.lev_prop_values where prop_id in (select prop_id from scalalever.lev_properties where lev_cd='CWS-HR' and prop_naam='transformer.cwshr.berichtversie.max');
delete from scalalever.lev_properties where lev_cd='CWS-HR' and prop_naam='transformer.cwshr.berichtversie.max';
COMMIT;