SET echo OFF
SET define ON
SET verify OFF
SET serveroutput ON
SET sqlblanklines ON

WHENEVER SQLERROR EXIT SQL.SQLCODE
WHENEVER OSERROR  EXIT FAILURE

PROMPT Start rollback cws-db-1.2.0

PROMPT Start 999-registreer_versie_in_database-rollback.sql
@@./010200/uninstall/999-registreer_versie_in_database-rollback.sql

-- ppls_cws00
PROMPT Start 10-cwswg_configuraties-rollback.sql
@@./010200/uninstall/ppls_cws00/010-cwswg_configuraties-rollback.sql

PROMPT Start 003-vul_cws_lev_filter-rollback.sql
@@./010200/uninstall/ppls_cws00/003-vul_cws_lev_filter-rollback.sql
PROMPT Start 002-vul_cws_meta_col-rollback.sql
@@./010200/uninstall/ppls_cws00/002-vul_cws_meta_col-rollback.sql
PROMPT Start 001-vul_cws_meta_root-rollback.sql
@@./010200/uninstall/ppls_cws00/001-vul_cws_meta_root-rollback.sql

-- ppls_cws05
PROMPT Start 001-create_user-rollback.sql
@@./010200/uninstall/ppls_cws05/001-create_user-rollback.sql

-- scalaafn: Levering type niet verwijderen ivm mogelijk bestaan child records na draaien levering

-- scalameta
PROMPT Start 001-columnx-rollback.sql
@@./010200/uninstall/scalameta/001-columnx-rollback.sql

-- scalaref
PROMPT Start afn_levering_type.sql
@@./010200/uninstall/scalaref/ref_transactietype_afh-rollback.sql
@@./010200/uninstall/scalaref/ref_transactietype-rollback.sql

commit;
PROMPT Einde rollback cws-db-1.2.0