SET echo OFF
SET define ON
SET verify OFF
SET serveroutput ON
SET sqlblanklines ON

WHENEVER SQLERROR EXIT SQL.SQLCODE
WHENEVER OSERROR  EXIT FAILURE

--XL Deploy Checksum:56d21e23269fbf6d1de39d35cad85e3e--

PROMPT Start install cws-db-1.2.0

-- ppls_cws00
PROMPT Start 001-vul_cws_meta_root.sql
@@./010200/install/ppls_cws00/001-vul_cws_meta_root.sql
PROMPT Start 002-vul_cws_meta_col.sql
@@./010200/install/ppls_cws00/002-vul_cws_meta_col.sql
PROMPT Start 003-vul_cws_lev_filter.sql
@@./010200/install/ppls_cws00/003-vul_cws_lev_filter.sql

-- ppls_cws05
PROMPT Start 001-create_user.sql
@@./010200/install/ppls_cws05/001-create_user.sql

PROMPT Start 002-grants.sql
@@./010200/install/ppls_cws05/002-grants.sql
PROMPT Start 003-synoniemen.sql
@@./010200/install/ppls_cws05/003-synoniemen.sql

-- scalaafn
PROMPT Start afn_levering_type.sql
@@./010200/install/scalaafn/afn_levering_type.sql

-- scalameta
PROMPT Start 001_columnx.sql
@@./010200/install/scalameta/001-columnx.sql

-- scalaref
PROMPT Start afn_levering_type.sql
@@./010200/install/scalaref/ref_transactietype.sql
@@./010200/install/scalaref/ref_transactietype_afh.sql


PROMPT Start 999-registreer_versie_in_database.sql
@@./010200/install/999-registreer_versie_in_database.sql

commit;
PROMPT Einde install cws-db-1.2.0
