--ALTER TABLE PPLS_CWS00.CWS_META_RUBRIEKNR_GBA
--RENAME COLUMN CWSMETA_ID TO META_COL_ID;

DECLARE

    PROCEDURE rename_column(table_name IN VARCHAR2, column_name_old IN VARCHAR2, column_name_new IN VARCHAR2) IS
	    v_sql_stmnt VARCHAR2(512);
	    e_column_oud_al_verwijderd EXCEPTION;
	    PRAGMA EXCEPTION_INIT(e_column_oud_al_verwijderd, -00904);
		e_column_nieuw_al_aanwezig EXCEPTION;
	    PRAGMA EXCEPTION_INIT(e_column_nieuw_al_aanwezig, -00957);
	BEGIN
    	v_sql_stmnt := 'ALTER TABLE '||table_name||' RENAME COLUMN '||column_name_old || ' TO ' || column_name_new;
    	execute immediate v_sql_stmnt;
		dbms_output.put_line ('De kolom ' || column_name_old || ' in tabel ' || table_name || ' is succesvol hernoemd naar ' || column_name_new);
	EXCEPTION
        WHEN e_column_oud_al_verwijderd THEN
        dbms_output.put_line ('De oude kolom ' || column_name_old || ' is niet meer aanwezig in tabel ' || table_name);
        WHEN e_column_nieuw_al_aanwezig THEN
        dbms_output.put_line ('De nieuwe kolom ' || column_name_new || ' is al aanwezig in tabel ' || table_name);
    END;

BEGIN
	rename_column('PPLS_CWS00.CWS_META_RUBRIEKNR_GBA', 'CWSMETA_ID', 'META_COL_ID');
END;
/