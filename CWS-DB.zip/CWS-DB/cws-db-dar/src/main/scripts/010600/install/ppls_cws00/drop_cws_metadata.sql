--DROP TABLE PPLS_CWS00.CWS_METADATA CASCADE CONSTRAINTS;

DECLARE

    PROCEDURE drop_table(table_name IN VARCHAR2) IS
	    v_sql_stmnt VARCHAR2(512);
	    e_table_al_verwijderd EXCEPTION;
	    PRAGMA EXCEPTION_INIT(e_table_al_verwijderd, -00942);
	BEGIN
    	v_sql_stmnt := 'DROP TABLE '||table_name||' CASCADE CONSTRAINTS';
    	execute immediate v_sql_stmnt;
		dbms_output.put_line ('De tabel ' || table_name || ' is succesvol verwijderd');
	EXCEPTION
        WHEN e_table_al_verwijderd THEN
        dbms_output.put_line ('De tabel ' || table_name || ' is al verwijderd');
    END;

    PROCEDURE drop_sequence(sequence_name IN VARCHAR2) IS
	    v_sql_stmnt VARCHAR2(512);
	    e_sequence_al_verwijderd EXCEPTION;
	    PRAGMA EXCEPTION_INIT(e_sequence_al_verwijderd, -02289);
	BEGIN
    	v_sql_stmnt := 'DROP SEQUENCE '||sequence_name;
    	execute immediate v_sql_stmnt;
		dbms_output.put_line ('De sequence ' || sequence_name || ' is succesvol verwijderd');
	EXCEPTION
        WHEN e_sequence_al_verwijderd THEN
        dbms_output.put_line ('De sequence ' || sequence_name || ' is al verwijderd');
    END;

BEGIN
	drop_table('PPLS_CWS00.CWS_METADATA');
	drop_sequence('PPLS_CWS00.CWSMETA_ID_SEQ');
END;
/
