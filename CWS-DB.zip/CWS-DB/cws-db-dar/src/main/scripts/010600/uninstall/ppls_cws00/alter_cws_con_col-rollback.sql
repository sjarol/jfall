DECLARE
    PROCEDURE add_column_cwsmeta_id(table_name IN VARCHAR2) IS
	    v_sql_stmnt VARCHAR2(512);
	    e_column_al_toegevoegd EXCEPTION;
	    PRAGMA EXCEPTION_INIT(e_column_al_toegevoegd, -01430);
	BEGIN
    	v_sql_stmnt := 'ALTER TABLE '||table_name||' ADD CWSMETA_ID NUMBER(12,0)';
    	execute immediate v_sql_stmnt;
		dbms_output.put_line ('De kolom CWSMETA_ID is succesvol toegevoegd aan tabel ' || table_name);
	EXCEPTION
        WHEN e_column_al_toegevoegd THEN
        dbms_output.put_line ('De kolom CWSMETA_ID was al toegevoegd aan tabel ' || table_name);
    END;
BEGIN
--ALTER TABLE PPLS_CWS00.CWS_CON_COL
--ADD CWSMETA_ID NUMBER(12,0);
	add_column_cwsmeta_id('PPLS_CWS00.CWS_CON_COL');
END;
/

UPDATE PPLS_CWS00.CWS_CON_COL
SET CWSMETA_ID = META_COL_ID;
COMMIT;

DECLARE
    PROCEDURE modify_column_not_null(table_name IN VARCHAR2, column_name IN VARCHAR2) IS
	    v_sql_stmnt VARCHAR2(512);
	    e_column_al_not_null EXCEPTION;
	    PRAGMA EXCEPTION_INIT(e_column_al_not_null, -01442);
	BEGIN
    	v_sql_stmnt := 'ALTER TABLE '||table_name||' MODIFY ' || column_name || ' NOT NULL';
    	execute immediate v_sql_stmnt;
		dbms_output.put_line ('De kolom ' || column_name || ' is succesvol NOT NULL gemaakt in tabel ' || table_name);
	EXCEPTION
        WHEN e_column_al_not_null THEN
        dbms_output.put_line ('De kolom ' || column_name || ' was al NOT NULL gemaakt in tabel ' || table_name);
    END;
BEGIN
--ALTER TABLE PPLS_CWS00.CWS_CON_COL
--MODIFY CWSMETA_ID NOT NULL;
    modify_column_not_null('PPLS_CWS00.CWS_CON_COL','CWSMETA_ID');
END;
/