--ALTER TABLE PPLS_CWS00.CWS_DATAMONITOR
--ADD BSN NUMBER(10,0);

-- UPDATE PPLS_CWS00.CWS_DATAMONITOR
-- SET BSN = IDENTIFIER;

--ALTER TABLE PPLS_CWS00.CWS_DATAMONITOR
--DROP COLUMN IDENTIFIER;

DECLARE

    PROCEDURE add_column(table_name IN VARCHAR2, column_name IN VARCHAR2, column_type IN VARCHAR2) IS
	    v_sql_stmnt VARCHAR2(512);
	    e_column_al_toegevoegd EXCEPTION;
	    PRAGMA EXCEPTION_INIT(e_column_al_toegevoegd, -01430);
	BEGIN
    	v_sql_stmnt := 'ALTER TABLE '||table_name||' ADD ' || column_name || ' ' ||  column_type;
    	execute immediate v_sql_stmnt;
		dbms_output.put_line ('De kolom ' || column_name || ' is succesvol toegevoegd aan tabel ' || table_name);
	EXCEPTION
        WHEN e_column_al_toegevoegd THEN
        dbms_output.put_line ('De kolom ' || column_name || ' was al toegevoegd aan tabel ' || table_name);
    END;

    PROCEDURE drop_column(table_name IN VARCHAR2, column_name IN VARCHAR2) IS
	    v_sql_stmnt VARCHAR2(512);
	    e_column_al_verwijderd EXCEPTION;
	    PRAGMA EXCEPTION_INIT(e_column_al_verwijderd, -00904);
	BEGIN
    	v_sql_stmnt := 'ALTER TABLE '||table_name||' DROP COLUMN '||column_name;
    	execute immediate v_sql_stmnt;
		dbms_output.put_line ('De kolom ' || column_name || ' in tabel ' || table_name || ' is succesvol verwijderd');
	EXCEPTION
        WHEN e_column_al_verwijderd THEN
        dbms_output.put_line ('De kolom ' || column_name || ' in tabel ' || table_name || ' is al verwijderd');
    END;

BEGIN
	add_column('PPLS_CWS00.CWS_DATAMONITOR', 'BSN', 'NUMBER(10,0)');
	execute immediate 'UPDATE PPLS_CWS00.CWS_DATAMONITOR SET BSN = IDENTIFIER';
	drop_column('PPLS_CWS00.CWS_DATAMONITOR', 'IDENTIFIER');
END;
/