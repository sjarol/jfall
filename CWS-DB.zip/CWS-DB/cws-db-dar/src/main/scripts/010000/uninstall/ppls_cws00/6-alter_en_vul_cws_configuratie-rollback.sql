DECLARE

    PROCEDURE drop_column(table_name IN VARCHAR2, column_name IN VARCHAR2) IS
	    v_sql_stmnt VARCHAR2(512);
	    e_column_al_verwijderd EXCEPTION;
	    PRAGMA EXCEPTION_INIT(e_column_al_verwijderd, -00904);
	BEGIN
    	v_sql_stmnt := 'ALTER TABLE '||table_name||' DROP COLUMN '||column_name;
    	execute immediate v_sql_stmnt;
	EXCEPTION
        WHEN e_column_al_verwijderd THEN
        dbms_output.put_line ('De kolom is al verwijderd');
    END;

    PROCEDURE drop_constraint(table_name IN VARCHAR2, constraint_name IN VARCHAR2) IS
	    v_sql_stmnt VARCHAR2(512);
	    e_constraint_al_verwijderd EXCEPTION;
	    PRAGMA EXCEPTION_INIT(e_constraint_al_verwijderd, -02443);
	BEGIN
    	v_sql_stmnt := 'ALTER TABLE '||table_name||' DROP CONSTRAINT '||constraint_name;
    	execute immediate v_sql_stmnt;
	EXCEPTION
        WHEN e_constraint_al_verwijderd THEN
        dbms_output.put_line ('De constraint is al verwijderd');
    END;

BEGIN
	drop_column('PPLS_CWS00.CWS_CONFIGURATIE', 'META_ROOT_ID');
    drop_constraint('PPLS_CWS00.CWS_CONFIGURATIE', 'CCON_ROOT');
END;
/
