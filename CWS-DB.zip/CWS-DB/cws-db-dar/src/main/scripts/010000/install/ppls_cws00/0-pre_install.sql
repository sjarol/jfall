-- Introduceer een nieuw id voor het PROGRAMMA ID DATABASE-CWS

MERGE INTO scalameta.program A USING
 (SELECT
  1701 AS pgrm_id,
  'DATABASE-CWS' AS name
  FROM DUAL) B
ON (A.pgrm_id = B.pgrm_id)
WHEN NOT MATCHED THEN 
INSERT (pgrm_id, name)
VALUES (B.pgrm_id, B.name)
;

UPDATE scaladiv.programma_versie 
SET pgrm_id = 1701
WHERE pgrm_id IN (SELECT pgrm_id FROM scalameta.program WHERE name = 'DATABASE-CWS')
AND pgrm_id <> 1701;

DELETE FROM scalameta.program
WHERE pgrm_id IN (SELECT pgrm_id FROM scalameta.program WHERE name = 'DATABASE-CWS')
AND pgrm_id <> 1701;

COMMIT;

