SET echo OFF
SET define ON
SET verify OFF
SET serveroutput ON
SET sqlblanklines ON

WHENEVER SQLERROR EXIT SQL.SQLCODE
WHENEVER OSERROR  EXIT FAILURE

PROMPT Start rollback cws-db-1.0.1
PROMPT Start 999-registreer_versie_in_database-rollback.sql
@@./010001/uninstall/999-registreer_versie_in_database-rollback.sql
PROMPT Start alter_cws_configuratie-rollback.sql
@@./010001/uninstall/ppls_cws00/alter_cws_configuratie-rollback.sql

commit;
PROMPT Einde rollback cws-db-1.0.1