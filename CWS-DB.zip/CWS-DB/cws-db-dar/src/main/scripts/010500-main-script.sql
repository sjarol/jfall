SET echo OFF
SET define ON
SET verify OFF
SET serveroutput ON
SET sqlblanklines ON

WHENEVER SQLERROR EXIT SQL.SQLCODE
WHENEVER OSERROR  EXIT FAILURE

--XL Deploy Checksum:f792862d95923c91910403e4398b256a--

PROMPT Start install cws-db-1.5.0

-- ppls_cws00
-- CWS-IHP
PROMPT Start 001-vul_cws_meta_root.sql
@@./010500/install/ppls_cws00/001-vul_cws_meta_root.sql
PROMPT Start 002-vul_cws_meta_col.sql
@@./010500/install/ppls_cws00/002-vul_cws_meta_col.sql
PROMPT Start 003-vul_cws_lev_filter.sql
@@./010500/install/ppls_cws00/003-vul_cws_lev_filter.sql

-- CWS-HR
PROMPT Start update_cws_meta_col.sql
@@./010500/install/ppls_cws00/update_cws_meta_col.sql

-- ppls_cws06
PROMPT Start 001-create_user.sql
@@./010500/install/ppls_cws06/001-create_user.sql
PROMPT Start 002-grants.sql ppls_cws06
@@./010500/install/ppls_cws06/002-grants.sql
PROMPT Start 003-synoniemen.sql ppls_cws06
@@./010500/install/ppls_cws06/003-synoniemen.sql

-- scalaafn
PROMPT Start afn_levering_type.sql
@@./010500/install/scalaafn/afn_levering_type.sql

-- scalalever
PROMPT Start 001-lev_properties.sql
@@./010500/install/scalalever/001-lev_properties.sql

-- scalaref
PROMPT Start afn_levering_type.sql
@@./010500/install/scalaref/ref_transactietype.sql
@@./010500/install/scalaref/ref_transactietype_afh.sql


PROMPT Start 999-registreer_versie_in_database.sql
@@./010500/install/999-registreer_versie_in_database.sql

commit;
PROMPT Einde install cws-db-1.5.0
