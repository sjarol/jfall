SET echo OFF
SET define ON
SET verify OFF
SET serveroutput ON
SET sqlblanklines ON

WHENEVER SQLERROR EXIT SQL.SQLCODE
WHENEVER OSERROR  EXIT FAILURE

PROMPT Start rollback cws-db-1.0.6

PROMPT Start 999-registreer_versie_in_database-rollback.sql
@@./010006/uninstall/999-registreer_versie_in_database-rollback.sql

-- ppls_cws00
PROMPT Start 010-cwsla_configuraties-rollback.sql
@@./010006/uninstall/ppls_cws00/010-cwsla_configuraties-rollback.sql
PROMPT Start 004-grants-rollback.sql
@@./010006/uninstall/ppls_cws00/004-grants-rollback.sql
PROMPT Start 003-synoniemen-rollback.sql
@@./010006/uninstall/ppls_cws00/003-synoniemen-rollback.sql
PROMPT Start 002-vul_cws_meta_col-rollback.sql
@@./010006/uninstall/ppls_cws00/002-vul_cws_meta_col-rollback.sql
PROMPT Start 001-vul_cws_meta_root-rollback.sql
@@./010006/uninstall/ppls_cws00/001-vul_cws_meta_root-rollback.sql

-- scalalever
PROMPT Start 001-lev_properties-rollback.sql
@@./010006/uninstall/scalalever/001-lev_properties-rollback.sql

commit;
PROMPT Einde rollback cws-db-1.0.6