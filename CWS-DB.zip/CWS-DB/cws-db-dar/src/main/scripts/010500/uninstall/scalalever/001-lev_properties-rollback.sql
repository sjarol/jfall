delete from scalalever.lev_prop_values where prop_id in (select prop_id from scalalever.lev_properties where lev_cd='CWS-IHP' and prop_naam='transformer.cwsihp.berichtversie.max');
delete from scalalever.lev_properties where lev_cd='CWS-IHP' and prop_naam='transformer.cwsihp.berichtversie.max';

delete from scalalever.lev_prop_values where prop_id in (select prop_id from scalalever.lev_properties where lev_cd='CWS-WG' and prop_naam='transformer.cwswg.berichtversie.max');
delete from scalalever.lev_properties where lev_cd='CWS-WG' and prop_naam='transformer.cwswg.berichtversie.max';

COMMIT;