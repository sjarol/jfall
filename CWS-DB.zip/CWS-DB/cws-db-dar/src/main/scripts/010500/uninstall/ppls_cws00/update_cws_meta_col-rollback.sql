UPDATE ppls_cws00.cws_meta_col
SET bron_rubriek = 'GESLACHTSNAAM'
WHERE meta_col_id = 13121
AND bron_rubriek = 'ACHTERNAAM';


commit;