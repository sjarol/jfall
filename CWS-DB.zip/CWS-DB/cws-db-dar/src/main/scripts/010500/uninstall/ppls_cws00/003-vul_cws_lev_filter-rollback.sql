delete from ppls_cws00.cws_lev_filter
where lev_cd = 'CWS-IHP' and tech_naam = 'BEEINDIGD_ADRES_UITSLUITEN_IHP';

commit;