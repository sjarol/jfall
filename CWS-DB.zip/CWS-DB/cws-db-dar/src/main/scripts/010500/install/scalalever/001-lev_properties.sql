MERGE INTO scalalever.lev_properties A USING
 (SELECT
  -- sequence voor prop_id kan pas bij de insert aangeroepen worden
  'CWS-IHP' as lev_cd,
  'transformer.cwsihp.berichtversie.max' as prop_naam,
  systimestamp as his_ts_in,
  to_timestamp('31129999', 'DDMMYYYY') as his_ts_end,
  'F' as prop_type,
  'STRING' as datatype,
  'J' as required,
  '0000' as format,
  null as his_days_keep,
  null as his_rows_keep,
  'Naar welke berichtversie voor CWS-IHP maximaal getransformeerd moet worden' as omschr
  FROM DUAL) B
ON (A.lev_cd = B.lev_cd and A.prop_naam = B.prop_naam and A.his_ts_end > systimestamp)
WHEN NOT MATCHED THEN 
INSERT (prop_id, lev_cd, prop_naam, his_ts_in, his_ts_end, prop_type, datatype, required, format, his_days_keep, his_rows_keep, omschr)
VALUES (SCALALEVER.LEV_PROPERTIES_SEQ.NEXTVAL, B.lev_cd, B.prop_naam, B.his_ts_in, B.his_ts_end, B.prop_type, B.datatype, B.required, B.format, B.his_days_keep, B.his_rows_keep, B.omschr)
;

MERGE INTO scalalever.lev_properties A USING
 (SELECT
  -- sequence voor prop_id kan pas bij de insert aangeroepen worden
  'CWS-WG' as lev_cd,
  'transformer.cwswg.berichtversie.max' as prop_naam,
  systimestamp as his_ts_in,
  to_timestamp('31129999', 'DDMMYYYY') as his_ts_end,
  'F' as prop_type,
  'STRING' as datatype,
  'J' as required,
  '0000' as format,
  null as his_days_keep,
  null as his_rows_keep,
  'Naar welke berichtversie voor CWS-WG maximaal getransformeerd moet worden' as omschr
  FROM DUAL) B
ON (A.lev_cd = B.lev_cd and A.prop_naam = B.prop_naam and A.his_ts_end > systimestamp)
WHEN NOT MATCHED THEN
INSERT (prop_id, lev_cd, prop_naam, his_ts_in, his_ts_end, prop_type, datatype, required, format, his_days_keep, his_rows_keep, omschr)
VALUES (SCALALEVER.LEV_PROPERTIES_SEQ.NEXTVAL, B.lev_cd, B.prop_naam, B.his_ts_in, B.his_ts_end, B.prop_type, B.datatype, B.required, B.format, B.his_days_keep, B.his_rows_keep, B.omschr);

COMMIT;

DECLARE
    l_err_message varchar2(512);
BEGIN
    l_err_message := NULL;
    scalalever.lev_prop.set_property('CWS-IHP','transformer.cwsihp.berichtversie.max', '0007', 'Automatisch door CWS-DB package ingesteld', systimestamp, l_err_message);
    IF l_err_message IS NOT NULL THEN
        raise_application_error(-20001, l_err_message);
    END IF;
END;
/

DECLARE
    l_err_message varchar2(512);
BEGIN
    l_err_message := NULL;
    scalalever.lev_prop.set_property('CWS-WG','transformer.cwswg.berichtversie.max', '0004', 'Automatisch door CWS-DB package ingesteld', systimestamp, l_err_message);
    IF l_err_message IS NOT NULL THEN
        raise_application_error(-20001, l_err_message);
    END IF;
END;
/

COMMIT;
