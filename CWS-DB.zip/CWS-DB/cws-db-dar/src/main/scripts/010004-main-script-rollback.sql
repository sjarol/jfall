SET echo OFF
SET define ON
SET verify OFF
SET serveroutput ON
SET sqlblanklines ON

WHENEVER SQLERROR EXIT SQL.SQLCODE
WHENEVER OSERROR  EXIT FAILURE

PROMPT Start rollback cws-db-1.0.4

PROMPT Start 999-registreer_versie_in_database-rollback.sql
@@./010004/uninstall/999-registreer_versie_in_database-rollback.sql
PROMPT Start 1-create_user-rollback.sql
@@./010004/uninstall/ppls_cws01/1-create_user-rollback.sql

commit;
PROMPT Einde rollback cws-db-1.0.4