SET echo OFF
SET define ON
SET verify OFF
SET serveroutput ON
SET sqlblanklines ON

WHENEVER SQLERROR EXIT SQL.SQLCODE
WHENEVER OSERROR  EXIT FAILURE

PROMPT Start rollback cws-db-1.0.3

PROMPT Start 999-registreer_versie_in_database-rollback.sql
@@./010003/uninstall/999-registreer_versie_in_database-rollback.sql

-- ppls_cws00
PROMPT Start 10-cwsnp_configuraties-rollback.sql
@@./010003/uninstall/ppls_cws00/10-cwsnp_configuraties-rollback.sql

PROMPT Start 8-cws_meta_rubrieknr_gba-rollback.sql
@@./010003/uninstall/ppls_cws00/8-cws_meta_rubrieknr_gba-rollback.sql
PROMPT Start 7-alter-cws_configuratie-rollback.sql
@@./010003/uninstall/ppls_cws00/7-alter-cws_configuratie-rollback.sql
PROMPT Start 5-cws_con_filter-rollback.sql
@@./010003/uninstall/ppls_cws00/5-cws_con_filter-rollback.sql
PROMPT Start 3-cws_lev_filter-rollback.sql
@@./010003/uninstall/ppls_cws00/3-cws_lev_filter-rollback.sql
PROMPT Start 2-vul_cws_meta_col-rollback.sql
@@./010003/uninstall/ppls_cws00/2-vul_cws_meta_col-rollback.sql
PROMPT Start 1-vul_cws_meta_root-rollback.sql
@@./010003/uninstall/ppls_cws00/1-vul_cws_meta_root-rollback.sql

-- ppls_cws03
PROMPT Start 001-create_user-rollback.sql
@@./010003/uninstall/ppls_cws03/001-create_user-rollback.sql

-- scalaafn: Levering type niet verwijderen ivm mogelijk bestaan child records na draaien levering

commit;
PROMPT Einde rollback cws-db-1.0.3