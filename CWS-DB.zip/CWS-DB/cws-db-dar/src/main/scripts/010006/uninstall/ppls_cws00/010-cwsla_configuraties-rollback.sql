-- verwijder eventueel aanwezige CWS-LA afnemer configuraties
delete from ppls_cws00.cws_con_filter
where ccon_id in (select ccon_id
                  from ppls_cws00.cws_configuratie cf
                  where cf.meta_root_id = (select meta_root_id
                                           from ppls_cws00.cws_meta_root
                                           where lev_cd = 'CWS-LA'
                                           and berichtversie = '0102'));

delete from ppls_cws00.cws_con_col
where ccon_id in (select ccon_id
                  from ppls_cws00.cws_configuratie cf
				  where cf.meta_root_id = (select meta_root_id
										   from ppls_cws00.cws_meta_root
										   where lev_cd = 'CWS-LA'
										   and berichtversie = '0102')
                 );

delete from ppls_cws00.cws_configuratie cf
where cf.meta_root_id = (select meta_root_id
						 from ppls_cws00.cws_meta_root
						 where lev_cd = 'CWS-LA'
						 and berichtversie = '0102');

commit;
