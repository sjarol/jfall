DECLARE
    PROCEDURE revoke_grant( grant_type IN VARCHAR2
                          , grant_object IN VARCHAR2
                          , grant_owner IN varchar2) IS
	    v_sql_stmnt VARCHAR2(512);
	    e_grant_al_verwijderd EXCEPTION;
	    PRAGMA EXCEPTION_INIT(e_grant_al_verwijderd, -01927);
	BEGIN
    	v_sql_stmnt := 'REVOKE '||grant_type||' ON '||grant_object||' FROM '||grant_owner;
    	execute immediate v_sql_stmnt;
		dbms_output.put_line ('De grant ' || grant_type || ' op ' || grant_owner || '.' || grant_object ||  ' is succesvol verwijderd');
	EXCEPTION
        WHEN e_grant_al_verwijderd THEN
        dbms_output.put_line ('De grant ' || grant_type || ' op ' || grant_owner || '.' || grant_object ||  ' is al verwijderd');
    END;

BEGIN
	revoke_grant('SELECT', 'SCALAWGA.WGA_AANGIFTEFREQUENTIE', 'PPLS_CWS00');
	revoke_grant('SELECT', 'SCALAWGA.WGA_AANGIFTEFREQUENTIE', 'PPLS_CWS01');
END;
/
