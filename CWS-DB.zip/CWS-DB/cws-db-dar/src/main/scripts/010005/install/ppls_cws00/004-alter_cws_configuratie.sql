COMMENT ON COLUMN ppls_cws00.cws_configuratie.contract_id IS 'Contract identificatie in UGC';
COMMENT ON COLUMN ppls_cws00.cws_configuratie.cont_his_dat_in IS 'Aanvangsdatum contract';
COMMENT ON COLUMN ppls_cws00.cws_configuratie.naam IS 'Configuratie naam';
COMMENT ON COLUMN ppls_cws00.cws_configuratie.his_dat_in IS 'Begindatum geledigheid';
COMMENT ON COLUMN ppls_cws00.cws_configuratie.his_dat_end IS 'Einddatum geldigheid (tot en met)';