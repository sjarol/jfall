-- verwijder meta root
delete from ppls_cws00.cws_meta_root
where lev_cd='CWS-HR' and berichtversie='0105';

commit;
