delete from ppls_cws00.cws_meta_col
where meta_root_id = (select meta_root_id from ppls_cws00.cws_meta_root where lev_cd='CWS-HR' and berichtversie='0105');

commit;
