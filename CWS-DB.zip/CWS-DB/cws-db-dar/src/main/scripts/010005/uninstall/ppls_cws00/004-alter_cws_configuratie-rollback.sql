COMMENT ON COLUMN ppls_cws00.cws_configuratie.contract_id IS '';
COMMENT ON COLUMN ppls_cws00.cws_configuratie.cont_his_dat_in IS '';
COMMENT ON COLUMN ppls_cws00.cws_configuratie.naam IS '';
COMMENT ON COLUMN ppls_cws00.cws_configuratie.his_dat_in IS 'Begindatum geledigheid, wordt afgeleid';
COMMENT ON COLUMN ppls_cws00.cws_configuratie.his_dat_end IS 'Einddatum geldigheid (tot), wordt afgeleid';