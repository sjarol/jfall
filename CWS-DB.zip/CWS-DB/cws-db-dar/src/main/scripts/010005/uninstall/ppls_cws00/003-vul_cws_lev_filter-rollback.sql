delete from ppls_cws00.cws_lev_filter
where lev_cd = 'CWS-HR' and tech_naam = 'BEEINDIGD_ADRES_UITSLUITEN';

commit;