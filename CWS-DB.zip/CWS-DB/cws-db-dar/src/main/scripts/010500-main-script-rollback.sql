SET echo OFF
SET define ON
SET verify OFF
SET serveroutput ON
SET sqlblanklines ON

WHENEVER SQLERROR EXIT SQL.SQLCODE
WHENEVER OSERROR  EXIT FAILURE

PROMPT Start rollback cws-db-1.5.0

PROMPT Start 999-registreer_versie_in_database-rollback.sql
@@./010500/uninstall/999-registreer_versie_in_database-rollback.sql

-- ppls_cws00
-- CWS-IHP
PROMPT Start 10-cwsihp_configuraties-rollback.sql
@@./010500/uninstall/ppls_cws00/010-cwsihp_configuraties-rollback.sql
PROMPT Start 003-vul_cws_lev_filter-rollback.sql
@@./010500/uninstall/ppls_cws00/003-vul_cws_lev_filter-rollback.sql
PROMPT Start 002-vul_cws_meta_col-rollback.sql
@@./010500/uninstall/ppls_cws00/002-vul_cws_meta_col-rollback.sql
PROMPT Start 001-vul_cws_meta_root-rollback.sql
@@./010500/uninstall/ppls_cws00/001-vul_cws_meta_root-rollback.sql

-- CWS-HR
PROMPT Start update_cws_meta_col-rollback.sql
@@./010500/uninstall/ppls_cws00/update_cws_meta_col-rollback.sql

-- ppls_cws06
PROMPT Start 001-create_user-rollback.sql ppls_cws06
@@./010500/uninstall/ppls_cws06/001-create_user-rollback.sql

-- scalaafn: Levering type niet verwijderen ivm mogelijk bestaan child records na draaien levering

-- scalalever
PROMPT Start 001-lev_properties-rollback.sql
@@./010500/uninstall/scalalever/001-lev_properties-rollback.sql

-- scalaref
PROMPT Start ref_transactietype_afh-rollback.sql
@@./010500/uninstall/scalaref/ref_transactietype_afh-rollback.sql
PROMPT Start ref_transactietype-rollback.sql
@@./010500/uninstall/scalaref/ref_transactietype-rollback.sql

commit;
PROMPT Einde rollback cws-db-1.5.0