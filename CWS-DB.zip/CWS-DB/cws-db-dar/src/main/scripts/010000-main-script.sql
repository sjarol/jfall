SET echo OFF
SET define ON
SET verify OFF
SET serveroutput ON
SET sqlblanklines ON

WHENEVER SQLERROR EXIT SQL.SQLCODE
WHENEVER OSERROR  EXIT FAILURE

--XL Deploy Checksum:486fbc4f5b0ed2c862ed8e16eb98c922--

PROMPT Start install cws-db-1.0.0
PROMPT Start 0-pre_install.sql
@@./010000/install/ppls_cws00/0-pre_install.sql
PROMPT Start 1-cws_meta_root.sql
@@./010000/install/ppls_cws00/1-cws_meta_root.sql
PROMPT Start 2-vul_cws_meta_root.sql
@@./010000/install/ppls_cws00/2-vul_cws_meta_root.sql
PROMPT Start 3-cws_meta_col.sql
@@./010000/install/ppls_cws00/3-cws_meta_col.sql
PROMPT Start 4-vul_cws_meta_col.sql
@@./010000/install/ppls_cws00/4-vul_cws_meta_col.sql
PROMPT Start 5-alter_cws_meta_col.sql
@@./010000/install/ppls_cws00/5-alter_cws_meta_col.sql
PROMPT Start 6-alter_en_vul_cws_configuratie.sql
@@./010000/install/ppls_cws00/6-alter_en_vul_cws_configuratie.sql
PROMPT Start 7-alter_en_vul_cws_con_col.sql
@@./010000/install/ppls_cws00/7-alter_en_vul_cws_con_col.sql
PROMPT Start 999-registreer_versie_in_database.sql
@@./010000/install/999-registreer_versie_in_database.sql

commit;
PROMPT Einde install cws-db-1.0.0