INSERT INTO PPLS_CWS00.CWS_CON_FILTER(ccon_id, lev_filter_id, value, his_ts_in, his_ts_end)
SELECT ccon_id
, (SELECT lev_filter_id FROM PPLS_CWS00.cws_lev_filter WHERE lev_cd='CWS-LA' and tech_naam='CD_SOORT_IKVS') AS lev_filter_id
, CD_SOORT_IKVS AS value
, systimestamp AS his_ts_in
, to_timestamp('99991231','YYYYMMDD') AS his_ts_end
FROM PPLS_CWS00.cws_configuratie ccon
UNION
SELECT ccon_id
, (SELECT lev_filter_id FROM PPLS_CWS00.cws_lev_filter WHERE lev_cd='CWS-LA' and tech_naam='MAX_LEVERPERIODE') AS lev_filter_id
, to_char(MAX_LEVERPERIODE) AS value
, systimestamp AS his_ts_in
, to_timestamp('99991231','YYYYMMDD') AS his_ts_end
FROM PPLS_CWS00.cws_configuratie ccon
UNION
SELECT ccon_id
, (SELECT lev_filter_id FROM PPLS_CWS00.cws_lev_filter WHERE lev_cd='CWS-LA' and tech_naam='NIHIL_LNSV_UITSLUITEN') AS lev_filter_id
, NIHIL_LNSV_UITSLUITEN AS value
, systimestamp AS his_ts_in
, to_timestamp('99991231','YYYYMMDD') AS his_ts_end
FROM PPLS_CWS00.cws_configuratie ccon
UNION
SELECT ccon_id
, (SELECT lev_filter_id FROM PPLS_CWS00.cws_lev_filter WHERE lev_cd='CWS-LA' and tech_naam='NIHIL_LNLBPH_UITSLUITEN') AS lev_filter_id
, NIHIL_LNLBPH_UITSLUITEN AS value
, systimestamp AS his_ts_in
, to_timestamp('99991231','YYYYMMDD') AS his_ts_end
FROM PPLS_CWS00.cws_configuratie ccon;

COMMIT;