DECLARE
    PROCEDURE modify_max_leverperiode IS
	    v_sql_stmnt VARCHAR2(512);
	    e_max_leverperiode_al_not_null EXCEPTION;
	    PRAGMA EXCEPTION_INIT(e_max_leverperiode_al_not_null, -01442);
	BEGIN
    	v_sql_stmnt := 'ALTER TABLE PPLS_CWS00.CWS_CONFIGURATIE MODIFY MAX_LEVERPERIODE NUMBER(3,0) NOT NULL';
    	execute immediate v_sql_stmnt;
	EXCEPTION
        WHEN e_max_leverperiode_al_not_null THEN
        dbms_output.put_line ('CWS_CONFIGURATIE.MAX_LEVERPERIODE was al NOT NULLable');
    END;
BEGIN
	modify_max_leverperiode();
END;
/
