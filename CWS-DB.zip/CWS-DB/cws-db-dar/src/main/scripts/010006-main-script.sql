SET echo OFF
SET define ON
SET verify OFF
SET serveroutput ON
SET sqlblanklines ON

WHENEVER SQLERROR EXIT SQL.SQLCODE
WHENEVER OSERROR  EXIT FAILURE

--XL Deploy Checksum:28c0b593175fc0ba9bf6508614ca0a81--

PROMPT Start install cws-db-1.0.6

-- ppls_cws00
PROMPT Start 001-vul_cws_meta_root.sql
@@./010006/install/ppls_cws00/001-vul_cws_meta_root.sql
PROMPT Start 002-vul_cws_meta_col.sql
@@./010006/install/ppls_cws00/002-vul_cws_meta_col.sql
PROMPT Start 003-grants.sql
@@./010006/install/ppls_cws00/003-grants.sql
PROMPT Start 004-synoniemen.sql
@@./010006/install/ppls_cws00/004-synoniemen.sql

-- scalalever
PROMPT Start 001-lev_properties.sql
@@./010006/install/scalalever/001-lev_properties.sql


PROMPT Start 999-registreer_versie_in_database.sql
@@./010006/install/999-registreer_versie_in_database.sql

commit;
PROMPT Einde install cws-db-1.0.6
