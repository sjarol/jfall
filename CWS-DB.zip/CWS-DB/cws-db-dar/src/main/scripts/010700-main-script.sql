SET echo OFF
SET define ON
SET verify OFF
SET serveroutput ON
SET sqlblanklines ON

WHENEVER SQLERROR EXIT SQL.SQLCODE
WHENEVER OSERROR  EXIT FAILURE

--XL Deploy Checksum:3679648530f52ae1bf1574c7fcbe712d--

PROMPT Start install cws-db-1.7.0

-- ppls_cws00
PROMPT Start 001-vul_cws_meta_root.sql
@@./010700/install/ppls_cws00/001-vul_cws_meta_root.sql
PROMPT Start 002-vul_cws_meta_col.sql
@@./010700/install/ppls_cws00/002-vul_cws_meta_col.sql

-- scalalever
PROMPT Start 001-lev_properties.sql
-- TODO aanzetten na aansluiten transformer
--@@./010700/install/scalalever/001-lev_properties.sql

PROMPT Start 999-registreer_versie_in_database.sql
@@./010700/install/999-registreer_versie_in_database.sql

commit;
PROMPT Einde install cws-db-1.7.0
