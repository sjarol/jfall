SET echo OFF
SET define ON
SET verify OFF
SET serveroutput ON
SET sqlblanklines ON

WHENEVER SQLERROR EXIT SQL.SQLCODE
WHENEVER OSERROR  EXIT FAILURE

PROMPT Start rollback cws-db-1.0.2
PROMPT Start 3-lev_properties-rollback.sql
@@./010002/uninstall/scalalever/3-lev_properties-rollback.sql
PROMPT Start 2-synoniemen-rollback.sql
@@./010002/uninstall/ppls_cws00/2-synoniemen-rollback.sql
PROMPT Start 1-grants-rollback.sql
@@./010002/uninstall/ppls_cws00/1-grants-rollback.sql
PROMPT Start 999-registreer_versie_in_database-rollback.sql
@@./010002/uninstall/999-registreer_versie_in_database-rollback.sql

commit;
PROMPT Einde rollback cws-db-1.0.2