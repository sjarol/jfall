SET echo OFF
SET define ON
SET verify OFF
SET serveroutput ON
SET sqlblanklines ON

WHENEVER SQLERROR EXIT SQL.SQLCODE
WHENEVER OSERROR  EXIT FAILURE

--XL Deploy Checksum:cc07c7258987e9f8d791eaf53b6cdd63--

PROMPT Start install cws-db-1.6.0

PROMPT Start alter_cws_con_col.sql
@@./010600/install/ppls_cws00/alter_cws_con_col.sql
PROMPT Start alter_cws_datamonitor.sql
@@./010600/install/ppls_cws00/alter_cws_datamonitor.sql
PROMPT Start alter_cws_meta_rubrieknr_gba.sql
@@./010600/install/ppls_cws00/alter_cws_meta_rubrieknr_gba.sql
PROMPT Start drop_cws_metadata.sql
@@./010600/install/ppls_cws00/drop_cws_metadata.sql

PROMPT Start 999-registreer_versie_in_database.sql
@@./010600/install/999-registreer_versie_in_database.sql

commit;
PROMPT Einde install cws-db-1.6.0
