SET echo OFF
SET define ON
SET verify OFF
SET serveroutput ON
SET sqlblanklines ON

WHENEVER SQLERROR EXIT SQL.SQLCODE
WHENEVER OSERROR  EXIT FAILURE

PROMPT Start rollback cws-db-1.6.0

PROMPT Start drop_cws_metadata-rollback.sql
@@./010600/uninstall/ppls_cws00/drop_cws_metadata-rollback.sql
PROMPT Start alter_cws_meta_rubrieknr_gba-rollback.sql
@@./010600/uninstall/ppls_cws00/alter_cws_meta_rubrieknr_gba-rollback.sql
PROMPT Start alter_cws_datamonitor-rollback.sql
@@./010600/uninstall/ppls_cws00/alter_cws_datamonitor-rollback.sql
PROMPT Start alter_cws_con_col-rollback.sql
@@./010600/uninstall/ppls_cws00/alter_cws_con_col-rollback.sql

PROMPT Start 999-registreer_versie_in_database-rollback.sql
@@./010600/uninstall/999-registreer_versie_in_database-rollback.sql

commit;
PROMPT Einde rollback cws-db-1.6.0