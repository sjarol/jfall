UPDATE PPLS_CWS00.CWS_META_COL
SET bron_rubriek = 'FAIL_SURS_IND'
WHERE meta_col_id = 6031;

UPDATE PPLS_CWS00.CWS_META_COL
SET bron_rubriek = 'FAIL_SURS_CODE'
WHERE meta_col_id = 6032;

commit;