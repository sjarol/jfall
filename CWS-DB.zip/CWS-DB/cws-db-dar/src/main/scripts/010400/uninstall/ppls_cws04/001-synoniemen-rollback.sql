-- ppls_lev
--DROP SYNONYM PPLS_CWS04.UPA_LEV_GET_UPANAAM;

DECLARE
    PROCEDURE drop_synonym(synonym_name IN VARCHAR2) IS
	    v_sql_stmnt VARCHAR2(512);
	    e_synonym_al_verwijderd EXCEPTION;
	    PRAGMA EXCEPTION_INIT(e_synonym_al_verwijderd, -01434);
	BEGIN
    	v_sql_stmnt := 'DROP SYNONYM '||synonym_name;
    	execute immediate v_sql_stmnt;
		dbms_output.put_line ('Het synonym ' || synonym_name || ' is succesvol verwijderd.');
	EXCEPTION
        WHEN e_synonym_al_verwijderd THEN
        dbms_output.put_line ('Het synonym ' || synonym_name || ' is al verwijderd.');
    END;
BEGIN
	drop_synonym('PPLS_CWS04.UPA_LEV_GET_UPANAAM');
END;
/

