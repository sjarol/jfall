DECLARE
    l_err_message varchar2(512);
BEGIN
    l_err_message := NULL;
    scalalever.lev_prop.set_property('CWS-HR','transformer.cwshr.berichtversie.max', '0106', 'Automatisch door CWS-DB package ingesteld', systimestamp, l_err_message);
    IF l_err_message IS NOT NULL THEN
        raise_application_error(-20001, l_err_message);
    END IF;
END;
/
