-- ppls_lev
--REVOKE EXECUTE ON PPLS_LEV.UPA_LEV_GET_UPANAAM FROM PPLS_CWS04;

DECLARE
    PROCEDURE revoke_grant( grant_type IN VARCHAR2
                          , grant_object IN VARCHAR2
                          , grant_owner IN varchar2) IS
	    v_sql_stmnt VARCHAR2(512);
	    e_grant_al_verwijderd EXCEPTION;
	    PRAGMA EXCEPTION_INIT(e_grant_al_verwijderd, -01927);
	BEGIN
    	v_sql_stmnt := 'REVOKE '||grant_type||' ON '||grant_object||' FROM '||grant_owner;
    	execute immediate v_sql_stmnt;
		dbms_output.put_line ('De grant ' || grant_type || ' op ' || grant_object || ' voor ' || grant_owner || ' is succesvol verwijderd.');
	EXCEPTION
        WHEN e_grant_al_verwijderd THEN
        dbms_output.put_line ('De grant ' || grant_type || ' op ' || grant_object || ' voor ' || grant_owner || ' was al verwijderd.');
    END;
BEGIN
	revoke_grant('EXECUTE', 'PPLS_LEV.UPA_LEV_GET_UPANAAM', 'PPLS_CWS04');
END;
/

