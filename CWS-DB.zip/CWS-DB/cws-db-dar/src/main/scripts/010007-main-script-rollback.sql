SET echo OFF
SET define ON
SET verify OFF
SET serveroutput ON
SET sqlblanklines ON

WHENEVER SQLERROR EXIT SQL.SQLCODE
WHENEVER OSERROR  EXIT FAILURE

PROMPT Start rollback cws-db-1.0.7

PROMPT Start 999-registreer_versie_in_database-rollback.sql
@@./010007/uninstall/999-registreer_versie_in_database-rollback.sql

-- ppls_cws00
PROMPT Start 001-update_cws_meta_col-rollback.sql
@@./010007/uninstall/ppls_cws00/001-update_cws_meta_col-rollback.sql

commit;
PROMPT Einde rollback cws-db-1.0.7