SET echo OFF
SET define ON
SET verify OFF
SET serveroutput ON
SET sqlblanklines ON

WHENEVER SQLERROR EXIT SQL.SQLCODE
WHENEVER OSERROR  EXIT FAILURE

--XL Deploy Checksum:14456a48e0a528c523ffa5b3e1e111f4--

PROMPT Start install cws-db-1.0.5

-- ppls_cws00
PROMPT Start 001-vul_cws_meta_root.sql
@@./010005/install/ppls_cws00/001-vul_cws_meta_root.sql
PROMPT Start 002-vul_cws_meta_col.sql
@@./010005/install/ppls_cws00/002-vul_cws_meta_col.sql
PROMPT Start 003-vul_cws_lev_filter.sql
@@./010005/install/ppls_cws00/003-vul_cws_lev_filter.sql
PROMPT Start 004-alter_cws_configuratie.sql
@@./010005/install/ppls_cws00/004-alter_cws_configuratie.sql

-- ppls_cws04
PROMPT Start 001-create_user.sql
@@./010005/install/ppls_cws04/001-create_user.sql
PROMPT Start 002-grants.sql
@@./010005/install/ppls_cws04/002-grants.sql
PROMPT Start 003-synoniemen.sql
@@./010005/install/ppls_cws04/003-synoniemen.sql

-- scalaafn
PROMPT Start afn_levering_type.sql
@@./010005/install/scalaafn/afn_levering_type.sql

-- scalameta
PROMPT Start 001_domainx.sql
@@./010005/install/scalameta/001-domainx.sql
PROMPT Start 002_columnx.sql
@@./010005/install/scalameta/002-columnx.sql


PROMPT Start 999-registreer_versie_in_database.sql
@@./010005/install/999-registreer_versie_in_database.sql

commit;
PROMPT Einde install cws-db-1.0.5
