SET echo OFF
SET define ON
SET verify OFF
SET serveroutput ON
SET sqlblanklines ON

WHENEVER SQLERROR EXIT SQL.SQLCODE
WHENEVER OSERROR  EXIT FAILURE

PROMPT Start rollback cws-db-upa-1.0.3

-- upa_cws03
PROMPT Start 001-create_user-rollback.sql
@@./010003/uninstall/upa_cws03/001-create_user-rollback.sql

commit;
PROMPT Einde rollback cws-db-upa-1.0.3
