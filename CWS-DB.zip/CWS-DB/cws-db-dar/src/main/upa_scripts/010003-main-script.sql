SET echo OFF
SET define ON
SET verify OFF
SET serveroutput ON
SET sqlblanklines ON

WHENEVER SQLERROR EXIT SQL.SQLCODE
WHENEVER OSERROR  EXIT FAILURE

--XL Deploy Checksum:145c6b741b9023b8380c9d6ca7fa34df--

PROMPT Start install cws-db-upa-1.0.3

-- upa_cws03
PROMPT Start 001-create_user.sql
@@./010003/install/upa_cws03/001-create_user.sql
PROMPT Start 002-grants.sql
@@./010003/install/upa_cws03/002-grants.sql
PROMPT Start 003-synoniemen.sql
@@./010003/install/upa_cws03/003-synoniemen.sql

commit;
PROMPT Einde install cws-db-upa-1.0.3
