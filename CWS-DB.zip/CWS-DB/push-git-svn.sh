#!/bin/bash

git svn rebase

git svn dcommit